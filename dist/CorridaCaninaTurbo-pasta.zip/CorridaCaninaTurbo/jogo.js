(()=>{var sh="160";var Ap=0,pu=1,Rp=2;var Zf=1,rh=2,Ei=3,qi=0,dn=1,Oe=2;var Wi=0,Xi=1,Zi=2,mu=3,gu=4,Cp=5,us=100,Pp=101,Ip=102,xu=103,yu=104,Lp=200,Dp=201,Up=202,Op=203,fl=204,dl=205,Np=206,Fp=207,zp=208,Bp=209,Hp=210,kp=211,Gp=212,Vp=213,Wp=214,Xp=0,Yp=1,$p=2,go=3,qp=4,Zp=5,Jp=6,Kp=7,Jf=0,jp=1,Qp=2,Yi=0,t0=1,e0=2,n0=3,ah=4,i0=5,s0=6;var Kf=300,lr=301,hr=302,pl=303,ml=304,Zo=306,Qr=1e3,jn=1001,gl=1002,sn=1003,_u=1004;var Lc=1005;var Bn=1006,r0=1007;var ta=1008;var $i=1009,a0=1010,o0=1011,oh=1012,jf=1013,Gi=1014,Vi=1015,ea=1016,Qf=1017,td=1018,ps=1020,c0=1021,Qn=1023,l0=1024,h0=1025,ms=1026,ur=1027,u0=1028,ed=1029,f0=1030,nd=1031,id=1033,Dc=33776,Uc=33777,Oc=33778,Nc=33779,vu=35840,Mu=35841,Eu=35842,Su=35843,sd=36196,bu=37492,Tu=37496,wu=37808,Au=37809,Ru=37810,Cu=37811,Pu=37812,Iu=37813,Lu=37814,Du=37815,Uu=37816,Ou=37817,Nu=37818,Fu=37819,zu=37820,Bu=37821,Fc=36492,Hu=36494,ku=36495,d0=36283,Gu=36284,Vu=36285,Wu=36286;var xo=2300,yo=2301,zc=2302,Xu=2400,Yu=2401,$u=2402;var rd=3e3,gs=3001,p0=3200,m0=3201,ad=0,g0=1,Hn="",be="srgb",Ti="srgb-linear",ch="display-p3",Jo="display-p3-linear",_o="linear",Pe="srgb",vo="rec709",Mo="p3";var Fs=7680;var qu=519,x0=512,y0=513,_0=514,od=515,v0=516,M0=517,E0=518,S0=519,xl=35044,cd=35048;var Zu="300 es",yl=1035,bi=2e3,Eo=2001,Ji=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let i=this._listeners;i[t]===void 0&&(i[t]=[]),i[t].indexOf(e)===-1&&i[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let i=this._listeners;return i[t]!==void 0&&i[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let s=this._listeners[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let i=this._listeners[t.type];if(i!==void 0){t.target=this;let s=i.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,t);t.target=null}}},un=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Ju=1234567,Yr=Math.PI/180,na=180/Math.PI;function ui(){let n=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(un[n&255]+un[n>>8&255]+un[n>>16&255]+un[n>>24&255]+"-"+un[t&255]+un[t>>8&255]+"-"+un[t>>16&15|64]+un[t>>24&255]+"-"+un[e&63|128]+un[e>>8&255]+"-"+un[e>>16&255]+un[e>>24&255]+un[i&255]+un[i>>8&255]+un[i>>16&255]+un[i>>24&255]).toLowerCase()}function on(n,t,e){return Math.max(t,Math.min(e,n))}function lh(n,t){return(n%t+t)%t}function b0(n,t,e,i,s){return i+(n-t)*(s-i)/(e-t)}function T0(n,t,e){return n!==t?(e-n)/(t-n):0}function $r(n,t,e){return(1-e)*n+e*t}function w0(n,t,e,i){return $r(n,t,1-Math.exp(-e*i))}function A0(n,t=1){return t-Math.abs(lh(n,t*2)-t)}function R0(n,t,e){return n<=t?0:n>=e?1:(n=(n-t)/(e-t),n*n*(3-2*n))}function C0(n,t,e){return n<=t?0:n>=e?1:(n=(n-t)/(e-t),n*n*n*(n*(n*6-15)+10))}function P0(n,t){return n+Math.floor(Math.random()*(t-n+1))}function I0(n,t){return n+Math.random()*(t-n)}function L0(n){return n*(.5-Math.random())}function D0(n){n!==void 0&&(Ju=n);let t=Ju+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function U0(n){return n*Yr}function O0(n){return n*na}function _l(n){return(n&n-1)===0&&n!==0}function N0(n){return Math.pow(2,Math.ceil(Math.log(n)/Math.LN2))}function So(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function F0(n,t,e,i,s){let r=Math.cos,a=Math.sin,o=r(e/2),c=a(e/2),l=r((t+i)/2),h=a((t+i)/2),u=r((t-i)/2),f=a((t-i)/2),d=r((i-t)/2),p=a((i-t)/2);switch(s){case"XYX":n.set(o*h,c*u,c*f,o*l);break;case"YZY":n.set(c*f,o*h,c*u,o*l);break;case"ZXZ":n.set(c*u,c*f,o*h,o*l);break;case"XZX":n.set(o*h,c*p,c*d,o*l);break;case"YXY":n.set(c*d,o*h,c*p,o*l);break;case"ZYZ":n.set(c*p,c*d,o*h,o*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function hi(n,t){switch(t.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function ve(n,t){switch(t.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}var ld={DEG2RAD:Yr,RAD2DEG:na,generateUUID:ui,clamp:on,euclideanModulo:lh,mapLinear:b0,inverseLerp:T0,lerp:$r,damp:w0,pingpong:A0,smoothstep:R0,smootherstep:C0,randInt:P0,randFloat:I0,randFloatSpread:L0,seededRandom:D0,degToRad:U0,radToDeg:O0,isPowerOfTwo:_l,ceilPowerOfTwo:N0,floorPowerOfTwo:So,setQuaternionFromProperEuler:F0,normalize:ve,denormalize:hi},ht=class n{constructor(t=0,e=0){n.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,i=this.y,s=t.elements;return this.x=s[0]*e+s[3]*i+s[6],this.y=s[1]*e+s[4]*i+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let i=this.dot(t)/e;return Math.acos(on(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,i=this.y-t.y;return e*e+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let i=Math.cos(e),s=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*i-a*s+t.x,this.y=r*s+a*i+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},ae=class n{constructor(t,e,i,s,r,a,o,c,l){n.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,i,s,r,a,o,c,l)}set(t,e,i,s,r,a,o,c,l){let h=this.elements;return h[0]=t,h[1]=s,h[2]=o,h[3]=e,h[4]=r,h[5]=c,h[6]=i,h[7]=a,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],this}extractBasis(t,e,i){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let i=t.elements,s=e.elements,r=this.elements,a=i[0],o=i[3],c=i[6],l=i[1],h=i[4],u=i[7],f=i[2],d=i[5],p=i[8],x=s[0],g=s[3],m=s[6],E=s[1],y=s[4],S=s[7],P=s[2],w=s[5],A=s[8];return r[0]=a*x+o*E+c*P,r[3]=a*g+o*y+c*w,r[6]=a*m+o*S+c*A,r[1]=l*x+h*E+u*P,r[4]=l*g+h*y+u*w,r[7]=l*m+h*S+u*A,r[2]=f*x+d*E+p*P,r[5]=f*g+d*y+p*w,r[8]=f*m+d*S+p*A,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8];return e*a*h-e*o*l-i*r*h+i*o*c+s*r*l-s*a*c}invert(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8],u=h*a-o*l,f=o*c-h*r,d=l*r-a*c,p=e*u+i*f+s*d;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let x=1/p;return t[0]=u*x,t[1]=(s*l-h*i)*x,t[2]=(o*i-s*a)*x,t[3]=f*x,t[4]=(h*e-s*c)*x,t[5]=(s*r-o*e)*x,t[6]=d*x,t[7]=(i*c-l*e)*x,t[8]=(a*e-i*r)*x,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,i,s,r,a,o){let c=Math.cos(r),l=Math.sin(r);return this.set(i*c,i*l,-i*(c*a+l*o)+a+t,-s*l,s*c,-s*(-l*a+c*o)+o+e,0,0,1),this}scale(t,e){return this.premultiply(Bc.makeScale(t,e)),this}rotate(t){return this.premultiply(Bc.makeRotation(-t)),this}translate(t,e){return this.premultiply(Bc.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,i,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,i=t.elements;for(let s=0;s<9;s++)if(e[s]!==i[s])return!1;return!0}fromArray(t,e=0){for(let i=0;i<9;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){let i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t}clone(){return new this.constructor().fromArray(this.elements)}},Bc=new ae;function hd(n){for(let t=n.length-1;t>=0;--t)if(n[t]>=65535)return!0;return!1}function bo(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function z0(){let n=bo("canvas");return n.style.display="block",n}var Ku={};function qr(n){n in Ku||(Ku[n]=!0,console.warn(n))}var ju=new ae().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Qu=new ae().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),Fa={[Ti]:{transfer:_o,primaries:vo,toReference:n=>n,fromReference:n=>n},[be]:{transfer:Pe,primaries:vo,toReference:n=>n.convertSRGBToLinear(),fromReference:n=>n.convertLinearToSRGB()},[Jo]:{transfer:_o,primaries:Mo,toReference:n=>n.applyMatrix3(Qu),fromReference:n=>n.applyMatrix3(ju)},[ch]:{transfer:Pe,primaries:Mo,toReference:n=>n.convertSRGBToLinear().applyMatrix3(Qu),fromReference:n=>n.applyMatrix3(ju).convertLinearToSRGB()}},B0=new Set([Ti,Jo]),Me={enabled:!0,_workingColorSpace:Ti,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(n){if(!B0.has(n))throw new Error(`Unsupported working color space, "${n}".`);this._workingColorSpace=n},convert:function(n,t,e){if(this.enabled===!1||t===e||!t||!e)return n;let i=Fa[t].toReference,s=Fa[e].fromReference;return s(i(n))},fromWorkingColorSpace:function(n,t){return this.convert(n,this._workingColorSpace,t)},toWorkingColorSpace:function(n,t){return this.convert(n,t,this._workingColorSpace)},getPrimaries:function(n){return Fa[n].primaries},getTransfer:function(n){return n===Hn?_o:Fa[n].transfer}};function or(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function Hc(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}var zs,To=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{zs===void 0&&(zs=bo("canvas")),zs.width=t.width,zs.height=t.height;let i=zs.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),e=zs}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=bo("canvas");e.width=t.width,e.height=t.height;let i=e.getContext("2d");i.drawImage(t,0,0,t.width,t.height);let s=i.getImageData(0,0,t.width,t.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=or(r[a]/255)*255;return i.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let i=0;i<e.length;i++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[i]=Math.floor(or(e[i]/255)*255):e[i]=or(e[i]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},H0=0,wo=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:H0++}),this.uuid=ui(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let i={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(kc(s[a].image)):r.push(kc(s[a]))}else r=kc(s);i.url=r}return e||(t.images[this.uuid]=i),i}};function kc(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?To.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var k0=0,kn=class n extends Ji{constructor(t=n.DEFAULT_IMAGE,e=n.DEFAULT_MAPPING,i=jn,s=jn,r=Bn,a=ta,o=Qn,c=$i,l=n.DEFAULT_ANISOTROPY,h=Hn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:k0++}),this.uuid=ui(),this.name="",this.source=new wo(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=i,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=c,this.offset=new ht(0,0),this.repeat=new ht(1,1),this.center=new ht(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new ae,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(qr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===gs?be:Hn),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),e||(t.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Kf)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Qr:t.x=t.x-Math.floor(t.x);break;case jn:t.x=t.x<0?0:1;break;case gl:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Qr:t.y=t.y-Math.floor(t.y);break;case jn:t.y=t.y<0?0:1;break;case gl:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return qr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===be?gs:rd}set encoding(t){qr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===gs?be:Hn}};kn.DEFAULT_IMAGE=null;kn.DEFAULT_MAPPING=Kf;kn.DEFAULT_ANISOTROPY=1;var We=class n{constructor(t=0,e=0,i=0,s=1){n.prototype.isVector4=!0,this.x=t,this.y=e,this.z=i,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,i,s){return this.x=t,this.y=e,this.z=i,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,i=this.y,s=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*i+a[8]*s+a[12]*r,this.y=a[1]*e+a[5]*i+a[9]*s+a[13]*r,this.z=a[2]*e+a[6]*i+a[10]*s+a[14]*r,this.w=a[3]*e+a[7]*i+a[11]*s+a[15]*r,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,i,s,r,c=t.elements,l=c[0],h=c[4],u=c[8],f=c[1],d=c[5],p=c[9],x=c[2],g=c[6],m=c[10];if(Math.abs(h-f)<.01&&Math.abs(u-x)<.01&&Math.abs(p-g)<.01){if(Math.abs(h+f)<.1&&Math.abs(u+x)<.1&&Math.abs(p+g)<.1&&Math.abs(l+d+m-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let y=(l+1)/2,S=(d+1)/2,P=(m+1)/2,w=(h+f)/4,A=(u+x)/4,F=(p+g)/4;return y>S&&y>P?y<.01?(i=0,s=.707106781,r=.707106781):(i=Math.sqrt(y),s=w/i,r=A/i):S>P?S<.01?(i=.707106781,s=0,r=.707106781):(s=Math.sqrt(S),i=w/s,r=F/s):P<.01?(i=.707106781,s=.707106781,r=0):(r=Math.sqrt(P),i=A/r,s=F/r),this.set(i,s,r,e),this}let E=Math.sqrt((g-p)*(g-p)+(u-x)*(u-x)+(f-h)*(f-h));return Math.abs(E)<.001&&(E=1),this.x=(g-p)/E,this.y=(u-x)/E,this.z=(f-h)/E,this.w=Math.acos((l+d+m-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this.w=t.w+(e.w-t.w)*i,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},vl=class extends Ji{constructor(t=1,e=1,i={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new We(0,0,t,e),this.scissorTest=!1,this.viewport=new We(0,0,t,e);let s={width:t,height:e,depth:1};i.encoding!==void 0&&(qr("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===gs?be:Hn),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Bn,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new kn(s,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(t,e,i=1){(this.width!==t||this.height!==e||this.depth!==i)&&(this.width=t,this.height=e,this.depth=i,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new wo(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},wi=class extends vl{constructor(t=1,e=1,i={}){super(t,e,i),this.isWebGLRenderTarget=!0}},Ao=class extends kn{constructor(t=null,e=1,i=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=sn,this.minFilter=sn,this.wrapR=jn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Ml=class extends kn{constructor(t=null,e=1,i=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=sn,this.minFilter=sn,this.wrapR=jn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var fi=class{constructor(t=0,e=0,i=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=i,this._w=s}static slerpFlat(t,e,i,s,r,a,o){let c=i[s+0],l=i[s+1],h=i[s+2],u=i[s+3],f=r[a+0],d=r[a+1],p=r[a+2],x=r[a+3];if(o===0){t[e+0]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u;return}if(o===1){t[e+0]=f,t[e+1]=d,t[e+2]=p,t[e+3]=x;return}if(u!==x||c!==f||l!==d||h!==p){let g=1-o,m=c*f+l*d+h*p+u*x,E=m>=0?1:-1,y=1-m*m;if(y>Number.EPSILON){let P=Math.sqrt(y),w=Math.atan2(P,m*E);g=Math.sin(g*w)/P,o=Math.sin(o*w)/P}let S=o*E;if(c=c*g+f*S,l=l*g+d*S,h=h*g+p*S,u=u*g+x*S,g===1-o){let P=1/Math.sqrt(c*c+l*l+h*h+u*u);c*=P,l*=P,h*=P,u*=P}}t[e]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,i,s,r,a){let o=i[s],c=i[s+1],l=i[s+2],h=i[s+3],u=r[a],f=r[a+1],d=r[a+2],p=r[a+3];return t[e]=o*p+h*u+c*d-l*f,t[e+1]=c*p+h*f+l*u-o*d,t[e+2]=l*p+h*d+o*f-c*u,t[e+3]=h*p-o*u-c*f-l*d,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,i,s){return this._x=t,this._y=e,this._z=i,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let i=t._x,s=t._y,r=t._z,a=t._order,o=Math.cos,c=Math.sin,l=o(i/2),h=o(s/2),u=o(r/2),f=c(i/2),d=c(s/2),p=c(r/2);switch(a){case"XYZ":this._x=f*h*u+l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u-f*d*p;break;case"YXZ":this._x=f*h*u+l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u+f*d*p;break;case"ZXY":this._x=f*h*u-l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u-f*d*p;break;case"ZYX":this._x=f*h*u-l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u+f*d*p;break;case"YZX":this._x=f*h*u+l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u-f*d*p;break;case"XZY":this._x=f*h*u-l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u+f*d*p;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let i=e/2,s=Math.sin(i);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,i=e[0],s=e[4],r=e[8],a=e[1],o=e[5],c=e[9],l=e[2],h=e[6],u=e[10],f=i+o+u;if(f>0){let d=.5/Math.sqrt(f+1);this._w=.25/d,this._x=(h-c)*d,this._y=(r-l)*d,this._z=(a-s)*d}else if(i>o&&i>u){let d=2*Math.sqrt(1+i-o-u);this._w=(h-c)/d,this._x=.25*d,this._y=(s+a)/d,this._z=(r+l)/d}else if(o>u){let d=2*Math.sqrt(1+o-i-u);this._w=(r-l)/d,this._x=(s+a)/d,this._y=.25*d,this._z=(c+h)/d}else{let d=2*Math.sqrt(1+u-i-o);this._w=(a-s)/d,this._x=(r+l)/d,this._y=(c+h)/d,this._z=.25*d}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let i=t.dot(e)+1;return i<Number.EPSILON?(i=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=i):(this._x=0,this._y=-t.z,this._z=t.y,this._w=i)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=i),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(on(this.dot(t),-1,1)))}rotateTowards(t,e){let i=this.angleTo(t);if(i===0)return this;let s=Math.min(1,e/i);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let i=t._x,s=t._y,r=t._z,a=t._w,o=e._x,c=e._y,l=e._z,h=e._w;return this._x=i*h+a*o+s*l-r*c,this._y=s*h+a*c+r*o-i*l,this._z=r*h+a*l+i*c-s*o,this._w=a*h-i*o-s*c-r*l,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let i=this._x,s=this._y,r=this._z,a=this._w,o=a*t._w+i*t._x+s*t._y+r*t._z;if(o<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,o=-o):this.copy(t),o>=1)return this._w=a,this._x=i,this._y=s,this._z=r,this;let c=1-o*o;if(c<=Number.EPSILON){let d=1-e;return this._w=d*a+e*this._w,this._x=d*i+e*this._x,this._y=d*s+e*this._y,this._z=d*r+e*this._z,this.normalize(),this}let l=Math.sqrt(c),h=Math.atan2(l,o),u=Math.sin((1-e)*h)/l,f=Math.sin(e*h)/l;return this._w=a*u+this._w*f,this._x=i*u+this._x*f,this._y=s*u+this._y*f,this._z=r*u+this._z*f,this._onChangeCallback(),this}slerpQuaternions(t,e,i){return this.copy(t).slerp(e,i)}random(){let t=Math.random(),e=Math.sqrt(1-t),i=Math.sqrt(t),s=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(e*Math.cos(s),i*Math.sin(r),i*Math.cos(r),e*Math.sin(s))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},L=class n{constructor(t=0,e=0,i=0){n.prototype.isVector3=!0,this.x=t,this.y=e,this.z=i}set(t,e,i){return i===void 0&&(i=this.z),this.x=t,this.y=e,this.z=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(tf.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(tf.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,i=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*i+r[6]*s,this.y=r[1]*e+r[4]*i+r[7]*s,this.z=r[2]*e+r[5]*i+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,i=this.y,s=this.z,r=t.elements,a=1/(r[3]*e+r[7]*i+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*i+r[8]*s+r[12])*a,this.y=(r[1]*e+r[5]*i+r[9]*s+r[13])*a,this.z=(r[2]*e+r[6]*i+r[10]*s+r[14])*a,this}applyQuaternion(t){let e=this.x,i=this.y,s=this.z,r=t.x,a=t.y,o=t.z,c=t.w,l=2*(a*s-o*i),h=2*(o*e-r*s),u=2*(r*i-a*e);return this.x=e+c*l+a*u-o*h,this.y=i+c*h+o*l-r*u,this.z=s+c*u+r*h-a*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,i=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*i+r[8]*s,this.y=r[1]*e+r[5]*i+r[9]*s,this.z=r[2]*e+r[6]*i+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let i=t.x,s=t.y,r=t.z,a=e.x,o=e.y,c=e.z;return this.x=s*c-r*o,this.y=r*a-i*c,this.z=i*o-s*a,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let i=t.dot(this)/e;return this.copy(t).multiplyScalar(i)}projectOnPlane(t){return Gc.copy(this).projectOnVector(t),this.sub(Gc)}reflect(t){return this.sub(Gc.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let i=this.dot(t)/e;return Math.acos(on(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,i=this.y-t.y,s=this.z-t.z;return e*e+i*i+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,i){let s=Math.sin(e)*t;return this.x=s*Math.sin(i),this.y=Math.cos(e)*t,this.z=s*Math.cos(i),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,i){return this.x=t*Math.sin(e),this.y=i,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),i=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=i,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,i=Math.sqrt(1-t**2);return this.x=i*Math.cos(e),this.y=i*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Gc=new L,tf=new fi,Gn=class{constructor(t=new L(1/0,1/0,1/0),e=new L(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e+=3)this.expandByPoint(Zn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,i=t.count;e<i;e++)this.expandByPoint(Zn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let i=Zn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(i),this.max.copy(t).add(i),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let i=t.geometry;if(i!==void 0){let r=i.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,Zn):Zn.fromBufferAttribute(r,a),Zn.applyMatrix4(t.matrixWorld),this.expandByPoint(Zn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),za.copy(t.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),za.copy(i.boundingBox)),za.applyMatrix4(t.matrixWorld),this.union(za)}let s=t.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,Zn),Zn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,i;return t.normal.x>0?(e=t.normal.x*this.min.x,i=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,i=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,i+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,i+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,i+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,i+=t.normal.z*this.min.z),e<=-t.constant&&i>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Fr),Ba.subVectors(this.max,Fr),Bs.subVectors(t.a,Fr),Hs.subVectors(t.b,Fr),ks.subVectors(t.c,Fr),Fi.subVectors(Hs,Bs),zi.subVectors(ks,Hs),as.subVectors(Bs,ks);let e=[0,-Fi.z,Fi.y,0,-zi.z,zi.y,0,-as.z,as.y,Fi.z,0,-Fi.x,zi.z,0,-zi.x,as.z,0,-as.x,-Fi.y,Fi.x,0,-zi.y,zi.x,0,-as.y,as.x,0];return!Vc(e,Bs,Hs,ks,Ba)||(e=[1,0,0,0,1,0,0,0,1],!Vc(e,Bs,Hs,ks,Ba))?!1:(Ha.crossVectors(Fi,zi),e=[Ha.x,Ha.y,Ha.z],Vc(e,Bs,Hs,ks,Ba))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Zn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Zn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(xi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),xi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),xi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),xi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),xi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),xi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),xi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),xi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(xi),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},xi=[new L,new L,new L,new L,new L,new L,new L,new L],Zn=new L,za=new Gn,Bs=new L,Hs=new L,ks=new L,Fi=new L,zi=new L,as=new L,Fr=new L,Ba=new L,Ha=new L,os=new L;function Vc(n,t,e,i,s){for(let r=0,a=n.length-3;r<=a;r+=3){os.fromArray(n,r);let o=s.x*Math.abs(os.x)+s.y*Math.abs(os.y)+s.z*Math.abs(os.z),c=t.dot(os),l=e.dot(os),h=i.dot(os);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>o)return!1}return!0}var G0=new Gn,zr=new L,Wc=new L,Ki=class{constructor(t=new L,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let i=this.center;e!==void 0?i.copy(e):G0.setFromPoints(t).getCenter(i);let s=0;for(let r=0,a=t.length;r<a;r++)s=Math.max(s,i.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let i=this.center.distanceToSquared(t);return e.copy(t),i>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;zr.subVectors(t,this.center);let e=zr.lengthSq();if(e>this.radius*this.radius){let i=Math.sqrt(e),s=(i-this.radius)*.5;this.center.addScaledVector(zr,s/i),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Wc.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(zr.copy(t.center).add(Wc)),this.expandByPoint(zr.copy(t.center).sub(Wc))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},yi=new L,Xc=new L,ka=new L,Bi=new L,Yc=new L,Ga=new L,$c=new L,ia=class{constructor(t=new L,e=new L(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,yi)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let i=e.dot(this.direction);return i<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=yi.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(yi.copy(this.origin).addScaledVector(this.direction,e),yi.distanceToSquared(t))}distanceSqToSegment(t,e,i,s){Xc.copy(t).add(e).multiplyScalar(.5),ka.copy(e).sub(t).normalize(),Bi.copy(this.origin).sub(Xc);let r=t.distanceTo(e)*.5,a=-this.direction.dot(ka),o=Bi.dot(this.direction),c=-Bi.dot(ka),l=Bi.lengthSq(),h=Math.abs(1-a*a),u,f,d,p;if(h>0)if(u=a*c-o,f=a*o-c,p=r*h,u>=0)if(f>=-p)if(f<=p){let x=1/h;u*=x,f*=x,d=u*(u+a*f+2*o)+f*(a*u+f+2*c)+l}else f=r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;else f=-r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;else f<=-p?(u=Math.max(0,-(-a*r+o)),f=u>0?-r:Math.min(Math.max(-r,-c),r),d=-u*u+f*(f+2*c)+l):f<=p?(u=0,f=Math.min(Math.max(-r,-c),r),d=f*(f+2*c)+l):(u=Math.max(0,-(a*r+o)),f=u>0?r:Math.min(Math.max(-r,-c),r),d=-u*u+f*(f+2*c)+l);else f=a>0?-r:r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;return i&&i.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(Xc).addScaledVector(ka,f),d}intersectSphere(t,e){yi.subVectors(t.center,this.origin);let i=yi.dot(this.direction),s=yi.dot(yi)-i*i,r=t.radius*t.radius;if(s>r)return null;let a=Math.sqrt(r-s),o=i-a,c=i+a;return c<0?null:o<0?this.at(c,e):this.at(o,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let i=-(this.origin.dot(t.normal)+t.constant)/e;return i>=0?i:null}intersectPlane(t,e){let i=this.distanceToPlane(t);return i===null?null:this.at(i,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let i,s,r,a,o,c,l=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,f=this.origin;return l>=0?(i=(t.min.x-f.x)*l,s=(t.max.x-f.x)*l):(i=(t.max.x-f.x)*l,s=(t.min.x-f.x)*l),h>=0?(r=(t.min.y-f.y)*h,a=(t.max.y-f.y)*h):(r=(t.max.y-f.y)*h,a=(t.min.y-f.y)*h),i>a||r>s||((r>i||isNaN(i))&&(i=r),(a<s||isNaN(s))&&(s=a),u>=0?(o=(t.min.z-f.z)*u,c=(t.max.z-f.z)*u):(o=(t.max.z-f.z)*u,c=(t.min.z-f.z)*u),i>c||o>s)||((o>i||i!==i)&&(i=o),(c<s||s!==s)&&(s=c),s<0)?null:this.at(i>=0?i:s,e)}intersectsBox(t){return this.intersectBox(t,yi)!==null}intersectTriangle(t,e,i,s,r){Yc.subVectors(e,t),Ga.subVectors(i,t),$c.crossVectors(Yc,Ga);let a=this.direction.dot($c),o;if(a>0){if(s)return null;o=1}else if(a<0)o=-1,a=-a;else return null;Bi.subVectors(this.origin,t);let c=o*this.direction.dot(Ga.crossVectors(Bi,Ga));if(c<0)return null;let l=o*this.direction.dot(Yc.cross(Bi));if(l<0||c+l>a)return null;let h=-o*Bi.dot($c);return h<0?null:this.at(h/a,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Ce=class n{constructor(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g){n.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g)}set(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g){let m=this.elements;return m[0]=t,m[4]=e,m[8]=i,m[12]=s,m[1]=r,m[5]=a,m[9]=o,m[13]=c,m[2]=l,m[6]=h,m[10]=u,m[14]=f,m[3]=d,m[7]=p,m[11]=x,m[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new n().fromArray(this.elements)}copy(t){let e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],e[9]=i[9],e[10]=i[10],e[11]=i[11],e[12]=i[12],e[13]=i[13],e[14]=i[14],e[15]=i[15],this}copyPosition(t){let e=this.elements,i=t.elements;return e[12]=i[12],e[13]=i[13],e[14]=i[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,i){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(t,e,i){return this.set(t.x,e.x,i.x,0,t.y,e.y,i.y,0,t.z,e.z,i.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,i=t.elements,s=1/Gs.setFromMatrixColumn(t,0).length(),r=1/Gs.setFromMatrixColumn(t,1).length(),a=1/Gs.setFromMatrixColumn(t,2).length();return e[0]=i[0]*s,e[1]=i[1]*s,e[2]=i[2]*s,e[3]=0,e[4]=i[4]*r,e[5]=i[5]*r,e[6]=i[6]*r,e[7]=0,e[8]=i[8]*a,e[9]=i[9]*a,e[10]=i[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,i=t.x,s=t.y,r=t.z,a=Math.cos(i),o=Math.sin(i),c=Math.cos(s),l=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){let f=a*h,d=a*u,p=o*h,x=o*u;e[0]=c*h,e[4]=-c*u,e[8]=l,e[1]=d+p*l,e[5]=f-x*l,e[9]=-o*c,e[2]=x-f*l,e[6]=p+d*l,e[10]=a*c}else if(t.order==="YXZ"){let f=c*h,d=c*u,p=l*h,x=l*u;e[0]=f+x*o,e[4]=p*o-d,e[8]=a*l,e[1]=a*u,e[5]=a*h,e[9]=-o,e[2]=d*o-p,e[6]=x+f*o,e[10]=a*c}else if(t.order==="ZXY"){let f=c*h,d=c*u,p=l*h,x=l*u;e[0]=f-x*o,e[4]=-a*u,e[8]=p+d*o,e[1]=d+p*o,e[5]=a*h,e[9]=x-f*o,e[2]=-a*l,e[6]=o,e[10]=a*c}else if(t.order==="ZYX"){let f=a*h,d=a*u,p=o*h,x=o*u;e[0]=c*h,e[4]=p*l-d,e[8]=f*l+x,e[1]=c*u,e[5]=x*l+f,e[9]=d*l-p,e[2]=-l,e[6]=o*c,e[10]=a*c}else if(t.order==="YZX"){let f=a*c,d=a*l,p=o*c,x=o*l;e[0]=c*h,e[4]=x-f*u,e[8]=p*u+d,e[1]=u,e[5]=a*h,e[9]=-o*h,e[2]=-l*h,e[6]=d*u+p,e[10]=f-x*u}else if(t.order==="XZY"){let f=a*c,d=a*l,p=o*c,x=o*l;e[0]=c*h,e[4]=-u,e[8]=l*h,e[1]=f*u+x,e[5]=a*h,e[9]=d*u-p,e[2]=p*u-d,e[6]=o*h,e[10]=x*u+f}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(V0,t,W0)}lookAt(t,e,i){let s=this.elements;return Pn.subVectors(t,e),Pn.lengthSq()===0&&(Pn.z=1),Pn.normalize(),Hi.crossVectors(i,Pn),Hi.lengthSq()===0&&(Math.abs(i.z)===1?Pn.x+=1e-4:Pn.z+=1e-4,Pn.normalize(),Hi.crossVectors(i,Pn)),Hi.normalize(),Va.crossVectors(Pn,Hi),s[0]=Hi.x,s[4]=Va.x,s[8]=Pn.x,s[1]=Hi.y,s[5]=Va.y,s[9]=Pn.y,s[2]=Hi.z,s[6]=Va.z,s[10]=Pn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let i=t.elements,s=e.elements,r=this.elements,a=i[0],o=i[4],c=i[8],l=i[12],h=i[1],u=i[5],f=i[9],d=i[13],p=i[2],x=i[6],g=i[10],m=i[14],E=i[3],y=i[7],S=i[11],P=i[15],w=s[0],A=s[4],F=s[8],M=s[12],b=s[1],R=s[5],O=s[9],Z=s[13],I=s[2],N=s[6],H=s[10],nt=s[14],B=s[3],W=s[7],Q=s[11],tt=s[15];return r[0]=a*w+o*b+c*I+l*B,r[4]=a*A+o*R+c*N+l*W,r[8]=a*F+o*O+c*H+l*Q,r[12]=a*M+o*Z+c*nt+l*tt,r[1]=h*w+u*b+f*I+d*B,r[5]=h*A+u*R+f*N+d*W,r[9]=h*F+u*O+f*H+d*Q,r[13]=h*M+u*Z+f*nt+d*tt,r[2]=p*w+x*b+g*I+m*B,r[6]=p*A+x*R+g*N+m*W,r[10]=p*F+x*O+g*H+m*Q,r[14]=p*M+x*Z+g*nt+m*tt,r[3]=E*w+y*b+S*I+P*B,r[7]=E*A+y*R+S*N+P*W,r[11]=E*F+y*O+S*H+P*Q,r[15]=E*M+y*Z+S*nt+P*tt,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],i=t[4],s=t[8],r=t[12],a=t[1],o=t[5],c=t[9],l=t[13],h=t[2],u=t[6],f=t[10],d=t[14],p=t[3],x=t[7],g=t[11],m=t[15];return p*(+r*c*u-s*l*u-r*o*f+i*l*f+s*o*d-i*c*d)+x*(+e*c*d-e*l*f+r*a*f-s*a*d+s*l*h-r*c*h)+g*(+e*l*u-e*o*d-r*a*u+i*a*d+r*o*h-i*l*h)+m*(-s*o*h-e*c*u+e*o*f+s*a*u-i*a*f+i*c*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,i){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=i),this}invert(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8],u=t[9],f=t[10],d=t[11],p=t[12],x=t[13],g=t[14],m=t[15],E=u*g*l-x*f*l+x*c*d-o*g*d-u*c*m+o*f*m,y=p*f*l-h*g*l-p*c*d+a*g*d+h*c*m-a*f*m,S=h*x*l-p*u*l+p*o*d-a*x*d-h*o*m+a*u*m,P=p*u*c-h*x*c-p*o*f+a*x*f+h*o*g-a*u*g,w=e*E+i*y+s*S+r*P;if(w===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let A=1/w;return t[0]=E*A,t[1]=(x*f*r-u*g*r-x*s*d+i*g*d+u*s*m-i*f*m)*A,t[2]=(o*g*r-x*c*r+x*s*l-i*g*l-o*s*m+i*c*m)*A,t[3]=(u*c*r-o*f*r-u*s*l+i*f*l+o*s*d-i*c*d)*A,t[4]=y*A,t[5]=(h*g*r-p*f*r+p*s*d-e*g*d-h*s*m+e*f*m)*A,t[6]=(p*c*r-a*g*r-p*s*l+e*g*l+a*s*m-e*c*m)*A,t[7]=(a*f*r-h*c*r+h*s*l-e*f*l-a*s*d+e*c*d)*A,t[8]=S*A,t[9]=(p*u*r-h*x*r-p*i*d+e*x*d+h*i*m-e*u*m)*A,t[10]=(a*x*r-p*o*r+p*i*l-e*x*l-a*i*m+e*o*m)*A,t[11]=(h*o*r-a*u*r-h*i*l+e*u*l+a*i*d-e*o*d)*A,t[12]=P*A,t[13]=(h*x*s-p*u*s+p*i*f-e*x*f-h*i*g+e*u*g)*A,t[14]=(p*o*s-a*x*s-p*i*c+e*x*c+a*i*g-e*o*g)*A,t[15]=(a*u*s-h*o*s+h*i*c-e*u*c-a*i*f+e*o*f)*A,this}scale(t){let e=this.elements,i=t.x,s=t.y,r=t.z;return e[0]*=i,e[4]*=s,e[8]*=r,e[1]*=i,e[5]*=s,e[9]*=r,e[2]*=i,e[6]*=s,e[10]*=r,e[3]*=i,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],i=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,i,s))}makeTranslation(t,e,i){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,i,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),i=Math.sin(t);return this.set(1,0,0,0,0,e,-i,0,0,i,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,0,i,0,0,1,0,0,-i,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,0,i,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let i=Math.cos(e),s=Math.sin(e),r=1-i,a=t.x,o=t.y,c=t.z,l=r*a,h=r*o;return this.set(l*a+i,l*o-s*c,l*c+s*o,0,l*o+s*c,h*o+i,h*c-s*a,0,l*c-s*o,h*c+s*a,r*c*c+i,0,0,0,0,1),this}makeScale(t,e,i){return this.set(t,0,0,0,0,e,0,0,0,0,i,0,0,0,0,1),this}makeShear(t,e,i,s,r,a){return this.set(1,i,r,0,t,1,a,0,e,s,1,0,0,0,0,1),this}compose(t,e,i){let s=this.elements,r=e._x,a=e._y,o=e._z,c=e._w,l=r+r,h=a+a,u=o+o,f=r*l,d=r*h,p=r*u,x=a*h,g=a*u,m=o*u,E=c*l,y=c*h,S=c*u,P=i.x,w=i.y,A=i.z;return s[0]=(1-(x+m))*P,s[1]=(d+S)*P,s[2]=(p-y)*P,s[3]=0,s[4]=(d-S)*w,s[5]=(1-(f+m))*w,s[6]=(g+E)*w,s[7]=0,s[8]=(p+y)*A,s[9]=(g-E)*A,s[10]=(1-(f+x))*A,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,i){let s=this.elements,r=Gs.set(s[0],s[1],s[2]).length(),a=Gs.set(s[4],s[5],s[6]).length(),o=Gs.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],Jn.copy(this);let l=1/r,h=1/a,u=1/o;return Jn.elements[0]*=l,Jn.elements[1]*=l,Jn.elements[2]*=l,Jn.elements[4]*=h,Jn.elements[5]*=h,Jn.elements[6]*=h,Jn.elements[8]*=u,Jn.elements[9]*=u,Jn.elements[10]*=u,e.setFromRotationMatrix(Jn),i.x=r,i.y=a,i.z=o,this}makePerspective(t,e,i,s,r,a,o=bi){let c=this.elements,l=2*r/(e-t),h=2*r/(i-s),u=(e+t)/(e-t),f=(i+s)/(i-s),d,p;if(o===bi)d=-(a+r)/(a-r),p=-2*a*r/(a-r);else if(o===Eo)d=-a/(a-r),p=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=l,c[4]=0,c[8]=u,c[12]=0,c[1]=0,c[5]=h,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=d,c[14]=p,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,i,s,r,a,o=bi){let c=this.elements,l=1/(e-t),h=1/(i-s),u=1/(a-r),f=(e+t)*l,d=(i+s)*h,p,x;if(o===bi)p=(a+r)*u,x=-2*u;else if(o===Eo)p=r*u,x=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-f,c[1]=0,c[5]=2*h,c[9]=0,c[13]=-d,c[2]=0,c[6]=0,c[10]=x,c[14]=-p,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){let e=this.elements,i=t.elements;for(let s=0;s<16;s++)if(e[s]!==i[s])return!1;return!0}fromArray(t,e=0){for(let i=0;i<16;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){let i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t[e+9]=i[9],t[e+10]=i[10],t[e+11]=i[11],t[e+12]=i[12],t[e+13]=i[13],t[e+14]=i[14],t[e+15]=i[15],t}},Gs=new L,Jn=new Ce,V0=new L(0,0,0),W0=new L(1,1,1),Hi=new L,Va=new L,Pn=new L,ef=new Ce,nf=new fi,fr=class n{constructor(t=0,e=0,i=0,s=n.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=i,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,i,s=this._order){return this._x=t,this._y=e,this._z=i,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,i=!0){let s=t.elements,r=s[0],a=s[4],o=s[8],c=s[1],l=s[5],h=s[9],u=s[2],f=s[6],d=s[10];switch(e){case"XYZ":this._y=Math.asin(on(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,d),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(f,l),this._z=0);break;case"YXZ":this._x=Math.asin(-on(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,d),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(on(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(-u,d),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-on(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(f,d),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(on(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(o,d));break;case"XZY":this._z=Math.asin(-on(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(f,l),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,d),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,i===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,i){return ef.makeRotationFromQuaternion(t),this.setFromRotationMatrix(ef,e,i)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return nf.setFromEuler(this),this.setFromQuaternion(nf,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};fr.DEFAULT_ORDER="XYZ";var sa=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},X0=0,sf=new L,Vs=new fi,_i=new Ce,Wa=new L,Br=new L,Y0=new L,$0=new fi,rf=new L(1,0,0),af=new L(0,1,0),of=new L(0,0,1),q0={type:"added"},Z0={type:"removed"},Ze=class n extends Ji{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:X0++}),this.uuid=ui(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=n.DEFAULT_UP.clone();let t=new L,e=new fr,i=new fi,s=new L(1,1,1);function r(){i.setFromEuler(e,!1)}function a(){e.setFromQuaternion(i,void 0,!1)}e._onChange(r),i._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Ce},normalMatrix:{value:new ae}}),this.matrix=new Ce,this.matrixWorld=new Ce,this.matrixAutoUpdate=n.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=n.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new sa,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Vs.setFromAxisAngle(t,e),this.quaternion.multiply(Vs),this}rotateOnWorldAxis(t,e){return Vs.setFromAxisAngle(t,e),this.quaternion.premultiply(Vs),this}rotateX(t){return this.rotateOnAxis(rf,t)}rotateY(t){return this.rotateOnAxis(af,t)}rotateZ(t){return this.rotateOnAxis(of,t)}translateOnAxis(t,e){return sf.copy(t).applyQuaternion(this.quaternion),this.position.add(sf.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(rf,t)}translateY(t){return this.translateOnAxis(af,t)}translateZ(t){return this.translateOnAxis(of,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(_i.copy(this.matrixWorld).invert())}lookAt(t,e,i){t.isVector3?Wa.copy(t):Wa.set(t,e,i);let s=this.parent;this.updateWorldMatrix(!0,!1),Br.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?_i.lookAt(Br,Wa,this.up):_i.lookAt(Wa,Br,this.up),this.quaternion.setFromRotationMatrix(_i),s&&(_i.extractRotation(s.matrixWorld),Vs.setFromRotationMatrix(_i),this.quaternion.premultiply(Vs.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(q0)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Z0)),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),_i.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),_i.multiply(t.parent.matrixWorld)),t.applyMatrix4(_i),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let i=0,s=this.children.length;i<s;i++){let a=this.children[i].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,i=[]){this[t]===e&&i.push(this);let s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(t,e,i);return i}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Br,t,Y0),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Br,$0,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let i=0,s=e.length;i<s;i++)e[i].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let i=0,s=e.length;i<s;i++)e[i].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let i=0,s=e.length;i<s;i++){let r=e[i];(r.matrixWorldAutoUpdate===!0||t===!0)&&r.updateMatrixWorld(t)}}updateWorldMatrix(t,e){let i=this.parent;if(t===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){let s=this.children;for(let r=0,a=s.length;r<a;r++){let o=s[r];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(t){let e=t===void 0||typeof t=="string",i={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),s.maxGeometryCount=this._maxGeometryCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let c=o.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){let u=c[l];r(t.shapes,u)}else r(t.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let c=0,l=this.material.length;c<l;c++)o.push(r(t.materials,this.material[c]));s.material=o}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){let c=this.animations[o];s.animations.push(r(t.animations,c))}}if(e){let o=a(t.geometries),c=a(t.materials),l=a(t.textures),h=a(t.images),u=a(t.shapes),f=a(t.skeletons),d=a(t.animations),p=a(t.nodes);o.length>0&&(i.geometries=o),c.length>0&&(i.materials=c),l.length>0&&(i.textures=l),h.length>0&&(i.images=h),u.length>0&&(i.shapes=u),f.length>0&&(i.skeletons=f),d.length>0&&(i.animations=d),p.length>0&&(i.nodes=p)}return i.object=s,i;function a(o){let c=[];for(let l in o){let h=o[l];delete h.metadata,c.push(h)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let i=0;i<t.children.length;i++){let s=t.children[i];this.add(s.clone())}return this}};Ze.DEFAULT_UP=new L(0,1,0);Ze.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ze.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Kn=new L,vi=new L,qc=new L,Mi=new L,Ws=new L,Xs=new L,cf=new L,Zc=new L,Jc=new L,Kc=new L,Xa=!1,ds=class n{constructor(t=new L,e=new L,i=new L){this.a=t,this.b=e,this.c=i}static getNormal(t,e,i,s){s.subVectors(i,e),Kn.subVectors(t,e),s.cross(Kn);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,i,s,r){Kn.subVectors(s,e),vi.subVectors(i,e),qc.subVectors(t,e);let a=Kn.dot(Kn),o=Kn.dot(vi),c=Kn.dot(qc),l=vi.dot(vi),h=vi.dot(qc),u=a*l-o*o;if(u===0)return r.set(0,0,0),null;let f=1/u,d=(l*c-o*h)*f,p=(a*h-o*c)*f;return r.set(1-d-p,p,d)}static containsPoint(t,e,i,s){return this.getBarycoord(t,e,i,s,Mi)===null?!1:Mi.x>=0&&Mi.y>=0&&Mi.x+Mi.y<=1}static getUV(t,e,i,s,r,a,o,c){return Xa===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Xa=!0),this.getInterpolation(t,e,i,s,r,a,o,c)}static getInterpolation(t,e,i,s,r,a,o,c){return this.getBarycoord(t,e,i,s,Mi)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,Mi.x),c.addScaledVector(a,Mi.y),c.addScaledVector(o,Mi.z),c)}static isFrontFacing(t,e,i,s){return Kn.subVectors(i,e),vi.subVectors(t,e),Kn.cross(vi).dot(s)<0}set(t,e,i){return this.a.copy(t),this.b.copy(e),this.c.copy(i),this}setFromPointsAndIndices(t,e,i,s){return this.a.copy(t[e]),this.b.copy(t[i]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,i,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,i),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Kn.subVectors(this.c,this.b),vi.subVectors(this.a,this.b),Kn.cross(vi).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return n.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return n.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,i,s,r){return Xa===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Xa=!0),n.getInterpolation(t,this.a,this.b,this.c,e,i,s,r)}getInterpolation(t,e,i,s,r){return n.getInterpolation(t,this.a,this.b,this.c,e,i,s,r)}containsPoint(t){return n.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return n.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let i=this.a,s=this.b,r=this.c,a,o;Ws.subVectors(s,i),Xs.subVectors(r,i),Zc.subVectors(t,i);let c=Ws.dot(Zc),l=Xs.dot(Zc);if(c<=0&&l<=0)return e.copy(i);Jc.subVectors(t,s);let h=Ws.dot(Jc),u=Xs.dot(Jc);if(h>=0&&u<=h)return e.copy(s);let f=c*u-h*l;if(f<=0&&c>=0&&h<=0)return a=c/(c-h),e.copy(i).addScaledVector(Ws,a);Kc.subVectors(t,r);let d=Ws.dot(Kc),p=Xs.dot(Kc);if(p>=0&&d<=p)return e.copy(r);let x=d*l-c*p;if(x<=0&&l>=0&&p<=0)return o=l/(l-p),e.copy(i).addScaledVector(Xs,o);let g=h*p-d*u;if(g<=0&&u-h>=0&&d-p>=0)return cf.subVectors(r,s),o=(u-h)/(u-h+(d-p)),e.copy(s).addScaledVector(cf,o);let m=1/(g+x+f);return a=x*m,o=f*m,e.copy(i).addScaledVector(Ws,a).addScaledVector(Xs,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},ud={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ki={h:0,s:0,l:0},Ya={h:0,s:0,l:0};function jc(n,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?n+(t-n)*6*e:e<1/2?t:e<2/3?n+(t-n)*6*(2/3-e):n}var Ft=class{constructor(t,e,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,i)}set(t,e,i){if(e===void 0&&i===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,i);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=be){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Me.toWorkingColorSpace(this,e),this}setRGB(t,e,i,s=Me.workingColorSpace){return this.r=t,this.g=e,this.b=i,Me.toWorkingColorSpace(this,s),this}setHSL(t,e,i,s=Me.workingColorSpace){if(t=lh(t,1),e=on(e,0,1),i=on(i,0,1),e===0)this.r=this.g=this.b=i;else{let r=i<=.5?i*(1+e):i+e-i*e,a=2*i-r;this.r=jc(a,r,t+1/3),this.g=jc(a,r,t),this.b=jc(a,r,t-1/3)}return Me.toWorkingColorSpace(this,s),this}setStyle(t,e=be){function i(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=be){let i=ud[t.toLowerCase()];return i!==void 0?this.setHex(i,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=or(t.r),this.g=or(t.g),this.b=or(t.b),this}copyLinearToSRGB(t){return this.r=Hc(t.r),this.g=Hc(t.g),this.b=Hc(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=be){return Me.fromWorkingColorSpace(fn.copy(this),t),Math.round(on(fn.r*255,0,255))*65536+Math.round(on(fn.g*255,0,255))*256+Math.round(on(fn.b*255,0,255))}getHexString(t=be){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Me.workingColorSpace){Me.fromWorkingColorSpace(fn.copy(this),e);let i=fn.r,s=fn.g,r=fn.b,a=Math.max(i,s,r),o=Math.min(i,s,r),c,l,h=(o+a)/2;if(o===a)c=0,l=0;else{let u=a-o;switch(l=h<=.5?u/(a+o):u/(2-a-o),a){case i:c=(s-r)/u+(s<r?6:0);break;case s:c=(r-i)/u+2;break;case r:c=(i-s)/u+4;break}c/=6}return t.h=c,t.s=l,t.l=h,t}getRGB(t,e=Me.workingColorSpace){return Me.fromWorkingColorSpace(fn.copy(this),e),t.r=fn.r,t.g=fn.g,t.b=fn.b,t}getStyle(t=be){Me.fromWorkingColorSpace(fn.copy(this),t);let e=fn.r,i=fn.g,s=fn.b;return t!==be?`color(${t} ${e.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(i*255)},${Math.round(s*255)})`}offsetHSL(t,e,i){return this.getHSL(ki),this.setHSL(ki.h+t,ki.s+e,ki.l+i)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,i){return this.r=t.r+(e.r-t.r)*i,this.g=t.g+(e.g-t.g)*i,this.b=t.b+(e.b-t.b)*i,this}lerpHSL(t,e){this.getHSL(ki),t.getHSL(Ya);let i=$r(ki.h,Ya.h,e),s=$r(ki.s,Ya.s,e),r=$r(ki.l,Ya.l,e);return this.setHSL(i,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,i=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*i+r[6]*s,this.g=r[1]*e+r[4]*i+r[7]*s,this.b=r[2]*e+r[5]*i+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},fn=new Ft;Ft.NAMES=ud;var J0=0,Ai=class extends Ji{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:J0++}),this.uuid=ui(),this.name="",this.type="Material",this.blending=Xi,this.side=qi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=fl,this.blendDst=dl,this.blendEquation=us,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ft(0,0,0),this.blendAlpha=0,this.depthFunc=go,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=qu,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Fs,this.stencilZFail=Fs,this.stencilZPass=Fs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let i=t[e];if(i===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(i):s&&s.isVector3&&i&&i.isVector3?s.copy(i):this[e]=i}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(t).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(t).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(t).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(t).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(t).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Xi&&(i.blending=this.blending),this.side!==qi&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==fl&&(i.blendSrc=this.blendSrc),this.blendDst!==dl&&(i.blendDst=this.blendDst),this.blendEquation!==us&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==go&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==qu&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Fs&&(i.stencilFail=this.stencilFail),this.stencilZFail!==Fs&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==Fs&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function s(r){let a=[];for(let o in r){let c=r[o];delete c.metadata,a.push(c)}return a}if(e){let r=s(t.textures),a=s(t.images);r.length>0&&(i.textures=r),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,i=null;if(e!==null){let s=e.length;i=new Array(s);for(let r=0;r!==s;++r)i[r]=e[r].clone()}return this.clippingPlanes=i,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},Tn=class extends Ai{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ft(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Jf,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var Xe=new L,$a=new ht,me=class{constructor(t,e,i=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=i,this.usage=xl,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Vi,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,i){t*=this.itemSize,i*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[i+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,i=this.count;e<i;e++)$a.fromBufferAttribute(this,e),$a.applyMatrix3(t),this.setXY(e,$a.x,$a.y);else if(this.itemSize===3)for(let e=0,i=this.count;e<i;e++)Xe.fromBufferAttribute(this,e),Xe.applyMatrix3(t),this.setXYZ(e,Xe.x,Xe.y,Xe.z);return this}applyMatrix4(t){for(let e=0,i=this.count;e<i;e++)Xe.fromBufferAttribute(this,e),Xe.applyMatrix4(t),this.setXYZ(e,Xe.x,Xe.y,Xe.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)Xe.fromBufferAttribute(this,e),Xe.applyNormalMatrix(t),this.setXYZ(e,Xe.x,Xe.y,Xe.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)Xe.fromBufferAttribute(this,e),Xe.transformDirection(t),this.setXYZ(e,Xe.x,Xe.y,Xe.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let i=this.array[t*this.itemSize+e];return this.normalized&&(i=hi(i,this.array)),i}setComponent(t,e,i){return this.normalized&&(i=ve(i,this.array)),this.array[t*this.itemSize+e]=i,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=hi(e,this.array)),e}setX(t,e){return this.normalized&&(e=ve(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=hi(e,this.array)),e}setY(t,e){return this.normalized&&(e=ve(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=hi(e,this.array)),e}setZ(t,e){return this.normalized&&(e=ve(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=hi(e,this.array)),e}setW(t,e){return this.normalized&&(e=ve(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,i){return t*=this.itemSize,this.normalized&&(e=ve(e,this.array),i=ve(i,this.array)),this.array[t+0]=e,this.array[t+1]=i,this}setXYZ(t,e,i,s){return t*=this.itemSize,this.normalized&&(e=ve(e,this.array),i=ve(i,this.array),s=ve(s,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this}setXYZW(t,e,i,s,r){return t*=this.itemSize,this.normalized&&(e=ve(e,this.array),i=ve(i,this.array),s=ve(s,this.array),r=ve(r,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==xl&&(t.usage=this.usage),t}};var Ro=class extends me{constructor(t,e,i){super(new Uint16Array(t),e,i)}};var Co=class extends me{constructor(t,e,i){super(new Uint32Array(t),e,i)}};var fe=class extends me{constructor(t,e,i){super(new Float32Array(t),e,i)}};var K0=0,zn=new Ce,Qc=new Ze,Ys=new L,In=new Gn,Hr=new Gn,nn=new L,Ie=class n extends Ji{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:K0++}),this.uuid=ui(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(hd(t)?Co:Ro)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,i=0){this.groups.push({start:t,count:e,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let i=this.attributes.normal;if(i!==void 0){let r=new ae().getNormalMatrix(t);i.applyNormalMatrix(r),i.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return zn.makeRotationFromQuaternion(t),this.applyMatrix4(zn),this}rotateX(t){return zn.makeRotationX(t),this.applyMatrix4(zn),this}rotateY(t){return zn.makeRotationY(t),this.applyMatrix4(zn),this}rotateZ(t){return zn.makeRotationZ(t),this.applyMatrix4(zn),this}translate(t,e,i){return zn.makeTranslation(t,e,i),this.applyMatrix4(zn),this}scale(t,e,i){return zn.makeScale(t,e,i),this.applyMatrix4(zn),this}lookAt(t){return Qc.lookAt(t),Qc.updateMatrix(),this.applyMatrix4(Qc.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ys).negate(),this.translate(Ys.x,Ys.y,Ys.z),this}setFromPoints(t){let e=[];for(let i=0,s=t.length;i<s;i++){let r=t[i];e.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new fe(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Gn);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new L(-1/0,-1/0,-1/0),new L(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let i=0,s=e.length;i<s;i++){let r=e[i];In.setFromBufferAttribute(r),this.morphTargetsRelative?(nn.addVectors(this.boundingBox.min,In.min),this.boundingBox.expandByPoint(nn),nn.addVectors(this.boundingBox.max,In.max),this.boundingBox.expandByPoint(nn)):(this.boundingBox.expandByPoint(In.min),this.boundingBox.expandByPoint(In.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ki);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new L,1/0);return}if(t){let i=this.boundingSphere.center;if(In.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){let o=e[r];Hr.setFromBufferAttribute(o),this.morphTargetsRelative?(nn.addVectors(In.min,Hr.min),In.expandByPoint(nn),nn.addVectors(In.max,Hr.max),In.expandByPoint(nn)):(In.expandByPoint(Hr.min),In.expandByPoint(Hr.max))}In.getCenter(i);let s=0;for(let r=0,a=t.count;r<a;r++)nn.fromBufferAttribute(t,r),s=Math.max(s,i.distanceToSquared(nn));if(e)for(let r=0,a=e.length;r<a;r++){let o=e[r],c=this.morphTargetsRelative;for(let l=0,h=o.count;l<h;l++)nn.fromBufferAttribute(o,l),c&&(Ys.fromBufferAttribute(t,l),nn.add(Ys)),s=Math.max(s,i.distanceToSquared(nn))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let i=t.array,s=e.position.array,r=e.normal.array,a=e.uv.array,o=s.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new me(new Float32Array(4*o),4));let c=this.getAttribute("tangent").array,l=[],h=[];for(let b=0;b<o;b++)l[b]=new L,h[b]=new L;let u=new L,f=new L,d=new L,p=new ht,x=new ht,g=new ht,m=new L,E=new L;function y(b,R,O){u.fromArray(s,b*3),f.fromArray(s,R*3),d.fromArray(s,O*3),p.fromArray(a,b*2),x.fromArray(a,R*2),g.fromArray(a,O*2),f.sub(u),d.sub(u),x.sub(p),g.sub(p);let Z=1/(x.x*g.y-g.x*x.y);isFinite(Z)&&(m.copy(f).multiplyScalar(g.y).addScaledVector(d,-x.y).multiplyScalar(Z),E.copy(d).multiplyScalar(x.x).addScaledVector(f,-g.x).multiplyScalar(Z),l[b].add(m),l[R].add(m),l[O].add(m),h[b].add(E),h[R].add(E),h[O].add(E))}let S=this.groups;S.length===0&&(S=[{start:0,count:i.length}]);for(let b=0,R=S.length;b<R;++b){let O=S[b],Z=O.start,I=O.count;for(let N=Z,H=Z+I;N<H;N+=3)y(i[N+0],i[N+1],i[N+2])}let P=new L,w=new L,A=new L,F=new L;function M(b){A.fromArray(r,b*3),F.copy(A);let R=l[b];P.copy(R),P.sub(A.multiplyScalar(A.dot(R))).normalize(),w.crossVectors(F,R);let Z=w.dot(h[b])<0?-1:1;c[b*4]=P.x,c[b*4+1]=P.y,c[b*4+2]=P.z,c[b*4+3]=Z}for(let b=0,R=S.length;b<R;++b){let O=S[b],Z=O.start,I=O.count;for(let N=Z,H=Z+I;N<H;N+=3)M(i[N+0]),M(i[N+1]),M(i[N+2])}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new me(new Float32Array(e.count*3),3),this.setAttribute("normal",i);else for(let f=0,d=i.count;f<d;f++)i.setXYZ(f,0,0,0);let s=new L,r=new L,a=new L,o=new L,c=new L,l=new L,h=new L,u=new L;if(t)for(let f=0,d=t.count;f<d;f+=3){let p=t.getX(f+0),x=t.getX(f+1),g=t.getX(f+2);s.fromBufferAttribute(e,p),r.fromBufferAttribute(e,x),a.fromBufferAttribute(e,g),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),o.fromBufferAttribute(i,p),c.fromBufferAttribute(i,x),l.fromBufferAttribute(i,g),o.add(h),c.add(h),l.add(h),i.setXYZ(p,o.x,o.y,o.z),i.setXYZ(x,c.x,c.y,c.z),i.setXYZ(g,l.x,l.y,l.z)}else for(let f=0,d=e.count;f<d;f+=3)s.fromBufferAttribute(e,f+0),r.fromBufferAttribute(e,f+1),a.fromBufferAttribute(e,f+2),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),i.setXYZ(f+0,h.x,h.y,h.z),i.setXYZ(f+1,h.x,h.y,h.z),i.setXYZ(f+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,i=t.count;e<i;e++)nn.fromBufferAttribute(t,e),nn.normalize(),t.setXYZ(e,nn.x,nn.y,nn.z)}toNonIndexed(){function t(o,c){let l=o.array,h=o.itemSize,u=o.normalized,f=new l.constructor(c.length*h),d=0,p=0;for(let x=0,g=c.length;x<g;x++){o.isInterleavedBufferAttribute?d=c[x]*o.data.stride+o.offset:d=c[x]*h;for(let m=0;m<h;m++)f[p++]=l[d++]}return new me(f,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new n,i=this.index.array,s=this.attributes;for(let o in s){let c=s[o],l=t(c,i);e.setAttribute(o,l)}let r=this.morphAttributes;for(let o in r){let c=[],l=r[o];for(let h=0,u=l.length;h<u;h++){let f=l[h],d=t(f,i);c.push(d)}e.morphAttributes[o]=c}e.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,c=a.length;o<c;o++){let l=a[o];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let c=this.parameters;for(let l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let i=this.attributes;for(let c in i){let l=i[c];t.data.attributes[c]=l.toJSON(t.data)}let s={},r=!1;for(let c in this.morphAttributes){let l=this.morphAttributes[c],h=[];for(let u=0,f=l.length;u<f;u++){let d=l[u];h.push(d.toJSON(t.data))}h.length>0&&(s[c]=h,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(t.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let i=t.index;i!==null&&this.setIndex(i.clone(e));let s=t.attributes;for(let l in s){let h=s[l];this.setAttribute(l,h.clone(e))}let r=t.morphAttributes;for(let l in r){let h=[],u=r[l];for(let f=0,d=u.length;f<d;f++)h.push(u[f].clone(e));this.morphAttributes[l]=h}this.morphTargetsRelative=t.morphTargetsRelative;let a=t.groups;for(let l=0,h=a.length;l<h;l++){let u=a[l];this.addGroup(u.start,u.count,u.materialIndex)}let o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());let c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},lf=new Ce,cs=new ia,qa=new Ki,hf=new L,$s=new L,qs=new L,Zs=new L,tl=new L,Za=new L,Ja=new ht,Ka=new ht,ja=new ht,uf=new L,ff=new L,df=new L,Qa=new L,to=new L,bt=class extends Ze{constructor(t=new Ie,e=new Tn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){let s=e[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){let o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){let i=this.geometry,s=i.attributes.position,r=i.morphAttributes.position,a=i.morphTargetsRelative;e.fromBufferAttribute(s,t);let o=this.morphTargetInfluences;if(r&&o){Za.set(0,0,0);for(let c=0,l=r.length;c<l;c++){let h=o[c],u=r[c];h!==0&&(tl.fromBufferAttribute(u,t),a?Za.addScaledVector(tl,h):Za.addScaledVector(tl.sub(e),h))}e.add(Za)}return e}raycast(t,e){let i=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),qa.copy(i.boundingSphere),qa.applyMatrix4(r),cs.copy(t.ray).recast(t.near),!(qa.containsPoint(cs.origin)===!1&&(cs.intersectSphere(qa,hf)===null||cs.origin.distanceToSquared(hf)>(t.far-t.near)**2))&&(lf.copy(r).invert(),cs.copy(t.ray).applyMatrix4(lf),!(i.boundingBox!==null&&cs.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(t,e,cs)))}_computeIntersections(t,e,i){let s,r=this.geometry,a=this.material,o=r.index,c=r.attributes.position,l=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,f=r.groups,d=r.drawRange;if(o!==null)if(Array.isArray(a))for(let p=0,x=f.length;p<x;p++){let g=f[p],m=a[g.materialIndex],E=Math.max(g.start,d.start),y=Math.min(o.count,Math.min(g.start+g.count,d.start+d.count));for(let S=E,P=y;S<P;S+=3){let w=o.getX(S),A=o.getX(S+1),F=o.getX(S+2);s=eo(this,m,t,i,l,h,u,w,A,F),s&&(s.faceIndex=Math.floor(S/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let p=Math.max(0,d.start),x=Math.min(o.count,d.start+d.count);for(let g=p,m=x;g<m;g+=3){let E=o.getX(g),y=o.getX(g+1),S=o.getX(g+2);s=eo(this,a,t,i,l,h,u,E,y,S),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}else if(c!==void 0)if(Array.isArray(a))for(let p=0,x=f.length;p<x;p++){let g=f[p],m=a[g.materialIndex],E=Math.max(g.start,d.start),y=Math.min(c.count,Math.min(g.start+g.count,d.start+d.count));for(let S=E,P=y;S<P;S+=3){let w=S,A=S+1,F=S+2;s=eo(this,m,t,i,l,h,u,w,A,F),s&&(s.faceIndex=Math.floor(S/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let p=Math.max(0,d.start),x=Math.min(c.count,d.start+d.count);for(let g=p,m=x;g<m;g+=3){let E=g,y=g+1,S=g+2;s=eo(this,a,t,i,l,h,u,E,y,S),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}}};function j0(n,t,e,i,s,r,a,o){let c;if(t.side===dn?c=i.intersectTriangle(a,r,s,!0,o):c=i.intersectTriangle(s,r,a,t.side===qi,o),c===null)return null;to.copy(o),to.applyMatrix4(n.matrixWorld);let l=e.ray.origin.distanceTo(to);return l<e.near||l>e.far?null:{distance:l,point:to.clone(),object:n}}function eo(n,t,e,i,s,r,a,o,c,l){n.getVertexPosition(o,$s),n.getVertexPosition(c,qs),n.getVertexPosition(l,Zs);let h=j0(n,t,e,i,$s,qs,Zs,Qa);if(h){s&&(Ja.fromBufferAttribute(s,o),Ka.fromBufferAttribute(s,c),ja.fromBufferAttribute(s,l),h.uv=ds.getInterpolation(Qa,$s,qs,Zs,Ja,Ka,ja,new ht)),r&&(Ja.fromBufferAttribute(r,o),Ka.fromBufferAttribute(r,c),ja.fromBufferAttribute(r,l),h.uv1=ds.getInterpolation(Qa,$s,qs,Zs,Ja,Ka,ja,new ht),h.uv2=h.uv1),a&&(uf.fromBufferAttribute(a,o),ff.fromBufferAttribute(a,c),df.fromBufferAttribute(a,l),h.normal=ds.getInterpolation(Qa,$s,qs,Zs,uf,ff,df,new L),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));let u={a:o,b:c,c:l,normal:new L,materialIndex:0};ds.getNormal($s,qs,Zs,u.normal),h.face=u}return h}var xe=class n extends Ie{constructor(t=1,e=1,i=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:i,widthSegments:s,heightSegments:r,depthSegments:a};let o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);let c=[],l=[],h=[],u=[],f=0,d=0;p("z","y","x",-1,-1,i,e,t,a,r,0),p("z","y","x",1,-1,i,e,-t,a,r,1),p("x","z","y",1,1,t,i,e,s,a,2),p("x","z","y",1,-1,t,i,-e,s,a,3),p("x","y","z",1,-1,t,e,i,s,r,4),p("x","y","z",-1,-1,t,e,-i,s,r,5),this.setIndex(c),this.setAttribute("position",new fe(l,3)),this.setAttribute("normal",new fe(h,3)),this.setAttribute("uv",new fe(u,2));function p(x,g,m,E,y,S,P,w,A,F,M){let b=S/A,R=P/F,O=S/2,Z=P/2,I=w/2,N=A+1,H=F+1,nt=0,B=0,W=new L;for(let Q=0;Q<H;Q++){let tt=Q*R-Z;for(let ut=0;ut<N;ut++){let J=ut*b-O;W[x]=J*E,W[g]=tt*y,W[m]=I,l.push(W.x,W.y,W.z),W[x]=0,W[g]=0,W[m]=w>0?1:-1,h.push(W.x,W.y,W.z),u.push(ut/A),u.push(1-Q/F),nt+=1}}for(let Q=0;Q<F;Q++)for(let tt=0;tt<A;tt++){let ut=f+tt+N*Q,J=f+tt+N*(Q+1),it=f+(tt+1)+N*(Q+1),dt=f+(tt+1)+N*Q;c.push(ut,J,dt),c.push(J,it,dt),B+=6}o.addGroup(d,B,M),d+=B,f+=nt}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function dr(n){let t={};for(let e in n){t[e]={};for(let i in n[e]){let s=n[e][i];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][i]=null):t[e][i]=s.clone():Array.isArray(s)?t[e][i]=s.slice():t[e][i]=s}}return t}function _n(n){let t={};for(let e=0;e<n.length;e++){let i=dr(n[e]);for(let s in i)t[s]=i[s]}return t}function Q0(n){let t=[];for(let e=0;e<n.length;e++)t.push(n[e].clone());return t}function fd(n){return n.getRenderTarget()===null?n.outputColorSpace:Me.workingColorSpace}var tm={clone:dr,merge:_n},em=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,nm=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Vn=class extends Ai{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=em,this.fragmentShader=nm,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=dr(t.uniforms),this.uniformsGroups=Q0(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let a=this.uniforms[s].value;a&&a.isTexture?e.uniforms[s]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[s]={type:"m4",value:a.toArray()}:e.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let i={};for(let s in this.extensions)this.extensions[s]===!0&&(i[s]=!0);return Object.keys(i).length>0&&(e.extensions=i),e}},Po=class extends Ze{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Ce,this.projectionMatrix=new Ce,this.projectionMatrixInverse=new Ce,this.coordinateSystem=bi}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},vn=class extends Po{constructor(t=50,e=1,i=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=i,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=na*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(Yr*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return na*2*Math.atan(Math.tan(Yr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,i,s,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(Yr*.5*this.fov)/this.zoom,i=2*e,s=this.aspect*i,r=-.5*s,a=this.view;if(this.view!==null&&this.view.enabled){let c=a.fullWidth,l=a.fullHeight;r+=a.offsetX*s/c,e-=a.offsetY*i/l,s*=a.width/c,i*=a.height/l}let o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-i,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},Js=-90,Ks=1,El=class extends Ze{constructor(t,e,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new vn(Js,Ks,t,e);s.layers=this.layers,this.add(s);let r=new vn(Js,Ks,t,e);r.layers=this.layers,this.add(r);let a=new vn(Js,Ks,t,e);a.layers=this.layers,this.add(a);let o=new vn(Js,Ks,t,e);o.layers=this.layers,this.add(o);let c=new vn(Js,Ks,t,e);c.layers=this.layers,this.add(c);let l=new vn(Js,Ks,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[i,s,r,a,o,c]=e;for(let l of e)this.remove(l);if(t===bi)i.up.set(0,1,0),i.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===Eo)i.up.set(0,-1,0),i.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:i,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,a,o,c,l,h]=this.children,u=t.getRenderTarget(),f=t.getActiveCubeFace(),d=t.getActiveMipmapLevel(),p=t.xr.enabled;t.xr.enabled=!1;let x=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,t.setRenderTarget(i,0,s),t.render(e,r),t.setRenderTarget(i,1,s),t.render(e,a),t.setRenderTarget(i,2,s),t.render(e,o),t.setRenderTarget(i,3,s),t.render(e,c),t.setRenderTarget(i,4,s),t.render(e,l),i.texture.generateMipmaps=x,t.setRenderTarget(i,5,s),t.render(e,h),t.setRenderTarget(u,f,d),t.xr.enabled=p,i.texture.needsPMREMUpdate=!0}},Io=class extends kn{constructor(t,e,i,s,r,a,o,c,l,h){t=t!==void 0?t:[],e=e!==void 0?e:lr,super(t,e,i,s,r,a,o,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},Sl=class extends wi{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let i={width:t,height:t,depth:1},s=[i,i,i,i,i,i];e.encoding!==void 0&&(qr("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===gs?be:Hn),this.texture=new Io(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:Bn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new xe(5,5,5),r=new Vn({name:"CubemapFromEquirect",uniforms:dr(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:dn,blending:Wi});r.uniforms.tEquirect.value=e;let a=new bt(s,r),o=e.minFilter;return e.minFilter===ta&&(e.minFilter=Bn),new El(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,i,s){let r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,i,s);t.setRenderTarget(r)}},el=new L,im=new L,sm=new ae,Si=class{constructor(t=new L(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,i,s){return this.normal.set(t,e,i),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,i){let s=el.subVectors(i,e).cross(im.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let i=t.delta(el),s=this.normal.dot(i);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(i,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),i=this.distanceToPoint(t.end);return e<0&&i>0||i<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let i=e||sm.getNormalMatrix(t),s=this.coplanarPoint(el).applyMatrix4(t),r=this.normal.applyMatrix3(i).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},ls=new Ki,no=new L,ra=class{constructor(t=new Si,e=new Si,i=new Si,s=new Si,r=new Si,a=new Si){this.planes=[t,e,i,s,r,a]}set(t,e,i,s,r,a){let o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(i),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(t){let e=this.planes;for(let i=0;i<6;i++)e[i].copy(t.planes[i]);return this}setFromProjectionMatrix(t,e=bi){let i=this.planes,s=t.elements,r=s[0],a=s[1],o=s[2],c=s[3],l=s[4],h=s[5],u=s[6],f=s[7],d=s[8],p=s[9],x=s[10],g=s[11],m=s[12],E=s[13],y=s[14],S=s[15];if(i[0].setComponents(c-r,f-l,g-d,S-m).normalize(),i[1].setComponents(c+r,f+l,g+d,S+m).normalize(),i[2].setComponents(c+a,f+h,g+p,S+E).normalize(),i[3].setComponents(c-a,f-h,g-p,S-E).normalize(),i[4].setComponents(c-o,f-u,g-x,S-y).normalize(),e===bi)i[5].setComponents(c+o,f+u,g+x,S+y).normalize();else if(e===Eo)i[5].setComponents(o,u,x,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),ls.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),ls.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(ls)}intersectsSprite(t){return ls.center.set(0,0,0),ls.radius=.7071067811865476,ls.applyMatrix4(t.matrixWorld),this.intersectsSphere(ls)}intersectsSphere(t){let e=this.planes,i=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(i)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let i=0;i<6;i++){let s=e[i];if(no.x=s.normal.x>0?t.max.x:t.min.x,no.y=s.normal.y>0?t.max.y:t.min.y,no.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(no)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let i=0;i<6;i++)if(e[i].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function dd(){let n=null,t=!1,e=null,i=null;function s(r,a){e(r,a),i=n.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(i=n.requestAnimationFrame(s),t=!0)},stop:function(){n.cancelAnimationFrame(i),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){n=r}}}function rm(n,t){let e=t.isWebGL2,i=new WeakMap;function s(l,h){let u=l.array,f=l.usage,d=u.byteLength,p=n.createBuffer();n.bindBuffer(h,p),n.bufferData(h,u,f),l.onUploadCallback();let x;if(u instanceof Float32Array)x=n.FLOAT;else if(u instanceof Uint16Array)if(l.isFloat16BufferAttribute)if(e)x=n.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else x=n.UNSIGNED_SHORT;else if(u instanceof Int16Array)x=n.SHORT;else if(u instanceof Uint32Array)x=n.UNSIGNED_INT;else if(u instanceof Int32Array)x=n.INT;else if(u instanceof Int8Array)x=n.BYTE;else if(u instanceof Uint8Array)x=n.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)x=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:p,type:x,bytesPerElement:u.BYTES_PER_ELEMENT,version:l.version,size:d}}function r(l,h,u){let f=h.array,d=h._updateRange,p=h.updateRanges;if(n.bindBuffer(u,l),d.count===-1&&p.length===0&&n.bufferSubData(u,0,f),p.length!==0){for(let x=0,g=p.length;x<g;x++){let m=p[x];e?n.bufferSubData(u,m.start*f.BYTES_PER_ELEMENT,f,m.start,m.count):n.bufferSubData(u,m.start*f.BYTES_PER_ELEMENT,f.subarray(m.start,m.start+m.count))}h.clearUpdateRanges()}d.count!==-1&&(e?n.bufferSubData(u,d.offset*f.BYTES_PER_ELEMENT,f,d.offset,d.count):n.bufferSubData(u,d.offset*f.BYTES_PER_ELEMENT,f.subarray(d.offset,d.offset+d.count)),d.count=-1),h.onUploadCallback()}function a(l){return l.isInterleavedBufferAttribute&&(l=l.data),i.get(l)}function o(l){l.isInterleavedBufferAttribute&&(l=l.data);let h=i.get(l);h&&(n.deleteBuffer(h.buffer),i.delete(l))}function c(l,h){if(l.isGLBufferAttribute){let f=i.get(l);(!f||f.version<l.version)&&i.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}l.isInterleavedBufferAttribute&&(l=l.data);let u=i.get(l);if(u===void 0)i.set(l,s(l,h));else if(u.version<l.version){if(u.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(u.buffer,l,h),u.version=l.version}}return{get:a,remove:o,update:c}}var cn=class n extends Ie{constructor(t=1,e=1,i=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:i,heightSegments:s};let r=t/2,a=e/2,o=Math.floor(i),c=Math.floor(s),l=o+1,h=c+1,u=t/o,f=e/c,d=[],p=[],x=[],g=[];for(let m=0;m<h;m++){let E=m*f-a;for(let y=0;y<l;y++){let S=y*u-r;p.push(S,-E,0),x.push(0,0,1),g.push(y/o),g.push(1-m/c)}}for(let m=0;m<c;m++)for(let E=0;E<o;E++){let y=E+l*m,S=E+l*(m+1),P=E+1+l*(m+1),w=E+1+l*m;d.push(y,S,w),d.push(S,P,w)}this.setIndex(d),this.setAttribute("position",new fe(p,3)),this.setAttribute("normal",new fe(x,3)),this.setAttribute("uv",new fe(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.width,t.height,t.widthSegments,t.heightSegments)}},am=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,om=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,cm=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,lm=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,hm=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,um=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,fm=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,dm=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,pm=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,mm=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,gm=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,xm=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,ym=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,_m=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,vm=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Mm=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Em=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Sm=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,bm=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Tm=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,wm=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Am=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Rm=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Cm=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Pm=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Im=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Lm=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Dm=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Um=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Om=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Nm="gl_FragColor = linearToOutputTexel( gl_FragColor );",Fm=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,zm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Bm=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Hm=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,km=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Gm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Vm=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Wm=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Xm=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Ym=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,$m=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,qm=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,Zm=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Jm=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Km=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,jm=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Qm=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,tg=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,eg=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,ng=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,ig=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,sg=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,rg=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,ag=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,og=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,cg=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,lg=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,hg=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,ug=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,fg=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,dg=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,pg=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,mg=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,gg=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,xg=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,yg=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,_g=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,vg=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,Mg=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Eg=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Sg=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,bg=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Tg=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,wg=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Ag=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Rg=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Cg=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Pg=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Ig=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Lg=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Dg=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Ug=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Og=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Ng=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Fg=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,zg=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Bg=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Hg=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,kg=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,Gg=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Vg=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Wg=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Xg=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Yg=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,$g=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,qg=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Zg=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Jg=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Kg=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,jg=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Qg=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,tx=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,ex=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,nx=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,ix=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,sx=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,rx=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,ax=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ox=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cx=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,lx=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,hx=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ux=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,fx=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,dx=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,px=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,mx=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,gx=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,xx=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,yx=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,_x=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,vx=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Mx=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ex=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Sx=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,bx=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tx=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,wx=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Ax=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Rx=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Cx=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Px=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ix=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Lx=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Dx=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Ux=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Ox=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Nx=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Fx=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,zx=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,te={alphahash_fragment:am,alphahash_pars_fragment:om,alphamap_fragment:cm,alphamap_pars_fragment:lm,alphatest_fragment:hm,alphatest_pars_fragment:um,aomap_fragment:fm,aomap_pars_fragment:dm,batching_pars_vertex:pm,batching_vertex:mm,begin_vertex:gm,beginnormal_vertex:xm,bsdfs:ym,iridescence_fragment:_m,bumpmap_pars_fragment:vm,clipping_planes_fragment:Mm,clipping_planes_pars_fragment:Em,clipping_planes_pars_vertex:Sm,clipping_planes_vertex:bm,color_fragment:Tm,color_pars_fragment:wm,color_pars_vertex:Am,color_vertex:Rm,common:Cm,cube_uv_reflection_fragment:Pm,defaultnormal_vertex:Im,displacementmap_pars_vertex:Lm,displacementmap_vertex:Dm,emissivemap_fragment:Um,emissivemap_pars_fragment:Om,colorspace_fragment:Nm,colorspace_pars_fragment:Fm,envmap_fragment:zm,envmap_common_pars_fragment:Bm,envmap_pars_fragment:Hm,envmap_pars_vertex:km,envmap_physical_pars_fragment:Qm,envmap_vertex:Gm,fog_vertex:Vm,fog_pars_vertex:Wm,fog_fragment:Xm,fog_pars_fragment:Ym,gradientmap_pars_fragment:$m,lightmap_fragment:qm,lightmap_pars_fragment:Zm,lights_lambert_fragment:Jm,lights_lambert_pars_fragment:Km,lights_pars_begin:jm,lights_toon_fragment:tg,lights_toon_pars_fragment:eg,lights_phong_fragment:ng,lights_phong_pars_fragment:ig,lights_physical_fragment:sg,lights_physical_pars_fragment:rg,lights_fragment_begin:ag,lights_fragment_maps:og,lights_fragment_end:cg,logdepthbuf_fragment:lg,logdepthbuf_pars_fragment:hg,logdepthbuf_pars_vertex:ug,logdepthbuf_vertex:fg,map_fragment:dg,map_pars_fragment:pg,map_particle_fragment:mg,map_particle_pars_fragment:gg,metalnessmap_fragment:xg,metalnessmap_pars_fragment:yg,morphcolor_vertex:_g,morphnormal_vertex:vg,morphtarget_pars_vertex:Mg,morphtarget_vertex:Eg,normal_fragment_begin:Sg,normal_fragment_maps:bg,normal_pars_fragment:Tg,normal_pars_vertex:wg,normal_vertex:Ag,normalmap_pars_fragment:Rg,clearcoat_normal_fragment_begin:Cg,clearcoat_normal_fragment_maps:Pg,clearcoat_pars_fragment:Ig,iridescence_pars_fragment:Lg,opaque_fragment:Dg,packing:Ug,premultiplied_alpha_fragment:Og,project_vertex:Ng,dithering_fragment:Fg,dithering_pars_fragment:zg,roughnessmap_fragment:Bg,roughnessmap_pars_fragment:Hg,shadowmap_pars_fragment:kg,shadowmap_pars_vertex:Gg,shadowmap_vertex:Vg,shadowmask_pars_fragment:Wg,skinbase_vertex:Xg,skinning_pars_vertex:Yg,skinning_vertex:$g,skinnormal_vertex:qg,specularmap_fragment:Zg,specularmap_pars_fragment:Jg,tonemapping_fragment:Kg,tonemapping_pars_fragment:jg,transmission_fragment:Qg,transmission_pars_fragment:tx,uv_pars_fragment:ex,uv_pars_vertex:nx,uv_vertex:ix,worldpos_vertex:sx,background_vert:rx,background_frag:ax,backgroundCube_vert:ox,backgroundCube_frag:cx,cube_vert:lx,cube_frag:hx,depth_vert:ux,depth_frag:fx,distanceRGBA_vert:dx,distanceRGBA_frag:px,equirect_vert:mx,equirect_frag:gx,linedashed_vert:xx,linedashed_frag:yx,meshbasic_vert:_x,meshbasic_frag:vx,meshlambert_vert:Mx,meshlambert_frag:Ex,meshmatcap_vert:Sx,meshmatcap_frag:bx,meshnormal_vert:Tx,meshnormal_frag:wx,meshphong_vert:Ax,meshphong_frag:Rx,meshphysical_vert:Cx,meshphysical_frag:Px,meshtoon_vert:Ix,meshtoon_frag:Lx,points_vert:Dx,points_frag:Ux,shadow_vert:Ox,shadow_frag:Nx,sprite_vert:Fx,sprite_frag:zx},mt={common:{diffuse:{value:new Ft(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new ae},alphaMap:{value:null},alphaMapTransform:{value:new ae},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new ae}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new ae}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new ae}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new ae},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new ae},normalScale:{value:new ht(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new ae},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new ae}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new ae}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new ae}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ft(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ft(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new ae},alphaTest:{value:0},uvTransform:{value:new ae}},sprite:{diffuse:{value:new Ft(16777215)},opacity:{value:1},center:{value:new ht(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new ae},alphaMap:{value:null},alphaMapTransform:{value:new ae},alphaTest:{value:0}}},li={basic:{uniforms:_n([mt.common,mt.specularmap,mt.envmap,mt.aomap,mt.lightmap,mt.fog]),vertexShader:te.meshbasic_vert,fragmentShader:te.meshbasic_frag},lambert:{uniforms:_n([mt.common,mt.specularmap,mt.envmap,mt.aomap,mt.lightmap,mt.emissivemap,mt.bumpmap,mt.normalmap,mt.displacementmap,mt.fog,mt.lights,{emissive:{value:new Ft(0)}}]),vertexShader:te.meshlambert_vert,fragmentShader:te.meshlambert_frag},phong:{uniforms:_n([mt.common,mt.specularmap,mt.envmap,mt.aomap,mt.lightmap,mt.emissivemap,mt.bumpmap,mt.normalmap,mt.displacementmap,mt.fog,mt.lights,{emissive:{value:new Ft(0)},specular:{value:new Ft(1118481)},shininess:{value:30}}]),vertexShader:te.meshphong_vert,fragmentShader:te.meshphong_frag},standard:{uniforms:_n([mt.common,mt.envmap,mt.aomap,mt.lightmap,mt.emissivemap,mt.bumpmap,mt.normalmap,mt.displacementmap,mt.roughnessmap,mt.metalnessmap,mt.fog,mt.lights,{emissive:{value:new Ft(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:te.meshphysical_vert,fragmentShader:te.meshphysical_frag},toon:{uniforms:_n([mt.common,mt.aomap,mt.lightmap,mt.emissivemap,mt.bumpmap,mt.normalmap,mt.displacementmap,mt.gradientmap,mt.fog,mt.lights,{emissive:{value:new Ft(0)}}]),vertexShader:te.meshtoon_vert,fragmentShader:te.meshtoon_frag},matcap:{uniforms:_n([mt.common,mt.bumpmap,mt.normalmap,mt.displacementmap,mt.fog,{matcap:{value:null}}]),vertexShader:te.meshmatcap_vert,fragmentShader:te.meshmatcap_frag},points:{uniforms:_n([mt.points,mt.fog]),vertexShader:te.points_vert,fragmentShader:te.points_frag},dashed:{uniforms:_n([mt.common,mt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:te.linedashed_vert,fragmentShader:te.linedashed_frag},depth:{uniforms:_n([mt.common,mt.displacementmap]),vertexShader:te.depth_vert,fragmentShader:te.depth_frag},normal:{uniforms:_n([mt.common,mt.bumpmap,mt.normalmap,mt.displacementmap,{opacity:{value:1}}]),vertexShader:te.meshnormal_vert,fragmentShader:te.meshnormal_frag},sprite:{uniforms:_n([mt.sprite,mt.fog]),vertexShader:te.sprite_vert,fragmentShader:te.sprite_frag},background:{uniforms:{uvTransform:{value:new ae},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:te.background_vert,fragmentShader:te.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:te.backgroundCube_vert,fragmentShader:te.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:te.cube_vert,fragmentShader:te.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:te.equirect_vert,fragmentShader:te.equirect_frag},distanceRGBA:{uniforms:_n([mt.common,mt.displacementmap,{referencePosition:{value:new L},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:te.distanceRGBA_vert,fragmentShader:te.distanceRGBA_frag},shadow:{uniforms:_n([mt.lights,mt.fog,{color:{value:new Ft(0)},opacity:{value:1}}]),vertexShader:te.shadow_vert,fragmentShader:te.shadow_frag}};li.physical={uniforms:_n([li.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new ae},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new ae},clearcoatNormalScale:{value:new ht(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new ae},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new ae},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new ae},sheen:{value:0},sheenColor:{value:new Ft(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new ae},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new ae},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new ae},transmissionSamplerSize:{value:new ht},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new ae},attenuationDistance:{value:0},attenuationColor:{value:new Ft(0)},specularColor:{value:new Ft(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new ae},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new ae},anisotropyVector:{value:new ht},anisotropyMap:{value:null},anisotropyMapTransform:{value:new ae}}]),vertexShader:te.meshphysical_vert,fragmentShader:te.meshphysical_frag};var io={r:0,b:0,g:0};function Bx(n,t,e,i,s,r,a){let o=new Ft(0),c=r===!0?0:1,l,h,u=null,f=0,d=null;function p(g,m){let E=!1,y=m.isScene===!0?m.background:null;y&&y.isTexture&&(y=(m.backgroundBlurriness>0?e:t).get(y)),y===null?x(o,c):y&&y.isColor&&(x(y,1),E=!0);let S=n.xr.getEnvironmentBlendMode();S==="additive"?i.buffers.color.setClear(0,0,0,1,a):S==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(n.autoClear||E)&&n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil),y&&(y.isCubeTexture||y.mapping===Zo)?(h===void 0&&(h=new bt(new xe(1,1,1),new Vn({name:"BackgroundCubeMaterial",uniforms:dr(li.backgroundCube.uniforms),vertexShader:li.backgroundCube.vertexShader,fragmentShader:li.backgroundCube.fragmentShader,side:dn,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(P,w,A){this.matrixWorld.copyPosition(A.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),h.material.uniforms.envMap.value=y,h.material.uniforms.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=m.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,h.material.toneMapped=Me.getTransfer(y.colorSpace)!==Pe,(u!==y||f!==y.version||d!==n.toneMapping)&&(h.material.needsUpdate=!0,u=y,f=y.version,d=n.toneMapping),h.layers.enableAll(),g.unshift(h,h.geometry,h.material,0,0,null)):y&&y.isTexture&&(l===void 0&&(l=new bt(new cn(2,2),new Vn({name:"BackgroundMaterial",uniforms:dr(li.background.uniforms),vertexShader:li.background.vertexShader,fragmentShader:li.background.fragmentShader,side:qi,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(l)),l.material.uniforms.t2D.value=y,l.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,l.material.toneMapped=Me.getTransfer(y.colorSpace)!==Pe,y.matrixAutoUpdate===!0&&y.updateMatrix(),l.material.uniforms.uvTransform.value.copy(y.matrix),(u!==y||f!==y.version||d!==n.toneMapping)&&(l.material.needsUpdate=!0,u=y,f=y.version,d=n.toneMapping),l.layers.enableAll(),g.unshift(l,l.geometry,l.material,0,0,null))}function x(g,m){g.getRGB(io,fd(n)),i.buffers.color.setClear(io.r,io.g,io.b,m,a)}return{getClearColor:function(){return o},setClearColor:function(g,m=1){o.set(g),c=m,x(o,c)},getClearAlpha:function(){return c},setClearAlpha:function(g){c=g,x(o,c)},render:p}}function Hx(n,t,e,i){let s=n.getParameter(n.MAX_VERTEX_ATTRIBS),r=i.isWebGL2?null:t.get("OES_vertex_array_object"),a=i.isWebGL2||r!==null,o={},c=g(null),l=c,h=!1;function u(I,N,H,nt,B){let W=!1;if(a){let Q=x(nt,H,N);l!==Q&&(l=Q,d(l.object)),W=m(I,nt,H,B),W&&E(I,nt,H,B)}else{let Q=N.wireframe===!0;(l.geometry!==nt.id||l.program!==H.id||l.wireframe!==Q)&&(l.geometry=nt.id,l.program=H.id,l.wireframe=Q,W=!0)}B!==null&&e.update(B,n.ELEMENT_ARRAY_BUFFER),(W||h)&&(h=!1,F(I,N,H,nt),B!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,e.get(B).buffer))}function f(){return i.isWebGL2?n.createVertexArray():r.createVertexArrayOES()}function d(I){return i.isWebGL2?n.bindVertexArray(I):r.bindVertexArrayOES(I)}function p(I){return i.isWebGL2?n.deleteVertexArray(I):r.deleteVertexArrayOES(I)}function x(I,N,H){let nt=H.wireframe===!0,B=o[I.id];B===void 0&&(B={},o[I.id]=B);let W=B[N.id];W===void 0&&(W={},B[N.id]=W);let Q=W[nt];return Q===void 0&&(Q=g(f()),W[nt]=Q),Q}function g(I){let N=[],H=[],nt=[];for(let B=0;B<s;B++)N[B]=0,H[B]=0,nt[B]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:N,enabledAttributes:H,attributeDivisors:nt,object:I,attributes:{},index:null}}function m(I,N,H,nt){let B=l.attributes,W=N.attributes,Q=0,tt=H.getAttributes();for(let ut in tt)if(tt[ut].location>=0){let it=B[ut],dt=W[ut];if(dt===void 0&&(ut==="instanceMatrix"&&I.instanceMatrix&&(dt=I.instanceMatrix),ut==="instanceColor"&&I.instanceColor&&(dt=I.instanceColor)),it===void 0||it.attribute!==dt||dt&&it.data!==dt.data)return!0;Q++}return l.attributesNum!==Q||l.index!==nt}function E(I,N,H,nt){let B={},W=N.attributes,Q=0,tt=H.getAttributes();for(let ut in tt)if(tt[ut].location>=0){let it=W[ut];it===void 0&&(ut==="instanceMatrix"&&I.instanceMatrix&&(it=I.instanceMatrix),ut==="instanceColor"&&I.instanceColor&&(it=I.instanceColor));let dt={};dt.attribute=it,it&&it.data&&(dt.data=it.data),B[ut]=dt,Q++}l.attributes=B,l.attributesNum=Q,l.index=nt}function y(){let I=l.newAttributes;for(let N=0,H=I.length;N<H;N++)I[N]=0}function S(I){P(I,0)}function P(I,N){let H=l.newAttributes,nt=l.enabledAttributes,B=l.attributeDivisors;H[I]=1,nt[I]===0&&(n.enableVertexAttribArray(I),nt[I]=1),B[I]!==N&&((i.isWebGL2?n:t.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](I,N),B[I]=N)}function w(){let I=l.newAttributes,N=l.enabledAttributes;for(let H=0,nt=N.length;H<nt;H++)N[H]!==I[H]&&(n.disableVertexAttribArray(H),N[H]=0)}function A(I,N,H,nt,B,W,Q){Q===!0?n.vertexAttribIPointer(I,N,H,B,W):n.vertexAttribPointer(I,N,H,nt,B,W)}function F(I,N,H,nt){if(i.isWebGL2===!1&&(I.isInstancedMesh||nt.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;y();let B=nt.attributes,W=H.getAttributes(),Q=N.defaultAttributeValues;for(let tt in W){let ut=W[tt];if(ut.location>=0){let J=B[tt];if(J===void 0&&(tt==="instanceMatrix"&&I.instanceMatrix&&(J=I.instanceMatrix),tt==="instanceColor"&&I.instanceColor&&(J=I.instanceColor)),J!==void 0){let it=J.normalized,dt=J.itemSize,It=e.get(J);if(It===void 0)continue;let St=It.buffer,Ht=It.type,st=It.bytesPerElement,ct=i.isWebGL2===!0&&(Ht===n.INT||Ht===n.UNSIGNED_INT||J.gpuType===jf);if(J.isInterleavedBufferAttribute){let xt=J.data,C=xt.stride,rt=J.offset;if(xt.isInstancedInterleavedBuffer){for(let q=0;q<ut.locationSize;q++)P(ut.location+q,xt.meshPerAttribute);I.isInstancedMesh!==!0&&nt._maxInstanceCount===void 0&&(nt._maxInstanceCount=xt.meshPerAttribute*xt.count)}else for(let q=0;q<ut.locationSize;q++)S(ut.location+q);n.bindBuffer(n.ARRAY_BUFFER,St);for(let q=0;q<ut.locationSize;q++)A(ut.location+q,dt/ut.locationSize,Ht,it,C*st,(rt+dt/ut.locationSize*q)*st,ct)}else{if(J.isInstancedBufferAttribute){for(let xt=0;xt<ut.locationSize;xt++)P(ut.location+xt,J.meshPerAttribute);I.isInstancedMesh!==!0&&nt._maxInstanceCount===void 0&&(nt._maxInstanceCount=J.meshPerAttribute*J.count)}else for(let xt=0;xt<ut.locationSize;xt++)S(ut.location+xt);n.bindBuffer(n.ARRAY_BUFFER,St);for(let xt=0;xt<ut.locationSize;xt++)A(ut.location+xt,dt/ut.locationSize,Ht,it,dt*st,dt/ut.locationSize*xt*st,ct)}}else if(Q!==void 0){let it=Q[tt];if(it!==void 0)switch(it.length){case 2:n.vertexAttrib2fv(ut.location,it);break;case 3:n.vertexAttrib3fv(ut.location,it);break;case 4:n.vertexAttrib4fv(ut.location,it);break;default:n.vertexAttrib1fv(ut.location,it)}}}}w()}function M(){O();for(let I in o){let N=o[I];for(let H in N){let nt=N[H];for(let B in nt)p(nt[B].object),delete nt[B];delete N[H]}delete o[I]}}function b(I){if(o[I.id]===void 0)return;let N=o[I.id];for(let H in N){let nt=N[H];for(let B in nt)p(nt[B].object),delete nt[B];delete N[H]}delete o[I.id]}function R(I){for(let N in o){let H=o[N];if(H[I.id]===void 0)continue;let nt=H[I.id];for(let B in nt)p(nt[B].object),delete nt[B];delete H[I.id]}}function O(){Z(),h=!0,l!==c&&(l=c,d(l.object))}function Z(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:u,reset:O,resetDefaultState:Z,dispose:M,releaseStatesOfGeometry:b,releaseStatesOfProgram:R,initAttributes:y,enableAttribute:S,disableUnusedAttributes:w}}function kx(n,t,e,i){let s=i.isWebGL2,r;function a(h){r=h}function o(h,u){n.drawArrays(r,h,u),e.update(u,r,1)}function c(h,u,f){if(f===0)return;let d,p;if(s)d=n,p="drawArraysInstanced";else if(d=t.get("ANGLE_instanced_arrays"),p="drawArraysInstancedANGLE",d===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}d[p](r,h,u,f),e.update(u,r,f)}function l(h,u,f){if(f===0)return;let d=t.get("WEBGL_multi_draw");if(d===null)for(let p=0;p<f;p++)this.render(h[p],u[p]);else{d.multiDrawArraysWEBGL(r,h,0,u,0,f);let p=0;for(let x=0;x<f;x++)p+=u[x];e.update(p,r,1)}}this.setMode=a,this.render=o,this.renderInstances=c,this.renderMultiDraw=l}function Gx(n,t,e){let i;function s(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){let A=t.get("EXT_texture_filter_anisotropic");i=n.getParameter(A.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function r(A){if(A==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";A="mediump"}return A==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let a=typeof WebGL2RenderingContext<"u"&&n.constructor.name==="WebGL2RenderingContext",o=e.precision!==void 0?e.precision:"highp",c=r(o);c!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",c,"instead."),o=c);let l=a||t.has("WEBGL_draw_buffers"),h=e.logarithmicDepthBuffer===!0,u=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),f=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),d=n.getParameter(n.MAX_TEXTURE_SIZE),p=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),x=n.getParameter(n.MAX_VERTEX_ATTRIBS),g=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),m=n.getParameter(n.MAX_VARYING_VECTORS),E=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),y=f>0,S=a||t.has("OES_texture_float"),P=y&&S,w=a?n.getParameter(n.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:l,getMaxAnisotropy:s,getMaxPrecision:r,precision:o,logarithmicDepthBuffer:h,maxTextures:u,maxVertexTextures:f,maxTextureSize:d,maxCubemapSize:p,maxAttributes:x,maxVertexUniforms:g,maxVaryings:m,maxFragmentUniforms:E,vertexTextures:y,floatFragmentTextures:S,floatVertexTextures:P,maxSamples:w}}function Vx(n){let t=this,e=null,i=0,s=!1,r=!1,a=new Si,o=new ae,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(u,f){let d=u.length!==0||f||i!==0||s;return s=f,i=u.length,d},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,f){e=h(u,f,0)},this.setState=function(u,f,d){let p=u.clippingPlanes,x=u.clipIntersection,g=u.clipShadows,m=n.get(u);if(!s||p===null||p.length===0||r&&!g)r?h(null):l();else{let E=r?0:i,y=E*4,S=m.clippingState||null;c.value=S,S=h(p,f,y,d);for(let P=0;P!==y;++P)S[P]=e[P];m.clippingState=S,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=E}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=i>0),t.numPlanes=i,t.numIntersection=0}function h(u,f,d,p){let x=u!==null?u.length:0,g=null;if(x!==0){if(g=c.value,p!==!0||g===null){let m=d+x*4,E=f.matrixWorldInverse;o.getNormalMatrix(E),(g===null||g.length<m)&&(g=new Float32Array(m));for(let y=0,S=d;y!==x;++y,S+=4)a.copy(u[y]).applyMatrix4(E,o),a.normal.toArray(g,S),g[S+3]=a.constant}c.value=g,c.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,g}}function Wx(n){let t=new WeakMap;function e(a,o){return o===pl?a.mapping=lr:o===ml&&(a.mapping=hr),a}function i(a){if(a&&a.isTexture){let o=a.mapping;if(o===pl||o===ml)if(t.has(a)){let c=t.get(a).texture;return e(c,a.mapping)}else{let c=a.image;if(c&&c.height>0){let l=new Sl(c.height/2);return l.fromEquirectangularTexture(n,a),t.set(a,l),a.addEventListener("dispose",s),e(l.texture,a.mapping)}else return null}}return a}function s(a){let o=a.target;o.removeEventListener("dispose",s);let c=t.get(o);c!==void 0&&(t.delete(o),c.dispose())}function r(){t=new WeakMap}return{get:i,dispose:r}}var Lo=class extends Po{constructor(t=-1,e=1,i=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=i,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,i,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=i-t,a=i+t,o=s+e,c=s-e;if(this.view!==null&&this.view.enabled){let l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,a=r+l*this.view.width,o-=h*this.view.offsetY,c=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},sr=4,pf=[.125,.215,.35,.446,.526,.582],fs=20,nl=new Lo,mf=new Ft,il=null,sl=0,rl=0,hs=(1+Math.sqrt(5))/2,js=1/hs,gf=[new L(1,1,1),new L(-1,1,1),new L(1,1,-1),new L(-1,1,-1),new L(0,hs,js),new L(0,hs,-js),new L(js,0,hs),new L(-js,0,hs),new L(hs,js,0),new L(-hs,js,0)],pr=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,i=.1,s=100){il=this._renderer.getRenderTarget(),sl=this._renderer.getActiveCubeFace(),rl=this._renderer.getActiveMipmapLevel(),this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,i,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=_f(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=yf(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(il,sl,rl),t.scissorTest=!1,so(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===lr||t.mapping===hr?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),il=this._renderer.getRenderTarget(),sl=this._renderer.getActiveCubeFace(),rl=this._renderer.getActiveMipmapLevel();let i=e||this._allocateTargets();return this._textureToCubeUV(t,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,i={magFilter:Bn,minFilter:Bn,generateMipmaps:!1,type:ea,format:Qn,colorSpace:Ti,depthBuffer:!1},s=xf(t,e,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=xf(t,e,i);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Xx(r)),this._blurMaterial=Yx(r,t,e)}return s}_compileMaterial(t){let e=new bt(this._lodPlanes[0],t);this._renderer.compile(e,nl)}_sceneToCubeUV(t,e,i,s){let o=new vn(90,1,e,i),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,f=h.toneMapping;h.getClearColor(mf),h.toneMapping=Yi,h.autoClear=!1;let d=new Tn({name:"PMREM.Background",side:dn,depthWrite:!1,depthTest:!1}),p=new bt(new xe,d),x=!1,g=t.background;g?g.isColor&&(d.color.copy(g),t.background=null,x=!0):(d.color.copy(mf),x=!0);for(let m=0;m<6;m++){let E=m%3;E===0?(o.up.set(0,c[m],0),o.lookAt(l[m],0,0)):E===1?(o.up.set(0,0,c[m]),o.lookAt(0,l[m],0)):(o.up.set(0,c[m],0),o.lookAt(0,0,l[m]));let y=this._cubeSize;so(s,E*y,m>2?y:0,y,y),h.setRenderTarget(s),x&&h.render(p,o),h.render(t,o)}p.geometry.dispose(),p.material.dispose(),h.toneMapping=f,h.autoClear=u,t.background=g}_textureToCubeUV(t,e){let i=this._renderer,s=t.mapping===lr||t.mapping===hr;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=_f()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=yf());let r=s?this._cubemapMaterial:this._equirectMaterial,a=new bt(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=t;let c=this._cubeSize;so(e,0,0,3*c,2*c),i.setRenderTarget(e),i.render(a,nl)}_applyPMREM(t){let e=this._renderer,i=e.autoClear;e.autoClear=!1;for(let s=1;s<this._lodPlanes.length;s++){let r=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),a=gf[(s-1)%gf.length];this._blur(t,s-1,s,r,a)}e.autoClear=i}_blur(t,e,i,s,r){let a=this._pingPongRenderTarget;this._halfBlur(t,a,e,i,s,"latitudinal",r),this._halfBlur(a,t,i,i,s,"longitudinal",r)}_halfBlur(t,e,i,s,r,a,o){let c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new bt(this._lodPlanes[s],l),f=l.uniforms,d=this._sizeLods[i]-1,p=isFinite(r)?Math.PI/(2*d):2*Math.PI/(2*fs-1),x=r/p,g=isFinite(r)?1+Math.floor(h*x):fs;g>fs&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${fs}`);let m=[],E=0;for(let A=0;A<fs;++A){let F=A/x,M=Math.exp(-F*F/2);m.push(M),A===0?E+=M:A<g&&(E+=2*M)}for(let A=0;A<m.length;A++)m[A]=m[A]/E;f.envMap.value=t.texture,f.samples.value=g,f.weights.value=m,f.latitudinal.value=a==="latitudinal",o&&(f.poleAxis.value=o);let{_lodMax:y}=this;f.dTheta.value=p,f.mipInt.value=y-i;let S=this._sizeLods[s],P=3*S*(s>y-sr?s-y+sr:0),w=4*(this._cubeSize-S);so(e,P,w,3*S,2*S),c.setRenderTarget(e),c.render(u,nl)}};function Xx(n){let t=[],e=[],i=[],s=n,r=n-sr+1+pf.length;for(let a=0;a<r;a++){let o=Math.pow(2,s);e.push(o);let c=1/o;a>n-sr?c=pf[a-n+sr-1]:a===0&&(c=0),i.push(c);let l=1/(o-2),h=-l,u=1+l,f=[h,h,u,h,u,u,h,h,u,u,h,u],d=6,p=6,x=3,g=2,m=1,E=new Float32Array(x*p*d),y=new Float32Array(g*p*d),S=new Float32Array(m*p*d);for(let w=0;w<d;w++){let A=w%3*2/3-1,F=w>2?0:-1,M=[A,F,0,A+2/3,F,0,A+2/3,F+1,0,A,F,0,A+2/3,F+1,0,A,F+1,0];E.set(M,x*p*w),y.set(f,g*p*w);let b=[w,w,w,w,w,w];S.set(b,m*p*w)}let P=new Ie;P.setAttribute("position",new me(E,x)),P.setAttribute("uv",new me(y,g)),P.setAttribute("faceIndex",new me(S,m)),t.push(P),s>sr&&s--}return{lodPlanes:t,sizeLods:e,sigmas:i}}function xf(n,t,e){let i=new wi(n,t,e);return i.texture.mapping=Zo,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function so(n,t,e,i,s){n.viewport.set(t,e,i,s),n.scissor.set(t,e,i,s)}function Yx(n,t,e){let i=new Float32Array(fs),s=new L(0,1,0);return new Vn({name:"SphericalGaussianBlur",defines:{n:fs,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:hh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Wi,depthTest:!1,depthWrite:!1})}function yf(){return new Vn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:hh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Wi,depthTest:!1,depthWrite:!1})}function _f(){return new Vn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:hh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Wi,depthTest:!1,depthWrite:!1})}function hh(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function $x(n){let t=new WeakMap,e=null;function i(o){if(o&&o.isTexture){let c=o.mapping,l=c===pl||c===ml,h=c===lr||c===hr;if(l||h)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let u=t.get(o);return e===null&&(e=new pr(n)),u=l?e.fromEquirectangular(o,u):e.fromCubemap(o,u),t.set(o,u),u.texture}else{if(t.has(o))return t.get(o).texture;{let u=o.image;if(l&&u&&u.height>0||h&&u&&s(u)){e===null&&(e=new pr(n));let f=l?e.fromEquirectangular(o):e.fromCubemap(o);return t.set(o,f),o.addEventListener("dispose",r),f.texture}else return null}}}return o}function s(o){let c=0,l=6;for(let h=0;h<l;h++)o[h]!==void 0&&c++;return c===l}function r(o){let c=o.target;c.removeEventListener("dispose",r);let l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:i,dispose:a}}function qx(n){let t={};function e(i){if(t[i]!==void 0)return t[i];let s;switch(i){case"WEBGL_depth_texture":s=n.getExtension("WEBGL_depth_texture")||n.getExtension("MOZ_WEBGL_depth_texture")||n.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=n.getExtension("EXT_texture_filter_anisotropic")||n.getExtension("MOZ_EXT_texture_filter_anisotropic")||n.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=n.getExtension("WEBGL_compressed_texture_s3tc")||n.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=n.getExtension("WEBGL_compressed_texture_pvrtc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=n.getExtension(i)}return t[i]=s,s}return{has:function(i){return e(i)!==null},init:function(i){i.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(i){let s=e(i);return s===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),s}}}function Zx(n,t,e,i){let s={},r=new WeakMap;function a(u){let f=u.target;f.index!==null&&t.remove(f.index);for(let p in f.attributes)t.remove(f.attributes[p]);for(let p in f.morphAttributes){let x=f.morphAttributes[p];for(let g=0,m=x.length;g<m;g++)t.remove(x[g])}f.removeEventListener("dispose",a),delete s[f.id];let d=r.get(f);d&&(t.remove(d),r.delete(f)),i.releaseStatesOfGeometry(f),f.isInstancedBufferGeometry===!0&&delete f._maxInstanceCount,e.memory.geometries--}function o(u,f){return s[f.id]===!0||(f.addEventListener("dispose",a),s[f.id]=!0,e.memory.geometries++),f}function c(u){let f=u.attributes;for(let p in f)t.update(f[p],n.ARRAY_BUFFER);let d=u.morphAttributes;for(let p in d){let x=d[p];for(let g=0,m=x.length;g<m;g++)t.update(x[g],n.ARRAY_BUFFER)}}function l(u){let f=[],d=u.index,p=u.attributes.position,x=0;if(d!==null){let E=d.array;x=d.version;for(let y=0,S=E.length;y<S;y+=3){let P=E[y+0],w=E[y+1],A=E[y+2];f.push(P,w,w,A,A,P)}}else if(p!==void 0){let E=p.array;x=p.version;for(let y=0,S=E.length/3-1;y<S;y+=3){let P=y+0,w=y+1,A=y+2;f.push(P,w,w,A,A,P)}}else return;let g=new(hd(f)?Co:Ro)(f,1);g.version=x;let m=r.get(u);m&&t.remove(m),r.set(u,g)}function h(u){let f=r.get(u);if(f){let d=u.index;d!==null&&f.version<d.version&&l(u)}else l(u);return r.get(u)}return{get:o,update:c,getWireframeAttribute:h}}function Jx(n,t,e,i){let s=i.isWebGL2,r;function a(d){r=d}let o,c;function l(d){o=d.type,c=d.bytesPerElement}function h(d,p){n.drawElements(r,p,o,d*c),e.update(p,r,1)}function u(d,p,x){if(x===0)return;let g,m;if(s)g=n,m="drawElementsInstanced";else if(g=t.get("ANGLE_instanced_arrays"),m="drawElementsInstancedANGLE",g===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}g[m](r,p,o,d*c,x),e.update(p,r,x)}function f(d,p,x){if(x===0)return;let g=t.get("WEBGL_multi_draw");if(g===null)for(let m=0;m<x;m++)this.render(d[m]/c,p[m]);else{g.multiDrawElementsWEBGL(r,p,0,o,d,0,x);let m=0;for(let E=0;E<x;E++)m+=p[E];e.update(m,r,1)}}this.setMode=a,this.setIndex=l,this.render=h,this.renderInstances=u,this.renderMultiDraw=f}function Kx(n){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,a,o){switch(e.calls++,a){case n.TRIANGLES:e.triangles+=o*(r/3);break;case n.LINES:e.lines+=o*(r/2);break;case n.LINE_STRIP:e.lines+=o*(r-1);break;case n.LINE_LOOP:e.lines+=o*r;break;case n.POINTS:e.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:i}}function jx(n,t){return n[0]-t[0]}function Qx(n,t){return Math.abs(t[1])-Math.abs(n[1])}function ty(n,t,e){let i={},s=new Float32Array(8),r=new WeakMap,a=new We,o=[];for(let l=0;l<8;l++)o[l]=[l,0];function c(l,h,u){let f=l.morphTargetInfluences;if(t.isWebGL2===!0){let d=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,p=d!==void 0?d.length:0,x=r.get(h);if(x===void 0||x.count!==p){let I=function(){O.dispose(),r.delete(h),h.removeEventListener("dispose",I)};x!==void 0&&x.texture.dispose();let E=h.morphAttributes.position!==void 0,y=h.morphAttributes.normal!==void 0,S=h.morphAttributes.color!==void 0,P=h.morphAttributes.position||[],w=h.morphAttributes.normal||[],A=h.morphAttributes.color||[],F=0;E===!0&&(F=1),y===!0&&(F=2),S===!0&&(F=3);let M=h.attributes.position.count*F,b=1;M>t.maxTextureSize&&(b=Math.ceil(M/t.maxTextureSize),M=t.maxTextureSize);let R=new Float32Array(M*b*4*p),O=new Ao(R,M,b,p);O.type=Vi,O.needsUpdate=!0;let Z=F*4;for(let N=0;N<p;N++){let H=P[N],nt=w[N],B=A[N],W=M*b*4*N;for(let Q=0;Q<H.count;Q++){let tt=Q*Z;E===!0&&(a.fromBufferAttribute(H,Q),R[W+tt+0]=a.x,R[W+tt+1]=a.y,R[W+tt+2]=a.z,R[W+tt+3]=0),y===!0&&(a.fromBufferAttribute(nt,Q),R[W+tt+4]=a.x,R[W+tt+5]=a.y,R[W+tt+6]=a.z,R[W+tt+7]=0),S===!0&&(a.fromBufferAttribute(B,Q),R[W+tt+8]=a.x,R[W+tt+9]=a.y,R[W+tt+10]=a.z,R[W+tt+11]=B.itemSize===4?a.w:1)}}x={count:p,texture:O,size:new ht(M,b)},r.set(h,x),h.addEventListener("dispose",I)}let g=0;for(let E=0;E<f.length;E++)g+=f[E];let m=h.morphTargetsRelative?1:1-g;u.getUniforms().setValue(n,"morphTargetBaseInfluence",m),u.getUniforms().setValue(n,"morphTargetInfluences",f),u.getUniforms().setValue(n,"morphTargetsTexture",x.texture,e),u.getUniforms().setValue(n,"morphTargetsTextureSize",x.size)}else{let d=f===void 0?0:f.length,p=i[h.id];if(p===void 0||p.length!==d){p=[];for(let y=0;y<d;y++)p[y]=[y,0];i[h.id]=p}for(let y=0;y<d;y++){let S=p[y];S[0]=y,S[1]=f[y]}p.sort(Qx);for(let y=0;y<8;y++)y<d&&p[y][1]?(o[y][0]=p[y][0],o[y][1]=p[y][1]):(o[y][0]=Number.MAX_SAFE_INTEGER,o[y][1]=0);o.sort(jx);let x=h.morphAttributes.position,g=h.morphAttributes.normal,m=0;for(let y=0;y<8;y++){let S=o[y],P=S[0],w=S[1];P!==Number.MAX_SAFE_INTEGER&&w?(x&&h.getAttribute("morphTarget"+y)!==x[P]&&h.setAttribute("morphTarget"+y,x[P]),g&&h.getAttribute("morphNormal"+y)!==g[P]&&h.setAttribute("morphNormal"+y,g[P]),s[y]=w,m+=w):(x&&h.hasAttribute("morphTarget"+y)===!0&&h.deleteAttribute("morphTarget"+y),g&&h.hasAttribute("morphNormal"+y)===!0&&h.deleteAttribute("morphNormal"+y),s[y]=0)}let E=h.morphTargetsRelative?1:1-m;u.getUniforms().setValue(n,"morphTargetBaseInfluence",E),u.getUniforms().setValue(n,"morphTargetInfluences",s)}}return{update:c}}function ey(n,t,e,i){let s=new WeakMap;function r(c){let l=i.render.frame,h=c.geometry,u=t.get(c,h);if(s.get(u)!==l&&(t.update(u),s.set(u,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",o)===!1&&c.addEventListener("dispose",o),s.get(c)!==l&&(e.update(c.instanceMatrix,n.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,n.ARRAY_BUFFER),s.set(c,l))),c.isSkinnedMesh){let f=c.skeleton;s.get(f)!==l&&(f.update(),s.set(f,l))}return u}function a(){s=new WeakMap}function o(c){let l=c.target;l.removeEventListener("dispose",o),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:r,dispose:a}}var Do=class extends kn{constructor(t,e,i,s,r,a,o,c,l,h){if(h=h!==void 0?h:ms,h!==ms&&h!==ur)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&h===ms&&(i=Gi),i===void 0&&h===ur&&(i=ps),super(null,s,r,a,o,c,h,i,l),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=o!==void 0?o:sn,this.minFilter=c!==void 0?c:sn,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},pd=new kn,md=new Do(1,1);md.compareFunction=od;var gd=new Ao,xd=new Ml,yd=new Io,vf=[],Mf=[],Ef=new Float32Array(16),Sf=new Float32Array(9),bf=new Float32Array(4);function _r(n,t,e){let i=n[0];if(i<=0||i>0)return n;let s=t*e,r=vf[s];if(r===void 0&&(r=new Float32Array(s),vf[s]=r),t!==0){i.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,n[a].toArray(r,o)}return r}function Je(n,t){if(n.length!==t.length)return!1;for(let e=0,i=n.length;e<i;e++)if(n[e]!==t[e])return!1;return!0}function Ke(n,t){for(let e=0,i=t.length;e<i;e++)n[e]=t[e]}function Ko(n,t){let e=Mf[t];e===void 0&&(e=new Int32Array(t),Mf[t]=e);for(let i=0;i!==t;++i)e[i]=n.allocateTextureUnit();return e}function ny(n,t){let e=this.cache;e[0]!==t&&(n.uniform1f(this.addr,t),e[0]=t)}function iy(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Je(e,t))return;n.uniform2fv(this.addr,t),Ke(e,t)}}function sy(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(n.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Je(e,t))return;n.uniform3fv(this.addr,t),Ke(e,t)}}function ry(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Je(e,t))return;n.uniform4fv(this.addr,t),Ke(e,t)}}function ay(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(Je(e,t))return;n.uniformMatrix2fv(this.addr,!1,t),Ke(e,t)}else{if(Je(e,i))return;bf.set(i),n.uniformMatrix2fv(this.addr,!1,bf),Ke(e,i)}}function oy(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(Je(e,t))return;n.uniformMatrix3fv(this.addr,!1,t),Ke(e,t)}else{if(Je(e,i))return;Sf.set(i),n.uniformMatrix3fv(this.addr,!1,Sf),Ke(e,i)}}function cy(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(Je(e,t))return;n.uniformMatrix4fv(this.addr,!1,t),Ke(e,t)}else{if(Je(e,i))return;Ef.set(i),n.uniformMatrix4fv(this.addr,!1,Ef),Ke(e,i)}}function ly(n,t){let e=this.cache;e[0]!==t&&(n.uniform1i(this.addr,t),e[0]=t)}function hy(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Je(e,t))return;n.uniform2iv(this.addr,t),Ke(e,t)}}function uy(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Je(e,t))return;n.uniform3iv(this.addr,t),Ke(e,t)}}function fy(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Je(e,t))return;n.uniform4iv(this.addr,t),Ke(e,t)}}function dy(n,t){let e=this.cache;e[0]!==t&&(n.uniform1ui(this.addr,t),e[0]=t)}function py(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Je(e,t))return;n.uniform2uiv(this.addr,t),Ke(e,t)}}function my(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Je(e,t))return;n.uniform3uiv(this.addr,t),Ke(e,t)}}function gy(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Je(e,t))return;n.uniform4uiv(this.addr,t),Ke(e,t)}}function xy(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s);let r=this.type===n.SAMPLER_2D_SHADOW?md:pd;e.setTexture2D(t||r,s)}function yy(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTexture3D(t||xd,s)}function _y(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTextureCube(t||yd,s)}function vy(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTexture2DArray(t||gd,s)}function My(n){switch(n){case 5126:return ny;case 35664:return iy;case 35665:return sy;case 35666:return ry;case 35674:return ay;case 35675:return oy;case 35676:return cy;case 5124:case 35670:return ly;case 35667:case 35671:return hy;case 35668:case 35672:return uy;case 35669:case 35673:return fy;case 5125:return dy;case 36294:return py;case 36295:return my;case 36296:return gy;case 35678:case 36198:case 36298:case 36306:case 35682:return xy;case 35679:case 36299:case 36307:return yy;case 35680:case 36300:case 36308:case 36293:return _y;case 36289:case 36303:case 36311:case 36292:return vy}}function Ey(n,t){n.uniform1fv(this.addr,t)}function Sy(n,t){let e=_r(t,this.size,2);n.uniform2fv(this.addr,e)}function by(n,t){let e=_r(t,this.size,3);n.uniform3fv(this.addr,e)}function Ty(n,t){let e=_r(t,this.size,4);n.uniform4fv(this.addr,e)}function wy(n,t){let e=_r(t,this.size,4);n.uniformMatrix2fv(this.addr,!1,e)}function Ay(n,t){let e=_r(t,this.size,9);n.uniformMatrix3fv(this.addr,!1,e)}function Ry(n,t){let e=_r(t,this.size,16);n.uniformMatrix4fv(this.addr,!1,e)}function Cy(n,t){n.uniform1iv(this.addr,t)}function Py(n,t){n.uniform2iv(this.addr,t)}function Iy(n,t){n.uniform3iv(this.addr,t)}function Ly(n,t){n.uniform4iv(this.addr,t)}function Dy(n,t){n.uniform1uiv(this.addr,t)}function Uy(n,t){n.uniform2uiv(this.addr,t)}function Oy(n,t){n.uniform3uiv(this.addr,t)}function Ny(n,t){n.uniform4uiv(this.addr,t)}function Fy(n,t,e){let i=this.cache,s=t.length,r=Ko(e,s);Je(i,r)||(n.uniform1iv(this.addr,r),Ke(i,r));for(let a=0;a!==s;++a)e.setTexture2D(t[a]||pd,r[a])}function zy(n,t,e){let i=this.cache,s=t.length,r=Ko(e,s);Je(i,r)||(n.uniform1iv(this.addr,r),Ke(i,r));for(let a=0;a!==s;++a)e.setTexture3D(t[a]||xd,r[a])}function By(n,t,e){let i=this.cache,s=t.length,r=Ko(e,s);Je(i,r)||(n.uniform1iv(this.addr,r),Ke(i,r));for(let a=0;a!==s;++a)e.setTextureCube(t[a]||yd,r[a])}function Hy(n,t,e){let i=this.cache,s=t.length,r=Ko(e,s);Je(i,r)||(n.uniform1iv(this.addr,r),Ke(i,r));for(let a=0;a!==s;++a)e.setTexture2DArray(t[a]||gd,r[a])}function ky(n){switch(n){case 5126:return Ey;case 35664:return Sy;case 35665:return by;case 35666:return Ty;case 35674:return wy;case 35675:return Ay;case 35676:return Ry;case 5124:case 35670:return Cy;case 35667:case 35671:return Py;case 35668:case 35672:return Iy;case 35669:case 35673:return Ly;case 5125:return Dy;case 36294:return Uy;case 36295:return Oy;case 36296:return Ny;case 35678:case 36198:case 36298:case 36306:case 35682:return Fy;case 35679:case 36299:case 36307:return zy;case 35680:case 36300:case 36308:case 36293:return By;case 36289:case 36303:case 36311:case 36292:return Hy}}var bl=class{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.setValue=My(e.type)}},Tl=class{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=ky(e.type)}},wl=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,i){let s=this.seq;for(let r=0,a=s.length;r!==a;++r){let o=s[r];o.setValue(t,e[o.id],i)}}},al=/(\w+)(\])?(\[|\.)?/g;function Tf(n,t){n.seq.push(t),n.map[t.id]=t}function Gy(n,t,e){let i=n.name,s=i.length;for(al.lastIndex=0;;){let r=al.exec(i),a=al.lastIndex,o=r[1],c=r[2]==="]",l=r[3];if(c&&(o=o|0),l===void 0||l==="["&&a+2===s){Tf(e,l===void 0?new bl(o,n,t):new Tl(o,n,t));break}else{let u=e.map[o];u===void 0&&(u=new wl(o),Tf(e,u)),e=u}}}var cr=class{constructor(t,e){this.seq=[],this.map={};let i=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<i;++s){let r=t.getActiveUniform(e,s),a=t.getUniformLocation(e,r.name);Gy(r,a,this)}}setValue(t,e,i,s){let r=this.map[e];r!==void 0&&r.setValue(t,i,s)}setOptional(t,e,i){let s=e[i];s!==void 0&&this.setValue(t,i,s)}static upload(t,e,i,s){for(let r=0,a=e.length;r!==a;++r){let o=e[r],c=i[o.id];c.needsUpdate!==!1&&o.setValue(t,c.value,s)}}static seqWithValue(t,e){let i=[];for(let s=0,r=t.length;s!==r;++s){let a=t[s];a.id in e&&i.push(a)}return i}};function wf(n,t,e){let i=n.createShader(t);return n.shaderSource(i,e),n.compileShader(i),i}var Vy=37297,Wy=0;function Xy(n,t){let e=n.split(`
`),i=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=s;a<r;a++){let o=a+1;i.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return i.join(`
`)}function Yy(n){let t=Me.getPrimaries(Me.workingColorSpace),e=Me.getPrimaries(n),i;switch(t===e?i="":t===Mo&&e===vo?i="LinearDisplayP3ToLinearSRGB":t===vo&&e===Mo&&(i="LinearSRGBToLinearDisplayP3"),n){case Ti:case Jo:return[i,"LinearTransferOETF"];case be:case ch:return[i,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",n),[i,"LinearTransferOETF"]}}function Af(n,t,e){let i=n.getShaderParameter(t,n.COMPILE_STATUS),s=n.getShaderInfoLog(t).trim();if(i&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let a=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+Xy(n.getShaderSource(t),a)}else return s}function $y(n,t){let e=Yy(t);return`vec4 ${n}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function qy(n,t){let e;switch(t){case t0:e="Linear";break;case e0:e="Reinhard";break;case n0:e="OptimizedCineon";break;case ah:e="ACESFilmic";break;case s0:e="AgX";break;case i0:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+n+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function Zy(n){return[n.extensionDerivatives||n.envMapCubeUVHeight||n.bumpMap||n.normalMapTangentSpace||n.clearcoatNormalMap||n.flatShading||n.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(n.extensionFragDepth||n.logarithmicDepthBuffer)&&n.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",n.extensionDrawBuffers&&n.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(n.extensionShaderTextureLOD||n.envMap||n.transmission)&&n.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(rr).join(`
`)}function Jy(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(rr).join(`
`)}function Ky(n){let t=[];for(let e in n){let i=n[e];i!==!1&&t.push("#define "+e+" "+i)}return t.join(`
`)}function jy(n,t){let e={},i=n.getProgramParameter(t,n.ACTIVE_ATTRIBUTES);for(let s=0;s<i;s++){let r=n.getActiveAttrib(t,s),a=r.name,o=1;r.type===n.FLOAT_MAT2&&(o=2),r.type===n.FLOAT_MAT3&&(o=3),r.type===n.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:n.getAttribLocation(t,a),locationSize:o}}return e}function rr(n){return n!==""}function Rf(n,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Cf(n,t){return n.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var Qy=/^[ \t]*#include +<([\w\d./]+)>/gm;function Al(n){return n.replace(Qy,e_)}var t_=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function e_(n,t){let e=te[t];if(e===void 0){let i=t_.get(t);if(i!==void 0)e=te[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,i);else throw new Error("Can not resolve #include <"+t+">")}return Al(e)}var n_=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Pf(n){return n.replace(n_,i_)}function i_(n,t,e,i){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function If(n){let t="precision "+n.precision+` float;
precision `+n.precision+" int;";return n.precision==="highp"?t+=`
#define HIGH_PRECISION`:n.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function s_(n){let t="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===Zf?t="SHADOWMAP_TYPE_PCF":n.shadowMapType===rh?t="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===Ei&&(t="SHADOWMAP_TYPE_VSM"),t}function r_(n){let t="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case lr:case hr:t="ENVMAP_TYPE_CUBE";break;case Zo:t="ENVMAP_TYPE_CUBE_UV";break}return t}function a_(n){let t="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case hr:t="ENVMAP_MODE_REFRACTION";break}return t}function o_(n){let t="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case Jf:t="ENVMAP_BLENDING_MULTIPLY";break;case jp:t="ENVMAP_BLENDING_MIX";break;case Qp:t="ENVMAP_BLENDING_ADD";break}return t}function c_(n){let t=n.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,i=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:i,maxMip:e}}function l_(n,t,e,i){let s=n.getContext(),r=e.defines,a=e.vertexShader,o=e.fragmentShader,c=s_(e),l=r_(e),h=a_(e),u=o_(e),f=c_(e),d=e.isWebGL2?"":Zy(e),p=Jy(e),x=Ky(r),g=s.createProgram(),m,E,y=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(rr).join(`
`),m.length>0&&(m+=`
`),E=[d,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(rr).join(`
`),E.length>0&&(E+=`
`)):(m=[If(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(rr).join(`
`),E=[d,If(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",f?"#define CUBEUV_TEXEL_WIDTH "+f.texelWidth:"",f?"#define CUBEUV_TEXEL_HEIGHT "+f.texelHeight:"",f?"#define CUBEUV_MAX_MIP "+f.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Yi?"#define TONE_MAPPING":"",e.toneMapping!==Yi?te.tonemapping_pars_fragment:"",e.toneMapping!==Yi?qy("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",te.colorspace_pars_fragment,$y("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(rr).join(`
`)),a=Al(a),a=Rf(a,e),a=Cf(a,e),o=Al(o),o=Rf(o,e),o=Cf(o,e),a=Pf(a),o=Pf(o),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(y=`#version 300 es
`,m=[p,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,E=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===Zu?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Zu?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+E);let S=y+m+a,P=y+E+o,w=wf(s,s.VERTEX_SHADER,S),A=wf(s,s.FRAGMENT_SHADER,P);s.attachShader(g,w),s.attachShader(g,A),e.index0AttributeName!==void 0?s.bindAttribLocation(g,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(g,0,"position"),s.linkProgram(g);function F(O){if(n.debug.checkShaderErrors){let Z=s.getProgramInfoLog(g).trim(),I=s.getShaderInfoLog(w).trim(),N=s.getShaderInfoLog(A).trim(),H=!0,nt=!0;if(s.getProgramParameter(g,s.LINK_STATUS)===!1)if(H=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(s,g,w,A);else{let B=Af(s,w,"vertex"),W=Af(s,A,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(g,s.VALIDATE_STATUS)+`

Program Info Log: `+Z+`
`+B+`
`+W)}else Z!==""?console.warn("THREE.WebGLProgram: Program Info Log:",Z):(I===""||N==="")&&(nt=!1);nt&&(O.diagnostics={runnable:H,programLog:Z,vertexShader:{log:I,prefix:m},fragmentShader:{log:N,prefix:E}})}s.deleteShader(w),s.deleteShader(A),M=new cr(s,g),b=jy(s,g)}let M;this.getUniforms=function(){return M===void 0&&F(this),M};let b;this.getAttributes=function(){return b===void 0&&F(this),b};let R=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return R===!1&&(R=s.getProgramParameter(g,Vy)),R},this.destroy=function(){i.releaseStatesOfProgram(this),s.deleteProgram(g),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Wy++,this.cacheKey=t,this.usedTimes=1,this.program=g,this.vertexShader=w,this.fragmentShader=A,this}var h_=0,Rl=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,i=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(i),a=this._getShaderCacheForMaterial(t);return a.has(s)===!1&&(a.add(s),s.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let i of e)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,i=e.get(t);return i===void 0&&(i=new Set,e.set(t,i)),i}_getShaderStage(t){let e=this.shaderCache,i=e.get(t);return i===void 0&&(i=new Cl(t),e.set(t,i)),i}},Cl=class{constructor(t){this.id=h_++,this.code=t,this.usedTimes=0}};function u_(n,t,e,i,s,r,a){let o=new sa,c=new Rl,l=[],h=s.isWebGL2,u=s.logarithmicDepthBuffer,f=s.vertexTextures,d=s.precision,p={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(M){return M===0?"uv":`uv${M}`}function g(M,b,R,O,Z){let I=O.fog,N=Z.geometry,H=M.isMeshStandardMaterial?O.environment:null,nt=(M.isMeshStandardMaterial?e:t).get(M.envMap||H),B=nt&&nt.mapping===Zo?nt.image.height:null,W=p[M.type];M.precision!==null&&(d=s.getMaxPrecision(M.precision),d!==M.precision&&console.warn("THREE.WebGLProgram.getParameters:",M.precision,"not supported, using",d,"instead."));let Q=N.morphAttributes.position||N.morphAttributes.normal||N.morphAttributes.color,tt=Q!==void 0?Q.length:0,ut=0;N.morphAttributes.position!==void 0&&(ut=1),N.morphAttributes.normal!==void 0&&(ut=2),N.morphAttributes.color!==void 0&&(ut=3);let J,it,dt,It;if(W){let gn=li[W];J=gn.vertexShader,it=gn.fragmentShader}else J=M.vertexShader,it=M.fragmentShader,c.update(M),dt=c.getVertexShaderID(M),It=c.getFragmentShaderID(M);let St=n.getRenderTarget(),Ht=Z.isInstancedMesh===!0,st=Z.isBatchedMesh===!0,ct=!!M.map,xt=!!M.matcap,C=!!nt,rt=!!M.aoMap,q=!!M.lightMap,et=!!M.bumpMap,K=!!M.normalMap,Pt=!!M.displacementMap,_t=!!M.emissiveMap,v=!!M.metalnessMap,_=!!M.roughnessMap,D=M.anisotropy>0,G=M.clearcoat>0,Y=M.iridescence>0,j=M.sheen>0,Tt=M.transmission>0,lt=D&&!!M.anisotropyMap,wt=G&&!!M.clearcoatMap,zt=G&&!!M.clearcoatNormalMap,qt=G&&!!M.clearcoatRoughnessMap,ot=Y&&!!M.iridescenceMap,ge=Y&&!!M.iridescenceThicknessMap,oe=j&&!!M.sheenColorMap,Zt=j&&!!M.sheenRoughnessMap,kt=!!M.specularMap,Dt=!!M.specularColorMap,Qt=!!M.specularIntensityMap,_e=Tt&&!!M.transmissionMap,ze=Tt&&!!M.thicknessMap,se=!!M.gradientMap,pt=!!M.alphaMap,U=M.alphaTest>0,Mt=!!M.alphaHash,Et=!!M.extensions,Xt=!!N.attributes.uv1,Gt=!!N.attributes.uv2,we=!!N.attributes.uv3,Ae=Yi;return M.toneMapped&&(St===null||St.isXRRenderTarget===!0)&&(Ae=n.toneMapping),{isWebGL2:h,shaderID:W,shaderType:M.type,shaderName:M.name,vertexShader:J,fragmentShader:it,defines:M.defines,customVertexShaderID:dt,customFragmentShaderID:It,isRawShaderMaterial:M.isRawShaderMaterial===!0,glslVersion:M.glslVersion,precision:d,batching:st,instancing:Ht,instancingColor:Ht&&Z.instanceColor!==null,supportsVertexTextures:f,outputColorSpace:St===null?n.outputColorSpace:St.isXRRenderTarget===!0?St.texture.colorSpace:Ti,map:ct,matcap:xt,envMap:C,envMapMode:C&&nt.mapping,envMapCubeUVHeight:B,aoMap:rt,lightMap:q,bumpMap:et,normalMap:K,displacementMap:f&&Pt,emissiveMap:_t,normalMapObjectSpace:K&&M.normalMapType===g0,normalMapTangentSpace:K&&M.normalMapType===ad,metalnessMap:v,roughnessMap:_,anisotropy:D,anisotropyMap:lt,clearcoat:G,clearcoatMap:wt,clearcoatNormalMap:zt,clearcoatRoughnessMap:qt,iridescence:Y,iridescenceMap:ot,iridescenceThicknessMap:ge,sheen:j,sheenColorMap:oe,sheenRoughnessMap:Zt,specularMap:kt,specularColorMap:Dt,specularIntensityMap:Qt,transmission:Tt,transmissionMap:_e,thicknessMap:ze,gradientMap:se,opaque:M.transparent===!1&&M.blending===Xi,alphaMap:pt,alphaTest:U,alphaHash:Mt,combine:M.combine,mapUv:ct&&x(M.map.channel),aoMapUv:rt&&x(M.aoMap.channel),lightMapUv:q&&x(M.lightMap.channel),bumpMapUv:et&&x(M.bumpMap.channel),normalMapUv:K&&x(M.normalMap.channel),displacementMapUv:Pt&&x(M.displacementMap.channel),emissiveMapUv:_t&&x(M.emissiveMap.channel),metalnessMapUv:v&&x(M.metalnessMap.channel),roughnessMapUv:_&&x(M.roughnessMap.channel),anisotropyMapUv:lt&&x(M.anisotropyMap.channel),clearcoatMapUv:wt&&x(M.clearcoatMap.channel),clearcoatNormalMapUv:zt&&x(M.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:qt&&x(M.clearcoatRoughnessMap.channel),iridescenceMapUv:ot&&x(M.iridescenceMap.channel),iridescenceThicknessMapUv:ge&&x(M.iridescenceThicknessMap.channel),sheenColorMapUv:oe&&x(M.sheenColorMap.channel),sheenRoughnessMapUv:Zt&&x(M.sheenRoughnessMap.channel),specularMapUv:kt&&x(M.specularMap.channel),specularColorMapUv:Dt&&x(M.specularColorMap.channel),specularIntensityMapUv:Qt&&x(M.specularIntensityMap.channel),transmissionMapUv:_e&&x(M.transmissionMap.channel),thicknessMapUv:ze&&x(M.thicknessMap.channel),alphaMapUv:pt&&x(M.alphaMap.channel),vertexTangents:!!N.attributes.tangent&&(K||D),vertexColors:M.vertexColors,vertexAlphas:M.vertexColors===!0&&!!N.attributes.color&&N.attributes.color.itemSize===4,vertexUv1s:Xt,vertexUv2s:Gt,vertexUv3s:we,pointsUvs:Z.isPoints===!0&&!!N.attributes.uv&&(ct||pt),fog:!!I,useFog:M.fog===!0,fogExp2:I&&I.isFogExp2,flatShading:M.flatShading===!0,sizeAttenuation:M.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:Z.isSkinnedMesh===!0,morphTargets:N.morphAttributes.position!==void 0,morphNormals:N.morphAttributes.normal!==void 0,morphColors:N.morphAttributes.color!==void 0,morphTargetsCount:tt,morphTextureStride:ut,numDirLights:b.directional.length,numPointLights:b.point.length,numSpotLights:b.spot.length,numSpotLightMaps:b.spotLightMap.length,numRectAreaLights:b.rectArea.length,numHemiLights:b.hemi.length,numDirLightShadows:b.directionalShadowMap.length,numPointLightShadows:b.pointShadowMap.length,numSpotLightShadows:b.spotShadowMap.length,numSpotLightShadowsWithMaps:b.numSpotLightShadowsWithMaps,numLightProbes:b.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:M.dithering,shadowMapEnabled:n.shadowMap.enabled&&R.length>0,shadowMapType:n.shadowMap.type,toneMapping:Ae,useLegacyLights:n._useLegacyLights,decodeVideoTexture:ct&&M.map.isVideoTexture===!0&&Me.getTransfer(M.map.colorSpace)===Pe,premultipliedAlpha:M.premultipliedAlpha,doubleSided:M.side===Oe,flipSided:M.side===dn,useDepthPacking:M.depthPacking>=0,depthPacking:M.depthPacking||0,index0AttributeName:M.index0AttributeName,extensionDerivatives:Et&&M.extensions.derivatives===!0,extensionFragDepth:Et&&M.extensions.fragDepth===!0,extensionDrawBuffers:Et&&M.extensions.drawBuffers===!0,extensionShaderTextureLOD:Et&&M.extensions.shaderTextureLOD===!0,extensionClipCullDistance:Et&&M.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:M.customProgramCacheKey()}}function m(M){let b=[];if(M.shaderID?b.push(M.shaderID):(b.push(M.customVertexShaderID),b.push(M.customFragmentShaderID)),M.defines!==void 0)for(let R in M.defines)b.push(R),b.push(M.defines[R]);return M.isRawShaderMaterial===!1&&(E(b,M),y(b,M),b.push(n.outputColorSpace)),b.push(M.customProgramCacheKey),b.join()}function E(M,b){M.push(b.precision),M.push(b.outputColorSpace),M.push(b.envMapMode),M.push(b.envMapCubeUVHeight),M.push(b.mapUv),M.push(b.alphaMapUv),M.push(b.lightMapUv),M.push(b.aoMapUv),M.push(b.bumpMapUv),M.push(b.normalMapUv),M.push(b.displacementMapUv),M.push(b.emissiveMapUv),M.push(b.metalnessMapUv),M.push(b.roughnessMapUv),M.push(b.anisotropyMapUv),M.push(b.clearcoatMapUv),M.push(b.clearcoatNormalMapUv),M.push(b.clearcoatRoughnessMapUv),M.push(b.iridescenceMapUv),M.push(b.iridescenceThicknessMapUv),M.push(b.sheenColorMapUv),M.push(b.sheenRoughnessMapUv),M.push(b.specularMapUv),M.push(b.specularColorMapUv),M.push(b.specularIntensityMapUv),M.push(b.transmissionMapUv),M.push(b.thicknessMapUv),M.push(b.combine),M.push(b.fogExp2),M.push(b.sizeAttenuation),M.push(b.morphTargetsCount),M.push(b.morphAttributeCount),M.push(b.numDirLights),M.push(b.numPointLights),M.push(b.numSpotLights),M.push(b.numSpotLightMaps),M.push(b.numHemiLights),M.push(b.numRectAreaLights),M.push(b.numDirLightShadows),M.push(b.numPointLightShadows),M.push(b.numSpotLightShadows),M.push(b.numSpotLightShadowsWithMaps),M.push(b.numLightProbes),M.push(b.shadowMapType),M.push(b.toneMapping),M.push(b.numClippingPlanes),M.push(b.numClipIntersection),M.push(b.depthPacking)}function y(M,b){o.disableAll(),b.isWebGL2&&o.enable(0),b.supportsVertexTextures&&o.enable(1),b.instancing&&o.enable(2),b.instancingColor&&o.enable(3),b.matcap&&o.enable(4),b.envMap&&o.enable(5),b.normalMapObjectSpace&&o.enable(6),b.normalMapTangentSpace&&o.enable(7),b.clearcoat&&o.enable(8),b.iridescence&&o.enable(9),b.alphaTest&&o.enable(10),b.vertexColors&&o.enable(11),b.vertexAlphas&&o.enable(12),b.vertexUv1s&&o.enable(13),b.vertexUv2s&&o.enable(14),b.vertexUv3s&&o.enable(15),b.vertexTangents&&o.enable(16),b.anisotropy&&o.enable(17),b.alphaHash&&o.enable(18),b.batching&&o.enable(19),M.push(o.mask),o.disableAll(),b.fog&&o.enable(0),b.useFog&&o.enable(1),b.flatShading&&o.enable(2),b.logarithmicDepthBuffer&&o.enable(3),b.skinning&&o.enable(4),b.morphTargets&&o.enable(5),b.morphNormals&&o.enable(6),b.morphColors&&o.enable(7),b.premultipliedAlpha&&o.enable(8),b.shadowMapEnabled&&o.enable(9),b.useLegacyLights&&o.enable(10),b.doubleSided&&o.enable(11),b.flipSided&&o.enable(12),b.useDepthPacking&&o.enable(13),b.dithering&&o.enable(14),b.transmission&&o.enable(15),b.sheen&&o.enable(16),b.opaque&&o.enable(17),b.pointsUvs&&o.enable(18),b.decodeVideoTexture&&o.enable(19),M.push(o.mask)}function S(M){let b=p[M.type],R;if(b){let O=li[b];R=tm.clone(O.uniforms)}else R=M.uniforms;return R}function P(M,b){let R;for(let O=0,Z=l.length;O<Z;O++){let I=l[O];if(I.cacheKey===b){R=I,++R.usedTimes;break}}return R===void 0&&(R=new l_(n,b,M,r),l.push(R)),R}function w(M){if(--M.usedTimes===0){let b=l.indexOf(M);l[b]=l[l.length-1],l.pop(),M.destroy()}}function A(M){c.remove(M)}function F(){c.dispose()}return{getParameters:g,getProgramCacheKey:m,getUniforms:S,acquireProgram:P,releaseProgram:w,releaseShaderCache:A,programs:l,dispose:F}}function f_(){let n=new WeakMap;function t(r){let a=n.get(r);return a===void 0&&(a={},n.set(r,a)),a}function e(r){n.delete(r)}function i(r,a,o){n.get(r)[a]=o}function s(){n=new WeakMap}return{get:t,remove:e,update:i,dispose:s}}function d_(n,t){return n.groupOrder!==t.groupOrder?n.groupOrder-t.groupOrder:n.renderOrder!==t.renderOrder?n.renderOrder-t.renderOrder:n.material.id!==t.material.id?n.material.id-t.material.id:n.z!==t.z?n.z-t.z:n.id-t.id}function Lf(n,t){return n.groupOrder!==t.groupOrder?n.groupOrder-t.groupOrder:n.renderOrder!==t.renderOrder?n.renderOrder-t.renderOrder:n.z!==t.z?t.z-n.z:n.id-t.id}function Df(){let n=[],t=0,e=[],i=[],s=[];function r(){t=0,e.length=0,i.length=0,s.length=0}function a(u,f,d,p,x,g){let m=n[t];return m===void 0?(m={id:u.id,object:u,geometry:f,material:d,groupOrder:p,renderOrder:u.renderOrder,z:x,group:g},n[t]=m):(m.id=u.id,m.object=u,m.geometry=f,m.material=d,m.groupOrder=p,m.renderOrder=u.renderOrder,m.z=x,m.group=g),t++,m}function o(u,f,d,p,x,g){let m=a(u,f,d,p,x,g);d.transmission>0?i.push(m):d.transparent===!0?s.push(m):e.push(m)}function c(u,f,d,p,x,g){let m=a(u,f,d,p,x,g);d.transmission>0?i.unshift(m):d.transparent===!0?s.unshift(m):e.unshift(m)}function l(u,f){e.length>1&&e.sort(u||d_),i.length>1&&i.sort(f||Lf),s.length>1&&s.sort(f||Lf)}function h(){for(let u=t,f=n.length;u<f;u++){let d=n[u];if(d.id===null)break;d.id=null,d.object=null,d.geometry=null,d.material=null,d.group=null}}return{opaque:e,transmissive:i,transparent:s,init:r,push:o,unshift:c,finish:h,sort:l}}function p_(){let n=new WeakMap;function t(i,s){let r=n.get(i),a;return r===void 0?(a=new Df,n.set(i,[a])):s>=r.length?(a=new Df,r.push(a)):a=r[s],a}function e(){n=new WeakMap}return{get:t,dispose:e}}function m_(){let n={};return{get:function(t){if(n[t.id]!==void 0)return n[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new L,color:new Ft};break;case"SpotLight":e={position:new L,direction:new L,color:new Ft,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new L,color:new Ft,distance:0,decay:0};break;case"HemisphereLight":e={direction:new L,skyColor:new Ft,groundColor:new Ft};break;case"RectAreaLight":e={color:new Ft,position:new L,halfWidth:new L,halfHeight:new L};break}return n[t.id]=e,e}}}function g_(){let n={};return{get:function(t){if(n[t.id]!==void 0)return n[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[t.id]=e,e}}}var x_=0;function y_(n,t){return(t.castShadow?2:0)-(n.castShadow?2:0)+(t.map?1:0)-(n.map?1:0)}function __(n,t){let e=new m_,i=g_(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)s.probe.push(new L);let r=new L,a=new Ce,o=new Ce;function c(h,u){let f=0,d=0,p=0;for(let O=0;O<9;O++)s.probe[O].set(0,0,0);let x=0,g=0,m=0,E=0,y=0,S=0,P=0,w=0,A=0,F=0,M=0;h.sort(y_);let b=u===!0?Math.PI:1;for(let O=0,Z=h.length;O<Z;O++){let I=h[O],N=I.color,H=I.intensity,nt=I.distance,B=I.shadow&&I.shadow.map?I.shadow.map.texture:null;if(I.isAmbientLight)f+=N.r*H*b,d+=N.g*H*b,p+=N.b*H*b;else if(I.isLightProbe){for(let W=0;W<9;W++)s.probe[W].addScaledVector(I.sh.coefficients[W],H);M++}else if(I.isDirectionalLight){let W=e.get(I);if(W.color.copy(I.color).multiplyScalar(I.intensity*b),I.castShadow){let Q=I.shadow,tt=i.get(I);tt.shadowBias=Q.bias,tt.shadowNormalBias=Q.normalBias,tt.shadowRadius=Q.radius,tt.shadowMapSize=Q.mapSize,s.directionalShadow[x]=tt,s.directionalShadowMap[x]=B,s.directionalShadowMatrix[x]=I.shadow.matrix,S++}s.directional[x]=W,x++}else if(I.isSpotLight){let W=e.get(I);W.position.setFromMatrixPosition(I.matrixWorld),W.color.copy(N).multiplyScalar(H*b),W.distance=nt,W.coneCos=Math.cos(I.angle),W.penumbraCos=Math.cos(I.angle*(1-I.penumbra)),W.decay=I.decay,s.spot[m]=W;let Q=I.shadow;if(I.map&&(s.spotLightMap[A]=I.map,A++,Q.updateMatrices(I),I.castShadow&&F++),s.spotLightMatrix[m]=Q.matrix,I.castShadow){let tt=i.get(I);tt.shadowBias=Q.bias,tt.shadowNormalBias=Q.normalBias,tt.shadowRadius=Q.radius,tt.shadowMapSize=Q.mapSize,s.spotShadow[m]=tt,s.spotShadowMap[m]=B,w++}m++}else if(I.isRectAreaLight){let W=e.get(I);W.color.copy(N).multiplyScalar(H),W.halfWidth.set(I.width*.5,0,0),W.halfHeight.set(0,I.height*.5,0),s.rectArea[E]=W,E++}else if(I.isPointLight){let W=e.get(I);if(W.color.copy(I.color).multiplyScalar(I.intensity*b),W.distance=I.distance,W.decay=I.decay,I.castShadow){let Q=I.shadow,tt=i.get(I);tt.shadowBias=Q.bias,tt.shadowNormalBias=Q.normalBias,tt.shadowRadius=Q.radius,tt.shadowMapSize=Q.mapSize,tt.shadowCameraNear=Q.camera.near,tt.shadowCameraFar=Q.camera.far,s.pointShadow[g]=tt,s.pointShadowMap[g]=B,s.pointShadowMatrix[g]=I.shadow.matrix,P++}s.point[g]=W,g++}else if(I.isHemisphereLight){let W=e.get(I);W.skyColor.copy(I.color).multiplyScalar(H*b),W.groundColor.copy(I.groundColor).multiplyScalar(H*b),s.hemi[y]=W,y++}}E>0&&(t.isWebGL2?n.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=mt.LTC_FLOAT_1,s.rectAreaLTC2=mt.LTC_FLOAT_2):(s.rectAreaLTC1=mt.LTC_HALF_1,s.rectAreaLTC2=mt.LTC_HALF_2):n.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=mt.LTC_FLOAT_1,s.rectAreaLTC2=mt.LTC_FLOAT_2):n.has("OES_texture_half_float_linear")===!0?(s.rectAreaLTC1=mt.LTC_HALF_1,s.rectAreaLTC2=mt.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),s.ambient[0]=f,s.ambient[1]=d,s.ambient[2]=p;let R=s.hash;(R.directionalLength!==x||R.pointLength!==g||R.spotLength!==m||R.rectAreaLength!==E||R.hemiLength!==y||R.numDirectionalShadows!==S||R.numPointShadows!==P||R.numSpotShadows!==w||R.numSpotMaps!==A||R.numLightProbes!==M)&&(s.directional.length=x,s.spot.length=m,s.rectArea.length=E,s.point.length=g,s.hemi.length=y,s.directionalShadow.length=S,s.directionalShadowMap.length=S,s.pointShadow.length=P,s.pointShadowMap.length=P,s.spotShadow.length=w,s.spotShadowMap.length=w,s.directionalShadowMatrix.length=S,s.pointShadowMatrix.length=P,s.spotLightMatrix.length=w+A-F,s.spotLightMap.length=A,s.numSpotLightShadowsWithMaps=F,s.numLightProbes=M,R.directionalLength=x,R.pointLength=g,R.spotLength=m,R.rectAreaLength=E,R.hemiLength=y,R.numDirectionalShadows=S,R.numPointShadows=P,R.numSpotShadows=w,R.numSpotMaps=A,R.numLightProbes=M,s.version=x_++)}function l(h,u){let f=0,d=0,p=0,x=0,g=0,m=u.matrixWorldInverse;for(let E=0,y=h.length;E<y;E++){let S=h[E];if(S.isDirectionalLight){let P=s.directional[f];P.direction.setFromMatrixPosition(S.matrixWorld),r.setFromMatrixPosition(S.target.matrixWorld),P.direction.sub(r),P.direction.transformDirection(m),f++}else if(S.isSpotLight){let P=s.spot[p];P.position.setFromMatrixPosition(S.matrixWorld),P.position.applyMatrix4(m),P.direction.setFromMatrixPosition(S.matrixWorld),r.setFromMatrixPosition(S.target.matrixWorld),P.direction.sub(r),P.direction.transformDirection(m),p++}else if(S.isRectAreaLight){let P=s.rectArea[x];P.position.setFromMatrixPosition(S.matrixWorld),P.position.applyMatrix4(m),o.identity(),a.copy(S.matrixWorld),a.premultiply(m),o.extractRotation(a),P.halfWidth.set(S.width*.5,0,0),P.halfHeight.set(0,S.height*.5,0),P.halfWidth.applyMatrix4(o),P.halfHeight.applyMatrix4(o),x++}else if(S.isPointLight){let P=s.point[d];P.position.setFromMatrixPosition(S.matrixWorld),P.position.applyMatrix4(m),d++}else if(S.isHemisphereLight){let P=s.hemi[g];P.direction.setFromMatrixPosition(S.matrixWorld),P.direction.transformDirection(m),g++}}}return{setup:c,setupView:l,state:s}}function Uf(n,t){let e=new __(n,t),i=[],s=[];function r(){i.length=0,s.length=0}function a(u){i.push(u)}function o(u){s.push(u)}function c(u){e.setup(i,u)}function l(u){e.setupView(i,u)}return{init:r,state:{lightsArray:i,shadowsArray:s,lights:e},setupLights:c,setupLightsView:l,pushLight:a,pushShadow:o}}function v_(n,t){let e=new WeakMap;function i(r,a=0){let o=e.get(r),c;return o===void 0?(c=new Uf(n,t),e.set(r,[c])):a>=o.length?(c=new Uf(n,t),o.push(c)):c=o[a],c}function s(){e=new WeakMap}return{get:i,dispose:s}}var Pl=class extends Ai{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=p0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},Il=class extends Ai{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},M_=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,E_=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function S_(n,t,e){let i=new ra,s=new ht,r=new ht,a=new We,o=new Pl({depthPacking:m0}),c=new Il,l={},h=e.maxTextureSize,u={[qi]:dn,[dn]:qi,[Oe]:Oe},f=new Vn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ht},radius:{value:4}},vertexShader:M_,fragmentShader:E_}),d=f.clone();d.defines.HORIZONTAL_PASS=1;let p=new Ie;p.setAttribute("position",new me(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let x=new bt(p,f),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Zf;let m=this.type;this.render=function(w,A,F){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||w.length===0)return;let M=n.getRenderTarget(),b=n.getActiveCubeFace(),R=n.getActiveMipmapLevel(),O=n.state;O.setBlending(Wi),O.buffers.color.setClear(1,1,1,1),O.buffers.depth.setTest(!0),O.setScissorTest(!1);let Z=m!==Ei&&this.type===Ei,I=m===Ei&&this.type!==Ei;for(let N=0,H=w.length;N<H;N++){let nt=w[N],B=nt.shadow;if(B===void 0){console.warn("THREE.WebGLShadowMap:",nt,"has no shadow.");continue}if(B.autoUpdate===!1&&B.needsUpdate===!1)continue;s.copy(B.mapSize);let W=B.getFrameExtents();if(s.multiply(W),r.copy(B.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/W.x),s.x=r.x*W.x,B.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/W.y),s.y=r.y*W.y,B.mapSize.y=r.y)),B.map===null||Z===!0||I===!0){let tt=this.type!==Ei?{minFilter:sn,magFilter:sn}:{};B.map!==null&&B.map.dispose(),B.map=new wi(s.x,s.y,tt),B.map.texture.name=nt.name+".shadowMap",B.camera.updateProjectionMatrix()}n.setRenderTarget(B.map),n.clear();let Q=B.getViewportCount();for(let tt=0;tt<Q;tt++){let ut=B.getViewport(tt);a.set(r.x*ut.x,r.y*ut.y,r.x*ut.z,r.y*ut.w),O.viewport(a),B.updateMatrices(nt,tt),i=B.getFrustum(),S(A,F,B.camera,nt,this.type)}B.isPointLightShadow!==!0&&this.type===Ei&&E(B,F),B.needsUpdate=!1}m=this.type,g.needsUpdate=!1,n.setRenderTarget(M,b,R)};function E(w,A){let F=t.update(x);f.defines.VSM_SAMPLES!==w.blurSamples&&(f.defines.VSM_SAMPLES=w.blurSamples,d.defines.VSM_SAMPLES=w.blurSamples,f.needsUpdate=!0,d.needsUpdate=!0),w.mapPass===null&&(w.mapPass=new wi(s.x,s.y)),f.uniforms.shadow_pass.value=w.map.texture,f.uniforms.resolution.value=w.mapSize,f.uniforms.radius.value=w.radius,n.setRenderTarget(w.mapPass),n.clear(),n.renderBufferDirect(A,null,F,f,x,null),d.uniforms.shadow_pass.value=w.mapPass.texture,d.uniforms.resolution.value=w.mapSize,d.uniforms.radius.value=w.radius,n.setRenderTarget(w.map),n.clear(),n.renderBufferDirect(A,null,F,d,x,null)}function y(w,A,F,M){let b=null,R=F.isPointLight===!0?w.customDistanceMaterial:w.customDepthMaterial;if(R!==void 0)b=R;else if(b=F.isPointLight===!0?c:o,n.localClippingEnabled&&A.clipShadows===!0&&Array.isArray(A.clippingPlanes)&&A.clippingPlanes.length!==0||A.displacementMap&&A.displacementScale!==0||A.alphaMap&&A.alphaTest>0||A.map&&A.alphaTest>0){let O=b.uuid,Z=A.uuid,I=l[O];I===void 0&&(I={},l[O]=I);let N=I[Z];N===void 0&&(N=b.clone(),I[Z]=N,A.addEventListener("dispose",P)),b=N}if(b.visible=A.visible,b.wireframe=A.wireframe,M===Ei?b.side=A.shadowSide!==null?A.shadowSide:A.side:b.side=A.shadowSide!==null?A.shadowSide:u[A.side],b.alphaMap=A.alphaMap,b.alphaTest=A.alphaTest,b.map=A.map,b.clipShadows=A.clipShadows,b.clippingPlanes=A.clippingPlanes,b.clipIntersection=A.clipIntersection,b.displacementMap=A.displacementMap,b.displacementScale=A.displacementScale,b.displacementBias=A.displacementBias,b.wireframeLinewidth=A.wireframeLinewidth,b.linewidth=A.linewidth,F.isPointLight===!0&&b.isMeshDistanceMaterial===!0){let O=n.properties.get(b);O.light=F}return b}function S(w,A,F,M,b){if(w.visible===!1)return;if(w.layers.test(A.layers)&&(w.isMesh||w.isLine||w.isPoints)&&(w.castShadow||w.receiveShadow&&b===Ei)&&(!w.frustumCulled||i.intersectsObject(w))){w.modelViewMatrix.multiplyMatrices(F.matrixWorldInverse,w.matrixWorld);let Z=t.update(w),I=w.material;if(Array.isArray(I)){let N=Z.groups;for(let H=0,nt=N.length;H<nt;H++){let B=N[H],W=I[B.materialIndex];if(W&&W.visible){let Q=y(w,W,M,b);w.onBeforeShadow(n,w,A,F,Z,Q,B),n.renderBufferDirect(F,null,Z,Q,w,B),w.onAfterShadow(n,w,A,F,Z,Q,B)}}}else if(I.visible){let N=y(w,I,M,b);w.onBeforeShadow(n,w,A,F,Z,N,null),n.renderBufferDirect(F,null,Z,N,w,null),w.onAfterShadow(n,w,A,F,Z,N,null)}}let O=w.children;for(let Z=0,I=O.length;Z<I;Z++)S(O[Z],A,F,M,b)}function P(w){w.target.removeEventListener("dispose",P);for(let F in l){let M=l[F],b=w.target.uuid;b in M&&(M[b].dispose(),delete M[b])}}}function b_(n,t,e){let i=e.isWebGL2;function s(){let U=!1,Mt=new We,Et=null,Xt=new We(0,0,0,0);return{setMask:function(Gt){Et!==Gt&&!U&&(n.colorMask(Gt,Gt,Gt,Gt),Et=Gt)},setLocked:function(Gt){U=Gt},setClear:function(Gt,we,Ae,tn,gn){gn===!0&&(Gt*=tn,we*=tn,Ae*=tn),Mt.set(Gt,we,Ae,tn),Xt.equals(Mt)===!1&&(n.clearColor(Gt,we,Ae,tn),Xt.copy(Mt))},reset:function(){U=!1,Et=null,Xt.set(-1,0,0,0)}}}function r(){let U=!1,Mt=null,Et=null,Xt=null;return{setTest:function(Gt){Gt?st(n.DEPTH_TEST):ct(n.DEPTH_TEST)},setMask:function(Gt){Mt!==Gt&&!U&&(n.depthMask(Gt),Mt=Gt)},setFunc:function(Gt){if(Et!==Gt){switch(Gt){case Xp:n.depthFunc(n.NEVER);break;case Yp:n.depthFunc(n.ALWAYS);break;case $p:n.depthFunc(n.LESS);break;case go:n.depthFunc(n.LEQUAL);break;case qp:n.depthFunc(n.EQUAL);break;case Zp:n.depthFunc(n.GEQUAL);break;case Jp:n.depthFunc(n.GREATER);break;case Kp:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}Et=Gt}},setLocked:function(Gt){U=Gt},setClear:function(Gt){Xt!==Gt&&(n.clearDepth(Gt),Xt=Gt)},reset:function(){U=!1,Mt=null,Et=null,Xt=null}}}function a(){let U=!1,Mt=null,Et=null,Xt=null,Gt=null,we=null,Ae=null,tn=null,gn=null;return{setTest:function(Re){U||(Re?st(n.STENCIL_TEST):ct(n.STENCIL_TEST))},setMask:function(Re){Mt!==Re&&!U&&(n.stencilMask(Re),Mt=Re)},setFunc:function(Re,xn,ci){(Et!==Re||Xt!==xn||Gt!==ci)&&(n.stencilFunc(Re,xn,ci),Et=Re,Xt=xn,Gt=ci)},setOp:function(Re,xn,ci){(we!==Re||Ae!==xn||tn!==ci)&&(n.stencilOp(Re,xn,ci),we=Re,Ae=xn,tn=ci)},setLocked:function(Re){U=Re},setClear:function(Re){gn!==Re&&(n.clearStencil(Re),gn=Re)},reset:function(){U=!1,Mt=null,Et=null,Xt=null,Gt=null,we=null,Ae=null,tn=null,gn=null}}}let o=new s,c=new r,l=new a,h=new WeakMap,u=new WeakMap,f={},d={},p=new WeakMap,x=[],g=null,m=!1,E=null,y=null,S=null,P=null,w=null,A=null,F=null,M=new Ft(0,0,0),b=0,R=!1,O=null,Z=null,I=null,N=null,H=null,nt=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS),B=!1,W=0,Q=n.getParameter(n.VERSION);Q.indexOf("WebGL")!==-1?(W=parseFloat(/^WebGL (\d)/.exec(Q)[1]),B=W>=1):Q.indexOf("OpenGL ES")!==-1&&(W=parseFloat(/^OpenGL ES (\d)/.exec(Q)[1]),B=W>=2);let tt=null,ut={},J=n.getParameter(n.SCISSOR_BOX),it=n.getParameter(n.VIEWPORT),dt=new We().fromArray(J),It=new We().fromArray(it);function St(U,Mt,Et,Xt){let Gt=new Uint8Array(4),we=n.createTexture();n.bindTexture(U,we),n.texParameteri(U,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(U,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let Ae=0;Ae<Et;Ae++)i&&(U===n.TEXTURE_3D||U===n.TEXTURE_2D_ARRAY)?n.texImage3D(Mt,0,n.RGBA,1,1,Xt,0,n.RGBA,n.UNSIGNED_BYTE,Gt):n.texImage2D(Mt+Ae,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Gt);return we}let Ht={};Ht[n.TEXTURE_2D]=St(n.TEXTURE_2D,n.TEXTURE_2D,1),Ht[n.TEXTURE_CUBE_MAP]=St(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(Ht[n.TEXTURE_2D_ARRAY]=St(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),Ht[n.TEXTURE_3D]=St(n.TEXTURE_3D,n.TEXTURE_3D,1,1)),o.setClear(0,0,0,1),c.setClear(1),l.setClear(0),st(n.DEPTH_TEST),c.setFunc(go),_t(!1),v(pu),st(n.CULL_FACE),K(Wi);function st(U){f[U]!==!0&&(n.enable(U),f[U]=!0)}function ct(U){f[U]!==!1&&(n.disable(U),f[U]=!1)}function xt(U,Mt){return d[U]!==Mt?(n.bindFramebuffer(U,Mt),d[U]=Mt,i&&(U===n.DRAW_FRAMEBUFFER&&(d[n.FRAMEBUFFER]=Mt),U===n.FRAMEBUFFER&&(d[n.DRAW_FRAMEBUFFER]=Mt)),!0):!1}function C(U,Mt){let Et=x,Xt=!1;if(U)if(Et=p.get(Mt),Et===void 0&&(Et=[],p.set(Mt,Et)),U.isWebGLMultipleRenderTargets){let Gt=U.texture;if(Et.length!==Gt.length||Et[0]!==n.COLOR_ATTACHMENT0){for(let we=0,Ae=Gt.length;we<Ae;we++)Et[we]=n.COLOR_ATTACHMENT0+we;Et.length=Gt.length,Xt=!0}}else Et[0]!==n.COLOR_ATTACHMENT0&&(Et[0]=n.COLOR_ATTACHMENT0,Xt=!0);else Et[0]!==n.BACK&&(Et[0]=n.BACK,Xt=!0);Xt&&(e.isWebGL2?n.drawBuffers(Et):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(Et))}function rt(U){return g!==U?(n.useProgram(U),g=U,!0):!1}let q={[us]:n.FUNC_ADD,[Pp]:n.FUNC_SUBTRACT,[Ip]:n.FUNC_REVERSE_SUBTRACT};if(i)q[xu]=n.MIN,q[yu]=n.MAX;else{let U=t.get("EXT_blend_minmax");U!==null&&(q[xu]=U.MIN_EXT,q[yu]=U.MAX_EXT)}let et={[Lp]:n.ZERO,[Dp]:n.ONE,[Up]:n.SRC_COLOR,[fl]:n.SRC_ALPHA,[Hp]:n.SRC_ALPHA_SATURATE,[zp]:n.DST_COLOR,[Np]:n.DST_ALPHA,[Op]:n.ONE_MINUS_SRC_COLOR,[dl]:n.ONE_MINUS_SRC_ALPHA,[Bp]:n.ONE_MINUS_DST_COLOR,[Fp]:n.ONE_MINUS_DST_ALPHA,[kp]:n.CONSTANT_COLOR,[Gp]:n.ONE_MINUS_CONSTANT_COLOR,[Vp]:n.CONSTANT_ALPHA,[Wp]:n.ONE_MINUS_CONSTANT_ALPHA};function K(U,Mt,Et,Xt,Gt,we,Ae,tn,gn,Re){if(U===Wi){m===!0&&(ct(n.BLEND),m=!1);return}if(m===!1&&(st(n.BLEND),m=!0),U!==Cp){if(U!==E||Re!==R){if((y!==us||w!==us)&&(n.blendEquation(n.FUNC_ADD),y=us,w=us),Re)switch(U){case Xi:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Zi:n.blendFunc(n.ONE,n.ONE);break;case mu:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case gu:n.blendFuncSeparate(n.ZERO,n.SRC_COLOR,n.ZERO,n.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}else switch(U){case Xi:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Zi:n.blendFunc(n.SRC_ALPHA,n.ONE);break;case mu:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case gu:n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}S=null,P=null,A=null,F=null,M.set(0,0,0),b=0,E=U,R=Re}return}Gt=Gt||Mt,we=we||Et,Ae=Ae||Xt,(Mt!==y||Gt!==w)&&(n.blendEquationSeparate(q[Mt],q[Gt]),y=Mt,w=Gt),(Et!==S||Xt!==P||we!==A||Ae!==F)&&(n.blendFuncSeparate(et[Et],et[Xt],et[we],et[Ae]),S=Et,P=Xt,A=we,F=Ae),(tn.equals(M)===!1||gn!==b)&&(n.blendColor(tn.r,tn.g,tn.b,gn),M.copy(tn),b=gn),E=U,R=!1}function Pt(U,Mt){U.side===Oe?ct(n.CULL_FACE):st(n.CULL_FACE);let Et=U.side===dn;Mt&&(Et=!Et),_t(Et),U.blending===Xi&&U.transparent===!1?K(Wi):K(U.blending,U.blendEquation,U.blendSrc,U.blendDst,U.blendEquationAlpha,U.blendSrcAlpha,U.blendDstAlpha,U.blendColor,U.blendAlpha,U.premultipliedAlpha),c.setFunc(U.depthFunc),c.setTest(U.depthTest),c.setMask(U.depthWrite),o.setMask(U.colorWrite);let Xt=U.stencilWrite;l.setTest(Xt),Xt&&(l.setMask(U.stencilWriteMask),l.setFunc(U.stencilFunc,U.stencilRef,U.stencilFuncMask),l.setOp(U.stencilFail,U.stencilZFail,U.stencilZPass)),D(U.polygonOffset,U.polygonOffsetFactor,U.polygonOffsetUnits),U.alphaToCoverage===!0?st(n.SAMPLE_ALPHA_TO_COVERAGE):ct(n.SAMPLE_ALPHA_TO_COVERAGE)}function _t(U){O!==U&&(U?n.frontFace(n.CW):n.frontFace(n.CCW),O=U)}function v(U){U!==Ap?(st(n.CULL_FACE),U!==Z&&(U===pu?n.cullFace(n.BACK):U===Rp?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):ct(n.CULL_FACE),Z=U}function _(U){U!==I&&(B&&n.lineWidth(U),I=U)}function D(U,Mt,Et){U?(st(n.POLYGON_OFFSET_FILL),(N!==Mt||H!==Et)&&(n.polygonOffset(Mt,Et),N=Mt,H=Et)):ct(n.POLYGON_OFFSET_FILL)}function G(U){U?st(n.SCISSOR_TEST):ct(n.SCISSOR_TEST)}function Y(U){U===void 0&&(U=n.TEXTURE0+nt-1),tt!==U&&(n.activeTexture(U),tt=U)}function j(U,Mt,Et){Et===void 0&&(tt===null?Et=n.TEXTURE0+nt-1:Et=tt);let Xt=ut[Et];Xt===void 0&&(Xt={type:void 0,texture:void 0},ut[Et]=Xt),(Xt.type!==U||Xt.texture!==Mt)&&(tt!==Et&&(n.activeTexture(Et),tt=Et),n.bindTexture(U,Mt||Ht[U]),Xt.type=U,Xt.texture=Mt)}function Tt(){let U=ut[tt];U!==void 0&&U.type!==void 0&&(n.bindTexture(U.type,null),U.type=void 0,U.texture=void 0)}function lt(){try{n.compressedTexImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function wt(){try{n.compressedTexImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function zt(){try{n.texSubImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function qt(){try{n.texSubImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function ot(){try{n.compressedTexSubImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function ge(){try{n.compressedTexSubImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function oe(){try{n.texStorage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Zt(){try{n.texStorage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function kt(){try{n.texImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Dt(){try{n.texImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Qt(U){dt.equals(U)===!1&&(n.scissor(U.x,U.y,U.z,U.w),dt.copy(U))}function _e(U){It.equals(U)===!1&&(n.viewport(U.x,U.y,U.z,U.w),It.copy(U))}function ze(U,Mt){let Et=u.get(Mt);Et===void 0&&(Et=new WeakMap,u.set(Mt,Et));let Xt=Et.get(U);Xt===void 0&&(Xt=n.getUniformBlockIndex(Mt,U.name),Et.set(U,Xt))}function se(U,Mt){let Xt=u.get(Mt).get(U);h.get(Mt)!==Xt&&(n.uniformBlockBinding(Mt,Xt,U.__bindingPointIndex),h.set(Mt,Xt))}function pt(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),i===!0&&(n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null)),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),f={},tt=null,ut={},d={},p=new WeakMap,x=[],g=null,m=!1,E=null,y=null,S=null,P=null,w=null,A=null,F=null,M=new Ft(0,0,0),b=0,R=!1,O=null,Z=null,I=null,N=null,H=null,dt.set(0,0,n.canvas.width,n.canvas.height),It.set(0,0,n.canvas.width,n.canvas.height),o.reset(),c.reset(),l.reset()}return{buffers:{color:o,depth:c,stencil:l},enable:st,disable:ct,bindFramebuffer:xt,drawBuffers:C,useProgram:rt,setBlending:K,setMaterial:Pt,setFlipSided:_t,setCullFace:v,setLineWidth:_,setPolygonOffset:D,setScissorTest:G,activeTexture:Y,bindTexture:j,unbindTexture:Tt,compressedTexImage2D:lt,compressedTexImage3D:wt,texImage2D:kt,texImage3D:Dt,updateUBOMapping:ze,uniformBlockBinding:se,texStorage2D:oe,texStorage3D:Zt,texSubImage2D:zt,texSubImage3D:qt,compressedTexSubImage2D:ot,compressedTexSubImage3D:ge,scissor:Qt,viewport:_e,reset:pt}}function T_(n,t,e,i,s,r,a){let o=s.isWebGL2,c=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap,u,f=new WeakMap,d=!1;try{d=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function p(v,_){return d?new OffscreenCanvas(v,_):bo("canvas")}function x(v,_,D,G){let Y=1;if((v.width>G||v.height>G)&&(Y=G/Math.max(v.width,v.height)),Y<1||_===!0)if(typeof HTMLImageElement<"u"&&v instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&v instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&v instanceof ImageBitmap){let j=_?So:Math.floor,Tt=j(Y*v.width),lt=j(Y*v.height);u===void 0&&(u=p(Tt,lt));let wt=D?p(Tt,lt):u;return wt.width=Tt,wt.height=lt,wt.getContext("2d").drawImage(v,0,0,Tt,lt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+v.width+"x"+v.height+") to ("+Tt+"x"+lt+")."),wt}else return"data"in v&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+v.width+"x"+v.height+")."),v;return v}function g(v){return _l(v.width)&&_l(v.height)}function m(v){return o?!1:v.wrapS!==jn||v.wrapT!==jn||v.minFilter!==sn&&v.minFilter!==Bn}function E(v,_){return v.generateMipmaps&&_&&v.minFilter!==sn&&v.minFilter!==Bn}function y(v){n.generateMipmap(v)}function S(v,_,D,G,Y=!1){if(o===!1)return _;if(v!==null){if(n[v]!==void 0)return n[v];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+v+"'")}let j=_;if(_===n.RED&&(D===n.FLOAT&&(j=n.R32F),D===n.HALF_FLOAT&&(j=n.R16F),D===n.UNSIGNED_BYTE&&(j=n.R8)),_===n.RED_INTEGER&&(D===n.UNSIGNED_BYTE&&(j=n.R8UI),D===n.UNSIGNED_SHORT&&(j=n.R16UI),D===n.UNSIGNED_INT&&(j=n.R32UI),D===n.BYTE&&(j=n.R8I),D===n.SHORT&&(j=n.R16I),D===n.INT&&(j=n.R32I)),_===n.RG&&(D===n.FLOAT&&(j=n.RG32F),D===n.HALF_FLOAT&&(j=n.RG16F),D===n.UNSIGNED_BYTE&&(j=n.RG8)),_===n.RGBA){let Tt=Y?_o:Me.getTransfer(G);D===n.FLOAT&&(j=n.RGBA32F),D===n.HALF_FLOAT&&(j=n.RGBA16F),D===n.UNSIGNED_BYTE&&(j=Tt===Pe?n.SRGB8_ALPHA8:n.RGBA8),D===n.UNSIGNED_SHORT_4_4_4_4&&(j=n.RGBA4),D===n.UNSIGNED_SHORT_5_5_5_1&&(j=n.RGB5_A1)}return(j===n.R16F||j===n.R32F||j===n.RG16F||j===n.RG32F||j===n.RGBA16F||j===n.RGBA32F)&&t.get("EXT_color_buffer_float"),j}function P(v,_,D){return E(v,D)===!0||v.isFramebufferTexture&&v.minFilter!==sn&&v.minFilter!==Bn?Math.log2(Math.max(_.width,_.height))+1:v.mipmaps!==void 0&&v.mipmaps.length>0?v.mipmaps.length:v.isCompressedTexture&&Array.isArray(v.image)?_.mipmaps.length:1}function w(v){return v===sn||v===_u||v===Lc?n.NEAREST:n.LINEAR}function A(v){let _=v.target;_.removeEventListener("dispose",A),M(_),_.isVideoTexture&&h.delete(_)}function F(v){let _=v.target;_.removeEventListener("dispose",F),R(_)}function M(v){let _=i.get(v);if(_.__webglInit===void 0)return;let D=v.source,G=f.get(D);if(G){let Y=G[_.__cacheKey];Y.usedTimes--,Y.usedTimes===0&&b(v),Object.keys(G).length===0&&f.delete(D)}i.remove(v)}function b(v){let _=i.get(v);n.deleteTexture(_.__webglTexture);let D=v.source,G=f.get(D);delete G[_.__cacheKey],a.memory.textures--}function R(v){let _=v.texture,D=i.get(v),G=i.get(_);if(G.__webglTexture!==void 0&&(n.deleteTexture(G.__webglTexture),a.memory.textures--),v.depthTexture&&v.depthTexture.dispose(),v.isWebGLCubeRenderTarget)for(let Y=0;Y<6;Y++){if(Array.isArray(D.__webglFramebuffer[Y]))for(let j=0;j<D.__webglFramebuffer[Y].length;j++)n.deleteFramebuffer(D.__webglFramebuffer[Y][j]);else n.deleteFramebuffer(D.__webglFramebuffer[Y]);D.__webglDepthbuffer&&n.deleteRenderbuffer(D.__webglDepthbuffer[Y])}else{if(Array.isArray(D.__webglFramebuffer))for(let Y=0;Y<D.__webglFramebuffer.length;Y++)n.deleteFramebuffer(D.__webglFramebuffer[Y]);else n.deleteFramebuffer(D.__webglFramebuffer);if(D.__webglDepthbuffer&&n.deleteRenderbuffer(D.__webglDepthbuffer),D.__webglMultisampledFramebuffer&&n.deleteFramebuffer(D.__webglMultisampledFramebuffer),D.__webglColorRenderbuffer)for(let Y=0;Y<D.__webglColorRenderbuffer.length;Y++)D.__webglColorRenderbuffer[Y]&&n.deleteRenderbuffer(D.__webglColorRenderbuffer[Y]);D.__webglDepthRenderbuffer&&n.deleteRenderbuffer(D.__webglDepthRenderbuffer)}if(v.isWebGLMultipleRenderTargets)for(let Y=0,j=_.length;Y<j;Y++){let Tt=i.get(_[Y]);Tt.__webglTexture&&(n.deleteTexture(Tt.__webglTexture),a.memory.textures--),i.remove(_[Y])}i.remove(_),i.remove(v)}let O=0;function Z(){O=0}function I(){let v=O;return v>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+v+" texture units while this GPU supports only "+s.maxTextures),O+=1,v}function N(v){let _=[];return _.push(v.wrapS),_.push(v.wrapT),_.push(v.wrapR||0),_.push(v.magFilter),_.push(v.minFilter),_.push(v.anisotropy),_.push(v.internalFormat),_.push(v.format),_.push(v.type),_.push(v.generateMipmaps),_.push(v.premultiplyAlpha),_.push(v.flipY),_.push(v.unpackAlignment),_.push(v.colorSpace),_.join()}function H(v,_){let D=i.get(v);if(v.isVideoTexture&&Pt(v),v.isRenderTargetTexture===!1&&v.version>0&&D.__version!==v.version){let G=v.image;if(G===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(G.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{dt(D,v,_);return}}e.bindTexture(n.TEXTURE_2D,D.__webglTexture,n.TEXTURE0+_)}function nt(v,_){let D=i.get(v);if(v.version>0&&D.__version!==v.version){dt(D,v,_);return}e.bindTexture(n.TEXTURE_2D_ARRAY,D.__webglTexture,n.TEXTURE0+_)}function B(v,_){let D=i.get(v);if(v.version>0&&D.__version!==v.version){dt(D,v,_);return}e.bindTexture(n.TEXTURE_3D,D.__webglTexture,n.TEXTURE0+_)}function W(v,_){let D=i.get(v);if(v.version>0&&D.__version!==v.version){It(D,v,_);return}e.bindTexture(n.TEXTURE_CUBE_MAP,D.__webglTexture,n.TEXTURE0+_)}let Q={[Qr]:n.REPEAT,[jn]:n.CLAMP_TO_EDGE,[gl]:n.MIRRORED_REPEAT},tt={[sn]:n.NEAREST,[_u]:n.NEAREST_MIPMAP_NEAREST,[Lc]:n.NEAREST_MIPMAP_LINEAR,[Bn]:n.LINEAR,[r0]:n.LINEAR_MIPMAP_NEAREST,[ta]:n.LINEAR_MIPMAP_LINEAR},ut={[x0]:n.NEVER,[S0]:n.ALWAYS,[y0]:n.LESS,[od]:n.LEQUAL,[_0]:n.EQUAL,[E0]:n.GEQUAL,[v0]:n.GREATER,[M0]:n.NOTEQUAL};function J(v,_,D){if(D?(n.texParameteri(v,n.TEXTURE_WRAP_S,Q[_.wrapS]),n.texParameteri(v,n.TEXTURE_WRAP_T,Q[_.wrapT]),(v===n.TEXTURE_3D||v===n.TEXTURE_2D_ARRAY)&&n.texParameteri(v,n.TEXTURE_WRAP_R,Q[_.wrapR]),n.texParameteri(v,n.TEXTURE_MAG_FILTER,tt[_.magFilter]),n.texParameteri(v,n.TEXTURE_MIN_FILTER,tt[_.minFilter])):(n.texParameteri(v,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(v,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE),(v===n.TEXTURE_3D||v===n.TEXTURE_2D_ARRAY)&&n.texParameteri(v,n.TEXTURE_WRAP_R,n.CLAMP_TO_EDGE),(_.wrapS!==jn||_.wrapT!==jn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),n.texParameteri(v,n.TEXTURE_MAG_FILTER,w(_.magFilter)),n.texParameteri(v,n.TEXTURE_MIN_FILTER,w(_.minFilter)),_.minFilter!==sn&&_.minFilter!==Bn&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),_.compareFunction&&(n.texParameteri(v,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(v,n.TEXTURE_COMPARE_FUNC,ut[_.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){let G=t.get("EXT_texture_filter_anisotropic");if(_.magFilter===sn||_.minFilter!==Lc&&_.minFilter!==ta||_.type===Vi&&t.has("OES_texture_float_linear")===!1||o===!1&&_.type===ea&&t.has("OES_texture_half_float_linear")===!1)return;(_.anisotropy>1||i.get(_).__currentAnisotropy)&&(n.texParameterf(v,G.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,s.getMaxAnisotropy())),i.get(_).__currentAnisotropy=_.anisotropy)}}function it(v,_){let D=!1;v.__webglInit===void 0&&(v.__webglInit=!0,_.addEventListener("dispose",A));let G=_.source,Y=f.get(G);Y===void 0&&(Y={},f.set(G,Y));let j=N(_);if(j!==v.__cacheKey){Y[j]===void 0&&(Y[j]={texture:n.createTexture(),usedTimes:0},a.memory.textures++,D=!0),Y[j].usedTimes++;let Tt=Y[v.__cacheKey];Tt!==void 0&&(Y[v.__cacheKey].usedTimes--,Tt.usedTimes===0&&b(_)),v.__cacheKey=j,v.__webglTexture=Y[j].texture}return D}function dt(v,_,D){let G=n.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(G=n.TEXTURE_2D_ARRAY),_.isData3DTexture&&(G=n.TEXTURE_3D);let Y=it(v,_),j=_.source;e.bindTexture(G,v.__webglTexture,n.TEXTURE0+D);let Tt=i.get(j);if(j.version!==Tt.__version||Y===!0){e.activeTexture(n.TEXTURE0+D);let lt=Me.getPrimaries(Me.workingColorSpace),wt=_.colorSpace===Hn?null:Me.getPrimaries(_.colorSpace),zt=_.colorSpace===Hn||lt===wt?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,zt);let qt=m(_)&&g(_.image)===!1,ot=x(_.image,qt,!1,s.maxTextureSize);ot=_t(_,ot);let ge=g(ot)||o,oe=r.convert(_.format,_.colorSpace),Zt=r.convert(_.type),kt=S(_.internalFormat,oe,Zt,_.colorSpace,_.isVideoTexture);J(G,_,ge);let Dt,Qt=_.mipmaps,_e=o&&_.isVideoTexture!==!0&&kt!==sd,ze=Tt.__version===void 0||Y===!0,se=P(_,ot,ge);if(_.isDepthTexture)kt=n.DEPTH_COMPONENT,o?_.type===Vi?kt=n.DEPTH_COMPONENT32F:_.type===Gi?kt=n.DEPTH_COMPONENT24:_.type===ps?kt=n.DEPTH24_STENCIL8:kt=n.DEPTH_COMPONENT16:_.type===Vi&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),_.format===ms&&kt===n.DEPTH_COMPONENT&&_.type!==oh&&_.type!==Gi&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),_.type=Gi,Zt=r.convert(_.type)),_.format===ur&&kt===n.DEPTH_COMPONENT&&(kt=n.DEPTH_STENCIL,_.type!==ps&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),_.type=ps,Zt=r.convert(_.type))),ze&&(_e?e.texStorage2D(n.TEXTURE_2D,1,kt,ot.width,ot.height):e.texImage2D(n.TEXTURE_2D,0,kt,ot.width,ot.height,0,oe,Zt,null));else if(_.isDataTexture)if(Qt.length>0&&ge){_e&&ze&&e.texStorage2D(n.TEXTURE_2D,se,kt,Qt[0].width,Qt[0].height);for(let pt=0,U=Qt.length;pt<U;pt++)Dt=Qt[pt],_e?e.texSubImage2D(n.TEXTURE_2D,pt,0,0,Dt.width,Dt.height,oe,Zt,Dt.data):e.texImage2D(n.TEXTURE_2D,pt,kt,Dt.width,Dt.height,0,oe,Zt,Dt.data);_.generateMipmaps=!1}else _e?(ze&&e.texStorage2D(n.TEXTURE_2D,se,kt,ot.width,ot.height),e.texSubImage2D(n.TEXTURE_2D,0,0,0,ot.width,ot.height,oe,Zt,ot.data)):e.texImage2D(n.TEXTURE_2D,0,kt,ot.width,ot.height,0,oe,Zt,ot.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){_e&&ze&&e.texStorage3D(n.TEXTURE_2D_ARRAY,se,kt,Qt[0].width,Qt[0].height,ot.depth);for(let pt=0,U=Qt.length;pt<U;pt++)Dt=Qt[pt],_.format!==Qn?oe!==null?_e?e.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,pt,0,0,0,Dt.width,Dt.height,ot.depth,oe,Dt.data,0,0):e.compressedTexImage3D(n.TEXTURE_2D_ARRAY,pt,kt,Dt.width,Dt.height,ot.depth,0,Dt.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):_e?e.texSubImage3D(n.TEXTURE_2D_ARRAY,pt,0,0,0,Dt.width,Dt.height,ot.depth,oe,Zt,Dt.data):e.texImage3D(n.TEXTURE_2D_ARRAY,pt,kt,Dt.width,Dt.height,ot.depth,0,oe,Zt,Dt.data)}else{_e&&ze&&e.texStorage2D(n.TEXTURE_2D,se,kt,Qt[0].width,Qt[0].height);for(let pt=0,U=Qt.length;pt<U;pt++)Dt=Qt[pt],_.format!==Qn?oe!==null?_e?e.compressedTexSubImage2D(n.TEXTURE_2D,pt,0,0,Dt.width,Dt.height,oe,Dt.data):e.compressedTexImage2D(n.TEXTURE_2D,pt,kt,Dt.width,Dt.height,0,Dt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):_e?e.texSubImage2D(n.TEXTURE_2D,pt,0,0,Dt.width,Dt.height,oe,Zt,Dt.data):e.texImage2D(n.TEXTURE_2D,pt,kt,Dt.width,Dt.height,0,oe,Zt,Dt.data)}else if(_.isDataArrayTexture)_e?(ze&&e.texStorage3D(n.TEXTURE_2D_ARRAY,se,kt,ot.width,ot.height,ot.depth),e.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,ot.width,ot.height,ot.depth,oe,Zt,ot.data)):e.texImage3D(n.TEXTURE_2D_ARRAY,0,kt,ot.width,ot.height,ot.depth,0,oe,Zt,ot.data);else if(_.isData3DTexture)_e?(ze&&e.texStorage3D(n.TEXTURE_3D,se,kt,ot.width,ot.height,ot.depth),e.texSubImage3D(n.TEXTURE_3D,0,0,0,0,ot.width,ot.height,ot.depth,oe,Zt,ot.data)):e.texImage3D(n.TEXTURE_3D,0,kt,ot.width,ot.height,ot.depth,0,oe,Zt,ot.data);else if(_.isFramebufferTexture){if(ze)if(_e)e.texStorage2D(n.TEXTURE_2D,se,kt,ot.width,ot.height);else{let pt=ot.width,U=ot.height;for(let Mt=0;Mt<se;Mt++)e.texImage2D(n.TEXTURE_2D,Mt,kt,pt,U,0,oe,Zt,null),pt>>=1,U>>=1}}else if(Qt.length>0&&ge){_e&&ze&&e.texStorage2D(n.TEXTURE_2D,se,kt,Qt[0].width,Qt[0].height);for(let pt=0,U=Qt.length;pt<U;pt++)Dt=Qt[pt],_e?e.texSubImage2D(n.TEXTURE_2D,pt,0,0,oe,Zt,Dt):e.texImage2D(n.TEXTURE_2D,pt,kt,oe,Zt,Dt);_.generateMipmaps=!1}else _e?(ze&&e.texStorage2D(n.TEXTURE_2D,se,kt,ot.width,ot.height),e.texSubImage2D(n.TEXTURE_2D,0,0,0,oe,Zt,ot)):e.texImage2D(n.TEXTURE_2D,0,kt,oe,Zt,ot);E(_,ge)&&y(G),Tt.__version=j.version,_.onUpdate&&_.onUpdate(_)}v.__version=_.version}function It(v,_,D){if(_.image.length!==6)return;let G=it(v,_),Y=_.source;e.bindTexture(n.TEXTURE_CUBE_MAP,v.__webglTexture,n.TEXTURE0+D);let j=i.get(Y);if(Y.version!==j.__version||G===!0){e.activeTexture(n.TEXTURE0+D);let Tt=Me.getPrimaries(Me.workingColorSpace),lt=_.colorSpace===Hn?null:Me.getPrimaries(_.colorSpace),wt=_.colorSpace===Hn||Tt===lt?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,wt);let zt=_.isCompressedTexture||_.image[0].isCompressedTexture,qt=_.image[0]&&_.image[0].isDataTexture,ot=[];for(let pt=0;pt<6;pt++)!zt&&!qt?ot[pt]=x(_.image[pt],!1,!0,s.maxCubemapSize):ot[pt]=qt?_.image[pt].image:_.image[pt],ot[pt]=_t(_,ot[pt]);let ge=ot[0],oe=g(ge)||o,Zt=r.convert(_.format,_.colorSpace),kt=r.convert(_.type),Dt=S(_.internalFormat,Zt,kt,_.colorSpace),Qt=o&&_.isVideoTexture!==!0,_e=j.__version===void 0||G===!0,ze=P(_,ge,oe);J(n.TEXTURE_CUBE_MAP,_,oe);let se;if(zt){Qt&&_e&&e.texStorage2D(n.TEXTURE_CUBE_MAP,ze,Dt,ge.width,ge.height);for(let pt=0;pt<6;pt++){se=ot[pt].mipmaps;for(let U=0;U<se.length;U++){let Mt=se[U];_.format!==Qn?Zt!==null?Qt?e.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,U,0,0,Mt.width,Mt.height,Zt,Mt.data):e.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,U,Dt,Mt.width,Mt.height,0,Mt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Qt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,U,0,0,Mt.width,Mt.height,Zt,kt,Mt.data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,U,Dt,Mt.width,Mt.height,0,Zt,kt,Mt.data)}}}else{se=_.mipmaps,Qt&&_e&&(se.length>0&&ze++,e.texStorage2D(n.TEXTURE_CUBE_MAP,ze,Dt,ot[0].width,ot[0].height));for(let pt=0;pt<6;pt++)if(qt){Qt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,0,0,0,ot[pt].width,ot[pt].height,Zt,kt,ot[pt].data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,0,Dt,ot[pt].width,ot[pt].height,0,Zt,kt,ot[pt].data);for(let U=0;U<se.length;U++){let Et=se[U].image[pt].image;Qt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,U+1,0,0,Et.width,Et.height,Zt,kt,Et.data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,U+1,Dt,Et.width,Et.height,0,Zt,kt,Et.data)}}else{Qt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,0,0,0,Zt,kt,ot[pt]):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,0,Dt,Zt,kt,ot[pt]);for(let U=0;U<se.length;U++){let Mt=se[U];Qt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,U+1,0,0,Zt,kt,Mt.image[pt]):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+pt,U+1,Dt,Zt,kt,Mt.image[pt])}}}E(_,oe)&&y(n.TEXTURE_CUBE_MAP),j.__version=Y.version,_.onUpdate&&_.onUpdate(_)}v.__version=_.version}function St(v,_,D,G,Y,j){let Tt=r.convert(D.format,D.colorSpace),lt=r.convert(D.type),wt=S(D.internalFormat,Tt,lt,D.colorSpace);if(!i.get(_).__hasExternalTextures){let qt=Math.max(1,_.width>>j),ot=Math.max(1,_.height>>j);Y===n.TEXTURE_3D||Y===n.TEXTURE_2D_ARRAY?e.texImage3D(Y,j,wt,qt,ot,_.depth,0,Tt,lt,null):e.texImage2D(Y,j,wt,qt,ot,0,Tt,lt,null)}e.bindFramebuffer(n.FRAMEBUFFER,v),K(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,G,Y,i.get(D).__webglTexture,0,et(_)):(Y===n.TEXTURE_2D||Y>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&Y<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,G,Y,i.get(D).__webglTexture,j),e.bindFramebuffer(n.FRAMEBUFFER,null)}function Ht(v,_,D){if(n.bindRenderbuffer(n.RENDERBUFFER,v),_.depthBuffer&&!_.stencilBuffer){let G=o===!0?n.DEPTH_COMPONENT24:n.DEPTH_COMPONENT16;if(D||K(_)){let Y=_.depthTexture;Y&&Y.isDepthTexture&&(Y.type===Vi?G=n.DEPTH_COMPONENT32F:Y.type===Gi&&(G=n.DEPTH_COMPONENT24));let j=et(_);K(_)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,j,G,_.width,_.height):n.renderbufferStorageMultisample(n.RENDERBUFFER,j,G,_.width,_.height)}else n.renderbufferStorage(n.RENDERBUFFER,G,_.width,_.height);n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.RENDERBUFFER,v)}else if(_.depthBuffer&&_.stencilBuffer){let G=et(_);D&&K(_)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,G,n.DEPTH24_STENCIL8,_.width,_.height):K(_)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,G,n.DEPTH24_STENCIL8,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,n.DEPTH_STENCIL,_.width,_.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.RENDERBUFFER,v)}else{let G=_.isWebGLMultipleRenderTargets===!0?_.texture:[_.texture];for(let Y=0;Y<G.length;Y++){let j=G[Y],Tt=r.convert(j.format,j.colorSpace),lt=r.convert(j.type),wt=S(j.internalFormat,Tt,lt,j.colorSpace),zt=et(_);D&&K(_)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,zt,wt,_.width,_.height):K(_)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,zt,wt,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,wt,_.width,_.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function st(v,_){if(_&&_.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(n.FRAMEBUFFER,v),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!i.get(_.depthTexture).__webglTexture||_.depthTexture.image.width!==_.width||_.depthTexture.image.height!==_.height)&&(_.depthTexture.image.width=_.width,_.depthTexture.image.height=_.height,_.depthTexture.needsUpdate=!0),H(_.depthTexture,0);let G=i.get(_.depthTexture).__webglTexture,Y=et(_);if(_.depthTexture.format===ms)K(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,G,0,Y):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,G,0);else if(_.depthTexture.format===ur)K(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,G,0,Y):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,G,0);else throw new Error("Unknown depthTexture format")}function ct(v){let _=i.get(v),D=v.isWebGLCubeRenderTarget===!0;if(v.depthTexture&&!_.__autoAllocateDepthBuffer){if(D)throw new Error("target.depthTexture not supported in Cube render targets");st(_.__webglFramebuffer,v)}else if(D){_.__webglDepthbuffer=[];for(let G=0;G<6;G++)e.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer[G]),_.__webglDepthbuffer[G]=n.createRenderbuffer(),Ht(_.__webglDepthbuffer[G],v,!1)}else e.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer=n.createRenderbuffer(),Ht(_.__webglDepthbuffer,v,!1);e.bindFramebuffer(n.FRAMEBUFFER,null)}function xt(v,_,D){let G=i.get(v);_!==void 0&&St(G.__webglFramebuffer,v,v.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),D!==void 0&&ct(v)}function C(v){let _=v.texture,D=i.get(v),G=i.get(_);v.addEventListener("dispose",F),v.isWebGLMultipleRenderTargets!==!0&&(G.__webglTexture===void 0&&(G.__webglTexture=n.createTexture()),G.__version=_.version,a.memory.textures++);let Y=v.isWebGLCubeRenderTarget===!0,j=v.isWebGLMultipleRenderTargets===!0,Tt=g(v)||o;if(Y){D.__webglFramebuffer=[];for(let lt=0;lt<6;lt++)if(o&&_.mipmaps&&_.mipmaps.length>0){D.__webglFramebuffer[lt]=[];for(let wt=0;wt<_.mipmaps.length;wt++)D.__webglFramebuffer[lt][wt]=n.createFramebuffer()}else D.__webglFramebuffer[lt]=n.createFramebuffer()}else{if(o&&_.mipmaps&&_.mipmaps.length>0){D.__webglFramebuffer=[];for(let lt=0;lt<_.mipmaps.length;lt++)D.__webglFramebuffer[lt]=n.createFramebuffer()}else D.__webglFramebuffer=n.createFramebuffer();if(j)if(s.drawBuffers){let lt=v.texture;for(let wt=0,zt=lt.length;wt<zt;wt++){let qt=i.get(lt[wt]);qt.__webglTexture===void 0&&(qt.__webglTexture=n.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&v.samples>0&&K(v)===!1){let lt=j?_:[_];D.__webglMultisampledFramebuffer=n.createFramebuffer(),D.__webglColorRenderbuffer=[],e.bindFramebuffer(n.FRAMEBUFFER,D.__webglMultisampledFramebuffer);for(let wt=0;wt<lt.length;wt++){let zt=lt[wt];D.__webglColorRenderbuffer[wt]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,D.__webglColorRenderbuffer[wt]);let qt=r.convert(zt.format,zt.colorSpace),ot=r.convert(zt.type),ge=S(zt.internalFormat,qt,ot,zt.colorSpace,v.isXRRenderTarget===!0),oe=et(v);n.renderbufferStorageMultisample(n.RENDERBUFFER,oe,ge,v.width,v.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+wt,n.RENDERBUFFER,D.__webglColorRenderbuffer[wt])}n.bindRenderbuffer(n.RENDERBUFFER,null),v.depthBuffer&&(D.__webglDepthRenderbuffer=n.createRenderbuffer(),Ht(D.__webglDepthRenderbuffer,v,!0)),e.bindFramebuffer(n.FRAMEBUFFER,null)}}if(Y){e.bindTexture(n.TEXTURE_CUBE_MAP,G.__webglTexture),J(n.TEXTURE_CUBE_MAP,_,Tt);for(let lt=0;lt<6;lt++)if(o&&_.mipmaps&&_.mipmaps.length>0)for(let wt=0;wt<_.mipmaps.length;wt++)St(D.__webglFramebuffer[lt][wt],v,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+lt,wt);else St(D.__webglFramebuffer[lt],v,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+lt,0);E(_,Tt)&&y(n.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(j){let lt=v.texture;for(let wt=0,zt=lt.length;wt<zt;wt++){let qt=lt[wt],ot=i.get(qt);e.bindTexture(n.TEXTURE_2D,ot.__webglTexture),J(n.TEXTURE_2D,qt,Tt),St(D.__webglFramebuffer,v,qt,n.COLOR_ATTACHMENT0+wt,n.TEXTURE_2D,0),E(qt,Tt)&&y(n.TEXTURE_2D)}e.unbindTexture()}else{let lt=n.TEXTURE_2D;if((v.isWebGL3DRenderTarget||v.isWebGLArrayRenderTarget)&&(o?lt=v.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(lt,G.__webglTexture),J(lt,_,Tt),o&&_.mipmaps&&_.mipmaps.length>0)for(let wt=0;wt<_.mipmaps.length;wt++)St(D.__webglFramebuffer[wt],v,_,n.COLOR_ATTACHMENT0,lt,wt);else St(D.__webglFramebuffer,v,_,n.COLOR_ATTACHMENT0,lt,0);E(_,Tt)&&y(lt),e.unbindTexture()}v.depthBuffer&&ct(v)}function rt(v){let _=g(v)||o,D=v.isWebGLMultipleRenderTargets===!0?v.texture:[v.texture];for(let G=0,Y=D.length;G<Y;G++){let j=D[G];if(E(j,_)){let Tt=v.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:n.TEXTURE_2D,lt=i.get(j).__webglTexture;e.bindTexture(Tt,lt),y(Tt),e.unbindTexture()}}}function q(v){if(o&&v.samples>0&&K(v)===!1){let _=v.isWebGLMultipleRenderTargets?v.texture:[v.texture],D=v.width,G=v.height,Y=n.COLOR_BUFFER_BIT,j=[],Tt=v.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,lt=i.get(v),wt=v.isWebGLMultipleRenderTargets===!0;if(wt)for(let zt=0;zt<_.length;zt++)e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+zt,n.RENDERBUFFER,null),e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+zt,n.TEXTURE_2D,null,0);e.bindFramebuffer(n.READ_FRAMEBUFFER,lt.__webglMultisampledFramebuffer),e.bindFramebuffer(n.DRAW_FRAMEBUFFER,lt.__webglFramebuffer);for(let zt=0;zt<_.length;zt++){j.push(n.COLOR_ATTACHMENT0+zt),v.depthBuffer&&j.push(Tt);let qt=lt.__ignoreDepthValues!==void 0?lt.__ignoreDepthValues:!1;if(qt===!1&&(v.depthBuffer&&(Y|=n.DEPTH_BUFFER_BIT),v.stencilBuffer&&(Y|=n.STENCIL_BUFFER_BIT)),wt&&n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,lt.__webglColorRenderbuffer[zt]),qt===!0&&(n.invalidateFramebuffer(n.READ_FRAMEBUFFER,[Tt]),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[Tt])),wt){let ot=i.get(_[zt]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,ot,0)}n.blitFramebuffer(0,0,D,G,0,0,D,G,Y,n.NEAREST),l&&n.invalidateFramebuffer(n.READ_FRAMEBUFFER,j)}if(e.bindFramebuffer(n.READ_FRAMEBUFFER,null),e.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),wt)for(let zt=0;zt<_.length;zt++){e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+zt,n.RENDERBUFFER,lt.__webglColorRenderbuffer[zt]);let qt=i.get(_[zt]).__webglTexture;e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+zt,n.TEXTURE_2D,qt,0)}e.bindFramebuffer(n.DRAW_FRAMEBUFFER,lt.__webglMultisampledFramebuffer)}}function et(v){return Math.min(s.maxSamples,v.samples)}function K(v){let _=i.get(v);return o&&v.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function Pt(v){let _=a.render.frame;h.get(v)!==_&&(h.set(v,_),v.update())}function _t(v,_){let D=v.colorSpace,G=v.format,Y=v.type;return v.isCompressedTexture===!0||v.isVideoTexture===!0||v.format===yl||D!==Ti&&D!==Hn&&(Me.getTransfer(D)===Pe?o===!1?t.has("EXT_sRGB")===!0&&G===Qn?(v.format=yl,v.minFilter=Bn,v.generateMipmaps=!1):_=To.sRGBToLinear(_):(G!==Qn||Y!==$i)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",D)),_}this.allocateTextureUnit=I,this.resetTextureUnits=Z,this.setTexture2D=H,this.setTexture2DArray=nt,this.setTexture3D=B,this.setTextureCube=W,this.rebindTextures=xt,this.setupRenderTarget=C,this.updateRenderTargetMipmap=rt,this.updateMultisampleRenderTarget=q,this.setupDepthRenderbuffer=ct,this.setupFrameBufferTexture=St,this.useMultisampledRTT=K}function w_(n,t,e){let i=e.isWebGL2;function s(r,a=Hn){let o,c=Me.getTransfer(a);if(r===$i)return n.UNSIGNED_BYTE;if(r===Qf)return n.UNSIGNED_SHORT_4_4_4_4;if(r===td)return n.UNSIGNED_SHORT_5_5_5_1;if(r===a0)return n.BYTE;if(r===o0)return n.SHORT;if(r===oh)return n.UNSIGNED_SHORT;if(r===jf)return n.INT;if(r===Gi)return n.UNSIGNED_INT;if(r===Vi)return n.FLOAT;if(r===ea)return i?n.HALF_FLOAT:(o=t.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(r===c0)return n.ALPHA;if(r===Qn)return n.RGBA;if(r===l0)return n.LUMINANCE;if(r===h0)return n.LUMINANCE_ALPHA;if(r===ms)return n.DEPTH_COMPONENT;if(r===ur)return n.DEPTH_STENCIL;if(r===yl)return o=t.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(r===u0)return n.RED;if(r===ed)return n.RED_INTEGER;if(r===f0)return n.RG;if(r===nd)return n.RG_INTEGER;if(r===id)return n.RGBA_INTEGER;if(r===Dc||r===Uc||r===Oc||r===Nc)if(c===Pe)if(o=t.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(r===Dc)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===Uc)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===Oc)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===Nc)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=t.get("WEBGL_compressed_texture_s3tc"),o!==null){if(r===Dc)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===Uc)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===Oc)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===Nc)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===vu||r===Mu||r===Eu||r===Su)if(o=t.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(r===vu)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===Mu)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===Eu)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===Su)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===sd)return o=t.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===bu||r===Tu)if(o=t.get("WEBGL_compressed_texture_etc"),o!==null){if(r===bu)return c===Pe?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(r===Tu)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===wu||r===Au||r===Ru||r===Cu||r===Pu||r===Iu||r===Lu||r===Du||r===Uu||r===Ou||r===Nu||r===Fu||r===zu||r===Bu)if(o=t.get("WEBGL_compressed_texture_astc"),o!==null){if(r===wu)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===Au)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Ru)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===Cu)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Pu)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===Iu)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===Lu)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Du)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===Uu)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Ou)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===Nu)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Fu)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===zu)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===Bu)return c===Pe?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===Fc||r===Hu||r===ku)if(o=t.get("EXT_texture_compression_bptc"),o!==null){if(r===Fc)return c===Pe?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===Hu)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===ku)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===d0||r===Gu||r===Vu||r===Wu)if(o=t.get("EXT_texture_compression_rgtc"),o!==null){if(r===Fc)return o.COMPRESSED_RED_RGTC1_EXT;if(r===Gu)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===Vu)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===Wu)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===ps?i?n.UNSIGNED_INT_24_8:(o=t.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):n[r]!==void 0?n[r]:null}return{convert:s}}var Ll=class extends vn{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},vt=class extends Ze{constructor(){super(),this.isGroup=!0,this.type="Group"}},A_={type:"move"},Zr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new vt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new vt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new L,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new L),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new vt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new L,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new L),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let i of t.hand.values())this._getHandJoint(e,i)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,i){let s=null,r=null,a=null,o=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){a=!0;for(let x of t.hand.values()){let g=e.getJointPose(x,i),m=this._getHandJoint(l,x);g!==null&&(m.matrix.fromArray(g.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,m.jointRadius=g.radius),m.visible=g!==null}let h=l.joints["index-finger-tip"],u=l.joints["thumb-tip"],f=h.position.distanceTo(u.position),d=.02,p=.005;l.inputState.pinching&&f>d+p?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&f<=d-p&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,i),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));o!==null&&(s=e.getPose(t.targetRaySpace,i),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(A_)))}return o!==null&&(o.visible=s!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let i=new vt;i.matrixAutoUpdate=!1,i.visible=!1,t.joints[e.jointName]=i,t.add(i)}return t.joints[e.jointName]}},Dl=class extends Ji{constructor(t,e){super();let i=this,s=null,r=1,a=null,o="local-floor",c=1,l=null,h=null,u=null,f=null,d=null,p=null,x=e.getContextAttributes(),g=null,m=null,E=[],y=[],S=new ht,P=null,w=new vn;w.layers.enable(1),w.viewport=new We;let A=new vn;A.layers.enable(2),A.viewport=new We;let F=[w,A],M=new Ll;M.layers.enable(1),M.layers.enable(2);let b=null,R=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(J){let it=E[J];return it===void 0&&(it=new Zr,E[J]=it),it.getTargetRaySpace()},this.getControllerGrip=function(J){let it=E[J];return it===void 0&&(it=new Zr,E[J]=it),it.getGripSpace()},this.getHand=function(J){let it=E[J];return it===void 0&&(it=new Zr,E[J]=it),it.getHandSpace()};function O(J){let it=y.indexOf(J.inputSource);if(it===-1)return;let dt=E[it];dt!==void 0&&(dt.update(J.inputSource,J.frame,l||a),dt.dispatchEvent({type:J.type,data:J.inputSource}))}function Z(){s.removeEventListener("select",O),s.removeEventListener("selectstart",O),s.removeEventListener("selectend",O),s.removeEventListener("squeeze",O),s.removeEventListener("squeezestart",O),s.removeEventListener("squeezeend",O),s.removeEventListener("end",Z),s.removeEventListener("inputsourceschange",I);for(let J=0;J<E.length;J++){let it=y[J];it!==null&&(y[J]=null,E[J].disconnect(it))}b=null,R=null,t.setRenderTarget(g),d=null,f=null,u=null,s=null,m=null,ut.stop(),i.isPresenting=!1,t.setPixelRatio(P),t.setSize(S.width,S.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(J){r=J,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(J){o=J,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(J){l=J},this.getBaseLayer=function(){return f!==null?f:d},this.getBinding=function(){return u},this.getFrame=function(){return p},this.getSession=function(){return s},this.setSession=async function(J){if(s=J,s!==null){if(g=t.getRenderTarget(),s.addEventListener("select",O),s.addEventListener("selectstart",O),s.addEventListener("selectend",O),s.addEventListener("squeeze",O),s.addEventListener("squeezestart",O),s.addEventListener("squeezeend",O),s.addEventListener("end",Z),s.addEventListener("inputsourceschange",I),x.xrCompatible!==!0&&await e.makeXRCompatible(),P=t.getPixelRatio(),t.getSize(S),s.renderState.layers===void 0||t.capabilities.isWebGL2===!1){let it={antialias:s.renderState.layers===void 0?x.antialias:!0,alpha:!0,depth:x.depth,stencil:x.stencil,framebufferScaleFactor:r};d=new XRWebGLLayer(s,e,it),s.updateRenderState({baseLayer:d}),t.setPixelRatio(1),t.setSize(d.framebufferWidth,d.framebufferHeight,!1),m=new wi(d.framebufferWidth,d.framebufferHeight,{format:Qn,type:$i,colorSpace:t.outputColorSpace,stencilBuffer:x.stencil})}else{let it=null,dt=null,It=null;x.depth&&(It=x.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,it=x.stencil?ur:ms,dt=x.stencil?ps:Gi);let St={colorFormat:e.RGBA8,depthFormat:It,scaleFactor:r};u=new XRWebGLBinding(s,e),f=u.createProjectionLayer(St),s.updateRenderState({layers:[f]}),t.setPixelRatio(1),t.setSize(f.textureWidth,f.textureHeight,!1),m=new wi(f.textureWidth,f.textureHeight,{format:Qn,type:$i,depthTexture:new Do(f.textureWidth,f.textureHeight,dt,void 0,void 0,void 0,void 0,void 0,void 0,it),stencilBuffer:x.stencil,colorSpace:t.outputColorSpace,samples:x.antialias?4:0});let Ht=t.properties.get(m);Ht.__ignoreDepthValues=f.ignoreDepthValues}m.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await s.requestReferenceSpace(o),ut.setContext(s),ut.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode};function I(J){for(let it=0;it<J.removed.length;it++){let dt=J.removed[it],It=y.indexOf(dt);It>=0&&(y[It]=null,E[It].disconnect(dt))}for(let it=0;it<J.added.length;it++){let dt=J.added[it],It=y.indexOf(dt);if(It===-1){for(let Ht=0;Ht<E.length;Ht++)if(Ht>=y.length){y.push(dt),It=Ht;break}else if(y[Ht]===null){y[Ht]=dt,It=Ht;break}if(It===-1)break}let St=E[It];St&&St.connect(dt)}}let N=new L,H=new L;function nt(J,it,dt){N.setFromMatrixPosition(it.matrixWorld),H.setFromMatrixPosition(dt.matrixWorld);let It=N.distanceTo(H),St=it.projectionMatrix.elements,Ht=dt.projectionMatrix.elements,st=St[14]/(St[10]-1),ct=St[14]/(St[10]+1),xt=(St[9]+1)/St[5],C=(St[9]-1)/St[5],rt=(St[8]-1)/St[0],q=(Ht[8]+1)/Ht[0],et=st*rt,K=st*q,Pt=It/(-rt+q),_t=Pt*-rt;it.matrixWorld.decompose(J.position,J.quaternion,J.scale),J.translateX(_t),J.translateZ(Pt),J.matrixWorld.compose(J.position,J.quaternion,J.scale),J.matrixWorldInverse.copy(J.matrixWorld).invert();let v=st+Pt,_=ct+Pt,D=et-_t,G=K+(It-_t),Y=xt*ct/_*v,j=C*ct/_*v;J.projectionMatrix.makePerspective(D,G,Y,j,v,_),J.projectionMatrixInverse.copy(J.projectionMatrix).invert()}function B(J,it){it===null?J.matrixWorld.copy(J.matrix):J.matrixWorld.multiplyMatrices(it.matrixWorld,J.matrix),J.matrixWorldInverse.copy(J.matrixWorld).invert()}this.updateCamera=function(J){if(s===null)return;M.near=A.near=w.near=J.near,M.far=A.far=w.far=J.far,(b!==M.near||R!==M.far)&&(s.updateRenderState({depthNear:M.near,depthFar:M.far}),b=M.near,R=M.far);let it=J.parent,dt=M.cameras;B(M,it);for(let It=0;It<dt.length;It++)B(dt[It],it);dt.length===2?nt(M,w,A):M.projectionMatrix.copy(w.projectionMatrix),W(J,M,it)};function W(J,it,dt){dt===null?J.matrix.copy(it.matrixWorld):(J.matrix.copy(dt.matrixWorld),J.matrix.invert(),J.matrix.multiply(it.matrixWorld)),J.matrix.decompose(J.position,J.quaternion,J.scale),J.updateMatrixWorld(!0),J.projectionMatrix.copy(it.projectionMatrix),J.projectionMatrixInverse.copy(it.projectionMatrixInverse),J.isPerspectiveCamera&&(J.fov=na*2*Math.atan(1/J.projectionMatrix.elements[5]),J.zoom=1)}this.getCamera=function(){return M},this.getFoveation=function(){if(!(f===null&&d===null))return c},this.setFoveation=function(J){c=J,f!==null&&(f.fixedFoveation=J),d!==null&&d.fixedFoveation!==void 0&&(d.fixedFoveation=J)};let Q=null;function tt(J,it){if(h=it.getViewerPose(l||a),p=it,h!==null){let dt=h.views;d!==null&&(t.setRenderTargetFramebuffer(m,d.framebuffer),t.setRenderTarget(m));let It=!1;dt.length!==M.cameras.length&&(M.cameras.length=0,It=!0);for(let St=0;St<dt.length;St++){let Ht=dt[St],st=null;if(d!==null)st=d.getViewport(Ht);else{let xt=u.getViewSubImage(f,Ht);st=xt.viewport,St===0&&(t.setRenderTargetTextures(m,xt.colorTexture,f.ignoreDepthValues?void 0:xt.depthStencilTexture),t.setRenderTarget(m))}let ct=F[St];ct===void 0&&(ct=new vn,ct.layers.enable(St),ct.viewport=new We,F[St]=ct),ct.matrix.fromArray(Ht.transform.matrix),ct.matrix.decompose(ct.position,ct.quaternion,ct.scale),ct.projectionMatrix.fromArray(Ht.projectionMatrix),ct.projectionMatrixInverse.copy(ct.projectionMatrix).invert(),ct.viewport.set(st.x,st.y,st.width,st.height),St===0&&(M.matrix.copy(ct.matrix),M.matrix.decompose(M.position,M.quaternion,M.scale)),It===!0&&M.cameras.push(ct)}}for(let dt=0;dt<E.length;dt++){let It=y[dt],St=E[dt];It!==null&&St!==void 0&&St.update(It,it,l||a)}Q&&Q(J,it),it.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:it}),p=null}let ut=new dd;ut.setAnimationLoop(tt),this.setAnimationLoop=function(J){Q=J},this.dispose=function(){}}};function R_(n,t){function e(g,m){g.matrixAutoUpdate===!0&&g.updateMatrix(),m.value.copy(g.matrix)}function i(g,m){m.color.getRGB(g.fogColor.value,fd(n)),m.isFog?(g.fogNear.value=m.near,g.fogFar.value=m.far):m.isFogExp2&&(g.fogDensity.value=m.density)}function s(g,m,E,y,S){m.isMeshBasicMaterial||m.isMeshLambertMaterial?r(g,m):m.isMeshToonMaterial?(r(g,m),u(g,m)):m.isMeshPhongMaterial?(r(g,m),h(g,m)):m.isMeshStandardMaterial?(r(g,m),f(g,m),m.isMeshPhysicalMaterial&&d(g,m,S)):m.isMeshMatcapMaterial?(r(g,m),p(g,m)):m.isMeshDepthMaterial?r(g,m):m.isMeshDistanceMaterial?(r(g,m),x(g,m)):m.isMeshNormalMaterial?r(g,m):m.isLineBasicMaterial?(a(g,m),m.isLineDashedMaterial&&o(g,m)):m.isPointsMaterial?c(g,m,E,y):m.isSpriteMaterial?l(g,m):m.isShadowMaterial?(g.color.value.copy(m.color),g.opacity.value=m.opacity):m.isShaderMaterial&&(m.uniformsNeedUpdate=!1)}function r(g,m){g.opacity.value=m.opacity,m.color&&g.diffuse.value.copy(m.color),m.emissive&&g.emissive.value.copy(m.emissive).multiplyScalar(m.emissiveIntensity),m.map&&(g.map.value=m.map,e(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.bumpMap&&(g.bumpMap.value=m.bumpMap,e(m.bumpMap,g.bumpMapTransform),g.bumpScale.value=m.bumpScale,m.side===dn&&(g.bumpScale.value*=-1)),m.normalMap&&(g.normalMap.value=m.normalMap,e(m.normalMap,g.normalMapTransform),g.normalScale.value.copy(m.normalScale),m.side===dn&&g.normalScale.value.negate()),m.displacementMap&&(g.displacementMap.value=m.displacementMap,e(m.displacementMap,g.displacementMapTransform),g.displacementScale.value=m.displacementScale,g.displacementBias.value=m.displacementBias),m.emissiveMap&&(g.emissiveMap.value=m.emissiveMap,e(m.emissiveMap,g.emissiveMapTransform)),m.specularMap&&(g.specularMap.value=m.specularMap,e(m.specularMap,g.specularMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest);let E=t.get(m).envMap;if(E&&(g.envMap.value=E,g.flipEnvMap.value=E.isCubeTexture&&E.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=m.reflectivity,g.ior.value=m.ior,g.refractionRatio.value=m.refractionRatio),m.lightMap){g.lightMap.value=m.lightMap;let y=n._useLegacyLights===!0?Math.PI:1;g.lightMapIntensity.value=m.lightMapIntensity*y,e(m.lightMap,g.lightMapTransform)}m.aoMap&&(g.aoMap.value=m.aoMap,g.aoMapIntensity.value=m.aoMapIntensity,e(m.aoMap,g.aoMapTransform))}function a(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,m.map&&(g.map.value=m.map,e(m.map,g.mapTransform))}function o(g,m){g.dashSize.value=m.dashSize,g.totalSize.value=m.dashSize+m.gapSize,g.scale.value=m.scale}function c(g,m,E,y){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.size.value=m.size*E,g.scale.value=y*.5,m.map&&(g.map.value=m.map,e(m.map,g.uvTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function l(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.rotation.value=m.rotation,m.map&&(g.map.value=m.map,e(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function h(g,m){g.specular.value.copy(m.specular),g.shininess.value=Math.max(m.shininess,1e-4)}function u(g,m){m.gradientMap&&(g.gradientMap.value=m.gradientMap)}function f(g,m){g.metalness.value=m.metalness,m.metalnessMap&&(g.metalnessMap.value=m.metalnessMap,e(m.metalnessMap,g.metalnessMapTransform)),g.roughness.value=m.roughness,m.roughnessMap&&(g.roughnessMap.value=m.roughnessMap,e(m.roughnessMap,g.roughnessMapTransform)),t.get(m).envMap&&(g.envMapIntensity.value=m.envMapIntensity)}function d(g,m,E){g.ior.value=m.ior,m.sheen>0&&(g.sheenColor.value.copy(m.sheenColor).multiplyScalar(m.sheen),g.sheenRoughness.value=m.sheenRoughness,m.sheenColorMap&&(g.sheenColorMap.value=m.sheenColorMap,e(m.sheenColorMap,g.sheenColorMapTransform)),m.sheenRoughnessMap&&(g.sheenRoughnessMap.value=m.sheenRoughnessMap,e(m.sheenRoughnessMap,g.sheenRoughnessMapTransform))),m.clearcoat>0&&(g.clearcoat.value=m.clearcoat,g.clearcoatRoughness.value=m.clearcoatRoughness,m.clearcoatMap&&(g.clearcoatMap.value=m.clearcoatMap,e(m.clearcoatMap,g.clearcoatMapTransform)),m.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=m.clearcoatRoughnessMap,e(m.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),m.clearcoatNormalMap&&(g.clearcoatNormalMap.value=m.clearcoatNormalMap,e(m.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(m.clearcoatNormalScale),m.side===dn&&g.clearcoatNormalScale.value.negate())),m.iridescence>0&&(g.iridescence.value=m.iridescence,g.iridescenceIOR.value=m.iridescenceIOR,g.iridescenceThicknessMinimum.value=m.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=m.iridescenceThicknessRange[1],m.iridescenceMap&&(g.iridescenceMap.value=m.iridescenceMap,e(m.iridescenceMap,g.iridescenceMapTransform)),m.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=m.iridescenceThicknessMap,e(m.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),m.transmission>0&&(g.transmission.value=m.transmission,g.transmissionSamplerMap.value=E.texture,g.transmissionSamplerSize.value.set(E.width,E.height),m.transmissionMap&&(g.transmissionMap.value=m.transmissionMap,e(m.transmissionMap,g.transmissionMapTransform)),g.thickness.value=m.thickness,m.thicknessMap&&(g.thicknessMap.value=m.thicknessMap,e(m.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=m.attenuationDistance,g.attenuationColor.value.copy(m.attenuationColor)),m.anisotropy>0&&(g.anisotropyVector.value.set(m.anisotropy*Math.cos(m.anisotropyRotation),m.anisotropy*Math.sin(m.anisotropyRotation)),m.anisotropyMap&&(g.anisotropyMap.value=m.anisotropyMap,e(m.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=m.specularIntensity,g.specularColor.value.copy(m.specularColor),m.specularColorMap&&(g.specularColorMap.value=m.specularColorMap,e(m.specularColorMap,g.specularColorMapTransform)),m.specularIntensityMap&&(g.specularIntensityMap.value=m.specularIntensityMap,e(m.specularIntensityMap,g.specularIntensityMapTransform))}function p(g,m){m.matcap&&(g.matcap.value=m.matcap)}function x(g,m){let E=t.get(m).light;g.referencePosition.value.setFromMatrixPosition(E.matrixWorld),g.nearDistance.value=E.shadow.camera.near,g.farDistance.value=E.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:s}}function C_(n,t,e,i){let s={},r={},a=[],o=e.isWebGL2?n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS):0;function c(E,y){let S=y.program;i.uniformBlockBinding(E,S)}function l(E,y){let S=s[E.id];S===void 0&&(p(E),S=h(E),s[E.id]=S,E.addEventListener("dispose",g));let P=y.program;i.updateUBOMapping(E,P);let w=t.render.frame;r[E.id]!==w&&(f(E),r[E.id]=w)}function h(E){let y=u();E.__bindingPointIndex=y;let S=n.createBuffer(),P=E.__size,w=E.usage;return n.bindBuffer(n.UNIFORM_BUFFER,S),n.bufferData(n.UNIFORM_BUFFER,P,w),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,y,S),S}function u(){for(let E=0;E<o;E++)if(a.indexOf(E)===-1)return a.push(E),E;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function f(E){let y=s[E.id],S=E.uniforms,P=E.__cache;n.bindBuffer(n.UNIFORM_BUFFER,y);for(let w=0,A=S.length;w<A;w++){let F=Array.isArray(S[w])?S[w]:[S[w]];for(let M=0,b=F.length;M<b;M++){let R=F[M];if(d(R,w,M,P)===!0){let O=R.__offset,Z=Array.isArray(R.value)?R.value:[R.value],I=0;for(let N=0;N<Z.length;N++){let H=Z[N],nt=x(H);typeof H=="number"||typeof H=="boolean"?(R.__data[0]=H,n.bufferSubData(n.UNIFORM_BUFFER,O+I,R.__data)):H.isMatrix3?(R.__data[0]=H.elements[0],R.__data[1]=H.elements[1],R.__data[2]=H.elements[2],R.__data[3]=0,R.__data[4]=H.elements[3],R.__data[5]=H.elements[4],R.__data[6]=H.elements[5],R.__data[7]=0,R.__data[8]=H.elements[6],R.__data[9]=H.elements[7],R.__data[10]=H.elements[8],R.__data[11]=0):(H.toArray(R.__data,I),I+=nt.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,O,R.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function d(E,y,S,P){let w=E.value,A=y+"_"+S;if(P[A]===void 0)return typeof w=="number"||typeof w=="boolean"?P[A]=w:P[A]=w.clone(),!0;{let F=P[A];if(typeof w=="number"||typeof w=="boolean"){if(F!==w)return P[A]=w,!0}else if(F.equals(w)===!1)return F.copy(w),!0}return!1}function p(E){let y=E.uniforms,S=0,P=16;for(let A=0,F=y.length;A<F;A++){let M=Array.isArray(y[A])?y[A]:[y[A]];for(let b=0,R=M.length;b<R;b++){let O=M[b],Z=Array.isArray(O.value)?O.value:[O.value];for(let I=0,N=Z.length;I<N;I++){let H=Z[I],nt=x(H),B=S%P;B!==0&&P-B<nt.boundary&&(S+=P-B),O.__data=new Float32Array(nt.storage/Float32Array.BYTES_PER_ELEMENT),O.__offset=S,S+=nt.storage}}}let w=S%P;return w>0&&(S+=P-w),E.__size=S,E.__cache={},this}function x(E){let y={boundary:0,storage:0};return typeof E=="number"||typeof E=="boolean"?(y.boundary=4,y.storage=4):E.isVector2?(y.boundary=8,y.storage=8):E.isVector3||E.isColor?(y.boundary=16,y.storage=12):E.isVector4?(y.boundary=16,y.storage=16):E.isMatrix3?(y.boundary=48,y.storage=48):E.isMatrix4?(y.boundary=64,y.storage=64):E.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",E),y}function g(E){let y=E.target;y.removeEventListener("dispose",g);let S=a.indexOf(y.__bindingPointIndex);a.splice(S,1),n.deleteBuffer(s[y.id]),delete s[y.id],delete r[y.id]}function m(){for(let E in s)n.deleteBuffer(s[E]);a=[],s={},r={}}return{bind:c,update:l,dispose:m}}var aa=class{constructor(t={}){let{canvas:e=z0(),context:i=null,depth:s=!0,stencil:r=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1}=t;this.isWebGLRenderer=!0;let f;i!==null?f=i.getContextAttributes().alpha:f=a;let d=new Uint32Array(4),p=new Int32Array(4),x=null,g=null,m=[],E=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=be,this._useLegacyLights=!1,this.toneMapping=Yi,this.toneMappingExposure=1;let y=this,S=!1,P=0,w=0,A=null,F=-1,M=null,b=new We,R=new We,O=null,Z=new Ft(0),I=0,N=e.width,H=e.height,nt=1,B=null,W=null,Q=new We(0,0,N,H),tt=new We(0,0,N,H),ut=!1,J=new ra,it=!1,dt=!1,It=null,St=new Ce,Ht=new ht,st=new L,ct={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function xt(){return A===null?nt:1}let C=i;function rt(T,z){for(let X=0;X<T.length;X++){let $=T[X],V=e.getContext($,z);if(V!==null)return V}return null}try{let T={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${sh}`),e.addEventListener("webglcontextlost",pt,!1),e.addEventListener("webglcontextrestored",U,!1),e.addEventListener("webglcontextcreationerror",Mt,!1),C===null){let z=["webgl2","webgl","experimental-webgl"];if(y.isWebGL1Renderer===!0&&z.shift(),C=rt(z,T),C===null)throw rt(z)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&C instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),C.getShaderPrecisionFormat===void 0&&(C.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(T){throw console.error("THREE.WebGLRenderer: "+T.message),T}let q,et,K,Pt,_t,v,_,D,G,Y,j,Tt,lt,wt,zt,qt,ot,ge,oe,Zt,kt,Dt,Qt,_e;function ze(){q=new qx(C),et=new Gx(C,q,t),q.init(et),Dt=new w_(C,q,et),K=new b_(C,q,et),Pt=new Kx(C),_t=new f_,v=new T_(C,q,K,_t,et,Dt,Pt),_=new Wx(y),D=new $x(y),G=new rm(C,et),Qt=new Hx(C,q,G,et),Y=new Zx(C,G,Pt,Qt),j=new ey(C,Y,G,Pt),oe=new ty(C,et,v),qt=new Vx(_t),Tt=new u_(y,_,D,q,et,Qt,qt),lt=new R_(y,_t),wt=new p_,zt=new v_(q,et),ge=new Bx(y,_,D,K,j,f,c),ot=new S_(y,j,et),_e=new C_(C,Pt,et,K),Zt=new kx(C,q,Pt,et),kt=new Jx(C,q,Pt,et),Pt.programs=Tt.programs,y.capabilities=et,y.extensions=q,y.properties=_t,y.renderLists=wt,y.shadowMap=ot,y.state=K,y.info=Pt}ze();let se=new Dl(y,C);this.xr=se,this.getContext=function(){return C},this.getContextAttributes=function(){return C.getContextAttributes()},this.forceContextLoss=function(){let T=q.get("WEBGL_lose_context");T&&T.loseContext()},this.forceContextRestore=function(){let T=q.get("WEBGL_lose_context");T&&T.restoreContext()},this.getPixelRatio=function(){return nt},this.setPixelRatio=function(T){T!==void 0&&(nt=T,this.setSize(N,H,!1))},this.getSize=function(T){return T.set(N,H)},this.setSize=function(T,z,X=!0){if(se.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}N=T,H=z,e.width=Math.floor(T*nt),e.height=Math.floor(z*nt),X===!0&&(e.style.width=T+"px",e.style.height=z+"px"),this.setViewport(0,0,T,z)},this.getDrawingBufferSize=function(T){return T.set(N*nt,H*nt).floor()},this.setDrawingBufferSize=function(T,z,X){N=T,H=z,nt=X,e.width=Math.floor(T*X),e.height=Math.floor(z*X),this.setViewport(0,0,T,z)},this.getCurrentViewport=function(T){return T.copy(b)},this.getViewport=function(T){return T.copy(Q)},this.setViewport=function(T,z,X,$){T.isVector4?Q.set(T.x,T.y,T.z,T.w):Q.set(T,z,X,$),K.viewport(b.copy(Q).multiplyScalar(nt).floor())},this.getScissor=function(T){return T.copy(tt)},this.setScissor=function(T,z,X,$){T.isVector4?tt.set(T.x,T.y,T.z,T.w):tt.set(T,z,X,$),K.scissor(R.copy(tt).multiplyScalar(nt).floor())},this.getScissorTest=function(){return ut},this.setScissorTest=function(T){K.setScissorTest(ut=T)},this.setOpaqueSort=function(T){B=T},this.setTransparentSort=function(T){W=T},this.getClearColor=function(T){return T.copy(ge.getClearColor())},this.setClearColor=function(){ge.setClearColor.apply(ge,arguments)},this.getClearAlpha=function(){return ge.getClearAlpha()},this.setClearAlpha=function(){ge.setClearAlpha.apply(ge,arguments)},this.clear=function(T=!0,z=!0,X=!0){let $=0;if(T){let V=!1;if(A!==null){let Rt=A.texture.format;V=Rt===id||Rt===nd||Rt===ed}if(V){let Rt=A.texture.type,Nt=Rt===$i||Rt===Gi||Rt===oh||Rt===ps||Rt===Qf||Rt===td,Wt=ge.getClearColor(),$t=ge.getClearAlpha(),ne=Wt.r,Jt=Wt.g,Kt=Wt.b;Nt?(d[0]=ne,d[1]=Jt,d[2]=Kt,d[3]=$t,C.clearBufferuiv(C.COLOR,0,d)):(p[0]=ne,p[1]=Jt,p[2]=Kt,p[3]=$t,C.clearBufferiv(C.COLOR,0,p))}else $|=C.COLOR_BUFFER_BIT}z&&($|=C.DEPTH_BUFFER_BIT),X&&($|=C.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),C.clear($)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",pt,!1),e.removeEventListener("webglcontextrestored",U,!1),e.removeEventListener("webglcontextcreationerror",Mt,!1),wt.dispose(),zt.dispose(),_t.dispose(),_.dispose(),D.dispose(),j.dispose(),Qt.dispose(),_e.dispose(),Tt.dispose(),se.dispose(),se.removeEventListener("sessionstart",gn),se.removeEventListener("sessionend",Re),It&&(It.dispose(),It=null),xn.stop()};function pt(T){T.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),S=!0}function U(){console.log("THREE.WebGLRenderer: Context Restored."),S=!1;let T=Pt.autoReset,z=ot.enabled,X=ot.autoUpdate,$=ot.needsUpdate,V=ot.type;ze(),Pt.autoReset=T,ot.enabled=z,ot.autoUpdate=X,ot.needsUpdate=$,ot.type=V}function Mt(T){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",T.statusMessage)}function Et(T){let z=T.target;z.removeEventListener("dispose",Et),Xt(z)}function Xt(T){Gt(T),_t.remove(T)}function Gt(T){let z=_t.get(T).programs;z!==void 0&&(z.forEach(function(X){Tt.releaseProgram(X)}),T.isShaderMaterial&&Tt.releaseShaderCache(T))}this.renderBufferDirect=function(T,z,X,$,V,Rt){z===null&&(z=ct);let Nt=V.isMesh&&V.matrixWorld.determinant()<0,Wt=Sp(T,z,X,$,V);K.setMaterial($,Nt);let $t=X.index,ne=1;if($.wireframe===!0){if($t=Y.getWireframeAttribute(X),$t===void 0)return;ne=2}let Jt=X.drawRange,Kt=X.attributes.position,Ve=Jt.start*ne,Cn=(Jt.start+Jt.count)*ne;Rt!==null&&(Ve=Math.max(Ve,Rt.start*ne),Cn=Math.min(Cn,(Rt.start+Rt.count)*ne)),$t!==null?(Ve=Math.max(Ve,0),Cn=Math.min(Cn,$t.count)):Kt!=null&&(Ve=Math.max(Ve,0),Cn=Math.min(Cn,Kt.count));let en=Cn-Ve;if(en<0||en===1/0)return;Qt.setup(V,$,Wt,X,$t);let gi,Ue=Zt;if($t!==null&&(gi=G.get($t),Ue=kt,Ue.setIndex(gi)),V.isMesh)$.wireframe===!0?(K.setLineWidth($.wireframeLinewidth*xt()),Ue.setMode(C.LINES)):Ue.setMode(C.TRIANGLES);else if(V.isLine){let re=$.linewidth;re===void 0&&(re=1),K.setLineWidth(re*xt()),V.isLineSegments?Ue.setMode(C.LINES):V.isLineLoop?Ue.setMode(C.LINE_LOOP):Ue.setMode(C.LINE_STRIP)}else V.isPoints?Ue.setMode(C.POINTS):V.isSprite&&Ue.setMode(C.TRIANGLES);if(V.isBatchedMesh)Ue.renderMultiDraw(V._multiDrawStarts,V._multiDrawCounts,V._multiDrawCount);else if(V.isInstancedMesh)Ue.renderInstances(Ve,en,V.count);else if(X.isInstancedBufferGeometry){let re=X._maxInstanceCount!==void 0?X._maxInstanceCount:1/0,Rc=Math.min(X.instanceCount,re);Ue.renderInstances(Ve,en,Rc)}else Ue.render(Ve,en)};function we(T,z,X){T.transparent===!0&&T.side===Oe&&T.forceSinglePass===!1?(T.side=dn,T.needsUpdate=!0,Na(T,z,X),T.side=qi,T.needsUpdate=!0,Na(T,z,X),T.side=Oe):Na(T,z,X)}this.compile=function(T,z,X=null){X===null&&(X=T),g=zt.get(X),g.init(),E.push(g),X.traverseVisible(function(V){V.isLight&&V.layers.test(z.layers)&&(g.pushLight(V),V.castShadow&&g.pushShadow(V))}),T!==X&&T.traverseVisible(function(V){V.isLight&&V.layers.test(z.layers)&&(g.pushLight(V),V.castShadow&&g.pushShadow(V))}),g.setupLights(y._useLegacyLights);let $=new Set;return T.traverse(function(V){let Rt=V.material;if(Rt)if(Array.isArray(Rt))for(let Nt=0;Nt<Rt.length;Nt++){let Wt=Rt[Nt];we(Wt,X,V),$.add(Wt)}else we(Rt,X,V),$.add(Rt)}),E.pop(),g=null,$},this.compileAsync=function(T,z,X=null){let $=this.compile(T,z,X);return new Promise(V=>{function Rt(){if($.forEach(function(Nt){_t.get(Nt).currentProgram.isReady()&&$.delete(Nt)}),$.size===0){V(T);return}setTimeout(Rt,10)}q.get("KHR_parallel_shader_compile")!==null?Rt():setTimeout(Rt,10)})};let Ae=null;function tn(T){Ae&&Ae(T)}function gn(){xn.stop()}function Re(){xn.start()}let xn=new dd;xn.setAnimationLoop(tn),typeof self<"u"&&xn.setContext(self),this.setAnimationLoop=function(T){Ae=T,se.setAnimationLoop(T),T===null?xn.stop():xn.start()},se.addEventListener("sessionstart",gn),se.addEventListener("sessionend",Re),this.render=function(T,z){if(z!==void 0&&z.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(S===!0)return;T.matrixWorldAutoUpdate===!0&&T.updateMatrixWorld(),z.parent===null&&z.matrixWorldAutoUpdate===!0&&z.updateMatrixWorld(),se.enabled===!0&&se.isPresenting===!0&&(se.cameraAutoUpdate===!0&&se.updateCamera(z),z=se.getCamera()),T.isScene===!0&&T.onBeforeRender(y,T,z,A),g=zt.get(T,E.length),g.init(),E.push(g),St.multiplyMatrices(z.projectionMatrix,z.matrixWorldInverse),J.setFromProjectionMatrix(St),dt=this.localClippingEnabled,it=qt.init(this.clippingPlanes,dt),x=wt.get(T,m.length),x.init(),m.push(x),ci(T,z,0,y.sortObjects),x.finish(),y.sortObjects===!0&&x.sort(B,W),this.info.render.frame++,it===!0&&qt.beginShadows();let X=g.state.shadowsArray;if(ot.render(X,T,z),it===!0&&qt.endShadows(),this.info.autoReset===!0&&this.info.reset(),ge.render(x,T),g.setupLights(y._useLegacyLights),z.isArrayCamera){let $=z.cameras;for(let V=0,Rt=$.length;V<Rt;V++){let Nt=$[V];cu(x,T,Nt,Nt.viewport)}}else cu(x,T,z);A!==null&&(v.updateMultisampleRenderTarget(A),v.updateRenderTargetMipmap(A)),T.isScene===!0&&T.onAfterRender(y,T,z),Qt.resetDefaultState(),F=-1,M=null,E.pop(),E.length>0?g=E[E.length-1]:g=null,m.pop(),m.length>0?x=m[m.length-1]:x=null};function ci(T,z,X,$){if(T.visible===!1)return;if(T.layers.test(z.layers)){if(T.isGroup)X=T.renderOrder;else if(T.isLOD)T.autoUpdate===!0&&T.update(z);else if(T.isLight)g.pushLight(T),T.castShadow&&g.pushShadow(T);else if(T.isSprite){if(!T.frustumCulled||J.intersectsSprite(T)){$&&st.setFromMatrixPosition(T.matrixWorld).applyMatrix4(St);let Nt=j.update(T),Wt=T.material;Wt.visible&&x.push(T,Nt,Wt,X,st.z,null)}}else if((T.isMesh||T.isLine||T.isPoints)&&(!T.frustumCulled||J.intersectsObject(T))){let Nt=j.update(T),Wt=T.material;if($&&(T.boundingSphere!==void 0?(T.boundingSphere===null&&T.computeBoundingSphere(),st.copy(T.boundingSphere.center)):(Nt.boundingSphere===null&&Nt.computeBoundingSphere(),st.copy(Nt.boundingSphere.center)),st.applyMatrix4(T.matrixWorld).applyMatrix4(St)),Array.isArray(Wt)){let $t=Nt.groups;for(let ne=0,Jt=$t.length;ne<Jt;ne++){let Kt=$t[ne],Ve=Wt[Kt.materialIndex];Ve&&Ve.visible&&x.push(T,Nt,Ve,X,st.z,Kt)}}else Wt.visible&&x.push(T,Nt,Wt,X,st.z,null)}}let Rt=T.children;for(let Nt=0,Wt=Rt.length;Nt<Wt;Nt++)ci(Rt[Nt],z,X,$)}function cu(T,z,X,$){let V=T.opaque,Rt=T.transmissive,Nt=T.transparent;g.setupLightsView(X),it===!0&&qt.setGlobalState(y.clippingPlanes,X),Rt.length>0&&Ep(V,Rt,z,X),$&&K.viewport(b.copy($)),V.length>0&&Oa(V,z,X),Rt.length>0&&Oa(Rt,z,X),Nt.length>0&&Oa(Nt,z,X),K.buffers.depth.setTest(!0),K.buffers.depth.setMask(!0),K.buffers.color.setMask(!0),K.setPolygonOffset(!1)}function Ep(T,z,X,$){if((X.isScene===!0?X.overrideMaterial:null)!==null)return;let Rt=et.isWebGL2;It===null&&(It=new wi(1,1,{generateMipmaps:!0,type:q.has("EXT_color_buffer_half_float")?ea:$i,minFilter:ta,samples:Rt?4:0})),y.getDrawingBufferSize(Ht),Rt?It.setSize(Ht.x,Ht.y):It.setSize(So(Ht.x),So(Ht.y));let Nt=y.getRenderTarget();y.setRenderTarget(It),y.getClearColor(Z),I=y.getClearAlpha(),I<1&&y.setClearColor(16777215,.5),y.clear();let Wt=y.toneMapping;y.toneMapping=Yi,Oa(T,X,$),v.updateMultisampleRenderTarget(It),v.updateRenderTargetMipmap(It);let $t=!1;for(let ne=0,Jt=z.length;ne<Jt;ne++){let Kt=z[ne],Ve=Kt.object,Cn=Kt.geometry,en=Kt.material,gi=Kt.group;if(en.side===Oe&&Ve.layers.test($.layers)){let Ue=en.side;en.side=dn,en.needsUpdate=!0,lu(Ve,X,$,Cn,en,gi),en.side=Ue,en.needsUpdate=!0,$t=!0}}$t===!0&&(v.updateMultisampleRenderTarget(It),v.updateRenderTargetMipmap(It)),y.setRenderTarget(Nt),y.setClearColor(Z,I),y.toneMapping=Wt}function Oa(T,z,X){let $=z.isScene===!0?z.overrideMaterial:null;for(let V=0,Rt=T.length;V<Rt;V++){let Nt=T[V],Wt=Nt.object,$t=Nt.geometry,ne=$===null?Nt.material:$,Jt=Nt.group;Wt.layers.test(X.layers)&&lu(Wt,z,X,$t,ne,Jt)}}function lu(T,z,X,$,V,Rt){T.onBeforeRender(y,z,X,$,V,Rt),T.modelViewMatrix.multiplyMatrices(X.matrixWorldInverse,T.matrixWorld),T.normalMatrix.getNormalMatrix(T.modelViewMatrix),V.onBeforeRender(y,z,X,$,T,Rt),V.transparent===!0&&V.side===Oe&&V.forceSinglePass===!1?(V.side=dn,V.needsUpdate=!0,y.renderBufferDirect(X,z,$,V,T,Rt),V.side=qi,V.needsUpdate=!0,y.renderBufferDirect(X,z,$,V,T,Rt),V.side=Oe):y.renderBufferDirect(X,z,$,V,T,Rt),T.onAfterRender(y,z,X,$,V,Rt)}function Na(T,z,X){z.isScene!==!0&&(z=ct);let $=_t.get(T),V=g.state.lights,Rt=g.state.shadowsArray,Nt=V.state.version,Wt=Tt.getParameters(T,V.state,Rt,z,X),$t=Tt.getProgramCacheKey(Wt),ne=$.programs;$.environment=T.isMeshStandardMaterial?z.environment:null,$.fog=z.fog,$.envMap=(T.isMeshStandardMaterial?D:_).get(T.envMap||$.environment),ne===void 0&&(T.addEventListener("dispose",Et),ne=new Map,$.programs=ne);let Jt=ne.get($t);if(Jt!==void 0){if($.currentProgram===Jt&&$.lightsStateVersion===Nt)return uu(T,Wt),Jt}else Wt.uniforms=Tt.getUniforms(T),T.onBuild(X,Wt,y),T.onBeforeCompile(Wt,y),Jt=Tt.acquireProgram(Wt,$t),ne.set($t,Jt),$.uniforms=Wt.uniforms;let Kt=$.uniforms;return(!T.isShaderMaterial&&!T.isRawShaderMaterial||T.clipping===!0)&&(Kt.clippingPlanes=qt.uniform),uu(T,Wt),$.needsLights=Tp(T),$.lightsStateVersion=Nt,$.needsLights&&(Kt.ambientLightColor.value=V.state.ambient,Kt.lightProbe.value=V.state.probe,Kt.directionalLights.value=V.state.directional,Kt.directionalLightShadows.value=V.state.directionalShadow,Kt.spotLights.value=V.state.spot,Kt.spotLightShadows.value=V.state.spotShadow,Kt.rectAreaLights.value=V.state.rectArea,Kt.ltc_1.value=V.state.rectAreaLTC1,Kt.ltc_2.value=V.state.rectAreaLTC2,Kt.pointLights.value=V.state.point,Kt.pointLightShadows.value=V.state.pointShadow,Kt.hemisphereLights.value=V.state.hemi,Kt.directionalShadowMap.value=V.state.directionalShadowMap,Kt.directionalShadowMatrix.value=V.state.directionalShadowMatrix,Kt.spotShadowMap.value=V.state.spotShadowMap,Kt.spotLightMatrix.value=V.state.spotLightMatrix,Kt.spotLightMap.value=V.state.spotLightMap,Kt.pointShadowMap.value=V.state.pointShadowMap,Kt.pointShadowMatrix.value=V.state.pointShadowMatrix),$.currentProgram=Jt,$.uniformsList=null,Jt}function hu(T){if(T.uniformsList===null){let z=T.currentProgram.getUniforms();T.uniformsList=cr.seqWithValue(z.seq,T.uniforms)}return T.uniformsList}function uu(T,z){let X=_t.get(T);X.outputColorSpace=z.outputColorSpace,X.batching=z.batching,X.instancing=z.instancing,X.instancingColor=z.instancingColor,X.skinning=z.skinning,X.morphTargets=z.morphTargets,X.morphNormals=z.morphNormals,X.morphColors=z.morphColors,X.morphTargetsCount=z.morphTargetsCount,X.numClippingPlanes=z.numClippingPlanes,X.numIntersection=z.numClipIntersection,X.vertexAlphas=z.vertexAlphas,X.vertexTangents=z.vertexTangents,X.toneMapping=z.toneMapping}function Sp(T,z,X,$,V){z.isScene!==!0&&(z=ct),v.resetTextureUnits();let Rt=z.fog,Nt=$.isMeshStandardMaterial?z.environment:null,Wt=A===null?y.outputColorSpace:A.isXRRenderTarget===!0?A.texture.colorSpace:Ti,$t=($.isMeshStandardMaterial?D:_).get($.envMap||Nt),ne=$.vertexColors===!0&&!!X.attributes.color&&X.attributes.color.itemSize===4,Jt=!!X.attributes.tangent&&(!!$.normalMap||$.anisotropy>0),Kt=!!X.morphAttributes.position,Ve=!!X.morphAttributes.normal,Cn=!!X.morphAttributes.color,en=Yi;$.toneMapped&&(A===null||A.isXRRenderTarget===!0)&&(en=y.toneMapping);let gi=X.morphAttributes.position||X.morphAttributes.normal||X.morphAttributes.color,Ue=gi!==void 0?gi.length:0,re=_t.get($),Rc=g.state.lights;if(it===!0&&(dt===!0||T!==M)){let Fn=T===M&&$.id===F;qt.setState($,T,Fn)}let Be=!1;$.version===re.__version?(re.needsLights&&re.lightsStateVersion!==Rc.state.version||re.outputColorSpace!==Wt||V.isBatchedMesh&&re.batching===!1||!V.isBatchedMesh&&re.batching===!0||V.isInstancedMesh&&re.instancing===!1||!V.isInstancedMesh&&re.instancing===!0||V.isSkinnedMesh&&re.skinning===!1||!V.isSkinnedMesh&&re.skinning===!0||V.isInstancedMesh&&re.instancingColor===!0&&V.instanceColor===null||V.isInstancedMesh&&re.instancingColor===!1&&V.instanceColor!==null||re.envMap!==$t||$.fog===!0&&re.fog!==Rt||re.numClippingPlanes!==void 0&&(re.numClippingPlanes!==qt.numPlanes||re.numIntersection!==qt.numIntersection)||re.vertexAlphas!==ne||re.vertexTangents!==Jt||re.morphTargets!==Kt||re.morphNormals!==Ve||re.morphColors!==Cn||re.toneMapping!==en||et.isWebGL2===!0&&re.morphTargetsCount!==Ue)&&(Be=!0):(Be=!0,re.__version=$.version);let ss=re.currentProgram;Be===!0&&(ss=Na($,z,V));let fu=!1,Nr=!1,Cc=!1,hn=ss.getUniforms(),rs=re.uniforms;if(K.useProgram(ss.program)&&(fu=!0,Nr=!0,Cc=!0),$.id!==F&&(F=$.id,Nr=!0),fu||M!==T){hn.setValue(C,"projectionMatrix",T.projectionMatrix),hn.setValue(C,"viewMatrix",T.matrixWorldInverse);let Fn=hn.map.cameraPosition;Fn!==void 0&&Fn.setValue(C,st.setFromMatrixPosition(T.matrixWorld)),et.logarithmicDepthBuffer&&hn.setValue(C,"logDepthBufFC",2/(Math.log(T.far+1)/Math.LN2)),($.isMeshPhongMaterial||$.isMeshToonMaterial||$.isMeshLambertMaterial||$.isMeshBasicMaterial||$.isMeshStandardMaterial||$.isShaderMaterial)&&hn.setValue(C,"isOrthographic",T.isOrthographicCamera===!0),M!==T&&(M=T,Nr=!0,Cc=!0)}if(V.isSkinnedMesh){hn.setOptional(C,V,"bindMatrix"),hn.setOptional(C,V,"bindMatrixInverse");let Fn=V.skeleton;Fn&&(et.floatVertexTextures?(Fn.boneTexture===null&&Fn.computeBoneTexture(),hn.setValue(C,"boneTexture",Fn.boneTexture,v)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}V.isBatchedMesh&&(hn.setOptional(C,V,"batchingTexture"),hn.setValue(C,"batchingTexture",V._matricesTexture,v));let Pc=X.morphAttributes;if((Pc.position!==void 0||Pc.normal!==void 0||Pc.color!==void 0&&et.isWebGL2===!0)&&oe.update(V,X,ss),(Nr||re.receiveShadow!==V.receiveShadow)&&(re.receiveShadow=V.receiveShadow,hn.setValue(C,"receiveShadow",V.receiveShadow)),$.isMeshGouraudMaterial&&$.envMap!==null&&(rs.envMap.value=$t,rs.flipEnvMap.value=$t.isCubeTexture&&$t.isRenderTargetTexture===!1?-1:1),Nr&&(hn.setValue(C,"toneMappingExposure",y.toneMappingExposure),re.needsLights&&bp(rs,Cc),Rt&&$.fog===!0&&lt.refreshFogUniforms(rs,Rt),lt.refreshMaterialUniforms(rs,$,nt,H,It),cr.upload(C,hu(re),rs,v)),$.isShaderMaterial&&$.uniformsNeedUpdate===!0&&(cr.upload(C,hu(re),rs,v),$.uniformsNeedUpdate=!1),$.isSpriteMaterial&&hn.setValue(C,"center",V.center),hn.setValue(C,"modelViewMatrix",V.modelViewMatrix),hn.setValue(C,"normalMatrix",V.normalMatrix),hn.setValue(C,"modelMatrix",V.matrixWorld),$.isShaderMaterial||$.isRawShaderMaterial){let Fn=$.uniformsGroups;for(let Ic=0,wp=Fn.length;Ic<wp;Ic++)if(et.isWebGL2){let du=Fn[Ic];_e.update(du,ss),_e.bind(du,ss)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return ss}function bp(T,z){T.ambientLightColor.needsUpdate=z,T.lightProbe.needsUpdate=z,T.directionalLights.needsUpdate=z,T.directionalLightShadows.needsUpdate=z,T.pointLights.needsUpdate=z,T.pointLightShadows.needsUpdate=z,T.spotLights.needsUpdate=z,T.spotLightShadows.needsUpdate=z,T.rectAreaLights.needsUpdate=z,T.hemisphereLights.needsUpdate=z}function Tp(T){return T.isMeshLambertMaterial||T.isMeshToonMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isShadowMaterial||T.isShaderMaterial&&T.lights===!0}this.getActiveCubeFace=function(){return P},this.getActiveMipmapLevel=function(){return w},this.getRenderTarget=function(){return A},this.setRenderTargetTextures=function(T,z,X){_t.get(T.texture).__webglTexture=z,_t.get(T.depthTexture).__webglTexture=X;let $=_t.get(T);$.__hasExternalTextures=!0,$.__hasExternalTextures&&($.__autoAllocateDepthBuffer=X===void 0,$.__autoAllocateDepthBuffer||q.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),$.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(T,z){let X=_t.get(T);X.__webglFramebuffer=z,X.__useDefaultFramebuffer=z===void 0},this.setRenderTarget=function(T,z=0,X=0){A=T,P=z,w=X;let $=!0,V=null,Rt=!1,Nt=!1;if(T){let $t=_t.get(T);$t.__useDefaultFramebuffer!==void 0?(K.bindFramebuffer(C.FRAMEBUFFER,null),$=!1):$t.__webglFramebuffer===void 0?v.setupRenderTarget(T):$t.__hasExternalTextures&&v.rebindTextures(T,_t.get(T.texture).__webglTexture,_t.get(T.depthTexture).__webglTexture);let ne=T.texture;(ne.isData3DTexture||ne.isDataArrayTexture||ne.isCompressedArrayTexture)&&(Nt=!0);let Jt=_t.get(T).__webglFramebuffer;T.isWebGLCubeRenderTarget?(Array.isArray(Jt[z])?V=Jt[z][X]:V=Jt[z],Rt=!0):et.isWebGL2&&T.samples>0&&v.useMultisampledRTT(T)===!1?V=_t.get(T).__webglMultisampledFramebuffer:Array.isArray(Jt)?V=Jt[X]:V=Jt,b.copy(T.viewport),R.copy(T.scissor),O=T.scissorTest}else b.copy(Q).multiplyScalar(nt).floor(),R.copy(tt).multiplyScalar(nt).floor(),O=ut;if(K.bindFramebuffer(C.FRAMEBUFFER,V)&&et.drawBuffers&&$&&K.drawBuffers(T,V),K.viewport(b),K.scissor(R),K.setScissorTest(O),Rt){let $t=_t.get(T.texture);C.framebufferTexture2D(C.FRAMEBUFFER,C.COLOR_ATTACHMENT0,C.TEXTURE_CUBE_MAP_POSITIVE_X+z,$t.__webglTexture,X)}else if(Nt){let $t=_t.get(T.texture),ne=z||0;C.framebufferTextureLayer(C.FRAMEBUFFER,C.COLOR_ATTACHMENT0,$t.__webglTexture,X||0,ne)}F=-1},this.readRenderTargetPixels=function(T,z,X,$,V,Rt,Nt){if(!(T&&T.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Wt=_t.get(T).__webglFramebuffer;if(T.isWebGLCubeRenderTarget&&Nt!==void 0&&(Wt=Wt[Nt]),Wt){K.bindFramebuffer(C.FRAMEBUFFER,Wt);try{let $t=T.texture,ne=$t.format,Jt=$t.type;if(ne!==Qn&&Dt.convert(ne)!==C.getParameter(C.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let Kt=Jt===ea&&(q.has("EXT_color_buffer_half_float")||et.isWebGL2&&q.has("EXT_color_buffer_float"));if(Jt!==$i&&Dt.convert(Jt)!==C.getParameter(C.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Jt===Vi&&(et.isWebGL2||q.has("OES_texture_float")||q.has("WEBGL_color_buffer_float")))&&!Kt){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}z>=0&&z<=T.width-$&&X>=0&&X<=T.height-V&&C.readPixels(z,X,$,V,Dt.convert(ne),Dt.convert(Jt),Rt)}finally{let $t=A!==null?_t.get(A).__webglFramebuffer:null;K.bindFramebuffer(C.FRAMEBUFFER,$t)}}},this.copyFramebufferToTexture=function(T,z,X=0){let $=Math.pow(2,-X),V=Math.floor(z.image.width*$),Rt=Math.floor(z.image.height*$);v.setTexture2D(z,0),C.copyTexSubImage2D(C.TEXTURE_2D,X,0,0,T.x,T.y,V,Rt),K.unbindTexture()},this.copyTextureToTexture=function(T,z,X,$=0){let V=z.image.width,Rt=z.image.height,Nt=Dt.convert(X.format),Wt=Dt.convert(X.type);v.setTexture2D(X,0),C.pixelStorei(C.UNPACK_FLIP_Y_WEBGL,X.flipY),C.pixelStorei(C.UNPACK_PREMULTIPLY_ALPHA_WEBGL,X.premultiplyAlpha),C.pixelStorei(C.UNPACK_ALIGNMENT,X.unpackAlignment),z.isDataTexture?C.texSubImage2D(C.TEXTURE_2D,$,T.x,T.y,V,Rt,Nt,Wt,z.image.data):z.isCompressedTexture?C.compressedTexSubImage2D(C.TEXTURE_2D,$,T.x,T.y,z.mipmaps[0].width,z.mipmaps[0].height,Nt,z.mipmaps[0].data):C.texSubImage2D(C.TEXTURE_2D,$,T.x,T.y,Nt,Wt,z.image),$===0&&X.generateMipmaps&&C.generateMipmap(C.TEXTURE_2D),K.unbindTexture()},this.copyTextureToTexture3D=function(T,z,X,$,V=0){if(y.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let Rt=T.max.x-T.min.x+1,Nt=T.max.y-T.min.y+1,Wt=T.max.z-T.min.z+1,$t=Dt.convert($.format),ne=Dt.convert($.type),Jt;if($.isData3DTexture)v.setTexture3D($,0),Jt=C.TEXTURE_3D;else if($.isDataArrayTexture||$.isCompressedArrayTexture)v.setTexture2DArray($,0),Jt=C.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}C.pixelStorei(C.UNPACK_FLIP_Y_WEBGL,$.flipY),C.pixelStorei(C.UNPACK_PREMULTIPLY_ALPHA_WEBGL,$.premultiplyAlpha),C.pixelStorei(C.UNPACK_ALIGNMENT,$.unpackAlignment);let Kt=C.getParameter(C.UNPACK_ROW_LENGTH),Ve=C.getParameter(C.UNPACK_IMAGE_HEIGHT),Cn=C.getParameter(C.UNPACK_SKIP_PIXELS),en=C.getParameter(C.UNPACK_SKIP_ROWS),gi=C.getParameter(C.UNPACK_SKIP_IMAGES),Ue=X.isCompressedTexture?X.mipmaps[V]:X.image;C.pixelStorei(C.UNPACK_ROW_LENGTH,Ue.width),C.pixelStorei(C.UNPACK_IMAGE_HEIGHT,Ue.height),C.pixelStorei(C.UNPACK_SKIP_PIXELS,T.min.x),C.pixelStorei(C.UNPACK_SKIP_ROWS,T.min.y),C.pixelStorei(C.UNPACK_SKIP_IMAGES,T.min.z),X.isDataTexture||X.isData3DTexture?C.texSubImage3D(Jt,V,z.x,z.y,z.z,Rt,Nt,Wt,$t,ne,Ue.data):X.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),C.compressedTexSubImage3D(Jt,V,z.x,z.y,z.z,Rt,Nt,Wt,$t,Ue.data)):C.texSubImage3D(Jt,V,z.x,z.y,z.z,Rt,Nt,Wt,$t,ne,Ue),C.pixelStorei(C.UNPACK_ROW_LENGTH,Kt),C.pixelStorei(C.UNPACK_IMAGE_HEIGHT,Ve),C.pixelStorei(C.UNPACK_SKIP_PIXELS,Cn),C.pixelStorei(C.UNPACK_SKIP_ROWS,en),C.pixelStorei(C.UNPACK_SKIP_IMAGES,gi),V===0&&$.generateMipmaps&&C.generateMipmap(Jt),K.unbindTexture()},this.initTexture=function(T){T.isCubeTexture?v.setTextureCube(T,0):T.isData3DTexture?v.setTexture3D(T,0):T.isDataArrayTexture||T.isCompressedArrayTexture?v.setTexture2DArray(T,0):v.setTexture2D(T,0),K.unbindTexture()},this.resetState=function(){P=0,w=0,A=null,K.reset(),Qt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return bi}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=t===ch?"display-p3":"srgb",e.unpackColorSpace=Me.workingColorSpace===Jo?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===be?gs:rd}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===gs?be:Ti}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}},Ul=class extends aa{};Ul.prototype.isWebGL1Renderer=!0;var Uo=class n{constructor(t,e=1,i=1e3){this.isFog=!0,this.name="",this.color=new Ft(t),this.near=e,this.far=i}clone(){return new n(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},oa=class extends Ze{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}},Ol=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=xl,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=ui()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,i){t*=this.stride,i*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[i+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ui()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(e,this.stride);return i.setUsage(this.usage),i}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ui()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},yn=new L,Oo=class n{constructor(t,e,i,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=i,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,i=this.data.count;e<i;e++)yn.fromBufferAttribute(this,e),yn.applyMatrix4(t),this.setXYZ(e,yn.x,yn.y,yn.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)yn.fromBufferAttribute(this,e),yn.applyNormalMatrix(t),this.setXYZ(e,yn.x,yn.y,yn.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)yn.fromBufferAttribute(this,e),yn.transformDirection(t),this.setXYZ(e,yn.x,yn.y,yn.z);return this}setX(t,e){return this.normalized&&(e=ve(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=ve(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=ve(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=ve(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=hi(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=hi(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=hi(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=hi(e,this.array)),e}setXY(t,e,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=ve(e,this.array),i=ve(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this}setXYZ(t,e,i,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=ve(e,this.array),i=ve(i,this.array),s=ve(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this}setXYZW(t,e,i,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=ve(e,this.array),i=ve(i,this.array),s=ve(s,this.array),r=ve(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let i=0;i<this.count;i++){let s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new me(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new n(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let i=0;i<this.count;i++){let s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},ji=class extends Ai{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Ft(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Qs,kr=new L,tr=new L,er=new L,nr=new ht,Gr=new ht,_d=new Ce,ro=new L,Vr=new L,ao=new L,Of=new ht,ol=new ht,Nf=new ht,xs=class extends Ze{constructor(t=new ji){if(super(),this.isSprite=!0,this.type="Sprite",Qs===void 0){Qs=new Ie;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new Ol(e,5);Qs.setIndex([0,1,2,0,2,3]),Qs.setAttribute("position",new Oo(i,3,0,!1)),Qs.setAttribute("uv",new Oo(i,2,3,!1))}this.geometry=Qs,this.material=t,this.center=new ht(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),tr.setFromMatrixScale(this.matrixWorld),_d.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),er.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&tr.multiplyScalar(-er.z);let i=this.material.rotation,s,r;i!==0&&(r=Math.cos(i),s=Math.sin(i));let a=this.center;oo(ro.set(-.5,-.5,0),er,a,tr,s,r),oo(Vr.set(.5,-.5,0),er,a,tr,s,r),oo(ao.set(.5,.5,0),er,a,tr,s,r),Of.set(0,0),ol.set(1,0),Nf.set(1,1);let o=t.ray.intersectTriangle(ro,Vr,ao,!1,kr);if(o===null&&(oo(Vr.set(-.5,.5,0),er,a,tr,s,r),ol.set(0,1),o=t.ray.intersectTriangle(ro,ao,Vr,!1,kr),o===null))return;let c=t.ray.origin.distanceTo(kr);c<t.near||c>t.far||e.push({distance:c,point:kr.clone(),uv:ds.getInterpolation(kr,ro,Vr,ao,Of,ol,Nf,new ht),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function oo(n,t,e,i,s,r){nr.subVectors(n,e).addScalar(.5).multiply(i),s!==void 0?(Gr.x=r*nr.x-s*nr.y,Gr.y=s*nr.x+r*nr.y):Gr.copy(nr),n.copy(t),n.x+=Gr.x,n.y+=Gr.y,n.applyMatrix4(_d)}var No=class extends me{constructor(t,e,i,s=1){super(t,e,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},ir=new Ce,Ff=new Ce,co=[],zf=new Gn,P_=new Ce,Wr=new bt,Xr=new Ki,Fo=class extends bt{constructor(t,e,i){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new No(new Float32Array(i*16),16),this.instanceColor=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<i;s++)this.setMatrixAt(s,P_)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new Gn),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,ir),zf.copy(t.boundingBox).applyMatrix4(ir),this.boundingBox.union(zf)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Ki),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,ir),Xr.copy(t.boundingSphere).applyMatrix4(ir),this.boundingSphere.union(Xr)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}raycast(t,e){let i=this.matrixWorld,s=this.count;if(Wr.geometry=this.geometry,Wr.material=this.material,Wr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Xr.copy(this.boundingSphere),Xr.applyMatrix4(i),t.ray.intersectsSphere(Xr)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,ir),Ff.multiplyMatrices(i,ir),Wr.matrixWorld=Ff,Wr.raycast(t,co);for(let a=0,o=co.length;a<o;a++){let c=co[a];c.instanceId=r,c.object=this,e.push(c)}co.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new No(new Float32Array(this.instanceMatrix.count*3),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var ca=class extends Ai{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Ft(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Bf=new Ce,Nl=new ia,lo=new Ki,ho=new L,la=class extends Ze{constructor(t=new Ie,e=new ca){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){let i=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),lo.copy(i.boundingSphere),lo.applyMatrix4(s),lo.radius+=r,t.ray.intersectsSphere(lo)===!1)return;Bf.copy(s).invert(),Nl.copy(t.ray).applyMatrix4(Bf);let o=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=i.index,u=i.attributes.position;if(l!==null){let f=Math.max(0,a.start),d=Math.min(l.count,a.start+a.count);for(let p=f,x=d;p<x;p++){let g=l.getX(p);ho.fromBufferAttribute(u,g),Hf(ho,g,c,s,t,e,this)}}else{let f=Math.max(0,a.start),d=Math.min(u.count,a.start+a.count);for(let p=f,x=d;p<x;p++)ho.fromBufferAttribute(u,p),Hf(ho,p,c,s,t,e,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){let s=e[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){let o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}};function Hf(n,t,e,i,s,r,a){let o=Nl.distanceSqToPoint(n);if(o<e){let c=new L;Nl.closestPointToPoint(n,c),c.applyMatrix4(i);let l=s.ray.origin.distanceTo(c);if(l<s.near||l>s.far)return;r.push({distance:l,distanceToRay:Math.sqrt(o),point:c,index:t,face:null,object:a})}}var ti=class extends kn{constructor(t,e,i,s,r,a,o,c,l){super(t,e,i,s,r,a,o,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}},Wn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){let i=this.getUtoTmapping(t);return this.getPoint(i,e)}getPoints(t=5){let e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return e}getSpacedPoints(t=5){let e=[];for(let i=0;i<=t;i++)e.push(this.getPointAt(i/t));return e}getLength(){let t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let e=[],i,s=this.getPoint(0),r=0;e.push(0);for(let a=1;a<=t;a++)i=this.getPoint(a/t),r+=i.distanceTo(s),e.push(r),s=i;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){let i=this.getLengths(),s=0,r=i.length,a;e?a=e:a=t*i[r-1];let o=0,c=r-1,l;for(;o<=c;)if(s=Math.floor(o+(c-o)/2),l=i[s]-a,l<0)o=s+1;else if(l>0)c=s-1;else{c=s;break}if(s=c,i[s]===a)return s/(r-1);let h=i[s],f=i[s+1]-h,d=(a-h)/f;return(s+d)/(r-1)}getTangent(t,e){let s=t-1e-4,r=t+1e-4;s<0&&(s=0),r>1&&(r=1);let a=this.getPoint(s),o=this.getPoint(r),c=e||(a.isVector2?new ht:new L);return c.copy(o).sub(a).normalize(),c}getTangentAt(t,e){let i=this.getUtoTmapping(t);return this.getTangent(i,e)}computeFrenetFrames(t,e){let i=new L,s=[],r=[],a=[],o=new L,c=new Ce;for(let d=0;d<=t;d++){let p=d/t;s[d]=this.getTangentAt(p,new L)}r[0]=new L,a[0]=new L;let l=Number.MAX_VALUE,h=Math.abs(s[0].x),u=Math.abs(s[0].y),f=Math.abs(s[0].z);h<=l&&(l=h,i.set(1,0,0)),u<=l&&(l=u,i.set(0,1,0)),f<=l&&i.set(0,0,1),o.crossVectors(s[0],i).normalize(),r[0].crossVectors(s[0],o),a[0].crossVectors(s[0],r[0]);for(let d=1;d<=t;d++){if(r[d]=r[d-1].clone(),a[d]=a[d-1].clone(),o.crossVectors(s[d-1],s[d]),o.length()>Number.EPSILON){o.normalize();let p=Math.acos(on(s[d-1].dot(s[d]),-1,1));r[d].applyMatrix4(c.makeRotationAxis(o,p))}a[d].crossVectors(s[d],r[d])}if(e===!0){let d=Math.acos(on(r[0].dot(r[t]),-1,1));d/=t,s[0].dot(o.crossVectors(r[0],r[t]))>0&&(d=-d);for(let p=1;p<=t;p++)r[p].applyMatrix4(c.makeRotationAxis(s[p],d*p)),a[p].crossVectors(s[p],r[p])}return{tangents:s,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){let t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}},ha=class extends Wn{constructor(t=0,e=0,i=1,s=1,r=0,a=Math.PI*2,o=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=i,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=c}getPoint(t,e){let i=e||new ht,s=Math.PI*2,r=this.aEndAngle-this.aStartAngle,a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(a?r=0:r=s),this.aClockwise===!0&&!a&&(r===s?r=-s:r=r-s);let o=this.aStartAngle+t*r,c=this.aX+this.xRadius*Math.cos(o),l=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),f=c-this.aX,d=l-this.aY;c=f*h-d*u+this.aX,l=f*u+d*h+this.aY}return i.set(c,l)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){let t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}},Fl=class extends ha{constructor(t,e,i,s,r,a){super(t,e,i,i,s,r,a),this.isArcCurve=!0,this.type="ArcCurve"}};function uh(){let n=0,t=0,e=0,i=0;function s(r,a,o,c){n=r,t=o,e=-3*r+3*a-2*o-c,i=2*r-2*a+o+c}return{initCatmullRom:function(r,a,o,c,l){s(a,o,l*(o-r),l*(c-a))},initNonuniformCatmullRom:function(r,a,o,c,l,h,u){let f=(a-r)/l-(o-r)/(l+h)+(o-a)/h,d=(o-a)/h-(c-a)/(h+u)+(c-o)/u;f*=h,d*=h,s(a,o,f,d)},calc:function(r){let a=r*r,o=a*r;return n+t*r+e*a+i*o}}}var uo=new L,cl=new uh,ll=new uh,hl=new uh,ua=class extends Wn{constructor(t=[],e=!1,i="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=i,this.tension=s}getPoint(t,e=new L){let i=e,s=this.points,r=s.length,a=(r-(this.closed?0:1))*t,o=Math.floor(a),c=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/r)+1)*r:c===0&&o===r-1&&(o=r-2,c=1);let l,h;this.closed||o>0?l=s[(o-1)%r]:(uo.subVectors(s[0],s[1]).add(s[0]),l=uo);let u=s[o%r],f=s[(o+1)%r];if(this.closed||o+2<r?h=s[(o+2)%r]:(uo.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=uo),this.curveType==="centripetal"||this.curveType==="chordal"){let d=this.curveType==="chordal"?.5:.25,p=Math.pow(l.distanceToSquared(u),d),x=Math.pow(u.distanceToSquared(f),d),g=Math.pow(f.distanceToSquared(h),d);x<1e-4&&(x=1),p<1e-4&&(p=x),g<1e-4&&(g=x),cl.initNonuniformCatmullRom(l.x,u.x,f.x,h.x,p,x,g),ll.initNonuniformCatmullRom(l.y,u.y,f.y,h.y,p,x,g),hl.initNonuniformCatmullRom(l.z,u.z,f.z,h.z,p,x,g)}else this.curveType==="catmullrom"&&(cl.initCatmullRom(l.x,u.x,f.x,h.x,this.tension),ll.initCatmullRom(l.y,u.y,f.y,h.y,this.tension),hl.initCatmullRom(l.z,u.z,f.z,h.z,this.tension));return i.set(cl.calc(c),ll.calc(c),hl.calc(c)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(s.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){let s=this.points[e];t.points.push(s.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(new L().fromArray(s))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}};function kf(n,t,e,i,s){let r=(i-t)*.5,a=(s-e)*.5,o=n*n,c=n*o;return(2*e-2*i+r+a)*c+(-3*e+3*i-2*r-a)*o+r*n+e}function I_(n,t){let e=1-n;return e*e*t}function L_(n,t){return 2*(1-n)*n*t}function D_(n,t){return n*n*t}function Jr(n,t,e,i){return I_(n,t)+L_(n,e)+D_(n,i)}function U_(n,t){let e=1-n;return e*e*e*t}function O_(n,t){let e=1-n;return 3*e*e*n*t}function N_(n,t){return 3*(1-n)*n*n*t}function F_(n,t){return n*n*n*t}function Kr(n,t,e,i,s){return U_(n,t)+O_(n,e)+N_(n,i)+F_(n,s)}var zo=class extends Wn{constructor(t=new ht,e=new ht,i=new ht,s=new ht){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=i,this.v3=s}getPoint(t,e=new ht){let i=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(Kr(t,s.x,r.x,a.x,o.x),Kr(t,s.y,r.y,a.y,o.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},zl=class extends Wn{constructor(t=new L,e=new L,i=new L,s=new L){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=i,this.v3=s}getPoint(t,e=new L){let i=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(Kr(t,s.x,r.x,a.x,o.x),Kr(t,s.y,r.y,a.y,o.y),Kr(t,s.z,r.z,a.z,o.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},Bo=class extends Wn{constructor(t=new ht,e=new ht){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new ht){let i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new ht){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Bl=class extends Wn{constructor(t=new L,e=new L){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new L){let i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new L){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Ho=class extends Wn{constructor(t=new ht,e=new ht,i=new ht){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new ht){let i=e,s=this.v0,r=this.v1,a=this.v2;return i.set(Jr(t,s.x,r.x,a.x),Jr(t,s.y,r.y,a.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Hl=class extends Wn{constructor(t=new L,e=new L,i=new L){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new L){let i=e,s=this.v0,r=this.v1,a=this.v2;return i.set(Jr(t,s.x,r.x,a.x),Jr(t,s.y,r.y,a.y),Jr(t,s.z,r.z,a.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},ko=class extends Wn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new ht){let i=e,s=this.points,r=(s.length-1)*t,a=Math.floor(r),o=r-a,c=s[a===0?a:a-1],l=s[a],h=s[a>s.length-2?s.length-1:a+1],u=s[a>s.length-3?s.length-1:a+2];return i.set(kf(o,c.x,l.x,h.x,u.x),kf(o,c.y,l.y,h.y,u.y)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){let s=this.points[e];t.points.push(s.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(new ht().fromArray(s))}return this}},kl=Object.freeze({__proto__:null,ArcCurve:Fl,CatmullRomCurve3:ua,CubicBezierCurve:zo,CubicBezierCurve3:zl,EllipseCurve:ha,LineCurve:Bo,LineCurve3:Bl,QuadraticBezierCurve:Ho,QuadraticBezierCurve3:Hl,SplineCurve:ko}),Gl=class extends Wn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){let i=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new kl[i](e,t))}return this}getPoint(t,e){let i=t*this.getLength(),s=this.getCurveLengths(),r=0;for(;r<s.length;){if(s[r]>=i){let a=s[r]-i,o=this.curves[r],c=o.getLength(),l=c===0?0:1-a/c;return o.getPointAt(l,e)}r++}return null}getLength(){let t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let t=[],e=0;for(let i=0,s=this.curves.length;i<s;i++)e+=this.curves[i].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){let e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){let e=[],i;for(let s=0,r=this.curves;s<r.length;s++){let a=r[s],o=a.isEllipseCurve?t*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?t*a.points.length:t,c=a.getPoints(o);for(let l=0;l<c.length;l++){let h=c[l];i&&i.equals(h)||(e.push(h),i=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){let s=t.curves[e];this.curves.push(s.clone())}return this.autoClose=t.autoClose,this}toJSON(){let t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,i=this.curves.length;e<i;e++){let s=this.curves[e];t.curves.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){let s=t.curves[e];this.curves.push(new kl[s.type]().fromJSON(s))}return this}},Go=class extends Gl{constructor(t){super(),this.type="Path",this.currentPoint=new ht,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,i=t.length;e<i;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){let i=new Bo(this.currentPoint.clone(),new ht(t,e));return this.curves.push(i),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,i,s){let r=new Ho(this.currentPoint.clone(),new ht(t,e),new ht(i,s));return this.curves.push(r),this.currentPoint.set(i,s),this}bezierCurveTo(t,e,i,s,r,a){let o=new zo(this.currentPoint.clone(),new ht(t,e),new ht(i,s),new ht(r,a));return this.curves.push(o),this.currentPoint.set(r,a),this}splineThru(t){let e=[this.currentPoint.clone()].concat(t),i=new ko(e);return this.curves.push(i),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,i,s,r,a){let o=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(t+o,e+c,i,s,r,a),this}absarc(t,e,i,s,r,a){return this.absellipse(t,e,i,i,s,r,a),this}ellipse(t,e,i,s,r,a,o,c){let l=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+l,e+h,i,s,r,a,o,c),this}absellipse(t,e,i,s,r,a,o,c){let l=new ha(t,e,i,s,r,a,o,c);if(this.curves.length>0){let u=l.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(l);let h=l.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){let t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}};var ys=class n extends Ie{constructor(t=1,e=32,i=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:i,thetaLength:s},e=Math.max(3,e);let r=[],a=[],o=[],c=[],l=new L,h=new ht;a.push(0,0,0),o.push(0,0,1),c.push(.5,.5);for(let u=0,f=3;u<=e;u++,f+=3){let d=i+u/e*s;l.x=t*Math.cos(d),l.y=t*Math.sin(d),a.push(l.x,l.y,l.z),o.push(0,0,1),h.x=(a[f]/t+1)/2,h.y=(a[f+1]/t+1)/2,c.push(h.x,h.y)}for(let u=1;u<=e;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new fe(a,3)),this.setAttribute("normal",new fe(o,3)),this.setAttribute("uv",new fe(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.segments,t.thetaStart,t.thetaLength)}},Vt=class n extends Ie{constructor(t=1,e=1,i=1,s=32,r=1,a=!1,o=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:i,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:c};let l=this;s=Math.floor(s),r=Math.floor(r);let h=[],u=[],f=[],d=[],p=0,x=[],g=i/2,m=0;E(),a===!1&&(t>0&&y(!0),e>0&&y(!1)),this.setIndex(h),this.setAttribute("position",new fe(u,3)),this.setAttribute("normal",new fe(f,3)),this.setAttribute("uv",new fe(d,2));function E(){let S=new L,P=new L,w=0,A=(e-t)/i;for(let F=0;F<=r;F++){let M=[],b=F/r,R=b*(e-t)+t;for(let O=0;O<=s;O++){let Z=O/s,I=Z*c+o,N=Math.sin(I),H=Math.cos(I);P.x=R*N,P.y=-b*i+g,P.z=R*H,u.push(P.x,P.y,P.z),S.set(N,A,H).normalize(),f.push(S.x,S.y,S.z),d.push(Z,1-b),M.push(p++)}x.push(M)}for(let F=0;F<s;F++)for(let M=0;M<r;M++){let b=x[M][F],R=x[M+1][F],O=x[M+1][F+1],Z=x[M][F+1];h.push(b,R,Z),h.push(R,O,Z),w+=6}l.addGroup(m,w,0),m+=w}function y(S){let P=p,w=new ht,A=new L,F=0,M=S===!0?t:e,b=S===!0?1:-1;for(let O=1;O<=s;O++)u.push(0,g*b,0),f.push(0,b,0),d.push(.5,.5),p++;let R=p;for(let O=0;O<=s;O++){let I=O/s*c+o,N=Math.cos(I),H=Math.sin(I);A.x=M*H,A.y=g*b,A.z=M*N,u.push(A.x,A.y,A.z),f.push(0,b,0),w.x=N*.5+.5,w.y=H*.5*b+.5,d.push(w.x,w.y),p++}for(let O=0;O<s;O++){let Z=P+O,I=R+O;S===!0?h.push(I,I+1,Z):h.push(I+1,I,Z),F+=3}l.addGroup(m,F,S===!0?1:2),m+=F}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},je=class n extends Vt{constructor(t=1,e=1,i=32,s=1,r=!1,a=0,o=Math.PI*2){super(0,t,e,i,s,r,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:i,heightSegments:s,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(t){return new n(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Vo=class n extends Ie{constructor(t=[],e=[],i=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:i,detail:s};let r=[],a=[];o(s),l(i),h(),this.setAttribute("position",new fe(r,3)),this.setAttribute("normal",new fe(r.slice(),3)),this.setAttribute("uv",new fe(a,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(E){let y=new L,S=new L,P=new L;for(let w=0;w<e.length;w+=3)d(e[w+0],y),d(e[w+1],S),d(e[w+2],P),c(y,S,P,E)}function c(E,y,S,P){let w=P+1,A=[];for(let F=0;F<=w;F++){A[F]=[];let M=E.clone().lerp(S,F/w),b=y.clone().lerp(S,F/w),R=w-F;for(let O=0;O<=R;O++)O===0&&F===w?A[F][O]=M:A[F][O]=M.clone().lerp(b,O/R)}for(let F=0;F<w;F++)for(let M=0;M<2*(w-F)-1;M++){let b=Math.floor(M/2);M%2===0?(f(A[F][b+1]),f(A[F+1][b]),f(A[F][b])):(f(A[F][b+1]),f(A[F+1][b+1]),f(A[F+1][b]))}}function l(E){let y=new L;for(let S=0;S<r.length;S+=3)y.x=r[S+0],y.y=r[S+1],y.z=r[S+2],y.normalize().multiplyScalar(E),r[S+0]=y.x,r[S+1]=y.y,r[S+2]=y.z}function h(){let E=new L;for(let y=0;y<r.length;y+=3){E.x=r[y+0],E.y=r[y+1],E.z=r[y+2];let S=g(E)/2/Math.PI+.5,P=m(E)/Math.PI+.5;a.push(S,1-P)}p(),u()}function u(){for(let E=0;E<a.length;E+=6){let y=a[E+0],S=a[E+2],P=a[E+4],w=Math.max(y,S,P),A=Math.min(y,S,P);w>.9&&A<.1&&(y<.2&&(a[E+0]+=1),S<.2&&(a[E+2]+=1),P<.2&&(a[E+4]+=1))}}function f(E){r.push(E.x,E.y,E.z)}function d(E,y){let S=E*3;y.x=t[S+0],y.y=t[S+1],y.z=t[S+2]}function p(){let E=new L,y=new L,S=new L,P=new L,w=new ht,A=new ht,F=new ht;for(let M=0,b=0;M<r.length;M+=9,b+=6){E.set(r[M+0],r[M+1],r[M+2]),y.set(r[M+3],r[M+4],r[M+5]),S.set(r[M+6],r[M+7],r[M+8]),w.set(a[b+0],a[b+1]),A.set(a[b+2],a[b+3]),F.set(a[b+4],a[b+5]),P.copy(E).add(y).add(S).divideScalar(3);let R=g(P);x(w,b+0,E,R),x(A,b+2,y,R),x(F,b+4,S,R)}}function x(E,y,S,P){P<0&&E.x===1&&(a[y]=E.x-1),S.x===0&&S.z===0&&(a[y]=P/2/Math.PI+.5)}function g(E){return Math.atan2(E.z,-E.x)}function m(E){return Math.atan2(-E.y,Math.sqrt(E.x*E.x+E.z*E.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.vertices,t.indices,t.radius,t.details)}};var Qi=class extends Go{constructor(t){super(t),this.uuid=ui(),this.type="Shape",this.holes=[]}getPointsHoles(t){let e=[];for(let i=0,s=this.holes.length;i<s;i++)e[i]=this.holes[i].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){let s=t.holes[e];this.holes.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,i=this.holes.length;e<i;e++){let s=this.holes[e];t.holes.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){let s=t.holes[e];this.holes.push(new Go().fromJSON(s))}return this}},z_={triangulate:function(n,t,e=2){let i=t&&t.length,s=i?t[0]*e:n.length,r=vd(n,0,s,e,!0),a=[];if(!r||r.next===r.prev)return a;let o,c,l,h,u,f,d;if(i&&(r=V_(n,t,r,e)),n.length>80*e){o=l=n[0],c=h=n[1];for(let p=e;p<s;p+=e)u=n[p],f=n[p+1],u<o&&(o=u),f<c&&(c=f),u>l&&(l=u),f>h&&(h=f);d=Math.max(l-o,h-c),d=d!==0?32767/d:0}return fa(r,a,e,o,c,d,0),a}};function vd(n,t,e,i,s){let r,a;if(s===tv(n,t,e,i)>0)for(r=t;r<e;r+=i)a=Gf(r,n[r],n[r+1],a);else for(r=e-i;r>=t;r-=i)a=Gf(r,n[r],n[r+1],a);return a&&jo(a,a.next)&&(pa(a),a=a.next),a}function _s(n,t){if(!n)return n;t||(t=n);let e=n,i;do if(i=!1,!e.steiner&&(jo(e,e.next)||Ne(e.prev,e,e.next)===0)){if(pa(e),e=t=e.prev,e===e.next)break;i=!0}else e=e.next;while(i||e!==t);return t}function fa(n,t,e,i,s,r,a){if(!n)return;!a&&r&&q_(n,i,s,r);let o=n,c,l;for(;n.prev!==n.next;){if(c=n.prev,l=n.next,r?H_(n,i,s,r):B_(n)){t.push(c.i/e|0),t.push(n.i/e|0),t.push(l.i/e|0),pa(n),n=l.next,o=l.next;continue}if(n=l,n===o){a?a===1?(n=k_(_s(n),t,e),fa(n,t,e,i,s,r,2)):a===2&&G_(n,t,e,i,s,r):fa(_s(n),t,e,i,s,r,1);break}}}function B_(n){let t=n.prev,e=n,i=n.next;if(Ne(t,e,i)>=0)return!1;let s=t.x,r=e.x,a=i.x,o=t.y,c=e.y,l=i.y,h=s<r?s<a?s:a:r<a?r:a,u=o<c?o<l?o:l:c<l?c:l,f=s>r?s>a?s:a:r>a?r:a,d=o>c?o>l?o:l:c>l?c:l,p=i.next;for(;p!==t;){if(p.x>=h&&p.x<=f&&p.y>=u&&p.y<=d&&ar(s,o,r,c,a,l,p.x,p.y)&&Ne(p.prev,p,p.next)>=0)return!1;p=p.next}return!0}function H_(n,t,e,i){let s=n.prev,r=n,a=n.next;if(Ne(s,r,a)>=0)return!1;let o=s.x,c=r.x,l=a.x,h=s.y,u=r.y,f=a.y,d=o<c?o<l?o:l:c<l?c:l,p=h<u?h<f?h:f:u<f?u:f,x=o>c?o>l?o:l:c>l?c:l,g=h>u?h>f?h:f:u>f?u:f,m=Vl(d,p,t,e,i),E=Vl(x,g,t,e,i),y=n.prevZ,S=n.nextZ;for(;y&&y.z>=m&&S&&S.z<=E;){if(y.x>=d&&y.x<=x&&y.y>=p&&y.y<=g&&y!==s&&y!==a&&ar(o,h,c,u,l,f,y.x,y.y)&&Ne(y.prev,y,y.next)>=0||(y=y.prevZ,S.x>=d&&S.x<=x&&S.y>=p&&S.y<=g&&S!==s&&S!==a&&ar(o,h,c,u,l,f,S.x,S.y)&&Ne(S.prev,S,S.next)>=0))return!1;S=S.nextZ}for(;y&&y.z>=m;){if(y.x>=d&&y.x<=x&&y.y>=p&&y.y<=g&&y!==s&&y!==a&&ar(o,h,c,u,l,f,y.x,y.y)&&Ne(y.prev,y,y.next)>=0)return!1;y=y.prevZ}for(;S&&S.z<=E;){if(S.x>=d&&S.x<=x&&S.y>=p&&S.y<=g&&S!==s&&S!==a&&ar(o,h,c,u,l,f,S.x,S.y)&&Ne(S.prev,S,S.next)>=0)return!1;S=S.nextZ}return!0}function k_(n,t,e){let i=n;do{let s=i.prev,r=i.next.next;!jo(s,r)&&Md(s,i,i.next,r)&&da(s,r)&&da(r,s)&&(t.push(s.i/e|0),t.push(i.i/e|0),t.push(r.i/e|0),pa(i),pa(i.next),i=n=r),i=i.next}while(i!==n);return _s(i)}function G_(n,t,e,i,s,r){let a=n;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&K_(a,o)){let c=Ed(a,o);a=_s(a,a.next),c=_s(c,c.next),fa(a,t,e,i,s,r,0),fa(c,t,e,i,s,r,0);return}o=o.next}a=a.next}while(a!==n)}function V_(n,t,e,i){let s=[],r,a,o,c,l;for(r=0,a=t.length;r<a;r++)o=t[r]*i,c=r<a-1?t[r+1]*i:n.length,l=vd(n,o,c,i,!1),l===l.next&&(l.steiner=!0),s.push(J_(l));for(s.sort(W_),r=0;r<s.length;r++)e=X_(s[r],e);return e}function W_(n,t){return n.x-t.x}function X_(n,t){let e=Y_(n,t);if(!e)return t;let i=Ed(e,n);return _s(i,i.next),_s(e,e.next)}function Y_(n,t){let e=t,i=-1/0,s,r=n.x,a=n.y;do{if(a<=e.y&&a>=e.next.y&&e.next.y!==e.y){let f=e.x+(a-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(f<=r&&f>i&&(i=f,s=e.x<e.next.x?e:e.next,f===r))return s}e=e.next}while(e!==t);if(!s)return null;let o=s,c=s.x,l=s.y,h=1/0,u;e=s;do r>=e.x&&e.x>=c&&r!==e.x&&ar(a<l?r:i,a,c,l,a<l?i:r,a,e.x,e.y)&&(u=Math.abs(a-e.y)/(r-e.x),da(e,n)&&(u<h||u===h&&(e.x>s.x||e.x===s.x&&$_(s,e)))&&(s=e,h=u)),e=e.next;while(e!==o);return s}function $_(n,t){return Ne(n.prev,n,t.prev)<0&&Ne(t.next,n,n.next)<0}function q_(n,t,e,i){let s=n;do s.z===0&&(s.z=Vl(s.x,s.y,t,e,i)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==n);s.prevZ.nextZ=null,s.prevZ=null,Z_(s)}function Z_(n){let t,e,i,s,r,a,o,c,l=1;do{for(e=n,n=null,r=null,a=0;e;){for(a++,i=e,o=0,t=0;t<l&&(o++,i=i.nextZ,!!i);t++);for(c=l;o>0||c>0&&i;)o!==0&&(c===0||!i||e.z<=i.z)?(s=e,e=e.nextZ,o--):(s=i,i=i.nextZ,c--),r?r.nextZ=s:n=s,s.prevZ=r,r=s;e=i}r.nextZ=null,l*=2}while(a>1);return n}function Vl(n,t,e,i,s){return n=(n-e)*s|0,t=(t-i)*s|0,n=(n|n<<8)&16711935,n=(n|n<<4)&252645135,n=(n|n<<2)&858993459,n=(n|n<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,n|t<<1}function J_(n){let t=n,e=n;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==n);return e}function ar(n,t,e,i,s,r,a,o){return(s-a)*(t-o)>=(n-a)*(r-o)&&(n-a)*(i-o)>=(e-a)*(t-o)&&(e-a)*(r-o)>=(s-a)*(i-o)}function K_(n,t){return n.next.i!==t.i&&n.prev.i!==t.i&&!j_(n,t)&&(da(n,t)&&da(t,n)&&Q_(n,t)&&(Ne(n.prev,n,t.prev)||Ne(n,t.prev,t))||jo(n,t)&&Ne(n.prev,n,n.next)>0&&Ne(t.prev,t,t.next)>0)}function Ne(n,t,e){return(t.y-n.y)*(e.x-t.x)-(t.x-n.x)*(e.y-t.y)}function jo(n,t){return n.x===t.x&&n.y===t.y}function Md(n,t,e,i){let s=po(Ne(n,t,e)),r=po(Ne(n,t,i)),a=po(Ne(e,i,n)),o=po(Ne(e,i,t));return!!(s!==r&&a!==o||s===0&&fo(n,e,t)||r===0&&fo(n,i,t)||a===0&&fo(e,n,i)||o===0&&fo(e,t,i))}function fo(n,t,e){return t.x<=Math.max(n.x,e.x)&&t.x>=Math.min(n.x,e.x)&&t.y<=Math.max(n.y,e.y)&&t.y>=Math.min(n.y,e.y)}function po(n){return n>0?1:n<0?-1:0}function j_(n,t){let e=n;do{if(e.i!==n.i&&e.next.i!==n.i&&e.i!==t.i&&e.next.i!==t.i&&Md(e,e.next,n,t))return!0;e=e.next}while(e!==n);return!1}function da(n,t){return Ne(n.prev,n,n.next)<0?Ne(n,t,n.next)>=0&&Ne(n,n.prev,t)>=0:Ne(n,t,n.prev)<0||Ne(n,n.next,t)<0}function Q_(n,t){let e=n,i=!1,s=(n.x+t.x)/2,r=(n.y+t.y)/2;do e.y>r!=e.next.y>r&&e.next.y!==e.y&&s<(e.next.x-e.x)*(r-e.y)/(e.next.y-e.y)+e.x&&(i=!i),e=e.next;while(e!==n);return i}function Ed(n,t){let e=new Wl(n.i,n.x,n.y),i=new Wl(t.i,t.x,t.y),s=n.next,r=t.prev;return n.next=t,t.prev=n,e.next=s,s.prev=e,i.next=e,e.prev=i,r.next=i,i.prev=r,i}function Gf(n,t,e,i){let s=new Wl(n,t,e);return i?(s.next=i.next,s.prev=i,i.next.prev=s,i.next=s):(s.prev=s,s.next=s),s}function pa(n){n.next.prev=n.prev,n.prev.next=n.next,n.prevZ&&(n.prevZ.nextZ=n.nextZ),n.nextZ&&(n.nextZ.prevZ=n.prevZ)}function Wl(n,t,e){this.i=n,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function tv(n,t,e,i){let s=0;for(let r=t,a=e-i;r<e;r+=i)s+=(n[a]-n[r])*(n[r+1]+n[a+1]),a=r;return s}var jr=class n{static area(t){let e=t.length,i=0;for(let s=e-1,r=0;r<e;s=r++)i+=t[s].x*t[r].y-t[r].x*t[s].y;return i*.5}static isClockWise(t){return n.area(t)<0}static triangulateShape(t,e){let i=[],s=[],r=[];Vf(t),Wf(i,t);let a=t.length;e.forEach(Vf);for(let c=0;c<e.length;c++)s.push(a),a+=e[c].length,Wf(i,e[c]);let o=z_.triangulate(i,s);for(let c=0;c<o.length;c+=3)r.push(o.slice(c,c+3));return r}};function Vf(n){let t=n.length;t>2&&n[t-1].equals(n[0])&&n.pop()}function Wf(n,t){for(let e=0;e<t.length;e++)n.push(t[e].x),n.push(t[e].y)}var vs=class n extends Ie{constructor(t=new Qi([new ht(.5,.5),new ht(-.5,.5),new ht(-.5,-.5),new ht(.5,-.5)]),e={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];let i=this,s=[],r=[];for(let o=0,c=t.length;o<c;o++){let l=t[o];a(l)}this.setAttribute("position",new fe(s,3)),this.setAttribute("uv",new fe(r,2)),this.computeVertexNormals();function a(o){let c=[],l=e.curveSegments!==void 0?e.curveSegments:12,h=e.steps!==void 0?e.steps:1,u=e.depth!==void 0?e.depth:1,f=e.bevelEnabled!==void 0?e.bevelEnabled:!0,d=e.bevelThickness!==void 0?e.bevelThickness:.2,p=e.bevelSize!==void 0?e.bevelSize:d-.1,x=e.bevelOffset!==void 0?e.bevelOffset:0,g=e.bevelSegments!==void 0?e.bevelSegments:3,m=e.extrudePath,E=e.UVGenerator!==void 0?e.UVGenerator:ev,y,S=!1,P,w,A,F;m&&(y=m.getSpacedPoints(h),S=!0,f=!1,P=m.computeFrenetFrames(h,!1),w=new L,A=new L,F=new L),f||(g=0,d=0,p=0,x=0);let M=o.extractPoints(l),b=M.shape,R=M.holes;if(!jr.isClockWise(b)){b=b.reverse();for(let C=0,rt=R.length;C<rt;C++){let q=R[C];jr.isClockWise(q)&&(R[C]=q.reverse())}}let Z=jr.triangulateShape(b,R),I=b;for(let C=0,rt=R.length;C<rt;C++){let q=R[C];b=b.concat(q)}function N(C,rt,q){return rt||console.error("THREE.ExtrudeGeometry: vec does not exist"),C.clone().addScaledVector(rt,q)}let H=b.length,nt=Z.length;function B(C,rt,q){let et,K,Pt,_t=C.x-rt.x,v=C.y-rt.y,_=q.x-C.x,D=q.y-C.y,G=_t*_t+v*v,Y=_t*D-v*_;if(Math.abs(Y)>Number.EPSILON){let j=Math.sqrt(G),Tt=Math.sqrt(_*_+D*D),lt=rt.x-v/j,wt=rt.y+_t/j,zt=q.x-D/Tt,qt=q.y+_/Tt,ot=((zt-lt)*D-(qt-wt)*_)/(_t*D-v*_);et=lt+_t*ot-C.x,K=wt+v*ot-C.y;let ge=et*et+K*K;if(ge<=2)return new ht(et,K);Pt=Math.sqrt(ge/2)}else{let j=!1;_t>Number.EPSILON?_>Number.EPSILON&&(j=!0):_t<-Number.EPSILON?_<-Number.EPSILON&&(j=!0):Math.sign(v)===Math.sign(D)&&(j=!0),j?(et=-v,K=_t,Pt=Math.sqrt(G)):(et=_t,K=v,Pt=Math.sqrt(G/2))}return new ht(et/Pt,K/Pt)}let W=[];for(let C=0,rt=I.length,q=rt-1,et=C+1;C<rt;C++,q++,et++)q===rt&&(q=0),et===rt&&(et=0),W[C]=B(I[C],I[q],I[et]);let Q=[],tt,ut=W.concat();for(let C=0,rt=R.length;C<rt;C++){let q=R[C];tt=[];for(let et=0,K=q.length,Pt=K-1,_t=et+1;et<K;et++,Pt++,_t++)Pt===K&&(Pt=0),_t===K&&(_t=0),tt[et]=B(q[et],q[Pt],q[_t]);Q.push(tt),ut=ut.concat(tt)}for(let C=0;C<g;C++){let rt=C/g,q=d*Math.cos(rt*Math.PI/2),et=p*Math.sin(rt*Math.PI/2)+x;for(let K=0,Pt=I.length;K<Pt;K++){let _t=N(I[K],W[K],et);St(_t.x,_t.y,-q)}for(let K=0,Pt=R.length;K<Pt;K++){let _t=R[K];tt=Q[K];for(let v=0,_=_t.length;v<_;v++){let D=N(_t[v],tt[v],et);St(D.x,D.y,-q)}}}let J=p+x;for(let C=0;C<H;C++){let rt=f?N(b[C],ut[C],J):b[C];S?(A.copy(P.normals[0]).multiplyScalar(rt.x),w.copy(P.binormals[0]).multiplyScalar(rt.y),F.copy(y[0]).add(A).add(w),St(F.x,F.y,F.z)):St(rt.x,rt.y,0)}for(let C=1;C<=h;C++)for(let rt=0;rt<H;rt++){let q=f?N(b[rt],ut[rt],J):b[rt];S?(A.copy(P.normals[C]).multiplyScalar(q.x),w.copy(P.binormals[C]).multiplyScalar(q.y),F.copy(y[C]).add(A).add(w),St(F.x,F.y,F.z)):St(q.x,q.y,u/h*C)}for(let C=g-1;C>=0;C--){let rt=C/g,q=d*Math.cos(rt*Math.PI/2),et=p*Math.sin(rt*Math.PI/2)+x;for(let K=0,Pt=I.length;K<Pt;K++){let _t=N(I[K],W[K],et);St(_t.x,_t.y,u+q)}for(let K=0,Pt=R.length;K<Pt;K++){let _t=R[K];tt=Q[K];for(let v=0,_=_t.length;v<_;v++){let D=N(_t[v],tt[v],et);S?St(D.x,D.y+y[h-1].y,y[h-1].x+q):St(D.x,D.y,u+q)}}}it(),dt();function it(){let C=s.length/3;if(f){let rt=0,q=H*rt;for(let et=0;et<nt;et++){let K=Z[et];Ht(K[2]+q,K[1]+q,K[0]+q)}rt=h+g*2,q=H*rt;for(let et=0;et<nt;et++){let K=Z[et];Ht(K[0]+q,K[1]+q,K[2]+q)}}else{for(let rt=0;rt<nt;rt++){let q=Z[rt];Ht(q[2],q[1],q[0])}for(let rt=0;rt<nt;rt++){let q=Z[rt];Ht(q[0]+H*h,q[1]+H*h,q[2]+H*h)}}i.addGroup(C,s.length/3-C,0)}function dt(){let C=s.length/3,rt=0;It(I,rt),rt+=I.length;for(let q=0,et=R.length;q<et;q++){let K=R[q];It(K,rt),rt+=K.length}i.addGroup(C,s.length/3-C,1)}function It(C,rt){let q=C.length;for(;--q>=0;){let et=q,K=q-1;K<0&&(K=C.length-1);for(let Pt=0,_t=h+g*2;Pt<_t;Pt++){let v=H*Pt,_=H*(Pt+1),D=rt+et+v,G=rt+K+v,Y=rt+K+_,j=rt+et+_;st(D,G,Y,j)}}}function St(C,rt,q){c.push(C),c.push(rt),c.push(q)}function Ht(C,rt,q){ct(C),ct(rt),ct(q);let et=s.length/3,K=E.generateTopUV(i,s,et-3,et-2,et-1);xt(K[0]),xt(K[1]),xt(K[2])}function st(C,rt,q,et){ct(C),ct(rt),ct(et),ct(rt),ct(q),ct(et);let K=s.length/3,Pt=E.generateSideWallUV(i,s,K-6,K-3,K-2,K-1);xt(Pt[0]),xt(Pt[1]),xt(Pt[3]),xt(Pt[1]),xt(Pt[2]),xt(Pt[3])}function ct(C){s.push(c[C*3+0]),s.push(c[C*3+1]),s.push(c[C*3+2])}function xt(C){r.push(C.x),r.push(C.y)}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes,i=this.parameters.options;return nv(e,i,t)}static fromJSON(t,e){let i=[];for(let r=0,a=t.shapes.length;r<a;r++){let o=e[t.shapes[r]];i.push(o)}let s=t.options.extrudePath;return s!==void 0&&(t.options.extrudePath=new kl[s.type]().fromJSON(s)),new n(i,t.options)}},ev={generateTopUV:function(n,t,e,i,s){let r=t[e*3],a=t[e*3+1],o=t[i*3],c=t[i*3+1],l=t[s*3],h=t[s*3+1];return[new ht(r,a),new ht(o,c),new ht(l,h)]},generateSideWallUV:function(n,t,e,i,s,r){let a=t[e*3],o=t[e*3+1],c=t[e*3+2],l=t[i*3],h=t[i*3+1],u=t[i*3+2],f=t[s*3],d=t[s*3+1],p=t[s*3+2],x=t[r*3],g=t[r*3+1],m=t[r*3+2];return Math.abs(o-h)<Math.abs(a-l)?[new ht(a,1-c),new ht(l,1-u),new ht(f,1-p),new ht(x,1-m)]:[new ht(o,1-c),new ht(h,1-u),new ht(d,1-p),new ht(g,1-m)]}};function nv(n,t,e){if(e.shapes=[],Array.isArray(n))for(let i=0,s=n.length;i<s;i++){let r=n[i];e.shapes.push(r.uuid)}else e.shapes.push(n.uuid);return e.options=Object.assign({},t),t.extrudePath!==void 0&&(e.options.extrudePath=t.extrudePath.toJSON()),e}var mr=class n extends Vo{constructor(t=1,e=0){let i=(1+Math.sqrt(5))/2,s=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new n(t.radius,t.detail)}},gr=class n extends Vo{constructor(t=1,e=0){let i=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(i,s,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new n(t.radius,t.detail)}},ma=class n extends Ie{constructor(t=.5,e=1,i=32,s=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:i,phiSegments:s,thetaStart:r,thetaLength:a},i=Math.max(3,i),s=Math.max(1,s);let o=[],c=[],l=[],h=[],u=t,f=(e-t)/s,d=new L,p=new ht;for(let x=0;x<=s;x++){for(let g=0;g<=i;g++){let m=r+g/i*a;d.x=u*Math.cos(m),d.y=u*Math.sin(m),c.push(d.x,d.y,d.z),l.push(0,0,1),p.x=(d.x/e+1)/2,p.y=(d.y/e+1)/2,h.push(p.x,p.y)}u+=f}for(let x=0;x<s;x++){let g=x*(i+1);for(let m=0;m<i;m++){let E=m+g,y=E,S=E+i+1,P=E+i+2,w=E+1;o.push(y,S,w),o.push(S,P,w)}}this.setIndex(o),this.setAttribute("position",new fe(c,3)),this.setAttribute("normal",new fe(l,3)),this.setAttribute("uv",new fe(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}};var de=class n extends Ie{constructor(t=1,e=32,i=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:i,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),i=Math.max(2,Math.floor(i));let c=Math.min(a+o,Math.PI),l=0,h=[],u=new L,f=new L,d=[],p=[],x=[],g=[];for(let m=0;m<=i;m++){let E=[],y=m/i,S=0;m===0&&a===0?S=.5/e:m===i&&c===Math.PI&&(S=-.5/e);for(let P=0;P<=e;P++){let w=P/e;u.x=-t*Math.cos(s+w*r)*Math.sin(a+y*o),u.y=t*Math.cos(a+y*o),u.z=t*Math.sin(s+w*r)*Math.sin(a+y*o),p.push(u.x,u.y,u.z),f.copy(u).normalize(),x.push(f.x,f.y,f.z),g.push(w+S,1-y),E.push(l++)}h.push(E)}for(let m=0;m<i;m++)for(let E=0;E<e;E++){let y=h[m][E+1],S=h[m][E],P=h[m+1][E],w=h[m+1][E+1];(m!==0||a>0)&&d.push(y,S,w),(m!==i-1||c<Math.PI)&&d.push(S,P,w)}this.setIndex(d),this.setAttribute("position",new fe(p,3)),this.setAttribute("normal",new fe(x,3)),this.setAttribute("uv",new fe(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var xr=class n extends Ie{constructor(t=1,e=.4,i=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:i,tubularSegments:s,arc:r},i=Math.floor(i),s=Math.floor(s);let a=[],o=[],c=[],l=[],h=new L,u=new L,f=new L;for(let d=0;d<=i;d++)for(let p=0;p<=s;p++){let x=p/s*r,g=d/i*Math.PI*2;u.x=(t+e*Math.cos(g))*Math.cos(x),u.y=(t+e*Math.cos(g))*Math.sin(x),u.z=e*Math.sin(g),o.push(u.x,u.y,u.z),h.x=t*Math.cos(x),h.y=t*Math.sin(x),f.subVectors(u,h).normalize(),c.push(f.x,f.y,f.z),l.push(p/s),l.push(d/i)}for(let d=1;d<=i;d++)for(let p=1;p<=s;p++){let x=(s+1)*d+p-1,g=(s+1)*(d-1)+p-1,m=(s+1)*(d-1)+p,E=(s+1)*d+p;a.push(x,g,E),a.push(g,m,E)}this.setIndex(a),this.setAttribute("position",new fe(o,3)),this.setAttribute("normal",new fe(c,3)),this.setAttribute("uv",new fe(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}};var ee=class extends Ai{constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new Ft(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ft(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=ad,this.normalScale=new ht(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}};function mo(n,t,e){return!n||!e&&n.constructor===t?n:typeof t.BYTES_PER_ELEMENT=="number"?new t(n):Array.prototype.slice.call(n)}function iv(n){return ArrayBuffer.isView(n)&&!(n instanceof DataView)}var yr=class{constructor(t,e,i,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(i),this.sampleValues=e,this.valueSize=i,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,i=this._cachedIndex,s=e[i],r=e[i-1];n:{t:{let a;e:{i:if(!(t<s)){for(let o=i+2;;){if(s===void 0){if(t<r)break i;return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)}if(i===o)break;if(r=s,s=e[++i],t<s)break t}a=e.length;break e}if(!(t>=r)){let o=e[1];t<o&&(i=2,r=o);for(let c=i-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===c)break;if(s=r,r=e[--i-1],t>=r)break t}a=i,i=0;break e}break n}for(;i<a;){let o=i+a>>>1;t<e[o]?a=o:i=o+1}if(s=e[i],r=e[i-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)}this._cachedIndex=i,this.intervalChanged_(i,r,s)}return this.interpolate_(i,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,i=this.sampleValues,s=this.valueSize,r=t*s;for(let a=0;a!==s;++a)e[a]=i[r+a];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},Xl=class extends yr{constructor(t,e,i,s){super(t,e,i,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Xu,endingEnd:Xu}}intervalChanged_(t,e,i){let s=this.parameterPositions,r=t-2,a=t+1,o=s[r],c=s[a];if(o===void 0)switch(this.getSettings_().endingStart){case Yu:r=t,o=2*e-i;break;case $u:r=s.length-2,o=e+s[r]-s[r+1];break;default:r=t,o=i}if(c===void 0)switch(this.getSettings_().endingEnd){case Yu:a=t,c=2*i-e;break;case $u:a=1,c=i+s[1]-s[0];break;default:a=t-1,c=e}let l=(i-e)*.5,h=this.valueSize;this._weightPrev=l/(e-o),this._weightNext=l/(c-i),this._offsetPrev=r*h,this._offsetNext=a*h}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=t*o,l=c-o,h=this._offsetPrev,u=this._offsetNext,f=this._weightPrev,d=this._weightNext,p=(i-e)/(s-e),x=p*p,g=x*p,m=-f*g+2*f*x-f*p,E=(1+f)*g+(-1.5-2*f)*x+(-.5+f)*p+1,y=(-1-d)*g+(1.5+d)*x+.5*p,S=d*g-d*x;for(let P=0;P!==o;++P)r[P]=m*a[h+P]+E*a[l+P]+y*a[c+P]+S*a[u+P];return r}},Yl=class extends yr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=t*o,l=c-o,h=(i-e)/(s-e),u=1-h;for(let f=0;f!==o;++f)r[f]=a[l+f]*u+a[c+f]*h;return r}},$l=class extends yr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t){return this.copySampleValue_(t-1)}},ei=class{constructor(t,e,i,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=mo(e,this.TimeBufferType),this.values=mo(i,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,i;if(e.toJSON!==this.toJSON)i=e.toJSON(t);else{i={name:t.name,times:mo(t.times,Array),values:mo(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(i.interpolation=s)}return i.type=t.ValueTypeName,i}InterpolantFactoryMethodDiscrete(t){return new $l(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new Yl(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new Xl(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case xo:e=this.InterpolantFactoryMethodDiscrete;break;case yo:e=this.InterpolantFactoryMethodLinear;break;case zc:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let i="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(i);return console.warn("THREE.KeyframeTrack:",i),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return xo;case this.InterpolantFactoryMethodLinear:return yo;case this.InterpolantFactoryMethodSmooth:return zc}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let i=0,s=e.length;i!==s;++i)e[i]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let i=0,s=e.length;i!==s;++i)e[i]*=t}return this}trim(t,e){let i=this.times,s=i.length,r=0,a=s-1;for(;r!==s&&i[r]<t;)++r;for(;a!==-1&&i[a]>e;)--a;if(++a,r!==0||a!==s){r>=a&&(a=Math.max(a,1),r=a-1);let o=this.getValueSize();this.times=i.slice(r,a),this.values=this.values.slice(r*o,a*o)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let i=this.times,s=this.values,r=i.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let a=null;for(let o=0;o!==r;o++){let c=i[o];if(typeof c=="number"&&isNaN(c)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,c),t=!1;break}if(a!==null&&a>c){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,c,a),t=!1;break}a=c}if(s!==void 0&&iv(s))for(let o=0,c=s.length;o!==c;++o){let l=s[o];if(isNaN(l)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,l),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),i=this.getValueSize(),s=this.getInterpolation()===zc,r=t.length-1,a=1;for(let o=1;o<r;++o){let c=!1,l=t[o],h=t[o+1];if(l!==h&&(o!==1||l!==t[0]))if(s)c=!0;else{let u=o*i,f=u-i,d=u+i;for(let p=0;p!==i;++p){let x=e[u+p];if(x!==e[f+p]||x!==e[d+p]){c=!0;break}}}if(c){if(o!==a){t[a]=t[o];let u=o*i,f=a*i;for(let d=0;d!==i;++d)e[f+d]=e[u+d]}++a}}if(r>0){t[a]=t[r];for(let o=r*i,c=a*i,l=0;l!==i;++l)e[c+l]=e[o+l];++a}return a!==t.length?(this.times=t.slice(0,a),this.values=e.slice(0,a*i)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),i=this.constructor,s=new i(this.name,t,e);return s.createInterpolant=this.createInterpolant,s}};ei.prototype.TimeBufferType=Float32Array;ei.prototype.ValueBufferType=Float32Array;ei.prototype.DefaultInterpolation=yo;var Ms=class extends ei{};Ms.prototype.ValueTypeName="bool";Ms.prototype.ValueBufferType=Array;Ms.prototype.DefaultInterpolation=xo;Ms.prototype.InterpolantFactoryMethodLinear=void 0;Ms.prototype.InterpolantFactoryMethodSmooth=void 0;var ql=class extends ei{};ql.prototype.ValueTypeName="color";var Zl=class extends ei{};Zl.prototype.ValueTypeName="number";var Jl=class extends yr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=(i-e)/(s-e),l=t*o;for(let h=l+o;l!==h;l+=4)fi.slerpFlat(r,0,a,l-o,a,l,c);return r}},ga=class extends ei{InterpolantFactoryMethodLinear(t){return new Jl(this.times,this.values,this.getValueSize(),t)}};ga.prototype.ValueTypeName="quaternion";ga.prototype.DefaultInterpolation=yo;ga.prototype.InterpolantFactoryMethodSmooth=void 0;var Es=class extends ei{};Es.prototype.ValueTypeName="string";Es.prototype.ValueBufferType=Array;Es.prototype.DefaultInterpolation=xo;Es.prototype.InterpolantFactoryMethodLinear=void 0;Es.prototype.InterpolantFactoryMethodSmooth=void 0;var Kl=class extends ei{};Kl.prototype.ValueTypeName="vector";var jl=class{constructor(t,e,i){let s=this,r=!1,a=0,o=0,c,l=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=i,this.itemStart=function(h){o++,r===!1&&s.onStart!==void 0&&s.onStart(h,a,o),r=!0},this.itemEnd=function(h){a++,s.onProgress!==void 0&&s.onProgress(h,a,o),a===o&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return c?c(h):h},this.setURLModifier=function(h){return c=h,this},this.addHandler=function(h,u){return l.push(h,u),this},this.removeHandler=function(h){let u=l.indexOf(h);return u!==-1&&l.splice(u,2),this},this.getHandler=function(h){for(let u=0,f=l.length;u<f;u+=2){let d=l[u],p=l[u+1];if(d.global&&(d.lastIndex=0),d.test(h))return p}return null}}},sv=new jl,Ql=class{constructor(t){this.manager=t!==void 0?t:sv,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let i=this;return new Promise(function(s,r){i.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};Ql.DEFAULT_MATERIAL_NAME="__DEFAULT";var Wo=class extends Ze{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Ft(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}},Xo=class extends Wo{constructor(t,e,i){super(t,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Ze.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ft(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},ul=new Ce,Xf=new L,Yf=new L,th=class{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new ht(512,512),this.map=null,this.mapPass=null,this.matrix=new Ce,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new ra,this._frameExtents=new ht(1,1),this._viewportCount=1,this._viewports=[new We(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,i=this.matrix;Xf.setFromMatrixPosition(t.matrixWorld),e.position.copy(Xf),Yf.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Yf),e.updateMatrixWorld(),ul.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ul),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(ul)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var eh=class extends th{constructor(){super(new Lo(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Yo=class extends Wo{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Ze.DEFAULT_UP),this.updateMatrix(),this.target=new Ze,this.shadow=new eh}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var $o=class{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=$f(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let e=$f();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}};function $f(){return(typeof performance>"u"?Date:performance).now()}var fh="\\[\\]\\.:\\/",rv=new RegExp("["+fh+"]","g"),dh="[^"+fh+"]",av="[^"+fh.replace("\\.","")+"]",ov=/((?:WC+[\/:])*)/.source.replace("WC",dh),cv=/(WCOD+)?/.source.replace("WCOD",av),lv=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",dh),hv=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",dh),uv=new RegExp("^"+ov+cv+lv+hv+"$"),fv=["material","materials","bones","map"],nh=class{constructor(t,e,i){let s=i||De.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let i=this._targetGroup.nCachedObjects_,s=this._bindings[i];s!==void 0&&s.getValue(t,e)}setValue(t,e){let i=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=i.length;s!==r;++s)i[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,i=t.length;e!==i;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,i=t.length;e!==i;++e)t[e].unbind()}},De=class n{constructor(t,e,i){this.path=e,this.parsedPath=i||n.parseTrackName(e),this.node=n.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,i){return t&&t.isAnimationObjectGroup?new n.Composite(t,e,i):new n(t,e,i)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(rv,"")}static parseTrackName(t){let e=uv.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let i={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=i.nodeName&&i.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=i.nodeName.substring(s+1);fv.indexOf(r)!==-1&&(i.nodeName=i.nodeName.substring(0,s),i.objectName=r)}if(i.propertyName===null||i.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return i}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let i=t.skeleton.getBoneByName(e);if(i!==void 0)return i}if(t.children){let i=function(r){for(let a=0;a<r.length;a++){let o=r[a];if(o.name===e||o.uuid===e)return o;let c=i(o.children);if(c)return c}return null},s=i(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)t[e++]=i[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,i=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=n.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(i){let l=e.objectIndex;switch(i){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===l){l=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[i]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[i]}if(l!==void 0){if(t[l]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[l]}}let a=t[s];if(a===void 0){let l=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+l+"."+s+" but it wasn't found.",t);return}let o=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}c=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=r}else a.fromArray!==void 0&&a.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(c=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=s;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};De.Composite=nh;De.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};De.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};De.prototype.GetterByBindingType=[De.prototype._getValue_direct,De.prototype._getValue_array,De.prototype._getValue_arrayElement,De.prototype._getValue_toArray];De.prototype.SetterByBindingTypeAndVersioning=[[De.prototype._setValue_direct,De.prototype._setValue_direct_setNeedsUpdate,De.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[De.prototype._setValue_array,De.prototype._setValue_array_setNeedsUpdate,De.prototype._setValue_array_setMatrixWorldNeedsUpdate],[De.prototype._setValue_arrayElement,De.prototype._setValue_arrayElement_setNeedsUpdate,De.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[De.prototype._setValue_fromArray,De.prototype._setValue_fromArray_setNeedsUpdate,De.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var GM=new Float32Array(1);var qo=class{constructor(t,e,i=0,s=1/0){this.ray=new ia(t,e),this.near=i,this.far=s,this.camera=null,this.layers=new sa,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):console.error("THREE.Raycaster: Unsupported camera type: "+e.type)}intersectObject(t,e=!0,i=[]){return ih(t,this,i,e),i.sort(qf),i}intersectObjects(t,e=!0,i=[]){for(let s=0,r=t.length;s<r;s++)ih(t[s],this,i,e);return i.sort(qf),i}};function qf(n,t){return n.distance-t.distance}function ih(n,t,e,i){if(n.layers.test(t.layers)&&n.raycast(t,e),i===!0){let s=n.children;for(let r=0,a=s.length;r<a;r++)ih(s[r],t,e,!0)}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:sh}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=sh);var ft=n=>document.getElementById(n),ce=(n,t,e)=>Math.max(t,Math.min(e,n)),Fe=(n,t,e)=>n+(t-n)*e,Ot=(n,t,e)=>{let i=ce((e-n)/(t-n),0,1);return i*i*(3-2*i)},ws=(n,t,e)=>Math.exp(-(((n-t)/e)**2)),xh=n=>(n%=Math.PI*2,n>Math.PI&&(n-=Math.PI*2),n<-Math.PI&&(n+=Math.PI*2),n),ec=1,Yt=()=>(ec=ec*16807%2147483647,(ec-1)/2147483646),Ut=(n,t)=>n+Yt()*(t-n);function Er(n,t,e){let i=Math.imul(n|0,374761393)^Math.imul(t|0,668265263)^Math.imul(e|0,1442695041);return i=Math.imul(i^i>>>13,1274126177),i^=i>>>16,(i>>>0)/4294967296}function Ni(n,t,e,i){let s=Math.floor(n),r=Math.floor(t),a=n-s,o=t-r,c=a*a*(3-2*a),l=o*o*(3-2*o),h=x=>e?(x%e+e)%e:x,u=Er(h(s),h(r),i),f=Er(h(s+1),h(r),i),d=Er(h(s),h(r+1),i),p=Er(h(s+1),h(r+1),i);return Fe(Fe(u,f,c),Fe(d,p,c),l)}function Li(n,t,e=4,i=0,s=0){let r=.5,a=1,o=0,c=0;for(let l=0;l<e;l++)o+=r*Ni(n*a,t*a,i?i*a:0,s+l*17),c+=r,r*=.5,a*=2;return o/c}var La="ontouchstart"in window||navigator.maxTouchPoints>0;La&&document.body.classList.add("touch");var Fh="corridaCaninaTurbo1",k={musicMode:0,vib:!0,voice:!0,mode:0,owned:[],looks:{},stats:{},ach:[],daily:null,trophies:{},coins:400,up:{},best:{},dog:0,track:0,diff:1,laps:3,qual:La?1:2,music:!0,cam:0,assist:!0};try{Object.assign(k,JSON.parse(localStorage.getItem(Fh)||"{}"))}catch{}k.music===!1&&k.musicMode===0&&!("musicMode"in JSON.parse((()=>{try{return localStorage.getItem(Fh)||"{}"}catch{return"{}"}})()))&&(k.musicMode=4);function Qe(){try{localStorage.setItem(Fh,JSON.stringify(k))}catch{}}var qn=new aa({canvas:ft("game"),antialias:!0,powerPreference:"high-performance"});qn.outputColorSpace=be;qn.toneMapping=ah;qn.shadowMap.enabled=!0;qn.shadowMap.type=rh;var pv=Math.min(8,qn.capabilities.getMaxAnisotropy()),rn=new oa,ye=new vn(66,1,.2,2600),ac=new Xo(16777215,5596740,.4);rn.add(ac);var Sn=new Yo(16777215,3);Sn.castShadow=!0;Object.assign(Sn.shadow.camera,{left:-42,right:42,top:42,bottom:-42,near:1,far:340});Sn.shadow.bias=-4e-4;Sn.shadow.normalBias=.05;rn.add(Sn,Sn.target);var yh=new L(.4,.6,.3).normalize(),bs={zen:{value:new Ft},hor:{value:new Ft},gnd:{value:new Ft},sunCol:{value:new Ft},sunDir:{value:new L},haze:{value:.5}},Ud=new Vn({uniforms:bs,side:dn,depthWrite:!1,fog:!1,vertexShader:"varying vec3 vD; void main(){ vD = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }",fragmentShader:`uniform vec3 zen, hor, gnd, sunCol, sunDir; uniform float haze; varying vec3 vD;
    void main(){
      vec3 d = normalize(vD); float h = d.y;
      vec3 c = h > 0.0 ? mix(hor, zen, pow(h, 0.5)) : mix(hor, gnd, pow(min(-h * 3.0, 1.0), 0.7));
      float sd = max(dot(d, normalize(sunDir)), 0.0);
      c += sunCol * (pow(sd, 900.0) * 14.0 + pow(sd, 40.0) * 0.45 * haze + pow(sd, 5.0) * 0.22 * haze * (1.0 - max(h, 0.0)));
      gl_FragColor = vec4(c, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`}),yc=new bt(new de(1e3,32,16),Ud);yc.frustumCulled=!1;yc.renderOrder=-10;rn.add(yc);var mv=new pr(qn),Tr=null;function gv(){let n=new oa;n.add(new bt(new de(50,32,16),Ud)),Tr&&Tr.dispose(),Tr=mv.fromScene(n,.02,.1,200),Od()}function Od(){let n=k.qual===0;rn.environment=n?null:Tr&&Tr.texture,ac.intensity=yt.light.hemi+(n?1.1:0)}var zh=[{n:"BAIXA",pr:.75,sh:0},{n:"M\xC9DIA",pr:1.25,sh:1024},{n:"ALTA",pr:2,sh:2048}];function Nd(){let n=zh[k.qual];qn.setPixelRatio(Math.min(devicePixelRatio,n.pr)),qn.shadowMap.enabled=n.sh>0,Sn.castShadow=n.sh>0,n.sh&&(Sn.shadow.mapSize.set(n.sh,n.sh),Sn.shadow.map&&(Sn.shadow.map.dispose(),Sn.shadow.map=null)),Tr&&Od(),rn.traverse(t=>{t.material&&[].concat(t.material).forEach(e=>e.needsUpdate=!0)}),Fd()}function Fd(){qn.setSize(innerWidth,innerHeight,!1),ye.aspect=innerWidth/innerHeight,ye.updateProjectionMatrix()}addEventListener("resize",Fd);function Bh(n,t){let e=document.createElement("canvas");e.width=e.height=n;let i=e.getContext("2d"),s=i.createImageData(n,n),r=s.data;for(let a=0;a<n;a++)for(let o=0;o<n;o++){let c=t(o,a),l=(a*n+o)*4;r[l]=c[0],r[l+1]=c[1],r[l+2]=c[2],r[l+3]=c[3]??255}return i.putImageData(s,0,0),e}function an(n,t=1,e=1,i=!0){let s=new ti(n);return i&&(s.colorSpace=be),s.wrapS=s.wrapT=Qr,s.repeat.set(t,e),s.anisotropy=pv,s}function Ge(n,t,e){let i=document.createElement("canvas");return i.width=n,i.height=t,e(i.getContext("2d"),n,t),i}var zd=(()=>{let n=Ge(256,256,(t,e,i)=>{t.fillStyle="#ececec",t.fillRect(0,0,e,i);for(let s=0;s<9e3;s++){let r=Math.random()*e,a=Math.random()*i,o=3+Math.random()*8,c=185+Math.random()*70|0;t.strokeStyle=`rgba(${c},${c},${c},.55)`,t.lineWidth=.7+Math.random()*.8,t.beginPath(),t.moveTo(r,a),t.lineTo(r+(Math.random()-.5)*2,a+o),t.stroke()}});return an(n,2,2)})(),wa=new ti(Ge(64,64,n=>{let t=n.createRadialGradient(32,32,2,32,32,32);t.addColorStop(0,"rgba(0,0,0,.6)"),t.addColorStop(1,"rgba(0,0,0,0)"),n.fillStyle=t,n.fillRect(0,0,64,64)})),Hh=new ti(Ge(64,64,n=>{let t=n.createRadialGradient(32,32,0,32,32,32);t.addColorStop(0,"rgba(255,255,255,1)"),t.addColorStop(.4,"rgba(255,255,255,.6)"),t.addColorStop(1,"rgba(255,255,255,0)"),n.fillStyle=t,n.fillRect(0,0,64,64)})),oc=class{constructor(t,e){this.max=t,this.n=0,this.pos=new Float32Array(t*3),this.col=new Float32Array(t*3),this.size=new Float32Array(t),this.alpha=new Float32Array(t),this.vel=new Float32Array(t*3),this.life=new Float32Array(t),this.ml=new Float32Array(t),this.s0=new Float32Array(t),this.s1=new Float32Array(t),this.a0=new Float32Array(t),this.grav=new Float32Array(t),this.drag=new Float32Array(t);let i=new Ie,s=(r,a)=>{let o=new me(r,a);return o.setUsage(cd),o};i.setAttribute("position",s(this.pos,3)),i.setAttribute("pcolor",s(this.col,3)),i.setAttribute("psize",s(this.size,1)),i.setAttribute("palpha",s(this.alpha,1)),this.geo=i,this.mat=new Vn({uniforms:{uScale:{value:500},map:{value:Hh}},vertexShader:`attribute vec3 pcolor; attribute float psize; attribute float palpha; uniform float uScale; varying vec3 vC; varying float vA;
        void main(){ vC = pcolor; vA = palpha; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_PointSize = psize * uScale / max(0.1, -mv.z); gl_Position = projectionMatrix * mv; }`,fragmentShader:`uniform sampler2D map; varying vec3 vC; varying float vA;
        void main(){ float a = texture2D(map, gl_PointCoord).a * vA; if (a < 0.01) discard; gl_FragColor = vec4(vC, a); }`,transparent:!0,depthWrite:!1,blending:e?Zi:Xi}),this.points=new la(i,this.mat),this.points.frustumCulled=!1,rn.add(this.points)}spawn(t,e,i,s,r,a,o,c,l,h,u=1,f=0,d=1){if(this.n>=this.max)return;let p=this.n++,x=p*3;this.pos[x]=t,this.pos[x+1]=e,this.pos[x+2]=i,this.vel[x]=s,this.vel[x+1]=r,this.vel[x+2]=a,this.col[x]=h[0],this.col[x+1]=h[1],this.col[x+2]=h[2],this.life[p]=this.ml[p]=o,this.s0[p]=c,this.s1[p]=l,this.a0[p]=u,this.grav[p]=f,this.drag[p]=d,this.size[p]=c,this.alpha[p]=0}copy(t,e){for(let i=0;i<3;i++)this.pos[t*3+i]=this.pos[e*3+i],this.vel[t*3+i]=this.vel[e*3+i],this.col[t*3+i]=this.col[e*3+i];this.life[t]=this.life[e],this.ml[t]=this.ml[e],this.s0[t]=this.s0[e],this.s1[t]=this.s1[e],this.a0[t]=this.a0[e],this.grav[t]=this.grav[e],this.drag[t]=this.drag[e],this.size[t]=this.size[e],this.alpha[t]=this.alpha[e]}update(t){for(let e=0;e<this.n;e++){if(this.life[e]-=t,this.life[e]<=0){this.n--,e<this.n&&(this.copy(e,this.n),e--);continue}let i=e*3,s=Math.exp(-this.drag[e]*t);this.vel[i]*=s,this.vel[i+1]=this.vel[i+1]*s-this.grav[e]*t,this.vel[i+2]*=s,this.pos[i]+=this.vel[i]*t,this.pos[i+1]+=this.vel[i+1]*t,this.pos[i+2]+=this.vel[i+2]*t,this.pos[i+1]<.02&&(this.pos[i+1]=.02,this.vel[i+1]*=-.3);let r=1-this.life[e]/this.ml[e];this.size[e]=Fe(this.s0[e],this.s1[e],r),this.alpha[e]=this.a0[e]*Math.min(1,r*10)*(1-r)}this.geo.setDrawRange(0,this.n);for(let e of["position","pcolor","psize","palpha"])this.geo.attributes[e].needsUpdate=!0;this.mat.uniforms.uScale.value=qn.domElement.height/(2*Math.tan(ld.degToRad(ye.fov)/2))}clear(){this.n=0}},oi=new oc(1400,!1),bn=new oc(1200,!0);function Rs(n,t){let e=Math.abs(2*n-1);return Math.pow(Math.max(0,1-Math.pow(e,t)),1/t)}function Ln(n,t,e){let i=new Float32Array((n+1)*t*3),s=new Float32Array((n+1)*t*2),r=[],a=0,o=0;for(let l=0;l<=n;l++){let h=l/n;for(let u=0;u<t;u++){let f=e(h,u/t*Math.PI*2);i[a++]=f[0],i[a++]=f[1],i[a++]=f[2],s[o++]=u/t*2,s[o++]=h*2}}for(let l=0;l<n;l++)for(let h=0;h<t;h++){let u=l*t+h,f=l*t+(h+1)%t,d=u+t,p=f+t;r.push(u,f,d,f,p,d)}let c=new Ie;return c.setAttribute("position",new me(i,3)),c.setAttribute("uv",new me(s,2)),c.setIndex(r),c.computeVertexNormals(),c}function va(n,t,e,i=1){let s=Math.min(t,e)*.8,r=Ln(10,12,(a,o)=>{let c=Fe(t,e,a)*Rs(a,4);return[Math.cos(o)*c,Math.sin(o)*c*i,-s+a*(n+2*s)]});return r.rotateX(Math.PI/2),r}function Di(n,t,e,i=14){let s=new de(1,i,Math.round(i*.75));return s.scale(n,t,e),s}function vr(n,t,e,i=1){let s=Rs(t,2.4),r=Ot(.3,.85,t),a=Fe(n.rumpW,n.chW,r),o=Fe(n.rumpH,n.chH,r),c=Math.sin(e),l=Math.cos(e),h=c*o*s;return c<0?h*=1-n.waist*ws(t,.36,.2):h+=n.arch*ws(t,.38,.22)*s,[l*a*s*i,Fe(n.rumpY,0,r)+h*i,(t-.5)*n.len]}function ph(n,t){let[e,i,s]=n.skull,[r,a,o,c]=n.muzzle,l=e*.5,h=l+r,u=Math.sqrt(Math.max(0,1-(t/e)**2)),f=1;t>l&&(f=Math.pow(Math.max(0,1-Math.pow((t-l)/r,3)),1/3));let d=Ot(-e*.6,l,t);return{w:Math.max(i*u,a*f*d),h:Math.max(s*u,o*f*d),yc:-c*Ot(l-.03,l+.05,t),zStop:l,zEnd:Math.max(h,e)}}var le=n=>new Ft(n),Xn={shepherd:{base:le(12615482),dark:le(2037779),light:le(14726010)},dalmatian:{base:le(15855592),dark:le(1446671)},caramel:{base:le(12611626),dark:le(7224597),light:le(15782042)},grey:{base:le(8160401),light:le(15856110)},husky:{base:le(4673373),dark:le(2764600),light:le(15921904)},pug:{base:le(14003058),dark:le(2235674),light:le(15255958)},pinscher:{base:le(1446158),light:le(11097887)},pitbull:{base:le(9987647),light:le(15986406),dark:le(7226663)},boar:{base:le(5061936),dark:le(2366228),light:le(8152916),hoof:le(1446157)},opossum:{base:le(8552314),light:le(15526111),dark:le(2235675),pink:le(15321026)},gecko:{base:le(15778634),dark:le(2760469),light:le(16116952),band:le(14272488)},tegu:{base:le(1250067),light:le(15526367),belly:le(14210508)}};function Bd(n,t,e){let i=t.cy,s=t.part==="head"?Ot(t.zStop-.03,t.zStop+.05,t.lz):0;switch(n.coat){case"shepherd":{let r=Xn.shepherd;if(t.part==="ear")return e.copy(r.dark);if(t.part==="head"){let a=Ot(.01,.07,t.ly)*Ot(t.zStop+.02,t.zStop-.05,t.lz);return e.copy(r.base).lerp(r.dark,Math.max(s*.9,a*.65))}if(t.part==="body"){let a=Ot(i,i+.08,t.y)*Ot(n.len/2,n.len/2-.22,t.z);return e.copy(r.base).lerp(r.light,Ot(i-n.chH*.2,i-n.chH*.8,t.y)*.6),e.lerp(r.dark,a)}return t.part==="neck"?e.copy(r.base).lerp(r.dark,Ot(0,.05,t.ly)*.6):t.part==="tail"?e.copy(r.base).lerp(r.dark,.72):e.copy(r.base)}case"dalmatian":{let r=Xn.dalmatian;if(t.part==="ear")return e.copy(r.dark).lerp(r.base,.1);for(let a of t.spots){let o=t.x-a[0],c=t.y-a[1],l=t.z-a[2];if(o*o+c*c+l*l<a[3]*a[3])return e.copy(r.dark)}return e.copy(r.base)}case"caramel":{let r=Xn.caramel;if(t.part==="ear")return e.copy(r.base).lerp(r.dark,.35);if(t.part==="head")return e.copy(r.base).lerp(r.light,Math.max(s*.75,Ot(0,-.035,t.ly)*.7));if(t.part==="body"){let a=Ot(i-n.chH*.1,i-n.chH*.7,t.y),o=Ot(n.len/2-.2,n.len/2-.05,t.z)*Ot(i+n.chH*.2,i-n.chH*.2,t.y);return e.copy(r.base).lerp(r.light,Math.max(a,o)*.85)}return t.part==="neck"?e.copy(r.base).lerp(r.light,Ot(0,-.03,t.ly)*.8):t.part==="paw"||t.part==="leg"&&t.seg>=2?e.copy(r.light):t.part==="tail"?e.copy(r.base).lerp(r.light,t.seg===3?.8:0):e.copy(r.base)}case"grey":{let r=Xn.grey;return t.part==="body"?e.copy(r.base).lerp(r.light,Ot(n.len/2-.22,n.len/2-.08,t.z)*Ot(i+n.chH*.1,i-n.chH*.3,t.y)*.9):t.part==="neck"?e.copy(r.base).lerp(r.light,Ot(0,-.03,t.ly)*.85):t.part==="paw"?e.copy(r.light):t.part==="head"?e.copy(r.base).lerp(r.light,Ot(.012,0,Math.abs(t.lx))*Ot(t.zStop-.05,t.zStop,t.lz)*.7):e.copy(r.base)}case"husky":{let r=Xn.husky;if(t.part==="ear")return e.copy(r.dark);if(t.part==="head"){let a=Ot(-.005,.045,t.ly)*Ot(t.zStop+.01,t.zStop-.03,t.lz),o=Ot(.022,.006,Math.abs(t.lx));return e.copy(r.light).lerp(r.base,a*(1-o*.9))}return t.part==="body"?e.copy(r.light).lerp(r.base,Ot(i-n.chH*.25,i+n.chH*.25,t.y)):t.part==="neck"?e.copy(r.light).lerp(r.base,Ot(-.01,.04,t.ly)):t.part==="tail"?e.copy(r.light).lerp(r.base,Ot(-.015,.02,t.ly)):t.part==="leg"&&t.seg===0&&!t.front?e.copy(r.base).lerp(r.light,.35):e.copy(r.light)}case"pug":{let r=Xn.pug;return t.part==="ear"?e.copy(r.dark):t.part==="head"?e.copy(r.base).lerp(r.dark,Ot(t.zStop-.05,t.zStop+.005,t.lz)*.95):t.part==="body"?e.copy(r.base).lerp(r.light,Ot(i,i-n.chH*.7,t.y)*.4):e.copy(r.base)}case"pinscher":{let r=Xn.pinscher;if(t.part==="ear")return e.copy(r.base);if(t.part==="head"){let a=Math.max(0,1-Math.hypot(Math.abs(t.lx)-.02,t.ly-.028,t.lz-(t.zStop-.01))/.012);return e.copy(r.base).lerp(r.light,Math.max(s*.95,Ot(-.005,-.03,t.ly)*.9,a))}return t.part==="body"?e.copy(r.base).lerp(r.light,Ot(n.len/2-.12,n.len/2-.03,t.z)*Ot(i,i-n.chH*.5,t.y)):t.part==="neck"?e.copy(r.base).lerp(r.light,Ot(0,-.02,t.ly)*.9):t.part==="paw"||t.part==="leg"&&t.seg>=1?e.copy(r.light):e.copy(r.base)}case"boar":{let r=Xn.boar;return t.part==="ear"||t.part==="tail"?e.copy(r.dark):t.part==="paw"?e.copy(r.hoof):t.part==="head"?e.copy(r.base).lerp(r.light,Ot(0,-.04,t.ly)*.5).lerp(r.dark,s*.45):t.part==="body"?e.copy(r.base).lerp(r.dark,Ot(i+n.chH*.2,i+n.chH*.9,t.y)*.8).lerp(r.light,Ot(i-n.chH*.4,i-n.chH,t.y)*.35):t.part==="neck"?e.copy(r.base).lerp(r.dark,Ot(0,.05,t.ly)*.7):t.part==="leg"?e.copy(r.base).lerp(r.dark,t.seg>=1?.7:.2):e.copy(r.base)}case"opossum":{let r=Xn.opossum,a=Ni(t.x*220+t.z*130,t.y*220,0,13);if(t.part==="ear")return e.copy(t.ly>n.earL*.55?r.light:r.dark);if(t.part==="head"){let[o,c,l]=n.skull,h=Ot(.016,.006,Math.abs(t.ly-l*.3))*Ot(c*.25,c*.45,Math.abs(t.lx))*Ot(t.zStop+.03,t.zStop-.01,t.lz),u=Ot(.012,.004,Math.abs(t.lx))*Ot(l*.3,l*.7,t.ly)*Ot(t.zStop,t.zStop-.04,t.lz);return e.copy(r.light).lerp(r.pink,s*Ot(t.zStop+n.muzzle[0]*.6,t.zStop+n.muzzle[0],t.lz)).lerp(r.dark,Math.max(h,u))}return t.part==="body"?e.copy(r.base).lerp(r.light,a>.62?.55:0).lerp(r.light,Ot(i-n.chH*.3,i-n.chH*.8,t.y)*.6):t.part==="neck"?e.copy(r.light).lerp(r.base,Ot(0,.05,t.ly)*.6):t.part==="leg"?e.copy(t.seg>=1?r.dark:r.base):t.part==="paw"?e.copy(r.pink):t.part==="tail"?e.copy(t.seg===0?r.dark:r.pink):e.copy(r.base)}case"gecko":{let r=Xn.gecko;if(t.part==="paw")return e.copy(r.light);for(let a of t.spots){let o=t.x-a[0],c=t.y-a[1],l=t.z-a[2];if(o*o+c*c+l*l<a[3]*a[3])return e.copy(r.dark)}return t.part==="body"&&t.ly<-n.chH*.35?e.copy(r.light):t.part==="tail"?e.copy(r.base).lerp(r.band,Math.sin(t.z*60)>.2?.7:.15).lerp(r.light,Ot(0,-.03,t.ly)*.6):t.part==="head"&&t.ly<-.012?e.copy(r.light):e.copy(r.base)}case"tegu":{let r=Xn.tegu,a=Ni(t.x*260+t.z*150,t.y*260+t.z*90,0,11);if(t.part==="body"||t.part==="tail"){if(t.ly<-n.chH*.45)return e.copy(r.belly).lerp(r.base,Math.sin(t.z*70)>.6?.8:0);let o=Math.sin(t.z*(t.part==="tail"?32:42)+Ni(t.x*30,t.z*30,0,5)*2.5)>.35;return e.copy(o&&a>.35?r.light:r.base)}return t.part==="head"?e.copy(t.ly<-.018?r.belly:a>.72?r.light:r.base):t.part==="leg"||t.part==="paw"?e.copy(a>.6?r.light:r.base):e.copy(r.base)}case"pitbull":{let r=Xn.pitbull;return t.part==="ear"?e.copy(r.dark):t.part==="head"?e.copy(r.base).lerp(r.light,Ot(.012,.004,Math.abs(t.lx))*Ot(t.zStop-.06,t.zStop,t.lz)*.9):t.part==="body"?e.copy(r.base).lerp(r.light,Ot(n.len/2-.2,n.len/2-.06,t.z)*Ot(i+n.chH*.2,i-n.chH*.3,t.y)):t.part==="neck"?e.copy(r.base).lerp(r.light,Ot(0,-.03,t.ly)):t.part==="paw"||t.part==="leg"&&t.seg===2?e.copy(r.light):e.copy(r.base)}}return e.set(16777215)}var ke=[{id:"rex",name:"REX",raca:"PASTOR ALEM\xC3O",coat:"shepherd",color:"#e53935",pitch:.85,eye:3875856,len:.8,chH:.16,chW:.12,rumpH:.13,rumpW:.11,rumpY:0,waist:.3,arch:.01,backY:.6,bone:.028,neck:.2,neckA:.85,skull:[.1,.075,.07],muzzle:[.12,.04,.038,.025],ear:"erect",earW:.05,earL:.12,tail:[.52,.035,-1,.22],spd:4,acc:3,han:3,jmp:3},{id:"pingo",name:"PINGO",raca:"D\xC1LMATA",coat:"dalmatian",color:"#1e63ff",pitch:1,eye:2758411,len:.78,chH:.15,chW:.11,rumpH:.12,rumpW:.1,rumpY:0,waist:.35,arch:0,backY:.62,bone:.026,neck:.2,neckA:.8,skull:[.095,.072,.07],muzzle:[.115,.042,.04,.022],ear:"floppy",earW:.045,earL:.11,tail:[.45,.028,-.35,.06],spd:3,acc:4,han:3,jmp:3},{id:"caramelo",name:"CARAMELO",raca:"VIRA-LATA",coat:"caramel",color:"#16a34a",pitch:1.05,eye:3021324,len:.7,chH:.14,chW:.11,rumpH:.12,rumpW:.1,rumpY:0,waist:.28,arch:0,backY:.52,bone:.026,neck:.18,neckA:.8,skull:[.09,.075,.072],muzzle:[.1,.043,.04,.022],ear:"fold",earW:.045,earL:.09,tail:[.42,.03,.9,.55],spd:3,acc:3,han:4,jmp:3},{id:"flecha",name:"FLECHA",raca:"GALGO",coat:"grey",color:"#f59e0b",pitch:.95,eye:2364682,len:.82,chH:.17,chW:.085,rumpH:.1,rumpW:.08,rumpY:.02,waist:.62,arch:.035,backY:.68,bone:.022,neck:.24,neckA:.75,skull:[.1,.058,.058],muzzle:[.16,.032,.032,.018],ear:"rose",earW:.035,earL:.08,tail:[.62,.022,-1.2,.2],spd:5,acc:2,han:2,jmp:4},{id:"nevasca",name:"NEVASCA",raca:"HUSKY SIBERIANO",coat:"husky",color:"#8b5cf6",pitch:.8,eye:4891647,len:.75,chH:.15,chW:.12,rumpH:.13,rumpW:.11,rumpY:0,waist:.2,arch:0,backY:.58,bone:.028,neck:.18,neckA:.85,skull:[.095,.08,.075],muzzle:[.1,.044,.042,.022],ear:"erect",earW:.045,earL:.09,tail:[.45,.05,.8,.5],spd:4,acc:4,han:3,jmp:2},{id:"bolinha",name:"BOLINHA",raca:"PUG",coat:"pug",color:"#84cc16",pitch:1.35,eye:1707526,eyeR:.028,len:.5,chH:.15,chW:.14,rumpH:.13,rumpW:.12,rumpY:.01,waist:.05,arch:0,backY:.38,bone:.03,neck:.08,neckA:.7,skull:[.1,.105,.095],muzzle:[.03,.06,.045,.03],ear:"floppy",earW:.04,earL:.07,tail:[.2,.035,1.5,1.3],spd:2,acc:5,han:4,jmp:2},{id:"pitiquin",name:"PITIQUIN",raca:"PINSCHER",coat:"pinscher",color:"#06b6d4",pitch:1.7,eye:1182213,eyeR:.017,len:.42,chH:.095,chW:.068,rumpH:.08,rumpW:.062,rumpY:.005,waist:.35,arch:0,backY:.37,bone:.016,neck:.12,neckA:.95,skull:[.058,.045,.044],muzzle:[.06,.021,.021,.012],ear:"erect",earW:.034,earL:.08,tail:[.1,.018,1.2,.1],spd:3,acc:5,han:3,jmp:2},{id:"princesa",name:"PRINCESA",raca:"PITBULL",coat:"pitbull",color:"#ff4fa3",pitch:.9,eye:5911828,nose:7027246,crown:!0,len:.72,chH:.17,chW:.14,rumpH:.13,rumpW:.115,rumpY:0,waist:.25,arch:0,backY:.52,bone:.034,neck:.14,neckA:.75,skull:[.1,.1,.085],muzzle:[.08,.058,.05,.03],ear:"rose",earW:.04,earL:.06,tail:[.4,.035,-.6,.1],spd:4,acc:4,han:2,jmp:3},{id:"linda",name:"LINDA",raca:"JAVALI",coat:"boar",color:"#0f766e",pitch:.8,voice:"grunt",mass:1.8,eye:1707526,eyeR:.014,snoutDisc:!0,tusks:!0,mane:!0,headDown:.3,len:.82,chH:.21,chW:.15,rumpH:.17,rumpW:.135,rumpY:.01,waist:.05,arch:.03,backY:.5,bone:.032,neck:.1,neckA:.3,skull:[.11,.085,.09],muzzle:[.2,.045,.045,.03],ear:"erect",earW:.042,earL:.07,tail:[.2,.012,-1.2,.1],spd:4,acc:4,han:2,jmp:3},{id:"faiton",name:"FAITON",raca:"LOBO NEGRO",kind:"glb",model:"faiton",gearY:.64,gearDz:-.13,scale:1.4,color:"#dc2626",pitch:.7,mass:1.3,spd:5,acc:3,han:3,jmp:2},{id:"paz",name:"PAZ",raca:"CACHORRO DA PAZ",kind:"glb",model:"paz",fly:!0,color:"#38bdf8",pitch:1.2,mass:.9,spd:3,acc:3,han:4,jmp:2},{id:"pintado",name:"PINTADO",raca:"MABECO",kind:"glb",model:"mabeco",color:"#a16207",pitch:1.1,spd:4,acc:4,han:3,jmp:2},{id:"ruivo",name:"RUIVO",raca:"DINGO",kind:"glb",model:"dingo",color:"#ea580c",pitch:1,spd:4,acc:3,han:3,jmp:3},{id:"ninja",name:"NINJA",raca:"SHIBA INU",kind:"glb",model:"shiba",color:"#334155",pitch:1.3,spd:3,acc:4,han:4,jmp:2},{id:"sombra",name:"SOMBRA",raca:"DOBERMANN",kind:"glb",model:"dobermann",color:"#6d28d9",pitch:.85,mass:1.2,spd:4,acc:4,han:2,jmp:3},{id:"pacoca",name:"PA\xC7OCA",raca:"VIRA-LATA",kind:"glb",model:"vira",color:"#92400e",pitch:1.05,spd:3,acc:3,han:4,jmp:3},{id:"raio",name:"RAIO",raca:"GREYHOUND",kind:"glb",model:"greyhound",color:"#facc15",pitch:.95,spd:5,acc:2,han:2,jmp:4},{id:"duque",name:"DUQUE",raca:"PINSCHER ALEM\xC3O",kind:"glb",model:"duque",color:"#b91c1c",pitch:1.1,spd:4,acc:3,han:3,jmp:3},{id:"frufru",name:"FRUFRU",raca:"POODLE",kind:"glb",model:"poodle",color:"#e879f9",pitch:1.4,spd:3,acc:3,han:4,jmp:3},{id:"major",name:"MAJOR",raca:"PASTOR ALEM\xC3O",kind:"glb",model:"major",color:"#1d4ed8",pitch:.85,mass:1.2,spd:4,acc:3,han:3,jmp:3},{id:"tofu",name:"TOFU",raca:"PUG",kind:"glb",model:"pug2",gearY:.87,color:"#65a30d",pitch:1.35,mass:.9,spd:2,acc:5,han:4,jmp:2},{id:"bidu",name:"BIDU",raca:"BOIADEIRO BERN\xCAS",kind:"glb",model:"bernes",color:"#0f766e",pitch:.8,mass:1.5,spd:3,acc:3,han:3,jmp:3},{id:"canela",name:"CANELA",raca:"AKITA",kind:"glb",model:"canela",color:"#c2410c",pitch:.95,spd:3,acc:4,han:3,jmp:3},{id:"biscoito",name:"BISCOITO",raca:"BEAGLE",kind:"glb",model:"beagle",color:"#0891b2",pitch:1.15,spd:3,acc:4,han:4,jmp:2},{id:"emilly",name:"EMILLY",raca:"SARU\xCA",coat:"opossum",noTongue:!0,color:"#be123c",pitch:2.2,voice:"hiss",mass:.8,eye:525830,eyeR:.016,nose:15179946,len:.6,chH:.13,chW:.11,rumpH:.145,rumpW:.125,rumpY:.025,waist:.05,arch:.035,backY:.35,bone:.02,neck:.08,neckA:.35,headDown:.15,skull:[.08,.06,.055],muzzle:[.13,.026,.024,.018],ear:"round",earW:.035,earL:.055,tail:[.6,.026,-.45,.2],spd:3,acc:4,han:4,jmp:2},{id:"taissa",name:"TAISSA",raca:"LAGARTIXA",kind:"lizard",coat:"gecko",color:"#facc15",pitch:1.8,voice:"hiss",mass:.6,scale:1.3,eye:1840914,eyeR:.024,len:.42,chW:.085,chH:.05,backY:.09,headL:[.15,.058,.036],bone:.013,legU:.1,gearS:.55,tailL:.42,tailR:.042,spd:2,acc:5,han:5,jmp:1},{id:"tiffany",name:"TIFFANY",raca:"TEI\xDA",kind:"lizard",coat:"tegu",color:"#f97316",pitch:1,voice:"hiss",mass:1.2,forked:!0,eye:657930,eyeR:.011,len:.68,chW:.13,chH:.075,backY:.13,headL:[.2,.068,.048],bone:.02,legU:.13,gearS:.8,tailL:.9,tailR:.068,spd:4,acc:3,han:4,jmp:2}];function kh(n,t){let e=new ti(Ge(64,64,i=>{i.fillStyle="#fff",i.beginPath(),i.arc(32,32,29,0,7),i.fill(),i.lineWidth=6,i.strokeStyle=t,i.stroke(),i.fillStyle="#111",i.font="bold 34px Arial",i.textAlign="center",i.textBaseline="middle",i.fillText(String(n),32,34)}));return e.colorSpace=be,e}var Hd=new ee({color:1708560,roughness:.5}),_h=new ee({color:1315346,roughness:.35}),kd=new ee({color:14704762,roughness:.4}),cc=new ee({color:12897496,roughness:.25,metalness:.6}),Gd=new ee({color:13703722,roughness:.3,metalness:.6}),Vd=new Tn({color:6737151,transparent:!0,opacity:.85,blending:Zi,depthWrite:!1}),_c=new Tn({color:16769357}),Da=new ti(Ge(64,64,n=>{n.fillStyle="#ffcc00",n.beginPath(),n.arc(32,32,28,0,7),n.fill(),n.fillStyle="#111",n.font="bold 44px Arial",n.textAlign="center",n.textBaseline="middle",n.fillText("!",32,35)}));Da.colorSpace=be;var vh=new ee({color:3818063,roughness:.4,metalness:.5}),Gh=new ee({color:16742938,roughness:.4,metalness:.3,emissive:4200448}),lc=new ee({color:14753066,roughness:.3,metalness:.4}),Wd=(()=>{let n=Ge(128,128,(t,e,i)=>{t.fillStyle="#e8e8e8",t.fillRect(0,0,e,i);for(let s=0;s<16;s++)for(let r=0;r<16;r++){let a=r*8+s%2*4,o=s*8,c=175+Math.random()*60|0;t.fillStyle=`rgb(${c},${c},${c})`,t.beginPath(),t.ellipse(a,o,3.6,3.1,0,0,7),t.fill()}});return an(n,3,3)})(),Mh=new Set([wa,zd,Wd,Hd,_h,kd,cc,Gd,Vd,_c,Da,wa,Hh,vh,Gh,lc]);function Vh(n,t,e,i=1){let s=new vt;s.position.set(0,t,e),s.scale.setScalar(i),n.add(s),t=0,e=0;let r=[];for(let h of[-1,1]){let u=new bt(new Vt(.026,.026,.16,12),cc);u.rotation.x=Math.PI/2,u.position.set(h*.034,t+.02,e),u.castShadow=!0,s.add(u);let f=new bt(new de(.026,10,6,0,Math.PI*2,0,Math.PI/2),Gd);f.rotation.x=Math.PI/2,f.position.set(h*.034,t+.02,e+.08),s.add(f);let d=new bt(new Vt(.012,.018,.03,8),cc);d.rotation.x=Math.PI/2,d.position.set(h*.034,t+.02,e-.095),s.add(d);let p=new bt(new je(.02,.2,8),Vd);p.rotation.x=-Math.PI/2,p.position.set(h*.034,t+.02,e-.21),p.visible=!1,s.add(p),r.push(p)}let a=new vt;a.position.set(0,t+.058,e+.015),s.add(a);let o=new bt(new xe(.075,.012,.09),vh);o.position.y=-.012,a.add(o);let c=[];[[-.02,.012],[.02,.012],[0,.044]].forEach(([h,u])=>{let f=new bt(new Vt(.018,.018,.15,12,1,!0),vh);f.material.side=Oe,f.rotation.x=Math.PI/2,f.position.set(h,u,0),f.castShadow=!0,a.add(f);let d=new bt(new Vt(.0195,.0195,.014,12),Gh);d.rotation.x=Math.PI/2,d.position.set(h,u,.06),a.add(d);let p=new bt(new je(.014,.034,10),lc);p.rotation.x=Math.PI/2,p.position.set(h,u,.082),a.add(p),c.push(p)});let l=new Ze;return l.position.set(0,.03,.12),a.add(l),{flames:r,launcher:{g:a,noses:c,muzzle:l}}}var nc=2.3;function xv(n,t,e){let i=new vt,s=new vt,r=new vt;i.add(s),s.add(r);let a=new ee({vertexColors:!0,map:zd,roughness:.88}),o=[],c=(v,_,D,G={},Y=a)=>{let j=new bt(v,Y);return j.userData={part:D,...G},j.castShadow=!0,_.add(j),Y===a&&o.push(j),j},l=n.backY-n.chH*.9,h=c(Ln(28,22,(v,_)=>vr(n,v,_)),r,"body");h.position.y=l;let[u,f,d]=n.skull,[p,x,g,m]=n.muzzle,E=new vt;E.position.set(0,l+n.chH*.3,n.len/2-.07),E.rotation.x=-n.neckA,r.add(E),c(Ln(10,16,(v,_)=>{let D=Rs(.5+v*.5,3)*.3+.7*(v<.9?1:Rs(.5+(v-.9)*5,2)),G=Fe(n.chW*.72,f*.8,v)*D,Y=Fe(n.chH*.62,d*.85,v)*D;return[Math.cos(_)*G,Math.sin(_)*Y,-.04+v*(n.neck+.06)]}),E,"neck");let y=new vt;y.position.set(0,0,n.neck),y.rotation.x=n.neckA-.12+(n.headDown||0),E.add(y);let S=new vt;S.position.set(0,d*.2,u*.55),y.add(S);let P=ph(n,0);c(Ln(34,22,(v,_)=>{let D=-u+v*(P.zEnd+u),G=ph(n,D),Y=Math.sin(_);return[Math.cos(_)*G.w,G.yc+Y*G.h*(Y<0?.88:1),D]}),S,"head");let w=n.eye===4891647?new ee({color:4891647,roughness:.05,emissive:664640}):new ee({color:n.eye,roughness:.06}),A=n.eyeR||f*.24,F=[0,0,0];{let v=P.zStop-u*.08,_=ph(n,v),D=.42;for(let G of[-1,1]){let Y=new bt(new de(A,12,9),w);Y.position.set(G*Math.cos(D)*_.w*.9,_.yc+Math.sin(D)*_.h*.9,v+A*.3),S.add(Y),G>0&&(F=[Y.position.x,Y.position.y,Y.position.z]);let j=new bt(new de(A*1.12,12,6,0,Math.PI*2,0,Math.PI*.42),Hd);j.position.copy(Y.position),j.rotation.x=-.2,S.add(j)}}let M=Math.max(P.zStop+p-x*.25,u*.97),b=new bt(Di(x*.62,x*.42,x*.4),n.nose?new ee({color:n.nose,roughness:.35}):_h);if(b.position.set(0,-m+g*.52,M),S.add(b),n.snoutDisc){b.visible=!1;let v=new ee({color:12157816,roughness:.55}),_=new bt(new Vt(x*.95,x*1,.02,22),v);_.rotation.x=Math.PI/2,_.position.set(0,-m*.9,P.zStop+p-.004),S.add(_);for(let D of[-1,1]){let G=new bt(new de(x*.2,8,6),_h);G.scale.z=.4,G.position.set(D*x*.35,-m*.9,P.zStop+p+.007),S.add(G)}}if(n.tusks){let v=new ee({color:15985366,roughness:.35});for(let _ of[-1,1]){let D=new bt(new je(.009,.06,8),v);D.position.set(_*x*.95,-m-g*.35,P.zStop+p*.62),D.rotation.set(-.5,0,-_*.55),D.castShadow=!0,S.add(D)}}if(n.crown){let v=new ee({color:16762173,roughness:.3,metalness:.6,emissive:3810304});var R=new vt;R.position.set(0,d*.95,-u*.1),R.rotation.x=-.15,S.add(R),R.add(new bt(new Vt(.032,.036,.018,16,1,!0),v));for(let _=0;_<5;_++){let D=_/5*Math.PI*2,G=new bt(new je(.009,.026,6),v);G.position.set(Math.cos(D)*.032,.02,Math.sin(D)*.032),R.add(G);let Y=new bt(new de(.005,8,6),new ee({color:16723338,roughness:.1,emissive:5570594}));Y.position.set(Math.cos(D)*.035,.002,Math.sin(D)*.035),R.add(Y)}R.traverse(_=>{_.isMesh&&(_.castShadow=!0)})}let O=new vt;O.position.set(0,-m-g*.75,P.zStop+p*.35),S.add(O);let Z=new bt(Di(x*.55,.008,.06),kd);Z.position.set(0,-.02,.02),Z.rotation.x=.9,O.add(Z);let I=[];for(let v of[-1,1]){let _=new vt;if(_.position.set(v*f*.55,d*.7,-u*.28),S.add(_),n.ear==="round"){let D=Ln(8,12,(G,Y)=>{let j=n.earW*Math.pow(Math.sin(Math.PI*(.06+.94*G)),.55);return[Math.cos(Y)*j,Math.sin(Y)*.01,G*n.earL]});D.rotateX(-Math.PI/2),c(D,_,"ear"),_.rotation.set(-.15,0,-v*.45)}else if(n.ear==="erect"||n.ear==="fold"){let D=Ln(8,12,(G,Y)=>{let j=n.earW*Math.pow(1-G,.85)*(G<.12?.75+2*G:1);return[Math.cos(Y)*j,Math.sin(Y)*(.018*(1-G*.6)),G*n.earL]});D.rotateX(-Math.PI/2),c(D,_,"ear"),_.rotation.set(n.ear==="fold"?.55:-.12,0,-v*.28)}else{let D=Ln(8,12,(G,Y)=>{let j=n.earW*Math.pow(Math.sin(Math.PI*(.12+.88*G)),.7);return[Math.cos(Y)*j,Math.sin(Y)*.013,G*n.earL]});D.rotateX(Math.PI/2),c(D,_,"ear"),_.rotation.set(n.ear==="rose"?1.3:.05,0,v*.35)}I.push({piv:_,type:n.ear,rx:_.rotation.x,rz:_.rotation.z,sx:v})}let N=[],H=n.bone;for(let v of[{f:1,sx:-1,off:0},{f:1,sx:1,off:.55},{f:0,sx:-1,off:Math.PI+.2},{f:0,sx:1,off:Math.PI+.75}]){let _=new vt;v.f?_.position.set(v.sx*n.chW*.6,l-n.chH*.2,n.len/2-.11):_.position.set(v.sx*n.rumpW*.62,l+n.rumpY,-n.len/2+.13),r.add(_);let D=_.position.y,G=D*(v.f?.44:.42),Y=D*.44,j=D*(v.f?.15:.28);c(va(G,v.f?H*2:H*2.6,v.f?H*1.25:H*1.35,v.f?1.15:1.35),_,"leg",{front:v.f,seg:0});let Tt=new vt;Tt.position.y=-G,_.add(Tt),c(va(Y,H*1.1,H*.78,1.1),Tt,"leg",{front:v.f,seg:1});let lt=new vt;lt.position.y=-Y,Tt.add(lt),c(va(j,H*.82,H*.72,1.1),lt,"leg",{front:v.f,seg:2});let wt=c(Di(H*1.15,H*.72,H*1.55),lt,"paw",{front:v.f});wt.position.set(0,-j-H*.35,H*.7);let zt=v.f?.45:-.55,qt=v.f?-.45:1.15,ot=v.f?-.22:-.6;_.rotation.x=zt,Tt.rotation.x=qt,lt.rotation.x=ot,N.push({hip:_,knee:Tt,ank:lt,paw:wt,front:v.f,off:v.off,rh:zt,rk:qt,ra:ot})}let[nt,B,W,Q]=n.tail,tt=new vt;tt.position.set(0,l+n.rumpY+n.rumpH*.55,-n.len/2+.04),r.add(tt);let ut=[],J=tt;for(let v=0;v<4;v++){let _=B*(1-v/4*.55),D=B*(1-(v+1)/4*.55),G=nt/4,Y=Ln(6,10,(Tt,lt)=>{let wt=Fe(_,D,Tt)*Rs(Tt,3);return[Math.cos(lt)*wt,Math.sin(lt)*wt,-_*.6+Tt*(G+_*1.2)]});Y.rotateY(Math.PI);let j=new vt;j.position.z=v?-G:0,J.add(j),c(Y,j,"tail",{seg:v}),j.rotation.x=v?Q:W,ut.push(j),J=j}let it=new ee({color:e,roughness:.45,metalness:.15,side:Oe}),dt=new bt(Ln(8,22,(v,_)=>vr(n,Fe(.47,.72,v),_,1.07)),it);dt.position.y=l,dt.castShadow=!0,r.add(dt);let It=new ee({map:kh(t,e),transparent:!0,roughness:.5});for(let v of[-1,1]){let _=vr(n,.6,v>0?0:Math.PI,1.08),D=new bt(new cn(.12,.12),It);D.position.set(_[0]+v*.004,l+_[1],_[2]),D.rotation.y=v*Math.PI/2,r.add(D)}let St=l+vr(n,.52,Math.PI/2,1.07)[1],Ht=vr(n,.5,0)[2],{flames:st,launcher:ct}=Vh(r,St,Ht);if(n.mane){let v=new ee({color:1971986,roughness:.95});for(let _=0;_<16;_++){let D=Fe(.28,.98,_/15),G=vr(n,D,Math.PI/2);if(Math.abs(G[2]-Ht)<.1)continue;let Y=new bt(new je(.014,.06+.02*Math.sin(_),5),v);Y.position.set(0,l+G[1]+.012,G[2]),Y.rotation.x=-.5,Y.castShadow=!0,r.add(Y)}}let xt=new vt;xt.position.set(0,d*2.2,0),S.add(xt);for(let v=0;v<4;v++){let _=new bt(new gr(.025),_c);_.position.set(Math.cos(v*1.57)*.09,0,Math.sin(v*1.57)*.09),xt.add(_)}xt.visible=!1;let C=new xs(new ji({map:Da,depthTest:!1}));C.scale.set(.13,.13,1),C.position.set(0,d*2.8,0),C.visible=!1,S.add(C),s.updateMatrixWorld(!0);let rt=new Gn;for(let v of N)rt.setFromObject(v.paw),v.hip.position.y-=rt.min.y;s.updateMatrixWorld(!0);let q=[];if(n.coat==="dalmatian")for(let v=0;v<300;v++)q.push([Ut(-.2,.2),Ut(.02,.8),Ut(-.6,.75),Ut(.012,.03)]);let et=new L,K=new Ft;for(let v of o){let _=v.geometry.attributes.position,D=new Float32Array(_.count*3);for(let G=0;G<_.count;G++){et.fromBufferAttribute(_,G);let Y=et.x,j=et.y,Tt=et.z;et.applyMatrix4(v.matrixWorld),Bd(n,{part:v.userData.part,front:v.userData.front,seg:v.userData.seg,zStop:P.zStop,lx:Y,ly:j,lz:Tt,x:et.x,y:et.y,z:et.z,cy:l,spots:q},K);let lt=(.9+.2*Ni(et.x*45+et.z*17,et.y*45,0,3))*(v.userData.part==="body"?1-.1*Ot(l,l+n.chH,et.y):1);D[G*3]=K.r*lt,D[G*3+1]=K.g*lt,D[G*3+2]=K.b*lt}v.geometry.setAttribute("color",new me(D,3))}s.scale.setScalar(nc);let Pt=new bt(new cn(1,1),new Tn({map:wa,transparent:!0,depthWrite:!1}));Pt.rotation.x=-Math.PI/2,Pt.position.y=.04,Pt.scale.set(n.chW*5*nc,n.len*1.5*nc,1),i.add(Pt);let _t={hat:[0,d*.9,-u*.12],s:f,eye:F,er:A,cape:[0,l+n.chH*.98,n.len/2-.15],capeW:n.chW,capeL:n.len};return{root:i,model:s,body:r,torso:h,neckPiv:E,headPiv:y,head:S,legs:N,tails:ut,ears:I,tongue:O,flames:st,stars:xt,excl:C,blob:Pt,b:n,launcher:ct,anim:Lv,vestMat:it,hi:_t,crown:typeof R<"u"?R:null}}var Cs={hat:{n:"CHAP\xC9US",items:[["none","NENHUM",0],["bone","BON\xC9",150],["festa","CHAP\xC9U DE FESTA",200],["cartola","CARTOLA",300],["cowboy","CHAP\xC9U DE CAUB\xD3I",350],["capacete","CAPACETE DE CORRIDA",450],["coroa","COROA DE REI",800]]},glasses:{n:"\xD3CULOS",items:[["none","NENHUM",0],["escuro","\xD3CULOS ESCUROS",150],["nerd","\xD3CULOS DE NERD",200],["aviador","AVIADOR",250],["coracao","CORA\xC7\xC3O",300]]},cape:{n:"CAPAS",items:[["none","NENHUMA",0],["vermelha","CAPA VERMELHA",300],["azul","CAPA AZUL",300],["roxa","CAPA ROXA",350],["dourada","CAPA DOURADA",600]]},vest:{n:"COLETES",items:[["padrao","COR ORIGINAL",0],["preto","PRETO",100],["branco","BRANCO",100],["vermelho","VERMELHO",100],["azul","AZUL",100],["verde","VERDE",100],["roxo","ROXO",100],["rosa","ROSA",100],["dourado","DOURADO",300]]},trail:{n:"RASTROS",items:[["none","NENHUM",0],["bolhas","BOLHAS",350],["coracoes","CORA\xC7\xD5ES",450],["estrelas","ESTRELAS",500],["fogo","FOGO",550],["arcoiris","ARCO-\xCDRIS",700]]}},Xd={preto:1842207,branco:15921906,vermelho:14163754,azul:2056191,verde:1483594,roxo:8141549,rosa:16732067,dourado:16762173},Yd={vermelha:"#d81f2a",azul:"#1f5fff",roxa:"#7c3aed",dourada:"#ffc53d"},yv={bolhas:"#9fdcff",coracoes:"#ff5f9e",estrelas:"#ffe14d",fogo:"#ff7a1a",arcoiris:"linear-gradient(90deg,#f33,#fc3,#3c6,#39f,#c3f)"},_v={bone:"#d81f2a",festa:"#ff4fa3",cartola:"#1a1a1a",cowboy:"#8a5a2b",capacete:"#f4f4f4",coroa:"#ffc53d"},vv={escuro:"#111",nerd:"#333",aviador:"#c9a24a",coracao:"#ff5f9e"},Mv={hat:"none",glasses:"none",cape:"none",vest:"padrao",trail:"none"},Ev=(n,t)=>Cs[n].items.find(e=>e[0]===t)[2]===0||k.owned.includes(n+":"+t);function vc(n){return Object.assign({},Mv,k.looks[n.id]||{})}function $d(){let n=(t,e)=>Math.random()<e?Cs[t].items[1+(Math.random()*(Cs[t].items.length-1)|0)][0]:Cs[t].items[0][0];return{hat:n("hat",.35),glasses:n("glasses",.25),cape:n("cape",.12),vest:"padrao",trail:n("trail",.15)}}function ln(n,t=.5,e=0,i={}){return new ee({color:n,roughness:t,metalness:e,...i})}function Sv(n,t){let e=new vt,i=(s,r,a=0,o=0,c=0)=>{let l=new bt(s,r);return l.position.set(a,o,c),l.castShadow=!0,e.add(l),l};if(n==="bone")i(new de(t*.95,18,10,0,Math.PI*2,0,Math.PI/2),ln(14163754,.6)).scale.y=.75,i(new xe(t*1.3,t*.06,t*.9),ln(16053492,.6),0,t*.03,t*1.05),i(new de(t*.12,8,6),ln(16053492),0,t*.72,0);else if(n==="festa"){let s=new ti(Ge(64,64,r=>{for(let a=0;a<8;a++)r.fillStyle=a%2?"#ffe14d":"#ff4fa3",r.fillRect(0,a*8,64,8)}));s.colorSpace=be,i(new je(t*.6,t*1.9,20),ln(16777215,.6,0,{map:s}),0,t*.9,0),i(new de(t*.2,10,8),ln(3526911,.9),0,t*1.9,0)}else if(n==="cartola"){let s=ln(1381653,.45);i(new Vt(t*1.25,t*1.25,t*.08,24),s,0,t*.02,0),i(new Vt(t*.72,t*.76,t*1.4,24),s,0,t*.72,0),i(new Vt(t*.78,t*.78,t*.26,24),ln(14163754,.5),0,t*.22,0)}else if(n==="cowboy"){let s=ln(9067051,.8);i(new Vt(t*1.7,t*1.7,t*.07,28),s).scale.z=.85,i(new Vt(t*.72,t*.85,t*.95,20),s,0,t*.48,0),i(new Vt(t*.87,t*.87,t*.2,20),ln(2824718,.6),0,t*.14,0)}else if(n==="capacete")i(new de(t*1.25,22,12,0,Math.PI*2,0,Math.PI*.55),ln(16053492,.15,.2),0,-t*.25,0),i(new de(t*1.27,22,12,-.3,.6,0,Math.PI*.55),ln(14163754,.2),0,-t*.25,0),i(new xe(t*1.2,t*.35,t*.1),ln(1120810,.05,.3),0,t*.25,t*1.05);else if(n==="coroa"){let s=ln(16762173,.3,.6,{emissive:3810304});i(new Vt(t*.82,t*.88,t*.42,24,1,!0),s,0,t*.2,0).material.side=Oe;for(let r=0;r<7;r++){let a=r/7*Math.PI*2;i(new je(t*.16,t*.42,6),s,Math.cos(a)*t*.82,t*.6,Math.sin(a)*t*.82),i(new de(t*.1,8,6),ln(r%2?2976767:14753096,.1),Math.cos(a)*t*.86,t*.22,Math.sin(a)*t*.86)}}return e.rotation.x=-.15,e}function bv(n,t){let e=new vt,[i,s,r]=t.eye,a=t.er*1.7,o=r+t.er*.95,c=ln({escuro:1118481,nerd:1710618,aviador:13214282,coracao:16736158}[n],.3,n==="aviador"?.7:.1),l=ln({escuro:328965,nerd:13625599,aviador:3877400,coracao:16752324}[n],.05,.2,{transparent:!0,opacity:n==="nerd"?.35:.85});for(let h of[-1,1])if(n==="coracao"){let u=new Qi,f=a*1.1;u.moveTo(0,-f),u.bezierCurveTo(f*1.2,-f*.2,f*.9,f*1,0,f*.45),u.bezierCurveTo(-f*.9,f*1,-f*1.2,-f*.2,0,-f);let d=new bt(new vs(u,{depth:a*.15,bevelEnabled:!1}),l);d.position.set(h*i,s,o),e.add(d)}else{let u=new bt(new Vt(a,a,a*.12,20),l);u.rotation.x=Math.PI/2,u.position.set(h*i,s,o),e.add(u),n==="aviador"&&u.scale.set(1,1,1.2);let f=new bt(new xr(a,a*(n==="nerd"?.22:.13),8,24),c);f.position.set(h*i,s,o),e.add(f)}if(i>a){let h=new bt(new xe(i*2-a*1.6,a*.18,a*.18),c);h.position.set(0,s+a*.25,o),e.add(h)}return e}function Tv(n,t,e){let i=Yd[n],s=new ti(Ge(64,96,c=>{let l=c.createLinearGradient(0,0,0,96);l.addColorStop(0,i),l.addColorStop(1,n==="dourada"?"#b8860b":"#00000088"),c.fillStyle=i,c.fillRect(0,0,64,96),c.fillStyle=l,c.fillRect(0,0,64,96),c.fillStyle="rgba(255,255,255,.85)",c.beginPath(),c.ellipse(32,54,8,7,0,0,7),c.fill();for(let[h,u]of[[-9,-8],[-3,-12],[3,-12],[9,-8]])c.beginPath(),c.ellipse(32+h,54+u,3,3.6,0,0,7),c.fill()}));s.colorSpace=be;let r=new cn(t*2.3,e*.55,1,6);r.translate(0,-e*.275,0);let a=r.attributes.position;for(let c=0;c<a.count;c++){let l=a.getY(c);a.setX(c,a.getX(c)*(1+-l/e*.6))}let o=new bt(r,ln(16777215,.6,n==="dourada"?.4:0,{map:s,side:Oe}));return o.castShadow=!0,o}function Mc(n,t){n.lookG&&n.lookG.forEach(i=>{i.parent&&i.parent.remove(i),Cr(i)}),n.lookG=[],n.cape=null,n.look=t,n.crown&&(n.crown.visible=t.hat==="none"),n.vestMat.color.set(t.vest==="padrao"?n.b.color:Xd[t.vest]),n.vestMat.metalness=t.vest==="dourado"?.7:.15;let e=n.hi;if(t.hat!=="none"){let i=Sv(t.hat,e.s);i.position.set(...e.hat),n.head.add(i),n.lookG.push(i)}if(t.glasses!=="none"&&!e.noGlasses){let i=bv(t.glasses,e);n.head.add(i),n.lookG.push(i)}if(t.cape!=="none"){let i=new vt;i.position.set(...e.cape),i.add(Tv(t.cape,e.capeW,e.capeL)),i.rotation.x=1.3,n.body.add(i),n.lookG.push(i),n.cape=i}}var Qo=new Ft;function wv(n,t){let e=n.look&&n.look.trail,i=Math.hypot(n.vx,n.vz);if(!e||e==="none"||i<6||Math.random()>t*30)return;let s=n.x-Math.sin(n.h)*1.4+(Math.random()-.5)*.8,r=n.z-Math.cos(n.h)*1.4+(Math.random()-.5)*.8,a=.5+n.y+Math.random()*.6;e==="bolhas"?oi.spawn(s,a,r,Math.random()-.5,1.5,Math.random()-.5,1.4,.35,.6,[.65,.88,1],.55,-1.5,1):e==="coracoes"?bn.spawn(s,a,r,0,1.2,0,.9,.45,.25,[1,.3,.6],.9,-.5,1):e==="estrelas"?bn.spawn(s,a,r,(Math.random()-.5)*2,1,(Math.random()-.5)*2,.7,.3,.05,[1,.92,.4],1,0,1):e==="fogo"?bn.spawn(s,.35+n.y,r,0,2.5,0,.45,.6,.15,Math.random()<.5?[1,.45,.1]:[1,.8,.2],1,-2,1):e==="arcoiris"&&(Qo.setHSL((Un*.6+Math.random()*.1)%1,.9,.6),bn.spawn(s,a,r,0,.3,0,.8,.5,.35,[Qo.r,Qo.g,Qo.b],.9,0,1))}function qd(n,t,e){return n.kind==="glb"&&Wh[n.model]?Rv(n,t,e):n.kind==="lizard"?Pv(n,t,e):xv(n,t,e)}var Wh={};(function(){let t=window.CAES;if(t)try{let e=atob(t.data),i=new Uint8Array(e.length);for(let a=0;a<e.length;a++)i[a]=e.charCodeAt(a);let s=i.buffer,r=new Ft;for(let a of t.meta){let o=new Int16Array(s,a.p,a.v*3),c=new Uint8Array(s,a.c,a.v*3),l=a.big?new Uint32Array(s,a.x,a.i):new Uint16Array(s,a.x,a.i),h=new Float32Array(a.v*3),u=new Float32Array(a.v*3),f=new Float32Array(a.v*3);for(let B=0;B<a.v;B++){for(let W=0;W<3;W++)h[B*3+W]=a.min[W]+(o[B*3+W]+32767)/65534*a.size[W];r.setRGB(c[B*3]/255,c[B*3+1]/255,c[B*3+2]/255,be),u[B*3]=r.r,u[B*3+1]=r.g,u[B*3+2]=r.b,f[B*3]=c[B*3],f[B*3+1]=c[B*3+1],f[B*3+2]=c[B*3+2]}let[d,p,x]=a.size,g=a.min[2]+x/2,m=p,E=0,y=0,S=-1e9,P=1e9;for(let B=0;B<a.v;B++){let W=h[B*3+2];W>S&&(S=W),W<P&&(P=W)}for(let B=0;B<a.v;B++){let W=h[B*3],Q=h[B*3+1],tt=h[B*3+2];Math.abs(tt-g)<x*.12&&Q>E&&(E=Q),Math.abs(tt-g)<x*.05&&Math.abs(W)<d*.3&&Q<m&&Q>p*.12&&(m=Q),tt>S-x*.22&&Q>y&&(y=Q)}let w=m+p*.04,A=new Float32Array(a.v),F=new Float32Array(a.v),M=[0,0,0,0],b=[0,0,0,0];for(let B=0;B<a.v;B++){let W=h[B*3],Q=h[B*3+1],tt=h[B*3+2],ut=(tt>g?0:2)+(W>0?1:0);A[B]=ut,F[B]=Q<w?Ot(w,w*.78,Q):0,Q<w&&Q>w*.75&&(M[ut]+=tt,b[ut]++)}for(let B=0;B<4;B++)M[B]=b[B]?M[B]/b[B]:g+(B<2?x*.3:-x*.3);let R=Fe((M[0]+M[1])/2,(M[2]+M[3])/2,.55),O=new Ie;O.setAttribute("position",new me(h,3)),O.setAttribute("color",new me(u,3)),O.setAttribute("legG",new me(A,1)),O.setAttribute("legW",new me(F,1)),O.setIndex(new me(a.big?new Uint32Array(l):new Uint16Array(l),1)),O.computeVertexNormals(),O.computeBoundingSphere(),O.userData.keep=!0;let Z=new bt(O,new Tn({side:Oe})),I=new qo,N=[],H=w+(p-w)*.55;for(let B of[-.12,-.05,0,.05,.12])for(let W of[-.04,0,.04]){I.set(new L(B*d,p*2,R+W*x),new L(0,-1,0));let Q=I.intersectObject(Z).map(tt=>tt.point.y).filter(tt=>tt>w&&tt<H);Q.length&&N.push(Math.max(...Q))}N.sort((B,W)=>B-W);let nt=N.length?N[N.length>>1]:E;Wh[a.n]={geo:O,W:d,H:p,L:x,zc:g,zmin:P,zmax:S,belly:m,back:E,headTop:y,legTop:w,pivots:M,raw8:f,idx:l,saddleZ:R,saddleTop:nt}}}catch(e){console.warn("modelos .glb n\xE3o carregados",e)}})();function Av(){let n={uAng:{value:new We},uPiv:{value:new We},uTop:{value:0}},t=new ee({vertexColors:!0,flatShading:!0,roughness:.82});return t.onBeforeCompile=e=>{Object.assign(e.uniforms,n),e.vertexShader=`attribute float legG; attribute float legW; uniform vec4 uAng; uniform vec4 uPiv; uniform float uTop;
`+e.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
        if (legW > 0.0) {
          float a = (legG < 0.5 ? uAng.x : legG < 1.5 ? uAng.y : legG < 2.5 ? uAng.z : uAng.w) * legW;
          float pz = legG < 0.5 ? uPiv.x : legG < 1.5 ? uPiv.y : legG < 2.5 ? uPiv.z : uPiv.w;
          float dy = transformed.y - uTop, dz = transformed.z - pz, c = cos(a), s = sin(a);
          transformed.y = uTop + dy * c - dz * s; transformed.z = pz + dy * s + dz * c;
        }`)},t.userData.u=n,t}function Rv(n,t,e){let i=Wh[n.model],s=new vt,r=new vt,a=new vt;s.add(r),r.add(a),r.scale.setScalar(n.scale||1);let o=Av();o.userData.u.uTop.value=i.legTop,o.userData.u.uPiv.value.set(...i.pivots);let c=null;if(n.prop){let w=i.geo.attributes.position,A=i.idx,F=[],M=[],b=new L,R=0,O=Z=>{let I=i.raw8[Z*3],N=i.raw8[Z*3+1],H=i.raw8[Z*3+2];return w.getZ(Z)>i.zmax-i.L*.22&&Math.abs(I-N)<18&&Math.abs(N-H)<18&&I>110};for(let Z=0;Z<A.length;Z+=3){let I=A[Z],N=A[Z+1],H=A[Z+2];if(O(I)&&O(N)&&O(H)){M.push(I,N,H);for(let nt of[I,N,H])b.x+=w.getX(nt),b.y+=w.getY(nt),b.z+=w.getZ(nt),R++}else F.push(I,N,H)}if(M.length){b.divideScalar(R);let Z=i.geo.clone();Z.setIndex(F),Z.userData.keep=!1;let I=i.geo.clone();I.setIndex(M),I.translate(-b.x,-b.y,-b.z),I.userData.keep=!1;let N=new bt(Z,o);N.castShadow=!0,a.add(N),c=new vt,c.position.copy(b),a.add(c);let H=new bt(I,o);c.add(H)}}if(!c){let w=new bt(i.geo,o);w.castShadow=!0,a.add(w)}let l=new vt;l.position.set(0,i.headTop-i.H*.08,i.zmax-i.L*.1),a.add(l);let h=i.L/1.9,u=n.fly?i.zc-i.L*.22:i.saddleZ+(n.gearDz||0)*i.L,f=new ee({color:e,roughness:.45,metalness:.15}),d=n.fly?i.H*.62:n.gearY?i.H*n.gearY:i.saddleTop-(n.gearDy||.015)*i.H,p=new bt(new de(1,20,8,0,Math.PI*2,0,Math.PI/2),f);p.scale.set(i.W*(n.fly?.3:.55),.06*h,i.L*.16),p.position.set(0,d,u),p.castShadow=!0,a.add(p);let x=new ee({map:kh(t,e),transparent:!0,roughness:.5,side:Oe});for(let w of[-1,1]){let A=new bt(new cn(.2*h,.2*h),x);A.position.set(w*(i.W*(n.fly?.3:.55)+.01),d-.02,u),A.rotation.y=w*Math.PI/2,a.add(A)}let{flames:g,launcher:m}=Vh(a,d+.02,u,2.3*h*.9),E=new vt;E.position.set(0,.35*h,0),l.add(E);for(let w=0;w<4;w++){let A=new bt(new gr(.06),_c);A.position.set(Math.cos(w*1.57)*.22,0,Math.sin(w*1.57)*.22),E.add(A)}E.visible=!1;let y=new xs(new ji({map:Da,depthTest:!1}));y.scale.set(.3,.3,1),y.position.set(0,.55*h,0),y.visible=!1,l.add(y);let S=new bt(new cn(1,1),new Tn({map:wa,transparent:!0,depthWrite:!1}));S.rotation.x=-Math.PI/2,S.position.y=.04,S.scale.set(i.W*2.2*(n.scale||1),i.L*1.3*(n.scale||1),1),s.add(S);let P={hat:[0,.1*h,-.02],s:.17*h,eye:[.08,0,.1],er:.03,cape:[0,d+.02,u+i.L*.22],capeW:i.W*.4,capeL:i.L*.85,noGlasses:!0};return{root:s,model:r,body:a,torso:a,neckPiv:l,headPiv:l,head:l,legs:[],tails:[],ears:[],tongue:new vt,flames:g,stars:E,excl:y,blob:S,b:n,launcher:m,anim:Cv,vestMat:f,hi:P,crown:null,mat:o,prop:c,G:i}}function Cv(n,t,e){let i=n.b,s=n.mat.userData.u.uAng.value,r=ce(t.v/12,0,1),a=t.y>.05;if(i.fly)s.set(0,0,0,0),n.body.position.y=.55+Math.sin(e*2.2)*.12,n.body.rotation.x=-r*.08+Math.sin(e*1.7)*.03,n.prop&&(n.prop.rotation.z+=.4+r*.9);else{let o=t.phase,c=.62*r;a?s.set(-.75,-.75,.8,.8):s.set(Math.sin(o)*c,Math.sin(o+.55)*c,Math.sin(o+Math.PI+.2)*c,Math.sin(o+Math.PI+.75)*c),n.body.position.y=a?0:Math.abs(Math.cos(o))*.06*r+(t.idle?Math.sin(e*3.5)*.008:0),n.body.rotation.x=a?ce(-t.vy*.03,-.3,.3):Math.sin(o*2)*.035*r,n.body.rotation.y=t.idle?Math.sin(e*.7)*.08:0}n.model.rotation.z=ce(-t.yawRate*(i.fly?.3:.16),-.4,.4)+(t.stun>0?Math.sin(e*18)*.15:0),Zd(n,t,e)}function Pv(n,t,e){let i=new vt,s=new vt,r=new vt;i.add(s),s.add(r);let a=new ee({vertexColors:!0,map:Wd,roughness:n.coat==="tegu"?.42:.6}),o=[],c=(st,ct,xt,C={},rt=a)=>{let q=new bt(st,rt);return q.userData={part:xt,...C},q.castShadow=!0,ct.add(q),rt===a&&o.push(q),q},l=n.len,h=n.chW,u=n.chH,f=n.backY,d=c(Ln(26,20,(st,ct)=>{let xt=Rs(st,2.2),C=Math.sin(ct);return[Math.cos(ct)*h*xt*(1-.15*ws(st,.1,.15)),C*u*xt*(C<0?.8:1),(st-.5)*l]}),r,"body");d.position.y=f;let[p,x,g]=n.headL,m=new vt;m.position.set(0,f+u*.15,l/2-.03),r.add(m);let E=m;c(Ln(8,16,(st,ct)=>{let xt=Fe(h*.8,x*.95,st),C=Fe(u*.8,g*.95,st);return[Math.cos(ct)*xt,Math.sin(ct)*C,-.05+st*.09]}),m,"neck");let y=new vt;y.position.set(0,0,.04+p*.3),m.add(y),c(Ln(24,18,(st,ct)=>{let xt=-p*.3+st*p*1.3,C=Math.pow(Math.max(0,1-Math.pow(Math.abs(2*st-1),3)),1/3),rt=x*(1-.45*st*st)*C,q=g*(1-.3*st)*C,et=Math.sin(ct);return[Math.cos(ct)*rt,-g*.15*st+et*q*(et<0?.75:1),xt]}),y,"head");let S=new ee({color:n.eye,roughness:.05});for(let st of[-1,1]){let ct=new bt(new de(n.eyeR,14,10),S);ct.position.set(st*x*.8,g*.42,p*.12),y.add(ct);let xt=new bt(new de(n.eyeR*1.15,12,6,0,Math.PI*2,0,Math.PI*.35),a);xt.position.copy(ct.position),xt.rotation.z=-st*.5,xt.userData={part:"head"},y.add(xt),o.push(xt)}let P=new vt;P.position.set(0,-g*.35,p*.95),y.add(P);let w=new ee({color:n.forked?7172019:14711434,roughness:.4}),A=new bt(new Vt(.004,.005,.07,6),w);if(A.rotation.x=Math.PI/2,A.position.z=.035,P.add(A),n.forked)for(let st of[-1,1]){let ct=new bt(new Vt(.0025,.0035,.03,5),w);ct.rotation.set(Math.PI/2,0,st*.4),ct.position.set(st*.006,0,.08),P.add(ct)}P.visible=!1;let F=[],M=n.bone,b=Math.PI/2-.18;for(let st of[{f:1,sx:-1,off:0},{f:1,sx:1,off:Math.PI},{f:0,sx:-1,off:Math.PI},{f:0,sx:1,off:0}]){let ct=new vt;ct.position.set(st.sx*h*.78,f-u*.2,(st.f?1:-1)*l*.3),r.add(ct);let xt=new vt;xt.rotation.z=st.sx*b,ct.add(xt);let C=n.legU;c(va(C,M*1.7,M*1.15,1.1),xt,"leg",{front:st.f,seg:0});let rt=new vt;rt.position.y=-C,rt.rotation.z=st.sx*(.12-b),xt.add(rt);let q=Math.max(.025,f-u*.2-C*Math.sin(Math.PI/2-b)-M*.5);c(va(q,M*1.15,M*.85),rt,"leg",{front:st.f,seg:1});let et=new vt;et.position.y=-q,et.rotation.z=-st.sx*.12,rt.add(et);let K=c(Di(M*1.3,M*.5,M*1.2),et,"paw",{front:st.f});for(let Pt=0;Pt<5;Pt++){let _t=(Pt-2)*.42+(st.f?.15:-.1)*-st.sx,v=c(Di(M*.32,M*.28,M*1.15),et,"paw",{front:st.f});v.position.set(Math.sin(_t)*M*1.5,0,Math.cos(_t)*M*1.5),v.rotation.y=_t,n.coat==="gecko"&&c(new de(M*.42,8,6),et,"paw",{front:st.f}).position.set(Math.sin(_t)*M*2.5,0,Math.cos(_t)*M*2.5)}F.push({yaw:ct,out:xt,knee:rt,paw:K,front:st.f,sx:st.sx,off:st.off,rest:xt.rotation.z})}let R=[],O=7,Z=n.tailL/O,I=new vt;I.position.set(0,f,-l/2+.03),r.add(I);for(let st=0;st<O;st++){let ct=n.tailR*(1-st/O*.88),xt=n.tailR*(1-(st+1)/O*.88),C=Ln(6,12,(q,et)=>{let K=Fe(ct,xt,q)*Rs(q,3);return[Math.cos(et)*K*1.1,Math.sin(et)*K*.85,-ct*.6+q*(Z+ct*1.2)]});C.rotateY(Math.PI);let rt=new vt;rt.position.z=st?-Z:0,I.add(rt),c(C,rt,"tail",{seg:st}),rt.rotation.x=st?.05:-.28,R.push(rt),I=rt}let N=new ee({color:e,roughness:.45,metalness:.15}),H=new bt(new de(1,22,10,0,Math.PI*2,0,Math.PI/2),N);H.scale.set(h*1.05,u*.45,l*.26),H.position.set(0,f+u*.7,0),H.castShadow=!0,r.add(H);let nt=new ee({map:kh(t,e),transparent:!0,roughness:.5,side:Oe});for(let st of[-1,1]){let ct=new bt(new cn(.075,.075),nt);ct.position.set(st*(h*.98+.004),f+u*.2,0),ct.rotation.y=st*Math.PI/2,r.add(ct)}let{flames:B,launcher:W}=Vh(r,f+u+.005,-.01,n.gearS||1),Q=new vt;Q.position.set(0,g*3,0),y.add(Q);for(let st=0;st<4;st++){let ct=new bt(new gr(.02),_c);ct.position.set(Math.cos(st*1.57)*.07,0,Math.sin(st*1.57)*.07),Q.add(ct)}Q.visible=!1;let tt=new xs(new ji({map:Da,depthTest:!1}));tt.scale.set(.11,.11,1),tt.position.set(0,g*4.2,0),tt.visible=!1,y.add(tt),s.updateMatrixWorld(!0);let ut=new Gn;for(let st of F)ut.setFromObject(st.paw),st.yaw.position.y-=ut.min.y;s.updateMatrixWorld(!0);let J=[];if(n.coat==="gecko")for(let st=0;st<420;st++)J.push([Ut(-.12,.12),Ut(.02,.2),Ut(-.7,.45),Ut(.006,.013)]);let it=new L,dt=new Ft;for(let st of o){let ct=st.geometry.attributes.position,xt=new Float32Array(ct.count*3);for(let C=0;C<ct.count;C++){it.fromBufferAttribute(ct,C);let rt=it.x,q=it.y,et=it.z;it.applyMatrix4(st.matrixWorld),Bd(n,{part:st.userData.part,front:st.userData.front,seg:st.userData.seg,zStop:0,lx:rt,ly:q,lz:et,x:it.x,y:it.y,z:it.z,cy:f,spots:J},dt);let K=.92+.16*Ni(it.x*60+it.z*23,it.y*60,0,3);xt[C*3]=dt.r*K,xt[C*3+1]=dt.g*K,xt[C*3+2]=dt.b*K}st.geometry.setAttribute("color",new me(xt,3))}let It=nc*(n.scale||1);s.scale.setScalar(It);let St=new bt(new cn(1,1),new Tn({map:wa,transparent:!0,depthWrite:!1}));St.rotation.x=-Math.PI/2,St.position.y=.04,St.scale.set(h*6*It,(l+n.tailL*.6)*1.3*It,1),i.add(St);let Ht={hat:[0,g*.92,p*.02],s:x*.85,eye:[x*.8,g*.42,p*.12],er:n.eyeR,cape:[0,f+u*.95,l*.28],capeW:h,capeL:l};return{root:i,model:s,body:r,torso:d,neckPiv:m,headPiv:E,head:y,legs:F,tails:R,ears:[],tongue:P,flames:B,stars:Q,excl:tt,blob:St,b:n,launcher:W,anim:Iv,vestMat:N,hi:Ht,crown:null}}function Zd(n,t,e){for(let i of n.flames)i.visible=t.nitro,t.nitro&&i.scale.set(1,.7+Math.random()*.6,1);n.stars.visible=t.stun>0,t.stun>0&&(n.stars.rotation.y=e*7),n.excl.visible=t.spook>0,n.blob.material.opacity=1/(1+t.y*.6),n.cape&&(n.cape.rotation.x=1.3+ce(t.v/14,0,1)*.35+Math.sin(e*13)*.06*ce(t.v/14,0,1))}function Iv(n,t,e){let i=ce(t.v/10,0,1),s=t.y>.05,r=t.phase*1.25;for(let c of n.legs){if(s){c.yaw.rotation.y=(c.front?.7:-.7)*-c.sx,c.out.rotation.z=c.rest+c.sx*.35;continue}let l=r+c.off;c.yaw.rotation.y=-c.sx*Math.sin(l)*.65*i,c.out.rotation.z=c.rest+c.sx*Math.max(0,Math.cos(l))*.35*i}let a=i>.05?i:.25;n.body.rotation.y=Math.sin(r)*.13*i,n.body.position.y=t.idle?Math.max(0,Math.sin(e*2.6))*.018:i*.015,n.neckPiv.rotation.y=-Math.sin(r)*.18*i+(t.idle?Math.sin(e*.8)*.35:ce(-t.yawRate*.2,-.4,.4)),n.neckPiv.rotation.x=s?-.2:t.idle?-Math.max(0,Math.sin(e*2.6))*.12:0,n.tails.forEach((c,l)=>{c.rotation.y=Math.sin((i>.05?r:e*1.4)-l*.8)*(.2+.05*l)*a,l===0&&(c.rotation.x=s?.1:-.28)});let o=n.b.forked?Math.sin(e*2.3+n.b.len*10)>.9:Math.sin(e*1.3)>.97;n.tongue.visible=o,o&&(n.tongue.scale.z=.6+Math.abs(Math.sin(e*30))*.6),n.model.rotation.z=ce(-t.yawRate*.1,-.2,.2)+(t.stun>0?Math.sin(e*18)*.15:0),Zd(n,t,e)}function Lv(n,t,e){let i=n.b,s=ce(t.v/12,0,1),r=t.y>.05;for(let o of n.legs){let c=t.phase+o.off,l=Math.sin(c),h=Math.max(0,-Math.cos(c)),u=o.rh,f=o.rk,d=o.ra;r?o.front?(u=-.8,f=.1,d=-.1):(u=.9,f=.2,d=-.3):s>.01&&(o.front?(u+=l*.8*s,f+=(h*1.2-.1)*s,d+=h*.9*s):(u+=l*.75*s,f+=h*.7*s,d-=h*.8*s)),o.hip.rotation.x=u,o.knee.rotation.x=f,o.ank.rotation.x=d}n.body.position.y=s*.035*Math.cos(t.phase)*(r?0:1),n.body.rotation.x=s*.06*Math.sin(t.phase+.8)+(r?ce(-t.vy*.03,-.35,.35):0),n.model.rotation.z=ce(-t.yawRate*.16,-.32,.32)+(t.stun>0?Math.sin(e*18)*.15:0),n.neckPiv.rotation.x=-i.neckA+.28*s+Math.sin(t.phase)*.07*s,n.headPiv.rotation.x=i.neckA-.12+(i.headDown||0)-.22*s,n.head.rotation.y=ce(-t.yawRate*.22,-.45,.45)+(t.idle?Math.sin(e*.7)*.35:0);for(let o of n.ears)o.type==="erect"||o.type==="fold"||o.type==="round"?o.piv.rotation.x=o.rx-.5*s+(t.idle?Math.max(0,Math.sin(e*3+o.sx))*.1:0):o.piv.rotation.x=o.rx+.9*s+Math.sin(t.phase*2)*.18*s;let a=1-s*.75;n.tails.forEach((o,c)=>{o.rotation.y=Math.sin(e*11-c*.6)*(c?.2:.45)*a,c===0&&(o.rotation.x=Fe(i.tail[2],-.2,s*.6)+Math.sin(t.phase)*.1*s)}),n.tongue.visible=!i.noTongue&&(t.v>6||t.idle),n.tongue.rotation.x=Math.sin(t.phase*2)*.25*s+(t.idle?Math.sin(e*9)*.1:0),n.torso.scale.y=1+Math.sin(e*(t.v>1?9:3.5))*.012;for(let o of n.flames)o.visible=t.nitro,t.nitro&&o.scale.set(1,.7+Math.random()*.6,1);n.stars.visible=t.stun>0,t.stun>0&&(n.stars.rotation.y=e*7),n.excl.visible=t.spook>0,n.blob.material.opacity=1/(1+t.y*.6),n.cape&&(n.cape.rotation.x=1.3+ce(t.v/14,0,1)*.35+Math.sin(e*13)*.06*ce(t.v/14,0,1))}var Ns=[{id:"parque",name:"PARQUE CENTRAL",W:18,grip:1,hills:55,surface:"dirt",ground:[92,138,58],trees:"broad",puddle:"mud",ctrl:[[0,-130],[90,-140],[165,-105],[185,-30],[140,25],[150,100],[95,160],[0,150],[-55,105],[-120,140],[-180,85],[-170,0],[-115,-60],[-80,-120]],sky:{zen:2976720,hor:12376047,gnd:7043676,sun:16773336,dir:[.45,.62,.3],haze:.5},fog:[12376047,180,900],light:{sun:3.2,col:16773854,hemi:.35},rail:16053492,curb:["#d62828","#ffffff"],stand:[10133931,3039156],mtn:[5334079,7168597]},{id:"praia",name:"PRAIA DO LATIDO",W:18,grip:.9,hills:14,surface:"sand",ground:[226,204,158],trees:"palm",puddle:"water",sea:-128,ctrl:[[-200,-40],[-120,-90],[0,-100],[120,-95],[200,-60],[230,10],[190,70],[110,80],[60,40],[0,50],[-50,110],[-130,120],[-210,60]],sky:{zen:2964358,hor:16753768,gnd:9071192,sun:16756848,dir:[.2,.09,-.97],haze:1.3},fog:[15770748,160,850],light:{sun:2.8,col:16758405,hemi:.3},rail:9132587,curb:["#1e88e5","#ffffff"],stand:[12028762,1019816],mtn:[8022610,6253386]},{id:"neve",name:"PICO NEVADO",W:18,grip:.78,hills:80,surface:"snow",ground:[236,241,248],trees:"pine",puddle:"ice",snow:!0,ctrl:[[0,-150],[100,-160],[170,-110],[150,-40],[200,20],[180,110],[100,150],[40,100],[-20,140],[-110,150],[-170,90],[-130,30],[-190,-40],[-120,-120]],sky:{zen:6260408,hor:14542834,gnd:13621474,sun:16774890,dir:[-.4,.42,.5],haze:.8},fog:[14542834,110,620],light:{sun:2.4,col:15922943,hemi:.5},rail:13840175,curb:["#d32f2f","#ffffff"],stand:[9268835,12000284],mtn:[5923954,7173508]}],yt=Ns[0],Lt=18,Ee=1,$e=1400,qe=[],si=[],Ls=[],As=[];function Dv(n){let t=new ua(n.ctrl.map(e=>new L(e[0],0,e[1])),!0,"centripetal");Ee=t.getLength(),qe.length=si.length=Ls.length=As.length=0;for(let e=0;e<$e;e++){let i=e/$e,s=t.getPointAt(i),r=t.getTangentAt(i);r.y=0,r.normalize(),qe.push(s),si.push(r),Ls.push(new L(-r.z,0,r.x)),e%6===0&&As.push(s)}}var Ec=n=>(n%Ee+Ee)%Ee,pn=n=>(n=Ec(n),n>Ee/2?n-Ee:n),Sd=new L,tc=new L,bd=new L;function Ds(n){let t=Ec(n)/Ee*$e,e=Math.floor(t)%$e,i=(e+1)%$e,s=t-Math.floor(t);return Sd.copy(qe[e]).lerp(qe[i],s),tc.copy(si[e]).lerp(si[i],s).normalize(),bd.set(-tc.z,0,tc.x),{p:Sd,t:tc,r:bd}}function He(n,t,e=0){let i=Ds(n);return new L(i.p.x+i.r.x*t,e,i.p.z+i.r.z*t)}function ri(n){let t=Ds(n);return Math.atan2(t.t.x,t.t.z)}function Xh(n,t){let e=!1;for(let i=0,s=As.length-1;i<As.length;s=i++){let r=As[i],a=As[s];r.z>t!=a.z>t&&n<(a.x-r.x)*(t-r.z)/(a.z-r.z)+r.x&&(e=!e)}return e}function Sc(n,t){let e=1/0;for(let i of As){let s=i.x-n,r=i.z-t,a=s*s+r*r;a<e&&(e=a)}return Math.sqrt(e)}function En(n,t){let e=Sc(n,t);if(yt.sea!==void 0&&t<yt.sea)return Math.max(-7,-(yt.sea-t)*.09)*Ot(Lt/2+6,Lt/2+22,e);let i=Ot(Lt/2+16,Lt/2+110,e)*Ot(70,150,Math.hypot(n-qe[0].x,t-qe[0].z));return i<=0||Xh(n,t)?0:i*Math.max(0,Li(n*.004+31,t*.004+17,4)-.3)*yt.hills}var Le=null,Yh=[],$h=[],Ma=null,hc=null,qh=[],Ui=null,wr=null,ts=[],Eh=[],uc=[],fc=[],Ar=[],Aa=[],Rr=[],Sh=null,Ea=null,gt=(n,t=.85,e=0,i={})=>new ee({color:n,roughness:t,metalness:e,...i});function At(n,t,e=!0,i=!0,s=Le){let r=new bt(n,t);return r.castShadow=e,r.receiveShadow=i,s.add(r),r}function wn(n,t,e,i=!0){let s=new Fo(n,t,e);return s.castShadow=i,s.receiveShadow=!0,s.frustumCulled=!1,Le.add(s),s}var Td=new Ce,wd=new fi,Uv=new fr,jt=new L,Ov=new L;function An(n,t,e,i,s,r,a,o,c,l,h){wd.setFromEuler(Uv.set(r,a,o)),Td.compose(jt.set(e,i,s),wd,Ov.set(c,l??c,h??c)),n.setMatrixAt(t,Td)}function Cr(n){n.traverse(t=>{t.geometry&&!t.geometry.userData.keep&&t.geometry.dispose(),t.material&&[].concat(t.material).forEach(e=>{if(!Mh.has(e)){for(let i of["map","bumpMap","normalMap","emissiveMap"])e[i]&&!Mh.has(e[i])&&e[i].dispose();e.dispose()}})})}function xa(n,t,e,i,s,r=!0){let a=[],o=[],c=[];for(let h=0;h<=$e;h++){let u=h%$e,f=qe[u],d=Ls[u];a.push(f.x+d.x*n,e,f.z+d.z*n,f.x+d.x*t,e,f.z+d.z*t);let p=h/$e*Ee/i;if(o.push(0,p,1,p),h<$e){let x=h*2;c.push(x,x+1,x+2,x+1,x+3,x+2)}}let l=new Ie;return l.setAttribute("position",new fe(a,3)),l.setAttribute("uv",new fe(o,2)),l.setIndex(c),l.computeVertexNormals(),At(l,s,!1,r)}function Ad(n,t,e,i){let s=[],r=[];for(let c=0;c<=$e;c+=2){let l=c%$e,h=qe[l],u=Ls[l];s.push(h.x+u.x*n,t,h.z+u.z*n,h.x+u.x*n,e,h.z+u.z*n)}let a=s.length/6;for(let c=0;c<a-1;c++){let l=c*2;r.push(l,l+2,l+1,l+1,l+2,l+3)}let o=new Ie;o.setAttribute("position",new fe(s,3)),o.setIndex(r),o.computeVertexNormals(),At(o,i,!0,!0)}function Nv(n){let e=Ns.indexOf(yt)*13,i=Bh(256,(r,a)=>{let o=Li(r/32,a/32,5,8,e),c=Li(r/8,a/8,3,32,e+5),l=Er(r,a,e+9),h=1-.07*ws(r/256,.33,.07)-.07*ws(r/256,.67,.07);if(n==="dirt"){let d=132+o*70+c*18,p=90+o*50+c*14,x=56+o*32+c*8;return l>.985?(d+=40,p+=36,x+=30):l<.012&&(d-=40,p-=34,x-=24),[d*h,p*h,x*h]}if(n==="sand"){let d=Math.sin(a*.45+o*9)*7;return[(178+o*30+d)*h,(146+o*26+d)*h,(102+o*20+d*.6)*h]}let u=l>.992?20:0,f=1-.1*ws(r/256,.25,.05)-.1*ws(r/256,.75,.05);return[(158+o*34+u)*h*f,(172+o*26+u)*h*f,(196+o*16+u)*h*f]}),s=i.getContext("2d");for(let r=0;r<70;r++){let a=30+Yt()*196,o=Yt()*256,c=Yt()*.4-.2;s.save(),s.translate(a,o),s.rotate(c),s.fillStyle=n==="snow"?"rgba(120,140,170,.22)":"rgba(40,24,10,.22)",s.beginPath(),s.ellipse(0,4,4,3.5,0,0,7),s.fill();for(let[l,h]of[[-4,-2],[-1.4,-4.5],[1.4,-4.5],[4,-2]])s.beginPath(),s.ellipse(l,h,1.5,1.8,0,0,7),s.fill();s.restore()}return i}function Fv(){let[n,t,e]=yt.ground,i=Ns.indexOf(yt)*7+3,s=Bh(256,(r,a)=>{let o=Li(r/16,a/16,4,16,i),c=Er(r,a,i),l=.78+o*.4+(c-.5)*(yt.ground[0]<150?.22:.08);return[n*l,t*l,e*l]});if(yt.trees==="broad"){let r=s.getContext("2d");for(let a=0;a<2600;a++){let o=Yt()*256,c=Yt()*256,l=110+Yt()*90|0;r.strokeStyle=`rgba(${l*.55|0},${l},${l*.35|0},.5)`,r.lineWidth=1,r.beginPath(),r.moveTo(o,c),r.lineTo(o+Yt()*2-1,c-2-Yt()*3),r.stroke()}}return s}function Zh(n){Le&&(rn.remove(Le),Cr(Le)),oi.clear(),bn.clear(),yt=Ns[n],Lt=yt.W,ec=1e3+n*77,Dv(yt),Le=new vt,rn.add(Le),Rr=[],Yh=[],$h=[],qh=[];let t=yt.sky;bs.zen.value.setHex(t.zen),bs.hor.value.setHex(t.hor),bs.gnd.value.setHex(t.gnd),bs.sunCol.value.setHex(t.sun),yh.set(...t.dir).normalize(),bs.sunDir.value.copy(yh),bs.haze.value=t.haze,rn.fog=new Uo(yt.fog[0],yt.fog[1],yt.fog[2]),Sn.color.setHex(yt.light.col),Sn.intensity=yt.light.sun,ac.color.setHex(t.hor),ac.groundColor.setHex(t.gnd),gv(),zv(),Bv(),Hv(),kv(),Gv(),Wv(),Xv(),$v(),qv(),Zv(),Jv(),Qv(),tM(),iM(),yM(),sM(),Ui&&(rn.remove(Ui),Ui.geometry.dispose(),Ui=null),yt.snow&&Kv()}function zv(){let t=k.qual===0?100:150,e=new cn(1700,1700,t,t);e.rotateX(-Math.PI/2);let i=e.attributes.position,s=e.attributes.uv,r=new Float32Array(i.count*3);for(let c=0;c<i.count;c++){let l=i.getX(c),h=i.getZ(c),u=En(l,h);i.setY(c,u),s.setXY(c,l/9,h/9);let f=.82+.36*Li(l*.012,h*.012,3,0,5),d=f,p=f,x=f;if(yt.id==="parque"){let g=Ot(.55,.75,Li(l*.006+5,h*.006,3));d+=g*.25,x-=g*.1}if(yt.id==="praia"&&u<-.3&&(d*=.8,p*=.78,x*=.72),yt.id==="neve"&&u>20){let g=Ot(.62,.72,Li(l*.03,h*.03,2));d-=g*.45,p-=g*.42,x-=g*.38}r[c*3]=d,r[c*3+1]=p,r[c*3+2]=x}e.setAttribute("color",new me(r,3)),e.computeVertexNormals();let a=an(Fv());At(e,new ee({map:a,vertexColors:!0,roughness:yt.id==="neve"?.7:1}),!1,!0);let o=At(new cn(9e3,9e3),new ee({color:new Ft(`rgb(${yt.ground.join(",")})`).multiplyScalar(.8),roughness:1}),!1,!1);if(o.rotation.x=-Math.PI/2,o.position.y=yt.sea!==void 0?-8:-.4,wr=null,yt.sea!==void 0){let c=Bh(128,(h,u)=>{let f=(x,g)=>Li(x/16,g/16,3,8,77),d=f(h+1,u)-f(h-1,u),p=f(h,u+1)-f(h,u-1);return[128-d*400,128-p*400,255]});wr=an(c,40,40,!1);let l=At(new cn(4e3,4e3),new ee({color:1007490,roughness:.12,metalness:.1,normalMap:wr,normalScale:new ht(.6,.6)}),!1,!1);l.rotation.x=-Math.PI/2,l.position.set(0,-1.1,-1400)}}function Bv(){let n=Nv(yt.surface),t=an(n),e=yt.surface==="snow"?.55:.95;xa(-Lt/2,Lt/2,.03,Lt,new ee({map:t,bumpMap:an(n,1,1,!1),bumpScale:1.2,roughness:e}));let i=an(Ge(4,8,a=>{a.fillStyle=yt.curb[0],a.fillRect(0,0,4,4),a.fillStyle=yt.curb[1],a.fillRect(0,4,4,4)}));i.magFilter=sn;let s=new ee({map:i,roughness:.6});xa(-Lt/2-1.3,-Lt/2,.05,6,s),xa(Lt/2,Lt/2+1.3,.05,6,s);let r=new ee({map:t,roughness:1,color:13619151});xa(-Lt/2-2.6,-Lt/2-1.3,.035,Lt,r),xa(Lt/2+1.3,Lt/2+2.6,.035,Lt,r)}function Hv(){let n=yt.id==="praia",t=gt(yt.rail,n?.9:.35,n?0:.3,{side:Oe});for(let r of[-1,1])Ad(r*(Lt/2+2.6),.95,1.12,t),Ad(r*(Lt/2+2.6),.45,.58,t);let e=Math.floor(Ee/4)*2,i=wn(new Vt(.08,.1,1.25,5),gt(n?7029795:14606046,.5,n?0:.6),e),s=0;for(let r=0;r<Ee-2&&s<e-1;r+=4)for(let a of[-1,1]){let o=He(r,a*(Lt/2+2.6));An(i,s++,o.x,.62,o.z,0,0,0,1)}i.count=s}function kv(){let n=an(Ge(16,4,o=>{for(let c=0;c<16;c++)for(let l=0;l<4;l++)o.fillStyle=(c+l)%2?"#111":"#f4f4f4",o.fillRect(c,l,1,1)}));n.magFilter=sn;let t=new bt(new cn(Lt,2.4),gt(16777215,.6,0,{map:n}));t.rotation.x=-Math.PI/2,t.receiveShadow=!0;let e=new vt;e.add(t),e.position.copy(He(0,0,.06)),e.rotation.y=ri(0),Le.add(e);let i=new vt,s=gt(2830134,.35,.8);for(let o of[-1,1])At(new xe(.9,11,.9),s,!0,!0,i).position.set(o*(Lt/2+3.2),5.5,0),At(new xe(1.8,.6,1.8),gt(5593958,.6,.4),!0,!0,i).position.set(o*(Lt/2+3.2),.3,0);let r=an(Ge(512,64,(o,c,l)=>{let h=o.createLinearGradient(0,0,0,l);h.addColorStop(0,"#1a1f2b"),h.addColorStop(1,"#0c0f16"),o.fillStyle=h,o.fillRect(0,0,c,l),o.fillStyle="#ff7a1a",o.fillRect(0,0,c,4),o.fillRect(0,l-4,c,4),o.font="italic 900 38px Arial",o.textAlign="center",o.textBaseline="middle",o.fillStyle="#fff",o.fillText(`LARGADA \xB7 ${yt.name}`,c/2,l/2+2)})),a=gt(16777215,.4,0,{map:r,emissive:16777215,emissiveMap:r,emissiveIntensity:.35});At(new xe(Lt+7.3,2.2,.6),[s,s,s,s,a,a],!0,!0,i).position.set(0,10,0);for(let o=0;o<3;o++){let c=new ee({color:2230280,emissive:0,roughness:.3});At(new de(.42,16,12),c,!1,!1,i).position.set((o-1)*1.2,8.2,-.3),At(new xe(1.05,1.05,.5),s,!1,!1,i).position.set((o-1)*1.2,8.2,.05),Yh.push(c)}i.position.copy(He(0,0)),i.rotation.y=ri(0),Le.add(i)}function bh(n,t){Yh.forEach((e,i)=>{let s=t||i<n,r=s?t?1113952:16719904:2230280;e.color.setHex(r),e.emissive.setHex(s?r:0),e.emissiveIntensity=s?2.2:0})}function Jh(){return Xh(qe[0].x+Ls[0].x*30,qe[0].z+Ls[0].z*30)?-1:1}function Gv(){let n=Jh(),t=new xe(1,1,1),e={concrete:[],seat:[],roof:[],pillar:[]},i=[],s=(l,h,u,f,d,p,x,g)=>{let m=He(h,u,f);l.push([m.x,m.y,m.z,g,d,p,x])};for(let l=-52;l<=52;l+=4){let h=ri(l);for(let u=0;u<7;u++){let f=n*(Lt/2+7+u*1.6);s(e.concrete,l,f,.4*(u+1),1.7,.8*(u+1),4.02,h),s(e.seat,l,f+n*.3,.8*(u+1)+.12,.5,.25,3.9,h);for(let d of[-1.3,0,1.3]){if(Yt()<.15)continue;let p=Ds(l+d);i.push({x:p.p.x+p.r.x*(f+n*.2),z:p.p.z+p.r.z*(f+n*.2),y:.8*(u+1)+.2,ph:Yt()*6,yaw:h})}}s(e.roof,l,n*(Lt/2+13),11.5,14,.3,4.05,h),s(e.concrete,l,n*(Lt/2+19),5.75,.4,11.5,4.05,h),l%16===0&&s(e.pillar,l,n*(Lt/2+7.2),5.75,.4,11.5,.4,h)}let r={concrete:gt(yt.stand[0],.9),seat:gt(yt.stand[1],.5),roof:gt(15263976,.4,.5),pillar:gt(3817287,.4,.7)};for(let l in e){let h=wn(t,r[l],e[l].length);e[l].forEach((u,f)=>An(h,f,u[0],u[1],u[2],0,u[3],0,u[4],u[5],u[6]))}let a=[15022389,2001125,16635957,4431943,16777215,16740419,9315498,44225,2171169],o=[15843965,14724201,9262372,13010498,16767916,7029286];Ma=wn(new Vt(.26,.32,.95,6),gt(16777215,.8),i.length,!1),hc=wn(new de(.21,7,5),gt(16777215,.7),i.length,!1);let c=new Ft;i.forEach((l,h)=>{Ma.setColorAt(h,c.setHex(a[Yt()*a.length|0])),hc.setColorAt(h,c.setHex(o[Yt()*o.length|0])),$h.push(l)}),Rr.push([qe[0].x,qe[0].z,80])}var Ra=.3;function Vv(n){Ma&&($h.forEach((t,e)=>{let i=Math.max(0,Math.sin(n*8+t.ph))*.4*Ra;An(Ma,e,t.x,t.y+.47+i,t.z,0,t.yaw,0,1),An(hc,e,t.x,t.y+1.15+i,t.z,0,0,0,1)}),Ma.instanceMatrix.needsUpdate=hc.instanceMatrix.needsUpdate=!0)}function Wv(){let n=Jh();[["RA\xC7\xC3O CROCK","energia para campe\xF5es","#ffcc00","#c62828"],["OSSO DE OURO","o petisco oficial","#101a3a","#ffc53d"],["PET SHOP 2000","tudo para seu c\xE3o","#00a6c8","#ffffff"],["LATIDO FM","97.5 \xB7 a r\xE1dio do auau","#e91e63","#ffffff"],["TURBO DOG","nitro para patas","#111111","#76ff03"],["COLEIRA MAX","aperta sem machucar","#ff8f00","#1a1a1a"],["VET 24H","plant\xE3o veterin\xE1rio","#ffffff","#1565c0"],["PETISCO BOM","sabor bacon","#2e7d32","#ffffff"]].forEach((e,i)=>{let s=Ee*(.1+i*.105),r=an(Ge(256,128,(p,x,g)=>{p.fillStyle=e[2],p.fillRect(0,0,x,g);let m=p.createLinearGradient(0,0,0,g);m.addColorStop(0,"rgba(255,255,255,.18)"),m.addColorStop(1,"rgba(0,0,0,.18)"),p.fillStyle=m,p.fillRect(0,0,x,g),p.fillStyle=e[3],p.fillRect(0,g-10,x,10),p.font="italic 900 38px Arial",p.textAlign="center",p.fillText(e[0],x/2,62),p.font="600 18px Arial",p.fillText(e[1].toUpperCase(),x/2,94)})),a=new vt,o=gt(2764341,.5,.6);At(new xe(12,6,.35),[o,o,o,o,gt(16777215,.5,0,{map:r}),o],!0,!0,a).position.y=6.5;for(let p of[-4,4])At(new xe(.35,4,.35),o,!0,!0,a).position.set(p,2,0);let c=Ds(s),l=n*(Lt/2+10),h=c.p.x+c.r.x*l,u=c.p.z+c.r.z*l,f=c.r.x,d=c.r.z;a.position.set(h,En(h,u),u),a.rotation.y=Math.atan2(-n*f,-n*d),Le.add(a)})}function Jd(n){let t=[];for(let i=-260;i<=260;i+=12)for(let s=-260;s<=260;s+=12){if(!Xh(i,s))continue;let r=Sc(i,s);r>Lt/2+22&&t.push([i,s,r])}t.sort((i,s)=>s[2]-i[2]);let e=[];for(let i of t)if(e.every(s=>Math.hypot(s[0]-i[0],s[1]-i[1])>55)&&e.push(i),e.length>=n)break;return e}function Xv(){let n=Jd(4),t=(e,i,s)=>{if(!n[i])return;let[r,a]=n[i];e.position.set(r,0,a),e.rotation.y=Yt()*6,Le.add(e),Rr.push([r,a,s])};if(yt.id==="parque"){{let e=new vt,i=gt(13209170,.8),s=gt(10558749,.6);At(new xe(14,10,14),i,!0,!0,e).position.y=5;let r=new Qi;r.moveTo(-8.5,0),r.lineTo(0,6.5),r.lineTo(8.5,0),r.lineTo(-8.5,0),At(new vs(r,{depth:16,bevelEnabled:!1}),s,!0,!0,e).position.set(0,10,-8);let a=At(new Vt(3,3,.4,20,1,!1,0,Math.PI),gt(1708042,1),!1,!0,e);a.rotation.set(Math.PI/2,Math.PI/2,0),a.position.set(0,4,7.05),At(new xe(6,4,.4),gt(1708042,1),!1,!0,e).position.set(0,2,7.05),At(new Vt(2.2,1.6,1.2,20),gt(13840175,.35,.3),!0,!0,e).position.set(6,.6,12),t(e,0,22)}{let e=new vt,i=gt(14163750,.35,.4),s=gt(15909166,.3,.8);At(new Vt(3.6,4,1.2,24),i,!0,!0,e).position.y=.6,At(new Vt(2.6,2.8,9,24),i,!0,!0,e).position.y=5.5,At(new de(2.7,24,12,0,Math.PI*2,0,Math.PI/2),i,!0,!0,e).position.y=10,At(new Vt(.7,.9,1.4,12),s,!0,!0,e).position.y=13;for(let r of[-1,1]){let a=At(new Vt(1,1,2,14),s,!0,!0,e);a.rotation.z=Math.PI/2,a.position.set(r*3.2,7,0)}t(e,1,12)}{let e=new vt,i=At(new ys(26,40),gt(12167034,1),!1,!0,e);i.rotation.x=-Math.PI/2,i.position.y=.04;let s=At(new ys(23,40),gt(2781071,.08,.1),!1,!0,e);s.rotation.x=-Math.PI/2,s.position.y=.08,t(e,2,30)}{let e=new vt,i=gt(15985362,.45),s=At(new Vt(1.4,1.4,12,20),i,!0,!0,e);s.rotation.z=Math.PI/2,s.position.y=2.4;for(let r of[-6,6])for(let a of[-1.4,1.4])At(new de(2.2,20,14),i,!0,!0,e).position.set(r,2.4,a);t(e,3,12)}}else if(yt.id==="praia"){{let e=new vt,i=an(Ge(8,64,s=>{for(let r=0;r<8;r++)s.fillStyle=r%2?"#f4f4f4":"#d32f2f",s.fillRect(0,r*8,8,8)}));At(new Vt(3,4.2,26,24),gt(16777215,.5,0,{map:i}),!0,!0,e).position.y=13,At(new Vt(3.6,3.6,.6,24),gt(2236962,.5,.6),!0,!0,e).position.y=26.3,At(new Vt(2.4,2.4,3,16),gt(16774064,.1,0,{emissive:16769674,emissiveIntensity:1.5}),!1,!1,e).position.y=28,At(new je(3,3,16),gt(12000284,.5,.3),!0,!0,e).position.y=31,t(e,0,14)}{let e=new vt,i=gt(14268286,1);At(new xe(14,5,14),i,!0,!0,e).position.y=2.5;for(let[s,r]of[[-7,-7],[7,-7],[-7,7],[7,7]])At(new Vt(2.2,2.6,9,12),i,!0,!0,e).position.set(s,4.5,r),At(new je(2.6,3.5,12),i,!0,!0,e).position.set(s,10.7,r);At(new Vt(3,3.4,11,14),i,!0,!0,e).position.set(0,5.5,0),t(e,1,16)}{let e=new vt,i=[15022389,2001125,16635957,4431943,16740419];for(let s=0;s<7;s++){let r=Ut(-14,14),a=Ut(-14,14);At(new Vt(.12,.12,5,8),gt(15658734,.4,.5),!0,!0,e).position.set(r,2.5,a),At(new je(3.2,1.4,12,1,!0),gt(i[s%5],.6,0,{side:Oe}),!0,!0,e).position.set(r,5.2,a);let o=At(new xe(1.6,.05,3),gt(i[(s+2)%5],.9),!1,!0,e);o.position.set(r+2,.05,a),o.rotation.y=Yt()}t(e,2,20)}}else{{let e=new vt,i=gt(7162413,.9),s=gt(16054527,.6);At(new xe(14,8,11),i,!0,!0,e).position.y=4;let r=new Qi;r.moveTo(-8.5,0),r.lineTo(0,6),r.lineTo(8.5,0),r.lineTo(-8.5,0),At(new vs(r,{depth:13,bevelEnabled:!1}),s,!0,!0,e).position.set(0,8,-6.5),At(new xe(1.6,6,1.6),gt(7829367,.9),!0,!0,e).position.set(4,12,0);let a=gt(16765562,.3,0,{emissive:16756800,emissiveIntensity:1.2});for(let o of[-4,4])At(new xe(2,2,.2),a,!1,!1,e).position.set(o,4.5,5.55);t(e,0,16)}{let e=new vt,i=gt(16251647,.6);for(let s=0;s<3;s++){let r=(s-1)*7,a=1+s*.15;At(new de(2*a,20,14),i,!0,!0,e).position.set(r,1.8*a,0),At(new de(1.4*a,20,14),i,!0,!0,e).position.set(r,4.4*a,0),At(new de(.95*a,20,14),i,!0,!0,e).position.set(r,6.4*a,0);let o=At(new je(.18*a,1*a,10),gt(16742938,.6),!0,!0,e);o.rotation.x=Math.PI/2,o.position.set(r,6.4*a,1.3*a),At(new Vt(.7*a,.7*a,1.2*a,16),gt(1710618,.5),!0,!0,e).position.set(r,7.6*a,0)}t(e,1,14)}{let e=new vt,i=At(new ys(24,40),gt(12575999,.05,.1),!1,!0,e);i.rotation.x=-Math.PI/2,i.position.y=.06,t(e,2,28)}}}var ai=null,Kd=new ee({vertexColors:!0,flatShading:!0,roughness:.88});Mh.add(Kd);function Yv(){let n=window.MODELOS;if(n)try{let t=atob(n.data),e=new Uint8Array(t.length);for(let r=0;r<t.length;r++)e[r]=t.charCodeAt(r);let i=e.buffer,s=new Ft;ai={};for(let r of n.meta){let a=new Int16Array(i,r.p,r.v*3),o=new Uint8Array(i,r.c,r.v*3),c=r.big?new Uint32Array(i,r.x,r.i):new Uint16Array(i,r.x,r.i),l=new Float32Array(r.v*3),h=new Float32Array(r.v*3);for(let f=0;f<r.v;f++){for(let d=0;d<3;d++)l[f*3+d]=r.min[d]+(a[f*3+d]+32767)/65534*r.size[d];s.setRGB(o[f*3]/255,o[f*3+1]/255,o[f*3+2]/255,be),h[f*3]=s.r,h[f*3+1]=s.g,h[f*3+2]=s.b}let u=new Ie;u.setAttribute("position",new me(l,3)),u.setAttribute("color",new me(h,3)),u.setIndex(new me(r.big?new Uint32Array(c):new Uint16Array(c),1)),u.computeVertexNormals(),u.computeBoundingSphere(),u.userData.keep=!0,ai[r.n]={geo:u,size:r.size}}}catch(t){console.warn("modelos n\xE3o carregados",t),ai=null}}var di=(n,t)=>ai?Object.keys(ai).filter(e=>e.startsWith(n)&&(!t||t(e))):[],$n=n=>n[Yt()*n.length|0];function Sr(n,t=!0){let e={};for(let i of n)(e[i[0]]=e[i[0]]||[]).push(i);for(let i in e){let s=ai[i];if(!s)continue;let r=e[i],a=wn(s.geo,Kd,r.length,t);r.forEach((o,c)=>An(a,c,o[1],o[2],o[3],0,o[4],0,o[5])),a.instanceMatrix.needsUpdate=!0}}var ni=2.1;function $v(){if(!ai)return;let n=[],t=Jh(),e=(o,c,l,h=ni,u=0)=>{let f=He(o,c);n.push([l,f.x,En(f.x,f.z),f.z,ri(o)+u,h])},i=(o,c,l,h)=>{for(let[u,f,d,p,x]of l){let g=o+f,m=c+d;n.push([u,g,En(g,m),m,p,(x||1)*ni])}Rr.push([o,c,h])},s={parque:"parque:lamp_1",praia:"parque:lamp_2",neve:"parque:lamp_4"}[yt.id],r=1;for(let o=40;o<Ee-30;o+=62)Math.abs(pn(o))<60||(e(o,r*(Lt/2+4.2),s,ni,r>0?Math.PI/2:-Math.PI/2),r=-r);for(let o=0;o<14;o++){let c=Yt()*Ee;if(Math.abs(pn(c))<70)continue;let l=Yt()<.5?-1:1;o%3===0?e(c,l*(Lt/2+4.6),$n(["vila:signpost_01","vila:signpost_02","vila:signpost_03"]),ni*1.3,Yt()*.6-.3):e(c,l*(Lt/2+6.5),yt.id==="neve"?"vila:bench":"parque:bench",ni,yt.id==="neve"?Math.PI/2:0)}let a=Jd(5);if(yt.id==="parque"){for(let c of[.13,.52,.83])for(let l of[-1,1])e(Ee*c+Ut(-6,6),l*(Lt/2+4.8),$n(["vila:haystack_01","vila:haystack_02","vila:haystack_03"]),ni*1.6,Yt()*6);let o=a[4]||a[3];o&&i(o[0],o[1],[["vila:well",0,0,.4],["vila:canopy",7,-4,1.2,1.3],["vila:trough",-5,4,.3],["vila:bucket",1.6,2.2,0],["vila:basin",-2.5,-2.5,0],["vila:haystack_01",-8,-3,0,1.5],["vila:haystack_02",-9.5,-.5,1,1.5],["vila:haystack_03",-7,1.5,2,1.5],["vila:firewood",6,4,.5],["vila:clothesline",3,8,.2],["vila:washboard",4.5,7,.3],["vila:barrel",8.5,1.5,0],["vila:barrel_broken",9.5,3.5,1],["vila:box",7.5,5,.4],["vila:stump",-4,-7,0],["vila:axe",-4,-7,.3],["vila:signpost_01",0,-9,0,1.3],["vila:pot_01",2.2,-1.8,0],["vila:pot_03",-1.5,2.6,0],["parque:fense_1",12,0,0],["parque:fense_1",12,7.2,0],["parque:fense_1",12,-7.2,0],["parque:fense_2",-12,0,0],["parque:fense_2",-12,6.4,0],["parque:fense_2",-12,-6.4,0]],20)}else if(yt.id==="praia"){let o=a[3]||a[2];o&&i(o[0],o[1],[["vila:chest",0,0,.6,1.4],["vila:barrel",2.5,1,0],["vila:barrel",3.4,-.6,1],["vila:barrel_broken",-2.5,2,.5],["vila:box",-2,-2,.3],["vila:box",-2.8,-1.2,1],["parque:bag_1",1.5,-2.6,0],["parque:bag_2",3,-2.5,1],["vila:canopy",-6,4,.5,1.4],["vila:pot_02",1,2.5,0],["vila:signpost_02",0,5.5,0,1.4],["vila:bench",6,3,1.2]],14);for(let c=0;c<26;c++){let l=Ut(-320,320),h=yt.sea-Ut(2,22);n.push([$n(di("pedra:stone_big")),l,En(l,h)-.5,h,Yt()*6,ni*Ut(.5,1.1)])}}else{let o=a[3]||a[2];o&&i(o[0],o[1],[["vila:firewood",0,0,0,1.4],["vila:firewood",1.8,.4,.3,1.4],["vila:stump",-2.5,1.5,0,1.3],["vila:axe",-2.5,1.5,.8,1.3],["vila:stump",-1,3.5,1],["vila:barrel",3.5,-2,0],["vila:box",4.5,-.5,.5],["vila:well",-6,-3,.8],["vila:signpost_03",0,-5,0,1.4],["vila:bucket",-4.5,-1,0],["vila:shovel",5.5,2,.3],["vila:rake",6,2.6,.5]],14);for(let c=0;c<12;c++){let l=c/12*Math.PI*2+Ut(-.2,.2),h=Ut(330,460),u=Math.cos(l)*h,f=Math.sin(l)*h;Sc(u,f)<90||n.push([$n(di("montanha:hill_winter")),u,En(u,f)-1,f,Yt()*6,Ut(3.5,5.5)])}}Sr(n)}function qv(){let n=k.qual===0,t=(o,c,l)=>{let h=[],u=0;for(;h.length<o&&u++<o*25;){let f=Ut(-l,l),d=Ut(-l,l),p=Sc(f,d);p<c||Rr.some(x=>Math.hypot(f-x[0],d-x[1])<x[2])||yt.sea!==void 0&&d<yt.sea+4||h.push([f,d,p])}return h},e=n?130:k.qual===1?220:320,i=new Ft;if(ai&&yt.trees!=="palm"){let o=yt.trees==="broad"?di("arvore:"):di("pinheiro:",l=>!/_0(09|10|11|19)$/.test(l)),c=t(yt.trees==="broad"?e:e*1.2|0,Lt/2+9,520);if(Sr(c.map(([l,h])=>[$n(o),l,En(l,h)-.2,h,Yt()*6.28,ni*Ut(.85,1.35)])),yt.trees==="pine"){let l=di("pinheiro:",h=>/_0(09|10|11|19)$/.test(h));Sr(t(n?20:45,Lt/2+5,300).map(([h,u])=>[$n(l),h,En(h,u),u,Yt()*6.28,ni*Ut(.9,1.4)]))}}else if(yt.trees==="broad"){let o=t(e,Lt/2+9,520),c=wn(new Vt(.3,.5,1,7).translate(0,.5,0),gt(5913894,.95),o.length),l=new mr(1,1);{let u=l.attributes.position;for(let f=0;f<u.count;f++){jt.fromBufferAttribute(u,f);let d=.82+.3*Ni(jt.x*2.3+5,jt.y*2.3+jt.z*1.7,0,9);u.setXYZ(f,jt.x*d,jt.y*d,jt.z*d)}l.computeVertexNormals()}let h=wn(l,gt(16777215,.9),o.length*3);o.forEach(([u,f],d)=>{let p=Ut(.8,1.4),x=En(u,f),g=5*p;An(c,d,u,x,f,0,0,0,p,g,p);for(let m=0;m<3;m++){let E=2.6*p*Ut(.8,1.1);An(h,d*3+m,u+Ut(-1.2,1.2)*p,x+g+E*.5+m*1.1*p,f+Ut(-1.2,1.2)*p,Yt()*3,Yt()*3,0,E,E*Ut(.8,1),E),h.setColorAt(d*3+m,i.setHSL(Ut(.22,.32),Ut(.45,.65),Ut(.18,.3)))}})}else if(yt.trees==="pine"){let o=t(e*1.2|0,Lt/2+9,520),c=wn(new Vt(.25,.4,1,6).translate(0,.5,0),gt(4862498,.95),o.length),l=new je(1,1,10,3).translate(0,.5,0);{let u=l.attributes.position,f=new Float32Array(u.count*3);for(let d=0;d<u.count;d++){let p=u.getY(d)>.45;f[d*3]=p?1:.3,f[d*3+1]=p?1:.42,f[d*3+2]=p?1.05:.3}l.setAttribute("color",new me(f,3))}let h=wn(l,gt(16777215,.85,0,{vertexColors:!0}),o.length*3);o.forEach(([u,f],d)=>{let p=Ut(.8,1.6),x=En(u,f);An(c,d,u,x,f,0,0,0,p,3*p,p);for(let g=0;g<3;g++){let m=(3.4-g*.9)*p;An(h,d*3+g,u,x+(2.2+g*2.6)*p,f,0,Yt()*3,0,m,4.2*p,m),h.setColorAt(d*3+g,i.setHSL(.36,.25,Ut(.62,.8)))}})}else{let o=t(e*.7|0,Lt/2+8,480),c=wn(new Vt(.28,.34,1.6,8).translate(0,.8,0),gt(9071176,.9),o.length*7),l=new cn(1,1,1,8);{let f=l.attributes.position;for(let d=0;d<f.count;d++){let p=f.getX(d),x=f.getY(d)+.5;f.setXYZ(d,p*(1-x*.8)*1.2,-x*x*1.6,x*4.8)}l.computeVertexNormals()}let h=wn(l,gt(4164142,.8,0,{side:Oe}),o.length*8),u=wn(new de(.28,8,6),gt(5913114,.7),o.length*3);o.forEach(([f,d],p)=>{let x=Ut(.05,.22),g=Yt()*6.28,m=f,E=En(f,d),y=d;for(let S=0;S<7;S++){let P=x*(S+1)*.35;An(c,p*7+S,m,E,y,Math.cos(g)*P,0,-Math.sin(g)*P,1-S*.05),m+=Math.sin(g)*Math.sin(P)*1.5,y+=Math.cos(g)*Math.sin(P)*1.5,E+=Math.cos(P)*1.5*(1-S*.05)}for(let S=0;S<8;S++)An(h,p*8+S,m,E,y,0,S/8*6.28+Yt()*.3,0,1.2,1,1.2),h.setColorAt(p*8+S,i.setHSL(Ut(.24,.3),.55,Ut(.25,.35)));for(let S=0;S<3;S++)An(u,p*3+S,m+Math.cos(S*2)*.4,E-.3,y+Math.sin(S*2)*.4,0,0,0,1)})}if(ai){let o=di("pedra:stone_mid"),c=di("pedra:stone_lit"),l=di("pedra:stone_big");Sr(t(n?40:90,Lt/2+6,420).map(([u,f,d],p)=>{let x=p%9===0&&d>Lt/2+30?$n(l):p%2?$n(o):$n(c);return[x,u,En(u,f)-.1,f,Yt()*6.28,ni*(x.includes("lit")?Ut(1.5,3):x.includes("big")?Ut(.5,.8):Ut(.8,1.5))]}));let h=[];for(let u=0;u<(n?40:90);u++){let f=Yt()*Ee,d=Yt()<.5?-1:1,p=He(f,d*(Lt/2+3+Yt()*6));h.push([$n(c),p.x,En(p.x,p.z),p.z,Yt()*6.28,ni*Ut(1,1.8)])}Sr(h,!1)}let s=ai?[]:t(n?40:90,Lt/2+6,420),r=new mr(1,1);{let o=r.attributes.position;for(let c=0;c<o.count;c++){jt.fromBufferAttribute(o,c);let l=.7+.5*Ni(jt.x*2+3,jt.y*2+jt.z*2,0,4);o.setXYZ(c,jt.x*l,jt.y*l*.7,jt.z*l)}r.computeVertexNormals()}let a=wn(r,gt(yt.id==="neve"?8160660:9274745,.95,0,{flatShading:!0}),s.length);if(s.forEach(([o,c],l)=>{let h=Ut(.6,2.4);An(a,l,o,En(o,c)+h*.2,c,Yt(),Yt()*6,0,h,h,h)}),yt.id!=="neve"){let o=n?700:yt.id==="praia"?900:k.qual===1?1800:3200,c=new Ie,l=[];for(let f=0;f<5;f++){let d=f/5*Math.PI,p=Math.cos(d)*.12,x=Math.sin(d)*.12,g=Ut(-.25,.25);l.push(-p,0,-x,p,0,x,g*1.4,.7+Yt()*.4,g)}c.setAttribute("position",new fe(l,3)),c.computeVertexNormals();let h=wn(c,gt(16777215,.9,0,{side:Oe}),o,!1),u=0;for(let f=0;f<o*3&&u<o;f++){let d=Yt()*Ee,p=Yt()<.5?-1:1,x=p*(Lt/2+3+Yt()*Yt()*40),g=He(d,x);Rr.some(m=>Math.hypot(g.x-m[0],g.z-m[1])<m[2])||yt.sea!==void 0&&g.z<yt.sea||(An(h,u,g.x,En(g.x,g.z),g.z,0,Yt()*6,0,Ut(.7,1.6)),h.setColorAt(u++,yt.id==="praia"?i.setHSL(.2,.35,Ut(.35,.5)):i.setHSL(Ut(.2,.3),Ut(.4,.6),Ut(.2,.34))))}h.count=u}}function Zv(){if(ai&&yt.id==="neve"){let n=di("montanha:mountain_winter"),t=di("montanha:plateau_winter"),e=[];for(let i=0;i<22;i++){let s=i/22*Math.PI*2+Ut(-.08,.08),r=Ut(520,640),a=Math.cos(s)*r,o=Math.sin(s)*r;e.push([i%4===3?$n(t):$n(n),a,-6,o,Math.atan2(-a,-o)+Ut(-.4,.4),Ut(6,8.5)])}Sr(e,!1);return}for(let n=0;n<26;n++){let t=n/26*Math.PI*2+Ut(-.1,.1),e=Ut(700,880),i=Math.cos(t)*e,s=Math.sin(t)*e;if(yt.sea!==void 0&&s<-250)continue;let r=Ut(110,260)*(yt.id==="neve"?1.35:1),a=Ut(140,240),o=new je(a,r,18,6,!0),c=o.attributes.position,l=new Float32Array(c.count*3),h=new Ft(yt.mtn[n%2]),u=new Ft(15922682),f=new Ft;for(let d=0;d<c.count;d++){jt.fromBufferAttribute(c,d);let p=(jt.y+r/2)/r,x=Li(jt.x*.02+n*7,jt.z*.02+jt.y*.02,4),g=1+(x-.5)*.5*(1-p*.5);c.setXYZ(d,jt.x*g,jt.y+(x-.5)*r*.12,jt.z*g),f.copy(h).lerp(u,Ot(.62-x*.2,.75-x*.2,p)*(yt.id==="praia"?0:1)),l[d*3]=f.r,l[d*3+1]=f.g,l[d*3+2]=f.b}o.setAttribute("color",new me(l,3)),o.computeVertexNormals(),At(o,gt(16777215,.95,0,{vertexColors:!0,flatShading:!0}),!1,!1).position.set(i,r/2-4,s)}}function Jv(){let n=new ti(Ge(256,128,e=>{for(let i=0;i<26;i++){let s=40+Yt()*176,r=50+Yt()*40,a=18+Yt()*30,o=e.createRadialGradient(s,r,0,s,r,a);o.addColorStop(0,"rgba(255,255,255,.9)"),o.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=o,e.fillRect(0,0,256,128)}}));n.colorSpace=be;let t=yt.id==="praia"?16763040:16777215;for(let e=0;e<18;e++){let i=new xs(new ji({map:n,color:t,fog:!1,depthWrite:!1,transparent:!0,opacity:Ut(.6,.95)})),s=Yt()*6.28,r=Ut(450,900);i.position.set(Math.cos(s)*r,Ut(160,300),Math.sin(s)*r),i.scale.set(Ut(220,380),Ut(90,140),1),Le.add(i),qh.push(i)}}function Kv(){let n=k.qual===0?700:1600,t=new Float32Array(n*3);for(let i=0;i<n;i++)t[i*3]=Ut(-60,60),t[i*3+1]=Ut(0,40),t[i*3+2]=Ut(-60,60);let e=new Ie;e.setAttribute("position",new me(t,3)),Ui=new la(e,new ca({size:.22,map:Hh,transparent:!0,depthWrite:!1,color:16777215})),Ui.frustumCulled=!1,rn.add(Ui)}function jv(n){let t=new vt,e=new bt(new Vt(.14,.14,.9,12),n);e.rotation.z=Math.PI/2,t.add(e);for(let i of[-.45,.45])for(let s of[-.13,.13]){let r=new bt(new de(.2,12,10),n);r.position.set(i,s,0),t.add(r)}return t.traverse(i=>{i.isMesh&&(i.castShadow=!0)}),t}function Qv(){ts=[],Eh=[],uc=[],fc=[],Ar=[],Aa=[];let n=[["pad",.06,-3],["hurdle",.13],["coins",.19,-4],["puddle",.26,4],["nitro",.32],["ramp",.4],["coins",.46,3],["hurdle",.52],["puddle",.59,-3.5],["pad",.65,3],["nitro",.71],["coins",.77,0],["hurdle",.83],["puddle",.89,2.5],["nitro",.95],["ammo",.23],["ammo",.62],["ammo",.925]];Ea=an(Ge(64,64,h=>{h.fillStyle="#062a3a",h.fillRect(0,0,64,64),h.strokeStyle="#35d0ff",h.lineWidth=9;for(let u of[10,42])h.beginPath(),h.moveTo(8,u+18),h.lineTo(32,u),h.lineTo(56,u+18),h.stroke()}),1,2);let t=an(Ge(64,4,h=>{for(let u=0;u<8;u++)h.fillStyle=u%2?"#ffffff":"#e53935",h.fillRect(u*8,0,8,4)}),3,1),e={mud:gt(3876372,.15,0),water:gt(3833768,.05,.1,{transparent:!0,opacity:.85}),ice:gt(13496063,.03,.2)}[yt.puddle],i=gt(2060287,.25,.7),s=gt(3526911,.2,0,{emissive:3526911,emissiveIntensity:1.2}),r=new Tn({color:3526911,transparent:!0,opacity:.45,blending:Zi,depthWrite:!1,side:Oe}),a=gt(16762173,.28,.55,{emissive:4861952});Ca=[];let o=an(Ge(64,64,h=>{h.fillStyle="#3f4a2c",h.fillRect(0,0,64,64),h.strokeStyle="#2a3120",h.lineWidth=4,h.strokeRect(2,2,60,60),h.beginPath(),h.moveTo(2,2),h.lineTo(62,62),h.moveTo(62,2),h.lineTo(2,62),h.stroke(),h.fillStyle="#ffcc00",h.fillRect(16,26,32,12),h.fillStyle="#111",h.font="bold 10px Arial",h.textAlign="center",h.fillText("M\xCDSSIL",32,35)})),c=gt(16777215,.7,.1,{map:o}),l=gt(16777215,.3,0,{map:Ea,emissive:16777215,emissiveMap:Ea,emissiveIntensity:1.4});for(let[h,u,f=0]of n){let d=Ee*u;if(h==="hurdle"){let p=new vt,x=new vt;At(new xe(Lt+1,.2,.2),gt(16777215,.4,0,{map:t}),!0,!0,x),x.position.y=.95,p.add(x);for(let g of[-1,1])At(new xe(.22,1.4,.22),gt(15790320,.4,.3),!0,!0,p).position.set(g*(Lt/2+.6),.7,0),At(new xe(.3,.12,1.4),gt(3355443,.5,.5),!0,!0,p).position.set(g*(Lt/2+.6),.06,0);p.position.copy(He(d,0)),p.rotation.y=ri(d),Le.add(p),ts.push({s:d,bar:x,fall:0})}else if(h==="ramp"){let p=new Qi;p.moveTo(-3,0),p.lineTo(3,0),p.lineTo(3,1.1),p.lineTo(-3,0);let x=new vs(p,{depth:Lt,bevelEnabled:!1});x.translate(0,0,-Lt/2),x.rotateY(-Math.PI/2);let g=an(Ge(64,64,E=>{E.fillStyle="#ffb300",E.fillRect(0,0,64,64),E.fillStyle="#1a1a1a";for(let y=-64;y<128;y+=22)E.beginPath(),E.moveTo(y,0),E.lineTo(y+11,0),E.lineTo(y+75,64),E.lineTo(y+64,64),E.fill()}),.25,.25),m=At(x,gt(16777215,.6,.2,{map:g}));m.position.copy(He(d,0,.02)),m.rotation.y=ri(d),Eh.push({s:d+3})}else if(h==="pad"){let p=At(new cn(4.2,7),l,!1,!0);p.rotation.x=-Math.PI/2;let x=new vt;x.add(p),x.position.copy(He(d,f,.07)),x.rotation.y=ri(d),Le.add(x),uc.push({s:d,d:f})}else if(h==="puddle"){let x=At(new ys(3.3,32),e,!1,!0);x.rotation.x=-Math.PI/2;let g=new vt;g.add(x),g.scale.set(.8,1,1.4),g.position.copy(He(d,f,.06)),g.rotation.y=ri(d),Le.add(g),fc.push({s:d,d:f,r:3.3,type:yt.puddle})}else if(h==="nitro")for(let p of[-5,0,5]){let x=new vt;At(new Vt(.42,.42,1.2,20),i,!0,!0,x),At(new Vt(.44,.44,.3,20),s,!1,!1,x),At(new Vt(.15,.2,.25,12),cc,!1,!1,x).position.y=.72;let g=At(new ma(.8,1.1,32),r,!1,!1,x);g.rotation.x=-Math.PI/2,g.position.y=-1.15,x.position.copy(He(d,p,1.3)),Le.add(x),Ar.push({s:d,d:p,g:x,cd:0})}else if(h==="ammo")for(let p of[-5,0,5]){let x=new vt;At(new xe(1.1,.8,1.1),c,!0,!0,x);let g=rp();g.visible=!0,g.scale.setScalar(.55),g.position.y=.7,g.rotation.x=-Math.PI/2,x.add(g);let m=At(new ma(.9,1.2,32),new Tn({color:16734778,transparent:!0,opacity:.45,blending:Zi,depthWrite:!1,side:Oe}),!1,!1,x);m.rotation.x=-Math.PI/2,m.position.y=-1,x.position.copy(He(d,p,1.1)),Le.add(x),Ca.push({s:d,d:p,g:x,cd:0})}else if(h==="coins")for(let p=0;p<6;p++){let x=jv(a);x.scale.setScalar(1.1);let g=d+p*4;x.position.copy(He(g,f,1.1)),Le.add(x),Aa.push({s:g,d:f,g:x,taken:!1})}}}var Pr=[];function tM(){Pr=[],[[.36,1,0],[.555,-1,3.2]].forEach(([n,t,e])=>{let i=Ee*n,s=new vt,r=new vt,a=new vt;s.position.copy(He(i,0)),s.rotation.y=ri(i),s.add(r),r.add(a),Le.add(s);let o=1.3,c="";if(yt.id==="parque"){o=1.2,c="ATROPELADO PELO FENO!";let f=an(Ge(64,64,p=>{p.fillStyle="#d9b44a",p.fillRect(0,0,64,64);for(let x=0;x<220;x++){p.strokeStyle=Math.random()<.5?"#b8912f":"#f0d27a",p.beginPath();let g=Math.random()*64,m=Math.random()*64;p.moveTo(g,m),p.lineTo(g+Math.random()*10-5,m+Math.random()*3),p.stroke()}})),d=At(new Vt(o,o,2.2,24),gt(16777215,.95,0,{map:f}),!0,!0,a);d.rotation.x=Math.PI/2;for(let p of[-.5,.5]){let x=At(new xr(o+.01,.05,6,32),gt(8014622,.8),!1,!1,a);x.position.z=p}}else if(yt.id==="praia"){o=1.35,c="BOLADA DE PRAIA!";let f=an(Ge(128,64,d=>{["#e53935","#ffffff","#1e88e5","#ffffff","#fdd835","#ffffff"].forEach((x,g)=>{d.fillStyle=x,d.fillRect(g*128/6,0,128/6+1,64)})}));At(new de(o,28,18),gt(16777215,.35,0,{map:f}),!0,!0,a)}else{o=1.5,c="ATROPELADO PELA BOLA DE NEVE!";let f=new mr(o,3),d=f.attributes.position;for(let p=0;p<d.count;p++){jt.fromBufferAttribute(d,p);let x=.92+.12*Ni(jt.x*2+4,jt.y*2+jt.z*2,0,7);d.setXYZ(p,jt.x*x,jt.y*x,jt.z*x)}f.computeVertexNormals(),At(f,gt(16054527,.6),!0,!0,a)}let l=new vt,h=an(Ge(64,64,f=>{f.fillStyle="#ffcc00",f.beginPath(),f.moveTo(32,3),f.lineTo(61,32),f.lineTo(32,61),f.lineTo(3,32),f.fill(),f.fillStyle="#111",f.beginPath(),f.arc(32,36,11,0,7),f.fill(),f.fillRect(12,46,40,4)}));At(new xe(1.6,1.6,.08),[gt(3355443),gt(3355443),gt(3355443),gt(3355443),gt(16777215,.5,0,{map:h}),gt(3355443)],!0,!0,l).position.y=2.6,At(new Vt(.06,.06,2,6),gt(7829367,.5,.6),!0,!0,l).position.y=1;let u=He(i-25,-(Lt/2+3.4));l.position.set(u.x,0,u.z),l.rotation.y=ri(i)+Math.PI,Le.add(l),Pr.push({s:i,dir:t,off:e,r:o,roller:r,active:!1,d:0,hitMsg:c,period:7.5})})}function Kh(n){for(let t of Pr){let e=((n+t.off)%t.period+t.period)%t.period,i=3.6,s=Lt/2+6,r=Math.min(1,e/i);t.d=t.dir*Fe(-s,s,r),t.active=e<i&&Math.abs(t.d)<Lt/2+1,t.roller.visible=e<i+.4,t.roller.position.set(-t.d,t.r,0),t.roller.rotation.z=t.d/t.r}}var eM={parque:{name:"POMBO",plural:"POMBOS",body:9213349,wing:10397622,tip:3817288,head:5205859,beak:3355443,pitch:1},praia:{name:"GAIVOTA",plural:"GAIVOTAS",body:16185074,wing:12173770,tip:1710618,head:16777215,beak:15907118,pitch:1.4},neve:{name:"CORVO",plural:"CORVOS",body:1382172,wing:1842982,tip:789776,head:1382172,beak:2105376,pitch:.7}},Pi=()=>eM[yt.id],Ps=[],Sa=8;function nM(n){let t=new vt,e=a=>gt(a,.6,.05),i=(a,o,c,l,h,u=t)=>{let f=new bt(a,o);return f.position.set(c,l,h),f.castShadow=!0,u.add(f),f};i(Di(.2,.19,.38),e(n.body),0,0,0),i(new de(.14,14,10),e(n.head),0,.14,.33);let s=i(new je(.045,.14,8),e(n.beak),0,.12,.5);s.rotation.x=Math.PI/2;for(let a of[-1,1])i(new de(.03,8,6),gt(657930,.1),a*.09,.18,.42);i(Di(.14,.025,.24),e(n.tip),0,.02,-.44);let r=[];for(let a of[-1,1]){let o=new vt;o.position.set(a*.14,.08,.04),t.add(o),i(Di(.42,.02,.2),e(n.wing),a*.4,0,0,o),i(Di(.18,.018,.12),e(n.tip),a*.78,0,-.05,o),r.push({piv:o,sx:a})}for(let a of[-1,1]){let o=i(new Vt(.012,.012,.16,5),gt(13662784,.6),a*.06,-.2,-.05);o.rotation.x=.8}return t.scale.setScalar(1.7),{g:t,wings:r}}function iM(){Ps=[],Sa=7;for(let n=0;n<4;n++){let t=nM(Pi());t.g.visible=!1,Le.add(t.g),Ps.push({...t,state:"off",pos:new L,vel:new L,t:0,target:null,phase:Math.random()*6})}}function ya(n,t){n.state="flee",n.t=0;let e=n.pos.x-t.x,i=n.pos.z-t.z,s=Math.hypot(e,i)||1;n.vel.set(e/s*22,14,i/s*22),n.target&&(n.target.birdT=0),Ct.squawk(Pi().pitch,at?ce(1-Math.hypot(n.pos.x-at.x,n.pos.z-at.z)/60,0,1):1);for(let r=0;r<8;r++)oi.spawn(n.pos.x,n.pos.y,n.pos.z,(Math.random()-.5)*6,Math.random()*3,(Math.random()-.5)*6,1.2,.25,.15,[.95,.95,.95],.9,3,1.5)}var Ss=new L;function jd(n,t){if(t&&Nn>5){Sa-=n;let e=Ps.filter(i=>i.state==="approach"||i.state==="harass").length;if(Sa<=0&&e<1+k.diff){Sa=6+Math.random()*5-k.diff;let i=Ps.find(r=>r.state==="off"),s=pe.filter(r=>!r.finished&&r.birdT<=0&&!ie(r,"major"));if(i&&s.length){let r=s.includes(at)&&Math.random()<.5?at:s[Math.random()*s.length|0],a=Ds(r.dist+55+Math.random()*20),o=(Math.random()-.5)*30;i.pos.set(a.p.x+a.r.x*o,16+Math.random()*6,a.p.z+a.r.z*o),i.vel.set(0,0,0),i.state="approach",i.t=0,i.target=r,i.g.visible=!0,r.isPlayer&&he(`CUIDADO: ${Pi().name}!`,"o")}}}for(let e of Ps){if(e.state==="off")continue;e.t+=n,e.phase+=n*(e.state==="harass"?22:15);let i=e.target;if(e.state==="approach"||e.state==="harass")if(!i||i.finished||!t)ya(e,e.pos);else{i.D.head.getWorldPosition(Ss);let r=Math.sin(i.h),a=Math.cos(i.h);if(e.state==="approach"){jt.set(Ss.x+r*1.2-e.pos.x,Ss.y+.8-e.pos.y,Ss.z+a*1.2-e.pos.z);let o=jt.length(),c=Math.hypot(i.vx,i.vz)+16;e.vel.lerp(jt.multiplyScalar(c/Math.max(o,.01)),1-Math.exp(-3*n)),e.pos.addScaledVector(e.vel,n),o<2.4&&(e.state="harass",e.t=0,i.isPlayer?(he(`${Pi().name} NA CARA! LATE!`,"r"),Ct.squawk(Pi().pitch,1),On([20,30,20,30,20])):ii(`${Pi().name} ATACANDO ${i.b.name}!`)),e.t>12&&ya(e,e.pos)}else{let o=e.t*5;if(jt.set(Ss.x+r*1.3+Math.cos(o)*.9,Ss.y+.55+Math.sin(e.t*9)*.25,Ss.z+a*1.3+Math.sin(o)*.9),e.vel.copy(jt).sub(e.pos).divideScalar(Math.max(n,.001)).clampLength(0,80),e.pos.lerp(jt,1-Math.exp(-10*n)),i.flyY>1.5){ya(e,i);continue}i.birdT=.25,Math.random()<n*1.5&&Ct.squawk(Pi().pitch,i.isPlayer?.6:.2),e.t>6&&ya(e,e.pos)}}else e.state==="flee"&&(e.vel.y+=n*4,e.pos.addScaledVector(e.vel,n),e.t>4&&(e.state="off",e.g.visible=!1));e.g.position.copy(e.pos),e.vel.lengthSq()>1&&e.g.rotation.set(-ce(e.vel.y*.03,-.5,.5),Math.atan2(e.vel.x,e.vel.z),0);let s=Math.sin(e.phase)*(e.state==="flee"?.9:.7);for(let r of e.wings)r.piv.rotation.z=r.sx*s}}function Qd(){for(let n of Ps)n.state="off",n.g.visible=!1,n.target=null;Sa=7}function sM(){let n=1/0,t=-1/0,e=1/0,i=-1/0;for(let o of qe)n=Math.min(n,o.x),t=Math.max(t,o.x),e=Math.min(e,o.z),i=Math.max(i,o.z);let s=216/Math.max(t-n,i-e),r=128-(n+t)/2*s,a=128-(e+i)/2*s;Sh={f:(o,c)=>[o*s+r,c*s+a],canvas:Ge(256,256,o=>{o.lineJoin="round",o.beginPath();for(let c=0;c<=$e;c+=8){let l=qe[c%$e],h=l.x*s+r,u=l.z*s+a;c?o.lineTo(h,u):o.moveTo(h,u)}o.closePath(),o.lineWidth=16,o.strokeStyle="rgba(0,0,0,.55)",o.stroke(),o.lineWidth=9,o.strokeStyle="rgba(255,255,255,.9)",o.stroke(),o.fillStyle="#ff7a1a",o.fillRect(qe[0].x*s+r-6,qe[0].z*s+a-6,12,12)})}}var tp=[{name:"REDLINE AGOG",src:"musica/redline-agog.mp3"},{name:"APEX PURSUIT",src:"musica/apex-pursuit.mp3"}],jh=["TODAS","REDLINE AGOG","APEX PURSUIT","8-BIT","DESLIGADA"],Rn=new Audio;Rn.preload="none";Rn.volume=.6;var Th=Math.random()<.5?0:1,wh=!1;Rn.addEventListener("ended",()=>{k.musicMode===0&&(Th=(Th+1)%tp.length,bc(!0))});Rn.addEventListener("error",()=>{Rn.getAttribute("src")&&(wh=!0,bc())});function bc(n){let t=k.musicMode,e=t<=2&&!wh;if(Ct.ctx&&Ct.setMusic(t===3||t<=2&&wh),e){let i=tp[t===0?Th:t-1];Rn.getAttribute("src")!==i.src&&(Rn.src=i.src,n=!0),Rn.loop=t!==0;let s=Rn.play();s&&s.catch(()=>{}),n&&Ct.ctx&&he("\u266A "+i.name,"c")}else Rn.pause()}function ep(){k.musicMode=(k.musicMode+1)%jh.length,Qe(),bc(!0)}var Ct={ctx:null,master:null,music:null,sfx:null,nb:null,loops:{},timer:null,init(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}let n=window.AudioContext||window.webkitAudioContext;if(!n)return;let t=this.ctx=new n;this.master=t.createGain(),this.master.gain.value=.75;let e=t.createDynamicsCompressor();this.master.connect(e).connect(t.destination),this.music=t.createGain(),this.music.gain.value=0;let i=t.createBiquadFilter();i.type="lowpass",i.frequency.value=3200,this.music.connect(i).connect(this.master),this.sfx=t.createGain(),this.sfx.connect(this.master);let s=t.createBuffer(1,t.sampleRate*2,t.sampleRate),r=s.getChannelData(0);for(let a=0;a<r.length;a++)r[a]=Math.random()*2-1;this.nb=s,this.loops.wind=this.loopNoise("highpass",900,.5),this.loops.skid=this.loopNoise("bandpass",2400,2.5),this.loops.nitro=this.loopNoise("lowpass",500,1),this.loops.crowd=this.loopNoise("bandpass",750,.7),this.setLoop("crowd",.035),this.startMusic(),bc()},loopNoise(n,t,e){let i=this.ctx,s=i.createBufferSource();s.buffer=this.nb,s.loop=!0;let r=i.createBiquadFilter();r.type=n,r.frequency.value=t,r.Q.value=e;let a=i.createGain();return a.gain.value=0,s.connect(r).connect(a).connect(this.sfx),s.start(0,Math.random()),{g:a,f:r}},setLoop(n,t,e){let i=this.loops[n];i&&(i.g.gain.setTargetAtTime(t,this.ctx.currentTime,.06),e&&i.f.frequency.setTargetAtTime(e,this.ctx.currentTime,.1))},tone(n,t,e="square",i=.2,s=0,r=0,a=null){if(!this.ctx)return;let o=this.ctx,c=r||o.currentTime,l=o.createOscillator(),h=o.createGain();l.type=e,l.frequency.setValueAtTime(n,c),s&&l.frequency.exponentialRampToValueAtTime(s,c+t),h.gain.setValueAtTime(i,c),h.gain.exponentialRampToValueAtTime(.001,c+t),l.connect(h).connect(a||this.sfx),l.start(c),l.stop(c+t+.03)},noise(n,t,e,i=0,s=null,r="bandpass"){if(!this.ctx)return;let a=this.ctx,o=i||a.currentTime,c=a.createBufferSource();c.buffer=this.nb;let l=a.createBiquadFilter();l.type=r,l.frequency.value=e,l.Q.value=1.2;let h=a.createGain();h.gain.setValueAtTime(t,o),h.gain.exponentialRampToValueAtTime(.001,o+n),c.connect(l).connect(h).connect(s||this.sfx),c.start(o,Math.random()),c.stop(o+n+.03)},bark(n=1,t=1){if(!this.ctx||t<.02)return;let e=this.ctx.currentTime;for(let i=0;i<2;i++){let s=e+i*.19;this.tone(560*n,.13,"sawtooth",.2*t,230*n,s),this.tone(280*n,.13,"triangle",.18*t,140*n,s),this.noise(.1,.25*t,1300*n,s)}},voice(n,t=1){if(!this.ctx||t<.02)return;let e=this.ctx.currentTime,i=n.pitch||1;if(n.voice==="hiss")for(let s=0;s<2;s++)this.noise(.32,.32*t,3800*i,e+s*.36,null,"highpass"),this.noise(.3,.12*t,1600*i,e+s*.36);else if(n.voice==="grunt")for(let s=0;s<3;s++){let r=e+s*.17;this.tone(190*i,.12,"square",.12*t,110*i,r),this.tone(95*i,.12,"sawtooth",.12*t,70*i,r),this.noise(.1,.2*t,500,r,null,"lowpass")}else this.bark(i,t)},boom(n=1){!this.ctx||n<.02||(this.noise(.8,.6*n,120,0,null,"lowpass"),this.noise(.4,.4*n,900),this.tone(90,.6,"sine",.4*n,30))},launch(n=1){!this.ctx||n<.02||(this.noise(.5,.35*n,1400),this.tone(300,.35,"sawtooth",.08*n,900))},reload(){let n=this.ctx?this.ctx.currentTime:0;this.noise(.05,.3,3e3,n),this.noise(.06,.3,1800,n+.12),this.tone(700,.1,"square",.06,0,n+.12)},lockon(){this.tone(1760,.06,"square",.07)},howl(n=1){if(!this.ctx||n<.03)return;let t=this.ctx,e=t.currentTime,i=t.createOscillator(),s=t.createGain(),r=t.createOscillator(),a=t.createGain();i.type="sawtooth",i.frequency.setValueAtTime(260,e),i.frequency.linearRampToValueAtTime(520,e+.5),i.frequency.linearRampToValueAtTime(470,e+1.2),i.frequency.linearRampToValueAtTime(300,e+1.7),r.frequency.value=6,a.gain.value=12,r.connect(a).connect(i.frequency);let o=t.createBiquadFilter();o.type="lowpass",o.frequency.value=1400,s.gain.setValueAtTime(.001,e),s.gain.linearRampToValueAtTime(.22*n,e+.25),s.gain.setValueAtTime(.22*n,e+1.3),s.gain.exponentialRampToValueAtTime(.001,e+1.8),i.connect(o).connect(s).connect(this.sfx),i.start(e),r.start(e),i.stop(e+1.85),r.stop(e+1.85)},squawk(n=1,t=1){if(!this.ctx||t<.03)return;let e=this.ctx.currentTime;for(let i=0;i<2;i++)this.tone(1300*n,.09,"sawtooth",.09*t,800*n,e+i*.12),this.noise(.07,.12*t,2500*n,e+i*.12)},beep(n){this.tone(n?1320:660,n?.6:.25,"square",.14)},jump(){this.noise(.18,.14,700),this.tone(220,.16,"sine",.12,420)},land(){this.noise(.12,.25,180,0,null,"lowpass")},paw(n,t){this.noise(.05,.05+n*.05,t==="snow"?1500:t==="sand"?700:260,0,null,"lowpass")},pickup(){let n=this.ctx?this.ctx.currentTime:0;[523,784,1047].forEach((t,e)=>this.tone(t,.16,"triangle",.14,0,n+e*.05)),this.tone(300,.4,"sawtooth",.05,1200)},coin(){let n=this.ctx?this.ctx.currentTime:0;this.tone(1568,.08,"square",.07,0,n),this.tone(2093,.2,"square",.07,0,n+.06)},boost(){this.tone(180,.5,"sawtooth",.12,900),this.noise(.5,.22,1200)},splash(){this.noise(.35,.3,900)},trip(){this.tone(300,.45,"sawtooth",.14,70),this.noise(.25,.3,300)},thud(){this.noise(.14,.35,150,0,null,"lowpass")},lap(){let n=this.ctx?this.ctx.currentTime:0;[880,1175].forEach((t,e)=>this.tone(t,.18,"square",.1,0,n+e*.12))},fanfare(){if(!this.ctx)return;let n=this.ctx.currentTime;[[523,0],[659,.12],[784,.24],[1047,.36],[784,.56],[1047,.68]].forEach(([t,e])=>this.tone(t,.25,"square",.1,0,n+e)),this.cheer()},cheer(){if(!this.ctx)return;let n=this.loops.crowd.g.gain,t=this.ctx.currentTime;n.cancelScheduledValues(t),n.setValueAtTime(.22,t),n.linearRampToValueAtTime(.035,t+4)},setMusic(n){this.music&&this.music.gain.setTargetAtTime(n?.22:0,this.ctx.currentTime,.1)},startMusic(){if(this.timer||!this.ctx)return;let n=a=>440*Math.pow(2,(a-69)/12),t=[[45,[0,3,7]],[41,[0,4,7]],[48,[0,4,7]],[43,[0,4,7]]],e=[76,0,76,79,0,76,74,72,72,0,72,76,0,72,71,69,72,0,72,76,0,79,77,76,74,0,74,79,0,78,79,0],i=60/124/4,s=0,r=this.ctx.currentTime+.1;this.timer=setInterval(()=>{if(!(!this.ctx||this.ctx.state!=="running"))for(;r<this.ctx.currentTime+.15;){let a=(s>>4)%4,o=s%16,[c,l]=t[a],h=this.music;o%2===0&&this.tone(n(c-12+(o%4===2?12:0)),i*1.8,"sawtooth",.22,0,r,h),this.tone(n(c+24+l[o%3]+(o%6>2?12:0)),i*.9,"square",.035,0,r,h);let u=e[(s>>1)%32];s%2===0&&u&&(s>>6)%2&&this.tone(n(u),i*1.8,"triangle",.09,0,r,h),o%4===0&&this.tone(150,.16,"sine",.5,40,r,h),(o===4||o===12)&&this.noise(.14,.3,1800,r,h),o%2===1&&this.noise(.03,.08,8e3,r,h,"highpass"),r+=i,s++}},25)}},es=[{n:"F\xC1CIL",k:.93,miss:.25,upOff:-1,reward:.8},{n:"NORMAL",k:.98,miss:.12,upOff:0,reward:1},{n:"DIF\xCDCIL",k:1.03,miss:.05,upOff:1,reward:1.3}],rM=[{id:"motor",name:"MOTOR",desc:"Mais velocidade m\xE1xima"},{id:"acel",name:"M\xDASCULOS",desc:"Arranca e acelera mais r\xE1pido"},{id:"grip",name:"GARRAS",desc:"Mais ader\xEAncia nas curvas e no drift"},{id:"nitro",name:"TANQUE DE NITRO",desc:"Nitro dura mais e empurra mais forte"},{id:"pulo",name:"MOLAS",desc:"Pula mais alto e mais longe"}],np=[150,280,450,700,1e3],aM=2.6,oM=30,cM=1;function Tc(n){return k.up[n.id]||(k.up[n.id]={motor:0,acel:0,grip:0,nitro:0,pulo:0})}var lM={rex:["GUARDI\xC3O","Latido alcan\xE7a mais longe e recarrega mais r\xE1pido"],pingo:["BOMBEIRO","Lama, \xE1gua e gelo n\xE3o atrapalham"],caramelo:["SORTUDO","Ossos de ouro valem o dobro e latas de nitro \xE0s vezes d\xE3o um m\xEDssil"],flecha:["ARRANCADA","No v\xE1cuo de um rival fica muito mais r\xE1pido e enche o nitro"],nevasca:["PATA DE NEVE","Nunca escorrega na neve nem no gelo"],bolinha:["CABE\xC7A DURA","Fica tonto s\xF3 pela metade do tempo"],pitiquin:["PEQUENO E BRAVO","Latir d\xE1 um mini-turbo"],princesa:["REALEZA","Trombadas n\xE3o a atrasam, e quem bate nela \xE9 empurrado"],linda:["INVESTIDA","Com nitro ligado, derruba quem ela atropelar"],faiton:["UIVO DA LUA","Quando algu\xE9m o ultrapassa, uiva e corre mais r\xE1pido"],paz:["VOO DA PAZ","Com o nitro, voa alto: passa por cima da cerca, dos rivais e dos m\xEDsseis"],pintado:["MATILHA","Fica mais r\xE1pido quanto mais rivais estiverem por perto"],ruivo:["SELVAGEM","Correr fora da pista n\xE3o deixa lento"],ninja:["PULO DUPLO","Aperte pular de novo no ar para dar um segundo pulo"],sombra:["ESQUIVA","Metade dos m\xEDsseis erram ele"],pacoca:["COMIL\xC3O","Latas de nitro enchem muito mais"],raio:["REL\xC2MPAGO","Nitro mais forte que o de todo mundo"],duque:["ARTILHEIRO","Come\xE7a com 3 m\xEDsseis e carrega at\xE9 4"],frufru:["ELEG\xC2NCIA","Drift enche o nitro em dobro e o mini-turbo dura mais"],major:["DISCIPLINA","Os bichos voadores n\xE3o se atrevem a atac\xE1-lo"],tofu:["ROLINHO","Trope\xE7ar ou ser atropelado quase n\xE3o o atrasa"],bidu:["TANQUE","Bolas rolando n\xE3o o derrubam"],canela:["F\xD4LEGO","O nitro enche sozinho aos poucos"],biscoito:["FARO","Pega ossos, latas e muni\xE7\xE3o de mais longe"],emilly:["FINGIR DE MORTA","Depois de ficar tonta, levanta com um mini-turbo"],taissa:["GRUDENTA","N\xE3o escorrega em po\xE7as nem no gelo e faz curvas mais fechadas"],tiffany:["RABO-CHICOTE","O chiado dela derruba quem estiver perto"]},ie=(n,t)=>n.b.id===t;function hM(n,t){return{maxV:30+n.spd*1.8+t.motor*1.4,accel:9+n.acc*2.4+t.acel*1.9,grip:5.5+n.han*.8+t.grip*.7,turn:1.5+n.han*.06+t.grip*.05+(n.id==="taissa"?.15:0),jumpV:9.6+n.jmp*.75+t.pulo*.5,nitroDrain:30*(1-t.nitro*.09),nitroPow:1.3+t.nitro*.03+(n.id==="raio"?.2:0)}}var uM={throttle:0,brake:!1,steer:0,drift:!1,nitro:!1,jump:!1,bark:!1,fire:!1},Ah=class{constructor(t,e,i,s){this.b=t,this.num=e,this.isPlayer=i,this.D=qd(t,e,t.color),rn.add(this.D.root),this.look=i?vc(t):$d(),Mc(this.D,this.look),Object.assign(this,hM(t,s)),this.skill=i?1:es[k.diff].k*(.98+Math.random()*.04),this.x=0,this.z=0,this.h=0,this.vx=0,this.vz=0,this.y=0,this.vy=0,this.yawRate=0,this.s=0,this.idx=0,this.dist=0,this.d=0,this.speed=0,this.slide=0,this.nitro=30,this.nitroOn=!1,this.drifting=!1,this.driftDir=0,this.driftT=0,this.mini=0,this.pad=0,this.stun=0,this.spook=0,this.barkCD=2,this.slip=0,this.surf=null,this.phase=Math.random()*6,this.lastStep=0,this.finished=!1,this.finishTime=0,this.lastLap=1,this.prevJump=!1,this.prevBark=!1,this.air=!1,this.rampAir=!1,this.howl=0,this.prevAhead=0,this.flyY=0,this.dj=!1,this.pack=1,this.ammo=t.id==="duque"?3:1,this.fireCD=0,this.prevFire=!1,this.missHits=0,this.flip=0,this.lockT=0,this.lane=(Math.random()-.5)*8,this.laneT=1+Math.random()*3,this.aiNitro=!1,this.jumpPlan=new Map,this.minis=0,this.scared=0,this.cleanJumps=0,this.cans=0,this.hits=0,this.birdT=0,this.hitCD=0,this.driftScore=0,this.coins=0,this.lapStart=0,this.bestLap=0,this.pressT=null,this.wrongT=0}get lap(){return ce(Math.floor(this.dist/Ee)+1,1,k.laps)}place(t,e){this.dist=t,this.s=Ec(t),this.idx=Math.round(this.s/Ee*$e)%$e;let i=He(t,e);this.x=i.x,this.z=i.z,this.d=e,this.h=ri(t)}dispose(){rn.remove(this.D.root),Cr(this.D.root)}},pe=[],at=null,Ye=null,mn=null;function fM(n){let t=n.idx,e=1/0;for(let l=-40;l<=40;l++){let h=(n.idx+l+$e)%$e,u=n.x-qe[h].x,f=n.z-qe[h].z,d=u*u+f*f;d<e&&(e=d,t=h)}n.idx=t;let i=qe[t],s=si[t],r=Ls[t],a=n.x-i.x,o=n.z-i.z,c=Ec(t*Ee/$e+a*s.x+o*s.z);n.d=a*r.x+o*r.z,n.dist+=pn(c-n.s),n.s=c}function Ts(n,t){if(!n.drifting||(n.drifting=!1,t))return;let e=n.driftT>2?2:n.driftT>.9?1:0,i=Math.round(n.driftT*140);n.driftScore+=i,e&&(n.minis++,n.isPlayer&&On(e===2?[25,30,25]:25),n.mini=(e===2?1.5:.8)*(ie(n,"frufru")?1.5:1),n.nitro=Math.min(100,n.nitro+e*8),n.isPlayer&&(he(e===2?"SUPER MINI-TURBO!":"MINI-TURBO!",e===2?"o":"c"),Ct.boost())),n.isPlayer&&i>60&&he(`DRIFT +${i}`,"g")}var dM=n=>n.voice==="hiss"?"CHIADO!":n.voice==="grunt"?"RONCO!":"LATIDO!",pM=n=>n.voice==="hiss"?"SSSSSS!":n.voice==="grunt"?"OINC OINC!":"AU AU!";function mM(n){n.barkCD=ie(n,"rex")?4:6,ie(n,"pitiquin")&&(n.mini=Math.max(n.mini,1),n.isPlayer&&he("MINI-TURBO DO PITIQUIN!","c"));let t=Math.sin(n.h),e=Math.cos(n.h);Ct.voice(n.b,at?ce(1-Math.hypot(n.x-at.x,n.z-at.z)/60,0,1):1);let i=0;for(let a of pe){if(a===n||a.stun>0)continue;let o=a.x-n.x,c=a.z-n.z,l=Math.hypot(o,c);l<(ie(n,"rex")?18:12)&&o*t+c*e>-2&&a.flyY<1.5&&(a.spook=1.1,i++,a.isPlayer&&he("ASSUSTADO!","r"),ie(n,"tiffany")&&l<9&&(a.stun=Math.max(a.stun,.7),a.vx*=.5,a.vz*=.5,a.isPlayer&&he("CHICOTADA DA TIFFANY!","r")))}let s=0;for(let a of Ps)a.state!=="approach"&&a.state!=="harass"||Math.hypot(a.pos.x-n.x,a.pos.z-n.z)<15&&(ya(a,n),s++);s&&(n.scared+=s,n.nitro=Math.min(100,n.nitro+10*s),n.isPlayer&&he(`ESPANTOU ${s>1?s+" "+Pi().plural:"O "+Pi().name}! +NITRO`,"v"));let r=n.D.head.getWorldPosition(jt);for(let a=0;a<26;a++){let o=a/26*6.28;bn.spawn(r.x,r.y,r.z,Math.cos(o)*14,.5,Math.sin(o)*14,.45,.5,1.4,[1,.85,.4],.8,0,3)}n.isPlayer&&!s&&he(i?`${dM(n.b)} ${i} ASSUSTADO${i>1?"S":""}`:pM(n.b),"g")}function Rh(n,t,e){let i=n.dist,s=n.y>.02;n.stun>0&&(n.stun-=e*(ie(n,"bolinha")?2:1),t=uM,n.stun<=0&&ie(n,"emilly")&&(n.mini=1.3,n.isPlayer&&he("FINGIU DE MORTA! MINI-TURBO","v"))),n.spook>0&&(n.spook-=e,t={...t,nitro:!1,steer:ce(t.steer+Math.sin(Un*16+n.num)*.7,-1,1)});let r=t.jump&&!n.prevJump;n.prevJump=t.jump;let a=t.bark&&!n.prevBark;n.prevBark=t.bark,n.barkCD-=e,a&&n.barkCD<=0&&mM(n);let o=t.fire&&!n.prevFire;n.prevFire=t.fire,n.fireCD-=e,n.flip=Math.max(0,n.flip-e),o&&_M(n);let c=Math.abs(n.d)>Lt/2+.4&&!ie(n,"ruivo")&&n.flyY<1.5,l=ie(n,"nevasca")||ie(n,"taissa")?Math.max(1,yt.grip):yt.grip,h=n.grip*l*(c?.8:1),u=c?.62:1;ie(n,"pingo")||ie(n,"taissa")&&n.surf==="ice"||ie(n,"nevasca")&&n.surf==="ice"||(!s&&n.surf==="mud"?(h*=.5,u*=.62):!s&&n.surf==="water"?(h*=.8,u*=.72):!s&&n.surf==="ice"&&(h*=.22)),n.hitCD=Math.max(0,n.hitCD-e),n.birdT>0&&(n.birdT-=e,t={...t,steer:ce(t.steer+Math.sin(Un*11+n.num*2)*.45,-1,1)}),n.nitroOn=t.nitro&&n.nitro>.5&&n.stun<=0,n.nitroOn&&(n.nitro=Math.max(0,n.nitro-n.nitroDrain*e)),ie(n,"canela")&&(n.nitro=Math.min(100,n.nitro+3*e)),n.howl=Math.max(0,n.howl-e),ie(n,"paz")&&(n.flyY=Fe(n.flyY,n.nitroOn?4.5:0,1-Math.exp(-(n.nitroOn?2.2:1.4)*e))),n.mini=Math.max(0,n.mini-e),n.pad=Math.max(0,n.pad-e);let f=1;!n.isPlayer&&at&&!at.finished&&(f=1+ce((at.dist-n.dist)/220,-.07,.07));let d=n.maxV*n.skill*f*u*(n.nitroOn?n.nitroPow:1)*(n.mini>0?1.15:1)*(n.pad>0?1.22:1)*(n.slip>.5?ie(n,"flecha")?1.14:1.06:1)*(n.howl>0?1.15:1)*n.pack*(n.spook>0?.72:1)*(n.birdT>0?.7:1)*(n.finished?.5:1),p=n.vx*Math.sin(n.h)+n.vz*Math.cos(n.h),x=Math.max(.45,ce(Math.abs(p)/7,0,1))*(1-.3*ce(Math.abs(p)/70,0,1));!n.drifting&&t.drift&&t.steer!==0&&p>16&&!s&&n.stun<=0&&(n.drifting=!0,n.driftDir=Math.sign(t.steer),n.driftT=0),n.drifting&&(!t.drift||p<10)&&Ts(n,!1);let g;n.drifting?(n.driftT+=e,g=-n.driftDir*n.turn*x*(.8+.5*t.steer*n.driftDir),n.nitro=Math.min(100,n.nitro+(ie(n,"frufru")?16:8)*e)):g=-t.steer*n.turn*x*(p<-1?-1:1),s&&(g*=.35),n.yawRate=Fe(n.yawRate,g,1-Math.exp(-(n.drifting?6:12)*e)),n.h+=n.yawRate*e;let m=Math.abs(n.d)>Lt/2+1.6;if(n.isPlayer&&!n.drifting&&!s&&(k.assist&&!t.steer&&p>3||m)){let R=He(n.dist+8+p*.35,ce(n.d,-Lt/2+2,Lt/2-2)),O=xh(Math.atan2(R.x-n.x,R.z-n.z)-n.h);n.h+=ce(O,-1,1)*(m?3:1.8)*e}let E=Math.sin(n.h),y=Math.cos(n.h),S=-y,P=E;p=n.vx*E+n.vz*y;let w=n.vx*S+n.vz*P;if(s)w*=Math.exp(-.4*e);else if(t.throttle>0&&p<d&&(p+=(n.accel*(n.nitroOn?1.7:1)*t.throttle*(1-.55*ce(p/d,0,1))+(n.mini>0?14:0)+(n.pad>.6?30:0))*e),t.throttle||(p-=Math.sign(p)*Math.min(Math.abs(p),7*e)),t.brake&&(p=p>0?Math.max(0,p-38*e):Math.max(-9,p-12*e)),t.drift&&!n.drifting&&p>4&&(p-=10*e),p>d&&(p=Math.max(d,p-(p-d)*2.2*e-2*e)),n.drifting){let R=p*p+w*w;w*=Math.exp(-(2.6+n.grip*.1)*e),p=Math.max(p,Math.sqrt(Math.max(0,R*(1-.12*e)-w*w)))}else w*=Math.exp(-h*e);if(n.vx=E*p+S*w,n.vz=y*p+P*w,n.x+=n.vx*e,n.z+=n.vz*e,n.speed=p,n.slide=w,r&&!s&&n.stun<=0)n.vy=n.jumpV,n.dj=!1,n.isPlayer&&Ct.jump(),n.drifting&&Ts(n,!1);else if(r&&s&&ie(n,"ninja")&&!n.dj&&n.stun<=0){n.dj=!0,n.vy=Math.max(n.vy,0)+n.jumpV*.9,n.isPlayer&&(Ct.jump(),he("PULO DUPLO!","c"));for(let R=0;R<14;R++){let O=R/14*6.28;oi.spawn(n.x,n.y+.3,n.z,Math.cos(O)*5,-1,Math.sin(O)*5,.5,.5,1.2,[.85,.85,.9],.6,0,3)}}if(n.vy-=oM*e,n.y+=n.vy*e,n.y<=0){if(s){n.isPlayer&&n.vy<-8&&(Ct.land(),Ci(.12)),n.rampAir&&(n.rampAir=!1,n.nitro=Math.min(100,n.nitro+12),n.isPlayer&&he("SALTO! +NITRO","c"));for(let R=0;R<10;R++)ip(n,1.4)}n.y=0,n.vy=0,n.dj=!1}n.air=n.y>.02;let A=ce(Math.abs(p)/12,0,1);n.phase+=e*(A>.02?4+Math.abs(p)*.33:0),fM(n);let F=Lt/2+2.1;if(!(n.flyY>1.5&&Math.abs(n.d)<F+30)){if(Math.abs(n.d)>F&&n.flyY>.05&&Math.abs(n.d)<F+30){let R=Math.sign(n.d),O=Ds(n.s),Z=Math.min(Math.abs(n.d)-F,14*e);n.x-=O.r.x*R*Z,n.z-=O.r.z*R*Z}else if(Math.abs(n.d)>F){let R=Math.sign(n.d),O=Ds(n.s),Z=Math.abs(n.d)-F;n.x-=O.r.x*R*Z,n.z-=O.r.z*R*Z,n.d=R*F;let I=(n.vx*O.r.x+n.vz*O.r.z)*R;if(I>0){n.vx-=O.r.x*R*I*1.3,n.vz-=O.r.z*R*I*1.3,n.vx*=.95,n.vz*=.95;let N=Math.sin(n.h)*O.t.x+Math.cos(n.h)*O.t.z>=0?1:-1;n.h+=xh(Math.atan2(O.t.x*N,O.t.z*N)-n.h)*.3,n.isPlayer&&I>6&&(Ci(.3),Ct.thud(),On(35)),I>8&&Ts(n,!0)}}}let M=n.s;for(let R of ts)if(Math.floor((i-R.s)/Ee)<Math.floor((n.dist-R.s)/Ee)&&Math.abs(n.d)<Lt/2+.6)if(n.y<.55&&n.stun<=0&&!n.b.fly){let O=ie(n,"tofu");n.stun=O?.4:1,n.vx*=O?.65:.25,n.vz*=O?.65:.25,n.vy=3,R.fall=1,Ts(n,!0),n.nitroOn=!1,n.hits++,n.isPlayer&&(Ct.trip(),he("TROPE\xC7OU!","r"),Ci(.4),On(70))}else(n.y>=.55||n.b.fly)&&(n.nitro=Math.min(100,n.nitro+10),n.cleanJumps++,n.isPlayer&&he("PULO LIMPO! +NITRO","v"));for(let R of Eh)Math.floor((i-R.s)/Ee)<Math.floor((n.dist-R.s)/Ee)&&Math.abs(n.d)<Lt/2&&n.y<.4&&(n.vy=9+Math.max(0,p)*.13,n.y=1.1,n.rampAir=!0,n.isPlayer&&(Ct.jump(),Ci(.15)));for(let R of uc)n.pad>.5||n.y>.5||Math.abs(pn(M-R.s))<3.5&&Math.abs(n.d-R.d)<2.2&&(n.pad=1.1,n.isPlayer&&(Ct.boost(),he("TURBO!","c"),Ci(.1)));let b=n.surf;if(n.surf=null,!n.air&&!n.b.fly)for(let R of fc){let O=pn(M-R.s)/1.4,Z=(n.d-R.d)/.8;O*O+Z*Z<R.r*R.r&&(n.surf=R.type)}if(n.isPlayer&&n.surf&&n.surf!==b&&(n.surf==="ice"?he("GELO!","c"):(Ct.splash(),he(n.surf==="mud"?"LAMA!":"SPLASH!","r"))),n.surf&&n.surf!=="ice"&&Math.abs(p)>6&&Math.random()<.6){let R=n.surf==="mud"?[.25,.15,.07]:[.75,.88,1];oi.spawn(n.x,.3,n.z,(Math.random()-.5)*6,3+Math.random()*3,(Math.random()-.5)*6,.6,.3,.6,R,.9,14,1)}for(let R of Pr)if(!(!R.active||n.hitCD>0||n.stun>0||n.y>R.r*1.25||n.b.fly||ie(n,"bidu"))&&Math.abs(pn(M-R.s))<R.r+.7&&Math.abs(n.d-R.d)<R.r+.8){let O=ie(n,"tofu");n.stun=O?.4:.9,n.hitCD=2,n.vx*=O?.65:.3,n.vz*=O?.65:.3,n.vy=5,n.hits++,Ts(n,!0),n.isPlayer?(Ct.thud(),Ct.trip(),Ci(.5),he(R.hitMsg,"r"),On([80,40,80])):ii(`BOLADA EM ${n.b.name}!`)}for(let R of Ar){if(R.cd>0||n.y>2.4)continue;let O=pn(M-R.s),Z=n.d-R.d;O*O+Z*Z<(ie(n,"biscoito")?16:3.2)&&(R.cd=8,R.g.visible=!1,n.nitro=Math.min(100,n.nitro+(ie(n,"pacoca")?70:35)),n.cans++,ie(n,"caramelo")&&n.ammo<3&&Math.random()<.35&&(n.ammo++,n.isPlayer&&he("SORTE! GANHOU UM M\xCDSSIL","g")),n.isPlayer&&(Ct.pickup(),he("NITRO +35","c"),On(15)))}for(let R of Ca){if(R.cd>0||n.y>2.4||n.ammo>=(ie(n,"duque")?4:3))continue;let O=pn(M-R.s),Z=n.d-R.d;O*O+Z*Z<(ie(n,"biscoito")?16:3.4)&&(R.cd=9,R.g.visible=!1,n.ammo++,n.isPlayer&&(Ct.reload(),he(`M\xCDSSIL +1 (${n.ammo}/3)`,"o"),On(15)))}if(n.isPlayer)for(let R of Aa){if(R.taken||n.y>2.6)continue;let O=pn(M-R.s),Z=n.d-R.d;O*O+Z*Z<(ie(n,"biscoito")?16:3.4)&&(R.taken=!0,R.g.visible=!1,n.coins+=ie(n,"caramelo")?2:1,Ct.coin(),ie(n,"pacoca")&&(n.nitro=Math.min(100,n.nitro+5)))}if(!n.finished&&n.dist>=k.laps*Ee){n.finished=!0,n.finishTime=Nn;let R=Nn-n.lapStart;(!n.bestLap||R<n.bestLap)&&(n.bestLap=R),Ts(n,!1),n.isPlayer&&DM()}else if(!n.finished&&n.lap>n.lastLap){let R=Nn-n.lapStart;(!n.bestLap||R<n.bestLap)&&(n.bestLap=R),n.lapStart=Nn,n.lastLap=n.lap,n.isPlayer&&(Ct.lap(),tu(n.lap===k.laps?"\xDALTIMA VOLTA":`VOLTA ${n.lap}`,1400,`melhor volta ${Lr(n.bestLap)}`),Us(n.lap===k.laps?"\xDAltima volta!":`Volta ${n.lap}!`,!0))}if(n.isPlayer&&!n.air&&A>.1){let R=Math.floor(n.phase/Math.PI);R!==n.lastStep&&(n.lastStep=R,Ct.paw(A,yt.surface))}}function ip(n,t=1){let e=yt.surface==="snow"?[.92,.95,1]:yt.surface==="sand"?[.85,.75,.55]:[.55,.4,.27],i=n.x-Math.sin(n.h)*1.2,s=n.z-Math.cos(n.h)*1.2;oi.spawn(i+(Math.random()-.5)*1.2,.2,s+(Math.random()-.5)*1.2,(Math.random()-.5)*3*t-n.vx*.05,(.8+Math.random()*1.5)*t,(Math.random()-.5)*3*t-n.vz*.05,.9+Math.random()*.6,.6*t,2.4*t,e,.45,-.5,1.5)}function gM(n,t){wv(n,t);let e=Math.hypot(n.vx,n.vz);if(!n.air&&e>8&&Math.random()<t*e*(n.drifting?1.6:.5)*(k.qual===0?.5:1)&&ip(n,n.drifting?1.3:1),n.drifting&&!n.air){let i=n.driftT>2?2:n.driftT>.9?1:0,s=i===2?[1,.35,.9]:i===1?[.3,.8,1]:[1,.85,.4];for(let r of[-1,1]){let a=n.x-Math.sin(n.h)*1+Math.cos(n.h)*r*.3,o=n.z-Math.cos(n.h)*1-Math.sin(n.h)*r*.3;bn.spawn(a,.15,o,(Math.random()-.5)*5-n.vx*.1,2+Math.random()*3,(Math.random()-.5)*5-n.vz*.1,.35,i?.35:.22,.05,s,1,12,1)}}if(n.nitroOn)for(let i of n.D.flames){let s=i.getWorldPosition(jt);bn.spawn(s.x,s.y,s.z,-Math.sin(n.h)*8+(Math.random()-.5),Math.random()-.5,-Math.cos(n.h)*8+(Math.random()-.5),.25,.45,.1,Math.random()<.5?[1,.5,.15]:[.35,.75,1],1,0,2)}if(n.mini>0||n.pad>0){let i=n.D.body.getWorldPosition(jt);bn.spawn(i.x,i.y+.4,i.z,-n.vx*.3,.5,-n.vz*.3,.3,.8,.2,n.pad>0?[.3,.85,1]:[1,.55,.2],.7,0,1)}}function Ch(n,t){let e=n.s;n.laneT-=t,n.laneT<=0&&(n.lane=(Math.random()-.5)*10,n.laneT=2+Math.random()*3);let i=n.lane;if(n.nitro<60)for(let p of Ar){let x=pn(p.s-e);if(p.cd<=0&&x>0&&x<40){i=p.d;break}}for(let p of uc){let x=pn(p.s-e);if(x>0&&x<35){i=p.d;break}}for(let p of fc){let x=pn(p.s-e);x>-3&&x<30&&Math.abs(i-p.d)<p.r+2&&(i=p.d+(i>=p.d?1:-1)*(p.r+2.6))}for(let p of pe){if(p===n)continue;let x=pn(p.dist-n.dist);x>0&&x<6&&Math.abs(p.d-n.d)<2.2&&(i+=n.d>=p.d?2.6:-2.6)}i=ce(i,-Lt/2+1.5,Lt/2-1.5);let s=7+Math.max(0,n.speed)*.42,r=He(n.dist+s,i),a=xh(Math.atan2(r.x-n.x,r.z-n.z)-n.h),o=ce(-a*2.6,-1,1),l=1-si[n.idx].dot(si[(n.idx+40)%$e])>.2&&n.speed>n.maxV*.9?.4:1,h=!1;for(let p=0;p<ts.length;p++){let x=pn(ts[p].s-e),g=p+":"+Math.floor((n.dist-ts[p].s)/Ee);n.jumpPlan.has(g)||n.jumpPlan.set(g,Math.random()<es[k.diff].miss?-1:.2+Math.random()*.14);let m=n.jumpPlan.get(g);m>0&&x>0&&x<n.speed*m+1&&(h=!0)}let u=si[n.idx].dot(si[(n.idx+80)%$e])>.94;u&&n.nitro>35&&(n.aiNitro=!0),(!u||n.nitro<5)&&(n.aiNitro=!1);for(let p of Pr){if(!p.active)continue;let x=pn(p.s-e);x>0&&x<n.speed*.3+p.r+1&&Math.abs(p.d-n.d)<p.r+2.5&&Math.random()>es[k.diff].miss*t*30&&(h=!0)}let f=n.birdT>0&&n.barkCD<=0&&Math.random()<t*(.8+k.diff*.8);if(n.barkCD<=0&&Math.random()<t*(.25+k.diff*.2))for(let p of pe){if(p===n)continue;let x=pn(p.dist-n.dist);x>1&&x<9&&Math.abs(p.d-n.d)<4&&(f=!0)}let d=!1;return n.ammo>0&&n.fireCD<=0&&Nn>4&&Math.random()<t*(.5+k.diff*.45)&&op(n)&&(d=!0),{throttle:l,brake:!1,steer:o,drift:!1,nitro:n.aiNitro,jump:h,bark:f,fire:d}}function xM(n){if(!(Bt!=="race"&&Bt!=="finished"))for(let t of pe){if(ie(t,"pintado")){let e=0;for(let i of pe)i!==t&&Math.hypot(i.x-t.x,i.z-t.z)<12&&e++;t.pack=1+Math.min(e,4)*.02}if(ie(t,"faiton")&&!t.finished){let e=0;for(let i of pe)i!==t&&(i.finished||i.dist>t.dist)&&e++;if(e>t.prevAhead&&Nn>3){t.howl=3.5,Ct.howl(at?ce(1-Math.hypot(t.x-at.x,t.z-at.z)/70,0,1):1),t.isPlayer?he("UIVO DA LUA! +VELOCIDADE","o"):ii("FAITON UIVOU E ACELEROU!");let i=t.D.head.getWorldPosition(jt);for(let s=0;s<18;s++){let r=s/18*6.28;bn.spawn(i.x,i.y,i.z,Math.cos(r)*3,2,Math.sin(r)*3,.8,.6,1.4,[.75,.85,1],.7,-1,1.5)}}if(t.prevAhead=e,t.howl>0&&Math.random()<n*20){let i=t.D.body.getWorldPosition(jt);bn.spawn(i.x,i.y+.6,i.z,-t.vx*.2,.8,-t.vz*.2,.4,.6,.1,[.6,.75,1],.8,0,1)}}}}function sp(n){xM(n);for(let t=0;t<pe.length;t++)for(let e=t+1;e<pe.length;e++){let i=pe[t],s=pe[e],r=s.x-i.x,a=s.z-i.z,o=r*r+a*a,c=cM*2;if(o<c*c&&Math.abs(i.y+i.flyY-s.y-s.flyY)<1.2){let l=Math.sqrt(o)||.01,h=r/l,u=a/l,f=(c-l)/2,d=(s.b.mass||1)/((i.b.mass||1)+(s.b.mass||1))*2,p=2-d;i.x-=h*f*d,i.z-=u*f*d,s.x+=h*f*p,s.z+=u*f*p;let x=(s.vx-i.vx)*h+(s.vz-i.vz)*u;if(x<0){let g=ie(i,"princesa")?1e6:i.b.mass||1,m=ie(s,"princesa")?1e6:s.b.mass||1,E=-1.3*x/(1/g+1/m)*(ie(i,"princesa")||ie(s,"princesa")?1.4:1);i.vx-=E/g*h,i.vz-=E/g*u,s.vx+=E/m*h,s.vz+=E/m*u;for(let[y,S]of[[i,s],[s,i]])ie(y,"linda")&&y.nitroOn&&S.stun<=0&&(S.stun=.8,S.vx*=.4,S.vz*=.4,S.vy=5,S.hits++,S.isPlayer&&he("ATROPELADO PELA LINDA!","r"),y.isPlayer&&he(`INVESTIDA EM ${S.b.name}!`,"v"));(i.isPlayer||s.isPlayer)&&-x>5&&(Ct.thud(),Ci(.2))}}}for(let t of pe){let e=Math.sin(t.h),i=Math.cos(t.h),s=!1;for(let r of pe){if(r===t||r.speed<15)continue;let a=r.x-t.x,o=r.z-t.z,c=a*e+o*i,l=Math.abs(a*i-o*e);if(c>2.5&&c<14&&l<1.8){s=!0;break}}t.slip=s?t.slip+n:0,t.slip>.5&&(t.nitro=Math.min(100,t.nitro+(ie(t,"flecha")?15:5)*n))}}var Is=[],Ir=[],Ca=[];function rp(){let n=new vt,t=new bt(new Vt(.14,.14,.9,14),gt(15658734,.35,.5));t.rotation.x=Math.PI/2,n.add(t);let e=new bt(new je(.14,.34,14),lc);e.rotation.x=Math.PI/2,e.position.z=.62,n.add(e);let i=new bt(new Vt(.145,.145,.1,14),Gh);i.rotation.x=Math.PI/2,i.position.z=.2,n.add(i);for(let r=0;r<4;r++){let a=new bt(new xe(.02,.3,.22),lc);a.rotation.z=r*Math.PI/2,a.position.z=-.38,a.translateY(.15),n.add(a)}let s=new bt(new je(.12,.6,10),new Tn({color:16752704,transparent:!0,opacity:.9,blending:Zi,depthWrite:!1}));return s.rotation.x=-Math.PI/2,s.position.z=-.75,n.add(s),n.traverse(r=>{r.isMesh&&(r.castShadow=!0)}),n.visible=!1,n}function yM(){Ir=[],Is=[];for(let n=0;n<10;n++){let t=rp();Le.add(t),Ir.push(t)}}function ap(){for(let n of Is)n.mesh.visible=!1,Ir.push(n.mesh);Is=[];for(let n of pe)n.lockT=0}function op(n){let t=Math.sin(n.h),e=Math.cos(n.h),i=null,s=95;for(let r of pe){if(r===n||r.finished)continue;let a=r.x-n.x,o=r.z-n.z,c=Math.hypot(a,o);c<s&&c>2&&(a*t+o*e)/c>.55&&(s=c,i=r)}return i}function _M(n){if(n.ammo<=0||n.fireCD>0||n.stun>0||!Ir.length){n.isPlayer&&n.ammo<=0&&he("SEM M\xCDSSEIS! PEGUE AS CAIXAS","r");return}n.ammo--,n.fireCD=.7;let t=Ir.pop(),e=n.D.launcher.muzzle.getWorldPosition(new L),i=op(n),s=Math.sin(n.h),r=Math.cos(n.h),a=Math.max(0,n.speed)+38;t.visible=!0,t.position.copy(e),Is.push({mesh:t,pos:e,vel:new L(s*a,3,r*a),owner:n,target:i,t:0});let o=at?ce(1-Math.hypot(n.x-at.x,n.z-at.z)/70,0,1):1;Ct.launch(o);for(let c=0;c<12;c++)oi.spawn(e.x,e.y,e.z,(Math.random()-.5)*4-s*6,Math.random()*2,(Math.random()-.5)*4-r*6,.8,.5,1.6,[.8,.8,.8],.6,-1,2);n.isPlayer&&he(i?`M\xCDSSIL NO ${i.b.name}!`:"M\xCDSSIL!","o"),i&&i.isPlayer&&(he(`${n.b.name} ATIROU EM VOC\xCA!`,"r"),Ct.lockon())}var mh=new L;function cp(n){for(let t=Is.length-1;t>=0;t--){let e=Is[t];e.t+=n;let i=e.target&&!e.target.finished?e.target:null,s=Math.max(62,e.vel.length());i?(mh.set(i.x,1.1+i.y,i.z).sub(e.pos).normalize().multiplyScalar(s),e.vel.lerp(mh,1-Math.exp(-(e.t<.25?1:3.4)*n)),i.isPlayer&&(i.lockT=.3)):e.vel.y+=(1.2-e.pos.y)*n*4,e.vel.setLength(Math.min(s+25*n,80)),e.pos.addScaledVector(e.vel,n),e.pos.y<.5&&(e.pos.y=.5,e.vel.y=Math.abs(e.vel.y)*.3),e.mesh.position.copy(e.pos),e.mesh.lookAt(mh.copy(e.pos).add(e.vel)),bn.spawn(e.pos.x,e.pos.y,e.pos.z,-e.vel.x*.05,.3,-e.vel.z*.05,.25,.7,.2,Math.random()<.5?[1,.6,.2]:[1,.9,.5],1,0,2),Math.random()<.7&&oi.spawn(e.pos.x,e.pos.y,e.pos.z,Math.random()-.5,Math.random(),Math.random()-.5,1.2,.5,2.2,[.75,.75,.78],.45,-.6,1.5);let r=null;for(let a of pe)if(!(a===e.owner&&e.t<1.5)&&!(a.flyY>1.5||e.dodge&&e.dodge.has(a))){if(ie(a,"sombra")&&Math.hypot(a.x-e.pos.x,a.z-e.pos.z)<1.8&&(e.dodge=e.dodge||new Set,e.dodge.add(a),Math.random()<.5)){a.isPlayer?he("ESQUIVOU DO M\xCDSSIL!","v"):e.owner.isPlayer&&he("O SOMBRA ESQUIVOU!","r");continue}if(Math.hypot(a.x-e.pos.x,a.z-e.pos.z)<1.8&&Math.abs(a.y+1-e.pos.y)<1.8){r=a;break}}(r||e.t>3.2)&&(vM(e,r),Is.splice(t,1))}}function vM(n,t){n.mesh.visible=!1,Ir.push(n.mesh);let e=n.pos;for(let s=0;s<40;s++){let r=Math.random()*6.28,a=Math.random()*10;bn.spawn(e.x,e.y,e.z,Math.cos(r)*a,Math.random()*9,Math.sin(r)*a,.5+Math.random()*.4,1.4,.3,Math.random()<.5?[1,.55,.15]:[1,.85,.3],1,6,2.5)}for(let s=0;s<18;s++)oi.spawn(e.x,e.y,e.z,(Math.random()-.5)*7,Math.random()*5,(Math.random()-.5)*7,1.6,1.2,3.6,[.3,.28,.27],.7,-1.5,1.8);let i=at?Math.hypot(e.x-at.x,e.z-at.z):0;Ct.boom(ce(1-i/90,0,1)),i<25&&Ci(.6*(1-i/25)),t&&(t.stun=1.4,t.flip=1,t.vx*=.2,t.vz*=.2,t.vy=8,t.nitroOn=!1,t.hits++,Ts(t,!0),n.owner!==t&&n.owner.missHits++,t.isPlayer?(he("ATINGIDO POR UM M\xCDSSIL!","r"),Ci(.8),On([100,50,160]),n.owner!==t&&ii(`${n.owner.b.name} ACERTOU VOC\xCA COM UM M\xCDSSIL!`,!0)):!n.owner.isPlayer&&n.owner!==t&&ii(`${n.owner.b.name} ACERTOU ${t.b.name} COM UM M\xCDSSIL!`),n.owner.isPlayer&&t!==n.owner&&(he(`ACERTOU ${t.b.name}!`,"v"),ii(`VOC\xCA ACERTOU ${t.b.name}!`,!0),n.owner.nitro=Math.min(100,n.owner.nitro+10)))}function ba(n){n.D.root.position.set(n.x,0,n.z),n.D.root.rotation.y=n.h,n.D.launcher.noses.forEach((t,e)=>{t.visible=e<n.ammo}),n.D.model.rotation.x=n.flip>0?-(1-n.flip)*Math.PI*2:0,n.D.model.position.y=n.y+n.flyY,n.D.anim(n.D,{v:Math.hypot(n.vx,n.vz),y:n.y,vy:n.vy,phase:n.phase,yawRate:n.yawRate,stun:n.stun,spook:n.spook,nitro:n.nitroOn,idle:!1},Un+n.num)}var Qh=["ATR\xC1S","ALTA","CACHORRO"],Ri=new L(0,0,1),gh=new L,Ii=new L,br=0;function Ci(n){br=Math.max(br,n)}function Ph(n,t,e=!1){let i=Math.hypot(n.vx,n.vz),s=Math.sin(n.h),r=Math.cos(n.h);if(i>4&&(s=s*.55+n.vx/i*.45,r=r*.55+n.vz/i*.45),Ii.set(s,0,r).normalize(),Ri.lerp(Ii,e?1:1-Math.exp(-4.5*t)).normalize(),k.cam===2){let o=n.D.head.getWorldPosition(Ii);ye.position.set(o.x-Ri.x*.3,o.y+.55,o.z-Ri.z*.3),gh.set(n.x+Ri.x*25,1.2+(n.y+n.flyY)*.3,n.z+Ri.z*25)}else{let o=(k.cam?11.5:6.6)+i*.025,c=k.cam?6:2.7;Ii.set(n.x-Ri.x*o,c+(n.y+n.flyY)*.5,n.z-Ri.z*o),ye.position.lerp(Ii,e?1:1-Math.exp(-8*t)),gh.set(n.x+Ri.x*5,1.3+(n.y+n.flyY)*.6,n.z+Ri.z*5)}br>.001&&(ye.position.x+=(Math.random()-.5)*br,ye.position.y+=(Math.random()-.5)*br,br*=Math.exp(-7*t)),ye.lookAt(gh);let a=64+i*.18+(n.nitroOn?10:0)+(n.pad>0||n.mini>0?5:0);ye.fov=Fe(ye.fov,a,1-Math.exp(-3*t)),ye.updateProjectionMatrix()}var Bt="loading",Nn=0,Ta=0,Oi=0,Ih=-1,Rd="race",Un=0,Mr=0,Lr=n=>{let t=Math.floor(n/60),e=Math.floor(n%60),i=Math.floor(n*100%100);return`${t}:${String(e).padStart(2,"0")}.${String(i).padStart(2,"0")}`};function he(n,t=""){let e=document.createElement("div");e.className="pop "+t,e.textContent=n;let i=ft("pops");for(i.appendChild(e);i.children.length>3;)i.firstChild.remove();setTimeout(()=>e.remove(),1300)}var Cd=null;function tu(n,t=1200,e=""){let i=ft("big");i.innerHTML=n+(e?`<small>${e}</small>`:""),i.classList.remove("pop"),i.offsetWidth,i.classList.add("pop"),clearTimeout(Cd),t&&(Cd=setTimeout(()=>{i.innerHTML=""},t))}var Lh=["","primeiro","segundo","terceiro","quarto","quinto","sexto"];function MM(n){return n.replace(/(\d)º LUGAR/g,(t,e)=>Lh[+e]+" lugar").replace(/(\d)º/g,(t,e)=>Lh[+e]||e).replace(/[+]\d+/g,"").replace(/[^\p{L}\p{N} ,.!?-]/gu," ").replace(/\s+/g," ").trim().toLowerCase()}var wc={v:null,until:0,pick(){try{let n=speechSynthesis.getVoices();this.v=n.find(t=>/pt[-_]BR/i.test(t.lang))||n.find(t=>/^pt/i.test(t.lang))||null}catch{}},duck(n){Rn.volume=n?.2:Bt==="paused"?.25:.6,Ct.music&&Ct.ctx&&Ct.music.gain.setTargetAtTime(n?.07:jh[k.musicMode]==="8-BIT"?.22:0,Ct.ctx.currentTime,.1)},say(n,t){if(!k.voice)return;let e=MM(n);if(!e)return;let i=performance.now();if(window.AndroidTTS){try{if(!t&&AndroidTTS.busy())return;AndroidTTS.speak(e)}catch{return}this.duck(!0),clearTimeout(this.tm),this.tm=setTimeout(()=>this.duck(!1),500+e.length*70);return}if(!("speechSynthesis"in window))return;if(speechSynthesis.speaking||i<this.until){if(!t)return;speechSynthesis.cancel()}this.v||this.pick();let s=new SpeechSynthesisUtterance(e);s.lang="pt-BR",this.v&&(s.voice=this.v),s.rate=1.12,s.pitch=1.05,s.onstart=()=>this.duck(!0),s.onend=s.onerror=()=>{this.until=0,this.duck(!1)},this.until=i+400+e.length*80;try{speechSynthesis.speak(s)}catch{}},stop(){try{window.AndroidTTS?AndroidTTS.stop():speechSynthesis.cancel()}catch{}this.duck(!1)}};try{speechSynthesis.onvoiceschanged=()=>wc.pick()}catch{}function Us(n,t){wc.say(n,t)}function On(n){if(k.vib&&navigator.vibrate)try{navigator.vibrate(n)}catch{}}function Se(n,t){ft(n).hidden=!t}function Ur(){document.querySelectorAll(".cval").forEach(n=>n.textContent=k.coins.toLocaleString("pt-BR"))}function Ac(){Ye&&(rn.remove(Ye.root),Cr(Ye.root));let n=ke[k.dog];Ye=qd(n,1,n.color),Mc(Ye,vc(n)),rn.add(Ye.root);let t=He(22,0);if(!mn||mn.parent!==Le){mn=new vt,At(new Vt(3.2,3.4,.3,48),gt(2764600,.3,.8),!0,!0,mn).position.y=.15;let e=At(new xr(3.3,.06,8,64),gt(16742938,.3,0,{emissive:16742938,emissiveIntensity:1.5}),!1,!1,mn);e.rotation.x=Math.PI/2,e.position.y=.3,Le.add(mn)}mn.position.copy(t),Ye.root.position.set(t.x,.3,t.z)}function Or(){let n=ke[k.dog],t=Tc(n);ft("dogName").textContent=n.name,ft("dogBreed").textContent=n.raca;let e=lM[n.id];ft("dogPas").innerHTML=e?`<b>\u2605 ${e[0]}</b> ${e[1]}`:"";let i=[["VELOCIDADE",n.spd,t.motor],["ACELERA\xC7\xC3O",n.acc,t.acel],["CURVAS",n.han,t.grip],["PULO",n.jmp,t.pulo]];ft("stats").innerHTML=i.map(([s,r,a])=>`<div class="stat"><span>${s}</span><div class="cells">${Array.from({length:10},(o,c)=>`<span class="${c<r?"b":c<r+a?"u":""}"></span>`).join("")}</div></div>`).join(""),ft("trackName").textContent=Ns[k.track].name.split(" ")[0],ft("diffName").textContent=es[k.diff].n,ft("lapsName").textContent=k.laps,ft("modeName").textContent=k.mode?"COPA":"CORRIDA",k.mode&&(ft("trackName").textContent="TODAS"),ft("startBtn").textContent=k.mode?"COME\xC7AR COPA":"CORRER",Ur()}function lp(){let n=ke[k.dog],t=Tc(n);ft("garageDog").textContent=`${n.name} \xB7 ${n.raca}`,ft("upList").innerHTML=rM.map(e=>{let i=t[e.id],s=np[i],r=i>=5;return`<div class="up panel"><h3>${e.name}</h3><p>${e.desc}</p><div class="pips">${[0,1,2,3,4].map(a=>`<span class="${a<i?"on":""}"></span>`).join("")}</div>
      <button data-up="${e.id}" ${r||k.coins<s?"disabled":""}>${r?"M\xC1XIMO":"MELHORAR<br>"+s}</button></div>`}).join(""),Ur()}ft("upList").addEventListener("click",n=>{let t=n.target.closest("button[data-up]");if(!t||t.disabled)return;let e=ke[k.dog],i=Tc(e),s=t.dataset.up,r=np[i[s]];k.coins<r||i[s]>=5||(k.coins-=r,i[s]++,i[s]>=5&&(k.stats.maxUp=1),Qe(),Ua(),Ct.init(),Ct.pickup(),Ct.voice(e,.6),lp())});function mi(){nu(),wc.stop(),ft("pops").style.top="",Bt="menu",["hud","results","pause","touch","lights","garage","shop","missions","cupEnd"].forEach(n=>Se(n,!1)),Se("menu",!0),ft("big").innerHTML="",ft("pops").innerHTML="",ou(0,0),Ct.ctx&&["wind","skid","nitro"].forEach(n=>Ct.setLoop(n,0)),ru(),Ac(),Or()}var Dn="hat",ic="daily";function EM(){Bt="shop",["menu"].forEach(n=>Se(n,!1)),Se("shop",!0),eu()}function eu(){let n=ke[k.dog],t=vc(n);ft("shopDog").textContent=`${n.name} \xB7 ${n.raca}`,ft("shopTabs").innerHTML=Object.entries(Cs).map(([e,i])=>`<button data-c="${e}" class="${e===Dn?"on":""}">${i.n}</button>`).join(""),ft("shopList").innerHTML=Cs[Dn].items.map(([e,i,s])=>{let r=Ev(Dn,e),a=t[Dn]===e,o=Dn==="vest"?e==="padrao"?n.color:"#"+Xd[e].toString(16).padStart(6,"0"):Dn==="cape"?Yd[e]||"transparent":Dn==="trail"?yv[e]||"transparent":Dn==="hat"?_v[e]||"transparent":vv[e]||"transparent",c=a?'<button class="eq" disabled>EM USO</button>':r?`<button data-eq="${e}">USAR</button>`:`<button data-buy="${e}" ${k.coins<s?"disabled":""}>COMPRAR ${s}</button>`;return`<div class="item panel"><span class="sw" style="background:${o}"></span><div><h4>${i}</h4><small>${r?a?"equipado no "+n.name:"seu":s+" ossos de ouro"}</small></div>${c}</div>`}).join(""),Ur()}ft("shopTabs").addEventListener("click",n=>{let t=n.target.closest("button[data-c]");t&&(Dn=t.dataset.c,eu())});ft("shopList").addEventListener("click",n=>{let t=n.target.closest("button");if(!t||t.disabled)return;let e=ke[k.dog],i=vc(e);if(t.dataset.buy){let s=Cs[Dn].items.find(r=>r[0]===t.dataset.buy);if(k.coins<s[2])return;k.coins-=s[2],k.owned.push(Dn+":"+s[0]),Yn("bought"),Ct.init(),Ct.pickup(),On(30),i[Dn]=s[0]}else t.dataset.eq&&(i[Dn]=t.dataset.eq,Ct.init(),Ct.beep(!1));k.looks[e.id]=i,Qe(),Ye&&Mc(Ye,i),Ua(),eu()});function SM(){Bt="missions",Se("menu",!1),Se("missions",!0),mp(),hp(),Ur()}function hp(){ru(),document.querySelectorAll("#missTabs button").forEach(s=>s.classList.toggle("on",s.dataset.t===ic));let n=new Date,t=new Date(n);t.setHours(24,0,0,0);let e=Math.floor((t-n)/36e5),i=Math.floor((t-n)/6e4)%60;ft("dailyTag").textContent=ic==="daily"?`NOVAS MISS\xD5ES EM ${e}H ${i}MIN`:`${k.ach.length} DE ${Oh.length} CONQUISTAS`,ic==="daily"?ft("missList").innerHTML=k.daily.ids.map(s=>{let r=pc.find(c=>c.id===s),a=Math.min(pp(r),r.n),o=k.daily.claimed.includes(s);return`<div class="item panel ${o?"done":""}"><span class="sw" style="background:${o?"var(--good)":"transparent"}"></span><div><h4>${r.txt}</h4><div class="bar2"><i style="width:${a/r.n*100}%"></i></div><small>${a}/${r.n}</small></div><span class="rw">${o?"RECEBIDO":"+"+Dh}</span></div>`}).join("")+`<div class="item panel ${k.daily.bonus?"done":""}"><span class="sw" style="background:${k.daily.bonus?"var(--good)":"transparent"}"></span><div><h4>B\xF4nus: complete as 3 miss\xF5es</h4><small>${k.daily.claimed.length}/3</small></div><span class="rw">${k.daily.bonus?"RECEBIDO":"+"+Uh}</span></div>`:ft("missList").innerHTML=Oh.map(s=>{let r=k.ach.includes(s.id),a=Math.min(s.v(),s.g);return`<div class="item panel ${r?"done":""}"><span class="sw" style="background:${r?"var(--gold)":"transparent"}"></span><div><h4>${s.n}</h4><small>${s.d}${r?"":" \xB7 "+a+"/"+s.g}</small>${r?"":`<div class="bar2"><i style="width:${a/s.g*100}%"></i></div>`}</div><span class="rw">${r?"\u2713":"+"+s.r}</span></div>`}).join("")}ft("missTabs").addEventListener("click",n=>{let t=n.target.closest("button[data-t]");t&&(ic=t.dataset.t,hp())});function dc(){Bt==="results"&&(nu(),Ac()),Bt="garage",["menu","results"].forEach(n=>Se(n,!1)),Se("garage",!0),lp()}function nu(){ap(),pe.forEach(n=>n.dispose()),pe=[],at=null,Qd()}function up(n){k.track=n,Qe(),Se("loading",!0),requestAnimationFrame(()=>requestAnimationFrame(()=>{Zh(k.track),mn=null,Ac(),Or(),Se("loading",!1)}))}function Os(){Ct.init(),nu(),Ye&&(rn.remove(Ye.root),Cr(Ye.root),Ye=null),mn&&(Le.remove(mn),Cr(mn),mn=null),ye.clearViewOffset();let n=Tc(ke[k.dog]),t=Object.values(n).reduce((r,a)=>r+a,0)/5,e=ue?[k.dog,...ue.rivals]:[k.dog,...ke.map((r,a)=>a).filter(r=>r!==k.dog).sort(()=>Math.random()-.5).slice(0,5)],i=[5,...[0,1,2,3,4].sort(()=>Math.random()-.5)];e.forEach((r,a)=>{let o=ke[r],c=n;if(a){let d=()=>ce(Math.round(t+es[k.diff].upOff+(Math.random()*2-1)),0,5);c={motor:d(),acel:d(),grip:d(),nitro:d(),pulo:d()}}let l=new Ah(o,a+1,a===0,c),h=i[a],u=Math.floor(h/2),f=h%2;l.place(-5-u*6.5-f*2.5,f?3.6:-3.6),ue&&a&&ue.looks[o.id]&&(l.look=ue.looks[o.id],Mc(l.D,l.look)),l.lane=l.d,pe.push(l),a||(at=l)}),ts.forEach(r=>{r.fall=0,r.bar.rotation.x=0,r.bar.position.y=.95}),Ar.forEach(r=>{r.cd=0,r.g.visible=!0}),Ca.forEach(r=>{r.cd=0,r.g.visible=!0}),Aa.forEach(r=>{r.taken=!1,r.g.visible=!0}),rc=null,_a=5,Nh=!1,gc=0,mc=0,ft("narr").classList.remove("on"),ft("cupTag").textContent=ue?`COPA \xB7 CORRIDA ${ue.idx+1}/${ue.tracks.length}`:"",ap(),oi.clear(),bn.clear(),Qd(),TM(),ft("goals").classList.remove("mini"),Nn=0,Ta=4,Ih=4,Oi=0,Bt="countdown",pe.forEach(ba),ye.fov=64,Ph(at,.016,!0),["menu","results","pause","garage"].forEach(r=>Se(r,!1)),Se("hud",!0),Se("lights",!0),La&&Se("touch",!0),ft("lapT").textContent=k.laps,ft("posOf").textContent="DE "+pe.length,ft("lights").querySelectorAll("span").forEach(r=>r.className=""),bh(0,!1);let s=k.best[yt.id+"_"+k.laps];ft("bestLap").textContent=s?"RECORDE "+Lr(s):"",Ra=.6}var bM=[{id:"mini",txt:"Fa\xE7a 3 mini-turbos no drift",n:3,v:n=>n.minis},{id:"scare",txt:"Espante 2 bichos com o latido",n:2,v:n=>n.scared},{id:"jumps",txt:"Pule 3 barreiras sem trope\xE7ar",n:3,v:n=>n.cleanJumps},{id:"coins",txt:"Pegue 10 ossos de ouro",n:10,v:n=>n.coins},{id:"cans",txt:"Pegue 3 latas de nitro",n:3,v:n=>n.cans},{id:"missile",txt:"Acerte 2 m\xEDsseis nos rivais",n:2,v:n=>n.missHits},{id:"clean",txt:"Termine sem trope\xE7ar nem ser atingido",final:!0,ok:(n,t)=>n.finished&&n.hits===0,bad:n=>n.hits>0},{id:"podium",txt:"Termine no p\xF3dio",final:!0,ok:(n,t)=>n.finished&&t<=3}],iu=120,pi=[],sc=0;function TM(){pi=bM.slice().sort(()=>Math.random()-.5).slice(0,3).map(n=>({g:n,done:!1})),sc=5,su()}function fp(n,t){let e=n.g,i=n.done?"\u2713":"",s="";return e.final?e.bad&&e.bad(at)&&(i="\u2717"):s=`${Math.min(e.v(at),e.n)}/${e.n}`,`<div class="${n.done?"ok":i==="\u2717"?"no":""}"><i>${i}</i><span>${e.txt}</span><b>${n.done?"+"+iu:s}</b></div>`}function su(){let n=pi.map(e=>fp(e)).join(""),t=pi.filter(e=>e.done).length;ft("goals").innerHTML=`<div class="gh">DESAFIOS <b>${t}/${pi.length}</b></div>`+n,ft("pauseGoals").innerHTML=`<div class="gh">DESAFIOS <b>${t}/${pi.length}</b></div>`+n}function dp(n){let t=!1;for(let i of pi)i.done||i.g.final||i.g.v(at)>=i.g.n&&(i.done=!0,t=!0,he(`DESAFIO CUMPRIDO! +${iu}`,"g"),Ct.lap(),sc=2.5,Us("Desafio cumprido!"));sc-=n;let e=sc>0;ft("goals").classList.toggle("mini",!e),(t||Math.random()<n*4)&&su()}function Mn(n){return k.stats[n]||0}function Yn(n,t=1){k.stats[n]=(k.stats[n]||0)+t}var pc=[{id:"win",txt:"Ven\xE7a 1 corrida",n:1,stat:"wins"},{id:"podium",txt:"Chegue ao p\xF3dio 2 vezes",n:2,stat:"podiums"},{id:"races",txt:"Complete 3 corridas",n:3,stat:"races"},{id:"minis",txt:"Fa\xE7a 8 mini-turbos",n:8,stat:"minis"},{id:"missiles",txt:"Acerte 4 m\xEDsseis",n:4,stat:"missHits"},{id:"birds",txt:"Espante 4 bichos voadores",n:4,stat:"scared"},{id:"coins",txt:"Pegue 25 ossos de ouro na pista",n:25,stat:"coins"},{id:"jumps",txt:"Pule 8 barreiras sem trope\xE7ar",n:8,stat:"cleanJumps"},{id:"cans",txt:"Pegue 6 latas de nitro",n:6,stat:"cans"}],Dh=250,Uh=300;function wM(){let n=new Date;return`${n.getFullYear()}-${n.getMonth()+1}-${n.getDate()}`}function ru(){let n=wM();if(k.daily&&k.daily.date===n)return;let t=7;for(let r of n)t=t*31+r.charCodeAt(0)>>>0;let e=pc.slice();for(let r=e.length-1;r>0;r--){t=t*1103515245+12345>>>0;let a=t%(r+1);[e[r],e[a]]=[e[a],e[r]]}let i=e.slice(0,3).map(r=>r.id),s={};i.forEach(r=>{let a=pc.find(o=>o.id===r);s[a.stat]=Mn(a.stat)}),k.daily={date:n,ids:i,base:s,claimed:[],bonus:!1},Qe()}function pp(n){return Math.max(0,Mn(n.stat)-(k.daily.base[n.stat]||0))}function mp(){ru();let n=[];for(let t of k.daily.ids){let e=pc.find(i=>i.id===t);!k.daily.claimed.includes(t)&&pp(e)>=e.n&&(k.daily.claimed.push(t),k.coins+=Dh,n.push([`Miss\xE3o di\xE1ria: ${e.txt}`,Dh]))}return!k.daily.bonus&&k.daily.claimed.length===k.daily.ids.length&&(k.daily.bonus=!0,k.coins+=Uh,n.push(["Todas as miss\xF5es do dia",Uh])),n}var Oh=[{id:"first",n:"Primeira corrida",d:"Complete uma corrida",v:()=>Mn("races"),g:1,r:100},{id:"win1",n:"Primeira vit\xF3ria",d:"Ven\xE7a uma corrida",v:()=>Mn("wins"),g:1,r:200},{id:"win10",n:"Campe\xE3o de verdade",d:"Ven\xE7a 10 corridas",v:()=>Mn("wins"),g:10,r:800},{id:"podium10",n:"Fregu\xEAs do p\xF3dio",d:"Chegue ao p\xF3dio 10 vezes",v:()=>Mn("podiums"),g:10,r:400},{id:"minis50",n:"Rei do drift",d:"Fa\xE7a 50 mini-turbos",v:()=>Mn("minis"),g:50,r:500},{id:"miss20",n:"Mira de \xE1guia",d:"Acerte 20 m\xEDsseis",v:()=>Mn("missHits"),g:20,r:500},{id:"birds30",n:"Espantalho",d:"Espante 30 bichos voadores",v:()=>Mn("scared"),g:30,r:500},{id:"coins200",n:"Garimpeiro",d:"Pegue 200 ossos de ouro na pista",v:()=>Mn("coins"),g:200,r:500},{id:"jumps50",n:"Saltador",d:"Pule 50 barreiras sem trope\xE7ar",v:()=>Mn("cleanJumps"),g:50,r:400},{id:"cup1",n:"Ta\xE7a na estante",d:"Ven\xE7a um campeonato",v:()=>Mn("cups"),g:1,r:1e3},{id:"cupHard",n:"Lenda das pistas",d:"Ven\xE7a um campeonato no dif\xEDcil",v:()=>Mn("cupsHard"),g:1,r:2e3},{id:"tracks",n:"Turista",d:"Ven\xE7a nas 3 pistas",v:()=>(k.stats.tracksWon||[]).length,g:3,r:600},{id:"zoo",n:"Zool\xF3gico completo",d:"Ven\xE7a com 6 corredores diferentes",v:()=>(k.stats.breedsWon||[]).length,g:6,r:1200},{id:"style",n:"Estiloso",d:"Compre 5 itens na loja",v:()=>Mn("bought"),g:5,r:300},{id:"tuned",n:"Tunado",d:"Deixe uma melhoria no n\xEDvel m\xE1ximo",v:()=>Mn("maxUp"),g:1,r:300}];function Ua(n){let t=[];for(let e of Oh)k.ach.includes(e.id)||e.v()<e.g||(k.ach.push(e.id),k.coins+=e.r,t.push([`Conquista: ${e.n}`,e.r]),n||he(`CONQUISTA: ${e.n.toUpperCase()}! +${e.r}`,"g"));return t.length&&Qe(),t}function AM(n){let t=at,e=k.stats;Yn("races"),n===1&&Yn("wins"),n<=3&&Yn("podiums"),Yn("minis",t.minis),Yn("missHits",t.missHits),Yn("scared",t.scared),Yn("coins",t.coins),Yn("cleanJumps",t.cleanJumps),Yn("cans",t.cans),n===1&&(e.tracksWon=e.tracksWon||[],e.tracksWon.includes(yt.id)||e.tracksWon.push(yt.id),e.breedsWon=e.breedsWon||[],e.breedsWon.includes(t.b.id)||e.breedsWon.push(t.b.id))}var RM=[10,7,5,3,2,1],CM=[1e3,600,400,0,0,0],ue=null;function PM(){Ct.init();let n=ke.map((t,e)=>e).filter(t=>t!==k.dog).sort(()=>Math.random()-.5).slice(0,5);ue={idx:0,tracks:[0,1,2],rivals:n,pts:{},looks:{}},n.forEach(t=>ue.looks[ke[t].id]=$d()),gp(0,Os)}function gp(n,t){Se("loading",!0),requestAnimationFrame(()=>requestAnimationFrame(()=>{k.track=n,Qe(),Zh(n),mn=null,Se("loading",!1),t()}))}function xp(n){return[ke[k.dog].id,...ue.rivals.map(i=>ke[i].id)].map(i=>({b:ke.find(s=>s.id===i),p:ue.pts[i]||0})).sort((i,s)=>s.p-i.p).map((i,s)=>`<tr class="${i.b.id===ke[k.dog].id?"me":""}"><td class="disp">${s+1}\xBA</td><td><i style="background:${i.b.color}"></i></td><td>${i.b.name}${i.b.id===ke[k.dog].id?" \xB7 VOC\xCA":""}</td><td class="mono">${i.p} pts</td></tr>`).join("")}function IM(n){let t=["#ffc53d","#d7dde6","#cd7f32"][n-1]||"#555b66",e=["#b8860b","#9aa3ae","#8b5a2b"][n-1]||"#333";return`<svg viewBox="0 0 120 140" role="img" aria-label="trof\xE9u"><path fill="${e}" d="M22 20h-14c0 22 10 34 26 36l2-8c-9-2-14-11-14-20zm76 0h14c0 22-10 34-26 36l-2-8c9-2 14-11 14-20z"/>
    <path fill="${t}" d="M24 10h72v26c0 24-16 40-36 42-20-2-36-18-36-42z"/><rect x="52" y="76" width="16" height="22" fill="${e}"/>
    <rect x="34" y="96" width="52" height="12" rx="3" fill="${t}"/><rect x="26" y="108" width="68" height="18" rx="4" fill="${e}"/>
    <text x="60" y="52" text-anchor="middle" font-family="Russo One, Arial Black, sans-serif" font-size="26" fill="${e}">${n<=3?n+"\xBA":""}</text></svg>`}function LM(){let e=[ke[k.dog].id,...ue.rivals.map(a=>ke[a].id)].map(a=>({id:a,p:ue.pts[a]||0})).sort((a,o)=>o.p-a.p).findIndex(a=>a.id===ke[k.dog].id)+1,i=Math.round(CM[e-1]*es[k.diff].reward);k.coins+=i,e===1&&(Yn("cups"),k.diff===2&&Yn("cupsHard"));let s=k.trophies[k.diff];(!s||e<s)&&(k.trophies[k.diff]=e);let r=Ua(!0);Qe(),Ur(),ft("cupTitle").textContent=e===1?"CAMPE\xC3O DA COPA!":e<=3?`${e}\xBA LUGAR NA COPA`:`${e}\xBA LUGAR`,ft("trophy").innerHTML=IM(e),ft("cupTable").innerHTML=xp(),ft("cupReward").innerHTML=(i?`PR\xCAMIO DA COPA +${i}`:"SEM PR\xCAMIO DESTA VEZ")+r.map(([a,o])=>`<br>${a.toUpperCase()} +${o}`).join(""),Se("results",!1),Se("cupEnd",!0),e===1&&(Ct.fanfare(),On([60,40,60,40,140]))}function yp(){ue=null,Se("cupEnd",!1),mi()}function au(){return pe.slice().sort((n,t)=>n.finished&&t.finished?n.finishTime-t.finishTime:n.finished?-1:t.finished?1:t.dist-n.dist)}function DM(){let n=au().indexOf(at)+1;Bt="finished",Oi=0,Ct.fanfare(),Ra=1.3,tu(n===1?"VIT\xD3RIA!":"CHEGADA!",3800,`${n}\xBA LUGAR \xB7 ${Lr(at.finishTime)}`),Us(n===1?`Vit\xF3ria! ${at.b.name} vence a corrida!`:`${at.b.name} cruza a linha em ${Lh[n]} lugar!`,!0),setTimeout(()=>at&&Ct.voice(at.b),700)}function _p(){Bt="results",ft("big").innerHTML="",["hud","touch","lights"].forEach(d=>Se(d,!1)),ou(0,0),["wind","skid","nitro"].forEach(d=>Ct.setLoop(d,0));let n=au(),t=n.indexOf(at)+1;ft("resTitle").textContent=t===1?"CAMPE\xC3O!":t<=3?"P\xD3DIO!":`${t}\xBA LUGAR`,ft("resTable").innerHTML=n.map((d,p)=>`<tr class="${d===at?"me":""}"><td class="disp">${p+1}\xBA</td><td><i style="background:${d.b.color}"></i></td><td>${d.b.name}${d===at?" \xB7 VOC\xCA":""}</td><td class="mono">${d.finished?Lr(d.finishTime):"\u2014"}</td></tr>`).join("");let e={1:.5,3:1,5:1.5,7:2}[k.laps]||1,i=Math.round([500,350,250,180,130,100][t-1]*e*es[k.diff].reward),s=at.coins*15,r=Math.round(at.driftScore/20);for(let d of pi)d.g.final&&!d.done&&(d.done=d.g.ok(at,t));let a=pi.filter(d=>d.done).length,o=a*iu;su(),AM(t);let c=[...mp(),...Ua(!0)],l=c.reduce((d,p)=>d+p[1],0),h=i+s+r+o+l;k.coins+=h-l,t===1&&On([60,40,60,40,120]),ue&&(n.forEach((d,p)=>{ue.pts[d.b.id]=(ue.pts[d.b.id]||0)+RM[p]}),ft("cupMid").innerHTML=`<tr><td colspan="4" class="lbl">COPA \xB7 CORRIDA ${ue.idx+1} DE ${ue.tracks.length}</td></tr>`+xp()),Se("cupPanel",!!ue),ft("resAgain").textContent=ue?ue.idx<ue.tracks.length-1?"PR\xD3XIMA PISTA":"VER TROF\xC9U":"DE NOVO",ft("resMenu").textContent=ue?"SAIR DA COPA":"MENU",Se("resGarage",!ue),ft("rewards").innerHTML=`<div><span>${t}\xBA lugar</span><b>+${i}</b></div><div><span>Ossos de ouro \xD7 ${at.coins}</span><b>+${s}</b></div><div><span>Drift (${at.driftScore} pts)</span><b>+${r}</b></div><div><span>Desafios ${a}/${pi.length}</span><b>+${o}</b></div>`+c.map(([d,p])=>`<div><span>${d}</span><b>+${p}</b></div>`).join("")+`<div class="goalsRes">${pi.map(d=>fp(d)).join("")}</div><div class="tot"><span>TOTAL</span><b class="disp">+${h}</b></div>`;let u=yt.id+"_"+k.laps,f=k.best[u];at.finished&&(!f||at.finishTime<f)?(k.best[u]=at.finishTime,ft("recordMsg").textContent="NOVO RECORDE DA PISTA!"):ft("recordMsg").textContent=f?"RECORDE "+Lr(f):"",Qe(),Ur(),Se("results",!0)}function Dr(n){n&&(Bt==="race"||Bt==="countdown"||Bt==="finished")?(Rd=Bt,Bt="paused",Se("pause",!0),ns(),Rn.volume=.25,Ct.ctx&&["wind","skid","nitro"].forEach(t=>Ct.setLoop(t,0))):!n&&Bt==="paused"&&(Bt=Rd,Se("pause",!1),Rn.volume=.6)}function ns(){ft("camBtn").textContent="C\xC2MERA: "+Qh[k.cam],ft("assistBtn").textContent="ASSIST\xCANCIA: "+(k.assist?"LIGADA":"DESLIGADA"),ft("qualBtn").textContent="GR\xC1FICOS: "+zh[k.qual].n,ft("vibBtn").textContent="VIBRA\xC7\xC3O: "+(k.vib?"LIGADA":"DESLIGADA"),ft("voiceBtn").textContent="LOCUTOR: "+(k.voice?"LIGADO":"DESLIGADO"),ft("musicBtn").textContent="M\xDASICA: "+jh[k.musicMode]}var UM=ft("map").getContext("2d");function OM(){let n=ft("map"),t=Math.min(devicePixelRatio,2),e=Math.round(n.clientWidth*t);n.width!==e&&(n.width=n.height=e);let i=UM;i.setTransform(1,0,0,1,0,0),i.clearRect(0,0,e,e),i.save(),i.scale(e/256,e/256),i.drawImage(Sh.canvas,0,0);for(let s of pe.slice().sort(r=>r.isPlayer?1:-1)){let[r,a]=Sh.f(s.x,s.z),o=s.isPlayer?9:7;i.beginPath(),i.arc(r,a,o,0,7),i.fillStyle="#000",i.fill(),i.beginPath(),i.arc(r,a,o-2.5,0,7),i.fillStyle=s.isPlayer?"#ffffff":s.b.color,i.fill()}i.restore()}var NM=ft("gauge").getContext("2d");function FM(){let n=ft("gauge"),t=Math.min(devicePixelRatio,2),e=Math.round(n.clientWidth*t);n.width!==e&&(n.width=n.height=e);let i=NM;i.setTransform(1,0,0,1,0,0),i.clearRect(0,0,e,e),i.save(),i.scale(e/220,e/220);let s=110,r=112,a=Math.PI*.75,o=Math.PI*2.25;i.fillStyle="rgba(10,14,24,.62)",i.beginPath(),i.arc(s,r,104,0,7),i.fill(),i.strokeStyle="rgba(255,255,255,.16)",i.lineWidth=1,i.stroke();let c=Math.abs(at.speed)*aM,l=ce(c/180,0,1);for(let u=0;u<=9;u++){let f=a+(o-a)*u/9,d=u%3?88:84;i.strokeStyle=u/9<=l?"#fff":"rgba(255,255,255,.35)",i.lineWidth=u%3?2:3,i.beginPath(),i.moveTo(s+Math.cos(f)*94,r+Math.sin(f)*94),i.lineTo(s+Math.cos(f)*d,r+Math.sin(f)*d),i.stroke()}i.lineCap="round",i.lineWidth=10,i.strokeStyle="rgba(255,255,255,.1)",i.beginPath(),i.arc(s,r,76,a,o),i.stroke();let h=i.createLinearGradient(20,0,200,0);h.addColorStop(0,"#ffffff"),h.addColorStop(.7,"#ffb36b"),h.addColorStop(1,"#ff4d1a"),i.strokeStyle=h,i.beginPath(),i.arc(s,r,76,a,a+(o-a)*Math.max(.001,l)),i.stroke(),i.lineWidth=7,i.strokeStyle="rgba(255,255,255,.1)",i.beginPath(),i.arc(s,r,61,a,o),i.stroke(),i.strokeStyle=at.nitroOn?"#35d0ff":"#ff7a1a",i.beginPath(),i.arc(s,r,61,a,a+(o-a)*Math.max(.001,at.nitro/100)),i.stroke(),i.fillStyle="#fff",i.textAlign="center",i.font='46px "Russo One", sans-serif',i.fillText(Math.round(c),s,r+12),i.font="700 14px Rajdhani, sans-serif",i.fillStyle="#9aa7bf",i.fillText("KM/H",s,r+32),i.fillStyle=at.nitro>99?"#35d0ff":"#ff9a4d",i.fillText(`NITRO ${Math.round(at.nitro)}%`,s,r+52);for(let u=0;u<3;u++){let f=s-24+u*24,d=r+66;i.fillStyle=u<at.ammo?"#ff4d5e":"rgba(255,255,255,.15)",i.beginPath(),i.moveTo(f,d-9),i.lineTo(f+5,d-3),i.lineTo(f+5,d+8),i.lineTo(f-5,d+8),i.lineTo(f-5,d-3),i.closePath(),i.fill()}if(at.drifting){let u=at.driftT>2?2:at.driftT>.9?1:0;i.fillStyle=["#ffd97a","#35d0ff","#ff5ae0"][u],i.font='17px "Russo One", sans-serif',i.fillText("DRIFT",s,r-34)}else at.barkCD<=0&&(i.fillStyle="#ffc53d",i.font="700 13px Rajdhani, sans-serif",i.fillText("LATIDO PRONTO",s,r-34));i.restore()}var Pd="",mc=0,gc=0,rc=null,_a=0,Nh=!1;function ii(n,t){if(!at||gc>0&&!t)return;let e=ft("narr");e.textContent=n,e.classList.add("on"),mc=3,gc=t?1.4:2.8,Us(n,t)}function zM(n,t){if(mc-=t,gc-=t,mc<=0&&ft("narr").classList.remove("on"),Bt!=="race"||Nn<3){rc=n[0],_a=n.indexOf(at);return}let e=n[0],i=n.indexOf(at);e!==rc&&!e.finished?e.isPlayer?ii("VOC\xCA EST\xC1 NA LIDERAN\xC7A!",!0):ii(`${e.b.name} ASSUMIU A LIDERAN\xC7A!`,!0):i<_a&&n[i+1]?ii(`VOC\xCA ULTRAPASSOU ${n[i+1].b.name}!`):i>_a&&n[i-1]&&!n[i-1].finished&&ii(`${n[i-1].b.name} ULTRAPASSOU VOC\xCA!`),!Nh&&e.finished&&(Nh=!0,e.isPlayer||ii(`${e.b.name} VENCEU A CORRIDA!`,!0)),rc=e,_a=i}function Id(n){let t=au(),e=t.indexOf(at)+1;ft("lap").textContent=at.lap,ft("time").textContent=Lr(Bt==="finished"?at.finishTime:Nn),ft("pos").innerHTML=e+"<sup>\xBA</sup>";let i=t.map((a,o)=>`<li class="${a.isPlayer?"me":""}"><span class="n">${o+1}</span><i style="background:${a.b.color}"></i>${a.b.name}</li>`).join("");i!==Pd&&(ft("board").innerHTML=i,Pd=i),zM(t,n),ft("chipSlip").hidden=!(at.slip>.5);let s=si[at.idx].x*Math.sin(at.h)+si[at.idx].z*Math.cos(at.h)<-.3&&Math.hypot(at.vx,at.vz)>3;at.wrongT=s?at.wrongT+n:0,ft("chipWrong").hidden=at.wrongT<1,at.lockT-=n,ft("chipMissile").hidden=!(at.lockT>0),at.lockT>0&&Math.random()<n*6&&Ct.lockon(),ft("tMn").textContent=at.ammo,OM(),FM();let r=ft("topStack").getBoundingClientRect();ft("pops").style.top=Math.round(r.bottom+6)+"px"}var Ld=ft("fx"),BM=ft("vig");function ou(n,t){Ld.style.opacity=n,BM.style.opacity=t,n>0&&(Ld.style.transform=`rotate(${Math.random()*6}deg)`)}var Pa={},Ia={left:!1,right:!1,brake:!1,drift:!1,nitro:!1,jump:!1,bark:!1,fire:!1};addEventListener("keydown",n=>{["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space","Enter"].includes(n.code)&&n.preventDefault(),Pa[n.code]=!0,!n.repeat&&(Ct.init(),Bt==="menu"?((n.code==="ArrowLeft"||n.code==="KeyA")&&xc(-1),(n.code==="ArrowRight"||n.code==="KeyD")&&xc(1),(n.code==="Enter"||n.code==="Space")&&Os(),n.code==="KeyG"&&dc(),n.code==="KeyT"&&up((k.track+1)%Ns.length)):Bt==="garage"||Bt==="shop"||Bt==="missions"?(n.code==="Escape"||n.code==="Enter")&&mi():Bt==="results"?ft("cupEnd").hidden?((n.code==="Enter"||n.code==="Space")&&vp(),n.code==="Escape"&&(ue=null,mi()),n.code==="KeyG"&&!ue&&dc()):["Enter","Space","Escape"].includes(n.code)&&yp():Bt==="paused"?((n.code==="Escape"||n.code==="KeyP")&&Dr(!1),n.code==="KeyQ"&&mi()):(Bt==="race"||Bt==="countdown"||Bt==="finished")&&(n.code==="Escape"||n.code==="KeyP")&&Dr(!0),n.code==="KeyC"&&(k.cam=(k.cam+1)%Qh.length,Qe()),n.code==="KeyM"&&(ep(),Bt==="paused"&&ns()))});addEventListener("keyup",n=>{Pa[n.code]=!1});addEventListener("blur",()=>{for(let n in Pa)Pa[n]=!1;for(let n in Ia)Ia[n]=!1;Dr(!0)});document.addEventListener("visibilitychange",()=>{document.hidden&&Dr(!0)});function is(n,t){let e=ft(n),i=r=>{r.preventDefault(),Ct.init(),Ia[t]=!0,e.classList.add("on");try{e.setPointerCapture(r.pointerId)}catch{}},s=r=>{r.preventDefault(),Ia[t]=!1,e.classList.remove("on")};e.addEventListener("pointerdown",i),e.addEventListener("pointerup",s),e.addEventListener("pointercancel",s),e.addEventListener("contextmenu",r=>r.preventDefault())}is("tL","left");is("tR","right");is("tS","brake");is("tD","drift");is("tN","nitro");is("tJ","jump");is("tB","bark");is("tM","fire");var Te=(n,t)=>ft(n).addEventListener("click",e=>{e.stopPropagation(),e.currentTarget.blur(),Ct.init(),t()});function xc(n){k.dog=(k.dog+n+ke.length)%ke.length,Qe(),Ac(),Or(),Ct.voice(ke[k.dog],.8)}Te("prevDog",()=>xc(-1));Te("nextDog",()=>xc(1));Te("trackBtn",()=>up((k.track+1)%Ns.length));Te("diffBtn",()=>{k.diff=(k.diff+1)%es.length,Qe(),Or(),Ct.beep(!1)});Te("lapsBtn",()=>{k.laps=k.laps>=7?1:k.laps+2,Qe(),Or(),Ct.beep(!1)});Te("garageBtn",dc);Te("garageBack",mi);Te("startBtn",()=>k.mode?PM():Os());Te("modeBtn",()=>{k.mode=1-k.mode,Qe(),Or(),Ct.beep(!1)});Te("shopBtn",EM);Te("shopBack",()=>{Ua(),mi()});Te("missBtn",SM);Te("missBack",mi);Te("pauseBtn",()=>Dr(!0));Te("resumeBtn",()=>Dr(!1));Te("restartBtn",()=>{Se("pause",!1),Os()});Te("quitBtn",()=>{ue=null,mi()});Te("voiceBtn",()=>{k.voice=!k.voice,Qe(),ns(),k.voice?Us("Locutor ligado!",!0):wc.stop()});Te("vibBtn",()=>{k.vib=!k.vib,Qe(),ns(),On(40)});Te("camBtn",()=>{k.cam=(k.cam+1)%Qh.length,Qe(),ns()});Te("assistBtn",()=>{k.assist=!k.assist,Qe(),ns()});Te("qualBtn",()=>{k.qual=(k.qual+1)%zh.length,Qe(),Nd(),ns()});Te("musicBtn",()=>{ep(),ns()});Te("resAgain",vp);function vp(){if(!ue)return Os();ue.idx<ue.tracks.length-1?(ue.idx++,gp(ue.tracks[ue.idx],Os)):LM()}Te("resMenu",()=>{ue=null,mi()});Te("cupDone",yp);Te("resGarage",dc);function Dd(){let n=Pa,t=Ia,e=n.ArrowLeft||n.KeyA||t.left,i=n.ArrowRight||n.KeyD||t.right,s=!!(n.ArrowDown||n.KeyS||t.brake);return{throttle:n.ArrowUp||n.KeyW||La&&!s?1:0,brake:s,steer:(i?1:0)-(e?1:0),drift:!!(n.ShiftLeft||n.ShiftRight||t.drift),nitro:!!(n.KeyN||n.ControlLeft||n.ControlRight||t.nitro),jump:!!(n.Space||t.jump),bark:!!(n.KeyB||n.KeyE||t.bark),fire:!!(n.KeyF||n.KeyX||t.fire)}}var HM=new $o;function Mp(){requestAnimationFrame(Mp);let n=Math.min(HM.getDelta(),.05);if(Un+=n,Bt!=="paused"){for(let e of qh)e.position.x+=n*2,e.position.x>950&&(e.position.x=-950);for(let e of Ca)e.g.rotation.y+=n*1.5,e.g.position.y=1.1+Math.sin(Un*3+e.s)*.12,e.cd>0&&(e.cd-=n,e.cd<=0&&(e.g.visible=!0));for(let e of Ar)e.g.rotation.y+=n*2,e.g.position.y=1.3+Math.sin(Un*3+e.s)*.15,e.cd>0&&(e.cd-=n,e.cd<=0&&(e.g.visible=!0));for(let e of Aa)e.g.rotation.y+=n*3;for(let e of ts)if(e.fall>0){e.fall=Math.max(0,e.fall-n*.5);let i=Ot(0,.25,1-e.fall)*(e.fall>.1?1:e.fall*10);e.bar.rotation.x=i*1.4,e.bar.position.y=.95-i*.8}if(Ea&&(Ea.offset.y-=n*1.5),Kh(Un),jd(n,Bt==="race"),(Bt==="race"||Bt==="finished"||Bt==="results")&&cp(n),wr&&(wr.offset.x+=n*.01,wr.offset.y+=n*.006),Vv(Un),Ra=Fe(Ra,.35,n*.25),oi.update(n),bn.update(n),Ui){let e=Ui.geometry.attributes.position,i=e.array,s=ye.position;for(let r=0;r<i.length;r+=3)i[r+1]-=n*(3+r%7*.3),i[r]+=Math.sin(Un+r)*n*.5,i[r+1]<s.y-15&&(i[r+1]+=40),i[r]<s.x-60&&(i[r]+=120),i[r]>s.x+60&&(i[r]-=120),i[r+2]<s.z-60&&(i[r+2]+=120),i[r+2]>s.z+60&&(i[r+2]-=120);e.needsUpdate=!0}}if(Bt==="menu"||Bt==="garage"||Bt==="shop"||Bt==="missions"){if(Mr+=n*.35,Ye&&mn){mn.rotation.y+=n*.4,Ye.root.rotation.y=mn.rotation.y,Ye.anim(Ye,{v:0,y:0,vy:0,phase:0,yawRate:0,stun:0,spook:0,nitro:!1,idle:!0},Un);let e=Ye.root.position,i=innerWidth,s=innerHeight,r=s>i*1.05,a=r?8.2:6.4;ye.position.set(e.x+Math.cos(Mr*.4)*a,2.4,e.z+Math.sin(Mr*.4)*a),ye.lookAt(e.x,1.1,e.z),ye.fov=50,r?ye.setViewOffset(i,s,0,s*.14,i,s):i>820?ye.setViewOffset(i,s,Math.min(220,i*.18),0,i,s):ye.clearViewOffset(),ye.updateProjectionMatrix()}}else if(Bt==="countdown"){Ta-=n;let e=Math.ceil(Ta-1);if(!La){let i=Dd();i.throttle&&at.pressT===null&&(at.pressT=Ta),i.throttle||(at.pressT=null)}if(e!==Ih){Ih=e;let i=ft("lights").querySelectorAll("span");e>0&&e<=3&&(i[3-e].className="r",bh(4-e,!1),Ct.beep(!1)),e<=0&&(i.forEach(s=>s.className="g"),bh(3,!0),Ct.beep(!0),tu("VAI!",900),Bt="race",Us("Valendo!",!0),setTimeout(()=>Se("lights",!1),900),at.pressT!==null&&(at.pressT<=.6?(at.mini=1.2,he("LARGADA PERFEITA!","v"),Ct.boost(),On(40),Us("Largada perfeita!",!0)):at.pressT>1.4&&(at.stun=.7,he("QUEIMOU A LARGADA!","r"))),pe.forEach(s=>{!s.isPlayer&&Math.random()<.35&&(s.mini=.8)}))}pe.forEach(ba),Ph(at,n),Id(n)}else if(Bt==="race"||Bt==="finished"){Nn+=n;for(let e of pe)Rh(e,e.isPlayer&&!e.finished?Dd():Ch(e,n),n);sp(n);for(let e of pe)ba(e),gM(e,n);if(Bt==="finished"){Oi+=n;let e=at.D.root.position,i=Oi*.45+at.h+Math.PI;Ii.set(e.x+Math.sin(i)*8,3.2,e.z+Math.cos(i)*8),ye.position.lerp(Ii,1-Math.exp(-3*n)),ye.lookAt(e.x,1.3+at.y,e.z),(Oi>7||Oi>3.5&&pe.every(s=>s.finished))&&_p()}else Ph(at,n);if(Bt!=="results"){Id(n),dp(n);let e=Math.hypot(at.vx,at.vz);ou(at.nitroOn?.55:at.pad>0||at.mini>0?.3:ce((e-40)/40,0,.18),at.nitroOn?1:0),Ct.ctx&&(Ct.setLoop("wind",ce(e/60,0,1)*.12,700+e*30),Ct.setLoop("skid",at.drifting&&!at.air?.16:at.surf==="ice"&&Math.abs(at.slide)>3?.08:0),Ct.setLoop("nitro",at.nitroOn?.3:0))}}else if(Bt==="results"){for(let i of pe)Rh(i,Ch(i,n),n),ba(i);let e=at.D.root.position;Mr+=n*.3,Ii.set(e.x+Math.cos(Mr)*12,6,e.z+Math.sin(Mr)*12),ye.position.lerp(Ii,1-Math.exp(-2*n)),ye.lookAt(e.x,1,e.z)}yc.position.copy(ye.position);let t=at?at.D.root.position:Ye?Ye.root.position:qe[0];Sn.target.position.copy(t),Sn.position.copy(t).addScaledVector(yh,150),qn.render(rn,ye)}Nd();Yv();Zh(k.track);mi();Se("loading",!1);Mp();function kM(n,t){let e=.016666666666666666;for(let i=0;i<n&&(Bt==="race"||Bt==="finished");i+=e){Nn+=e,Un+=e,Kh(Un),jd(e,Bt==="race"),cp(e);for(let s of pe)Rh(s,s.isPlayer&&!s.finished?t(at,Nn):Ch(s,e),e);sp(e),Bt==="race"&&dp(e),Bt==="finished"&&(Oi+=e,(Oi>7||Oi>3.5&&pe.every(s=>s.finished))&&_p())}pe.forEach(ba)}window.__game={sim:kM,bgm:Rn,debugBall(){let n=Pr[0];Kh(n.period-n.off+1.4-n.period*50);let t=He(n.s-14,-4,3.5),e=He(n.s,0,1);ye.position.copy(t),ye.lookAt(e)},skipCountdown(){Ta=.01},get state(){return Bt},get player(){return at},get runners(){return pe},startRace:Os,save:k,renderer:qn,scene:rn,camera:ye,get L(){return Ee}};})();
/*! Bundled license information:

three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2023 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
