(()=>{var Xl="160";var up=0,Kh=1,fp=2;var Lf=1,Yl=2,mi=3,ki=0,un=1,He=2;var Fi=0,zi=1,Gi=2,jh=3,Qh=4,dp=5,is=100,pp=101,mp=102,tu=103,eu=104,gp=200,xp=201,_p=202,yp=203,tl=204,el=205,vp=206,Mp=207,Ep=208,Sp=209,bp=210,Tp=211,wp=212,Ap=213,Rp=214,Cp=0,Pp=1,Lp=2,io=3,Ip=4,Dp=5,Up=6,Np=7,If=0,Op=1,Fp=2,Bi=0,zp=1,Bp=2,Hp=3,$l=4,kp=5,Gp=6;var Df=300,er=301,nr=302,nl=303,il=304,zo=306,Wr=1e3,Zn=1001,sl=1002,tn=1003,nu=1004;var vc=1005;var Nn=1006,Vp=1007;var Xr=1008;var Hi=1009,Wp=1010,Xp=1011,ql=1012,Uf=1013,Ni=1014,Oi=1015,Yr=1016,Nf=1017,Of=1018,as=1020,Yp=1021,Jn=1023,$p=1024,qp=1025,os=1026,ir=1027,Zp=1028,Ff=1029,Jp=1030,zf=1031,Bf=1033,Mc=33776,Ec=33777,Sc=33778,bc=33779,iu=35840,su=35841,ru=35842,au=35843,Hf=36196,ou=37492,cu=37496,lu=37808,hu=37809,uu=37810,fu=37811,du=37812,pu=37813,mu=37814,gu=37815,xu=37816,_u=37817,yu=37818,vu=37819,Mu=37820,Eu=37821,Tc=36492,Su=36494,bu=36495,Kp=36283,Tu=36284,wu=36285,Au=36286;var so=2300,ro=2301,wc=2302,Ru=2400,Cu=2401,Pu=2402;var kf=3e3,cs=3001,jp=3200,Qp=3201,Gf=0,t0=1,On="",Ae="srgb",_i="srgb-linear",Zl="display-p3",Bo="display-p3-linear",ao="linear",we="srgb",oo="rec709",co="p3";var Cs=7680;var Lu=519,e0=512,n0=513,i0=514,Vf=515,s0=516,r0=517,a0=518,o0=519,rl=35044,Wf=35048;var Iu="300 es",al=1035,xi=2e3,lo=2001,Vi=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let i=this._listeners;i[t]===void 0&&(i[t]=[]),i[t].indexOf(e)===-1&&i[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let i=this._listeners;return i[t]!==void 0&&i[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let s=this._listeners[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let i=this._listeners[t.type];if(i!==void 0){t.target=this;let s=i.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,t);t.target=null}}},ln=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Du=1234567,Fr=Math.PI/180,$r=180/Math.PI;function ii(){let n=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(ln[n&255]+ln[n>>8&255]+ln[n>>16&255]+ln[n>>24&255]+"-"+ln[t&255]+ln[t>>8&255]+"-"+ln[t>>16&15|64]+ln[t>>24&255]+"-"+ln[e&63|128]+ln[e>>8&255]+"-"+ln[e>>16&255]+ln[e>>24&255]+ln[i&255]+ln[i>>8&255]+ln[i>>16&255]+ln[i>>24&255]).toLowerCase()}function an(n,t,e){return Math.max(t,Math.min(e,n))}function Jl(n,t){return(n%t+t)%t}function c0(n,t,e,i,s){return i+(n-t)*(s-i)/(e-t)}function l0(n,t,e){return n!==t?(e-n)/(t-n):0}function zr(n,t,e){return(1-e)*n+e*t}function h0(n,t,e,i){return zr(n,t,1-Math.exp(-e*i))}function u0(n,t=1){return t-Math.abs(Jl(n,t*2)-t)}function f0(n,t,e){return n<=t?0:n>=e?1:(n=(n-t)/(e-t),n*n*(3-2*n))}function d0(n,t,e){return n<=t?0:n>=e?1:(n=(n-t)/(e-t),n*n*n*(n*(n*6-15)+10))}function p0(n,t){return n+Math.floor(Math.random()*(t-n+1))}function m0(n,t){return n+Math.random()*(t-n)}function g0(n){return n*(.5-Math.random())}function x0(n){n!==void 0&&(Du=n);let t=Du+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function _0(n){return n*Fr}function y0(n){return n*$r}function ol(n){return(n&n-1)===0&&n!==0}function v0(n){return Math.pow(2,Math.ceil(Math.log(n)/Math.LN2))}function ho(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function M0(n,t,e,i,s){let r=Math.cos,a=Math.sin,o=r(e/2),c=a(e/2),l=r((t+i)/2),h=a((t+i)/2),u=r((t-i)/2),f=a((t-i)/2),d=r((i-t)/2),p=a((i-t)/2);switch(s){case"XYX":n.set(o*h,c*u,c*f,o*l);break;case"YZY":n.set(c*f,o*h,c*u,o*l);break;case"ZXZ":n.set(c*u,c*f,o*h,o*l);break;case"XZX":n.set(o*h,c*p,c*d,o*l);break;case"YXY":n.set(c*d,o*h,c*p,o*l);break;case"ZYZ":n.set(c*p,c*d,o*h,o*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function ni(n,t){switch(t.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function xe(n,t){switch(t.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}var Xf={DEG2RAD:Fr,RAD2DEG:$r,generateUUID:ii,clamp:an,euclideanModulo:Jl,mapLinear:c0,inverseLerp:l0,lerp:zr,damp:h0,pingpong:u0,smoothstep:f0,smootherstep:d0,randInt:p0,randFloat:m0,randFloatSpread:g0,seededRandom:x0,degToRad:_0,radToDeg:y0,isPowerOfTwo:ol,ceilPowerOfTwo:v0,floorPowerOfTwo:ho,setQuaternionFromProperEuler:M0,normalize:xe,denormalize:ni},ht=class n{constructor(t=0,e=0){n.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,i=this.y,s=t.elements;return this.x=s[0]*e+s[3]*i+s[6],this.y=s[1]*e+s[4]*i+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let i=this.dot(t)/e;return Math.acos(an(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,i=this.y-t.y;return e*e+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let i=Math.cos(e),s=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*i-a*s+t.x,this.y=r*s+a*i+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},ie=class n{constructor(t,e,i,s,r,a,o,c,l){n.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,i,s,r,a,o,c,l)}set(t,e,i,s,r,a,o,c,l){let h=this.elements;return h[0]=t,h[1]=s,h[2]=o,h[3]=e,h[4]=r,h[5]=c,h[6]=i,h[7]=a,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],this}extractBasis(t,e,i){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let i=t.elements,s=e.elements,r=this.elements,a=i[0],o=i[3],c=i[6],l=i[1],h=i[4],u=i[7],f=i[2],d=i[5],p=i[8],x=s[0],g=s[3],m=s[6],S=s[1],y=s[4],b=s[7],C=s[2],A=s[5],R=s[8];return r[0]=a*x+o*S+c*C,r[3]=a*g+o*y+c*A,r[6]=a*m+o*b+c*R,r[1]=l*x+h*S+u*C,r[4]=l*g+h*y+u*A,r[7]=l*m+h*b+u*R,r[2]=f*x+d*S+p*C,r[5]=f*g+d*y+p*A,r[8]=f*m+d*b+p*R,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8];return e*a*h-e*o*l-i*r*h+i*o*c+s*r*l-s*a*c}invert(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8],u=h*a-o*l,f=o*c-h*r,d=l*r-a*c,p=e*u+i*f+s*d;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let x=1/p;return t[0]=u*x,t[1]=(s*l-h*i)*x,t[2]=(o*i-s*a)*x,t[3]=f*x,t[4]=(h*e-s*c)*x,t[5]=(s*r-o*e)*x,t[6]=d*x,t[7]=(i*c-l*e)*x,t[8]=(a*e-i*r)*x,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,i,s,r,a,o){let c=Math.cos(r),l=Math.sin(r);return this.set(i*c,i*l,-i*(c*a+l*o)+a+t,-s*l,s*c,-s*(-l*a+c*o)+o+e,0,0,1),this}scale(t,e){return this.premultiply(Ac.makeScale(t,e)),this}rotate(t){return this.premultiply(Ac.makeRotation(-t)),this}translate(t,e){return this.premultiply(Ac.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,i,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,i=t.elements;for(let s=0;s<9;s++)if(e[s]!==i[s])return!1;return!0}fromArray(t,e=0){for(let i=0;i<9;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){let i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t}clone(){return new this.constructor().fromArray(this.elements)}},Ac=new ie;function Yf(n){for(let t=n.length-1;t>=0;--t)if(n[t]>=65535)return!0;return!1}function uo(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function E0(){let n=uo("canvas");return n.style.display="block",n}var Uu={};function Br(n){n in Uu||(Uu[n]=!0,console.warn(n))}var Nu=new ie().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Ou=new ie().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),Ta={[_i]:{transfer:ao,primaries:oo,toReference:n=>n,fromReference:n=>n},[Ae]:{transfer:we,primaries:oo,toReference:n=>n.convertSRGBToLinear(),fromReference:n=>n.convertLinearToSRGB()},[Bo]:{transfer:ao,primaries:co,toReference:n=>n.applyMatrix3(Ou),fromReference:n=>n.applyMatrix3(Nu)},[Zl]:{transfer:we,primaries:co,toReference:n=>n.convertSRGBToLinear().applyMatrix3(Ou),fromReference:n=>n.applyMatrix3(Nu).convertLinearToSRGB()}},S0=new Set([_i,Bo]),_e={enabled:!0,_workingColorSpace:_i,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(n){if(!S0.has(n))throw new Error(`Unsupported working color space, "${n}".`);this._workingColorSpace=n},convert:function(n,t,e){if(this.enabled===!1||t===e||!t||!e)return n;let i=Ta[t].toReference,s=Ta[e].fromReference;return s(i(n))},fromWorkingColorSpace:function(n,t){return this.convert(n,this._workingColorSpace,t)},toWorkingColorSpace:function(n,t){return this.convert(n,t,this._workingColorSpace)},getPrimaries:function(n){return Ta[n].primaries},getTransfer:function(n){return n===On?ao:Ta[n].transfer}};function Qs(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function Rc(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}var Ps,fo=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{Ps===void 0&&(Ps=uo("canvas")),Ps.width=t.width,Ps.height=t.height;let i=Ps.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),e=Ps}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=uo("canvas");e.width=t.width,e.height=t.height;let i=e.getContext("2d");i.drawImage(t,0,0,t.width,t.height);let s=i.getImageData(0,0,t.width,t.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=Qs(r[a]/255)*255;return i.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let i=0;i<e.length;i++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[i]=Math.floor(Qs(e[i]/255)*255):e[i]=Qs(e[i]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},b0=0,po=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:b0++}),this.uuid=ii(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let i={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(Cc(s[a].image)):r.push(Cc(s[a]))}else r=Cc(s);i.url=r}return e||(t.images[this.uuid]=i),i}};function Cc(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?fo.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var T0=0,Fn=class n extends Vi{constructor(t=n.DEFAULT_IMAGE,e=n.DEFAULT_MAPPING,i=Zn,s=Zn,r=Nn,a=Xr,o=Jn,c=Hi,l=n.DEFAULT_ANISOTROPY,h=On){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:T0++}),this.uuid=ii(),this.name="",this.source=new po(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=i,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=c,this.offset=new ht(0,0),this.repeat=new ht(1,1),this.center=new ht(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new ie,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(Br("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===cs?Ae:On),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),e||(t.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Df)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Wr:t.x=t.x-Math.floor(t.x);break;case Zn:t.x=t.x<0?0:1;break;case sl:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Wr:t.y=t.y-Math.floor(t.y);break;case Zn:t.y=t.y<0?0:1;break;case sl:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return Br("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===Ae?cs:kf}set encoding(t){Br("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===cs?Ae:On}};Fn.DEFAULT_IMAGE=null;Fn.DEFAULT_MAPPING=Df;Fn.DEFAULT_ANISOTROPY=1;var en=class n{constructor(t=0,e=0,i=0,s=1){n.prototype.isVector4=!0,this.x=t,this.y=e,this.z=i,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,i,s){return this.x=t,this.y=e,this.z=i,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,i=this.y,s=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*i+a[8]*s+a[12]*r,this.y=a[1]*e+a[5]*i+a[9]*s+a[13]*r,this.z=a[2]*e+a[6]*i+a[10]*s+a[14]*r,this.w=a[3]*e+a[7]*i+a[11]*s+a[15]*r,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,i,s,r,c=t.elements,l=c[0],h=c[4],u=c[8],f=c[1],d=c[5],p=c[9],x=c[2],g=c[6],m=c[10];if(Math.abs(h-f)<.01&&Math.abs(u-x)<.01&&Math.abs(p-g)<.01){if(Math.abs(h+f)<.1&&Math.abs(u+x)<.1&&Math.abs(p+g)<.1&&Math.abs(l+d+m-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let y=(l+1)/2,b=(d+1)/2,C=(m+1)/2,A=(h+f)/4,R=(u+x)/4,O=(p+g)/4;return y>b&&y>C?y<.01?(i=0,s=.707106781,r=.707106781):(i=Math.sqrt(y),s=A/i,r=R/i):b>C?b<.01?(i=.707106781,s=0,r=.707106781):(s=Math.sqrt(b),i=A/s,r=O/s):C<.01?(i=.707106781,s=.707106781,r=0):(r=Math.sqrt(C),i=R/r,s=O/r),this.set(i,s,r,e),this}let S=Math.sqrt((g-p)*(g-p)+(u-x)*(u-x)+(f-h)*(f-h));return Math.abs(S)<.001&&(S=1),this.x=(g-p)/S,this.y=(u-x)/S,this.z=(f-h)/S,this.w=Math.acos((l+d+m-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this.w=t.w+(e.w-t.w)*i,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},cl=class extends Vi{constructor(t=1,e=1,i={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new en(0,0,t,e),this.scissorTest=!1,this.viewport=new en(0,0,t,e);let s={width:t,height:e,depth:1};i.encoding!==void 0&&(Br("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===cs?Ae:On),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Nn,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new Fn(s,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(t,e,i=1){(this.width!==t||this.height!==e||this.depth!==i)&&(this.width=t,this.height=e,this.depth=i,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new po(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},yi=class extends cl{constructor(t=1,e=1,i={}){super(t,e,i),this.isWebGLRenderTarget=!0}},mo=class extends Fn{constructor(t=null,e=1,i=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=tn,this.minFilter=tn,this.wrapR=Zn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var ll=class extends Fn{constructor(t=null,e=1,i=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=tn,this.minFilter=tn,this.wrapR=Zn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var si=class{constructor(t=0,e=0,i=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=i,this._w=s}static slerpFlat(t,e,i,s,r,a,o){let c=i[s+0],l=i[s+1],h=i[s+2],u=i[s+3],f=r[a+0],d=r[a+1],p=r[a+2],x=r[a+3];if(o===0){t[e+0]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u;return}if(o===1){t[e+0]=f,t[e+1]=d,t[e+2]=p,t[e+3]=x;return}if(u!==x||c!==f||l!==d||h!==p){let g=1-o,m=c*f+l*d+h*p+u*x,S=m>=0?1:-1,y=1-m*m;if(y>Number.EPSILON){let C=Math.sqrt(y),A=Math.atan2(C,m*S);g=Math.sin(g*A)/C,o=Math.sin(o*A)/C}let b=o*S;if(c=c*g+f*b,l=l*g+d*b,h=h*g+p*b,u=u*g+x*b,g===1-o){let C=1/Math.sqrt(c*c+l*l+h*h+u*u);c*=C,l*=C,h*=C,u*=C}}t[e]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,i,s,r,a){let o=i[s],c=i[s+1],l=i[s+2],h=i[s+3],u=r[a],f=r[a+1],d=r[a+2],p=r[a+3];return t[e]=o*p+h*u+c*d-l*f,t[e+1]=c*p+h*f+l*u-o*d,t[e+2]=l*p+h*d+o*f-c*u,t[e+3]=h*p-o*u-c*f-l*d,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,i,s){return this._x=t,this._y=e,this._z=i,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let i=t._x,s=t._y,r=t._z,a=t._order,o=Math.cos,c=Math.sin,l=o(i/2),h=o(s/2),u=o(r/2),f=c(i/2),d=c(s/2),p=c(r/2);switch(a){case"XYZ":this._x=f*h*u+l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u-f*d*p;break;case"YXZ":this._x=f*h*u+l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u+f*d*p;break;case"ZXY":this._x=f*h*u-l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u-f*d*p;break;case"ZYX":this._x=f*h*u-l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u+f*d*p;break;case"YZX":this._x=f*h*u+l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u-f*d*p;break;case"XZY":this._x=f*h*u-l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u+f*d*p;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let i=e/2,s=Math.sin(i);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,i=e[0],s=e[4],r=e[8],a=e[1],o=e[5],c=e[9],l=e[2],h=e[6],u=e[10],f=i+o+u;if(f>0){let d=.5/Math.sqrt(f+1);this._w=.25/d,this._x=(h-c)*d,this._y=(r-l)*d,this._z=(a-s)*d}else if(i>o&&i>u){let d=2*Math.sqrt(1+i-o-u);this._w=(h-c)/d,this._x=.25*d,this._y=(s+a)/d,this._z=(r+l)/d}else if(o>u){let d=2*Math.sqrt(1+o-i-u);this._w=(r-l)/d,this._x=(s+a)/d,this._y=.25*d,this._z=(c+h)/d}else{let d=2*Math.sqrt(1+u-i-o);this._w=(a-s)/d,this._x=(r+l)/d,this._y=(c+h)/d,this._z=.25*d}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let i=t.dot(e)+1;return i<Number.EPSILON?(i=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=i):(this._x=0,this._y=-t.z,this._z=t.y,this._w=i)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=i),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(an(this.dot(t),-1,1)))}rotateTowards(t,e){let i=this.angleTo(t);if(i===0)return this;let s=Math.min(1,e/i);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let i=t._x,s=t._y,r=t._z,a=t._w,o=e._x,c=e._y,l=e._z,h=e._w;return this._x=i*h+a*o+s*l-r*c,this._y=s*h+a*c+r*o-i*l,this._z=r*h+a*l+i*c-s*o,this._w=a*h-i*o-s*c-r*l,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let i=this._x,s=this._y,r=this._z,a=this._w,o=a*t._w+i*t._x+s*t._y+r*t._z;if(o<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,o=-o):this.copy(t),o>=1)return this._w=a,this._x=i,this._y=s,this._z=r,this;let c=1-o*o;if(c<=Number.EPSILON){let d=1-e;return this._w=d*a+e*this._w,this._x=d*i+e*this._x,this._y=d*s+e*this._y,this._z=d*r+e*this._z,this.normalize(),this}let l=Math.sqrt(c),h=Math.atan2(l,o),u=Math.sin((1-e)*h)/l,f=Math.sin(e*h)/l;return this._w=a*u+this._w*f,this._x=i*u+this._x*f,this._y=s*u+this._y*f,this._z=r*u+this._z*f,this._onChangeCallback(),this}slerpQuaternions(t,e,i){return this.copy(t).slerp(e,i)}random(){let t=Math.random(),e=Math.sqrt(1-t),i=Math.sqrt(t),s=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(e*Math.cos(s),i*Math.sin(r),i*Math.cos(r),e*Math.sin(s))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},P=class n{constructor(t=0,e=0,i=0){n.prototype.isVector3=!0,this.x=t,this.y=e,this.z=i}set(t,e,i){return i===void 0&&(i=this.z),this.x=t,this.y=e,this.z=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Fu.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Fu.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,i=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*i+r[6]*s,this.y=r[1]*e+r[4]*i+r[7]*s,this.z=r[2]*e+r[5]*i+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,i=this.y,s=this.z,r=t.elements,a=1/(r[3]*e+r[7]*i+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*i+r[8]*s+r[12])*a,this.y=(r[1]*e+r[5]*i+r[9]*s+r[13])*a,this.z=(r[2]*e+r[6]*i+r[10]*s+r[14])*a,this}applyQuaternion(t){let e=this.x,i=this.y,s=this.z,r=t.x,a=t.y,o=t.z,c=t.w,l=2*(a*s-o*i),h=2*(o*e-r*s),u=2*(r*i-a*e);return this.x=e+c*l+a*u-o*h,this.y=i+c*h+o*l-r*u,this.z=s+c*u+r*h-a*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,i=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*i+r[8]*s,this.y=r[1]*e+r[5]*i+r[9]*s,this.z=r[2]*e+r[6]*i+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let i=t.x,s=t.y,r=t.z,a=e.x,o=e.y,c=e.z;return this.x=s*c-r*o,this.y=r*a-i*c,this.z=i*o-s*a,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let i=t.dot(this)/e;return this.copy(t).multiplyScalar(i)}projectOnPlane(t){return Pc.copy(this).projectOnVector(t),this.sub(Pc)}reflect(t){return this.sub(Pc.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let i=this.dot(t)/e;return Math.acos(an(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,i=this.y-t.y,s=this.z-t.z;return e*e+i*i+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,i){let s=Math.sin(e)*t;return this.x=s*Math.sin(i),this.y=Math.cos(e)*t,this.z=s*Math.cos(i),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,i){return this.x=t*Math.sin(e),this.y=i,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),i=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=i,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,i=Math.sqrt(1-t**2);return this.x=i*Math.cos(e),this.y=i*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Pc=new P,Fu=new si,zn=class{constructor(t=new P(1/0,1/0,1/0),e=new P(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e+=3)this.expandByPoint(Yn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,i=t.count;e<i;e++)this.expandByPoint(Yn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let i=Yn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(i),this.max.copy(t).add(i),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let i=t.geometry;if(i!==void 0){let r=i.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,Yn):Yn.fromBufferAttribute(r,a),Yn.applyMatrix4(t.matrixWorld),this.expandByPoint(Yn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),wa.copy(t.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),wa.copy(i.boundingBox)),wa.applyMatrix4(t.matrixWorld),this.union(wa)}let s=t.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,Yn),Yn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,i;return t.normal.x>0?(e=t.normal.x*this.min.x,i=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,i=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,i+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,i+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,i+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,i+=t.normal.z*this.min.z),e<=-t.constant&&i>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Rr),Aa.subVectors(this.max,Rr),Ls.subVectors(t.a,Rr),Is.subVectors(t.b,Rr),Ds.subVectors(t.c,Rr),Pi.subVectors(Is,Ls),Li.subVectors(Ds,Is),ji.subVectors(Ls,Ds);let e=[0,-Pi.z,Pi.y,0,-Li.z,Li.y,0,-ji.z,ji.y,Pi.z,0,-Pi.x,Li.z,0,-Li.x,ji.z,0,-ji.x,-Pi.y,Pi.x,0,-Li.y,Li.x,0,-ji.y,ji.x,0];return!Lc(e,Ls,Is,Ds,Aa)||(e=[1,0,0,0,1,0,0,0,1],!Lc(e,Ls,Is,Ds,Aa))?!1:(Ra.crossVectors(Pi,Li),e=[Ra.x,Ra.y,Ra.z],Lc(e,Ls,Is,Ds,Aa))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Yn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Yn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(hi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),hi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),hi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),hi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),hi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),hi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),hi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),hi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(hi),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},hi=[new P,new P,new P,new P,new P,new P,new P,new P],Yn=new P,wa=new zn,Ls=new P,Is=new P,Ds=new P,Pi=new P,Li=new P,ji=new P,Rr=new P,Aa=new P,Ra=new P,Qi=new P;function Lc(n,t,e,i,s){for(let r=0,a=n.length-3;r<=a;r+=3){Qi.fromArray(n,r);let o=s.x*Math.abs(Qi.x)+s.y*Math.abs(Qi.y)+s.z*Math.abs(Qi.z),c=t.dot(Qi),l=e.dot(Qi),h=i.dot(Qi);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>o)return!1}return!0}var w0=new zn,Cr=new P,Ic=new P,Wi=class{constructor(t=new P,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let i=this.center;e!==void 0?i.copy(e):w0.setFromPoints(t).getCenter(i);let s=0;for(let r=0,a=t.length;r<a;r++)s=Math.max(s,i.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let i=this.center.distanceToSquared(t);return e.copy(t),i>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Cr.subVectors(t,this.center);let e=Cr.lengthSq();if(e>this.radius*this.radius){let i=Math.sqrt(e),s=(i-this.radius)*.5;this.center.addScaledVector(Cr,s/i),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Ic.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Cr.copy(t.center).add(Ic)),this.expandByPoint(Cr.copy(t.center).sub(Ic))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},ui=new P,Dc=new P,Ca=new P,Ii=new P,Uc=new P,Pa=new P,Nc=new P,go=class{constructor(t=new P,e=new P(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,ui)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let i=e.dot(this.direction);return i<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=ui.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(ui.copy(this.origin).addScaledVector(this.direction,e),ui.distanceToSquared(t))}distanceSqToSegment(t,e,i,s){Dc.copy(t).add(e).multiplyScalar(.5),Ca.copy(e).sub(t).normalize(),Ii.copy(this.origin).sub(Dc);let r=t.distanceTo(e)*.5,a=-this.direction.dot(Ca),o=Ii.dot(this.direction),c=-Ii.dot(Ca),l=Ii.lengthSq(),h=Math.abs(1-a*a),u,f,d,p;if(h>0)if(u=a*c-o,f=a*o-c,p=r*h,u>=0)if(f>=-p)if(f<=p){let x=1/h;u*=x,f*=x,d=u*(u+a*f+2*o)+f*(a*u+f+2*c)+l}else f=r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;else f=-r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;else f<=-p?(u=Math.max(0,-(-a*r+o)),f=u>0?-r:Math.min(Math.max(-r,-c),r),d=-u*u+f*(f+2*c)+l):f<=p?(u=0,f=Math.min(Math.max(-r,-c),r),d=f*(f+2*c)+l):(u=Math.max(0,-(a*r+o)),f=u>0?r:Math.min(Math.max(-r,-c),r),d=-u*u+f*(f+2*c)+l);else f=a>0?-r:r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;return i&&i.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(Dc).addScaledVector(Ca,f),d}intersectSphere(t,e){ui.subVectors(t.center,this.origin);let i=ui.dot(this.direction),s=ui.dot(ui)-i*i,r=t.radius*t.radius;if(s>r)return null;let a=Math.sqrt(r-s),o=i-a,c=i+a;return c<0?null:o<0?this.at(c,e):this.at(o,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let i=-(this.origin.dot(t.normal)+t.constant)/e;return i>=0?i:null}intersectPlane(t,e){let i=this.distanceToPlane(t);return i===null?null:this.at(i,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let i,s,r,a,o,c,l=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,f=this.origin;return l>=0?(i=(t.min.x-f.x)*l,s=(t.max.x-f.x)*l):(i=(t.max.x-f.x)*l,s=(t.min.x-f.x)*l),h>=0?(r=(t.min.y-f.y)*h,a=(t.max.y-f.y)*h):(r=(t.max.y-f.y)*h,a=(t.min.y-f.y)*h),i>a||r>s||((r>i||isNaN(i))&&(i=r),(a<s||isNaN(s))&&(s=a),u>=0?(o=(t.min.z-f.z)*u,c=(t.max.z-f.z)*u):(o=(t.max.z-f.z)*u,c=(t.min.z-f.z)*u),i>c||o>s)||((o>i||i!==i)&&(i=o),(c<s||s!==s)&&(s=c),s<0)?null:this.at(i>=0?i:s,e)}intersectsBox(t){return this.intersectBox(t,ui)!==null}intersectTriangle(t,e,i,s,r){Uc.subVectors(e,t),Pa.subVectors(i,t),Nc.crossVectors(Uc,Pa);let a=this.direction.dot(Nc),o;if(a>0){if(s)return null;o=1}else if(a<0)o=-1,a=-a;else return null;Ii.subVectors(this.origin,t);let c=o*this.direction.dot(Pa.crossVectors(Ii,Pa));if(c<0)return null;let l=o*this.direction.dot(Uc.cross(Ii));if(l<0||c+l>a)return null;let h=-o*Ii.dot(Nc);return h<0?null:this.at(h/a,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Se=class n{constructor(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g){n.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g)}set(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g){let m=this.elements;return m[0]=t,m[4]=e,m[8]=i,m[12]=s,m[1]=r,m[5]=a,m[9]=o,m[13]=c,m[2]=l,m[6]=h,m[10]=u,m[14]=f,m[3]=d,m[7]=p,m[11]=x,m[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new n().fromArray(this.elements)}copy(t){let e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],e[9]=i[9],e[10]=i[10],e[11]=i[11],e[12]=i[12],e[13]=i[13],e[14]=i[14],e[15]=i[15],this}copyPosition(t){let e=this.elements,i=t.elements;return e[12]=i[12],e[13]=i[13],e[14]=i[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,i){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(t,e,i){return this.set(t.x,e.x,i.x,0,t.y,e.y,i.y,0,t.z,e.z,i.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,i=t.elements,s=1/Us.setFromMatrixColumn(t,0).length(),r=1/Us.setFromMatrixColumn(t,1).length(),a=1/Us.setFromMatrixColumn(t,2).length();return e[0]=i[0]*s,e[1]=i[1]*s,e[2]=i[2]*s,e[3]=0,e[4]=i[4]*r,e[5]=i[5]*r,e[6]=i[6]*r,e[7]=0,e[8]=i[8]*a,e[9]=i[9]*a,e[10]=i[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,i=t.x,s=t.y,r=t.z,a=Math.cos(i),o=Math.sin(i),c=Math.cos(s),l=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){let f=a*h,d=a*u,p=o*h,x=o*u;e[0]=c*h,e[4]=-c*u,e[8]=l,e[1]=d+p*l,e[5]=f-x*l,e[9]=-o*c,e[2]=x-f*l,e[6]=p+d*l,e[10]=a*c}else if(t.order==="YXZ"){let f=c*h,d=c*u,p=l*h,x=l*u;e[0]=f+x*o,e[4]=p*o-d,e[8]=a*l,e[1]=a*u,e[5]=a*h,e[9]=-o,e[2]=d*o-p,e[6]=x+f*o,e[10]=a*c}else if(t.order==="ZXY"){let f=c*h,d=c*u,p=l*h,x=l*u;e[0]=f-x*o,e[4]=-a*u,e[8]=p+d*o,e[1]=d+p*o,e[5]=a*h,e[9]=x-f*o,e[2]=-a*l,e[6]=o,e[10]=a*c}else if(t.order==="ZYX"){let f=a*h,d=a*u,p=o*h,x=o*u;e[0]=c*h,e[4]=p*l-d,e[8]=f*l+x,e[1]=c*u,e[5]=x*l+f,e[9]=d*l-p,e[2]=-l,e[6]=o*c,e[10]=a*c}else if(t.order==="YZX"){let f=a*c,d=a*l,p=o*c,x=o*l;e[0]=c*h,e[4]=x-f*u,e[8]=p*u+d,e[1]=u,e[5]=a*h,e[9]=-o*h,e[2]=-l*h,e[6]=d*u+p,e[10]=f-x*u}else if(t.order==="XZY"){let f=a*c,d=a*l,p=o*c,x=o*l;e[0]=c*h,e[4]=-u,e[8]=l*h,e[1]=f*u+x,e[5]=a*h,e[9]=d*u-p,e[2]=p*u-d,e[6]=o*h,e[10]=x*u+f}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(A0,t,R0)}lookAt(t,e,i){let s=this.elements;return Sn.subVectors(t,e),Sn.lengthSq()===0&&(Sn.z=1),Sn.normalize(),Di.crossVectors(i,Sn),Di.lengthSq()===0&&(Math.abs(i.z)===1?Sn.x+=1e-4:Sn.z+=1e-4,Sn.normalize(),Di.crossVectors(i,Sn)),Di.normalize(),La.crossVectors(Sn,Di),s[0]=Di.x,s[4]=La.x,s[8]=Sn.x,s[1]=Di.y,s[5]=La.y,s[9]=Sn.y,s[2]=Di.z,s[6]=La.z,s[10]=Sn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let i=t.elements,s=e.elements,r=this.elements,a=i[0],o=i[4],c=i[8],l=i[12],h=i[1],u=i[5],f=i[9],d=i[13],p=i[2],x=i[6],g=i[10],m=i[14],S=i[3],y=i[7],b=i[11],C=i[15],A=s[0],R=s[4],O=s[8],E=s[12],M=s[1],U=s[5],H=s[9],rt=s[13],I=s[2],F=s[6],B=s[10],et=s[14],j=s[3],J=s[7],it=s[11],nt=s[15];return r[0]=a*A+o*M+c*I+l*j,r[4]=a*R+o*U+c*F+l*J,r[8]=a*O+o*H+c*B+l*it,r[12]=a*E+o*rt+c*et+l*nt,r[1]=h*A+u*M+f*I+d*j,r[5]=h*R+u*U+f*F+d*J,r[9]=h*O+u*H+f*B+d*it,r[13]=h*E+u*rt+f*et+d*nt,r[2]=p*A+x*M+g*I+m*j,r[6]=p*R+x*U+g*F+m*J,r[10]=p*O+x*H+g*B+m*it,r[14]=p*E+x*rt+g*et+m*nt,r[3]=S*A+y*M+b*I+C*j,r[7]=S*R+y*U+b*F+C*J,r[11]=S*O+y*H+b*B+C*it,r[15]=S*E+y*rt+b*et+C*nt,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],i=t[4],s=t[8],r=t[12],a=t[1],o=t[5],c=t[9],l=t[13],h=t[2],u=t[6],f=t[10],d=t[14],p=t[3],x=t[7],g=t[11],m=t[15];return p*(+r*c*u-s*l*u-r*o*f+i*l*f+s*o*d-i*c*d)+x*(+e*c*d-e*l*f+r*a*f-s*a*d+s*l*h-r*c*h)+g*(+e*l*u-e*o*d-r*a*u+i*a*d+r*o*h-i*l*h)+m*(-s*o*h-e*c*u+e*o*f+s*a*u-i*a*f+i*c*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,i){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=i),this}invert(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8],u=t[9],f=t[10],d=t[11],p=t[12],x=t[13],g=t[14],m=t[15],S=u*g*l-x*f*l+x*c*d-o*g*d-u*c*m+o*f*m,y=p*f*l-h*g*l-p*c*d+a*g*d+h*c*m-a*f*m,b=h*x*l-p*u*l+p*o*d-a*x*d-h*o*m+a*u*m,C=p*u*c-h*x*c-p*o*f+a*x*f+h*o*g-a*u*g,A=e*S+i*y+s*b+r*C;if(A===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let R=1/A;return t[0]=S*R,t[1]=(x*f*r-u*g*r-x*s*d+i*g*d+u*s*m-i*f*m)*R,t[2]=(o*g*r-x*c*r+x*s*l-i*g*l-o*s*m+i*c*m)*R,t[3]=(u*c*r-o*f*r-u*s*l+i*f*l+o*s*d-i*c*d)*R,t[4]=y*R,t[5]=(h*g*r-p*f*r+p*s*d-e*g*d-h*s*m+e*f*m)*R,t[6]=(p*c*r-a*g*r-p*s*l+e*g*l+a*s*m-e*c*m)*R,t[7]=(a*f*r-h*c*r+h*s*l-e*f*l-a*s*d+e*c*d)*R,t[8]=b*R,t[9]=(p*u*r-h*x*r-p*i*d+e*x*d+h*i*m-e*u*m)*R,t[10]=(a*x*r-p*o*r+p*i*l-e*x*l-a*i*m+e*o*m)*R,t[11]=(h*o*r-a*u*r-h*i*l+e*u*l+a*i*d-e*o*d)*R,t[12]=C*R,t[13]=(h*x*s-p*u*s+p*i*f-e*x*f-h*i*g+e*u*g)*R,t[14]=(p*o*s-a*x*s-p*i*c+e*x*c+a*i*g-e*o*g)*R,t[15]=(a*u*s-h*o*s+h*i*c-e*u*c-a*i*f+e*o*f)*R,this}scale(t){let e=this.elements,i=t.x,s=t.y,r=t.z;return e[0]*=i,e[4]*=s,e[8]*=r,e[1]*=i,e[5]*=s,e[9]*=r,e[2]*=i,e[6]*=s,e[10]*=r,e[3]*=i,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],i=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,i,s))}makeTranslation(t,e,i){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,i,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),i=Math.sin(t);return this.set(1,0,0,0,0,e,-i,0,0,i,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,0,i,0,0,1,0,0,-i,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,0,i,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let i=Math.cos(e),s=Math.sin(e),r=1-i,a=t.x,o=t.y,c=t.z,l=r*a,h=r*o;return this.set(l*a+i,l*o-s*c,l*c+s*o,0,l*o+s*c,h*o+i,h*c-s*a,0,l*c-s*o,h*c+s*a,r*c*c+i,0,0,0,0,1),this}makeScale(t,e,i){return this.set(t,0,0,0,0,e,0,0,0,0,i,0,0,0,0,1),this}makeShear(t,e,i,s,r,a){return this.set(1,i,r,0,t,1,a,0,e,s,1,0,0,0,0,1),this}compose(t,e,i){let s=this.elements,r=e._x,a=e._y,o=e._z,c=e._w,l=r+r,h=a+a,u=o+o,f=r*l,d=r*h,p=r*u,x=a*h,g=a*u,m=o*u,S=c*l,y=c*h,b=c*u,C=i.x,A=i.y,R=i.z;return s[0]=(1-(x+m))*C,s[1]=(d+b)*C,s[2]=(p-y)*C,s[3]=0,s[4]=(d-b)*A,s[5]=(1-(f+m))*A,s[6]=(g+S)*A,s[7]=0,s[8]=(p+y)*R,s[9]=(g-S)*R,s[10]=(1-(f+x))*R,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,i){let s=this.elements,r=Us.set(s[0],s[1],s[2]).length(),a=Us.set(s[4],s[5],s[6]).length(),o=Us.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],$n.copy(this);let l=1/r,h=1/a,u=1/o;return $n.elements[0]*=l,$n.elements[1]*=l,$n.elements[2]*=l,$n.elements[4]*=h,$n.elements[5]*=h,$n.elements[6]*=h,$n.elements[8]*=u,$n.elements[9]*=u,$n.elements[10]*=u,e.setFromRotationMatrix($n),i.x=r,i.y=a,i.z=o,this}makePerspective(t,e,i,s,r,a,o=xi){let c=this.elements,l=2*r/(e-t),h=2*r/(i-s),u=(e+t)/(e-t),f=(i+s)/(i-s),d,p;if(o===xi)d=-(a+r)/(a-r),p=-2*a*r/(a-r);else if(o===lo)d=-a/(a-r),p=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=l,c[4]=0,c[8]=u,c[12]=0,c[1]=0,c[5]=h,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=d,c[14]=p,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,i,s,r,a,o=xi){let c=this.elements,l=1/(e-t),h=1/(i-s),u=1/(a-r),f=(e+t)*l,d=(i+s)*h,p,x;if(o===xi)p=(a+r)*u,x=-2*u;else if(o===lo)p=r*u,x=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-f,c[1]=0,c[5]=2*h,c[9]=0,c[13]=-d,c[2]=0,c[6]=0,c[10]=x,c[14]=-p,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){let e=this.elements,i=t.elements;for(let s=0;s<16;s++)if(e[s]!==i[s])return!1;return!0}fromArray(t,e=0){for(let i=0;i<16;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){let i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t[e+9]=i[9],t[e+10]=i[10],t[e+11]=i[11],t[e+12]=i[12],t[e+13]=i[13],t[e+14]=i[14],t[e+15]=i[15],t}},Us=new P,$n=new Se,A0=new P(0,0,0),R0=new P(1,1,1),Di=new P,La=new P,Sn=new P,zu=new Se,Bu=new si,sr=class n{constructor(t=0,e=0,i=0,s=n.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=i,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,i,s=this._order){return this._x=t,this._y=e,this._z=i,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,i=!0){let s=t.elements,r=s[0],a=s[4],o=s[8],c=s[1],l=s[5],h=s[9],u=s[2],f=s[6],d=s[10];switch(e){case"XYZ":this._y=Math.asin(an(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,d),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(f,l),this._z=0);break;case"YXZ":this._x=Math.asin(-an(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,d),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(an(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(-u,d),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-an(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(f,d),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(an(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(o,d));break;case"XZY":this._z=Math.asin(-an(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(f,l),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,d),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,i===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,i){return zu.makeRotationFromQuaternion(t),this.setFromRotationMatrix(zu,e,i)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Bu.setFromEuler(this),this.setFromQuaternion(Bu,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};sr.DEFAULT_ORDER="XYZ";var xo=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},C0=0,Hu=new P,Ns=new si,fi=new Se,Ia=new P,Pr=new P,P0=new P,L0=new si,ku=new P(1,0,0),Gu=new P(0,1,0),Vu=new P(0,0,1),I0={type:"added"},D0={type:"removed"},$e=class n extends Vi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:C0++}),this.uuid=ii(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=n.DEFAULT_UP.clone();let t=new P,e=new sr,i=new si,s=new P(1,1,1);function r(){i.setFromEuler(e,!1)}function a(){e.setFromQuaternion(i,void 0,!1)}e._onChange(r),i._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Se},normalMatrix:{value:new ie}}),this.matrix=new Se,this.matrixWorld=new Se,this.matrixAutoUpdate=n.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=n.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new xo,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Ns.setFromAxisAngle(t,e),this.quaternion.multiply(Ns),this}rotateOnWorldAxis(t,e){return Ns.setFromAxisAngle(t,e),this.quaternion.premultiply(Ns),this}rotateX(t){return this.rotateOnAxis(ku,t)}rotateY(t){return this.rotateOnAxis(Gu,t)}rotateZ(t){return this.rotateOnAxis(Vu,t)}translateOnAxis(t,e){return Hu.copy(t).applyQuaternion(this.quaternion),this.position.add(Hu.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(ku,t)}translateY(t){return this.translateOnAxis(Gu,t)}translateZ(t){return this.translateOnAxis(Vu,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(fi.copy(this.matrixWorld).invert())}lookAt(t,e,i){t.isVector3?Ia.copy(t):Ia.set(t,e,i);let s=this.parent;this.updateWorldMatrix(!0,!1),Pr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?fi.lookAt(Pr,Ia,this.up):fi.lookAt(Ia,Pr,this.up),this.quaternion.setFromRotationMatrix(fi),s&&(fi.extractRotation(s.matrixWorld),Ns.setFromRotationMatrix(fi),this.quaternion.premultiply(Ns.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(I0)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(D0)),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),fi.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),fi.multiply(t.parent.matrixWorld)),t.applyMatrix4(fi),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let i=0,s=this.children.length;i<s;i++){let a=this.children[i].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,i=[]){this[t]===e&&i.push(this);let s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(t,e,i);return i}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Pr,t,P0),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Pr,L0,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let i=0,s=e.length;i<s;i++)e[i].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let i=0,s=e.length;i<s;i++)e[i].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let i=0,s=e.length;i<s;i++){let r=e[i];(r.matrixWorldAutoUpdate===!0||t===!0)&&r.updateMatrixWorld(t)}}updateWorldMatrix(t,e){let i=this.parent;if(t===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){let s=this.children;for(let r=0,a=s.length;r<a;r++){let o=s[r];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(t){let e=t===void 0||typeof t=="string",i={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),s.maxGeometryCount=this._maxGeometryCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let c=o.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){let u=c[l];r(t.shapes,u)}else r(t.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let c=0,l=this.material.length;c<l;c++)o.push(r(t.materials,this.material[c]));s.material=o}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){let c=this.animations[o];s.animations.push(r(t.animations,c))}}if(e){let o=a(t.geometries),c=a(t.materials),l=a(t.textures),h=a(t.images),u=a(t.shapes),f=a(t.skeletons),d=a(t.animations),p=a(t.nodes);o.length>0&&(i.geometries=o),c.length>0&&(i.materials=c),l.length>0&&(i.textures=l),h.length>0&&(i.images=h),u.length>0&&(i.shapes=u),f.length>0&&(i.skeletons=f),d.length>0&&(i.animations=d),p.length>0&&(i.nodes=p)}return i.object=s,i;function a(o){let c=[];for(let l in o){let h=o[l];delete h.metadata,c.push(h)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let i=0;i<t.children.length;i++){let s=t.children[i];this.add(s.clone())}return this}};$e.DEFAULT_UP=new P(0,1,0);$e.DEFAULT_MATRIX_AUTO_UPDATE=!0;$e.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var qn=new P,di=new P,Oc=new P,pi=new P,Os=new P,Fs=new P,Wu=new P,Fc=new P,zc=new P,Bc=new P,Da=!1,rs=class n{constructor(t=new P,e=new P,i=new P){this.a=t,this.b=e,this.c=i}static getNormal(t,e,i,s){s.subVectors(i,e),qn.subVectors(t,e),s.cross(qn);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,i,s,r){qn.subVectors(s,e),di.subVectors(i,e),Oc.subVectors(t,e);let a=qn.dot(qn),o=qn.dot(di),c=qn.dot(Oc),l=di.dot(di),h=di.dot(Oc),u=a*l-o*o;if(u===0)return r.set(0,0,0),null;let f=1/u,d=(l*c-o*h)*f,p=(a*h-o*c)*f;return r.set(1-d-p,p,d)}static containsPoint(t,e,i,s){return this.getBarycoord(t,e,i,s,pi)===null?!1:pi.x>=0&&pi.y>=0&&pi.x+pi.y<=1}static getUV(t,e,i,s,r,a,o,c){return Da===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Da=!0),this.getInterpolation(t,e,i,s,r,a,o,c)}static getInterpolation(t,e,i,s,r,a,o,c){return this.getBarycoord(t,e,i,s,pi)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,pi.x),c.addScaledVector(a,pi.y),c.addScaledVector(o,pi.z),c)}static isFrontFacing(t,e,i,s){return qn.subVectors(i,e),di.subVectors(t,e),qn.cross(di).dot(s)<0}set(t,e,i){return this.a.copy(t),this.b.copy(e),this.c.copy(i),this}setFromPointsAndIndices(t,e,i,s){return this.a.copy(t[e]),this.b.copy(t[i]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,i,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,i),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return qn.subVectors(this.c,this.b),di.subVectors(this.a,this.b),qn.cross(di).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return n.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return n.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,i,s,r){return Da===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Da=!0),n.getInterpolation(t,this.a,this.b,this.c,e,i,s,r)}getInterpolation(t,e,i,s,r){return n.getInterpolation(t,this.a,this.b,this.c,e,i,s,r)}containsPoint(t){return n.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return n.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let i=this.a,s=this.b,r=this.c,a,o;Os.subVectors(s,i),Fs.subVectors(r,i),Fc.subVectors(t,i);let c=Os.dot(Fc),l=Fs.dot(Fc);if(c<=0&&l<=0)return e.copy(i);zc.subVectors(t,s);let h=Os.dot(zc),u=Fs.dot(zc);if(h>=0&&u<=h)return e.copy(s);let f=c*u-h*l;if(f<=0&&c>=0&&h<=0)return a=c/(c-h),e.copy(i).addScaledVector(Os,a);Bc.subVectors(t,r);let d=Os.dot(Bc),p=Fs.dot(Bc);if(p>=0&&d<=p)return e.copy(r);let x=d*l-c*p;if(x<=0&&l>=0&&p<=0)return o=l/(l-p),e.copy(i).addScaledVector(Fs,o);let g=h*p-d*u;if(g<=0&&u-h>=0&&d-p>=0)return Wu.subVectors(r,s),o=(u-h)/(u-h+(d-p)),e.copy(s).addScaledVector(Wu,o);let m=1/(g+x+f);return a=x*m,o=f*m,e.copy(i).addScaledVector(Os,a).addScaledVector(Fs,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},$f={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Ui={h:0,s:0,l:0},Ua={h:0,s:0,l:0};function Hc(n,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?n+(t-n)*6*e:e<1/2?t:e<2/3?n+(t-n)*6*(2/3-e):n}var Ft=class{constructor(t,e,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,i)}set(t,e,i){if(e===void 0&&i===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,i);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Ae){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,_e.toWorkingColorSpace(this,e),this}setRGB(t,e,i,s=_e.workingColorSpace){return this.r=t,this.g=e,this.b=i,_e.toWorkingColorSpace(this,s),this}setHSL(t,e,i,s=_e.workingColorSpace){if(t=Jl(t,1),e=an(e,0,1),i=an(i,0,1),e===0)this.r=this.g=this.b=i;else{let r=i<=.5?i*(1+e):i+e-i*e,a=2*i-r;this.r=Hc(a,r,t+1/3),this.g=Hc(a,r,t),this.b=Hc(a,r,t-1/3)}return _e.toWorkingColorSpace(this,s),this}setStyle(t,e=Ae){function i(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Ae){let i=$f[t.toLowerCase()];return i!==void 0?this.setHex(i,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Qs(t.r),this.g=Qs(t.g),this.b=Qs(t.b),this}copyLinearToSRGB(t){return this.r=Rc(t.r),this.g=Rc(t.g),this.b=Rc(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Ae){return _e.fromWorkingColorSpace(hn.copy(this),t),Math.round(an(hn.r*255,0,255))*65536+Math.round(an(hn.g*255,0,255))*256+Math.round(an(hn.b*255,0,255))}getHexString(t=Ae){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=_e.workingColorSpace){_e.fromWorkingColorSpace(hn.copy(this),e);let i=hn.r,s=hn.g,r=hn.b,a=Math.max(i,s,r),o=Math.min(i,s,r),c,l,h=(o+a)/2;if(o===a)c=0,l=0;else{let u=a-o;switch(l=h<=.5?u/(a+o):u/(2-a-o),a){case i:c=(s-r)/u+(s<r?6:0);break;case s:c=(r-i)/u+2;break;case r:c=(i-s)/u+4;break}c/=6}return t.h=c,t.s=l,t.l=h,t}getRGB(t,e=_e.workingColorSpace){return _e.fromWorkingColorSpace(hn.copy(this),e),t.r=hn.r,t.g=hn.g,t.b=hn.b,t}getStyle(t=Ae){_e.fromWorkingColorSpace(hn.copy(this),t);let e=hn.r,i=hn.g,s=hn.b;return t!==Ae?`color(${t} ${e.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(i*255)},${Math.round(s*255)})`}offsetHSL(t,e,i){return this.getHSL(Ui),this.setHSL(Ui.h+t,Ui.s+e,Ui.l+i)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,i){return this.r=t.r+(e.r-t.r)*i,this.g=t.g+(e.g-t.g)*i,this.b=t.b+(e.b-t.b)*i,this}lerpHSL(t,e){this.getHSL(Ui),t.getHSL(Ua);let i=zr(Ui.h,Ua.h,e),s=zr(Ui.s,Ua.s,e),r=zr(Ui.l,Ua.l,e);return this.setHSL(i,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,i=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*i+r[6]*s,this.g=r[1]*e+r[4]*i+r[7]*s,this.b=r[2]*e+r[5]*i+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},hn=new Ft;Ft.NAMES=$f;var U0=0,vi=class extends Vi{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:U0++}),this.uuid=ii(),this.name="",this.type="Material",this.blending=zi,this.side=ki,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=tl,this.blendDst=el,this.blendEquation=is,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ft(0,0,0),this.blendAlpha=0,this.depthFunc=io,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Lu,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Cs,this.stencilZFail=Cs,this.stencilZPass=Cs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let i=t[e];if(i===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(i):s&&s.isVector3&&i&&i.isVector3?s.copy(i):this[e]=i}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(t).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(t).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(t).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(t).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(t).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==zi&&(i.blending=this.blending),this.side!==ki&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==tl&&(i.blendSrc=this.blendSrc),this.blendDst!==el&&(i.blendDst=this.blendDst),this.blendEquation!==is&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==io&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Lu&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Cs&&(i.stencilFail=this.stencilFail),this.stencilZFail!==Cs&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==Cs&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function s(r){let a=[];for(let o in r){let c=r[o];delete c.metadata,a.push(c)}return a}if(e){let r=s(t.textures),a=s(t.images);r.length>0&&(i.textures=r),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,i=null;if(e!==null){let s=e.length;i=new Array(s);for(let r=0;r!==s;++r)i[r]=e[r].clone()}return this.clippingPlanes=i,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},Bn=class extends vi{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ft(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=If,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var Ge=new P,Na=new ht,Pe=class{constructor(t,e,i=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=i,this.usage=rl,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Oi,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,i){t*=this.itemSize,i*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[i+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,i=this.count;e<i;e++)Na.fromBufferAttribute(this,e),Na.applyMatrix3(t),this.setXY(e,Na.x,Na.y);else if(this.itemSize===3)for(let e=0,i=this.count;e<i;e++)Ge.fromBufferAttribute(this,e),Ge.applyMatrix3(t),this.setXYZ(e,Ge.x,Ge.y,Ge.z);return this}applyMatrix4(t){for(let e=0,i=this.count;e<i;e++)Ge.fromBufferAttribute(this,e),Ge.applyMatrix4(t),this.setXYZ(e,Ge.x,Ge.y,Ge.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)Ge.fromBufferAttribute(this,e),Ge.applyNormalMatrix(t),this.setXYZ(e,Ge.x,Ge.y,Ge.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)Ge.fromBufferAttribute(this,e),Ge.transformDirection(t),this.setXYZ(e,Ge.x,Ge.y,Ge.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let i=this.array[t*this.itemSize+e];return this.normalized&&(i=ni(i,this.array)),i}setComponent(t,e,i){return this.normalized&&(i=xe(i,this.array)),this.array[t*this.itemSize+e]=i,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=ni(e,this.array)),e}setX(t,e){return this.normalized&&(e=xe(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=ni(e,this.array)),e}setY(t,e){return this.normalized&&(e=xe(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=ni(e,this.array)),e}setZ(t,e){return this.normalized&&(e=xe(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=ni(e,this.array)),e}setW(t,e){return this.normalized&&(e=xe(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,i){return t*=this.itemSize,this.normalized&&(e=xe(e,this.array),i=xe(i,this.array)),this.array[t+0]=e,this.array[t+1]=i,this}setXYZ(t,e,i,s){return t*=this.itemSize,this.normalized&&(e=xe(e,this.array),i=xe(i,this.array),s=xe(s,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this}setXYZW(t,e,i,s,r){return t*=this.itemSize,this.normalized&&(e=xe(e,this.array),i=xe(i,this.array),s=xe(s,this.array),r=xe(r,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==rl&&(t.usage=this.usage),t}};var _o=class extends Pe{constructor(t,e,i){super(new Uint16Array(t),e,i)}};var yo=class extends Pe{constructor(t,e,i){super(new Uint32Array(t),e,i)}};var ce=class extends Pe{constructor(t,e,i){super(new Float32Array(t),e,i)}};var N0=0,Un=new Se,kc=new $e,zs=new P,bn=new zn,Lr=new zn,Qe=new P,Ue=class n extends Vi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:N0++}),this.uuid=ii(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Yf(t)?yo:_o)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,i=0){this.groups.push({start:t,count:e,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let i=this.attributes.normal;if(i!==void 0){let r=new ie().getNormalMatrix(t);i.applyNormalMatrix(r),i.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return Un.makeRotationFromQuaternion(t),this.applyMatrix4(Un),this}rotateX(t){return Un.makeRotationX(t),this.applyMatrix4(Un),this}rotateY(t){return Un.makeRotationY(t),this.applyMatrix4(Un),this}rotateZ(t){return Un.makeRotationZ(t),this.applyMatrix4(Un),this}translate(t,e,i){return Un.makeTranslation(t,e,i),this.applyMatrix4(Un),this}scale(t,e,i){return Un.makeScale(t,e,i),this.applyMatrix4(Un),this}lookAt(t){return kc.lookAt(t),kc.updateMatrix(),this.applyMatrix4(kc.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(zs).negate(),this.translate(zs.x,zs.y,zs.z),this}setFromPoints(t){let e=[];for(let i=0,s=t.length;i<s;i++){let r=t[i];e.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new ce(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new zn);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new P(-1/0,-1/0,-1/0),new P(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let i=0,s=e.length;i<s;i++){let r=e[i];bn.setFromBufferAttribute(r),this.morphTargetsRelative?(Qe.addVectors(this.boundingBox.min,bn.min),this.boundingBox.expandByPoint(Qe),Qe.addVectors(this.boundingBox.max,bn.max),this.boundingBox.expandByPoint(Qe)):(this.boundingBox.expandByPoint(bn.min),this.boundingBox.expandByPoint(bn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Wi);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new P,1/0);return}if(t){let i=this.boundingSphere.center;if(bn.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){let o=e[r];Lr.setFromBufferAttribute(o),this.morphTargetsRelative?(Qe.addVectors(bn.min,Lr.min),bn.expandByPoint(Qe),Qe.addVectors(bn.max,Lr.max),bn.expandByPoint(Qe)):(bn.expandByPoint(Lr.min),bn.expandByPoint(Lr.max))}bn.getCenter(i);let s=0;for(let r=0,a=t.count;r<a;r++)Qe.fromBufferAttribute(t,r),s=Math.max(s,i.distanceToSquared(Qe));if(e)for(let r=0,a=e.length;r<a;r++){let o=e[r],c=this.morphTargetsRelative;for(let l=0,h=o.count;l<h;l++)Qe.fromBufferAttribute(o,l),c&&(zs.fromBufferAttribute(t,l),Qe.add(zs)),s=Math.max(s,i.distanceToSquared(Qe))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let i=t.array,s=e.position.array,r=e.normal.array,a=e.uv.array,o=s.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Pe(new Float32Array(4*o),4));let c=this.getAttribute("tangent").array,l=[],h=[];for(let M=0;M<o;M++)l[M]=new P,h[M]=new P;let u=new P,f=new P,d=new P,p=new ht,x=new ht,g=new ht,m=new P,S=new P;function y(M,U,H){u.fromArray(s,M*3),f.fromArray(s,U*3),d.fromArray(s,H*3),p.fromArray(a,M*2),x.fromArray(a,U*2),g.fromArray(a,H*2),f.sub(u),d.sub(u),x.sub(p),g.sub(p);let rt=1/(x.x*g.y-g.x*x.y);isFinite(rt)&&(m.copy(f).multiplyScalar(g.y).addScaledVector(d,-x.y).multiplyScalar(rt),S.copy(d).multiplyScalar(x.x).addScaledVector(f,-g.x).multiplyScalar(rt),l[M].add(m),l[U].add(m),l[H].add(m),h[M].add(S),h[U].add(S),h[H].add(S))}let b=this.groups;b.length===0&&(b=[{start:0,count:i.length}]);for(let M=0,U=b.length;M<U;++M){let H=b[M],rt=H.start,I=H.count;for(let F=rt,B=rt+I;F<B;F+=3)y(i[F+0],i[F+1],i[F+2])}let C=new P,A=new P,R=new P,O=new P;function E(M){R.fromArray(r,M*3),O.copy(R);let U=l[M];C.copy(U),C.sub(R.multiplyScalar(R.dot(U))).normalize(),A.crossVectors(O,U);let rt=A.dot(h[M])<0?-1:1;c[M*4]=C.x,c[M*4+1]=C.y,c[M*4+2]=C.z,c[M*4+3]=rt}for(let M=0,U=b.length;M<U;++M){let H=b[M],rt=H.start,I=H.count;for(let F=rt,B=rt+I;F<B;F+=3)E(i[F+0]),E(i[F+1]),E(i[F+2])}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new Pe(new Float32Array(e.count*3),3),this.setAttribute("normal",i);else for(let f=0,d=i.count;f<d;f++)i.setXYZ(f,0,0,0);let s=new P,r=new P,a=new P,o=new P,c=new P,l=new P,h=new P,u=new P;if(t)for(let f=0,d=t.count;f<d;f+=3){let p=t.getX(f+0),x=t.getX(f+1),g=t.getX(f+2);s.fromBufferAttribute(e,p),r.fromBufferAttribute(e,x),a.fromBufferAttribute(e,g),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),o.fromBufferAttribute(i,p),c.fromBufferAttribute(i,x),l.fromBufferAttribute(i,g),o.add(h),c.add(h),l.add(h),i.setXYZ(p,o.x,o.y,o.z),i.setXYZ(x,c.x,c.y,c.z),i.setXYZ(g,l.x,l.y,l.z)}else for(let f=0,d=e.count;f<d;f+=3)s.fromBufferAttribute(e,f+0),r.fromBufferAttribute(e,f+1),a.fromBufferAttribute(e,f+2),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),i.setXYZ(f+0,h.x,h.y,h.z),i.setXYZ(f+1,h.x,h.y,h.z),i.setXYZ(f+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,i=t.count;e<i;e++)Qe.fromBufferAttribute(t,e),Qe.normalize(),t.setXYZ(e,Qe.x,Qe.y,Qe.z)}toNonIndexed(){function t(o,c){let l=o.array,h=o.itemSize,u=o.normalized,f=new l.constructor(c.length*h),d=0,p=0;for(let x=0,g=c.length;x<g;x++){o.isInterleavedBufferAttribute?d=c[x]*o.data.stride+o.offset:d=c[x]*h;for(let m=0;m<h;m++)f[p++]=l[d++]}return new Pe(f,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new n,i=this.index.array,s=this.attributes;for(let o in s){let c=s[o],l=t(c,i);e.setAttribute(o,l)}let r=this.morphAttributes;for(let o in r){let c=[],l=r[o];for(let h=0,u=l.length;h<u;h++){let f=l[h],d=t(f,i);c.push(d)}e.morphAttributes[o]=c}e.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,c=a.length;o<c;o++){let l=a[o];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let c=this.parameters;for(let l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let i=this.attributes;for(let c in i){let l=i[c];t.data.attributes[c]=l.toJSON(t.data)}let s={},r=!1;for(let c in this.morphAttributes){let l=this.morphAttributes[c],h=[];for(let u=0,f=l.length;u<f;u++){let d=l[u];h.push(d.toJSON(t.data))}h.length>0&&(s[c]=h,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(t.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let i=t.index;i!==null&&this.setIndex(i.clone(e));let s=t.attributes;for(let l in s){let h=s[l];this.setAttribute(l,h.clone(e))}let r=t.morphAttributes;for(let l in r){let h=[],u=r[l];for(let f=0,d=u.length;f<d;f++)h.push(u[f].clone(e));this.morphAttributes[l]=h}this.morphTargetsRelative=t.morphTargetsRelative;let a=t.groups;for(let l=0,h=a.length;l<h;l++){let u=a[l];this.addGroup(u.start,u.count,u.materialIndex)}let o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());let c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},Xu=new Se,ts=new go,Oa=new Wi,Yu=new P,Bs=new P,Hs=new P,ks=new P,Gc=new P,Fa=new P,za=new ht,Ba=new ht,Ha=new ht,$u=new P,qu=new P,Zu=new P,ka=new P,Ga=new P,Ct=class extends $e{constructor(t=new Ue,e=new Bn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){let s=e[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){let o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){let i=this.geometry,s=i.attributes.position,r=i.morphAttributes.position,a=i.morphTargetsRelative;e.fromBufferAttribute(s,t);let o=this.morphTargetInfluences;if(r&&o){Fa.set(0,0,0);for(let c=0,l=r.length;c<l;c++){let h=o[c],u=r[c];h!==0&&(Gc.fromBufferAttribute(u,t),a?Fa.addScaledVector(Gc,h):Fa.addScaledVector(Gc.sub(e),h))}e.add(Fa)}return e}raycast(t,e){let i=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Oa.copy(i.boundingSphere),Oa.applyMatrix4(r),ts.copy(t.ray).recast(t.near),!(Oa.containsPoint(ts.origin)===!1&&(ts.intersectSphere(Oa,Yu)===null||ts.origin.distanceToSquared(Yu)>(t.far-t.near)**2))&&(Xu.copy(r).invert(),ts.copy(t.ray).applyMatrix4(Xu),!(i.boundingBox!==null&&ts.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(t,e,ts)))}_computeIntersections(t,e,i){let s,r=this.geometry,a=this.material,o=r.index,c=r.attributes.position,l=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,f=r.groups,d=r.drawRange;if(o!==null)if(Array.isArray(a))for(let p=0,x=f.length;p<x;p++){let g=f[p],m=a[g.materialIndex],S=Math.max(g.start,d.start),y=Math.min(o.count,Math.min(g.start+g.count,d.start+d.count));for(let b=S,C=y;b<C;b+=3){let A=o.getX(b),R=o.getX(b+1),O=o.getX(b+2);s=Va(this,m,t,i,l,h,u,A,R,O),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let p=Math.max(0,d.start),x=Math.min(o.count,d.start+d.count);for(let g=p,m=x;g<m;g+=3){let S=o.getX(g),y=o.getX(g+1),b=o.getX(g+2);s=Va(this,a,t,i,l,h,u,S,y,b),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}else if(c!==void 0)if(Array.isArray(a))for(let p=0,x=f.length;p<x;p++){let g=f[p],m=a[g.materialIndex],S=Math.max(g.start,d.start),y=Math.min(c.count,Math.min(g.start+g.count,d.start+d.count));for(let b=S,C=y;b<C;b+=3){let A=b,R=b+1,O=b+2;s=Va(this,m,t,i,l,h,u,A,R,O),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let p=Math.max(0,d.start),x=Math.min(c.count,d.start+d.count);for(let g=p,m=x;g<m;g+=3){let S=g,y=g+1,b=g+2;s=Va(this,a,t,i,l,h,u,S,y,b),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}}};function O0(n,t,e,i,s,r,a,o){let c;if(t.side===un?c=i.intersectTriangle(a,r,s,!0,o):c=i.intersectTriangle(s,r,a,t.side===ki,o),c===null)return null;Ga.copy(o),Ga.applyMatrix4(n.matrixWorld);let l=e.ray.origin.distanceTo(Ga);return l<e.near||l>e.far?null:{distance:l,point:Ga.clone(),object:n}}function Va(n,t,e,i,s,r,a,o,c,l){n.getVertexPosition(o,Bs),n.getVertexPosition(c,Hs),n.getVertexPosition(l,ks);let h=O0(n,t,e,i,Bs,Hs,ks,ka);if(h){s&&(za.fromBufferAttribute(s,o),Ba.fromBufferAttribute(s,c),Ha.fromBufferAttribute(s,l),h.uv=rs.getInterpolation(ka,Bs,Hs,ks,za,Ba,Ha,new ht)),r&&(za.fromBufferAttribute(r,o),Ba.fromBufferAttribute(r,c),Ha.fromBufferAttribute(r,l),h.uv1=rs.getInterpolation(ka,Bs,Hs,ks,za,Ba,Ha,new ht),h.uv2=h.uv1),a&&($u.fromBufferAttribute(a,o),qu.fromBufferAttribute(a,c),Zu.fromBufferAttribute(a,l),h.normal=rs.getInterpolation(ka,Bs,Hs,ks,$u,qu,Zu,new P),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));let u={a:o,b:c,c:l,normal:new P,materialIndex:0};rs.getNormal(Bs,Hs,ks,u.normal),h.face=u}return h}var de=class n extends Ue{constructor(t=1,e=1,i=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:i,widthSegments:s,heightSegments:r,depthSegments:a};let o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);let c=[],l=[],h=[],u=[],f=0,d=0;p("z","y","x",-1,-1,i,e,t,a,r,0),p("z","y","x",1,-1,i,e,-t,a,r,1),p("x","z","y",1,1,t,i,e,s,a,2),p("x","z","y",1,-1,t,i,-e,s,a,3),p("x","y","z",1,-1,t,e,i,s,r,4),p("x","y","z",-1,-1,t,e,-i,s,r,5),this.setIndex(c),this.setAttribute("position",new ce(l,3)),this.setAttribute("normal",new ce(h,3)),this.setAttribute("uv",new ce(u,2));function p(x,g,m,S,y,b,C,A,R,O,E){let M=b/R,U=C/O,H=b/2,rt=C/2,I=A/2,F=R+1,B=O+1,et=0,j=0,J=new P;for(let it=0;it<B;it++){let nt=it*U-rt;for(let gt=0;gt<F;gt++){let $=gt*M-H;J[x]=$*S,J[g]=nt*y,J[m]=I,l.push(J.x,J.y,J.z),J[x]=0,J[g]=0,J[m]=A>0?1:-1,h.push(J.x,J.y,J.z),u.push(gt/R),u.push(1-it/O),et+=1}}for(let it=0;it<O;it++)for(let nt=0;nt<R;nt++){let gt=f+nt+F*it,$=f+nt+F*(it+1),Q=f+(nt+1)+F*(it+1),ut=f+(nt+1)+F*it;c.push(gt,$,ut),c.push($,Q,ut),j+=6}o.addGroup(d,j,E),d+=j,f+=et}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function rr(n){let t={};for(let e in n){t[e]={};for(let i in n[e]){let s=n[e][i];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][i]=null):t[e][i]=s.clone():Array.isArray(s)?t[e][i]=s.slice():t[e][i]=s}}return t}function gn(n){let t={};for(let e=0;e<n.length;e++){let i=rr(n[e]);for(let s in i)t[s]=i[s]}return t}function F0(n){let t=[];for(let e=0;e<n.length;e++)t.push(n[e].clone());return t}function qf(n){return n.getRenderTarget()===null?n.outputColorSpace:_e.workingColorSpace}var z0={clone:rr,merge:gn},B0=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,H0=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Hn=class extends vi{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=B0,this.fragmentShader=H0,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=rr(t.uniforms),this.uniformsGroups=F0(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let a=this.uniforms[s].value;a&&a.isTexture?e.uniforms[s]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[s]={type:"m4",value:a.toArray()}:e.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let i={};for(let s in this.extensions)this.extensions[s]===!0&&(i[s]=!0);return Object.keys(i).length>0&&(e.extensions=i),e}},vo=class extends $e{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Se,this.projectionMatrix=new Se,this.projectionMatrixInverse=new Se,this.coordinateSystem=xi}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},xn=class extends vo{constructor(t=50,e=1,i=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=i,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=$r*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(Fr*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return $r*2*Math.atan(Math.tan(Fr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,i,s,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(Fr*.5*this.fov)/this.zoom,i=2*e,s=this.aspect*i,r=-.5*s,a=this.view;if(this.view!==null&&this.view.enabled){let c=a.fullWidth,l=a.fullHeight;r+=a.offsetX*s/c,e-=a.offsetY*i/l,s*=a.width/c,i*=a.height/l}let o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-i,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},Gs=-90,Vs=1,hl=class extends $e{constructor(t,e,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new xn(Gs,Vs,t,e);s.layers=this.layers,this.add(s);let r=new xn(Gs,Vs,t,e);r.layers=this.layers,this.add(r);let a=new xn(Gs,Vs,t,e);a.layers=this.layers,this.add(a);let o=new xn(Gs,Vs,t,e);o.layers=this.layers,this.add(o);let c=new xn(Gs,Vs,t,e);c.layers=this.layers,this.add(c);let l=new xn(Gs,Vs,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[i,s,r,a,o,c]=e;for(let l of e)this.remove(l);if(t===xi)i.up.set(0,1,0),i.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===lo)i.up.set(0,-1,0),i.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:i,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,a,o,c,l,h]=this.children,u=t.getRenderTarget(),f=t.getActiveCubeFace(),d=t.getActiveMipmapLevel(),p=t.xr.enabled;t.xr.enabled=!1;let x=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,t.setRenderTarget(i,0,s),t.render(e,r),t.setRenderTarget(i,1,s),t.render(e,a),t.setRenderTarget(i,2,s),t.render(e,o),t.setRenderTarget(i,3,s),t.render(e,c),t.setRenderTarget(i,4,s),t.render(e,l),i.texture.generateMipmaps=x,t.setRenderTarget(i,5,s),t.render(e,h),t.setRenderTarget(u,f,d),t.xr.enabled=p,i.texture.needsPMREMUpdate=!0}},Mo=class extends Fn{constructor(t,e,i,s,r,a,o,c,l,h){t=t!==void 0?t:[],e=e!==void 0?e:er,super(t,e,i,s,r,a,o,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},ul=class extends yi{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let i={width:t,height:t,depth:1},s=[i,i,i,i,i,i];e.encoding!==void 0&&(Br("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===cs?Ae:On),this.texture=new Mo(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:Nn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new de(5,5,5),r=new Hn({name:"CubemapFromEquirect",uniforms:rr(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:un,blending:Fi});r.uniforms.tEquirect.value=e;let a=new Ct(s,r),o=e.minFilter;return e.minFilter===Xr&&(e.minFilter=Nn),new hl(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,i,s){let r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,i,s);t.setRenderTarget(r)}},Vc=new P,k0=new P,G0=new ie,gi=class{constructor(t=new P(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,i,s){return this.normal.set(t,e,i),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,i){let s=Vc.subVectors(i,e).cross(k0.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let i=t.delta(Vc),s=this.normal.dot(i);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(i,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),i=this.distanceToPoint(t.end);return e<0&&i>0||i<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let i=e||G0.getNormalMatrix(t),s=this.coplanarPoint(Vc).applyMatrix4(t),r=this.normal.applyMatrix3(i).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},es=new Wi,Wa=new P,qr=class{constructor(t=new gi,e=new gi,i=new gi,s=new gi,r=new gi,a=new gi){this.planes=[t,e,i,s,r,a]}set(t,e,i,s,r,a){let o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(i),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(t){let e=this.planes;for(let i=0;i<6;i++)e[i].copy(t.planes[i]);return this}setFromProjectionMatrix(t,e=xi){let i=this.planes,s=t.elements,r=s[0],a=s[1],o=s[2],c=s[3],l=s[4],h=s[5],u=s[6],f=s[7],d=s[8],p=s[9],x=s[10],g=s[11],m=s[12],S=s[13],y=s[14],b=s[15];if(i[0].setComponents(c-r,f-l,g-d,b-m).normalize(),i[1].setComponents(c+r,f+l,g+d,b+m).normalize(),i[2].setComponents(c+a,f+h,g+p,b+S).normalize(),i[3].setComponents(c-a,f-h,g-p,b-S).normalize(),i[4].setComponents(c-o,f-u,g-x,b-y).normalize(),e===xi)i[5].setComponents(c+o,f+u,g+x,b+y).normalize();else if(e===lo)i[5].setComponents(o,u,x,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),es.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),es.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(es)}intersectsSprite(t){return es.center.set(0,0,0),es.radius=.7071067811865476,es.applyMatrix4(t.matrixWorld),this.intersectsSphere(es)}intersectsSphere(t){let e=this.planes,i=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(i)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let i=0;i<6;i++){let s=e[i];if(Wa.x=s.normal.x>0?t.max.x:t.min.x,Wa.y=s.normal.y>0?t.max.y:t.min.y,Wa.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(Wa)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let i=0;i<6;i++)if(e[i].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function Zf(){let n=null,t=!1,e=null,i=null;function s(r,a){e(r,a),i=n.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(i=n.requestAnimationFrame(s),t=!0)},stop:function(){n.cancelAnimationFrame(i),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){n=r}}}function V0(n,t){let e=t.isWebGL2,i=new WeakMap;function s(l,h){let u=l.array,f=l.usage,d=u.byteLength,p=n.createBuffer();n.bindBuffer(h,p),n.bufferData(h,u,f),l.onUploadCallback();let x;if(u instanceof Float32Array)x=n.FLOAT;else if(u instanceof Uint16Array)if(l.isFloat16BufferAttribute)if(e)x=n.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else x=n.UNSIGNED_SHORT;else if(u instanceof Int16Array)x=n.SHORT;else if(u instanceof Uint32Array)x=n.UNSIGNED_INT;else if(u instanceof Int32Array)x=n.INT;else if(u instanceof Int8Array)x=n.BYTE;else if(u instanceof Uint8Array)x=n.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)x=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:p,type:x,bytesPerElement:u.BYTES_PER_ELEMENT,version:l.version,size:d}}function r(l,h,u){let f=h.array,d=h._updateRange,p=h.updateRanges;if(n.bindBuffer(u,l),d.count===-1&&p.length===0&&n.bufferSubData(u,0,f),p.length!==0){for(let x=0,g=p.length;x<g;x++){let m=p[x];e?n.bufferSubData(u,m.start*f.BYTES_PER_ELEMENT,f,m.start,m.count):n.bufferSubData(u,m.start*f.BYTES_PER_ELEMENT,f.subarray(m.start,m.start+m.count))}h.clearUpdateRanges()}d.count!==-1&&(e?n.bufferSubData(u,d.offset*f.BYTES_PER_ELEMENT,f,d.offset,d.count):n.bufferSubData(u,d.offset*f.BYTES_PER_ELEMENT,f.subarray(d.offset,d.offset+d.count)),d.count=-1),h.onUploadCallback()}function a(l){return l.isInterleavedBufferAttribute&&(l=l.data),i.get(l)}function o(l){l.isInterleavedBufferAttribute&&(l=l.data);let h=i.get(l);h&&(n.deleteBuffer(h.buffer),i.delete(l))}function c(l,h){if(l.isGLBufferAttribute){let f=i.get(l);(!f||f.version<l.version)&&i.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}l.isInterleavedBufferAttribute&&(l=l.data);let u=i.get(l);if(u===void 0)i.set(l,s(l,h));else if(u.version<l.version){if(u.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(u.buffer,l,h),u.version=l.version}}return{get:a,remove:o,update:c}}var _n=class n extends Ue{constructor(t=1,e=1,i=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:i,heightSegments:s};let r=t/2,a=e/2,o=Math.floor(i),c=Math.floor(s),l=o+1,h=c+1,u=t/o,f=e/c,d=[],p=[],x=[],g=[];for(let m=0;m<h;m++){let S=m*f-a;for(let y=0;y<l;y++){let b=y*u-r;p.push(b,-S,0),x.push(0,0,1),g.push(y/o),g.push(1-m/c)}}for(let m=0;m<c;m++)for(let S=0;S<o;S++){let y=S+l*m,b=S+l*(m+1),C=S+1+l*(m+1),A=S+1+l*m;d.push(y,b,A),d.push(b,C,A)}this.setIndex(d),this.setAttribute("position",new ce(p,3)),this.setAttribute("normal",new ce(x,3)),this.setAttribute("uv",new ce(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.width,t.height,t.widthSegments,t.heightSegments)}},W0=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,X0=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Y0=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,$0=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,q0=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,Z0=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,J0=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,K0=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,j0=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Q0=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,tm=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,em=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,nm=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,im=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,sm=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,rm=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,am=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,om=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,cm=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,lm=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,hm=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,um=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,fm=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,dm=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,pm=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,mm=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,gm=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,xm=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,_m=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,ym=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,vm="gl_FragColor = linearToOutputTexel( gl_FragColor );",Mm=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Em=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Sm=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,bm=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Tm=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,wm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Am=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Rm=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Cm=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Pm=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Lm=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Im=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,Dm=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Um=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Nm=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Om=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Fm=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,zm=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Bm=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Hm=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,km=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Gm=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Vm=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Wm=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Xm=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Ym=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,$m=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,qm=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Zm=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,Jm=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,Km=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,jm=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Qm=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,tg=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,eg=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,ng=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,ig=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,sg=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,rg=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,ag=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,og=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,cg=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,lg=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,hg=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,ug=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,fg=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,dg=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,pg=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,mg=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,gg=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,xg=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,_g=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,yg=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,vg=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Mg=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Eg=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Sg=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,bg=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Tg=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,wg=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Ag=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Rg=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Cg=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Pg=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Lg=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Ig=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Dg=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Ug=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Ng=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Og=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Fg=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,zg=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Bg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Hg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,kg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Gg=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,Vg=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Wg=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Xg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Yg=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,$g=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,qg=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Zg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Jg=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,Kg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,jg=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Qg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,tx=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ex=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,nx=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,ix=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,sx=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,rx=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ax=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ox=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,cx=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,lx=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,hx=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,ux=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,fx=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,dx=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,px=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,mx=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,gx=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,xx=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,_x=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,yx=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,vx=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Mx=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Ex=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,jt={alphahash_fragment:W0,alphahash_pars_fragment:X0,alphamap_fragment:Y0,alphamap_pars_fragment:$0,alphatest_fragment:q0,alphatest_pars_fragment:Z0,aomap_fragment:J0,aomap_pars_fragment:K0,batching_pars_vertex:j0,batching_vertex:Q0,begin_vertex:tm,beginnormal_vertex:em,bsdfs:nm,iridescence_fragment:im,bumpmap_pars_fragment:sm,clipping_planes_fragment:rm,clipping_planes_pars_fragment:am,clipping_planes_pars_vertex:om,clipping_planes_vertex:cm,color_fragment:lm,color_pars_fragment:hm,color_pars_vertex:um,color_vertex:fm,common:dm,cube_uv_reflection_fragment:pm,defaultnormal_vertex:mm,displacementmap_pars_vertex:gm,displacementmap_vertex:xm,emissivemap_fragment:_m,emissivemap_pars_fragment:ym,colorspace_fragment:vm,colorspace_pars_fragment:Mm,envmap_fragment:Em,envmap_common_pars_fragment:Sm,envmap_pars_fragment:bm,envmap_pars_vertex:Tm,envmap_physical_pars_fragment:Fm,envmap_vertex:wm,fog_vertex:Am,fog_pars_vertex:Rm,fog_fragment:Cm,fog_pars_fragment:Pm,gradientmap_pars_fragment:Lm,lightmap_fragment:Im,lightmap_pars_fragment:Dm,lights_lambert_fragment:Um,lights_lambert_pars_fragment:Nm,lights_pars_begin:Om,lights_toon_fragment:zm,lights_toon_pars_fragment:Bm,lights_phong_fragment:Hm,lights_phong_pars_fragment:km,lights_physical_fragment:Gm,lights_physical_pars_fragment:Vm,lights_fragment_begin:Wm,lights_fragment_maps:Xm,lights_fragment_end:Ym,logdepthbuf_fragment:$m,logdepthbuf_pars_fragment:qm,logdepthbuf_pars_vertex:Zm,logdepthbuf_vertex:Jm,map_fragment:Km,map_pars_fragment:jm,map_particle_fragment:Qm,map_particle_pars_fragment:tg,metalnessmap_fragment:eg,metalnessmap_pars_fragment:ng,morphcolor_vertex:ig,morphnormal_vertex:sg,morphtarget_pars_vertex:rg,morphtarget_vertex:ag,normal_fragment_begin:og,normal_fragment_maps:cg,normal_pars_fragment:lg,normal_pars_vertex:hg,normal_vertex:ug,normalmap_pars_fragment:fg,clearcoat_normal_fragment_begin:dg,clearcoat_normal_fragment_maps:pg,clearcoat_pars_fragment:mg,iridescence_pars_fragment:gg,opaque_fragment:xg,packing:_g,premultiplied_alpha_fragment:yg,project_vertex:vg,dithering_fragment:Mg,dithering_pars_fragment:Eg,roughnessmap_fragment:Sg,roughnessmap_pars_fragment:bg,shadowmap_pars_fragment:Tg,shadowmap_pars_vertex:wg,shadowmap_vertex:Ag,shadowmask_pars_fragment:Rg,skinbase_vertex:Cg,skinning_pars_vertex:Pg,skinning_vertex:Lg,skinnormal_vertex:Ig,specularmap_fragment:Dg,specularmap_pars_fragment:Ug,tonemapping_fragment:Ng,tonemapping_pars_fragment:Og,transmission_fragment:Fg,transmission_pars_fragment:zg,uv_pars_fragment:Bg,uv_pars_vertex:Hg,uv_vertex:kg,worldpos_vertex:Gg,background_vert:Vg,background_frag:Wg,backgroundCube_vert:Xg,backgroundCube_frag:Yg,cube_vert:$g,cube_frag:qg,depth_vert:Zg,depth_frag:Jg,distanceRGBA_vert:Kg,distanceRGBA_frag:jg,equirect_vert:Qg,equirect_frag:tx,linedashed_vert:ex,linedashed_frag:nx,meshbasic_vert:ix,meshbasic_frag:sx,meshlambert_vert:rx,meshlambert_frag:ax,meshmatcap_vert:ox,meshmatcap_frag:cx,meshnormal_vert:lx,meshnormal_frag:hx,meshphong_vert:ux,meshphong_frag:fx,meshphysical_vert:dx,meshphysical_frag:px,meshtoon_vert:mx,meshtoon_frag:gx,points_vert:xx,points_frag:_x,shadow_vert:yx,shadow_frag:vx,sprite_vert:Mx,sprite_frag:Ex},dt={common:{diffuse:{value:new Ft(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new ie},alphaMap:{value:null},alphaMapTransform:{value:new ie},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new ie}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new ie}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new ie}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new ie},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new ie},normalScale:{value:new ht(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new ie},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new ie}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new ie}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new ie}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ft(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ft(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new ie},alphaTest:{value:0},uvTransform:{value:new ie}},sprite:{diffuse:{value:new Ft(16777215)},opacity:{value:1},center:{value:new ht(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new ie},alphaMap:{value:null},alphaMapTransform:{value:new ie},alphaTest:{value:0}}},ei={basic:{uniforms:gn([dt.common,dt.specularmap,dt.envmap,dt.aomap,dt.lightmap,dt.fog]),vertexShader:jt.meshbasic_vert,fragmentShader:jt.meshbasic_frag},lambert:{uniforms:gn([dt.common,dt.specularmap,dt.envmap,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.fog,dt.lights,{emissive:{value:new Ft(0)}}]),vertexShader:jt.meshlambert_vert,fragmentShader:jt.meshlambert_frag},phong:{uniforms:gn([dt.common,dt.specularmap,dt.envmap,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.fog,dt.lights,{emissive:{value:new Ft(0)},specular:{value:new Ft(1118481)},shininess:{value:30}}]),vertexShader:jt.meshphong_vert,fragmentShader:jt.meshphong_frag},standard:{uniforms:gn([dt.common,dt.envmap,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.roughnessmap,dt.metalnessmap,dt.fog,dt.lights,{emissive:{value:new Ft(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:jt.meshphysical_vert,fragmentShader:jt.meshphysical_frag},toon:{uniforms:gn([dt.common,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.gradientmap,dt.fog,dt.lights,{emissive:{value:new Ft(0)}}]),vertexShader:jt.meshtoon_vert,fragmentShader:jt.meshtoon_frag},matcap:{uniforms:gn([dt.common,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.fog,{matcap:{value:null}}]),vertexShader:jt.meshmatcap_vert,fragmentShader:jt.meshmatcap_frag},points:{uniforms:gn([dt.points,dt.fog]),vertexShader:jt.points_vert,fragmentShader:jt.points_frag},dashed:{uniforms:gn([dt.common,dt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:jt.linedashed_vert,fragmentShader:jt.linedashed_frag},depth:{uniforms:gn([dt.common,dt.displacementmap]),vertexShader:jt.depth_vert,fragmentShader:jt.depth_frag},normal:{uniforms:gn([dt.common,dt.bumpmap,dt.normalmap,dt.displacementmap,{opacity:{value:1}}]),vertexShader:jt.meshnormal_vert,fragmentShader:jt.meshnormal_frag},sprite:{uniforms:gn([dt.sprite,dt.fog]),vertexShader:jt.sprite_vert,fragmentShader:jt.sprite_frag},background:{uniforms:{uvTransform:{value:new ie},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:jt.background_vert,fragmentShader:jt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:jt.backgroundCube_vert,fragmentShader:jt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:jt.cube_vert,fragmentShader:jt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:jt.equirect_vert,fragmentShader:jt.equirect_frag},distanceRGBA:{uniforms:gn([dt.common,dt.displacementmap,{referencePosition:{value:new P},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:jt.distanceRGBA_vert,fragmentShader:jt.distanceRGBA_frag},shadow:{uniforms:gn([dt.lights,dt.fog,{color:{value:new Ft(0)},opacity:{value:1}}]),vertexShader:jt.shadow_vert,fragmentShader:jt.shadow_frag}};ei.physical={uniforms:gn([ei.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new ie},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new ie},clearcoatNormalScale:{value:new ht(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new ie},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new ie},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new ie},sheen:{value:0},sheenColor:{value:new Ft(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new ie},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new ie},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new ie},transmissionSamplerSize:{value:new ht},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new ie},attenuationDistance:{value:0},attenuationColor:{value:new Ft(0)},specularColor:{value:new Ft(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new ie},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new ie},anisotropyVector:{value:new ht},anisotropyMap:{value:null},anisotropyMapTransform:{value:new ie}}]),vertexShader:jt.meshphysical_vert,fragmentShader:jt.meshphysical_frag};var Xa={r:0,b:0,g:0};function Sx(n,t,e,i,s,r,a){let o=new Ft(0),c=r===!0?0:1,l,h,u=null,f=0,d=null;function p(g,m){let S=!1,y=m.isScene===!0?m.background:null;y&&y.isTexture&&(y=(m.backgroundBlurriness>0?e:t).get(y)),y===null?x(o,c):y&&y.isColor&&(x(y,1),S=!0);let b=n.xr.getEnvironmentBlendMode();b==="additive"?i.buffers.color.setClear(0,0,0,1,a):b==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(n.autoClear||S)&&n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil),y&&(y.isCubeTexture||y.mapping===zo)?(h===void 0&&(h=new Ct(new de(1,1,1),new Hn({name:"BackgroundCubeMaterial",uniforms:rr(ei.backgroundCube.uniforms),vertexShader:ei.backgroundCube.vertexShader,fragmentShader:ei.backgroundCube.fragmentShader,side:un,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(C,A,R){this.matrixWorld.copyPosition(R.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),h.material.uniforms.envMap.value=y,h.material.uniforms.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=m.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,h.material.toneMapped=_e.getTransfer(y.colorSpace)!==we,(u!==y||f!==y.version||d!==n.toneMapping)&&(h.material.needsUpdate=!0,u=y,f=y.version,d=n.toneMapping),h.layers.enableAll(),g.unshift(h,h.geometry,h.material,0,0,null)):y&&y.isTexture&&(l===void 0&&(l=new Ct(new _n(2,2),new Hn({name:"BackgroundMaterial",uniforms:rr(ei.background.uniforms),vertexShader:ei.background.vertexShader,fragmentShader:ei.background.fragmentShader,side:ki,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(l)),l.material.uniforms.t2D.value=y,l.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,l.material.toneMapped=_e.getTransfer(y.colorSpace)!==we,y.matrixAutoUpdate===!0&&y.updateMatrix(),l.material.uniforms.uvTransform.value.copy(y.matrix),(u!==y||f!==y.version||d!==n.toneMapping)&&(l.material.needsUpdate=!0,u=y,f=y.version,d=n.toneMapping),l.layers.enableAll(),g.unshift(l,l.geometry,l.material,0,0,null))}function x(g,m){g.getRGB(Xa,qf(n)),i.buffers.color.setClear(Xa.r,Xa.g,Xa.b,m,a)}return{getClearColor:function(){return o},setClearColor:function(g,m=1){o.set(g),c=m,x(o,c)},getClearAlpha:function(){return c},setClearAlpha:function(g){c=g,x(o,c)},render:p}}function bx(n,t,e,i){let s=n.getParameter(n.MAX_VERTEX_ATTRIBS),r=i.isWebGL2?null:t.get("OES_vertex_array_object"),a=i.isWebGL2||r!==null,o={},c=g(null),l=c,h=!1;function u(I,F,B,et,j){let J=!1;if(a){let it=x(et,B,F);l!==it&&(l=it,d(l.object)),J=m(I,et,B,j),J&&S(I,et,B,j)}else{let it=F.wireframe===!0;(l.geometry!==et.id||l.program!==B.id||l.wireframe!==it)&&(l.geometry=et.id,l.program=B.id,l.wireframe=it,J=!0)}j!==null&&e.update(j,n.ELEMENT_ARRAY_BUFFER),(J||h)&&(h=!1,O(I,F,B,et),j!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,e.get(j).buffer))}function f(){return i.isWebGL2?n.createVertexArray():r.createVertexArrayOES()}function d(I){return i.isWebGL2?n.bindVertexArray(I):r.bindVertexArrayOES(I)}function p(I){return i.isWebGL2?n.deleteVertexArray(I):r.deleteVertexArrayOES(I)}function x(I,F,B){let et=B.wireframe===!0,j=o[I.id];j===void 0&&(j={},o[I.id]=j);let J=j[F.id];J===void 0&&(J={},j[F.id]=J);let it=J[et];return it===void 0&&(it=g(f()),J[et]=it),it}function g(I){let F=[],B=[],et=[];for(let j=0;j<s;j++)F[j]=0,B[j]=0,et[j]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:F,enabledAttributes:B,attributeDivisors:et,object:I,attributes:{},index:null}}function m(I,F,B,et){let j=l.attributes,J=F.attributes,it=0,nt=B.getAttributes();for(let gt in nt)if(nt[gt].location>=0){let Q=j[gt],ut=J[gt];if(ut===void 0&&(gt==="instanceMatrix"&&I.instanceMatrix&&(ut=I.instanceMatrix),gt==="instanceColor"&&I.instanceColor&&(ut=I.instanceColor)),Q===void 0||Q.attribute!==ut||ut&&Q.data!==ut.data)return!0;it++}return l.attributesNum!==it||l.index!==et}function S(I,F,B,et){let j={},J=F.attributes,it=0,nt=B.getAttributes();for(let gt in nt)if(nt[gt].location>=0){let Q=J[gt];Q===void 0&&(gt==="instanceMatrix"&&I.instanceMatrix&&(Q=I.instanceMatrix),gt==="instanceColor"&&I.instanceColor&&(Q=I.instanceColor));let ut={};ut.attribute=Q,Q&&Q.data&&(ut.data=Q.data),j[gt]=ut,it++}l.attributes=j,l.attributesNum=it,l.index=et}function y(){let I=l.newAttributes;for(let F=0,B=I.length;F<B;F++)I[F]=0}function b(I){C(I,0)}function C(I,F){let B=l.newAttributes,et=l.enabledAttributes,j=l.attributeDivisors;B[I]=1,et[I]===0&&(n.enableVertexAttribArray(I),et[I]=1),j[I]!==F&&((i.isWebGL2?n:t.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](I,F),j[I]=F)}function A(){let I=l.newAttributes,F=l.enabledAttributes;for(let B=0,et=F.length;B<et;B++)F[B]!==I[B]&&(n.disableVertexAttribArray(B),F[B]=0)}function R(I,F,B,et,j,J,it){it===!0?n.vertexAttribIPointer(I,F,B,j,J):n.vertexAttribPointer(I,F,B,et,j,J)}function O(I,F,B,et){if(i.isWebGL2===!1&&(I.isInstancedMesh||et.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;y();let j=et.attributes,J=B.getAttributes(),it=F.defaultAttributeValues;for(let nt in J){let gt=J[nt];if(gt.location>=0){let $=j[nt];if($===void 0&&(nt==="instanceMatrix"&&I.instanceMatrix&&($=I.instanceMatrix),nt==="instanceColor"&&I.instanceColor&&($=I.instanceColor)),$!==void 0){let Q=$.normalized,ut=$.itemSize,Pt=e.get($);if(Pt===void 0)continue;let Mt=Pt.buffer,zt=Pt.type,tt=Pt.bytesPerElement,ct=i.isWebGL2===!0&&(zt===n.INT||zt===n.UNSIGNED_INT||$.gpuType===Uf);if($.isInterleavedBufferAttribute){let mt=$.data,w=mt.stride,st=$.offset;if(mt.isInstancedInterleavedBuffer){for(let Y=0;Y<gt.locationSize;Y++)C(gt.location+Y,mt.meshPerAttribute);I.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=mt.meshPerAttribute*mt.count)}else for(let Y=0;Y<gt.locationSize;Y++)b(gt.location+Y);n.bindBuffer(n.ARRAY_BUFFER,Mt);for(let Y=0;Y<gt.locationSize;Y++)R(gt.location+Y,ut/gt.locationSize,zt,Q,w*tt,(st+ut/gt.locationSize*Y)*tt,ct)}else{if($.isInstancedBufferAttribute){for(let mt=0;mt<gt.locationSize;mt++)C(gt.location+mt,$.meshPerAttribute);I.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=$.meshPerAttribute*$.count)}else for(let mt=0;mt<gt.locationSize;mt++)b(gt.location+mt);n.bindBuffer(n.ARRAY_BUFFER,Mt);for(let mt=0;mt<gt.locationSize;mt++)R(gt.location+mt,ut/gt.locationSize,zt,Q,ut*tt,ut/gt.locationSize*mt*tt,ct)}}else if(it!==void 0){let Q=it[nt];if(Q!==void 0)switch(Q.length){case 2:n.vertexAttrib2fv(gt.location,Q);break;case 3:n.vertexAttrib3fv(gt.location,Q);break;case 4:n.vertexAttrib4fv(gt.location,Q);break;default:n.vertexAttrib1fv(gt.location,Q)}}}}A()}function E(){H();for(let I in o){let F=o[I];for(let B in F){let et=F[B];for(let j in et)p(et[j].object),delete et[j];delete F[B]}delete o[I]}}function M(I){if(o[I.id]===void 0)return;let F=o[I.id];for(let B in F){let et=F[B];for(let j in et)p(et[j].object),delete et[j];delete F[B]}delete o[I.id]}function U(I){for(let F in o){let B=o[F];if(B[I.id]===void 0)continue;let et=B[I.id];for(let j in et)p(et[j].object),delete et[j];delete B[I.id]}}function H(){rt(),h=!0,l!==c&&(l=c,d(l.object))}function rt(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:u,reset:H,resetDefaultState:rt,dispose:E,releaseStatesOfGeometry:M,releaseStatesOfProgram:U,initAttributes:y,enableAttribute:b,disableUnusedAttributes:A}}function Tx(n,t,e,i){let s=i.isWebGL2,r;function a(h){r=h}function o(h,u){n.drawArrays(r,h,u),e.update(u,r,1)}function c(h,u,f){if(f===0)return;let d,p;if(s)d=n,p="drawArraysInstanced";else if(d=t.get("ANGLE_instanced_arrays"),p="drawArraysInstancedANGLE",d===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}d[p](r,h,u,f),e.update(u,r,f)}function l(h,u,f){if(f===0)return;let d=t.get("WEBGL_multi_draw");if(d===null)for(let p=0;p<f;p++)this.render(h[p],u[p]);else{d.multiDrawArraysWEBGL(r,h,0,u,0,f);let p=0;for(let x=0;x<f;x++)p+=u[x];e.update(p,r,1)}}this.setMode=a,this.render=o,this.renderInstances=c,this.renderMultiDraw=l}function wx(n,t,e){let i;function s(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){let R=t.get("EXT_texture_filter_anisotropic");i=n.getParameter(R.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function r(R){if(R==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";R="mediump"}return R==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let a=typeof WebGL2RenderingContext<"u"&&n.constructor.name==="WebGL2RenderingContext",o=e.precision!==void 0?e.precision:"highp",c=r(o);c!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",c,"instead."),o=c);let l=a||t.has("WEBGL_draw_buffers"),h=e.logarithmicDepthBuffer===!0,u=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),f=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),d=n.getParameter(n.MAX_TEXTURE_SIZE),p=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),x=n.getParameter(n.MAX_VERTEX_ATTRIBS),g=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),m=n.getParameter(n.MAX_VARYING_VECTORS),S=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),y=f>0,b=a||t.has("OES_texture_float"),C=y&&b,A=a?n.getParameter(n.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:l,getMaxAnisotropy:s,getMaxPrecision:r,precision:o,logarithmicDepthBuffer:h,maxTextures:u,maxVertexTextures:f,maxTextureSize:d,maxCubemapSize:p,maxAttributes:x,maxVertexUniforms:g,maxVaryings:m,maxFragmentUniforms:S,vertexTextures:y,floatFragmentTextures:b,floatVertexTextures:C,maxSamples:A}}function Ax(n){let t=this,e=null,i=0,s=!1,r=!1,a=new gi,o=new ie,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(u,f){let d=u.length!==0||f||i!==0||s;return s=f,i=u.length,d},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,f){e=h(u,f,0)},this.setState=function(u,f,d){let p=u.clippingPlanes,x=u.clipIntersection,g=u.clipShadows,m=n.get(u);if(!s||p===null||p.length===0||r&&!g)r?h(null):l();else{let S=r?0:i,y=S*4,b=m.clippingState||null;c.value=b,b=h(p,f,y,d);for(let C=0;C!==y;++C)b[C]=e[C];m.clippingState=b,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=S}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=i>0),t.numPlanes=i,t.numIntersection=0}function h(u,f,d,p){let x=u!==null?u.length:0,g=null;if(x!==0){if(g=c.value,p!==!0||g===null){let m=d+x*4,S=f.matrixWorldInverse;o.getNormalMatrix(S),(g===null||g.length<m)&&(g=new Float32Array(m));for(let y=0,b=d;y!==x;++y,b+=4)a.copy(u[y]).applyMatrix4(S,o),a.normal.toArray(g,b),g[b+3]=a.constant}c.value=g,c.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,g}}function Rx(n){let t=new WeakMap;function e(a,o){return o===nl?a.mapping=er:o===il&&(a.mapping=nr),a}function i(a){if(a&&a.isTexture){let o=a.mapping;if(o===nl||o===il)if(t.has(a)){let c=t.get(a).texture;return e(c,a.mapping)}else{let c=a.image;if(c&&c.height>0){let l=new ul(c.height/2);return l.fromEquirectangularTexture(n,a),t.set(a,l),a.addEventListener("dispose",s),e(l.texture,a.mapping)}else return null}}return a}function s(a){let o=a.target;o.removeEventListener("dispose",s);let c=t.get(o);c!==void 0&&(t.delete(o),c.dispose())}function r(){t=new WeakMap}return{get:i,dispose:r}}var Eo=class extends vo{constructor(t=-1,e=1,i=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=i,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,i,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=i-t,a=i+t,o=s+e,c=s-e;if(this.view!==null&&this.view.enabled){let l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,a=r+l*this.view.width,o-=h*this.view.offsetY,c=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Js=4,Ju=[.125,.215,.35,.446,.526,.582],ss=20,Wc=new Eo,Ku=new Ft,Xc=null,Yc=0,$c=0,ns=(1+Math.sqrt(5))/2,Ws=1/ns,ju=[new P(1,1,1),new P(-1,1,1),new P(1,1,-1),new P(-1,1,-1),new P(0,ns,Ws),new P(0,ns,-Ws),new P(Ws,0,ns),new P(-Ws,0,ns),new P(ns,Ws,0),new P(-ns,Ws,0)],ar=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,i=.1,s=100){Xc=this._renderer.getRenderTarget(),Yc=this._renderer.getActiveCubeFace(),$c=this._renderer.getActiveMipmapLevel(),this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,i,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=ef(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=tf(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Xc,Yc,$c),t.scissorTest=!1,Ya(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===er||t.mapping===nr?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Xc=this._renderer.getRenderTarget(),Yc=this._renderer.getActiveCubeFace(),$c=this._renderer.getActiveMipmapLevel();let i=e||this._allocateTargets();return this._textureToCubeUV(t,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,i={magFilter:Nn,minFilter:Nn,generateMipmaps:!1,type:Yr,format:Jn,colorSpace:_i,depthBuffer:!1},s=Qu(t,e,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Qu(t,e,i);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Cx(r)),this._blurMaterial=Px(r,t,e)}return s}_compileMaterial(t){let e=new Ct(this._lodPlanes[0],t);this._renderer.compile(e,Wc)}_sceneToCubeUV(t,e,i,s){let o=new xn(90,1,e,i),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,f=h.toneMapping;h.getClearColor(Ku),h.toneMapping=Bi,h.autoClear=!1;let d=new Bn({name:"PMREM.Background",side:un,depthWrite:!1,depthTest:!1}),p=new Ct(new de,d),x=!1,g=t.background;g?g.isColor&&(d.color.copy(g),t.background=null,x=!0):(d.color.copy(Ku),x=!0);for(let m=0;m<6;m++){let S=m%3;S===0?(o.up.set(0,c[m],0),o.lookAt(l[m],0,0)):S===1?(o.up.set(0,0,c[m]),o.lookAt(0,l[m],0)):(o.up.set(0,c[m],0),o.lookAt(0,0,l[m]));let y=this._cubeSize;Ya(s,S*y,m>2?y:0,y,y),h.setRenderTarget(s),x&&h.render(p,o),h.render(t,o)}p.geometry.dispose(),p.material.dispose(),h.toneMapping=f,h.autoClear=u,t.background=g}_textureToCubeUV(t,e){let i=this._renderer,s=t.mapping===er||t.mapping===nr;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=ef()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=tf());let r=s?this._cubemapMaterial:this._equirectMaterial,a=new Ct(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=t;let c=this._cubeSize;Ya(e,0,0,3*c,2*c),i.setRenderTarget(e),i.render(a,Wc)}_applyPMREM(t){let e=this._renderer,i=e.autoClear;e.autoClear=!1;for(let s=1;s<this._lodPlanes.length;s++){let r=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),a=ju[(s-1)%ju.length];this._blur(t,s-1,s,r,a)}e.autoClear=i}_blur(t,e,i,s,r){let a=this._pingPongRenderTarget;this._halfBlur(t,a,e,i,s,"latitudinal",r),this._halfBlur(a,t,i,i,s,"longitudinal",r)}_halfBlur(t,e,i,s,r,a,o){let c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new Ct(this._lodPlanes[s],l),f=l.uniforms,d=this._sizeLods[i]-1,p=isFinite(r)?Math.PI/(2*d):2*Math.PI/(2*ss-1),x=r/p,g=isFinite(r)?1+Math.floor(h*x):ss;g>ss&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${ss}`);let m=[],S=0;for(let R=0;R<ss;++R){let O=R/x,E=Math.exp(-O*O/2);m.push(E),R===0?S+=E:R<g&&(S+=2*E)}for(let R=0;R<m.length;R++)m[R]=m[R]/S;f.envMap.value=t.texture,f.samples.value=g,f.weights.value=m,f.latitudinal.value=a==="latitudinal",o&&(f.poleAxis.value=o);let{_lodMax:y}=this;f.dTheta.value=p,f.mipInt.value=y-i;let b=this._sizeLods[s],C=3*b*(s>y-Js?s-y+Js:0),A=4*(this._cubeSize-b);Ya(e,C,A,3*b,2*b),c.setRenderTarget(e),c.render(u,Wc)}};function Cx(n){let t=[],e=[],i=[],s=n,r=n-Js+1+Ju.length;for(let a=0;a<r;a++){let o=Math.pow(2,s);e.push(o);let c=1/o;a>n-Js?c=Ju[a-n+Js-1]:a===0&&(c=0),i.push(c);let l=1/(o-2),h=-l,u=1+l,f=[h,h,u,h,u,u,h,h,u,u,h,u],d=6,p=6,x=3,g=2,m=1,S=new Float32Array(x*p*d),y=new Float32Array(g*p*d),b=new Float32Array(m*p*d);for(let A=0;A<d;A++){let R=A%3*2/3-1,O=A>2?0:-1,E=[R,O,0,R+2/3,O,0,R+2/3,O+1,0,R,O,0,R+2/3,O+1,0,R,O+1,0];S.set(E,x*p*A),y.set(f,g*p*A);let M=[A,A,A,A,A,A];b.set(M,m*p*A)}let C=new Ue;C.setAttribute("position",new Pe(S,x)),C.setAttribute("uv",new Pe(y,g)),C.setAttribute("faceIndex",new Pe(b,m)),t.push(C),s>Js&&s--}return{lodPlanes:t,sizeLods:e,sigmas:i}}function Qu(n,t,e){let i=new yi(n,t,e);return i.texture.mapping=zo,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Ya(n,t,e,i,s){n.viewport.set(t,e,i,s),n.scissor.set(t,e,i,s)}function Px(n,t,e){let i=new Float32Array(ss),s=new P(0,1,0);return new Hn({name:"SphericalGaussianBlur",defines:{n:ss,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Kl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Fi,depthTest:!1,depthWrite:!1})}function tf(){return new Hn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Kl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Fi,depthTest:!1,depthWrite:!1})}function ef(){return new Hn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Kl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Fi,depthTest:!1,depthWrite:!1})}function Kl(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Lx(n){let t=new WeakMap,e=null;function i(o){if(o&&o.isTexture){let c=o.mapping,l=c===nl||c===il,h=c===er||c===nr;if(l||h)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let u=t.get(o);return e===null&&(e=new ar(n)),u=l?e.fromEquirectangular(o,u):e.fromCubemap(o,u),t.set(o,u),u.texture}else{if(t.has(o))return t.get(o).texture;{let u=o.image;if(l&&u&&u.height>0||h&&u&&s(u)){e===null&&(e=new ar(n));let f=l?e.fromEquirectangular(o):e.fromCubemap(o);return t.set(o,f),o.addEventListener("dispose",r),f.texture}else return null}}}return o}function s(o){let c=0,l=6;for(let h=0;h<l;h++)o[h]!==void 0&&c++;return c===l}function r(o){let c=o.target;c.removeEventListener("dispose",r);let l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:i,dispose:a}}function Ix(n){let t={};function e(i){if(t[i]!==void 0)return t[i];let s;switch(i){case"WEBGL_depth_texture":s=n.getExtension("WEBGL_depth_texture")||n.getExtension("MOZ_WEBGL_depth_texture")||n.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=n.getExtension("EXT_texture_filter_anisotropic")||n.getExtension("MOZ_EXT_texture_filter_anisotropic")||n.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=n.getExtension("WEBGL_compressed_texture_s3tc")||n.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=n.getExtension("WEBGL_compressed_texture_pvrtc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=n.getExtension(i)}return t[i]=s,s}return{has:function(i){return e(i)!==null},init:function(i){i.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(i){let s=e(i);return s===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),s}}}function Dx(n,t,e,i){let s={},r=new WeakMap;function a(u){let f=u.target;f.index!==null&&t.remove(f.index);for(let p in f.attributes)t.remove(f.attributes[p]);for(let p in f.morphAttributes){let x=f.morphAttributes[p];for(let g=0,m=x.length;g<m;g++)t.remove(x[g])}f.removeEventListener("dispose",a),delete s[f.id];let d=r.get(f);d&&(t.remove(d),r.delete(f)),i.releaseStatesOfGeometry(f),f.isInstancedBufferGeometry===!0&&delete f._maxInstanceCount,e.memory.geometries--}function o(u,f){return s[f.id]===!0||(f.addEventListener("dispose",a),s[f.id]=!0,e.memory.geometries++),f}function c(u){let f=u.attributes;for(let p in f)t.update(f[p],n.ARRAY_BUFFER);let d=u.morphAttributes;for(let p in d){let x=d[p];for(let g=0,m=x.length;g<m;g++)t.update(x[g],n.ARRAY_BUFFER)}}function l(u){let f=[],d=u.index,p=u.attributes.position,x=0;if(d!==null){let S=d.array;x=d.version;for(let y=0,b=S.length;y<b;y+=3){let C=S[y+0],A=S[y+1],R=S[y+2];f.push(C,A,A,R,R,C)}}else if(p!==void 0){let S=p.array;x=p.version;for(let y=0,b=S.length/3-1;y<b;y+=3){let C=y+0,A=y+1,R=y+2;f.push(C,A,A,R,R,C)}}else return;let g=new(Yf(f)?yo:_o)(f,1);g.version=x;let m=r.get(u);m&&t.remove(m),r.set(u,g)}function h(u){let f=r.get(u);if(f){let d=u.index;d!==null&&f.version<d.version&&l(u)}else l(u);return r.get(u)}return{get:o,update:c,getWireframeAttribute:h}}function Ux(n,t,e,i){let s=i.isWebGL2,r;function a(d){r=d}let o,c;function l(d){o=d.type,c=d.bytesPerElement}function h(d,p){n.drawElements(r,p,o,d*c),e.update(p,r,1)}function u(d,p,x){if(x===0)return;let g,m;if(s)g=n,m="drawElementsInstanced";else if(g=t.get("ANGLE_instanced_arrays"),m="drawElementsInstancedANGLE",g===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}g[m](r,p,o,d*c,x),e.update(p,r,x)}function f(d,p,x){if(x===0)return;let g=t.get("WEBGL_multi_draw");if(g===null)for(let m=0;m<x;m++)this.render(d[m]/c,p[m]);else{g.multiDrawElementsWEBGL(r,p,0,o,d,0,x);let m=0;for(let S=0;S<x;S++)m+=p[S];e.update(m,r,1)}}this.setMode=a,this.setIndex=l,this.render=h,this.renderInstances=u,this.renderMultiDraw=f}function Nx(n){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,a,o){switch(e.calls++,a){case n.TRIANGLES:e.triangles+=o*(r/3);break;case n.LINES:e.lines+=o*(r/2);break;case n.LINE_STRIP:e.lines+=o*(r-1);break;case n.LINE_LOOP:e.lines+=o*r;break;case n.POINTS:e.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:i}}function Ox(n,t){return n[0]-t[0]}function Fx(n,t){return Math.abs(t[1])-Math.abs(n[1])}function zx(n,t,e){let i={},s=new Float32Array(8),r=new WeakMap,a=new en,o=[];for(let l=0;l<8;l++)o[l]=[l,0];function c(l,h,u){let f=l.morphTargetInfluences;if(t.isWebGL2===!0){let d=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,p=d!==void 0?d.length:0,x=r.get(h);if(x===void 0||x.count!==p){let I=function(){H.dispose(),r.delete(h),h.removeEventListener("dispose",I)};x!==void 0&&x.texture.dispose();let S=h.morphAttributes.position!==void 0,y=h.morphAttributes.normal!==void 0,b=h.morphAttributes.color!==void 0,C=h.morphAttributes.position||[],A=h.morphAttributes.normal||[],R=h.morphAttributes.color||[],O=0;S===!0&&(O=1),y===!0&&(O=2),b===!0&&(O=3);let E=h.attributes.position.count*O,M=1;E>t.maxTextureSize&&(M=Math.ceil(E/t.maxTextureSize),E=t.maxTextureSize);let U=new Float32Array(E*M*4*p),H=new mo(U,E,M,p);H.type=Oi,H.needsUpdate=!0;let rt=O*4;for(let F=0;F<p;F++){let B=C[F],et=A[F],j=R[F],J=E*M*4*F;for(let it=0;it<B.count;it++){let nt=it*rt;S===!0&&(a.fromBufferAttribute(B,it),U[J+nt+0]=a.x,U[J+nt+1]=a.y,U[J+nt+2]=a.z,U[J+nt+3]=0),y===!0&&(a.fromBufferAttribute(et,it),U[J+nt+4]=a.x,U[J+nt+5]=a.y,U[J+nt+6]=a.z,U[J+nt+7]=0),b===!0&&(a.fromBufferAttribute(j,it),U[J+nt+8]=a.x,U[J+nt+9]=a.y,U[J+nt+10]=a.z,U[J+nt+11]=j.itemSize===4?a.w:1)}}x={count:p,texture:H,size:new ht(E,M)},r.set(h,x),h.addEventListener("dispose",I)}let g=0;for(let S=0;S<f.length;S++)g+=f[S];let m=h.morphTargetsRelative?1:1-g;u.getUniforms().setValue(n,"morphTargetBaseInfluence",m),u.getUniforms().setValue(n,"morphTargetInfluences",f),u.getUniforms().setValue(n,"morphTargetsTexture",x.texture,e),u.getUniforms().setValue(n,"morphTargetsTextureSize",x.size)}else{let d=f===void 0?0:f.length,p=i[h.id];if(p===void 0||p.length!==d){p=[];for(let y=0;y<d;y++)p[y]=[y,0];i[h.id]=p}for(let y=0;y<d;y++){let b=p[y];b[0]=y,b[1]=f[y]}p.sort(Fx);for(let y=0;y<8;y++)y<d&&p[y][1]?(o[y][0]=p[y][0],o[y][1]=p[y][1]):(o[y][0]=Number.MAX_SAFE_INTEGER,o[y][1]=0);o.sort(Ox);let x=h.morphAttributes.position,g=h.morphAttributes.normal,m=0;for(let y=0;y<8;y++){let b=o[y],C=b[0],A=b[1];C!==Number.MAX_SAFE_INTEGER&&A?(x&&h.getAttribute("morphTarget"+y)!==x[C]&&h.setAttribute("morphTarget"+y,x[C]),g&&h.getAttribute("morphNormal"+y)!==g[C]&&h.setAttribute("morphNormal"+y,g[C]),s[y]=A,m+=A):(x&&h.hasAttribute("morphTarget"+y)===!0&&h.deleteAttribute("morphTarget"+y),g&&h.hasAttribute("morphNormal"+y)===!0&&h.deleteAttribute("morphNormal"+y),s[y]=0)}let S=h.morphTargetsRelative?1:1-m;u.getUniforms().setValue(n,"morphTargetBaseInfluence",S),u.getUniforms().setValue(n,"morphTargetInfluences",s)}}return{update:c}}function Bx(n,t,e,i){let s=new WeakMap;function r(c){let l=i.render.frame,h=c.geometry,u=t.get(c,h);if(s.get(u)!==l&&(t.update(u),s.set(u,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",o)===!1&&c.addEventListener("dispose",o),s.get(c)!==l&&(e.update(c.instanceMatrix,n.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,n.ARRAY_BUFFER),s.set(c,l))),c.isSkinnedMesh){let f=c.skeleton;s.get(f)!==l&&(f.update(),s.set(f,l))}return u}function a(){s=new WeakMap}function o(c){let l=c.target;l.removeEventListener("dispose",o),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:r,dispose:a}}var So=class extends Fn{constructor(t,e,i,s,r,a,o,c,l,h){if(h=h!==void 0?h:os,h!==os&&h!==ir)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&h===os&&(i=Ni),i===void 0&&h===ir&&(i=as),super(null,s,r,a,o,c,h,i,l),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=o!==void 0?o:tn,this.minFilter=c!==void 0?c:tn,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},Jf=new Fn,Kf=new So(1,1);Kf.compareFunction=Vf;var jf=new mo,Qf=new ll,td=new Mo,nf=[],sf=[],rf=new Float32Array(16),af=new Float32Array(9),of=new Float32Array(4);function ur(n,t,e){let i=n[0];if(i<=0||i>0)return n;let s=t*e,r=nf[s];if(r===void 0&&(r=new Float32Array(s),nf[s]=r),t!==0){i.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,n[a].toArray(r,o)}return r}function qe(n,t){if(n.length!==t.length)return!1;for(let e=0,i=n.length;e<i;e++)if(n[e]!==t[e])return!1;return!0}function Ze(n,t){for(let e=0,i=t.length;e<i;e++)n[e]=t[e]}function Ho(n,t){let e=sf[t];e===void 0&&(e=new Int32Array(t),sf[t]=e);for(let i=0;i!==t;++i)e[i]=n.allocateTextureUnit();return e}function Hx(n,t){let e=this.cache;e[0]!==t&&(n.uniform1f(this.addr,t),e[0]=t)}function kx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(qe(e,t))return;n.uniform2fv(this.addr,t),Ze(e,t)}}function Gx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(n.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(qe(e,t))return;n.uniform3fv(this.addr,t),Ze(e,t)}}function Vx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(qe(e,t))return;n.uniform4fv(this.addr,t),Ze(e,t)}}function Wx(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(qe(e,t))return;n.uniformMatrix2fv(this.addr,!1,t),Ze(e,t)}else{if(qe(e,i))return;of.set(i),n.uniformMatrix2fv(this.addr,!1,of),Ze(e,i)}}function Xx(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(qe(e,t))return;n.uniformMatrix3fv(this.addr,!1,t),Ze(e,t)}else{if(qe(e,i))return;af.set(i),n.uniformMatrix3fv(this.addr,!1,af),Ze(e,i)}}function Yx(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(qe(e,t))return;n.uniformMatrix4fv(this.addr,!1,t),Ze(e,t)}else{if(qe(e,i))return;rf.set(i),n.uniformMatrix4fv(this.addr,!1,rf),Ze(e,i)}}function $x(n,t){let e=this.cache;e[0]!==t&&(n.uniform1i(this.addr,t),e[0]=t)}function qx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(qe(e,t))return;n.uniform2iv(this.addr,t),Ze(e,t)}}function Zx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(qe(e,t))return;n.uniform3iv(this.addr,t),Ze(e,t)}}function Jx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(qe(e,t))return;n.uniform4iv(this.addr,t),Ze(e,t)}}function Kx(n,t){let e=this.cache;e[0]!==t&&(n.uniform1ui(this.addr,t),e[0]=t)}function jx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(qe(e,t))return;n.uniform2uiv(this.addr,t),Ze(e,t)}}function Qx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(qe(e,t))return;n.uniform3uiv(this.addr,t),Ze(e,t)}}function t_(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(qe(e,t))return;n.uniform4uiv(this.addr,t),Ze(e,t)}}function e_(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s);let r=this.type===n.SAMPLER_2D_SHADOW?Kf:Jf;e.setTexture2D(t||r,s)}function n_(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTexture3D(t||Qf,s)}function i_(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTextureCube(t||td,s)}function s_(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTexture2DArray(t||jf,s)}function r_(n){switch(n){case 5126:return Hx;case 35664:return kx;case 35665:return Gx;case 35666:return Vx;case 35674:return Wx;case 35675:return Xx;case 35676:return Yx;case 5124:case 35670:return $x;case 35667:case 35671:return qx;case 35668:case 35672:return Zx;case 35669:case 35673:return Jx;case 5125:return Kx;case 36294:return jx;case 36295:return Qx;case 36296:return t_;case 35678:case 36198:case 36298:case 36306:case 35682:return e_;case 35679:case 36299:case 36307:return n_;case 35680:case 36300:case 36308:case 36293:return i_;case 36289:case 36303:case 36311:case 36292:return s_}}function a_(n,t){n.uniform1fv(this.addr,t)}function o_(n,t){let e=ur(t,this.size,2);n.uniform2fv(this.addr,e)}function c_(n,t){let e=ur(t,this.size,3);n.uniform3fv(this.addr,e)}function l_(n,t){let e=ur(t,this.size,4);n.uniform4fv(this.addr,e)}function h_(n,t){let e=ur(t,this.size,4);n.uniformMatrix2fv(this.addr,!1,e)}function u_(n,t){let e=ur(t,this.size,9);n.uniformMatrix3fv(this.addr,!1,e)}function f_(n,t){let e=ur(t,this.size,16);n.uniformMatrix4fv(this.addr,!1,e)}function d_(n,t){n.uniform1iv(this.addr,t)}function p_(n,t){n.uniform2iv(this.addr,t)}function m_(n,t){n.uniform3iv(this.addr,t)}function g_(n,t){n.uniform4iv(this.addr,t)}function x_(n,t){n.uniform1uiv(this.addr,t)}function __(n,t){n.uniform2uiv(this.addr,t)}function y_(n,t){n.uniform3uiv(this.addr,t)}function v_(n,t){n.uniform4uiv(this.addr,t)}function M_(n,t,e){let i=this.cache,s=t.length,r=Ho(e,s);qe(i,r)||(n.uniform1iv(this.addr,r),Ze(i,r));for(let a=0;a!==s;++a)e.setTexture2D(t[a]||Jf,r[a])}function E_(n,t,e){let i=this.cache,s=t.length,r=Ho(e,s);qe(i,r)||(n.uniform1iv(this.addr,r),Ze(i,r));for(let a=0;a!==s;++a)e.setTexture3D(t[a]||Qf,r[a])}function S_(n,t,e){let i=this.cache,s=t.length,r=Ho(e,s);qe(i,r)||(n.uniform1iv(this.addr,r),Ze(i,r));for(let a=0;a!==s;++a)e.setTextureCube(t[a]||td,r[a])}function b_(n,t,e){let i=this.cache,s=t.length,r=Ho(e,s);qe(i,r)||(n.uniform1iv(this.addr,r),Ze(i,r));for(let a=0;a!==s;++a)e.setTexture2DArray(t[a]||jf,r[a])}function T_(n){switch(n){case 5126:return a_;case 35664:return o_;case 35665:return c_;case 35666:return l_;case 35674:return h_;case 35675:return u_;case 35676:return f_;case 5124:case 35670:return d_;case 35667:case 35671:return p_;case 35668:case 35672:return m_;case 35669:case 35673:return g_;case 5125:return x_;case 36294:return __;case 36295:return y_;case 36296:return v_;case 35678:case 36198:case 36298:case 36306:case 35682:return M_;case 35679:case 36299:case 36307:return E_;case 35680:case 36300:case 36308:case 36293:return S_;case 36289:case 36303:case 36311:case 36292:return b_}}var fl=class{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.setValue=r_(e.type)}},dl=class{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=T_(e.type)}},pl=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,i){let s=this.seq;for(let r=0,a=s.length;r!==a;++r){let o=s[r];o.setValue(t,e[o.id],i)}}},qc=/(\w+)(\])?(\[|\.)?/g;function cf(n,t){n.seq.push(t),n.map[t.id]=t}function w_(n,t,e){let i=n.name,s=i.length;for(qc.lastIndex=0;;){let r=qc.exec(i),a=qc.lastIndex,o=r[1],c=r[2]==="]",l=r[3];if(c&&(o=o|0),l===void 0||l==="["&&a+2===s){cf(e,l===void 0?new fl(o,n,t):new dl(o,n,t));break}else{let u=e.map[o];u===void 0&&(u=new pl(o),cf(e,u)),e=u}}}var tr=class{constructor(t,e){this.seq=[],this.map={};let i=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<i;++s){let r=t.getActiveUniform(e,s),a=t.getUniformLocation(e,r.name);w_(r,a,this)}}setValue(t,e,i,s){let r=this.map[e];r!==void 0&&r.setValue(t,i,s)}setOptional(t,e,i){let s=e[i];s!==void 0&&this.setValue(t,i,s)}static upload(t,e,i,s){for(let r=0,a=e.length;r!==a;++r){let o=e[r],c=i[o.id];c.needsUpdate!==!1&&o.setValue(t,c.value,s)}}static seqWithValue(t,e){let i=[];for(let s=0,r=t.length;s!==r;++s){let a=t[s];a.id in e&&i.push(a)}return i}};function lf(n,t,e){let i=n.createShader(t);return n.shaderSource(i,e),n.compileShader(i),i}var A_=37297,R_=0;function C_(n,t){let e=n.split(`
`),i=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=s;a<r;a++){let o=a+1;i.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return i.join(`
`)}function P_(n){let t=_e.getPrimaries(_e.workingColorSpace),e=_e.getPrimaries(n),i;switch(t===e?i="":t===co&&e===oo?i="LinearDisplayP3ToLinearSRGB":t===oo&&e===co&&(i="LinearSRGBToLinearDisplayP3"),n){case _i:case Bo:return[i,"LinearTransferOETF"];case Ae:case Zl:return[i,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",n),[i,"LinearTransferOETF"]}}function hf(n,t,e){let i=n.getShaderParameter(t,n.COMPILE_STATUS),s=n.getShaderInfoLog(t).trim();if(i&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let a=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+C_(n.getShaderSource(t),a)}else return s}function L_(n,t){let e=P_(t);return`vec4 ${n}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function I_(n,t){let e;switch(t){case zp:e="Linear";break;case Bp:e="Reinhard";break;case Hp:e="OptimizedCineon";break;case $l:e="ACESFilmic";break;case Gp:e="AgX";break;case kp:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+n+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function D_(n){return[n.extensionDerivatives||n.envMapCubeUVHeight||n.bumpMap||n.normalMapTangentSpace||n.clearcoatNormalMap||n.flatShading||n.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(n.extensionFragDepth||n.logarithmicDepthBuffer)&&n.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",n.extensionDrawBuffers&&n.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(n.extensionShaderTextureLOD||n.envMap||n.transmission)&&n.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Ks).join(`
`)}function U_(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(Ks).join(`
`)}function N_(n){let t=[];for(let e in n){let i=n[e];i!==!1&&t.push("#define "+e+" "+i)}return t.join(`
`)}function O_(n,t){let e={},i=n.getProgramParameter(t,n.ACTIVE_ATTRIBUTES);for(let s=0;s<i;s++){let r=n.getActiveAttrib(t,s),a=r.name,o=1;r.type===n.FLOAT_MAT2&&(o=2),r.type===n.FLOAT_MAT3&&(o=3),r.type===n.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:n.getAttribLocation(t,a),locationSize:o}}return e}function Ks(n){return n!==""}function uf(n,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function ff(n,t){return n.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var F_=/^[ \t]*#include +<([\w\d./]+)>/gm;function ml(n){return n.replace(F_,B_)}var z_=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function B_(n,t){let e=jt[t];if(e===void 0){let i=z_.get(t);if(i!==void 0)e=jt[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,i);else throw new Error("Can not resolve #include <"+t+">")}return ml(e)}var H_=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function df(n){return n.replace(H_,k_)}function k_(n,t,e,i){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function pf(n){let t="precision "+n.precision+` float;
precision `+n.precision+" int;";return n.precision==="highp"?t+=`
#define HIGH_PRECISION`:n.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function G_(n){let t="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===Lf?t="SHADOWMAP_TYPE_PCF":n.shadowMapType===Yl?t="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===mi&&(t="SHADOWMAP_TYPE_VSM"),t}function V_(n){let t="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case er:case nr:t="ENVMAP_TYPE_CUBE";break;case zo:t="ENVMAP_TYPE_CUBE_UV";break}return t}function W_(n){let t="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case nr:t="ENVMAP_MODE_REFRACTION";break}return t}function X_(n){let t="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case If:t="ENVMAP_BLENDING_MULTIPLY";break;case Op:t="ENVMAP_BLENDING_MIX";break;case Fp:t="ENVMAP_BLENDING_ADD";break}return t}function Y_(n){let t=n.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,i=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:i,maxMip:e}}function $_(n,t,e,i){let s=n.getContext(),r=e.defines,a=e.vertexShader,o=e.fragmentShader,c=G_(e),l=V_(e),h=W_(e),u=X_(e),f=Y_(e),d=e.isWebGL2?"":D_(e),p=U_(e),x=N_(r),g=s.createProgram(),m,S,y=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(Ks).join(`
`),m.length>0&&(m+=`
`),S=[d,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(Ks).join(`
`),S.length>0&&(S+=`
`)):(m=[pf(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ks).join(`
`),S=[d,pf(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",f?"#define CUBEUV_TEXEL_WIDTH "+f.texelWidth:"",f?"#define CUBEUV_TEXEL_HEIGHT "+f.texelHeight:"",f?"#define CUBEUV_MAX_MIP "+f.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Bi?"#define TONE_MAPPING":"",e.toneMapping!==Bi?jt.tonemapping_pars_fragment:"",e.toneMapping!==Bi?I_("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",jt.colorspace_pars_fragment,L_("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Ks).join(`
`)),a=ml(a),a=uf(a,e),a=ff(a,e),o=ml(o),o=uf(o,e),o=ff(o,e),a=df(a),o=df(o),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(y=`#version 300 es
`,m=[p,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,S=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===Iu?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Iu?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+S);let b=y+m+a,C=y+S+o,A=lf(s,s.VERTEX_SHADER,b),R=lf(s,s.FRAGMENT_SHADER,C);s.attachShader(g,A),s.attachShader(g,R),e.index0AttributeName!==void 0?s.bindAttribLocation(g,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(g,0,"position"),s.linkProgram(g);function O(H){if(n.debug.checkShaderErrors){let rt=s.getProgramInfoLog(g).trim(),I=s.getShaderInfoLog(A).trim(),F=s.getShaderInfoLog(R).trim(),B=!0,et=!0;if(s.getProgramParameter(g,s.LINK_STATUS)===!1)if(B=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(s,g,A,R);else{let j=hf(s,A,"vertex"),J=hf(s,R,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(g,s.VALIDATE_STATUS)+`

Program Info Log: `+rt+`
`+j+`
`+J)}else rt!==""?console.warn("THREE.WebGLProgram: Program Info Log:",rt):(I===""||F==="")&&(et=!1);et&&(H.diagnostics={runnable:B,programLog:rt,vertexShader:{log:I,prefix:m},fragmentShader:{log:F,prefix:S}})}s.deleteShader(A),s.deleteShader(R),E=new tr(s,g),M=O_(s,g)}let E;this.getUniforms=function(){return E===void 0&&O(this),E};let M;this.getAttributes=function(){return M===void 0&&O(this),M};let U=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return U===!1&&(U=s.getProgramParameter(g,A_)),U},this.destroy=function(){i.releaseStatesOfProgram(this),s.deleteProgram(g),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=R_++,this.cacheKey=t,this.usedTimes=1,this.program=g,this.vertexShader=A,this.fragmentShader=R,this}var q_=0,gl=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,i=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(i),a=this._getShaderCacheForMaterial(t);return a.has(s)===!1&&(a.add(s),s.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let i of e)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,i=e.get(t);return i===void 0&&(i=new Set,e.set(t,i)),i}_getShaderStage(t){let e=this.shaderCache,i=e.get(t);return i===void 0&&(i=new xl(t),e.set(t,i)),i}},xl=class{constructor(t){this.id=q_++,this.code=t,this.usedTimes=0}};function Z_(n,t,e,i,s,r,a){let o=new xo,c=new gl,l=[],h=s.isWebGL2,u=s.logarithmicDepthBuffer,f=s.vertexTextures,d=s.precision,p={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(E){return E===0?"uv":`uv${E}`}function g(E,M,U,H,rt){let I=H.fog,F=rt.geometry,B=E.isMeshStandardMaterial?H.environment:null,et=(E.isMeshStandardMaterial?e:t).get(E.envMap||B),j=et&&et.mapping===zo?et.image.height:null,J=p[E.type];E.precision!==null&&(d=s.getMaxPrecision(E.precision),d!==E.precision&&console.warn("THREE.WebGLProgram.getParameters:",E.precision,"not supported, using",d,"instead."));let it=F.morphAttributes.position||F.morphAttributes.normal||F.morphAttributes.color,nt=it!==void 0?it.length:0,gt=0;F.morphAttributes.position!==void 0&&(gt=1),F.morphAttributes.normal!==void 0&&(gt=2),F.morphAttributes.color!==void 0&&(gt=3);let $,Q,ut,Pt;if(J){let dn=ei[J];$=dn.vertexShader,Q=dn.fragmentShader}else $=E.vertexShader,Q=E.fragmentShader,c.update(E),ut=c.getVertexShaderID(E),Pt=c.getFragmentShaderID(E);let Mt=n.getRenderTarget(),zt=rt.isInstancedMesh===!0,tt=rt.isBatchedMesh===!0,ct=!!E.map,mt=!!E.matcap,w=!!et,st=!!E.aoMap,Y=!!E.lightMap,K=!!E.bumpMap,q=!!E.normalMap,Rt=!!E.displacementMap,xt=!!E.emissiveMap,v=!!E.metalnessMap,_=!!E.roughnessMap,L=E.anisotropy>0,k=E.clearcoat>0,W=E.iridescence>0,Z=E.sheen>0,Et=E.transmission>0,lt=L&&!!E.anisotropyMap,St=k&&!!E.clearcoatMap,Ot=k&&!!E.clearcoatNormalMap,Yt=k&&!!E.clearcoatRoughnessMap,at=W&&!!E.iridescenceMap,fe=W&&!!E.iridescenceThicknessMap,se=Z&&!!E.sheenColorMap,qt=Z&&!!E.sheenRoughnessMap,Bt=!!E.specularMap,Lt=!!E.specularColorMap,Kt=!!E.specularIntensityMap,ge=Et&&!!E.transmissionMap,Ne=Et&&!!E.thicknessMap,ee=!!E.gradientMap,ft=!!E.alphaMap,D=E.alphaTest>0,yt=!!E.alphaHash,vt=!!E.extensions,Wt=!!F.attributes.uv1,Ht=!!F.attributes.uv2,ve=!!F.attributes.uv3,Me=Bi;return E.toneMapped&&(Mt===null||Mt.isXRRenderTarget===!0)&&(Me=n.toneMapping),{isWebGL2:h,shaderID:J,shaderType:E.type,shaderName:E.name,vertexShader:$,fragmentShader:Q,defines:E.defines,customVertexShaderID:ut,customFragmentShaderID:Pt,isRawShaderMaterial:E.isRawShaderMaterial===!0,glslVersion:E.glslVersion,precision:d,batching:tt,instancing:zt,instancingColor:zt&&rt.instanceColor!==null,supportsVertexTextures:f,outputColorSpace:Mt===null?n.outputColorSpace:Mt.isXRRenderTarget===!0?Mt.texture.colorSpace:_i,map:ct,matcap:mt,envMap:w,envMapMode:w&&et.mapping,envMapCubeUVHeight:j,aoMap:st,lightMap:Y,bumpMap:K,normalMap:q,displacementMap:f&&Rt,emissiveMap:xt,normalMapObjectSpace:q&&E.normalMapType===t0,normalMapTangentSpace:q&&E.normalMapType===Gf,metalnessMap:v,roughnessMap:_,anisotropy:L,anisotropyMap:lt,clearcoat:k,clearcoatMap:St,clearcoatNormalMap:Ot,clearcoatRoughnessMap:Yt,iridescence:W,iridescenceMap:at,iridescenceThicknessMap:fe,sheen:Z,sheenColorMap:se,sheenRoughnessMap:qt,specularMap:Bt,specularColorMap:Lt,specularIntensityMap:Kt,transmission:Et,transmissionMap:ge,thicknessMap:Ne,gradientMap:ee,opaque:E.transparent===!1&&E.blending===zi,alphaMap:ft,alphaTest:D,alphaHash:yt,combine:E.combine,mapUv:ct&&x(E.map.channel),aoMapUv:st&&x(E.aoMap.channel),lightMapUv:Y&&x(E.lightMap.channel),bumpMapUv:K&&x(E.bumpMap.channel),normalMapUv:q&&x(E.normalMap.channel),displacementMapUv:Rt&&x(E.displacementMap.channel),emissiveMapUv:xt&&x(E.emissiveMap.channel),metalnessMapUv:v&&x(E.metalnessMap.channel),roughnessMapUv:_&&x(E.roughnessMap.channel),anisotropyMapUv:lt&&x(E.anisotropyMap.channel),clearcoatMapUv:St&&x(E.clearcoatMap.channel),clearcoatNormalMapUv:Ot&&x(E.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Yt&&x(E.clearcoatRoughnessMap.channel),iridescenceMapUv:at&&x(E.iridescenceMap.channel),iridescenceThicknessMapUv:fe&&x(E.iridescenceThicknessMap.channel),sheenColorMapUv:se&&x(E.sheenColorMap.channel),sheenRoughnessMapUv:qt&&x(E.sheenRoughnessMap.channel),specularMapUv:Bt&&x(E.specularMap.channel),specularColorMapUv:Lt&&x(E.specularColorMap.channel),specularIntensityMapUv:Kt&&x(E.specularIntensityMap.channel),transmissionMapUv:ge&&x(E.transmissionMap.channel),thicknessMapUv:Ne&&x(E.thicknessMap.channel),alphaMapUv:ft&&x(E.alphaMap.channel),vertexTangents:!!F.attributes.tangent&&(q||L),vertexColors:E.vertexColors,vertexAlphas:E.vertexColors===!0&&!!F.attributes.color&&F.attributes.color.itemSize===4,vertexUv1s:Wt,vertexUv2s:Ht,vertexUv3s:ve,pointsUvs:rt.isPoints===!0&&!!F.attributes.uv&&(ct||ft),fog:!!I,useFog:E.fog===!0,fogExp2:I&&I.isFogExp2,flatShading:E.flatShading===!0,sizeAttenuation:E.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:rt.isSkinnedMesh===!0,morphTargets:F.morphAttributes.position!==void 0,morphNormals:F.morphAttributes.normal!==void 0,morphColors:F.morphAttributes.color!==void 0,morphTargetsCount:nt,morphTextureStride:gt,numDirLights:M.directional.length,numPointLights:M.point.length,numSpotLights:M.spot.length,numSpotLightMaps:M.spotLightMap.length,numRectAreaLights:M.rectArea.length,numHemiLights:M.hemi.length,numDirLightShadows:M.directionalShadowMap.length,numPointLightShadows:M.pointShadowMap.length,numSpotLightShadows:M.spotShadowMap.length,numSpotLightShadowsWithMaps:M.numSpotLightShadowsWithMaps,numLightProbes:M.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:E.dithering,shadowMapEnabled:n.shadowMap.enabled&&U.length>0,shadowMapType:n.shadowMap.type,toneMapping:Me,useLegacyLights:n._useLegacyLights,decodeVideoTexture:ct&&E.map.isVideoTexture===!0&&_e.getTransfer(E.map.colorSpace)===we,premultipliedAlpha:E.premultipliedAlpha,doubleSided:E.side===He,flipSided:E.side===un,useDepthPacking:E.depthPacking>=0,depthPacking:E.depthPacking||0,index0AttributeName:E.index0AttributeName,extensionDerivatives:vt&&E.extensions.derivatives===!0,extensionFragDepth:vt&&E.extensions.fragDepth===!0,extensionDrawBuffers:vt&&E.extensions.drawBuffers===!0,extensionShaderTextureLOD:vt&&E.extensions.shaderTextureLOD===!0,extensionClipCullDistance:vt&&E.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:E.customProgramCacheKey()}}function m(E){let M=[];if(E.shaderID?M.push(E.shaderID):(M.push(E.customVertexShaderID),M.push(E.customFragmentShaderID)),E.defines!==void 0)for(let U in E.defines)M.push(U),M.push(E.defines[U]);return E.isRawShaderMaterial===!1&&(S(M,E),y(M,E),M.push(n.outputColorSpace)),M.push(E.customProgramCacheKey),M.join()}function S(E,M){E.push(M.precision),E.push(M.outputColorSpace),E.push(M.envMapMode),E.push(M.envMapCubeUVHeight),E.push(M.mapUv),E.push(M.alphaMapUv),E.push(M.lightMapUv),E.push(M.aoMapUv),E.push(M.bumpMapUv),E.push(M.normalMapUv),E.push(M.displacementMapUv),E.push(M.emissiveMapUv),E.push(M.metalnessMapUv),E.push(M.roughnessMapUv),E.push(M.anisotropyMapUv),E.push(M.clearcoatMapUv),E.push(M.clearcoatNormalMapUv),E.push(M.clearcoatRoughnessMapUv),E.push(M.iridescenceMapUv),E.push(M.iridescenceThicknessMapUv),E.push(M.sheenColorMapUv),E.push(M.sheenRoughnessMapUv),E.push(M.specularMapUv),E.push(M.specularColorMapUv),E.push(M.specularIntensityMapUv),E.push(M.transmissionMapUv),E.push(M.thicknessMapUv),E.push(M.combine),E.push(M.fogExp2),E.push(M.sizeAttenuation),E.push(M.morphTargetsCount),E.push(M.morphAttributeCount),E.push(M.numDirLights),E.push(M.numPointLights),E.push(M.numSpotLights),E.push(M.numSpotLightMaps),E.push(M.numHemiLights),E.push(M.numRectAreaLights),E.push(M.numDirLightShadows),E.push(M.numPointLightShadows),E.push(M.numSpotLightShadows),E.push(M.numSpotLightShadowsWithMaps),E.push(M.numLightProbes),E.push(M.shadowMapType),E.push(M.toneMapping),E.push(M.numClippingPlanes),E.push(M.numClipIntersection),E.push(M.depthPacking)}function y(E,M){o.disableAll(),M.isWebGL2&&o.enable(0),M.supportsVertexTextures&&o.enable(1),M.instancing&&o.enable(2),M.instancingColor&&o.enable(3),M.matcap&&o.enable(4),M.envMap&&o.enable(5),M.normalMapObjectSpace&&o.enable(6),M.normalMapTangentSpace&&o.enable(7),M.clearcoat&&o.enable(8),M.iridescence&&o.enable(9),M.alphaTest&&o.enable(10),M.vertexColors&&o.enable(11),M.vertexAlphas&&o.enable(12),M.vertexUv1s&&o.enable(13),M.vertexUv2s&&o.enable(14),M.vertexUv3s&&o.enable(15),M.vertexTangents&&o.enable(16),M.anisotropy&&o.enable(17),M.alphaHash&&o.enable(18),M.batching&&o.enable(19),E.push(o.mask),o.disableAll(),M.fog&&o.enable(0),M.useFog&&o.enable(1),M.flatShading&&o.enable(2),M.logarithmicDepthBuffer&&o.enable(3),M.skinning&&o.enable(4),M.morphTargets&&o.enable(5),M.morphNormals&&o.enable(6),M.morphColors&&o.enable(7),M.premultipliedAlpha&&o.enable(8),M.shadowMapEnabled&&o.enable(9),M.useLegacyLights&&o.enable(10),M.doubleSided&&o.enable(11),M.flipSided&&o.enable(12),M.useDepthPacking&&o.enable(13),M.dithering&&o.enable(14),M.transmission&&o.enable(15),M.sheen&&o.enable(16),M.opaque&&o.enable(17),M.pointsUvs&&o.enable(18),M.decodeVideoTexture&&o.enable(19),E.push(o.mask)}function b(E){let M=p[E.type],U;if(M){let H=ei[M];U=z0.clone(H.uniforms)}else U=E.uniforms;return U}function C(E,M){let U;for(let H=0,rt=l.length;H<rt;H++){let I=l[H];if(I.cacheKey===M){U=I,++U.usedTimes;break}}return U===void 0&&(U=new $_(n,M,E,r),l.push(U)),U}function A(E){if(--E.usedTimes===0){let M=l.indexOf(E);l[M]=l[l.length-1],l.pop(),E.destroy()}}function R(E){c.remove(E)}function O(){c.dispose()}return{getParameters:g,getProgramCacheKey:m,getUniforms:b,acquireProgram:C,releaseProgram:A,releaseShaderCache:R,programs:l,dispose:O}}function J_(){let n=new WeakMap;function t(r){let a=n.get(r);return a===void 0&&(a={},n.set(r,a)),a}function e(r){n.delete(r)}function i(r,a,o){n.get(r)[a]=o}function s(){n=new WeakMap}return{get:t,remove:e,update:i,dispose:s}}function K_(n,t){return n.groupOrder!==t.groupOrder?n.groupOrder-t.groupOrder:n.renderOrder!==t.renderOrder?n.renderOrder-t.renderOrder:n.material.id!==t.material.id?n.material.id-t.material.id:n.z!==t.z?n.z-t.z:n.id-t.id}function mf(n,t){return n.groupOrder!==t.groupOrder?n.groupOrder-t.groupOrder:n.renderOrder!==t.renderOrder?n.renderOrder-t.renderOrder:n.z!==t.z?t.z-n.z:n.id-t.id}function gf(){let n=[],t=0,e=[],i=[],s=[];function r(){t=0,e.length=0,i.length=0,s.length=0}function a(u,f,d,p,x,g){let m=n[t];return m===void 0?(m={id:u.id,object:u,geometry:f,material:d,groupOrder:p,renderOrder:u.renderOrder,z:x,group:g},n[t]=m):(m.id=u.id,m.object=u,m.geometry=f,m.material=d,m.groupOrder=p,m.renderOrder=u.renderOrder,m.z=x,m.group=g),t++,m}function o(u,f,d,p,x,g){let m=a(u,f,d,p,x,g);d.transmission>0?i.push(m):d.transparent===!0?s.push(m):e.push(m)}function c(u,f,d,p,x,g){let m=a(u,f,d,p,x,g);d.transmission>0?i.unshift(m):d.transparent===!0?s.unshift(m):e.unshift(m)}function l(u,f){e.length>1&&e.sort(u||K_),i.length>1&&i.sort(f||mf),s.length>1&&s.sort(f||mf)}function h(){for(let u=t,f=n.length;u<f;u++){let d=n[u];if(d.id===null)break;d.id=null,d.object=null,d.geometry=null,d.material=null,d.group=null}}return{opaque:e,transmissive:i,transparent:s,init:r,push:o,unshift:c,finish:h,sort:l}}function j_(){let n=new WeakMap;function t(i,s){let r=n.get(i),a;return r===void 0?(a=new gf,n.set(i,[a])):s>=r.length?(a=new gf,r.push(a)):a=r[s],a}function e(){n=new WeakMap}return{get:t,dispose:e}}function Q_(){let n={};return{get:function(t){if(n[t.id]!==void 0)return n[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new P,color:new Ft};break;case"SpotLight":e={position:new P,direction:new P,color:new Ft,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new P,color:new Ft,distance:0,decay:0};break;case"HemisphereLight":e={direction:new P,skyColor:new Ft,groundColor:new Ft};break;case"RectAreaLight":e={color:new Ft,position:new P,halfWidth:new P,halfHeight:new P};break}return n[t.id]=e,e}}}function ty(){let n={};return{get:function(t){if(n[t.id]!==void 0)return n[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[t.id]=e,e}}}var ey=0;function ny(n,t){return(t.castShadow?2:0)-(n.castShadow?2:0)+(t.map?1:0)-(n.map?1:0)}function iy(n,t){let e=new Q_,i=ty(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)s.probe.push(new P);let r=new P,a=new Se,o=new Se;function c(h,u){let f=0,d=0,p=0;for(let H=0;H<9;H++)s.probe[H].set(0,0,0);let x=0,g=0,m=0,S=0,y=0,b=0,C=0,A=0,R=0,O=0,E=0;h.sort(ny);let M=u===!0?Math.PI:1;for(let H=0,rt=h.length;H<rt;H++){let I=h[H],F=I.color,B=I.intensity,et=I.distance,j=I.shadow&&I.shadow.map?I.shadow.map.texture:null;if(I.isAmbientLight)f+=F.r*B*M,d+=F.g*B*M,p+=F.b*B*M;else if(I.isLightProbe){for(let J=0;J<9;J++)s.probe[J].addScaledVector(I.sh.coefficients[J],B);E++}else if(I.isDirectionalLight){let J=e.get(I);if(J.color.copy(I.color).multiplyScalar(I.intensity*M),I.castShadow){let it=I.shadow,nt=i.get(I);nt.shadowBias=it.bias,nt.shadowNormalBias=it.normalBias,nt.shadowRadius=it.radius,nt.shadowMapSize=it.mapSize,s.directionalShadow[x]=nt,s.directionalShadowMap[x]=j,s.directionalShadowMatrix[x]=I.shadow.matrix,b++}s.directional[x]=J,x++}else if(I.isSpotLight){let J=e.get(I);J.position.setFromMatrixPosition(I.matrixWorld),J.color.copy(F).multiplyScalar(B*M),J.distance=et,J.coneCos=Math.cos(I.angle),J.penumbraCos=Math.cos(I.angle*(1-I.penumbra)),J.decay=I.decay,s.spot[m]=J;let it=I.shadow;if(I.map&&(s.spotLightMap[R]=I.map,R++,it.updateMatrices(I),I.castShadow&&O++),s.spotLightMatrix[m]=it.matrix,I.castShadow){let nt=i.get(I);nt.shadowBias=it.bias,nt.shadowNormalBias=it.normalBias,nt.shadowRadius=it.radius,nt.shadowMapSize=it.mapSize,s.spotShadow[m]=nt,s.spotShadowMap[m]=j,A++}m++}else if(I.isRectAreaLight){let J=e.get(I);J.color.copy(F).multiplyScalar(B),J.halfWidth.set(I.width*.5,0,0),J.halfHeight.set(0,I.height*.5,0),s.rectArea[S]=J,S++}else if(I.isPointLight){let J=e.get(I);if(J.color.copy(I.color).multiplyScalar(I.intensity*M),J.distance=I.distance,J.decay=I.decay,I.castShadow){let it=I.shadow,nt=i.get(I);nt.shadowBias=it.bias,nt.shadowNormalBias=it.normalBias,nt.shadowRadius=it.radius,nt.shadowMapSize=it.mapSize,nt.shadowCameraNear=it.camera.near,nt.shadowCameraFar=it.camera.far,s.pointShadow[g]=nt,s.pointShadowMap[g]=j,s.pointShadowMatrix[g]=I.shadow.matrix,C++}s.point[g]=J,g++}else if(I.isHemisphereLight){let J=e.get(I);J.skyColor.copy(I.color).multiplyScalar(B*M),J.groundColor.copy(I.groundColor).multiplyScalar(B*M),s.hemi[y]=J,y++}}S>0&&(t.isWebGL2?n.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=dt.LTC_FLOAT_1,s.rectAreaLTC2=dt.LTC_FLOAT_2):(s.rectAreaLTC1=dt.LTC_HALF_1,s.rectAreaLTC2=dt.LTC_HALF_2):n.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=dt.LTC_FLOAT_1,s.rectAreaLTC2=dt.LTC_FLOAT_2):n.has("OES_texture_half_float_linear")===!0?(s.rectAreaLTC1=dt.LTC_HALF_1,s.rectAreaLTC2=dt.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),s.ambient[0]=f,s.ambient[1]=d,s.ambient[2]=p;let U=s.hash;(U.directionalLength!==x||U.pointLength!==g||U.spotLength!==m||U.rectAreaLength!==S||U.hemiLength!==y||U.numDirectionalShadows!==b||U.numPointShadows!==C||U.numSpotShadows!==A||U.numSpotMaps!==R||U.numLightProbes!==E)&&(s.directional.length=x,s.spot.length=m,s.rectArea.length=S,s.point.length=g,s.hemi.length=y,s.directionalShadow.length=b,s.directionalShadowMap.length=b,s.pointShadow.length=C,s.pointShadowMap.length=C,s.spotShadow.length=A,s.spotShadowMap.length=A,s.directionalShadowMatrix.length=b,s.pointShadowMatrix.length=C,s.spotLightMatrix.length=A+R-O,s.spotLightMap.length=R,s.numSpotLightShadowsWithMaps=O,s.numLightProbes=E,U.directionalLength=x,U.pointLength=g,U.spotLength=m,U.rectAreaLength=S,U.hemiLength=y,U.numDirectionalShadows=b,U.numPointShadows=C,U.numSpotShadows=A,U.numSpotMaps=R,U.numLightProbes=E,s.version=ey++)}function l(h,u){let f=0,d=0,p=0,x=0,g=0,m=u.matrixWorldInverse;for(let S=0,y=h.length;S<y;S++){let b=h[S];if(b.isDirectionalLight){let C=s.directional[f];C.direction.setFromMatrixPosition(b.matrixWorld),r.setFromMatrixPosition(b.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(m),f++}else if(b.isSpotLight){let C=s.spot[p];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(m),C.direction.setFromMatrixPosition(b.matrixWorld),r.setFromMatrixPosition(b.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(m),p++}else if(b.isRectAreaLight){let C=s.rectArea[x];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(m),o.identity(),a.copy(b.matrixWorld),a.premultiply(m),o.extractRotation(a),C.halfWidth.set(b.width*.5,0,0),C.halfHeight.set(0,b.height*.5,0),C.halfWidth.applyMatrix4(o),C.halfHeight.applyMatrix4(o),x++}else if(b.isPointLight){let C=s.point[d];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(m),d++}else if(b.isHemisphereLight){let C=s.hemi[g];C.direction.setFromMatrixPosition(b.matrixWorld),C.direction.transformDirection(m),g++}}}return{setup:c,setupView:l,state:s}}function xf(n,t){let e=new iy(n,t),i=[],s=[];function r(){i.length=0,s.length=0}function a(u){i.push(u)}function o(u){s.push(u)}function c(u){e.setup(i,u)}function l(u){e.setupView(i,u)}return{init:r,state:{lightsArray:i,shadowsArray:s,lights:e},setupLights:c,setupLightsView:l,pushLight:a,pushShadow:o}}function sy(n,t){let e=new WeakMap;function i(r,a=0){let o=e.get(r),c;return o===void 0?(c=new xf(n,t),e.set(r,[c])):a>=o.length?(c=new xf(n,t),o.push(c)):c=o[a],c}function s(){e=new WeakMap}return{get:i,dispose:s}}var _l=class extends vi{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=jp,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},yl=class extends vi{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},ry=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,ay=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function oy(n,t,e){let i=new qr,s=new ht,r=new ht,a=new en,o=new _l({depthPacking:Qp}),c=new yl,l={},h=e.maxTextureSize,u={[ki]:un,[un]:ki,[He]:He},f=new Hn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ht},radius:{value:4}},vertexShader:ry,fragmentShader:ay}),d=f.clone();d.defines.HORIZONTAL_PASS=1;let p=new Ue;p.setAttribute("position",new Pe(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let x=new Ct(p,f),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Lf;let m=this.type;this.render=function(A,R,O){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||A.length===0)return;let E=n.getRenderTarget(),M=n.getActiveCubeFace(),U=n.getActiveMipmapLevel(),H=n.state;H.setBlending(Fi),H.buffers.color.setClear(1,1,1,1),H.buffers.depth.setTest(!0),H.setScissorTest(!1);let rt=m!==mi&&this.type===mi,I=m===mi&&this.type!==mi;for(let F=0,B=A.length;F<B;F++){let et=A[F],j=et.shadow;if(j===void 0){console.warn("THREE.WebGLShadowMap:",et,"has no shadow.");continue}if(j.autoUpdate===!1&&j.needsUpdate===!1)continue;s.copy(j.mapSize);let J=j.getFrameExtents();if(s.multiply(J),r.copy(j.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/J.x),s.x=r.x*J.x,j.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/J.y),s.y=r.y*J.y,j.mapSize.y=r.y)),j.map===null||rt===!0||I===!0){let nt=this.type!==mi?{minFilter:tn,magFilter:tn}:{};j.map!==null&&j.map.dispose(),j.map=new yi(s.x,s.y,nt),j.map.texture.name=et.name+".shadowMap",j.camera.updateProjectionMatrix()}n.setRenderTarget(j.map),n.clear();let it=j.getViewportCount();for(let nt=0;nt<it;nt++){let gt=j.getViewport(nt);a.set(r.x*gt.x,r.y*gt.y,r.x*gt.z,r.y*gt.w),H.viewport(a),j.updateMatrices(et,nt),i=j.getFrustum(),b(R,O,j.camera,et,this.type)}j.isPointLightShadow!==!0&&this.type===mi&&S(j,O),j.needsUpdate=!1}m=this.type,g.needsUpdate=!1,n.setRenderTarget(E,M,U)};function S(A,R){let O=t.update(x);f.defines.VSM_SAMPLES!==A.blurSamples&&(f.defines.VSM_SAMPLES=A.blurSamples,d.defines.VSM_SAMPLES=A.blurSamples,f.needsUpdate=!0,d.needsUpdate=!0),A.mapPass===null&&(A.mapPass=new yi(s.x,s.y)),f.uniforms.shadow_pass.value=A.map.texture,f.uniforms.resolution.value=A.mapSize,f.uniforms.radius.value=A.radius,n.setRenderTarget(A.mapPass),n.clear(),n.renderBufferDirect(R,null,O,f,x,null),d.uniforms.shadow_pass.value=A.mapPass.texture,d.uniforms.resolution.value=A.mapSize,d.uniforms.radius.value=A.radius,n.setRenderTarget(A.map),n.clear(),n.renderBufferDirect(R,null,O,d,x,null)}function y(A,R,O,E){let M=null,U=O.isPointLight===!0?A.customDistanceMaterial:A.customDepthMaterial;if(U!==void 0)M=U;else if(M=O.isPointLight===!0?c:o,n.localClippingEnabled&&R.clipShadows===!0&&Array.isArray(R.clippingPlanes)&&R.clippingPlanes.length!==0||R.displacementMap&&R.displacementScale!==0||R.alphaMap&&R.alphaTest>0||R.map&&R.alphaTest>0){let H=M.uuid,rt=R.uuid,I=l[H];I===void 0&&(I={},l[H]=I);let F=I[rt];F===void 0&&(F=M.clone(),I[rt]=F,R.addEventListener("dispose",C)),M=F}if(M.visible=R.visible,M.wireframe=R.wireframe,E===mi?M.side=R.shadowSide!==null?R.shadowSide:R.side:M.side=R.shadowSide!==null?R.shadowSide:u[R.side],M.alphaMap=R.alphaMap,M.alphaTest=R.alphaTest,M.map=R.map,M.clipShadows=R.clipShadows,M.clippingPlanes=R.clippingPlanes,M.clipIntersection=R.clipIntersection,M.displacementMap=R.displacementMap,M.displacementScale=R.displacementScale,M.displacementBias=R.displacementBias,M.wireframeLinewidth=R.wireframeLinewidth,M.linewidth=R.linewidth,O.isPointLight===!0&&M.isMeshDistanceMaterial===!0){let H=n.properties.get(M);H.light=O}return M}function b(A,R,O,E,M){if(A.visible===!1)return;if(A.layers.test(R.layers)&&(A.isMesh||A.isLine||A.isPoints)&&(A.castShadow||A.receiveShadow&&M===mi)&&(!A.frustumCulled||i.intersectsObject(A))){A.modelViewMatrix.multiplyMatrices(O.matrixWorldInverse,A.matrixWorld);let rt=t.update(A),I=A.material;if(Array.isArray(I)){let F=rt.groups;for(let B=0,et=F.length;B<et;B++){let j=F[B],J=I[j.materialIndex];if(J&&J.visible){let it=y(A,J,E,M);A.onBeforeShadow(n,A,R,O,rt,it,j),n.renderBufferDirect(O,null,rt,it,A,j),A.onAfterShadow(n,A,R,O,rt,it,j)}}}else if(I.visible){let F=y(A,I,E,M);A.onBeforeShadow(n,A,R,O,rt,F,null),n.renderBufferDirect(O,null,rt,F,A,null),A.onAfterShadow(n,A,R,O,rt,F,null)}}let H=A.children;for(let rt=0,I=H.length;rt<I;rt++)b(H[rt],R,O,E,M)}function C(A){A.target.removeEventListener("dispose",C);for(let O in l){let E=l[O],M=A.target.uuid;M in E&&(E[M].dispose(),delete E[M])}}}function cy(n,t,e){let i=e.isWebGL2;function s(){let D=!1,yt=new en,vt=null,Wt=new en(0,0,0,0);return{setMask:function(Ht){vt!==Ht&&!D&&(n.colorMask(Ht,Ht,Ht,Ht),vt=Ht)},setLocked:function(Ht){D=Ht},setClear:function(Ht,ve,Me,Ke,dn){dn===!0&&(Ht*=Ke,ve*=Ke,Me*=Ke),yt.set(Ht,ve,Me,Ke),Wt.equals(yt)===!1&&(n.clearColor(Ht,ve,Me,Ke),Wt.copy(yt))},reset:function(){D=!1,vt=null,Wt.set(-1,0,0,0)}}}function r(){let D=!1,yt=null,vt=null,Wt=null;return{setTest:function(Ht){Ht?tt(n.DEPTH_TEST):ct(n.DEPTH_TEST)},setMask:function(Ht){yt!==Ht&&!D&&(n.depthMask(Ht),yt=Ht)},setFunc:function(Ht){if(vt!==Ht){switch(Ht){case Cp:n.depthFunc(n.NEVER);break;case Pp:n.depthFunc(n.ALWAYS);break;case Lp:n.depthFunc(n.LESS);break;case io:n.depthFunc(n.LEQUAL);break;case Ip:n.depthFunc(n.EQUAL);break;case Dp:n.depthFunc(n.GEQUAL);break;case Up:n.depthFunc(n.GREATER);break;case Np:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}vt=Ht}},setLocked:function(Ht){D=Ht},setClear:function(Ht){Wt!==Ht&&(n.clearDepth(Ht),Wt=Ht)},reset:function(){D=!1,yt=null,vt=null,Wt=null}}}function a(){let D=!1,yt=null,vt=null,Wt=null,Ht=null,ve=null,Me=null,Ke=null,dn=null;return{setTest:function(Ee){D||(Ee?tt(n.STENCIL_TEST):ct(n.STENCIL_TEST))},setMask:function(Ee){yt!==Ee&&!D&&(n.stencilMask(Ee),yt=Ee)},setFunc:function(Ee,pn,ti){(vt!==Ee||Wt!==pn||Ht!==ti)&&(n.stencilFunc(Ee,pn,ti),vt=Ee,Wt=pn,Ht=ti)},setOp:function(Ee,pn,ti){(ve!==Ee||Me!==pn||Ke!==ti)&&(n.stencilOp(Ee,pn,ti),ve=Ee,Me=pn,Ke=ti)},setLocked:function(Ee){D=Ee},setClear:function(Ee){dn!==Ee&&(n.clearStencil(Ee),dn=Ee)},reset:function(){D=!1,yt=null,vt=null,Wt=null,Ht=null,ve=null,Me=null,Ke=null,dn=null}}}let o=new s,c=new r,l=new a,h=new WeakMap,u=new WeakMap,f={},d={},p=new WeakMap,x=[],g=null,m=!1,S=null,y=null,b=null,C=null,A=null,R=null,O=null,E=new Ft(0,0,0),M=0,U=!1,H=null,rt=null,I=null,F=null,B=null,et=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS),j=!1,J=0,it=n.getParameter(n.VERSION);it.indexOf("WebGL")!==-1?(J=parseFloat(/^WebGL (\d)/.exec(it)[1]),j=J>=1):it.indexOf("OpenGL ES")!==-1&&(J=parseFloat(/^OpenGL ES (\d)/.exec(it)[1]),j=J>=2);let nt=null,gt={},$=n.getParameter(n.SCISSOR_BOX),Q=n.getParameter(n.VIEWPORT),ut=new en().fromArray($),Pt=new en().fromArray(Q);function Mt(D,yt,vt,Wt){let Ht=new Uint8Array(4),ve=n.createTexture();n.bindTexture(D,ve),n.texParameteri(D,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(D,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let Me=0;Me<vt;Me++)i&&(D===n.TEXTURE_3D||D===n.TEXTURE_2D_ARRAY)?n.texImage3D(yt,0,n.RGBA,1,1,Wt,0,n.RGBA,n.UNSIGNED_BYTE,Ht):n.texImage2D(yt+Me,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Ht);return ve}let zt={};zt[n.TEXTURE_2D]=Mt(n.TEXTURE_2D,n.TEXTURE_2D,1),zt[n.TEXTURE_CUBE_MAP]=Mt(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(zt[n.TEXTURE_2D_ARRAY]=Mt(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),zt[n.TEXTURE_3D]=Mt(n.TEXTURE_3D,n.TEXTURE_3D,1,1)),o.setClear(0,0,0,1),c.setClear(1),l.setClear(0),tt(n.DEPTH_TEST),c.setFunc(io),xt(!1),v(Kh),tt(n.CULL_FACE),q(Fi);function tt(D){f[D]!==!0&&(n.enable(D),f[D]=!0)}function ct(D){f[D]!==!1&&(n.disable(D),f[D]=!1)}function mt(D,yt){return d[D]!==yt?(n.bindFramebuffer(D,yt),d[D]=yt,i&&(D===n.DRAW_FRAMEBUFFER&&(d[n.FRAMEBUFFER]=yt),D===n.FRAMEBUFFER&&(d[n.DRAW_FRAMEBUFFER]=yt)),!0):!1}function w(D,yt){let vt=x,Wt=!1;if(D)if(vt=p.get(yt),vt===void 0&&(vt=[],p.set(yt,vt)),D.isWebGLMultipleRenderTargets){let Ht=D.texture;if(vt.length!==Ht.length||vt[0]!==n.COLOR_ATTACHMENT0){for(let ve=0,Me=Ht.length;ve<Me;ve++)vt[ve]=n.COLOR_ATTACHMENT0+ve;vt.length=Ht.length,Wt=!0}}else vt[0]!==n.COLOR_ATTACHMENT0&&(vt[0]=n.COLOR_ATTACHMENT0,Wt=!0);else vt[0]!==n.BACK&&(vt[0]=n.BACK,Wt=!0);Wt&&(e.isWebGL2?n.drawBuffers(vt):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(vt))}function st(D){return g!==D?(n.useProgram(D),g=D,!0):!1}let Y={[is]:n.FUNC_ADD,[pp]:n.FUNC_SUBTRACT,[mp]:n.FUNC_REVERSE_SUBTRACT};if(i)Y[tu]=n.MIN,Y[eu]=n.MAX;else{let D=t.get("EXT_blend_minmax");D!==null&&(Y[tu]=D.MIN_EXT,Y[eu]=D.MAX_EXT)}let K={[gp]:n.ZERO,[xp]:n.ONE,[_p]:n.SRC_COLOR,[tl]:n.SRC_ALPHA,[bp]:n.SRC_ALPHA_SATURATE,[Ep]:n.DST_COLOR,[vp]:n.DST_ALPHA,[yp]:n.ONE_MINUS_SRC_COLOR,[el]:n.ONE_MINUS_SRC_ALPHA,[Sp]:n.ONE_MINUS_DST_COLOR,[Mp]:n.ONE_MINUS_DST_ALPHA,[Tp]:n.CONSTANT_COLOR,[wp]:n.ONE_MINUS_CONSTANT_COLOR,[Ap]:n.CONSTANT_ALPHA,[Rp]:n.ONE_MINUS_CONSTANT_ALPHA};function q(D,yt,vt,Wt,Ht,ve,Me,Ke,dn,Ee){if(D===Fi){m===!0&&(ct(n.BLEND),m=!1);return}if(m===!1&&(tt(n.BLEND),m=!0),D!==dp){if(D!==S||Ee!==U){if((y!==is||A!==is)&&(n.blendEquation(n.FUNC_ADD),y=is,A=is),Ee)switch(D){case zi:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Gi:n.blendFunc(n.ONE,n.ONE);break;case jh:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Qh:n.blendFuncSeparate(n.ZERO,n.SRC_COLOR,n.ZERO,n.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}else switch(D){case zi:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Gi:n.blendFunc(n.SRC_ALPHA,n.ONE);break;case jh:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Qh:n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}b=null,C=null,R=null,O=null,E.set(0,0,0),M=0,S=D,U=Ee}return}Ht=Ht||yt,ve=ve||vt,Me=Me||Wt,(yt!==y||Ht!==A)&&(n.blendEquationSeparate(Y[yt],Y[Ht]),y=yt,A=Ht),(vt!==b||Wt!==C||ve!==R||Me!==O)&&(n.blendFuncSeparate(K[vt],K[Wt],K[ve],K[Me]),b=vt,C=Wt,R=ve,O=Me),(Ke.equals(E)===!1||dn!==M)&&(n.blendColor(Ke.r,Ke.g,Ke.b,dn),E.copy(Ke),M=dn),S=D,U=!1}function Rt(D,yt){D.side===He?ct(n.CULL_FACE):tt(n.CULL_FACE);let vt=D.side===un;yt&&(vt=!vt),xt(vt),D.blending===zi&&D.transparent===!1?q(Fi):q(D.blending,D.blendEquation,D.blendSrc,D.blendDst,D.blendEquationAlpha,D.blendSrcAlpha,D.blendDstAlpha,D.blendColor,D.blendAlpha,D.premultipliedAlpha),c.setFunc(D.depthFunc),c.setTest(D.depthTest),c.setMask(D.depthWrite),o.setMask(D.colorWrite);let Wt=D.stencilWrite;l.setTest(Wt),Wt&&(l.setMask(D.stencilWriteMask),l.setFunc(D.stencilFunc,D.stencilRef,D.stencilFuncMask),l.setOp(D.stencilFail,D.stencilZFail,D.stencilZPass)),L(D.polygonOffset,D.polygonOffsetFactor,D.polygonOffsetUnits),D.alphaToCoverage===!0?tt(n.SAMPLE_ALPHA_TO_COVERAGE):ct(n.SAMPLE_ALPHA_TO_COVERAGE)}function xt(D){H!==D&&(D?n.frontFace(n.CW):n.frontFace(n.CCW),H=D)}function v(D){D!==up?(tt(n.CULL_FACE),D!==rt&&(D===Kh?n.cullFace(n.BACK):D===fp?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):ct(n.CULL_FACE),rt=D}function _(D){D!==I&&(j&&n.lineWidth(D),I=D)}function L(D,yt,vt){D?(tt(n.POLYGON_OFFSET_FILL),(F!==yt||B!==vt)&&(n.polygonOffset(yt,vt),F=yt,B=vt)):ct(n.POLYGON_OFFSET_FILL)}function k(D){D?tt(n.SCISSOR_TEST):ct(n.SCISSOR_TEST)}function W(D){D===void 0&&(D=n.TEXTURE0+et-1),nt!==D&&(n.activeTexture(D),nt=D)}function Z(D,yt,vt){vt===void 0&&(nt===null?vt=n.TEXTURE0+et-1:vt=nt);let Wt=gt[vt];Wt===void 0&&(Wt={type:void 0,texture:void 0},gt[vt]=Wt),(Wt.type!==D||Wt.texture!==yt)&&(nt!==vt&&(n.activeTexture(vt),nt=vt),n.bindTexture(D,yt||zt[D]),Wt.type=D,Wt.texture=yt)}function Et(){let D=gt[nt];D!==void 0&&D.type!==void 0&&(n.bindTexture(D.type,null),D.type=void 0,D.texture=void 0)}function lt(){try{n.compressedTexImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function St(){try{n.compressedTexImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ot(){try{n.texSubImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Yt(){try{n.texSubImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function at(){try{n.compressedTexSubImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function fe(){try{n.compressedTexSubImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function se(){try{n.texStorage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function qt(){try{n.texStorage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Bt(){try{n.texImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Lt(){try{n.texImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Kt(D){ut.equals(D)===!1&&(n.scissor(D.x,D.y,D.z,D.w),ut.copy(D))}function ge(D){Pt.equals(D)===!1&&(n.viewport(D.x,D.y,D.z,D.w),Pt.copy(D))}function Ne(D,yt){let vt=u.get(yt);vt===void 0&&(vt=new WeakMap,u.set(yt,vt));let Wt=vt.get(D);Wt===void 0&&(Wt=n.getUniformBlockIndex(yt,D.name),vt.set(D,Wt))}function ee(D,yt){let Wt=u.get(yt).get(D);h.get(yt)!==Wt&&(n.uniformBlockBinding(yt,Wt,D.__bindingPointIndex),h.set(yt,Wt))}function ft(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),i===!0&&(n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null)),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),f={},nt=null,gt={},d={},p=new WeakMap,x=[],g=null,m=!1,S=null,y=null,b=null,C=null,A=null,R=null,O=null,E=new Ft(0,0,0),M=0,U=!1,H=null,rt=null,I=null,F=null,B=null,ut.set(0,0,n.canvas.width,n.canvas.height),Pt.set(0,0,n.canvas.width,n.canvas.height),o.reset(),c.reset(),l.reset()}return{buffers:{color:o,depth:c,stencil:l},enable:tt,disable:ct,bindFramebuffer:mt,drawBuffers:w,useProgram:st,setBlending:q,setMaterial:Rt,setFlipSided:xt,setCullFace:v,setLineWidth:_,setPolygonOffset:L,setScissorTest:k,activeTexture:W,bindTexture:Z,unbindTexture:Et,compressedTexImage2D:lt,compressedTexImage3D:St,texImage2D:Bt,texImage3D:Lt,updateUBOMapping:Ne,uniformBlockBinding:ee,texStorage2D:se,texStorage3D:qt,texSubImage2D:Ot,texSubImage3D:Yt,compressedTexSubImage2D:at,compressedTexSubImage3D:fe,scissor:Kt,viewport:ge,reset:ft}}function ly(n,t,e,i,s,r,a){let o=s.isWebGL2,c=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap,u,f=new WeakMap,d=!1;try{d=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function p(v,_){return d?new OffscreenCanvas(v,_):uo("canvas")}function x(v,_,L,k){let W=1;if((v.width>k||v.height>k)&&(W=k/Math.max(v.width,v.height)),W<1||_===!0)if(typeof HTMLImageElement<"u"&&v instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&v instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&v instanceof ImageBitmap){let Z=_?ho:Math.floor,Et=Z(W*v.width),lt=Z(W*v.height);u===void 0&&(u=p(Et,lt));let St=L?p(Et,lt):u;return St.width=Et,St.height=lt,St.getContext("2d").drawImage(v,0,0,Et,lt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+v.width+"x"+v.height+") to ("+Et+"x"+lt+")."),St}else return"data"in v&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+v.width+"x"+v.height+")."),v;return v}function g(v){return ol(v.width)&&ol(v.height)}function m(v){return o?!1:v.wrapS!==Zn||v.wrapT!==Zn||v.minFilter!==tn&&v.minFilter!==Nn}function S(v,_){return v.generateMipmaps&&_&&v.minFilter!==tn&&v.minFilter!==Nn}function y(v){n.generateMipmap(v)}function b(v,_,L,k,W=!1){if(o===!1)return _;if(v!==null){if(n[v]!==void 0)return n[v];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+v+"'")}let Z=_;if(_===n.RED&&(L===n.FLOAT&&(Z=n.R32F),L===n.HALF_FLOAT&&(Z=n.R16F),L===n.UNSIGNED_BYTE&&(Z=n.R8)),_===n.RED_INTEGER&&(L===n.UNSIGNED_BYTE&&(Z=n.R8UI),L===n.UNSIGNED_SHORT&&(Z=n.R16UI),L===n.UNSIGNED_INT&&(Z=n.R32UI),L===n.BYTE&&(Z=n.R8I),L===n.SHORT&&(Z=n.R16I),L===n.INT&&(Z=n.R32I)),_===n.RG&&(L===n.FLOAT&&(Z=n.RG32F),L===n.HALF_FLOAT&&(Z=n.RG16F),L===n.UNSIGNED_BYTE&&(Z=n.RG8)),_===n.RGBA){let Et=W?ao:_e.getTransfer(k);L===n.FLOAT&&(Z=n.RGBA32F),L===n.HALF_FLOAT&&(Z=n.RGBA16F),L===n.UNSIGNED_BYTE&&(Z=Et===we?n.SRGB8_ALPHA8:n.RGBA8),L===n.UNSIGNED_SHORT_4_4_4_4&&(Z=n.RGBA4),L===n.UNSIGNED_SHORT_5_5_5_1&&(Z=n.RGB5_A1)}return(Z===n.R16F||Z===n.R32F||Z===n.RG16F||Z===n.RG32F||Z===n.RGBA16F||Z===n.RGBA32F)&&t.get("EXT_color_buffer_float"),Z}function C(v,_,L){return S(v,L)===!0||v.isFramebufferTexture&&v.minFilter!==tn&&v.minFilter!==Nn?Math.log2(Math.max(_.width,_.height))+1:v.mipmaps!==void 0&&v.mipmaps.length>0?v.mipmaps.length:v.isCompressedTexture&&Array.isArray(v.image)?_.mipmaps.length:1}function A(v){return v===tn||v===nu||v===vc?n.NEAREST:n.LINEAR}function R(v){let _=v.target;_.removeEventListener("dispose",R),E(_),_.isVideoTexture&&h.delete(_)}function O(v){let _=v.target;_.removeEventListener("dispose",O),U(_)}function E(v){let _=i.get(v);if(_.__webglInit===void 0)return;let L=v.source,k=f.get(L);if(k){let W=k[_.__cacheKey];W.usedTimes--,W.usedTimes===0&&M(v),Object.keys(k).length===0&&f.delete(L)}i.remove(v)}function M(v){let _=i.get(v);n.deleteTexture(_.__webglTexture);let L=v.source,k=f.get(L);delete k[_.__cacheKey],a.memory.textures--}function U(v){let _=v.texture,L=i.get(v),k=i.get(_);if(k.__webglTexture!==void 0&&(n.deleteTexture(k.__webglTexture),a.memory.textures--),v.depthTexture&&v.depthTexture.dispose(),v.isWebGLCubeRenderTarget)for(let W=0;W<6;W++){if(Array.isArray(L.__webglFramebuffer[W]))for(let Z=0;Z<L.__webglFramebuffer[W].length;Z++)n.deleteFramebuffer(L.__webglFramebuffer[W][Z]);else n.deleteFramebuffer(L.__webglFramebuffer[W]);L.__webglDepthbuffer&&n.deleteRenderbuffer(L.__webglDepthbuffer[W])}else{if(Array.isArray(L.__webglFramebuffer))for(let W=0;W<L.__webglFramebuffer.length;W++)n.deleteFramebuffer(L.__webglFramebuffer[W]);else n.deleteFramebuffer(L.__webglFramebuffer);if(L.__webglDepthbuffer&&n.deleteRenderbuffer(L.__webglDepthbuffer),L.__webglMultisampledFramebuffer&&n.deleteFramebuffer(L.__webglMultisampledFramebuffer),L.__webglColorRenderbuffer)for(let W=0;W<L.__webglColorRenderbuffer.length;W++)L.__webglColorRenderbuffer[W]&&n.deleteRenderbuffer(L.__webglColorRenderbuffer[W]);L.__webglDepthRenderbuffer&&n.deleteRenderbuffer(L.__webglDepthRenderbuffer)}if(v.isWebGLMultipleRenderTargets)for(let W=0,Z=_.length;W<Z;W++){let Et=i.get(_[W]);Et.__webglTexture&&(n.deleteTexture(Et.__webglTexture),a.memory.textures--),i.remove(_[W])}i.remove(_),i.remove(v)}let H=0;function rt(){H=0}function I(){let v=H;return v>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+v+" texture units while this GPU supports only "+s.maxTextures),H+=1,v}function F(v){let _=[];return _.push(v.wrapS),_.push(v.wrapT),_.push(v.wrapR||0),_.push(v.magFilter),_.push(v.minFilter),_.push(v.anisotropy),_.push(v.internalFormat),_.push(v.format),_.push(v.type),_.push(v.generateMipmaps),_.push(v.premultiplyAlpha),_.push(v.flipY),_.push(v.unpackAlignment),_.push(v.colorSpace),_.join()}function B(v,_){let L=i.get(v);if(v.isVideoTexture&&Rt(v),v.isRenderTargetTexture===!1&&v.version>0&&L.__version!==v.version){let k=v.image;if(k===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(k.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{ut(L,v,_);return}}e.bindTexture(n.TEXTURE_2D,L.__webglTexture,n.TEXTURE0+_)}function et(v,_){let L=i.get(v);if(v.version>0&&L.__version!==v.version){ut(L,v,_);return}e.bindTexture(n.TEXTURE_2D_ARRAY,L.__webglTexture,n.TEXTURE0+_)}function j(v,_){let L=i.get(v);if(v.version>0&&L.__version!==v.version){ut(L,v,_);return}e.bindTexture(n.TEXTURE_3D,L.__webglTexture,n.TEXTURE0+_)}function J(v,_){let L=i.get(v);if(v.version>0&&L.__version!==v.version){Pt(L,v,_);return}e.bindTexture(n.TEXTURE_CUBE_MAP,L.__webglTexture,n.TEXTURE0+_)}let it={[Wr]:n.REPEAT,[Zn]:n.CLAMP_TO_EDGE,[sl]:n.MIRRORED_REPEAT},nt={[tn]:n.NEAREST,[nu]:n.NEAREST_MIPMAP_NEAREST,[vc]:n.NEAREST_MIPMAP_LINEAR,[Nn]:n.LINEAR,[Vp]:n.LINEAR_MIPMAP_NEAREST,[Xr]:n.LINEAR_MIPMAP_LINEAR},gt={[e0]:n.NEVER,[o0]:n.ALWAYS,[n0]:n.LESS,[Vf]:n.LEQUAL,[i0]:n.EQUAL,[a0]:n.GEQUAL,[s0]:n.GREATER,[r0]:n.NOTEQUAL};function $(v,_,L){if(L?(n.texParameteri(v,n.TEXTURE_WRAP_S,it[_.wrapS]),n.texParameteri(v,n.TEXTURE_WRAP_T,it[_.wrapT]),(v===n.TEXTURE_3D||v===n.TEXTURE_2D_ARRAY)&&n.texParameteri(v,n.TEXTURE_WRAP_R,it[_.wrapR]),n.texParameteri(v,n.TEXTURE_MAG_FILTER,nt[_.magFilter]),n.texParameteri(v,n.TEXTURE_MIN_FILTER,nt[_.minFilter])):(n.texParameteri(v,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(v,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE),(v===n.TEXTURE_3D||v===n.TEXTURE_2D_ARRAY)&&n.texParameteri(v,n.TEXTURE_WRAP_R,n.CLAMP_TO_EDGE),(_.wrapS!==Zn||_.wrapT!==Zn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),n.texParameteri(v,n.TEXTURE_MAG_FILTER,A(_.magFilter)),n.texParameteri(v,n.TEXTURE_MIN_FILTER,A(_.minFilter)),_.minFilter!==tn&&_.minFilter!==Nn&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),_.compareFunction&&(n.texParameteri(v,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(v,n.TEXTURE_COMPARE_FUNC,gt[_.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){let k=t.get("EXT_texture_filter_anisotropic");if(_.magFilter===tn||_.minFilter!==vc&&_.minFilter!==Xr||_.type===Oi&&t.has("OES_texture_float_linear")===!1||o===!1&&_.type===Yr&&t.has("OES_texture_half_float_linear")===!1)return;(_.anisotropy>1||i.get(_).__currentAnisotropy)&&(n.texParameterf(v,k.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,s.getMaxAnisotropy())),i.get(_).__currentAnisotropy=_.anisotropy)}}function Q(v,_){let L=!1;v.__webglInit===void 0&&(v.__webglInit=!0,_.addEventListener("dispose",R));let k=_.source,W=f.get(k);W===void 0&&(W={},f.set(k,W));let Z=F(_);if(Z!==v.__cacheKey){W[Z]===void 0&&(W[Z]={texture:n.createTexture(),usedTimes:0},a.memory.textures++,L=!0),W[Z].usedTimes++;let Et=W[v.__cacheKey];Et!==void 0&&(W[v.__cacheKey].usedTimes--,Et.usedTimes===0&&M(_)),v.__cacheKey=Z,v.__webglTexture=W[Z].texture}return L}function ut(v,_,L){let k=n.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(k=n.TEXTURE_2D_ARRAY),_.isData3DTexture&&(k=n.TEXTURE_3D);let W=Q(v,_),Z=_.source;e.bindTexture(k,v.__webglTexture,n.TEXTURE0+L);let Et=i.get(Z);if(Z.version!==Et.__version||W===!0){e.activeTexture(n.TEXTURE0+L);let lt=_e.getPrimaries(_e.workingColorSpace),St=_.colorSpace===On?null:_e.getPrimaries(_.colorSpace),Ot=_.colorSpace===On||lt===St?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ot);let Yt=m(_)&&g(_.image)===!1,at=x(_.image,Yt,!1,s.maxTextureSize);at=xt(_,at);let fe=g(at)||o,se=r.convert(_.format,_.colorSpace),qt=r.convert(_.type),Bt=b(_.internalFormat,se,qt,_.colorSpace,_.isVideoTexture);$(k,_,fe);let Lt,Kt=_.mipmaps,ge=o&&_.isVideoTexture!==!0&&Bt!==Hf,Ne=Et.__version===void 0||W===!0,ee=C(_,at,fe);if(_.isDepthTexture)Bt=n.DEPTH_COMPONENT,o?_.type===Oi?Bt=n.DEPTH_COMPONENT32F:_.type===Ni?Bt=n.DEPTH_COMPONENT24:_.type===as?Bt=n.DEPTH24_STENCIL8:Bt=n.DEPTH_COMPONENT16:_.type===Oi&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),_.format===os&&Bt===n.DEPTH_COMPONENT&&_.type!==ql&&_.type!==Ni&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),_.type=Ni,qt=r.convert(_.type)),_.format===ir&&Bt===n.DEPTH_COMPONENT&&(Bt=n.DEPTH_STENCIL,_.type!==as&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),_.type=as,qt=r.convert(_.type))),Ne&&(ge?e.texStorage2D(n.TEXTURE_2D,1,Bt,at.width,at.height):e.texImage2D(n.TEXTURE_2D,0,Bt,at.width,at.height,0,se,qt,null));else if(_.isDataTexture)if(Kt.length>0&&fe){ge&&Ne&&e.texStorage2D(n.TEXTURE_2D,ee,Bt,Kt[0].width,Kt[0].height);for(let ft=0,D=Kt.length;ft<D;ft++)Lt=Kt[ft],ge?e.texSubImage2D(n.TEXTURE_2D,ft,0,0,Lt.width,Lt.height,se,qt,Lt.data):e.texImage2D(n.TEXTURE_2D,ft,Bt,Lt.width,Lt.height,0,se,qt,Lt.data);_.generateMipmaps=!1}else ge?(Ne&&e.texStorage2D(n.TEXTURE_2D,ee,Bt,at.width,at.height),e.texSubImage2D(n.TEXTURE_2D,0,0,0,at.width,at.height,se,qt,at.data)):e.texImage2D(n.TEXTURE_2D,0,Bt,at.width,at.height,0,se,qt,at.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){ge&&Ne&&e.texStorage3D(n.TEXTURE_2D_ARRAY,ee,Bt,Kt[0].width,Kt[0].height,at.depth);for(let ft=0,D=Kt.length;ft<D;ft++)Lt=Kt[ft],_.format!==Jn?se!==null?ge?e.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,ft,0,0,0,Lt.width,Lt.height,at.depth,se,Lt.data,0,0):e.compressedTexImage3D(n.TEXTURE_2D_ARRAY,ft,Bt,Lt.width,Lt.height,at.depth,0,Lt.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ge?e.texSubImage3D(n.TEXTURE_2D_ARRAY,ft,0,0,0,Lt.width,Lt.height,at.depth,se,qt,Lt.data):e.texImage3D(n.TEXTURE_2D_ARRAY,ft,Bt,Lt.width,Lt.height,at.depth,0,se,qt,Lt.data)}else{ge&&Ne&&e.texStorage2D(n.TEXTURE_2D,ee,Bt,Kt[0].width,Kt[0].height);for(let ft=0,D=Kt.length;ft<D;ft++)Lt=Kt[ft],_.format!==Jn?se!==null?ge?e.compressedTexSubImage2D(n.TEXTURE_2D,ft,0,0,Lt.width,Lt.height,se,Lt.data):e.compressedTexImage2D(n.TEXTURE_2D,ft,Bt,Lt.width,Lt.height,0,Lt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ge?e.texSubImage2D(n.TEXTURE_2D,ft,0,0,Lt.width,Lt.height,se,qt,Lt.data):e.texImage2D(n.TEXTURE_2D,ft,Bt,Lt.width,Lt.height,0,se,qt,Lt.data)}else if(_.isDataArrayTexture)ge?(Ne&&e.texStorage3D(n.TEXTURE_2D_ARRAY,ee,Bt,at.width,at.height,at.depth),e.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,at.width,at.height,at.depth,se,qt,at.data)):e.texImage3D(n.TEXTURE_2D_ARRAY,0,Bt,at.width,at.height,at.depth,0,se,qt,at.data);else if(_.isData3DTexture)ge?(Ne&&e.texStorage3D(n.TEXTURE_3D,ee,Bt,at.width,at.height,at.depth),e.texSubImage3D(n.TEXTURE_3D,0,0,0,0,at.width,at.height,at.depth,se,qt,at.data)):e.texImage3D(n.TEXTURE_3D,0,Bt,at.width,at.height,at.depth,0,se,qt,at.data);else if(_.isFramebufferTexture){if(Ne)if(ge)e.texStorage2D(n.TEXTURE_2D,ee,Bt,at.width,at.height);else{let ft=at.width,D=at.height;for(let yt=0;yt<ee;yt++)e.texImage2D(n.TEXTURE_2D,yt,Bt,ft,D,0,se,qt,null),ft>>=1,D>>=1}}else if(Kt.length>0&&fe){ge&&Ne&&e.texStorage2D(n.TEXTURE_2D,ee,Bt,Kt[0].width,Kt[0].height);for(let ft=0,D=Kt.length;ft<D;ft++)Lt=Kt[ft],ge?e.texSubImage2D(n.TEXTURE_2D,ft,0,0,se,qt,Lt):e.texImage2D(n.TEXTURE_2D,ft,Bt,se,qt,Lt);_.generateMipmaps=!1}else ge?(Ne&&e.texStorage2D(n.TEXTURE_2D,ee,Bt,at.width,at.height),e.texSubImage2D(n.TEXTURE_2D,0,0,0,se,qt,at)):e.texImage2D(n.TEXTURE_2D,0,Bt,se,qt,at);S(_,fe)&&y(k),Et.__version=Z.version,_.onUpdate&&_.onUpdate(_)}v.__version=_.version}function Pt(v,_,L){if(_.image.length!==6)return;let k=Q(v,_),W=_.source;e.bindTexture(n.TEXTURE_CUBE_MAP,v.__webglTexture,n.TEXTURE0+L);let Z=i.get(W);if(W.version!==Z.__version||k===!0){e.activeTexture(n.TEXTURE0+L);let Et=_e.getPrimaries(_e.workingColorSpace),lt=_.colorSpace===On?null:_e.getPrimaries(_.colorSpace),St=_.colorSpace===On||Et===lt?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,St);let Ot=_.isCompressedTexture||_.image[0].isCompressedTexture,Yt=_.image[0]&&_.image[0].isDataTexture,at=[];for(let ft=0;ft<6;ft++)!Ot&&!Yt?at[ft]=x(_.image[ft],!1,!0,s.maxCubemapSize):at[ft]=Yt?_.image[ft].image:_.image[ft],at[ft]=xt(_,at[ft]);let fe=at[0],se=g(fe)||o,qt=r.convert(_.format,_.colorSpace),Bt=r.convert(_.type),Lt=b(_.internalFormat,qt,Bt,_.colorSpace),Kt=o&&_.isVideoTexture!==!0,ge=Z.__version===void 0||k===!0,Ne=C(_,fe,se);$(n.TEXTURE_CUBE_MAP,_,se);let ee;if(Ot){Kt&&ge&&e.texStorage2D(n.TEXTURE_CUBE_MAP,Ne,Lt,fe.width,fe.height);for(let ft=0;ft<6;ft++){ee=at[ft].mipmaps;for(let D=0;D<ee.length;D++){let yt=ee[D];_.format!==Jn?qt!==null?Kt?e.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,D,0,0,yt.width,yt.height,qt,yt.data):e.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,D,Lt,yt.width,yt.height,0,yt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Kt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,D,0,0,yt.width,yt.height,qt,Bt,yt.data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,D,Lt,yt.width,yt.height,0,qt,Bt,yt.data)}}}else{ee=_.mipmaps,Kt&&ge&&(ee.length>0&&Ne++,e.texStorage2D(n.TEXTURE_CUBE_MAP,Ne,Lt,at[0].width,at[0].height));for(let ft=0;ft<6;ft++)if(Yt){Kt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,0,0,at[ft].width,at[ft].height,qt,Bt,at[ft].data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,Lt,at[ft].width,at[ft].height,0,qt,Bt,at[ft].data);for(let D=0;D<ee.length;D++){let vt=ee[D].image[ft].image;Kt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,D+1,0,0,vt.width,vt.height,qt,Bt,vt.data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,D+1,Lt,vt.width,vt.height,0,qt,Bt,vt.data)}}else{Kt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,0,0,qt,Bt,at[ft]):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,Lt,qt,Bt,at[ft]);for(let D=0;D<ee.length;D++){let yt=ee[D];Kt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,D+1,0,0,qt,Bt,yt.image[ft]):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,D+1,Lt,qt,Bt,yt.image[ft])}}}S(_,se)&&y(n.TEXTURE_CUBE_MAP),Z.__version=W.version,_.onUpdate&&_.onUpdate(_)}v.__version=_.version}function Mt(v,_,L,k,W,Z){let Et=r.convert(L.format,L.colorSpace),lt=r.convert(L.type),St=b(L.internalFormat,Et,lt,L.colorSpace);if(!i.get(_).__hasExternalTextures){let Yt=Math.max(1,_.width>>Z),at=Math.max(1,_.height>>Z);W===n.TEXTURE_3D||W===n.TEXTURE_2D_ARRAY?e.texImage3D(W,Z,St,Yt,at,_.depth,0,Et,lt,null):e.texImage2D(W,Z,St,Yt,at,0,Et,lt,null)}e.bindFramebuffer(n.FRAMEBUFFER,v),q(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,k,W,i.get(L).__webglTexture,0,K(_)):(W===n.TEXTURE_2D||W>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&W<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,k,W,i.get(L).__webglTexture,Z),e.bindFramebuffer(n.FRAMEBUFFER,null)}function zt(v,_,L){if(n.bindRenderbuffer(n.RENDERBUFFER,v),_.depthBuffer&&!_.stencilBuffer){let k=o===!0?n.DEPTH_COMPONENT24:n.DEPTH_COMPONENT16;if(L||q(_)){let W=_.depthTexture;W&&W.isDepthTexture&&(W.type===Oi?k=n.DEPTH_COMPONENT32F:W.type===Ni&&(k=n.DEPTH_COMPONENT24));let Z=K(_);q(_)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Z,k,_.width,_.height):n.renderbufferStorageMultisample(n.RENDERBUFFER,Z,k,_.width,_.height)}else n.renderbufferStorage(n.RENDERBUFFER,k,_.width,_.height);n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.RENDERBUFFER,v)}else if(_.depthBuffer&&_.stencilBuffer){let k=K(_);L&&q(_)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,k,n.DEPTH24_STENCIL8,_.width,_.height):q(_)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,k,n.DEPTH24_STENCIL8,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,n.DEPTH_STENCIL,_.width,_.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.RENDERBUFFER,v)}else{let k=_.isWebGLMultipleRenderTargets===!0?_.texture:[_.texture];for(let W=0;W<k.length;W++){let Z=k[W],Et=r.convert(Z.format,Z.colorSpace),lt=r.convert(Z.type),St=b(Z.internalFormat,Et,lt,Z.colorSpace),Ot=K(_);L&&q(_)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,Ot,St,_.width,_.height):q(_)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Ot,St,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,St,_.width,_.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function tt(v,_){if(_&&_.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(n.FRAMEBUFFER,v),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!i.get(_.depthTexture).__webglTexture||_.depthTexture.image.width!==_.width||_.depthTexture.image.height!==_.height)&&(_.depthTexture.image.width=_.width,_.depthTexture.image.height=_.height,_.depthTexture.needsUpdate=!0),B(_.depthTexture,0);let k=i.get(_.depthTexture).__webglTexture,W=K(_);if(_.depthTexture.format===os)q(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,k,0,W):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,k,0);else if(_.depthTexture.format===ir)q(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,k,0,W):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,k,0);else throw new Error("Unknown depthTexture format")}function ct(v){let _=i.get(v),L=v.isWebGLCubeRenderTarget===!0;if(v.depthTexture&&!_.__autoAllocateDepthBuffer){if(L)throw new Error("target.depthTexture not supported in Cube render targets");tt(_.__webglFramebuffer,v)}else if(L){_.__webglDepthbuffer=[];for(let k=0;k<6;k++)e.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer[k]),_.__webglDepthbuffer[k]=n.createRenderbuffer(),zt(_.__webglDepthbuffer[k],v,!1)}else e.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer=n.createRenderbuffer(),zt(_.__webglDepthbuffer,v,!1);e.bindFramebuffer(n.FRAMEBUFFER,null)}function mt(v,_,L){let k=i.get(v);_!==void 0&&Mt(k.__webglFramebuffer,v,v.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),L!==void 0&&ct(v)}function w(v){let _=v.texture,L=i.get(v),k=i.get(_);v.addEventListener("dispose",O),v.isWebGLMultipleRenderTargets!==!0&&(k.__webglTexture===void 0&&(k.__webglTexture=n.createTexture()),k.__version=_.version,a.memory.textures++);let W=v.isWebGLCubeRenderTarget===!0,Z=v.isWebGLMultipleRenderTargets===!0,Et=g(v)||o;if(W){L.__webglFramebuffer=[];for(let lt=0;lt<6;lt++)if(o&&_.mipmaps&&_.mipmaps.length>0){L.__webglFramebuffer[lt]=[];for(let St=0;St<_.mipmaps.length;St++)L.__webglFramebuffer[lt][St]=n.createFramebuffer()}else L.__webglFramebuffer[lt]=n.createFramebuffer()}else{if(o&&_.mipmaps&&_.mipmaps.length>0){L.__webglFramebuffer=[];for(let lt=0;lt<_.mipmaps.length;lt++)L.__webglFramebuffer[lt]=n.createFramebuffer()}else L.__webglFramebuffer=n.createFramebuffer();if(Z)if(s.drawBuffers){let lt=v.texture;for(let St=0,Ot=lt.length;St<Ot;St++){let Yt=i.get(lt[St]);Yt.__webglTexture===void 0&&(Yt.__webglTexture=n.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&v.samples>0&&q(v)===!1){let lt=Z?_:[_];L.__webglMultisampledFramebuffer=n.createFramebuffer(),L.__webglColorRenderbuffer=[],e.bindFramebuffer(n.FRAMEBUFFER,L.__webglMultisampledFramebuffer);for(let St=0;St<lt.length;St++){let Ot=lt[St];L.__webglColorRenderbuffer[St]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,L.__webglColorRenderbuffer[St]);let Yt=r.convert(Ot.format,Ot.colorSpace),at=r.convert(Ot.type),fe=b(Ot.internalFormat,Yt,at,Ot.colorSpace,v.isXRRenderTarget===!0),se=K(v);n.renderbufferStorageMultisample(n.RENDERBUFFER,se,fe,v.width,v.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+St,n.RENDERBUFFER,L.__webglColorRenderbuffer[St])}n.bindRenderbuffer(n.RENDERBUFFER,null),v.depthBuffer&&(L.__webglDepthRenderbuffer=n.createRenderbuffer(),zt(L.__webglDepthRenderbuffer,v,!0)),e.bindFramebuffer(n.FRAMEBUFFER,null)}}if(W){e.bindTexture(n.TEXTURE_CUBE_MAP,k.__webglTexture),$(n.TEXTURE_CUBE_MAP,_,Et);for(let lt=0;lt<6;lt++)if(o&&_.mipmaps&&_.mipmaps.length>0)for(let St=0;St<_.mipmaps.length;St++)Mt(L.__webglFramebuffer[lt][St],v,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+lt,St);else Mt(L.__webglFramebuffer[lt],v,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+lt,0);S(_,Et)&&y(n.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(Z){let lt=v.texture;for(let St=0,Ot=lt.length;St<Ot;St++){let Yt=lt[St],at=i.get(Yt);e.bindTexture(n.TEXTURE_2D,at.__webglTexture),$(n.TEXTURE_2D,Yt,Et),Mt(L.__webglFramebuffer,v,Yt,n.COLOR_ATTACHMENT0+St,n.TEXTURE_2D,0),S(Yt,Et)&&y(n.TEXTURE_2D)}e.unbindTexture()}else{let lt=n.TEXTURE_2D;if((v.isWebGL3DRenderTarget||v.isWebGLArrayRenderTarget)&&(o?lt=v.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(lt,k.__webglTexture),$(lt,_,Et),o&&_.mipmaps&&_.mipmaps.length>0)for(let St=0;St<_.mipmaps.length;St++)Mt(L.__webglFramebuffer[St],v,_,n.COLOR_ATTACHMENT0,lt,St);else Mt(L.__webglFramebuffer,v,_,n.COLOR_ATTACHMENT0,lt,0);S(_,Et)&&y(lt),e.unbindTexture()}v.depthBuffer&&ct(v)}function st(v){let _=g(v)||o,L=v.isWebGLMultipleRenderTargets===!0?v.texture:[v.texture];for(let k=0,W=L.length;k<W;k++){let Z=L[k];if(S(Z,_)){let Et=v.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:n.TEXTURE_2D,lt=i.get(Z).__webglTexture;e.bindTexture(Et,lt),y(Et),e.unbindTexture()}}}function Y(v){if(o&&v.samples>0&&q(v)===!1){let _=v.isWebGLMultipleRenderTargets?v.texture:[v.texture],L=v.width,k=v.height,W=n.COLOR_BUFFER_BIT,Z=[],Et=v.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,lt=i.get(v),St=v.isWebGLMultipleRenderTargets===!0;if(St)for(let Ot=0;Ot<_.length;Ot++)e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ot,n.RENDERBUFFER,null),e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ot,n.TEXTURE_2D,null,0);e.bindFramebuffer(n.READ_FRAMEBUFFER,lt.__webglMultisampledFramebuffer),e.bindFramebuffer(n.DRAW_FRAMEBUFFER,lt.__webglFramebuffer);for(let Ot=0;Ot<_.length;Ot++){Z.push(n.COLOR_ATTACHMENT0+Ot),v.depthBuffer&&Z.push(Et);let Yt=lt.__ignoreDepthValues!==void 0?lt.__ignoreDepthValues:!1;if(Yt===!1&&(v.depthBuffer&&(W|=n.DEPTH_BUFFER_BIT),v.stencilBuffer&&(W|=n.STENCIL_BUFFER_BIT)),St&&n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,lt.__webglColorRenderbuffer[Ot]),Yt===!0&&(n.invalidateFramebuffer(n.READ_FRAMEBUFFER,[Et]),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[Et])),St){let at=i.get(_[Ot]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,at,0)}n.blitFramebuffer(0,0,L,k,0,0,L,k,W,n.NEAREST),l&&n.invalidateFramebuffer(n.READ_FRAMEBUFFER,Z)}if(e.bindFramebuffer(n.READ_FRAMEBUFFER,null),e.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),St)for(let Ot=0;Ot<_.length;Ot++){e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ot,n.RENDERBUFFER,lt.__webglColorRenderbuffer[Ot]);let Yt=i.get(_[Ot]).__webglTexture;e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ot,n.TEXTURE_2D,Yt,0)}e.bindFramebuffer(n.DRAW_FRAMEBUFFER,lt.__webglMultisampledFramebuffer)}}function K(v){return Math.min(s.maxSamples,v.samples)}function q(v){let _=i.get(v);return o&&v.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function Rt(v){let _=a.render.frame;h.get(v)!==_&&(h.set(v,_),v.update())}function xt(v,_){let L=v.colorSpace,k=v.format,W=v.type;return v.isCompressedTexture===!0||v.isVideoTexture===!0||v.format===al||L!==_i&&L!==On&&(_e.getTransfer(L)===we?o===!1?t.has("EXT_sRGB")===!0&&k===Jn?(v.format=al,v.minFilter=Nn,v.generateMipmaps=!1):_=fo.sRGBToLinear(_):(k!==Jn||W!==Hi)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",L)),_}this.allocateTextureUnit=I,this.resetTextureUnits=rt,this.setTexture2D=B,this.setTexture2DArray=et,this.setTexture3D=j,this.setTextureCube=J,this.rebindTextures=mt,this.setupRenderTarget=w,this.updateRenderTargetMipmap=st,this.updateMultisampleRenderTarget=Y,this.setupDepthRenderbuffer=ct,this.setupFrameBufferTexture=Mt,this.useMultisampledRTT=q}function hy(n,t,e){let i=e.isWebGL2;function s(r,a=On){let o,c=_e.getTransfer(a);if(r===Hi)return n.UNSIGNED_BYTE;if(r===Nf)return n.UNSIGNED_SHORT_4_4_4_4;if(r===Of)return n.UNSIGNED_SHORT_5_5_5_1;if(r===Wp)return n.BYTE;if(r===Xp)return n.SHORT;if(r===ql)return n.UNSIGNED_SHORT;if(r===Uf)return n.INT;if(r===Ni)return n.UNSIGNED_INT;if(r===Oi)return n.FLOAT;if(r===Yr)return i?n.HALF_FLOAT:(o=t.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(r===Yp)return n.ALPHA;if(r===Jn)return n.RGBA;if(r===$p)return n.LUMINANCE;if(r===qp)return n.LUMINANCE_ALPHA;if(r===os)return n.DEPTH_COMPONENT;if(r===ir)return n.DEPTH_STENCIL;if(r===al)return o=t.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(r===Zp)return n.RED;if(r===Ff)return n.RED_INTEGER;if(r===Jp)return n.RG;if(r===zf)return n.RG_INTEGER;if(r===Bf)return n.RGBA_INTEGER;if(r===Mc||r===Ec||r===Sc||r===bc)if(c===we)if(o=t.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(r===Mc)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===Ec)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===Sc)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===bc)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=t.get("WEBGL_compressed_texture_s3tc"),o!==null){if(r===Mc)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===Ec)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===Sc)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===bc)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===iu||r===su||r===ru||r===au)if(o=t.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(r===iu)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===su)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===ru)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===au)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===Hf)return o=t.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===ou||r===cu)if(o=t.get("WEBGL_compressed_texture_etc"),o!==null){if(r===ou)return c===we?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(r===cu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===lu||r===hu||r===uu||r===fu||r===du||r===pu||r===mu||r===gu||r===xu||r===_u||r===yu||r===vu||r===Mu||r===Eu)if(o=t.get("WEBGL_compressed_texture_astc"),o!==null){if(r===lu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===hu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===uu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===fu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===du)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===pu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===mu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===gu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===xu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===_u)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===yu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===vu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Mu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===Eu)return c===we?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===Tc||r===Su||r===bu)if(o=t.get("EXT_texture_compression_bptc"),o!==null){if(r===Tc)return c===we?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===Su)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===bu)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===Kp||r===Tu||r===wu||r===Au)if(o=t.get("EXT_texture_compression_rgtc"),o!==null){if(r===Tc)return o.COMPRESSED_RED_RGTC1_EXT;if(r===Tu)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===wu)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===Au)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===as?i?n.UNSIGNED_INT_24_8:(o=t.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):n[r]!==void 0?n[r]:null}return{convert:s}}var vl=class extends xn{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},bt=class extends $e{constructor(){super(),this.isGroup=!0,this.type="Group"}},uy={type:"move"},Hr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new bt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new bt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new P,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new P),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new bt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new P,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new P),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let i of t.hand.values())this._getHandJoint(e,i)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,i){let s=null,r=null,a=null,o=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){a=!0;for(let x of t.hand.values()){let g=e.getJointPose(x,i),m=this._getHandJoint(l,x);g!==null&&(m.matrix.fromArray(g.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,m.jointRadius=g.radius),m.visible=g!==null}let h=l.joints["index-finger-tip"],u=l.joints["thumb-tip"],f=h.position.distanceTo(u.position),d=.02,p=.005;l.inputState.pinching&&f>d+p?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&f<=d-p&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,i),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));o!==null&&(s=e.getPose(t.targetRaySpace,i),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(uy)))}return o!==null&&(o.visible=s!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let i=new bt;i.matrixAutoUpdate=!1,i.visible=!1,t.joints[e.jointName]=i,t.add(i)}return t.joints[e.jointName]}},Ml=class extends Vi{constructor(t,e){super();let i=this,s=null,r=1,a=null,o="local-floor",c=1,l=null,h=null,u=null,f=null,d=null,p=null,x=e.getContextAttributes(),g=null,m=null,S=[],y=[],b=new ht,C=null,A=new xn;A.layers.enable(1),A.viewport=new en;let R=new xn;R.layers.enable(2),R.viewport=new en;let O=[A,R],E=new vl;E.layers.enable(1),E.layers.enable(2);let M=null,U=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function($){let Q=S[$];return Q===void 0&&(Q=new Hr,S[$]=Q),Q.getTargetRaySpace()},this.getControllerGrip=function($){let Q=S[$];return Q===void 0&&(Q=new Hr,S[$]=Q),Q.getGripSpace()},this.getHand=function($){let Q=S[$];return Q===void 0&&(Q=new Hr,S[$]=Q),Q.getHandSpace()};function H($){let Q=y.indexOf($.inputSource);if(Q===-1)return;let ut=S[Q];ut!==void 0&&(ut.update($.inputSource,$.frame,l||a),ut.dispatchEvent({type:$.type,data:$.inputSource}))}function rt(){s.removeEventListener("select",H),s.removeEventListener("selectstart",H),s.removeEventListener("selectend",H),s.removeEventListener("squeeze",H),s.removeEventListener("squeezestart",H),s.removeEventListener("squeezeend",H),s.removeEventListener("end",rt),s.removeEventListener("inputsourceschange",I);for(let $=0;$<S.length;$++){let Q=y[$];Q!==null&&(y[$]=null,S[$].disconnect(Q))}M=null,U=null,t.setRenderTarget(g),d=null,f=null,u=null,s=null,m=null,gt.stop(),i.isPresenting=!1,t.setPixelRatio(C),t.setSize(b.width,b.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function($){r=$,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function($){o=$,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function($){l=$},this.getBaseLayer=function(){return f!==null?f:d},this.getBinding=function(){return u},this.getFrame=function(){return p},this.getSession=function(){return s},this.setSession=async function($){if(s=$,s!==null){if(g=t.getRenderTarget(),s.addEventListener("select",H),s.addEventListener("selectstart",H),s.addEventListener("selectend",H),s.addEventListener("squeeze",H),s.addEventListener("squeezestart",H),s.addEventListener("squeezeend",H),s.addEventListener("end",rt),s.addEventListener("inputsourceschange",I),x.xrCompatible!==!0&&await e.makeXRCompatible(),C=t.getPixelRatio(),t.getSize(b),s.renderState.layers===void 0||t.capabilities.isWebGL2===!1){let Q={antialias:s.renderState.layers===void 0?x.antialias:!0,alpha:!0,depth:x.depth,stencil:x.stencil,framebufferScaleFactor:r};d=new XRWebGLLayer(s,e,Q),s.updateRenderState({baseLayer:d}),t.setPixelRatio(1),t.setSize(d.framebufferWidth,d.framebufferHeight,!1),m=new yi(d.framebufferWidth,d.framebufferHeight,{format:Jn,type:Hi,colorSpace:t.outputColorSpace,stencilBuffer:x.stencil})}else{let Q=null,ut=null,Pt=null;x.depth&&(Pt=x.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,Q=x.stencil?ir:os,ut=x.stencil?as:Ni);let Mt={colorFormat:e.RGBA8,depthFormat:Pt,scaleFactor:r};u=new XRWebGLBinding(s,e),f=u.createProjectionLayer(Mt),s.updateRenderState({layers:[f]}),t.setPixelRatio(1),t.setSize(f.textureWidth,f.textureHeight,!1),m=new yi(f.textureWidth,f.textureHeight,{format:Jn,type:Hi,depthTexture:new So(f.textureWidth,f.textureHeight,ut,void 0,void 0,void 0,void 0,void 0,void 0,Q),stencilBuffer:x.stencil,colorSpace:t.outputColorSpace,samples:x.antialias?4:0});let zt=t.properties.get(m);zt.__ignoreDepthValues=f.ignoreDepthValues}m.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await s.requestReferenceSpace(o),gt.setContext(s),gt.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode};function I($){for(let Q=0;Q<$.removed.length;Q++){let ut=$.removed[Q],Pt=y.indexOf(ut);Pt>=0&&(y[Pt]=null,S[Pt].disconnect(ut))}for(let Q=0;Q<$.added.length;Q++){let ut=$.added[Q],Pt=y.indexOf(ut);if(Pt===-1){for(let zt=0;zt<S.length;zt++)if(zt>=y.length){y.push(ut),Pt=zt;break}else if(y[zt]===null){y[zt]=ut,Pt=zt;break}if(Pt===-1)break}let Mt=S[Pt];Mt&&Mt.connect(ut)}}let F=new P,B=new P;function et($,Q,ut){F.setFromMatrixPosition(Q.matrixWorld),B.setFromMatrixPosition(ut.matrixWorld);let Pt=F.distanceTo(B),Mt=Q.projectionMatrix.elements,zt=ut.projectionMatrix.elements,tt=Mt[14]/(Mt[10]-1),ct=Mt[14]/(Mt[10]+1),mt=(Mt[9]+1)/Mt[5],w=(Mt[9]-1)/Mt[5],st=(Mt[8]-1)/Mt[0],Y=(zt[8]+1)/zt[0],K=tt*st,q=tt*Y,Rt=Pt/(-st+Y),xt=Rt*-st;Q.matrixWorld.decompose($.position,$.quaternion,$.scale),$.translateX(xt),$.translateZ(Rt),$.matrixWorld.compose($.position,$.quaternion,$.scale),$.matrixWorldInverse.copy($.matrixWorld).invert();let v=tt+Rt,_=ct+Rt,L=K-xt,k=q+(Pt-xt),W=mt*ct/_*v,Z=w*ct/_*v;$.projectionMatrix.makePerspective(L,k,W,Z,v,_),$.projectionMatrixInverse.copy($.projectionMatrix).invert()}function j($,Q){Q===null?$.matrixWorld.copy($.matrix):$.matrixWorld.multiplyMatrices(Q.matrixWorld,$.matrix),$.matrixWorldInverse.copy($.matrixWorld).invert()}this.updateCamera=function($){if(s===null)return;E.near=R.near=A.near=$.near,E.far=R.far=A.far=$.far,(M!==E.near||U!==E.far)&&(s.updateRenderState({depthNear:E.near,depthFar:E.far}),M=E.near,U=E.far);let Q=$.parent,ut=E.cameras;j(E,Q);for(let Pt=0;Pt<ut.length;Pt++)j(ut[Pt],Q);ut.length===2?et(E,A,R):E.projectionMatrix.copy(A.projectionMatrix),J($,E,Q)};function J($,Q,ut){ut===null?$.matrix.copy(Q.matrixWorld):($.matrix.copy(ut.matrixWorld),$.matrix.invert(),$.matrix.multiply(Q.matrixWorld)),$.matrix.decompose($.position,$.quaternion,$.scale),$.updateMatrixWorld(!0),$.projectionMatrix.copy(Q.projectionMatrix),$.projectionMatrixInverse.copy(Q.projectionMatrixInverse),$.isPerspectiveCamera&&($.fov=$r*2*Math.atan(1/$.projectionMatrix.elements[5]),$.zoom=1)}this.getCamera=function(){return E},this.getFoveation=function(){if(!(f===null&&d===null))return c},this.setFoveation=function($){c=$,f!==null&&(f.fixedFoveation=$),d!==null&&d.fixedFoveation!==void 0&&(d.fixedFoveation=$)};let it=null;function nt($,Q){if(h=Q.getViewerPose(l||a),p=Q,h!==null){let ut=h.views;d!==null&&(t.setRenderTargetFramebuffer(m,d.framebuffer),t.setRenderTarget(m));let Pt=!1;ut.length!==E.cameras.length&&(E.cameras.length=0,Pt=!0);for(let Mt=0;Mt<ut.length;Mt++){let zt=ut[Mt],tt=null;if(d!==null)tt=d.getViewport(zt);else{let mt=u.getViewSubImage(f,zt);tt=mt.viewport,Mt===0&&(t.setRenderTargetTextures(m,mt.colorTexture,f.ignoreDepthValues?void 0:mt.depthStencilTexture),t.setRenderTarget(m))}let ct=O[Mt];ct===void 0&&(ct=new xn,ct.layers.enable(Mt),ct.viewport=new en,O[Mt]=ct),ct.matrix.fromArray(zt.transform.matrix),ct.matrix.decompose(ct.position,ct.quaternion,ct.scale),ct.projectionMatrix.fromArray(zt.projectionMatrix),ct.projectionMatrixInverse.copy(ct.projectionMatrix).invert(),ct.viewport.set(tt.x,tt.y,tt.width,tt.height),Mt===0&&(E.matrix.copy(ct.matrix),E.matrix.decompose(E.position,E.quaternion,E.scale)),Pt===!0&&E.cameras.push(ct)}}for(let ut=0;ut<S.length;ut++){let Pt=y[ut],Mt=S[ut];Pt!==null&&Mt!==void 0&&Mt.update(Pt,Q,l||a)}it&&it($,Q),Q.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:Q}),p=null}let gt=new Zf;gt.setAnimationLoop(nt),this.setAnimationLoop=function($){it=$},this.dispose=function(){}}};function fy(n,t){function e(g,m){g.matrixAutoUpdate===!0&&g.updateMatrix(),m.value.copy(g.matrix)}function i(g,m){m.color.getRGB(g.fogColor.value,qf(n)),m.isFog?(g.fogNear.value=m.near,g.fogFar.value=m.far):m.isFogExp2&&(g.fogDensity.value=m.density)}function s(g,m,S,y,b){m.isMeshBasicMaterial||m.isMeshLambertMaterial?r(g,m):m.isMeshToonMaterial?(r(g,m),u(g,m)):m.isMeshPhongMaterial?(r(g,m),h(g,m)):m.isMeshStandardMaterial?(r(g,m),f(g,m),m.isMeshPhysicalMaterial&&d(g,m,b)):m.isMeshMatcapMaterial?(r(g,m),p(g,m)):m.isMeshDepthMaterial?r(g,m):m.isMeshDistanceMaterial?(r(g,m),x(g,m)):m.isMeshNormalMaterial?r(g,m):m.isLineBasicMaterial?(a(g,m),m.isLineDashedMaterial&&o(g,m)):m.isPointsMaterial?c(g,m,S,y):m.isSpriteMaterial?l(g,m):m.isShadowMaterial?(g.color.value.copy(m.color),g.opacity.value=m.opacity):m.isShaderMaterial&&(m.uniformsNeedUpdate=!1)}function r(g,m){g.opacity.value=m.opacity,m.color&&g.diffuse.value.copy(m.color),m.emissive&&g.emissive.value.copy(m.emissive).multiplyScalar(m.emissiveIntensity),m.map&&(g.map.value=m.map,e(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.bumpMap&&(g.bumpMap.value=m.bumpMap,e(m.bumpMap,g.bumpMapTransform),g.bumpScale.value=m.bumpScale,m.side===un&&(g.bumpScale.value*=-1)),m.normalMap&&(g.normalMap.value=m.normalMap,e(m.normalMap,g.normalMapTransform),g.normalScale.value.copy(m.normalScale),m.side===un&&g.normalScale.value.negate()),m.displacementMap&&(g.displacementMap.value=m.displacementMap,e(m.displacementMap,g.displacementMapTransform),g.displacementScale.value=m.displacementScale,g.displacementBias.value=m.displacementBias),m.emissiveMap&&(g.emissiveMap.value=m.emissiveMap,e(m.emissiveMap,g.emissiveMapTransform)),m.specularMap&&(g.specularMap.value=m.specularMap,e(m.specularMap,g.specularMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest);let S=t.get(m).envMap;if(S&&(g.envMap.value=S,g.flipEnvMap.value=S.isCubeTexture&&S.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=m.reflectivity,g.ior.value=m.ior,g.refractionRatio.value=m.refractionRatio),m.lightMap){g.lightMap.value=m.lightMap;let y=n._useLegacyLights===!0?Math.PI:1;g.lightMapIntensity.value=m.lightMapIntensity*y,e(m.lightMap,g.lightMapTransform)}m.aoMap&&(g.aoMap.value=m.aoMap,g.aoMapIntensity.value=m.aoMapIntensity,e(m.aoMap,g.aoMapTransform))}function a(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,m.map&&(g.map.value=m.map,e(m.map,g.mapTransform))}function o(g,m){g.dashSize.value=m.dashSize,g.totalSize.value=m.dashSize+m.gapSize,g.scale.value=m.scale}function c(g,m,S,y){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.size.value=m.size*S,g.scale.value=y*.5,m.map&&(g.map.value=m.map,e(m.map,g.uvTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function l(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.rotation.value=m.rotation,m.map&&(g.map.value=m.map,e(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function h(g,m){g.specular.value.copy(m.specular),g.shininess.value=Math.max(m.shininess,1e-4)}function u(g,m){m.gradientMap&&(g.gradientMap.value=m.gradientMap)}function f(g,m){g.metalness.value=m.metalness,m.metalnessMap&&(g.metalnessMap.value=m.metalnessMap,e(m.metalnessMap,g.metalnessMapTransform)),g.roughness.value=m.roughness,m.roughnessMap&&(g.roughnessMap.value=m.roughnessMap,e(m.roughnessMap,g.roughnessMapTransform)),t.get(m).envMap&&(g.envMapIntensity.value=m.envMapIntensity)}function d(g,m,S){g.ior.value=m.ior,m.sheen>0&&(g.sheenColor.value.copy(m.sheenColor).multiplyScalar(m.sheen),g.sheenRoughness.value=m.sheenRoughness,m.sheenColorMap&&(g.sheenColorMap.value=m.sheenColorMap,e(m.sheenColorMap,g.sheenColorMapTransform)),m.sheenRoughnessMap&&(g.sheenRoughnessMap.value=m.sheenRoughnessMap,e(m.sheenRoughnessMap,g.sheenRoughnessMapTransform))),m.clearcoat>0&&(g.clearcoat.value=m.clearcoat,g.clearcoatRoughness.value=m.clearcoatRoughness,m.clearcoatMap&&(g.clearcoatMap.value=m.clearcoatMap,e(m.clearcoatMap,g.clearcoatMapTransform)),m.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=m.clearcoatRoughnessMap,e(m.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),m.clearcoatNormalMap&&(g.clearcoatNormalMap.value=m.clearcoatNormalMap,e(m.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(m.clearcoatNormalScale),m.side===un&&g.clearcoatNormalScale.value.negate())),m.iridescence>0&&(g.iridescence.value=m.iridescence,g.iridescenceIOR.value=m.iridescenceIOR,g.iridescenceThicknessMinimum.value=m.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=m.iridescenceThicknessRange[1],m.iridescenceMap&&(g.iridescenceMap.value=m.iridescenceMap,e(m.iridescenceMap,g.iridescenceMapTransform)),m.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=m.iridescenceThicknessMap,e(m.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),m.transmission>0&&(g.transmission.value=m.transmission,g.transmissionSamplerMap.value=S.texture,g.transmissionSamplerSize.value.set(S.width,S.height),m.transmissionMap&&(g.transmissionMap.value=m.transmissionMap,e(m.transmissionMap,g.transmissionMapTransform)),g.thickness.value=m.thickness,m.thicknessMap&&(g.thicknessMap.value=m.thicknessMap,e(m.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=m.attenuationDistance,g.attenuationColor.value.copy(m.attenuationColor)),m.anisotropy>0&&(g.anisotropyVector.value.set(m.anisotropy*Math.cos(m.anisotropyRotation),m.anisotropy*Math.sin(m.anisotropyRotation)),m.anisotropyMap&&(g.anisotropyMap.value=m.anisotropyMap,e(m.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=m.specularIntensity,g.specularColor.value.copy(m.specularColor),m.specularColorMap&&(g.specularColorMap.value=m.specularColorMap,e(m.specularColorMap,g.specularColorMapTransform)),m.specularIntensityMap&&(g.specularIntensityMap.value=m.specularIntensityMap,e(m.specularIntensityMap,g.specularIntensityMapTransform))}function p(g,m){m.matcap&&(g.matcap.value=m.matcap)}function x(g,m){let S=t.get(m).light;g.referencePosition.value.setFromMatrixPosition(S.matrixWorld),g.nearDistance.value=S.shadow.camera.near,g.farDistance.value=S.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:s}}function dy(n,t,e,i){let s={},r={},a=[],o=e.isWebGL2?n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS):0;function c(S,y){let b=y.program;i.uniformBlockBinding(S,b)}function l(S,y){let b=s[S.id];b===void 0&&(p(S),b=h(S),s[S.id]=b,S.addEventListener("dispose",g));let C=y.program;i.updateUBOMapping(S,C);let A=t.render.frame;r[S.id]!==A&&(f(S),r[S.id]=A)}function h(S){let y=u();S.__bindingPointIndex=y;let b=n.createBuffer(),C=S.__size,A=S.usage;return n.bindBuffer(n.UNIFORM_BUFFER,b),n.bufferData(n.UNIFORM_BUFFER,C,A),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,y,b),b}function u(){for(let S=0;S<o;S++)if(a.indexOf(S)===-1)return a.push(S),S;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function f(S){let y=s[S.id],b=S.uniforms,C=S.__cache;n.bindBuffer(n.UNIFORM_BUFFER,y);for(let A=0,R=b.length;A<R;A++){let O=Array.isArray(b[A])?b[A]:[b[A]];for(let E=0,M=O.length;E<M;E++){let U=O[E];if(d(U,A,E,C)===!0){let H=U.__offset,rt=Array.isArray(U.value)?U.value:[U.value],I=0;for(let F=0;F<rt.length;F++){let B=rt[F],et=x(B);typeof B=="number"||typeof B=="boolean"?(U.__data[0]=B,n.bufferSubData(n.UNIFORM_BUFFER,H+I,U.__data)):B.isMatrix3?(U.__data[0]=B.elements[0],U.__data[1]=B.elements[1],U.__data[2]=B.elements[2],U.__data[3]=0,U.__data[4]=B.elements[3],U.__data[5]=B.elements[4],U.__data[6]=B.elements[5],U.__data[7]=0,U.__data[8]=B.elements[6],U.__data[9]=B.elements[7],U.__data[10]=B.elements[8],U.__data[11]=0):(B.toArray(U.__data,I),I+=et.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,H,U.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function d(S,y,b,C){let A=S.value,R=y+"_"+b;if(C[R]===void 0)return typeof A=="number"||typeof A=="boolean"?C[R]=A:C[R]=A.clone(),!0;{let O=C[R];if(typeof A=="number"||typeof A=="boolean"){if(O!==A)return C[R]=A,!0}else if(O.equals(A)===!1)return O.copy(A),!0}return!1}function p(S){let y=S.uniforms,b=0,C=16;for(let R=0,O=y.length;R<O;R++){let E=Array.isArray(y[R])?y[R]:[y[R]];for(let M=0,U=E.length;M<U;M++){let H=E[M],rt=Array.isArray(H.value)?H.value:[H.value];for(let I=0,F=rt.length;I<F;I++){let B=rt[I],et=x(B),j=b%C;j!==0&&C-j<et.boundary&&(b+=C-j),H.__data=new Float32Array(et.storage/Float32Array.BYTES_PER_ELEMENT),H.__offset=b,b+=et.storage}}}let A=b%C;return A>0&&(b+=C-A),S.__size=b,S.__cache={},this}function x(S){let y={boundary:0,storage:0};return typeof S=="number"||typeof S=="boolean"?(y.boundary=4,y.storage=4):S.isVector2?(y.boundary=8,y.storage=8):S.isVector3||S.isColor?(y.boundary=16,y.storage=12):S.isVector4?(y.boundary=16,y.storage=16):S.isMatrix3?(y.boundary=48,y.storage=48):S.isMatrix4?(y.boundary=64,y.storage=64):S.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",S),y}function g(S){let y=S.target;y.removeEventListener("dispose",g);let b=a.indexOf(y.__bindingPointIndex);a.splice(b,1),n.deleteBuffer(s[y.id]),delete s[y.id],delete r[y.id]}function m(){for(let S in s)n.deleteBuffer(s[S]);a=[],s={},r={}}return{bind:c,update:l,dispose:m}}var Zr=class{constructor(t={}){let{canvas:e=E0(),context:i=null,depth:s=!0,stencil:r=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1}=t;this.isWebGLRenderer=!0;let f;i!==null?f=i.getContextAttributes().alpha:f=a;let d=new Uint32Array(4),p=new Int32Array(4),x=null,g=null,m=[],S=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Ae,this._useLegacyLights=!1,this.toneMapping=Bi,this.toneMappingExposure=1;let y=this,b=!1,C=0,A=0,R=null,O=-1,E=null,M=new en,U=new en,H=null,rt=new Ft(0),I=0,F=e.width,B=e.height,et=1,j=null,J=null,it=new en(0,0,F,B),nt=new en(0,0,F,B),gt=!1,$=new qr,Q=!1,ut=!1,Pt=null,Mt=new Se,zt=new ht,tt=new P,ct={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function mt(){return R===null?et:1}let w=i;function st(T,N){for(let V=0;V<T.length;V++){let X=T[V],G=e.getContext(X,N);if(G!==null)return G}return null}try{let T={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${Xl}`),e.addEventListener("webglcontextlost",ft,!1),e.addEventListener("webglcontextrestored",D,!1),e.addEventListener("webglcontextcreationerror",yt,!1),w===null){let N=["webgl2","webgl","experimental-webgl"];if(y.isWebGL1Renderer===!0&&N.shift(),w=st(N,T),w===null)throw st(N)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&w instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),w.getShaderPrecisionFormat===void 0&&(w.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(T){throw console.error("THREE.WebGLRenderer: "+T.message),T}let Y,K,q,Rt,xt,v,_,L,k,W,Z,Et,lt,St,Ot,Yt,at,fe,se,qt,Bt,Lt,Kt,ge;function Ne(){Y=new Ix(w),K=new wx(w,Y,t),Y.init(K),Lt=new hy(w,Y,K),q=new cy(w,Y,K),Rt=new Nx(w),xt=new J_,v=new ly(w,Y,q,xt,K,Lt,Rt),_=new Rx(y),L=new Lx(y),k=new V0(w,K),Kt=new bx(w,Y,k,K),W=new Dx(w,k,Rt,Kt),Z=new Bx(w,W,k,Rt),se=new zx(w,K,v),Yt=new Ax(xt),Et=new Z_(y,_,L,Y,K,Kt,Yt),lt=new fy(y,xt),St=new j_,Ot=new sy(Y,K),fe=new Sx(y,_,L,q,Z,f,c),at=new oy(y,Z,K),ge=new dy(w,Rt,K,q),qt=new Tx(w,Y,Rt,K),Bt=new Ux(w,Y,Rt,K),Rt.programs=Et.programs,y.capabilities=K,y.extensions=Y,y.properties=xt,y.renderLists=St,y.shadowMap=at,y.state=q,y.info=Rt}Ne();let ee=new Ml(y,w);this.xr=ee,this.getContext=function(){return w},this.getContextAttributes=function(){return w.getContextAttributes()},this.forceContextLoss=function(){let T=Y.get("WEBGL_lose_context");T&&T.loseContext()},this.forceContextRestore=function(){let T=Y.get("WEBGL_lose_context");T&&T.restoreContext()},this.getPixelRatio=function(){return et},this.setPixelRatio=function(T){T!==void 0&&(et=T,this.setSize(F,B,!1))},this.getSize=function(T){return T.set(F,B)},this.setSize=function(T,N,V=!0){if(ee.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}F=T,B=N,e.width=Math.floor(T*et),e.height=Math.floor(N*et),V===!0&&(e.style.width=T+"px",e.style.height=N+"px"),this.setViewport(0,0,T,N)},this.getDrawingBufferSize=function(T){return T.set(F*et,B*et).floor()},this.setDrawingBufferSize=function(T,N,V){F=T,B=N,et=V,e.width=Math.floor(T*V),e.height=Math.floor(N*V),this.setViewport(0,0,T,N)},this.getCurrentViewport=function(T){return T.copy(M)},this.getViewport=function(T){return T.copy(it)},this.setViewport=function(T,N,V,X){T.isVector4?it.set(T.x,T.y,T.z,T.w):it.set(T,N,V,X),q.viewport(M.copy(it).multiplyScalar(et).floor())},this.getScissor=function(T){return T.copy(nt)},this.setScissor=function(T,N,V,X){T.isVector4?nt.set(T.x,T.y,T.z,T.w):nt.set(T,N,V,X),q.scissor(U.copy(nt).multiplyScalar(et).floor())},this.getScissorTest=function(){return gt},this.setScissorTest=function(T){q.setScissorTest(gt=T)},this.setOpaqueSort=function(T){j=T},this.setTransparentSort=function(T){J=T},this.getClearColor=function(T){return T.copy(fe.getClearColor())},this.setClearColor=function(){fe.setClearColor.apply(fe,arguments)},this.getClearAlpha=function(){return fe.getClearAlpha()},this.setClearAlpha=function(){fe.setClearAlpha.apply(fe,arguments)},this.clear=function(T=!0,N=!0,V=!0){let X=0;if(T){let G=!1;if(R!==null){let wt=R.texture.format;G=wt===Bf||wt===zf||wt===Ff}if(G){let wt=R.texture.type,Ut=wt===Hi||wt===Ni||wt===ql||wt===as||wt===Nf||wt===Of,Vt=fe.getClearColor(),Xt=fe.getClearAlpha(),Qt=Vt.r,Zt=Vt.g,Jt=Vt.b;Ut?(d[0]=Qt,d[1]=Zt,d[2]=Jt,d[3]=Xt,w.clearBufferuiv(w.COLOR,0,d)):(p[0]=Qt,p[1]=Zt,p[2]=Jt,p[3]=Xt,w.clearBufferiv(w.COLOR,0,p))}else X|=w.COLOR_BUFFER_BIT}N&&(X|=w.DEPTH_BUFFER_BIT),V&&(X|=w.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),w.clear(X)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",ft,!1),e.removeEventListener("webglcontextrestored",D,!1),e.removeEventListener("webglcontextcreationerror",yt,!1),St.dispose(),Ot.dispose(),xt.dispose(),_.dispose(),L.dispose(),Z.dispose(),Kt.dispose(),ge.dispose(),Et.dispose(),ee.dispose(),ee.removeEventListener("sessionstart",dn),ee.removeEventListener("sessionend",Ee),Pt&&(Pt.dispose(),Pt=null),pn.stop()};function ft(T){T.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),b=!0}function D(){console.log("THREE.WebGLRenderer: Context Restored."),b=!1;let T=Rt.autoReset,N=at.enabled,V=at.autoUpdate,X=at.needsUpdate,G=at.type;Ne(),Rt.autoReset=T,at.enabled=N,at.autoUpdate=V,at.needsUpdate=X,at.type=G}function yt(T){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",T.statusMessage)}function vt(T){let N=T.target;N.removeEventListener("dispose",vt),Wt(N)}function Wt(T){Ht(T),xt.remove(T)}function Ht(T){let N=xt.get(T).programs;N!==void 0&&(N.forEach(function(V){Et.releaseProgram(V)}),T.isShaderMaterial&&Et.releaseShaderCache(T))}this.renderBufferDirect=function(T,N,V,X,G,wt){N===null&&(N=ct);let Ut=G.isMesh&&G.matrixWorld.determinant()<0,Vt=op(T,N,V,X,G);q.setMaterial(X,Ut);let Xt=V.index,Qt=1;if(X.wireframe===!0){if(Xt=W.getWireframeAttribute(V),Xt===void 0)return;Qt=2}let Zt=V.drawRange,Jt=V.attributes.position,Be=Zt.start*Qt,En=(Zt.start+Zt.count)*Qt;wt!==null&&(Be=Math.max(Be,wt.start*Qt),En=Math.min(En,(wt.start+wt.count)*Qt)),Xt!==null?(Be=Math.max(Be,0),En=Math.min(En,Xt.count)):Jt!=null&&(Be=Math.max(Be,0),En=Math.min(En,Jt.count));let je=En-Be;if(je<0||je===1/0)return;Kt.setup(G,X,Vt,V,Xt);let li,Ie=qt;if(Xt!==null&&(li=k.get(Xt),Ie=Bt,Ie.setIndex(li)),G.isMesh)X.wireframe===!0?(q.setLineWidth(X.wireframeLinewidth*mt()),Ie.setMode(w.LINES)):Ie.setMode(w.TRIANGLES);else if(G.isLine){let ne=X.linewidth;ne===void 0&&(ne=1),q.setLineWidth(ne*mt()),G.isLineSegments?Ie.setMode(w.LINES):G.isLineLoop?Ie.setMode(w.LINE_LOOP):Ie.setMode(w.LINE_STRIP)}else G.isPoints?Ie.setMode(w.POINTS):G.isSprite&&Ie.setMode(w.TRIANGLES);if(G.isBatchedMesh)Ie.renderMultiDraw(G._multiDrawStarts,G._multiDrawCounts,G._multiDrawCount);else if(G.isInstancedMesh)Ie.renderInstances(Be,je,G.count);else if(V.isInstancedBufferGeometry){let ne=V._maxInstanceCount!==void 0?V._maxInstanceCount:1/0,gc=Math.min(V.instanceCount,ne);Ie.renderInstances(Be,je,gc)}else Ie.render(Be,je)};function ve(T,N,V){T.transparent===!0&&T.side===He&&T.forceSinglePass===!1?(T.side=un,T.needsUpdate=!0,ba(T,N,V),T.side=ki,T.needsUpdate=!0,ba(T,N,V),T.side=He):ba(T,N,V)}this.compile=function(T,N,V=null){V===null&&(V=T),g=Ot.get(V),g.init(),S.push(g),V.traverseVisible(function(G){G.isLight&&G.layers.test(N.layers)&&(g.pushLight(G),G.castShadow&&g.pushShadow(G))}),T!==V&&T.traverseVisible(function(G){G.isLight&&G.layers.test(N.layers)&&(g.pushLight(G),G.castShadow&&g.pushShadow(G))}),g.setupLights(y._useLegacyLights);let X=new Set;return T.traverse(function(G){let wt=G.material;if(wt)if(Array.isArray(wt))for(let Ut=0;Ut<wt.length;Ut++){let Vt=wt[Ut];ve(Vt,V,G),X.add(Vt)}else ve(wt,V,G),X.add(wt)}),S.pop(),g=null,X},this.compileAsync=function(T,N,V=null){let X=this.compile(T,N,V);return new Promise(G=>{function wt(){if(X.forEach(function(Ut){xt.get(Ut).currentProgram.isReady()&&X.delete(Ut)}),X.size===0){G(T);return}setTimeout(wt,10)}Y.get("KHR_parallel_shader_compile")!==null?wt():setTimeout(wt,10)})};let Me=null;function Ke(T){Me&&Me(T)}function dn(){pn.stop()}function Ee(){pn.start()}let pn=new Zf;pn.setAnimationLoop(Ke),typeof self<"u"&&pn.setContext(self),this.setAnimationLoop=function(T){Me=T,ee.setAnimationLoop(T),T===null?pn.stop():pn.start()},ee.addEventListener("sessionstart",dn),ee.addEventListener("sessionend",Ee),this.render=function(T,N){if(N!==void 0&&N.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(b===!0)return;T.matrixWorldAutoUpdate===!0&&T.updateMatrixWorld(),N.parent===null&&N.matrixWorldAutoUpdate===!0&&N.updateMatrixWorld(),ee.enabled===!0&&ee.isPresenting===!0&&(ee.cameraAutoUpdate===!0&&ee.updateCamera(N),N=ee.getCamera()),T.isScene===!0&&T.onBeforeRender(y,T,N,R),g=Ot.get(T,S.length),g.init(),S.push(g),Mt.multiplyMatrices(N.projectionMatrix,N.matrixWorldInverse),$.setFromProjectionMatrix(Mt),ut=this.localClippingEnabled,Q=Yt.init(this.clippingPlanes,ut),x=St.get(T,m.length),x.init(),m.push(x),ti(T,N,0,y.sortObjects),x.finish(),y.sortObjects===!0&&x.sort(j,J),this.info.render.frame++,Q===!0&&Yt.beginShadows();let V=g.state.shadowsArray;if(at.render(V,T,N),Q===!0&&Yt.endShadows(),this.info.autoReset===!0&&this.info.reset(),fe.render(x,T),g.setupLights(y._useLegacyLights),N.isArrayCamera){let X=N.cameras;for(let G=0,wt=X.length;G<wt;G++){let Ut=X[G];Xh(x,T,Ut,Ut.viewport)}}else Xh(x,T,N);R!==null&&(v.updateMultisampleRenderTarget(R),v.updateRenderTargetMipmap(R)),T.isScene===!0&&T.onAfterRender(y,T,N),Kt.resetDefaultState(),O=-1,E=null,S.pop(),S.length>0?g=S[S.length-1]:g=null,m.pop(),m.length>0?x=m[m.length-1]:x=null};function ti(T,N,V,X){if(T.visible===!1)return;if(T.layers.test(N.layers)){if(T.isGroup)V=T.renderOrder;else if(T.isLOD)T.autoUpdate===!0&&T.update(N);else if(T.isLight)g.pushLight(T),T.castShadow&&g.pushShadow(T);else if(T.isSprite){if(!T.frustumCulled||$.intersectsSprite(T)){X&&tt.setFromMatrixPosition(T.matrixWorld).applyMatrix4(Mt);let Ut=Z.update(T),Vt=T.material;Vt.visible&&x.push(T,Ut,Vt,V,tt.z,null)}}else if((T.isMesh||T.isLine||T.isPoints)&&(!T.frustumCulled||$.intersectsObject(T))){let Ut=Z.update(T),Vt=T.material;if(X&&(T.boundingSphere!==void 0?(T.boundingSphere===null&&T.computeBoundingSphere(),tt.copy(T.boundingSphere.center)):(Ut.boundingSphere===null&&Ut.computeBoundingSphere(),tt.copy(Ut.boundingSphere.center)),tt.applyMatrix4(T.matrixWorld).applyMatrix4(Mt)),Array.isArray(Vt)){let Xt=Ut.groups;for(let Qt=0,Zt=Xt.length;Qt<Zt;Qt++){let Jt=Xt[Qt],Be=Vt[Jt.materialIndex];Be&&Be.visible&&x.push(T,Ut,Be,V,tt.z,Jt)}}else Vt.visible&&x.push(T,Ut,Vt,V,tt.z,null)}}let wt=T.children;for(let Ut=0,Vt=wt.length;Ut<Vt;Ut++)ti(wt[Ut],N,V,X)}function Xh(T,N,V,X){let G=T.opaque,wt=T.transmissive,Ut=T.transparent;g.setupLightsView(V),Q===!0&&Yt.setGlobalState(y.clippingPlanes,V),wt.length>0&&ap(G,wt,N,V),X&&q.viewport(M.copy(X)),G.length>0&&Sa(G,N,V),wt.length>0&&Sa(wt,N,V),Ut.length>0&&Sa(Ut,N,V),q.buffers.depth.setTest(!0),q.buffers.depth.setMask(!0),q.buffers.color.setMask(!0),q.setPolygonOffset(!1)}function ap(T,N,V,X){if((V.isScene===!0?V.overrideMaterial:null)!==null)return;let wt=K.isWebGL2;Pt===null&&(Pt=new yi(1,1,{generateMipmaps:!0,type:Y.has("EXT_color_buffer_half_float")?Yr:Hi,minFilter:Xr,samples:wt?4:0})),y.getDrawingBufferSize(zt),wt?Pt.setSize(zt.x,zt.y):Pt.setSize(ho(zt.x),ho(zt.y));let Ut=y.getRenderTarget();y.setRenderTarget(Pt),y.getClearColor(rt),I=y.getClearAlpha(),I<1&&y.setClearColor(16777215,.5),y.clear();let Vt=y.toneMapping;y.toneMapping=Bi,Sa(T,V,X),v.updateMultisampleRenderTarget(Pt),v.updateRenderTargetMipmap(Pt);let Xt=!1;for(let Qt=0,Zt=N.length;Qt<Zt;Qt++){let Jt=N[Qt],Be=Jt.object,En=Jt.geometry,je=Jt.material,li=Jt.group;if(je.side===He&&Be.layers.test(X.layers)){let Ie=je.side;je.side=un,je.needsUpdate=!0,Yh(Be,V,X,En,je,li),je.side=Ie,je.needsUpdate=!0,Xt=!0}}Xt===!0&&(v.updateMultisampleRenderTarget(Pt),v.updateRenderTargetMipmap(Pt)),y.setRenderTarget(Ut),y.setClearColor(rt,I),y.toneMapping=Vt}function Sa(T,N,V){let X=N.isScene===!0?N.overrideMaterial:null;for(let G=0,wt=T.length;G<wt;G++){let Ut=T[G],Vt=Ut.object,Xt=Ut.geometry,Qt=X===null?Ut.material:X,Zt=Ut.group;Vt.layers.test(V.layers)&&Yh(Vt,N,V,Xt,Qt,Zt)}}function Yh(T,N,V,X,G,wt){T.onBeforeRender(y,N,V,X,G,wt),T.modelViewMatrix.multiplyMatrices(V.matrixWorldInverse,T.matrixWorld),T.normalMatrix.getNormalMatrix(T.modelViewMatrix),G.onBeforeRender(y,N,V,X,T,wt),G.transparent===!0&&G.side===He&&G.forceSinglePass===!1?(G.side=un,G.needsUpdate=!0,y.renderBufferDirect(V,N,X,G,T,wt),G.side=ki,G.needsUpdate=!0,y.renderBufferDirect(V,N,X,G,T,wt),G.side=He):y.renderBufferDirect(V,N,X,G,T,wt),T.onAfterRender(y,N,V,X,G,wt)}function ba(T,N,V){N.isScene!==!0&&(N=ct);let X=xt.get(T),G=g.state.lights,wt=g.state.shadowsArray,Ut=G.state.version,Vt=Et.getParameters(T,G.state,wt,N,V),Xt=Et.getProgramCacheKey(Vt),Qt=X.programs;X.environment=T.isMeshStandardMaterial?N.environment:null,X.fog=N.fog,X.envMap=(T.isMeshStandardMaterial?L:_).get(T.envMap||X.environment),Qt===void 0&&(T.addEventListener("dispose",vt),Qt=new Map,X.programs=Qt);let Zt=Qt.get(Xt);if(Zt!==void 0){if(X.currentProgram===Zt&&X.lightsStateVersion===Ut)return qh(T,Vt),Zt}else Vt.uniforms=Et.getUniforms(T),T.onBuild(V,Vt,y),T.onBeforeCompile(Vt,y),Zt=Et.acquireProgram(Vt,Xt),Qt.set(Xt,Zt),X.uniforms=Vt.uniforms;let Jt=X.uniforms;return(!T.isShaderMaterial&&!T.isRawShaderMaterial||T.clipping===!0)&&(Jt.clippingPlanes=Yt.uniform),qh(T,Vt),X.needsLights=lp(T),X.lightsStateVersion=Ut,X.needsLights&&(Jt.ambientLightColor.value=G.state.ambient,Jt.lightProbe.value=G.state.probe,Jt.directionalLights.value=G.state.directional,Jt.directionalLightShadows.value=G.state.directionalShadow,Jt.spotLights.value=G.state.spot,Jt.spotLightShadows.value=G.state.spotShadow,Jt.rectAreaLights.value=G.state.rectArea,Jt.ltc_1.value=G.state.rectAreaLTC1,Jt.ltc_2.value=G.state.rectAreaLTC2,Jt.pointLights.value=G.state.point,Jt.pointLightShadows.value=G.state.pointShadow,Jt.hemisphereLights.value=G.state.hemi,Jt.directionalShadowMap.value=G.state.directionalShadowMap,Jt.directionalShadowMatrix.value=G.state.directionalShadowMatrix,Jt.spotShadowMap.value=G.state.spotShadowMap,Jt.spotLightMatrix.value=G.state.spotLightMatrix,Jt.spotLightMap.value=G.state.spotLightMap,Jt.pointShadowMap.value=G.state.pointShadowMap,Jt.pointShadowMatrix.value=G.state.pointShadowMatrix),X.currentProgram=Zt,X.uniformsList=null,Zt}function $h(T){if(T.uniformsList===null){let N=T.currentProgram.getUniforms();T.uniformsList=tr.seqWithValue(N.seq,T.uniforms)}return T.uniformsList}function qh(T,N){let V=xt.get(T);V.outputColorSpace=N.outputColorSpace,V.batching=N.batching,V.instancing=N.instancing,V.instancingColor=N.instancingColor,V.skinning=N.skinning,V.morphTargets=N.morphTargets,V.morphNormals=N.morphNormals,V.morphColors=N.morphColors,V.morphTargetsCount=N.morphTargetsCount,V.numClippingPlanes=N.numClippingPlanes,V.numIntersection=N.numClipIntersection,V.vertexAlphas=N.vertexAlphas,V.vertexTangents=N.vertexTangents,V.toneMapping=N.toneMapping}function op(T,N,V,X,G){N.isScene!==!0&&(N=ct),v.resetTextureUnits();let wt=N.fog,Ut=X.isMeshStandardMaterial?N.environment:null,Vt=R===null?y.outputColorSpace:R.isXRRenderTarget===!0?R.texture.colorSpace:_i,Xt=(X.isMeshStandardMaterial?L:_).get(X.envMap||Ut),Qt=X.vertexColors===!0&&!!V.attributes.color&&V.attributes.color.itemSize===4,Zt=!!V.attributes.tangent&&(!!X.normalMap||X.anisotropy>0),Jt=!!V.morphAttributes.position,Be=!!V.morphAttributes.normal,En=!!V.morphAttributes.color,je=Bi;X.toneMapped&&(R===null||R.isXRRenderTarget===!0)&&(je=y.toneMapping);let li=V.morphAttributes.position||V.morphAttributes.normal||V.morphAttributes.color,Ie=li!==void 0?li.length:0,ne=xt.get(X),gc=g.state.lights;if(Q===!0&&(ut===!0||T!==E)){let Dn=T===E&&X.id===O;Yt.setState(X,T,Dn)}let Oe=!1;X.version===ne.__version?(ne.needsLights&&ne.lightsStateVersion!==gc.state.version||ne.outputColorSpace!==Vt||G.isBatchedMesh&&ne.batching===!1||!G.isBatchedMesh&&ne.batching===!0||G.isInstancedMesh&&ne.instancing===!1||!G.isInstancedMesh&&ne.instancing===!0||G.isSkinnedMesh&&ne.skinning===!1||!G.isSkinnedMesh&&ne.skinning===!0||G.isInstancedMesh&&ne.instancingColor===!0&&G.instanceColor===null||G.isInstancedMesh&&ne.instancingColor===!1&&G.instanceColor!==null||ne.envMap!==Xt||X.fog===!0&&ne.fog!==wt||ne.numClippingPlanes!==void 0&&(ne.numClippingPlanes!==Yt.numPlanes||ne.numIntersection!==Yt.numIntersection)||ne.vertexAlphas!==Qt||ne.vertexTangents!==Zt||ne.morphTargets!==Jt||ne.morphNormals!==Be||ne.morphColors!==En||ne.toneMapping!==je||K.isWebGL2===!0&&ne.morphTargetsCount!==Ie)&&(Oe=!0):(Oe=!0,ne.__version=X.version);let Ji=ne.currentProgram;Oe===!0&&(Ji=ba(X,N,G));let Zh=!1,Ar=!1,xc=!1,cn=Ji.getUniforms(),Ki=ne.uniforms;if(q.useProgram(Ji.program)&&(Zh=!0,Ar=!0,xc=!0),X.id!==O&&(O=X.id,Ar=!0),Zh||E!==T){cn.setValue(w,"projectionMatrix",T.projectionMatrix),cn.setValue(w,"viewMatrix",T.matrixWorldInverse);let Dn=cn.map.cameraPosition;Dn!==void 0&&Dn.setValue(w,tt.setFromMatrixPosition(T.matrixWorld)),K.logarithmicDepthBuffer&&cn.setValue(w,"logDepthBufFC",2/(Math.log(T.far+1)/Math.LN2)),(X.isMeshPhongMaterial||X.isMeshToonMaterial||X.isMeshLambertMaterial||X.isMeshBasicMaterial||X.isMeshStandardMaterial||X.isShaderMaterial)&&cn.setValue(w,"isOrthographic",T.isOrthographicCamera===!0),E!==T&&(E=T,Ar=!0,xc=!0)}if(G.isSkinnedMesh){cn.setOptional(w,G,"bindMatrix"),cn.setOptional(w,G,"bindMatrixInverse");let Dn=G.skeleton;Dn&&(K.floatVertexTextures?(Dn.boneTexture===null&&Dn.computeBoneTexture(),cn.setValue(w,"boneTexture",Dn.boneTexture,v)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}G.isBatchedMesh&&(cn.setOptional(w,G,"batchingTexture"),cn.setValue(w,"batchingTexture",G._matricesTexture,v));let _c=V.morphAttributes;if((_c.position!==void 0||_c.normal!==void 0||_c.color!==void 0&&K.isWebGL2===!0)&&se.update(G,V,Ji),(Ar||ne.receiveShadow!==G.receiveShadow)&&(ne.receiveShadow=G.receiveShadow,cn.setValue(w,"receiveShadow",G.receiveShadow)),X.isMeshGouraudMaterial&&X.envMap!==null&&(Ki.envMap.value=Xt,Ki.flipEnvMap.value=Xt.isCubeTexture&&Xt.isRenderTargetTexture===!1?-1:1),Ar&&(cn.setValue(w,"toneMappingExposure",y.toneMappingExposure),ne.needsLights&&cp(Ki,xc),wt&&X.fog===!0&&lt.refreshFogUniforms(Ki,wt),lt.refreshMaterialUniforms(Ki,X,et,B,Pt),tr.upload(w,$h(ne),Ki,v)),X.isShaderMaterial&&X.uniformsNeedUpdate===!0&&(tr.upload(w,$h(ne),Ki,v),X.uniformsNeedUpdate=!1),X.isSpriteMaterial&&cn.setValue(w,"center",G.center),cn.setValue(w,"modelViewMatrix",G.modelViewMatrix),cn.setValue(w,"normalMatrix",G.normalMatrix),cn.setValue(w,"modelMatrix",G.matrixWorld),X.isShaderMaterial||X.isRawShaderMaterial){let Dn=X.uniformsGroups;for(let yc=0,hp=Dn.length;yc<hp;yc++)if(K.isWebGL2){let Jh=Dn[yc];ge.update(Jh,Ji),ge.bind(Jh,Ji)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Ji}function cp(T,N){T.ambientLightColor.needsUpdate=N,T.lightProbe.needsUpdate=N,T.directionalLights.needsUpdate=N,T.directionalLightShadows.needsUpdate=N,T.pointLights.needsUpdate=N,T.pointLightShadows.needsUpdate=N,T.spotLights.needsUpdate=N,T.spotLightShadows.needsUpdate=N,T.rectAreaLights.needsUpdate=N,T.hemisphereLights.needsUpdate=N}function lp(T){return T.isMeshLambertMaterial||T.isMeshToonMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isShadowMaterial||T.isShaderMaterial&&T.lights===!0}this.getActiveCubeFace=function(){return C},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return R},this.setRenderTargetTextures=function(T,N,V){xt.get(T.texture).__webglTexture=N,xt.get(T.depthTexture).__webglTexture=V;let X=xt.get(T);X.__hasExternalTextures=!0,X.__hasExternalTextures&&(X.__autoAllocateDepthBuffer=V===void 0,X.__autoAllocateDepthBuffer||Y.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),X.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(T,N){let V=xt.get(T);V.__webglFramebuffer=N,V.__useDefaultFramebuffer=N===void 0},this.setRenderTarget=function(T,N=0,V=0){R=T,C=N,A=V;let X=!0,G=null,wt=!1,Ut=!1;if(T){let Xt=xt.get(T);Xt.__useDefaultFramebuffer!==void 0?(q.bindFramebuffer(w.FRAMEBUFFER,null),X=!1):Xt.__webglFramebuffer===void 0?v.setupRenderTarget(T):Xt.__hasExternalTextures&&v.rebindTextures(T,xt.get(T.texture).__webglTexture,xt.get(T.depthTexture).__webglTexture);let Qt=T.texture;(Qt.isData3DTexture||Qt.isDataArrayTexture||Qt.isCompressedArrayTexture)&&(Ut=!0);let Zt=xt.get(T).__webglFramebuffer;T.isWebGLCubeRenderTarget?(Array.isArray(Zt[N])?G=Zt[N][V]:G=Zt[N],wt=!0):K.isWebGL2&&T.samples>0&&v.useMultisampledRTT(T)===!1?G=xt.get(T).__webglMultisampledFramebuffer:Array.isArray(Zt)?G=Zt[V]:G=Zt,M.copy(T.viewport),U.copy(T.scissor),H=T.scissorTest}else M.copy(it).multiplyScalar(et).floor(),U.copy(nt).multiplyScalar(et).floor(),H=gt;if(q.bindFramebuffer(w.FRAMEBUFFER,G)&&K.drawBuffers&&X&&q.drawBuffers(T,G),q.viewport(M),q.scissor(U),q.setScissorTest(H),wt){let Xt=xt.get(T.texture);w.framebufferTexture2D(w.FRAMEBUFFER,w.COLOR_ATTACHMENT0,w.TEXTURE_CUBE_MAP_POSITIVE_X+N,Xt.__webglTexture,V)}else if(Ut){let Xt=xt.get(T.texture),Qt=N||0;w.framebufferTextureLayer(w.FRAMEBUFFER,w.COLOR_ATTACHMENT0,Xt.__webglTexture,V||0,Qt)}O=-1},this.readRenderTargetPixels=function(T,N,V,X,G,wt,Ut){if(!(T&&T.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Vt=xt.get(T).__webglFramebuffer;if(T.isWebGLCubeRenderTarget&&Ut!==void 0&&(Vt=Vt[Ut]),Vt){q.bindFramebuffer(w.FRAMEBUFFER,Vt);try{let Xt=T.texture,Qt=Xt.format,Zt=Xt.type;if(Qt!==Jn&&Lt.convert(Qt)!==w.getParameter(w.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let Jt=Zt===Yr&&(Y.has("EXT_color_buffer_half_float")||K.isWebGL2&&Y.has("EXT_color_buffer_float"));if(Zt!==Hi&&Lt.convert(Zt)!==w.getParameter(w.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Zt===Oi&&(K.isWebGL2||Y.has("OES_texture_float")||Y.has("WEBGL_color_buffer_float")))&&!Jt){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}N>=0&&N<=T.width-X&&V>=0&&V<=T.height-G&&w.readPixels(N,V,X,G,Lt.convert(Qt),Lt.convert(Zt),wt)}finally{let Xt=R!==null?xt.get(R).__webglFramebuffer:null;q.bindFramebuffer(w.FRAMEBUFFER,Xt)}}},this.copyFramebufferToTexture=function(T,N,V=0){let X=Math.pow(2,-V),G=Math.floor(N.image.width*X),wt=Math.floor(N.image.height*X);v.setTexture2D(N,0),w.copyTexSubImage2D(w.TEXTURE_2D,V,0,0,T.x,T.y,G,wt),q.unbindTexture()},this.copyTextureToTexture=function(T,N,V,X=0){let G=N.image.width,wt=N.image.height,Ut=Lt.convert(V.format),Vt=Lt.convert(V.type);v.setTexture2D(V,0),w.pixelStorei(w.UNPACK_FLIP_Y_WEBGL,V.flipY),w.pixelStorei(w.UNPACK_PREMULTIPLY_ALPHA_WEBGL,V.premultiplyAlpha),w.pixelStorei(w.UNPACK_ALIGNMENT,V.unpackAlignment),N.isDataTexture?w.texSubImage2D(w.TEXTURE_2D,X,T.x,T.y,G,wt,Ut,Vt,N.image.data):N.isCompressedTexture?w.compressedTexSubImage2D(w.TEXTURE_2D,X,T.x,T.y,N.mipmaps[0].width,N.mipmaps[0].height,Ut,N.mipmaps[0].data):w.texSubImage2D(w.TEXTURE_2D,X,T.x,T.y,Ut,Vt,N.image),X===0&&V.generateMipmaps&&w.generateMipmap(w.TEXTURE_2D),q.unbindTexture()},this.copyTextureToTexture3D=function(T,N,V,X,G=0){if(y.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let wt=T.max.x-T.min.x+1,Ut=T.max.y-T.min.y+1,Vt=T.max.z-T.min.z+1,Xt=Lt.convert(X.format),Qt=Lt.convert(X.type),Zt;if(X.isData3DTexture)v.setTexture3D(X,0),Zt=w.TEXTURE_3D;else if(X.isDataArrayTexture||X.isCompressedArrayTexture)v.setTexture2DArray(X,0),Zt=w.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}w.pixelStorei(w.UNPACK_FLIP_Y_WEBGL,X.flipY),w.pixelStorei(w.UNPACK_PREMULTIPLY_ALPHA_WEBGL,X.premultiplyAlpha),w.pixelStorei(w.UNPACK_ALIGNMENT,X.unpackAlignment);let Jt=w.getParameter(w.UNPACK_ROW_LENGTH),Be=w.getParameter(w.UNPACK_IMAGE_HEIGHT),En=w.getParameter(w.UNPACK_SKIP_PIXELS),je=w.getParameter(w.UNPACK_SKIP_ROWS),li=w.getParameter(w.UNPACK_SKIP_IMAGES),Ie=V.isCompressedTexture?V.mipmaps[G]:V.image;w.pixelStorei(w.UNPACK_ROW_LENGTH,Ie.width),w.pixelStorei(w.UNPACK_IMAGE_HEIGHT,Ie.height),w.pixelStorei(w.UNPACK_SKIP_PIXELS,T.min.x),w.pixelStorei(w.UNPACK_SKIP_ROWS,T.min.y),w.pixelStorei(w.UNPACK_SKIP_IMAGES,T.min.z),V.isDataTexture||V.isData3DTexture?w.texSubImage3D(Zt,G,N.x,N.y,N.z,wt,Ut,Vt,Xt,Qt,Ie.data):V.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),w.compressedTexSubImage3D(Zt,G,N.x,N.y,N.z,wt,Ut,Vt,Xt,Ie.data)):w.texSubImage3D(Zt,G,N.x,N.y,N.z,wt,Ut,Vt,Xt,Qt,Ie),w.pixelStorei(w.UNPACK_ROW_LENGTH,Jt),w.pixelStorei(w.UNPACK_IMAGE_HEIGHT,Be),w.pixelStorei(w.UNPACK_SKIP_PIXELS,En),w.pixelStorei(w.UNPACK_SKIP_ROWS,je),w.pixelStorei(w.UNPACK_SKIP_IMAGES,li),G===0&&X.generateMipmaps&&w.generateMipmap(Zt),q.unbindTexture()},this.initTexture=function(T){T.isCubeTexture?v.setTextureCube(T,0):T.isData3DTexture?v.setTexture3D(T,0):T.isDataArrayTexture||T.isCompressedArrayTexture?v.setTexture2DArray(T,0):v.setTexture2D(T,0),q.unbindTexture()},this.resetState=function(){C=0,A=0,R=null,q.reset(),Kt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return xi}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=t===Zl?"display-p3":"srgb",e.unpackColorSpace=_e.workingColorSpace===Bo?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===Ae?cs:kf}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===cs?Ae:_i}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}},El=class extends Zr{};El.prototype.isWebGL1Renderer=!0;var bo=class n{constructor(t,e=1,i=1e3){this.isFog=!0,this.name="",this.color=new Ft(t),this.near=e,this.far=i}clone(){return new n(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},Jr=class extends $e{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}},Sl=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=rl,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=ii()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,i){t*=this.stride,i*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[i+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ii()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(e,this.stride);return i.setUsage(this.usage),i}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ii()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},mn=new P,To=class n{constructor(t,e,i,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=i,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,i=this.data.count;e<i;e++)mn.fromBufferAttribute(this,e),mn.applyMatrix4(t),this.setXYZ(e,mn.x,mn.y,mn.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)mn.fromBufferAttribute(this,e),mn.applyNormalMatrix(t),this.setXYZ(e,mn.x,mn.y,mn.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)mn.fromBufferAttribute(this,e),mn.transformDirection(t),this.setXYZ(e,mn.x,mn.y,mn.z);return this}setX(t,e){return this.normalized&&(e=xe(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=xe(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=xe(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=xe(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=ni(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=ni(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=ni(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=ni(e,this.array)),e}setXY(t,e,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=xe(e,this.array),i=xe(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this}setXYZ(t,e,i,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=xe(e,this.array),i=xe(i,this.array),s=xe(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this}setXYZW(t,e,i,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=xe(e,this.array),i=xe(i,this.array),s=xe(s,this.array),r=xe(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let i=0;i<this.count;i++){let s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new Pe(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new n(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let i=0;i<this.count;i++){let s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},ls=class extends vi{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Ft(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Xs,Ir=new P,Ys=new P,$s=new P,qs=new ht,Dr=new ht,ed=new Se,$a=new P,Ur=new P,qa=new P,_f=new ht,Zc=new ht,yf=new ht,or=class extends $e{constructor(t=new ls){if(super(),this.isSprite=!0,this.type="Sprite",Xs===void 0){Xs=new Ue;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new Sl(e,5);Xs.setIndex([0,1,2,0,2,3]),Xs.setAttribute("position",new To(i,3,0,!1)),Xs.setAttribute("uv",new To(i,2,3,!1))}this.geometry=Xs,this.material=t,this.center=new ht(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ys.setFromMatrixScale(this.matrixWorld),ed.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),$s.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ys.multiplyScalar(-$s.z);let i=this.material.rotation,s,r;i!==0&&(r=Math.cos(i),s=Math.sin(i));let a=this.center;Za($a.set(-.5,-.5,0),$s,a,Ys,s,r),Za(Ur.set(.5,-.5,0),$s,a,Ys,s,r),Za(qa.set(.5,.5,0),$s,a,Ys,s,r),_f.set(0,0),Zc.set(1,0),yf.set(1,1);let o=t.ray.intersectTriangle($a,Ur,qa,!1,Ir);if(o===null&&(Za(Ur.set(-.5,.5,0),$s,a,Ys,s,r),Zc.set(0,1),o=t.ray.intersectTriangle($a,qa,Ur,!1,Ir),o===null))return;let c=t.ray.origin.distanceTo(Ir);c<t.near||c>t.far||e.push({distance:c,point:Ir.clone(),uv:rs.getInterpolation(Ir,$a,Ur,qa,_f,Zc,yf,new ht),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function Za(n,t,e,i,s,r){qs.subVectors(n,e).addScalar(.5).multiply(i),s!==void 0?(Dr.x=r*qs.x-s*qs.y,Dr.y=s*qs.x+r*qs.y):Dr.copy(qs),n.copy(t),n.x+=Dr.x,n.y+=Dr.y,n.applyMatrix4(ed)}var wo=class extends Pe{constructor(t,e,i,s=1){super(t,e,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},Zs=new Se,vf=new Se,Ja=[],Mf=new zn,py=new Se,Nr=new Ct,Or=new Wi,Ao=class extends Ct{constructor(t,e,i){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new wo(new Float32Array(i*16),16),this.instanceColor=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<i;s++)this.setMatrixAt(s,py)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new zn),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,Zs),Mf.copy(t.boundingBox).applyMatrix4(Zs),this.boundingBox.union(Mf)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Wi),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,Zs),Or.copy(t.boundingSphere).applyMatrix4(Zs),this.boundingSphere.union(Or)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}raycast(t,e){let i=this.matrixWorld,s=this.count;if(Nr.geometry=this.geometry,Nr.material=this.material,Nr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Or.copy(this.boundingSphere),Or.applyMatrix4(i),t.ray.intersectsSphere(Or)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Zs),vf.multiplyMatrices(i,Zs),Nr.matrixWorld=vf,Nr.raycast(t,Ja);for(let a=0,o=Ja.length;a<o;a++){let c=Ja[a];c.instanceId=r,c.object=this,e.push(c)}Ja.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new wo(new Float32Array(this.instanceMatrix.count*3),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var Kr=class extends vi{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Ft(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Ef=new Se,bl=new go,Ka=new Wi,ja=new P,jr=class extends $e{constructor(t=new Ue,e=new Kr){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){let i=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),Ka.copy(i.boundingSphere),Ka.applyMatrix4(s),Ka.radius+=r,t.ray.intersectsSphere(Ka)===!1)return;Ef.copy(s).invert(),bl.copy(t.ray).applyMatrix4(Ef);let o=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=i.index,u=i.attributes.position;if(l!==null){let f=Math.max(0,a.start),d=Math.min(l.count,a.start+a.count);for(let p=f,x=d;p<x;p++){let g=l.getX(p);ja.fromBufferAttribute(u,g),Sf(ja,g,c,s,t,e,this)}}else{let f=Math.max(0,a.start),d=Math.min(u.count,a.start+a.count);for(let p=f,x=d;p<x;p++)ja.fromBufferAttribute(u,p),Sf(ja,p,c,s,t,e,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){let s=e[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){let o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}};function Sf(n,t,e,i,s,r,a){let o=bl.distanceSqToPoint(n);if(o<e){let c=new P;bl.closestPointToPoint(n,c),c.applyMatrix4(i);let l=s.ray.origin.distanceTo(c);if(l<s.near||l>s.far)return;r.push({distance:l,distanceToRay:Math.sqrt(o),point:c,index:t,face:null,object:a})}}var Kn=class extends Fn{constructor(t,e,i,s,r,a,o,c,l){super(t,e,i,s,r,a,o,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}},kn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){let i=this.getUtoTmapping(t);return this.getPoint(i,e)}getPoints(t=5){let e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return e}getSpacedPoints(t=5){let e=[];for(let i=0;i<=t;i++)e.push(this.getPointAt(i/t));return e}getLength(){let t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let e=[],i,s=this.getPoint(0),r=0;e.push(0);for(let a=1;a<=t;a++)i=this.getPoint(a/t),r+=i.distanceTo(s),e.push(r),s=i;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){let i=this.getLengths(),s=0,r=i.length,a;e?a=e:a=t*i[r-1];let o=0,c=r-1,l;for(;o<=c;)if(s=Math.floor(o+(c-o)/2),l=i[s]-a,l<0)o=s+1;else if(l>0)c=s-1;else{c=s;break}if(s=c,i[s]===a)return s/(r-1);let h=i[s],f=i[s+1]-h,d=(a-h)/f;return(s+d)/(r-1)}getTangent(t,e){let s=t-1e-4,r=t+1e-4;s<0&&(s=0),r>1&&(r=1);let a=this.getPoint(s),o=this.getPoint(r),c=e||(a.isVector2?new ht:new P);return c.copy(o).sub(a).normalize(),c}getTangentAt(t,e){let i=this.getUtoTmapping(t);return this.getTangent(i,e)}computeFrenetFrames(t,e){let i=new P,s=[],r=[],a=[],o=new P,c=new Se;for(let d=0;d<=t;d++){let p=d/t;s[d]=this.getTangentAt(p,new P)}r[0]=new P,a[0]=new P;let l=Number.MAX_VALUE,h=Math.abs(s[0].x),u=Math.abs(s[0].y),f=Math.abs(s[0].z);h<=l&&(l=h,i.set(1,0,0)),u<=l&&(l=u,i.set(0,1,0)),f<=l&&i.set(0,0,1),o.crossVectors(s[0],i).normalize(),r[0].crossVectors(s[0],o),a[0].crossVectors(s[0],r[0]);for(let d=1;d<=t;d++){if(r[d]=r[d-1].clone(),a[d]=a[d-1].clone(),o.crossVectors(s[d-1],s[d]),o.length()>Number.EPSILON){o.normalize();let p=Math.acos(an(s[d-1].dot(s[d]),-1,1));r[d].applyMatrix4(c.makeRotationAxis(o,p))}a[d].crossVectors(s[d],r[d])}if(e===!0){let d=Math.acos(an(r[0].dot(r[t]),-1,1));d/=t,s[0].dot(o.crossVectors(r[0],r[t]))>0&&(d=-d);for(let p=1;p<=t;p++)r[p].applyMatrix4(c.makeRotationAxis(s[p],d*p)),a[p].crossVectors(s[p],r[p])}return{tangents:s,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){let t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}},Qr=class extends kn{constructor(t=0,e=0,i=1,s=1,r=0,a=Math.PI*2,o=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=i,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=c}getPoint(t,e){let i=e||new ht,s=Math.PI*2,r=this.aEndAngle-this.aStartAngle,a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(a?r=0:r=s),this.aClockwise===!0&&!a&&(r===s?r=-s:r=r-s);let o=this.aStartAngle+t*r,c=this.aX+this.xRadius*Math.cos(o),l=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),f=c-this.aX,d=l-this.aY;c=f*h-d*u+this.aX,l=f*u+d*h+this.aY}return i.set(c,l)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){let t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}},Tl=class extends Qr{constructor(t,e,i,s,r,a){super(t,e,i,i,s,r,a),this.isArcCurve=!0,this.type="ArcCurve"}};function jl(){let n=0,t=0,e=0,i=0;function s(r,a,o,c){n=r,t=o,e=-3*r+3*a-2*o-c,i=2*r-2*a+o+c}return{initCatmullRom:function(r,a,o,c,l){s(a,o,l*(o-r),l*(c-a))},initNonuniformCatmullRom:function(r,a,o,c,l,h,u){let f=(a-r)/l-(o-r)/(l+h)+(o-a)/h,d=(o-a)/h-(c-a)/(h+u)+(c-o)/u;f*=h,d*=h,s(a,o,f,d)},calc:function(r){let a=r*r,o=a*r;return n+t*r+e*a+i*o}}}var Qa=new P,Jc=new jl,Kc=new jl,jc=new jl,ta=class extends kn{constructor(t=[],e=!1,i="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=i,this.tension=s}getPoint(t,e=new P){let i=e,s=this.points,r=s.length,a=(r-(this.closed?0:1))*t,o=Math.floor(a),c=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/r)+1)*r:c===0&&o===r-1&&(o=r-2,c=1);let l,h;this.closed||o>0?l=s[(o-1)%r]:(Qa.subVectors(s[0],s[1]).add(s[0]),l=Qa);let u=s[o%r],f=s[(o+1)%r];if(this.closed||o+2<r?h=s[(o+2)%r]:(Qa.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=Qa),this.curveType==="centripetal"||this.curveType==="chordal"){let d=this.curveType==="chordal"?.5:.25,p=Math.pow(l.distanceToSquared(u),d),x=Math.pow(u.distanceToSquared(f),d),g=Math.pow(f.distanceToSquared(h),d);x<1e-4&&(x=1),p<1e-4&&(p=x),g<1e-4&&(g=x),Jc.initNonuniformCatmullRom(l.x,u.x,f.x,h.x,p,x,g),Kc.initNonuniformCatmullRom(l.y,u.y,f.y,h.y,p,x,g),jc.initNonuniformCatmullRom(l.z,u.z,f.z,h.z,p,x,g)}else this.curveType==="catmullrom"&&(Jc.initCatmullRom(l.x,u.x,f.x,h.x,this.tension),Kc.initCatmullRom(l.y,u.y,f.y,h.y,this.tension),jc.initCatmullRom(l.z,u.z,f.z,h.z,this.tension));return i.set(Jc.calc(c),Kc.calc(c),jc.calc(c)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(s.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){let s=this.points[e];t.points.push(s.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(new P().fromArray(s))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}};function bf(n,t,e,i,s){let r=(i-t)*.5,a=(s-e)*.5,o=n*n,c=n*o;return(2*e-2*i+r+a)*c+(-3*e+3*i-2*r-a)*o+r*n+e}function my(n,t){let e=1-n;return e*e*t}function gy(n,t){return 2*(1-n)*n*t}function xy(n,t){return n*n*t}function kr(n,t,e,i){return my(n,t)+gy(n,e)+xy(n,i)}function _y(n,t){let e=1-n;return e*e*e*t}function yy(n,t){let e=1-n;return 3*e*e*n*t}function vy(n,t){return 3*(1-n)*n*n*t}function My(n,t){return n*n*n*t}function Gr(n,t,e,i,s){return _y(n,t)+yy(n,e)+vy(n,i)+My(n,s)}var Ro=class extends kn{constructor(t=new ht,e=new ht,i=new ht,s=new ht){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=i,this.v3=s}getPoint(t,e=new ht){let i=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(Gr(t,s.x,r.x,a.x,o.x),Gr(t,s.y,r.y,a.y,o.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},wl=class extends kn{constructor(t=new P,e=new P,i=new P,s=new P){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=i,this.v3=s}getPoint(t,e=new P){let i=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(Gr(t,s.x,r.x,a.x,o.x),Gr(t,s.y,r.y,a.y,o.y),Gr(t,s.z,r.z,a.z,o.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},Co=class extends kn{constructor(t=new ht,e=new ht){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new ht){let i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new ht){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Al=class extends kn{constructor(t=new P,e=new P){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new P){let i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new P){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Po=class extends kn{constructor(t=new ht,e=new ht,i=new ht){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new ht){let i=e,s=this.v0,r=this.v1,a=this.v2;return i.set(kr(t,s.x,r.x,a.x),kr(t,s.y,r.y,a.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Rl=class extends kn{constructor(t=new P,e=new P,i=new P){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new P){let i=e,s=this.v0,r=this.v1,a=this.v2;return i.set(kr(t,s.x,r.x,a.x),kr(t,s.y,r.y,a.y),kr(t,s.z,r.z,a.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Lo=class extends kn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new ht){let i=e,s=this.points,r=(s.length-1)*t,a=Math.floor(r),o=r-a,c=s[a===0?a:a-1],l=s[a],h=s[a>s.length-2?s.length-1:a+1],u=s[a>s.length-3?s.length-1:a+2];return i.set(bf(o,c.x,l.x,h.x,u.x),bf(o,c.y,l.y,h.y,u.y)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){let s=this.points[e];t.points.push(s.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(new ht().fromArray(s))}return this}},Cl=Object.freeze({__proto__:null,ArcCurve:Tl,CatmullRomCurve3:ta,CubicBezierCurve:Ro,CubicBezierCurve3:wl,EllipseCurve:Qr,LineCurve:Co,LineCurve3:Al,QuadraticBezierCurve:Po,QuadraticBezierCurve3:Rl,SplineCurve:Lo}),Pl=class extends kn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){let i=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Cl[i](e,t))}return this}getPoint(t,e){let i=t*this.getLength(),s=this.getCurveLengths(),r=0;for(;r<s.length;){if(s[r]>=i){let a=s[r]-i,o=this.curves[r],c=o.getLength(),l=c===0?0:1-a/c;return o.getPointAt(l,e)}r++}return null}getLength(){let t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let t=[],e=0;for(let i=0,s=this.curves.length;i<s;i++)e+=this.curves[i].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){let e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){let e=[],i;for(let s=0,r=this.curves;s<r.length;s++){let a=r[s],o=a.isEllipseCurve?t*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?t*a.points.length:t,c=a.getPoints(o);for(let l=0;l<c.length;l++){let h=c[l];i&&i.equals(h)||(e.push(h),i=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){let s=t.curves[e];this.curves.push(s.clone())}return this.autoClose=t.autoClose,this}toJSON(){let t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,i=this.curves.length;e<i;e++){let s=this.curves[e];t.curves.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){let s=t.curves[e];this.curves.push(new Cl[s.type]().fromJSON(s))}return this}},Io=class extends Pl{constructor(t){super(),this.type="Path",this.currentPoint=new ht,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,i=t.length;e<i;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){let i=new Co(this.currentPoint.clone(),new ht(t,e));return this.curves.push(i),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,i,s){let r=new Po(this.currentPoint.clone(),new ht(t,e),new ht(i,s));return this.curves.push(r),this.currentPoint.set(i,s),this}bezierCurveTo(t,e,i,s,r,a){let o=new Ro(this.currentPoint.clone(),new ht(t,e),new ht(i,s),new ht(r,a));return this.curves.push(o),this.currentPoint.set(r,a),this}splineThru(t){let e=[this.currentPoint.clone()].concat(t),i=new Lo(e);return this.curves.push(i),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,i,s,r,a){let o=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(t+o,e+c,i,s,r,a),this}absarc(t,e,i,s,r,a){return this.absellipse(t,e,i,i,s,r,a),this}ellipse(t,e,i,s,r,a,o,c){let l=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+l,e+h,i,s,r,a,o,c),this}absellipse(t,e,i,s,r,a,o,c){let l=new Qr(t,e,i,s,r,a,o,c);if(this.curves.length>0){let u=l.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(l);let h=l.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){let t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}};var hs=class n extends Ue{constructor(t=1,e=32,i=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:i,thetaLength:s},e=Math.max(3,e);let r=[],a=[],o=[],c=[],l=new P,h=new ht;a.push(0,0,0),o.push(0,0,1),c.push(.5,.5);for(let u=0,f=3;u<=e;u++,f+=3){let d=i+u/e*s;l.x=t*Math.cos(d),l.y=t*Math.sin(d),a.push(l.x,l.y,l.z),o.push(0,0,1),h.x=(a[f]/t+1)/2,h.y=(a[f+1]/t+1)/2,c.push(h.x,h.y)}for(let u=1;u<=e;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new ce(a,3)),this.setAttribute("normal",new ce(o,3)),this.setAttribute("uv",new ce(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.segments,t.thetaStart,t.thetaLength)}},kt=class n extends Ue{constructor(t=1,e=1,i=1,s=32,r=1,a=!1,o=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:i,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:c};let l=this;s=Math.floor(s),r=Math.floor(r);let h=[],u=[],f=[],d=[],p=0,x=[],g=i/2,m=0;S(),a===!1&&(t>0&&y(!0),e>0&&y(!1)),this.setIndex(h),this.setAttribute("position",new ce(u,3)),this.setAttribute("normal",new ce(f,3)),this.setAttribute("uv",new ce(d,2));function S(){let b=new P,C=new P,A=0,R=(e-t)/i;for(let O=0;O<=r;O++){let E=[],M=O/r,U=M*(e-t)+t;for(let H=0;H<=s;H++){let rt=H/s,I=rt*c+o,F=Math.sin(I),B=Math.cos(I);C.x=U*F,C.y=-M*i+g,C.z=U*B,u.push(C.x,C.y,C.z),b.set(F,R,B).normalize(),f.push(b.x,b.y,b.z),d.push(rt,1-M),E.push(p++)}x.push(E)}for(let O=0;O<s;O++)for(let E=0;E<r;E++){let M=x[E][O],U=x[E+1][O],H=x[E+1][O+1],rt=x[E][O+1];h.push(M,U,rt),h.push(U,H,rt),A+=6}l.addGroup(m,A,0),m+=A}function y(b){let C=p,A=new ht,R=new P,O=0,E=b===!0?t:e,M=b===!0?1:-1;for(let H=1;H<=s;H++)u.push(0,g*M,0),f.push(0,M,0),d.push(.5,.5),p++;let U=p;for(let H=0;H<=s;H++){let I=H/s*c+o,F=Math.cos(I),B=Math.sin(I);R.x=E*B,R.y=g*M,R.z=E*F,u.push(R.x,R.y,R.z),f.push(0,M,0),A.x=F*.5+.5,A.y=B*.5*M+.5,d.push(A.x,A.y),p++}for(let H=0;H<s;H++){let rt=C+H,I=U+H;b===!0?h.push(I,I+1,rt):h.push(I+1,I,rt),O+=3}l.addGroup(m,O,b===!0?1:2),m+=O}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Je=class n extends kt{constructor(t=1,e=1,i=32,s=1,r=!1,a=0,o=Math.PI*2){super(0,t,e,i,s,r,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:i,heightSegments:s,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(t){return new n(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Do=class n extends Ue{constructor(t=[],e=[],i=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:i,detail:s};let r=[],a=[];o(s),l(i),h(),this.setAttribute("position",new ce(r,3)),this.setAttribute("normal",new ce(r.slice(),3)),this.setAttribute("uv",new ce(a,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(S){let y=new P,b=new P,C=new P;for(let A=0;A<e.length;A+=3)d(e[A+0],y),d(e[A+1],b),d(e[A+2],C),c(y,b,C,S)}function c(S,y,b,C){let A=C+1,R=[];for(let O=0;O<=A;O++){R[O]=[];let E=S.clone().lerp(b,O/A),M=y.clone().lerp(b,O/A),U=A-O;for(let H=0;H<=U;H++)H===0&&O===A?R[O][H]=E:R[O][H]=E.clone().lerp(M,H/U)}for(let O=0;O<A;O++)for(let E=0;E<2*(A-O)-1;E++){let M=Math.floor(E/2);E%2===0?(f(R[O][M+1]),f(R[O+1][M]),f(R[O][M])):(f(R[O][M+1]),f(R[O+1][M+1]),f(R[O+1][M]))}}function l(S){let y=new P;for(let b=0;b<r.length;b+=3)y.x=r[b+0],y.y=r[b+1],y.z=r[b+2],y.normalize().multiplyScalar(S),r[b+0]=y.x,r[b+1]=y.y,r[b+2]=y.z}function h(){let S=new P;for(let y=0;y<r.length;y+=3){S.x=r[y+0],S.y=r[y+1],S.z=r[y+2];let b=g(S)/2/Math.PI+.5,C=m(S)/Math.PI+.5;a.push(b,1-C)}p(),u()}function u(){for(let S=0;S<a.length;S+=6){let y=a[S+0],b=a[S+2],C=a[S+4],A=Math.max(y,b,C),R=Math.min(y,b,C);A>.9&&R<.1&&(y<.2&&(a[S+0]+=1),b<.2&&(a[S+2]+=1),C<.2&&(a[S+4]+=1))}}function f(S){r.push(S.x,S.y,S.z)}function d(S,y){let b=S*3;y.x=t[b+0],y.y=t[b+1],y.z=t[b+2]}function p(){let S=new P,y=new P,b=new P,C=new P,A=new ht,R=new ht,O=new ht;for(let E=0,M=0;E<r.length;E+=9,M+=6){S.set(r[E+0],r[E+1],r[E+2]),y.set(r[E+3],r[E+4],r[E+5]),b.set(r[E+6],r[E+7],r[E+8]),A.set(a[M+0],a[M+1]),R.set(a[M+2],a[M+3]),O.set(a[M+4],a[M+5]),C.copy(S).add(y).add(b).divideScalar(3);let U=g(C);x(A,M+0,S,U),x(R,M+2,y,U),x(O,M+4,b,U)}}function x(S,y,b,C){C<0&&S.x===1&&(a[y]=S.x-1),b.x===0&&b.z===0&&(a[y]=C/2/Math.PI+.5)}function g(S){return Math.atan2(S.z,-S.x)}function m(S){return Math.atan2(-S.y,Math.sqrt(S.x*S.x+S.z*S.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.vertices,t.indices,t.radius,t.details)}};var Xi=class extends Io{constructor(t){super(t),this.uuid=ii(),this.type="Shape",this.holes=[]}getPointsHoles(t){let e=[];for(let i=0,s=this.holes.length;i<s;i++)e[i]=this.holes[i].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){let s=t.holes[e];this.holes.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,i=this.holes.length;e<i;e++){let s=this.holes[e];t.holes.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){let s=t.holes[e];this.holes.push(new Io().fromJSON(s))}return this}},Ey={triangulate:function(n,t,e=2){let i=t&&t.length,s=i?t[0]*e:n.length,r=nd(n,0,s,e,!0),a=[];if(!r||r.next===r.prev)return a;let o,c,l,h,u,f,d;if(i&&(r=Ay(n,t,r,e)),n.length>80*e){o=l=n[0],c=h=n[1];for(let p=e;p<s;p+=e)u=n[p],f=n[p+1],u<o&&(o=u),f<c&&(c=f),u>l&&(l=u),f>h&&(h=f);d=Math.max(l-o,h-c),d=d!==0?32767/d:0}return ea(r,a,e,o,c,d,0),a}};function nd(n,t,e,i,s){let r,a;if(s===zy(n,t,e,i)>0)for(r=t;r<e;r+=i)a=Tf(r,n[r],n[r+1],a);else for(r=e-i;r>=t;r-=i)a=Tf(r,n[r],n[r+1],a);return a&&ko(a,a.next)&&(ia(a),a=a.next),a}function us(n,t){if(!n)return n;t||(t=n);let e=n,i;do if(i=!1,!e.steiner&&(ko(e,e.next)||De(e.prev,e,e.next)===0)){if(ia(e),e=t=e.prev,e===e.next)break;i=!0}else e=e.next;while(i||e!==t);return t}function ea(n,t,e,i,s,r,a){if(!n)return;!a&&r&&Iy(n,i,s,r);let o=n,c,l;for(;n.prev!==n.next;){if(c=n.prev,l=n.next,r?by(n,i,s,r):Sy(n)){t.push(c.i/e|0),t.push(n.i/e|0),t.push(l.i/e|0),ia(n),n=l.next,o=l.next;continue}if(n=l,n===o){a?a===1?(n=Ty(us(n),t,e),ea(n,t,e,i,s,r,2)):a===2&&wy(n,t,e,i,s,r):ea(us(n),t,e,i,s,r,1);break}}}function Sy(n){let t=n.prev,e=n,i=n.next;if(De(t,e,i)>=0)return!1;let s=t.x,r=e.x,a=i.x,o=t.y,c=e.y,l=i.y,h=s<r?s<a?s:a:r<a?r:a,u=o<c?o<l?o:l:c<l?c:l,f=s>r?s>a?s:a:r>a?r:a,d=o>c?o>l?o:l:c>l?c:l,p=i.next;for(;p!==t;){if(p.x>=h&&p.x<=f&&p.y>=u&&p.y<=d&&js(s,o,r,c,a,l,p.x,p.y)&&De(p.prev,p,p.next)>=0)return!1;p=p.next}return!0}function by(n,t,e,i){let s=n.prev,r=n,a=n.next;if(De(s,r,a)>=0)return!1;let o=s.x,c=r.x,l=a.x,h=s.y,u=r.y,f=a.y,d=o<c?o<l?o:l:c<l?c:l,p=h<u?h<f?h:f:u<f?u:f,x=o>c?o>l?o:l:c>l?c:l,g=h>u?h>f?h:f:u>f?u:f,m=Ll(d,p,t,e,i),S=Ll(x,g,t,e,i),y=n.prevZ,b=n.nextZ;for(;y&&y.z>=m&&b&&b.z<=S;){if(y.x>=d&&y.x<=x&&y.y>=p&&y.y<=g&&y!==s&&y!==a&&js(o,h,c,u,l,f,y.x,y.y)&&De(y.prev,y,y.next)>=0||(y=y.prevZ,b.x>=d&&b.x<=x&&b.y>=p&&b.y<=g&&b!==s&&b!==a&&js(o,h,c,u,l,f,b.x,b.y)&&De(b.prev,b,b.next)>=0))return!1;b=b.nextZ}for(;y&&y.z>=m;){if(y.x>=d&&y.x<=x&&y.y>=p&&y.y<=g&&y!==s&&y!==a&&js(o,h,c,u,l,f,y.x,y.y)&&De(y.prev,y,y.next)>=0)return!1;y=y.prevZ}for(;b&&b.z<=S;){if(b.x>=d&&b.x<=x&&b.y>=p&&b.y<=g&&b!==s&&b!==a&&js(o,h,c,u,l,f,b.x,b.y)&&De(b.prev,b,b.next)>=0)return!1;b=b.nextZ}return!0}function Ty(n,t,e){let i=n;do{let s=i.prev,r=i.next.next;!ko(s,r)&&id(s,i,i.next,r)&&na(s,r)&&na(r,s)&&(t.push(s.i/e|0),t.push(i.i/e|0),t.push(r.i/e|0),ia(i),ia(i.next),i=n=r),i=i.next}while(i!==n);return us(i)}function wy(n,t,e,i,s,r){let a=n;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&Ny(a,o)){let c=sd(a,o);a=us(a,a.next),c=us(c,c.next),ea(a,t,e,i,s,r,0),ea(c,t,e,i,s,r,0);return}o=o.next}a=a.next}while(a!==n)}function Ay(n,t,e,i){let s=[],r,a,o,c,l;for(r=0,a=t.length;r<a;r++)o=t[r]*i,c=r<a-1?t[r+1]*i:n.length,l=nd(n,o,c,i,!1),l===l.next&&(l.steiner=!0),s.push(Uy(l));for(s.sort(Ry),r=0;r<s.length;r++)e=Cy(s[r],e);return e}function Ry(n,t){return n.x-t.x}function Cy(n,t){let e=Py(n,t);if(!e)return t;let i=sd(e,n);return us(i,i.next),us(e,e.next)}function Py(n,t){let e=t,i=-1/0,s,r=n.x,a=n.y;do{if(a<=e.y&&a>=e.next.y&&e.next.y!==e.y){let f=e.x+(a-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(f<=r&&f>i&&(i=f,s=e.x<e.next.x?e:e.next,f===r))return s}e=e.next}while(e!==t);if(!s)return null;let o=s,c=s.x,l=s.y,h=1/0,u;e=s;do r>=e.x&&e.x>=c&&r!==e.x&&js(a<l?r:i,a,c,l,a<l?i:r,a,e.x,e.y)&&(u=Math.abs(a-e.y)/(r-e.x),na(e,n)&&(u<h||u===h&&(e.x>s.x||e.x===s.x&&Ly(s,e)))&&(s=e,h=u)),e=e.next;while(e!==o);return s}function Ly(n,t){return De(n.prev,n,t.prev)<0&&De(t.next,n,n.next)<0}function Iy(n,t,e,i){let s=n;do s.z===0&&(s.z=Ll(s.x,s.y,t,e,i)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==n);s.prevZ.nextZ=null,s.prevZ=null,Dy(s)}function Dy(n){let t,e,i,s,r,a,o,c,l=1;do{for(e=n,n=null,r=null,a=0;e;){for(a++,i=e,o=0,t=0;t<l&&(o++,i=i.nextZ,!!i);t++);for(c=l;o>0||c>0&&i;)o!==0&&(c===0||!i||e.z<=i.z)?(s=e,e=e.nextZ,o--):(s=i,i=i.nextZ,c--),r?r.nextZ=s:n=s,s.prevZ=r,r=s;e=i}r.nextZ=null,l*=2}while(a>1);return n}function Ll(n,t,e,i,s){return n=(n-e)*s|0,t=(t-i)*s|0,n=(n|n<<8)&16711935,n=(n|n<<4)&252645135,n=(n|n<<2)&858993459,n=(n|n<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,n|t<<1}function Uy(n){let t=n,e=n;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==n);return e}function js(n,t,e,i,s,r,a,o){return(s-a)*(t-o)>=(n-a)*(r-o)&&(n-a)*(i-o)>=(e-a)*(t-o)&&(e-a)*(r-o)>=(s-a)*(i-o)}function Ny(n,t){return n.next.i!==t.i&&n.prev.i!==t.i&&!Oy(n,t)&&(na(n,t)&&na(t,n)&&Fy(n,t)&&(De(n.prev,n,t.prev)||De(n,t.prev,t))||ko(n,t)&&De(n.prev,n,n.next)>0&&De(t.prev,t,t.next)>0)}function De(n,t,e){return(t.y-n.y)*(e.x-t.x)-(t.x-n.x)*(e.y-t.y)}function ko(n,t){return n.x===t.x&&n.y===t.y}function id(n,t,e,i){let s=eo(De(n,t,e)),r=eo(De(n,t,i)),a=eo(De(e,i,n)),o=eo(De(e,i,t));return!!(s!==r&&a!==o||s===0&&to(n,e,t)||r===0&&to(n,i,t)||a===0&&to(e,n,i)||o===0&&to(e,t,i))}function to(n,t,e){return t.x<=Math.max(n.x,e.x)&&t.x>=Math.min(n.x,e.x)&&t.y<=Math.max(n.y,e.y)&&t.y>=Math.min(n.y,e.y)}function eo(n){return n>0?1:n<0?-1:0}function Oy(n,t){let e=n;do{if(e.i!==n.i&&e.next.i!==n.i&&e.i!==t.i&&e.next.i!==t.i&&id(e,e.next,n,t))return!0;e=e.next}while(e!==n);return!1}function na(n,t){return De(n.prev,n,n.next)<0?De(n,t,n.next)>=0&&De(n,n.prev,t)>=0:De(n,t,n.prev)<0||De(n,n.next,t)<0}function Fy(n,t){let e=n,i=!1,s=(n.x+t.x)/2,r=(n.y+t.y)/2;do e.y>r!=e.next.y>r&&e.next.y!==e.y&&s<(e.next.x-e.x)*(r-e.y)/(e.next.y-e.y)+e.x&&(i=!i),e=e.next;while(e!==n);return i}function sd(n,t){let e=new Il(n.i,n.x,n.y),i=new Il(t.i,t.x,t.y),s=n.next,r=t.prev;return n.next=t,t.prev=n,e.next=s,s.prev=e,i.next=e,e.prev=i,r.next=i,i.prev=r,i}function Tf(n,t,e,i){let s=new Il(n,t,e);return i?(s.next=i.next,s.prev=i,i.next.prev=s,i.next=s):(s.prev=s,s.next=s),s}function ia(n){n.next.prev=n.prev,n.prev.next=n.next,n.prevZ&&(n.prevZ.nextZ=n.nextZ),n.nextZ&&(n.nextZ.prevZ=n.prevZ)}function Il(n,t,e){this.i=n,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function zy(n,t,e,i){let s=0;for(let r=t,a=e-i;r<e;r+=i)s+=(n[a]-n[r])*(n[r+1]+n[a+1]),a=r;return s}var Vr=class n{static area(t){let e=t.length,i=0;for(let s=e-1,r=0;r<e;s=r++)i+=t[s].x*t[r].y-t[r].x*t[s].y;return i*.5}static isClockWise(t){return n.area(t)<0}static triangulateShape(t,e){let i=[],s=[],r=[];wf(t),Af(i,t);let a=t.length;e.forEach(wf);for(let c=0;c<e.length;c++)s.push(a),a+=e[c].length,Af(i,e[c]);let o=Ey.triangulate(i,s);for(let c=0;c<o.length;c+=3)r.push(o.slice(c,c+3));return r}};function wf(n){let t=n.length;t>2&&n[t-1].equals(n[0])&&n.pop()}function Af(n,t){for(let e=0;e<t.length;e++)n.push(t[e].x),n.push(t[e].y)}var fs=class n extends Ue{constructor(t=new Xi([new ht(.5,.5),new ht(-.5,.5),new ht(-.5,-.5),new ht(.5,-.5)]),e={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];let i=this,s=[],r=[];for(let o=0,c=t.length;o<c;o++){let l=t[o];a(l)}this.setAttribute("position",new ce(s,3)),this.setAttribute("uv",new ce(r,2)),this.computeVertexNormals();function a(o){let c=[],l=e.curveSegments!==void 0?e.curveSegments:12,h=e.steps!==void 0?e.steps:1,u=e.depth!==void 0?e.depth:1,f=e.bevelEnabled!==void 0?e.bevelEnabled:!0,d=e.bevelThickness!==void 0?e.bevelThickness:.2,p=e.bevelSize!==void 0?e.bevelSize:d-.1,x=e.bevelOffset!==void 0?e.bevelOffset:0,g=e.bevelSegments!==void 0?e.bevelSegments:3,m=e.extrudePath,S=e.UVGenerator!==void 0?e.UVGenerator:By,y,b=!1,C,A,R,O;m&&(y=m.getSpacedPoints(h),b=!0,f=!1,C=m.computeFrenetFrames(h,!1),A=new P,R=new P,O=new P),f||(g=0,d=0,p=0,x=0);let E=o.extractPoints(l),M=E.shape,U=E.holes;if(!Vr.isClockWise(M)){M=M.reverse();for(let w=0,st=U.length;w<st;w++){let Y=U[w];Vr.isClockWise(Y)&&(U[w]=Y.reverse())}}let rt=Vr.triangulateShape(M,U),I=M;for(let w=0,st=U.length;w<st;w++){let Y=U[w];M=M.concat(Y)}function F(w,st,Y){return st||console.error("THREE.ExtrudeGeometry: vec does not exist"),w.clone().addScaledVector(st,Y)}let B=M.length,et=rt.length;function j(w,st,Y){let K,q,Rt,xt=w.x-st.x,v=w.y-st.y,_=Y.x-w.x,L=Y.y-w.y,k=xt*xt+v*v,W=xt*L-v*_;if(Math.abs(W)>Number.EPSILON){let Z=Math.sqrt(k),Et=Math.sqrt(_*_+L*L),lt=st.x-v/Z,St=st.y+xt/Z,Ot=Y.x-L/Et,Yt=Y.y+_/Et,at=((Ot-lt)*L-(Yt-St)*_)/(xt*L-v*_);K=lt+xt*at-w.x,q=St+v*at-w.y;let fe=K*K+q*q;if(fe<=2)return new ht(K,q);Rt=Math.sqrt(fe/2)}else{let Z=!1;xt>Number.EPSILON?_>Number.EPSILON&&(Z=!0):xt<-Number.EPSILON?_<-Number.EPSILON&&(Z=!0):Math.sign(v)===Math.sign(L)&&(Z=!0),Z?(K=-v,q=xt,Rt=Math.sqrt(k)):(K=xt,q=v,Rt=Math.sqrt(k/2))}return new ht(K/Rt,q/Rt)}let J=[];for(let w=0,st=I.length,Y=st-1,K=w+1;w<st;w++,Y++,K++)Y===st&&(Y=0),K===st&&(K=0),J[w]=j(I[w],I[Y],I[K]);let it=[],nt,gt=J.concat();for(let w=0,st=U.length;w<st;w++){let Y=U[w];nt=[];for(let K=0,q=Y.length,Rt=q-1,xt=K+1;K<q;K++,Rt++,xt++)Rt===q&&(Rt=0),xt===q&&(xt=0),nt[K]=j(Y[K],Y[Rt],Y[xt]);it.push(nt),gt=gt.concat(nt)}for(let w=0;w<g;w++){let st=w/g,Y=d*Math.cos(st*Math.PI/2),K=p*Math.sin(st*Math.PI/2)+x;for(let q=0,Rt=I.length;q<Rt;q++){let xt=F(I[q],J[q],K);Mt(xt.x,xt.y,-Y)}for(let q=0,Rt=U.length;q<Rt;q++){let xt=U[q];nt=it[q];for(let v=0,_=xt.length;v<_;v++){let L=F(xt[v],nt[v],K);Mt(L.x,L.y,-Y)}}}let $=p+x;for(let w=0;w<B;w++){let st=f?F(M[w],gt[w],$):M[w];b?(R.copy(C.normals[0]).multiplyScalar(st.x),A.copy(C.binormals[0]).multiplyScalar(st.y),O.copy(y[0]).add(R).add(A),Mt(O.x,O.y,O.z)):Mt(st.x,st.y,0)}for(let w=1;w<=h;w++)for(let st=0;st<B;st++){let Y=f?F(M[st],gt[st],$):M[st];b?(R.copy(C.normals[w]).multiplyScalar(Y.x),A.copy(C.binormals[w]).multiplyScalar(Y.y),O.copy(y[w]).add(R).add(A),Mt(O.x,O.y,O.z)):Mt(Y.x,Y.y,u/h*w)}for(let w=g-1;w>=0;w--){let st=w/g,Y=d*Math.cos(st*Math.PI/2),K=p*Math.sin(st*Math.PI/2)+x;for(let q=0,Rt=I.length;q<Rt;q++){let xt=F(I[q],J[q],K);Mt(xt.x,xt.y,u+Y)}for(let q=0,Rt=U.length;q<Rt;q++){let xt=U[q];nt=it[q];for(let v=0,_=xt.length;v<_;v++){let L=F(xt[v],nt[v],K);b?Mt(L.x,L.y+y[h-1].y,y[h-1].x+Y):Mt(L.x,L.y,u+Y)}}}Q(),ut();function Q(){let w=s.length/3;if(f){let st=0,Y=B*st;for(let K=0;K<et;K++){let q=rt[K];zt(q[2]+Y,q[1]+Y,q[0]+Y)}st=h+g*2,Y=B*st;for(let K=0;K<et;K++){let q=rt[K];zt(q[0]+Y,q[1]+Y,q[2]+Y)}}else{for(let st=0;st<et;st++){let Y=rt[st];zt(Y[2],Y[1],Y[0])}for(let st=0;st<et;st++){let Y=rt[st];zt(Y[0]+B*h,Y[1]+B*h,Y[2]+B*h)}}i.addGroup(w,s.length/3-w,0)}function ut(){let w=s.length/3,st=0;Pt(I,st),st+=I.length;for(let Y=0,K=U.length;Y<K;Y++){let q=U[Y];Pt(q,st),st+=q.length}i.addGroup(w,s.length/3-w,1)}function Pt(w,st){let Y=w.length;for(;--Y>=0;){let K=Y,q=Y-1;q<0&&(q=w.length-1);for(let Rt=0,xt=h+g*2;Rt<xt;Rt++){let v=B*Rt,_=B*(Rt+1),L=st+K+v,k=st+q+v,W=st+q+_,Z=st+K+_;tt(L,k,W,Z)}}}function Mt(w,st,Y){c.push(w),c.push(st),c.push(Y)}function zt(w,st,Y){ct(w),ct(st),ct(Y);let K=s.length/3,q=S.generateTopUV(i,s,K-3,K-2,K-1);mt(q[0]),mt(q[1]),mt(q[2])}function tt(w,st,Y,K){ct(w),ct(st),ct(K),ct(st),ct(Y),ct(K);let q=s.length/3,Rt=S.generateSideWallUV(i,s,q-6,q-3,q-2,q-1);mt(Rt[0]),mt(Rt[1]),mt(Rt[3]),mt(Rt[1]),mt(Rt[2]),mt(Rt[3])}function ct(w){s.push(c[w*3+0]),s.push(c[w*3+1]),s.push(c[w*3+2])}function mt(w){r.push(w.x),r.push(w.y)}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes,i=this.parameters.options;return Hy(e,i,t)}static fromJSON(t,e){let i=[];for(let r=0,a=t.shapes.length;r<a;r++){let o=e[t.shapes[r]];i.push(o)}let s=t.options.extrudePath;return s!==void 0&&(t.options.extrudePath=new Cl[s.type]().fromJSON(s)),new n(i,t.options)}},By={generateTopUV:function(n,t,e,i,s){let r=t[e*3],a=t[e*3+1],o=t[i*3],c=t[i*3+1],l=t[s*3],h=t[s*3+1];return[new ht(r,a),new ht(o,c),new ht(l,h)]},generateSideWallUV:function(n,t,e,i,s,r){let a=t[e*3],o=t[e*3+1],c=t[e*3+2],l=t[i*3],h=t[i*3+1],u=t[i*3+2],f=t[s*3],d=t[s*3+1],p=t[s*3+2],x=t[r*3],g=t[r*3+1],m=t[r*3+2];return Math.abs(o-h)<Math.abs(a-l)?[new ht(a,1-c),new ht(l,1-u),new ht(f,1-p),new ht(x,1-m)]:[new ht(o,1-c),new ht(h,1-u),new ht(d,1-p),new ht(g,1-m)]}};function Hy(n,t,e){if(e.shapes=[],Array.isArray(n))for(let i=0,s=n.length;i<s;i++){let r=n[i];e.shapes.push(r.uuid)}else e.shapes.push(n.uuid);return e.options=Object.assign({},t),t.extrudePath!==void 0&&(e.options.extrudePath=t.extrudePath.toJSON()),e}var cr=class n extends Do{constructor(t=1,e=0){let i=(1+Math.sqrt(5))/2,s=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new n(t.radius,t.detail)}},sa=class n extends Do{constructor(t=1,e=0){let i=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(i,s,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new n(t.radius,t.detail)}},ra=class n extends Ue{constructor(t=.5,e=1,i=32,s=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:i,phiSegments:s,thetaStart:r,thetaLength:a},i=Math.max(3,i),s=Math.max(1,s);let o=[],c=[],l=[],h=[],u=t,f=(e-t)/s,d=new P,p=new ht;for(let x=0;x<=s;x++){for(let g=0;g<=i;g++){let m=r+g/i*a;d.x=u*Math.cos(m),d.y=u*Math.sin(m),c.push(d.x,d.y,d.z),l.push(0,0,1),p.x=(d.x/e+1)/2,p.y=(d.y/e+1)/2,h.push(p.x,p.y)}u+=f}for(let x=0;x<s;x++){let g=x*(i+1);for(let m=0;m<i;m++){let S=m+g,y=S,b=S+i+1,C=S+i+2,A=S+1;o.push(y,b,A),o.push(b,C,A)}}this.setIndex(o),this.setAttribute("position",new ce(c,3)),this.setAttribute("normal",new ce(l,3)),this.setAttribute("uv",new ce(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}};var le=class n extends Ue{constructor(t=1,e=32,i=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:i,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),i=Math.max(2,Math.floor(i));let c=Math.min(a+o,Math.PI),l=0,h=[],u=new P,f=new P,d=[],p=[],x=[],g=[];for(let m=0;m<=i;m++){let S=[],y=m/i,b=0;m===0&&a===0?b=.5/e:m===i&&c===Math.PI&&(b=-.5/e);for(let C=0;C<=e;C++){let A=C/e;u.x=-t*Math.cos(s+A*r)*Math.sin(a+y*o),u.y=t*Math.cos(a+y*o),u.z=t*Math.sin(s+A*r)*Math.sin(a+y*o),p.push(u.x,u.y,u.z),f.copy(u).normalize(),x.push(f.x,f.y,f.z),g.push(A+b,1-y),S.push(l++)}h.push(S)}for(let m=0;m<i;m++)for(let S=0;S<e;S++){let y=h[m][S+1],b=h[m][S],C=h[m+1][S],A=h[m+1][S+1];(m!==0||a>0)&&d.push(y,b,A),(m!==i-1||c<Math.PI)&&d.push(b,C,A)}this.setIndex(d),this.setAttribute("position",new ce(p,3)),this.setAttribute("normal",new ce(x,3)),this.setAttribute("uv",new ce(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var lr=class n extends Ue{constructor(t=1,e=.4,i=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:i,tubularSegments:s,arc:r},i=Math.floor(i),s=Math.floor(s);let a=[],o=[],c=[],l=[],h=new P,u=new P,f=new P;for(let d=0;d<=i;d++)for(let p=0;p<=s;p++){let x=p/s*r,g=d/i*Math.PI*2;u.x=(t+e*Math.cos(g))*Math.cos(x),u.y=(t+e*Math.cos(g))*Math.sin(x),u.z=e*Math.sin(g),o.push(u.x,u.y,u.z),h.x=t*Math.cos(x),h.y=t*Math.sin(x),f.subVectors(u,h).normalize(),c.push(f.x,f.y,f.z),l.push(p/s),l.push(d/i)}for(let d=1;d<=i;d++)for(let p=1;p<=s;p++){let x=(s+1)*d+p-1,g=(s+1)*(d-1)+p-1,m=(s+1)*(d-1)+p,S=(s+1)*d+p;a.push(x,g,S),a.push(g,m,S)}this.setIndex(a),this.setAttribute("position",new ce(o,3)),this.setAttribute("normal",new ce(c,3)),this.setAttribute("uv",new ce(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}};var re=class extends vi{constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new Ft(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ft(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Gf,this.normalScale=new ht(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}};function no(n,t,e){return!n||!e&&n.constructor===t?n:typeof t.BYTES_PER_ELEMENT=="number"?new t(n):Array.prototype.slice.call(n)}function ky(n){return ArrayBuffer.isView(n)&&!(n instanceof DataView)}var hr=class{constructor(t,e,i,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(i),this.sampleValues=e,this.valueSize=i,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,i=this._cachedIndex,s=e[i],r=e[i-1];n:{t:{let a;e:{i:if(!(t<s)){for(let o=i+2;;){if(s===void 0){if(t<r)break i;return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)}if(i===o)break;if(r=s,s=e[++i],t<s)break t}a=e.length;break e}if(!(t>=r)){let o=e[1];t<o&&(i=2,r=o);for(let c=i-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===c)break;if(s=r,r=e[--i-1],t>=r)break t}a=i,i=0;break e}break n}for(;i<a;){let o=i+a>>>1;t<e[o]?a=o:i=o+1}if(s=e[i],r=e[i-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)}this._cachedIndex=i,this.intervalChanged_(i,r,s)}return this.interpolate_(i,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,i=this.sampleValues,s=this.valueSize,r=t*s;for(let a=0;a!==s;++a)e[a]=i[r+a];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},Dl=class extends hr{constructor(t,e,i,s){super(t,e,i,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Ru,endingEnd:Ru}}intervalChanged_(t,e,i){let s=this.parameterPositions,r=t-2,a=t+1,o=s[r],c=s[a];if(o===void 0)switch(this.getSettings_().endingStart){case Cu:r=t,o=2*e-i;break;case Pu:r=s.length-2,o=e+s[r]-s[r+1];break;default:r=t,o=i}if(c===void 0)switch(this.getSettings_().endingEnd){case Cu:a=t,c=2*i-e;break;case Pu:a=1,c=i+s[1]-s[0];break;default:a=t-1,c=e}let l=(i-e)*.5,h=this.valueSize;this._weightPrev=l/(e-o),this._weightNext=l/(c-i),this._offsetPrev=r*h,this._offsetNext=a*h}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=t*o,l=c-o,h=this._offsetPrev,u=this._offsetNext,f=this._weightPrev,d=this._weightNext,p=(i-e)/(s-e),x=p*p,g=x*p,m=-f*g+2*f*x-f*p,S=(1+f)*g+(-1.5-2*f)*x+(-.5+f)*p+1,y=(-1-d)*g+(1.5+d)*x+.5*p,b=d*g-d*x;for(let C=0;C!==o;++C)r[C]=m*a[h+C]+S*a[l+C]+y*a[c+C]+b*a[u+C];return r}},Ul=class extends hr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=t*o,l=c-o,h=(i-e)/(s-e),u=1-h;for(let f=0;f!==o;++f)r[f]=a[l+f]*u+a[c+f]*h;return r}},Nl=class extends hr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t){return this.copySampleValue_(t-1)}},jn=class{constructor(t,e,i,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=no(e,this.TimeBufferType),this.values=no(i,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,i;if(e.toJSON!==this.toJSON)i=e.toJSON(t);else{i={name:t.name,times:no(t.times,Array),values:no(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(i.interpolation=s)}return i.type=t.ValueTypeName,i}InterpolantFactoryMethodDiscrete(t){return new Nl(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new Ul(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new Dl(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case so:e=this.InterpolantFactoryMethodDiscrete;break;case ro:e=this.InterpolantFactoryMethodLinear;break;case wc:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let i="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(i);return console.warn("THREE.KeyframeTrack:",i),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return so;case this.InterpolantFactoryMethodLinear:return ro;case this.InterpolantFactoryMethodSmooth:return wc}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let i=0,s=e.length;i!==s;++i)e[i]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let i=0,s=e.length;i!==s;++i)e[i]*=t}return this}trim(t,e){let i=this.times,s=i.length,r=0,a=s-1;for(;r!==s&&i[r]<t;)++r;for(;a!==-1&&i[a]>e;)--a;if(++a,r!==0||a!==s){r>=a&&(a=Math.max(a,1),r=a-1);let o=this.getValueSize();this.times=i.slice(r,a),this.values=this.values.slice(r*o,a*o)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let i=this.times,s=this.values,r=i.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let a=null;for(let o=0;o!==r;o++){let c=i[o];if(typeof c=="number"&&isNaN(c)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,c),t=!1;break}if(a!==null&&a>c){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,c,a),t=!1;break}a=c}if(s!==void 0&&ky(s))for(let o=0,c=s.length;o!==c;++o){let l=s[o];if(isNaN(l)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,l),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),i=this.getValueSize(),s=this.getInterpolation()===wc,r=t.length-1,a=1;for(let o=1;o<r;++o){let c=!1,l=t[o],h=t[o+1];if(l!==h&&(o!==1||l!==t[0]))if(s)c=!0;else{let u=o*i,f=u-i,d=u+i;for(let p=0;p!==i;++p){let x=e[u+p];if(x!==e[f+p]||x!==e[d+p]){c=!0;break}}}if(c){if(o!==a){t[a]=t[o];let u=o*i,f=a*i;for(let d=0;d!==i;++d)e[f+d]=e[u+d]}++a}}if(r>0){t[a]=t[r];for(let o=r*i,c=a*i,l=0;l!==i;++l)e[c+l]=e[o+l];++a}return a!==t.length?(this.times=t.slice(0,a),this.values=e.slice(0,a*i)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),i=this.constructor,s=new i(this.name,t,e);return s.createInterpolant=this.createInterpolant,s}};jn.prototype.TimeBufferType=Float32Array;jn.prototype.ValueBufferType=Float32Array;jn.prototype.DefaultInterpolation=ro;var ds=class extends jn{};ds.prototype.ValueTypeName="bool";ds.prototype.ValueBufferType=Array;ds.prototype.DefaultInterpolation=so;ds.prototype.InterpolantFactoryMethodLinear=void 0;ds.prototype.InterpolantFactoryMethodSmooth=void 0;var Ol=class extends jn{};Ol.prototype.ValueTypeName="color";var Fl=class extends jn{};Fl.prototype.ValueTypeName="number";var zl=class extends hr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=(i-e)/(s-e),l=t*o;for(let h=l+o;l!==h;l+=4)si.slerpFlat(r,0,a,l-o,a,l,c);return r}},aa=class extends jn{InterpolantFactoryMethodLinear(t){return new zl(this.times,this.values,this.getValueSize(),t)}};aa.prototype.ValueTypeName="quaternion";aa.prototype.DefaultInterpolation=ro;aa.prototype.InterpolantFactoryMethodSmooth=void 0;var ps=class extends jn{};ps.prototype.ValueTypeName="string";ps.prototype.ValueBufferType=Array;ps.prototype.DefaultInterpolation=so;ps.prototype.InterpolantFactoryMethodLinear=void 0;ps.prototype.InterpolantFactoryMethodSmooth=void 0;var Bl=class extends jn{};Bl.prototype.ValueTypeName="vector";var Hl=class{constructor(t,e,i){let s=this,r=!1,a=0,o=0,c,l=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=i,this.itemStart=function(h){o++,r===!1&&s.onStart!==void 0&&s.onStart(h,a,o),r=!0},this.itemEnd=function(h){a++,s.onProgress!==void 0&&s.onProgress(h,a,o),a===o&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return c?c(h):h},this.setURLModifier=function(h){return c=h,this},this.addHandler=function(h,u){return l.push(h,u),this},this.removeHandler=function(h){let u=l.indexOf(h);return u!==-1&&l.splice(u,2),this},this.getHandler=function(h){for(let u=0,f=l.length;u<f;u+=2){let d=l[u],p=l[u+1];if(d.global&&(d.lastIndex=0),d.test(h))return p}return null}}},Gy=new Hl,kl=class{constructor(t){this.manager=t!==void 0?t:Gy,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let i=this;return new Promise(function(s,r){i.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};kl.DEFAULT_MATERIAL_NAME="__DEFAULT";var Uo=class extends $e{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Ft(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}},No=class extends Uo{constructor(t,e,i){super(t,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy($e.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ft(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},Qc=new Se,Rf=new P,Cf=new P,Gl=class{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new ht(512,512),this.map=null,this.mapPass=null,this.matrix=new Se,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new qr,this._frameExtents=new ht(1,1),this._viewportCount=1,this._viewports=[new en(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,i=this.matrix;Rf.setFromMatrixPosition(t.matrixWorld),e.position.copy(Rf),Cf.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Cf),e.updateMatrixWorld(),Qc.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Qc),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(Qc)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var Vl=class extends Gl{constructor(){super(new Eo(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Oo=class extends Uo{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy($e.DEFAULT_UP),this.updateMatrix(),this.target=new $e,this.shadow=new Vl}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var Fo=class{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=Pf(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let e=Pf();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}};function Pf(){return(typeof performance>"u"?Date:performance).now()}var Ql="\\[\\]\\.:\\/",Vy=new RegExp("["+Ql+"]","g"),th="[^"+Ql+"]",Wy="[^"+Ql.replace("\\.","")+"]",Xy=/((?:WC+[\/:])*)/.source.replace("WC",th),Yy=/(WCOD+)?/.source.replace("WCOD",Wy),$y=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",th),qy=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",th),Zy=new RegExp("^"+Xy+Yy+$y+qy+"$"),Jy=["material","materials","bones","map"],Wl=class{constructor(t,e,i){let s=i||Ce.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let i=this._targetGroup.nCachedObjects_,s=this._bindings[i];s!==void 0&&s.getValue(t,e)}setValue(t,e){let i=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=i.length;s!==r;++s)i[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,i=t.length;e!==i;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,i=t.length;e!==i;++e)t[e].unbind()}},Ce=class n{constructor(t,e,i){this.path=e,this.parsedPath=i||n.parseTrackName(e),this.node=n.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,i){return t&&t.isAnimationObjectGroup?new n.Composite(t,e,i):new n(t,e,i)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(Vy,"")}static parseTrackName(t){let e=Zy.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let i={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=i.nodeName&&i.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=i.nodeName.substring(s+1);Jy.indexOf(r)!==-1&&(i.nodeName=i.nodeName.substring(0,s),i.objectName=r)}if(i.propertyName===null||i.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return i}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let i=t.skeleton.getBoneByName(e);if(i!==void 0)return i}if(t.children){let i=function(r){for(let a=0;a<r.length;a++){let o=r[a];if(o.name===e||o.uuid===e)return o;let c=i(o.children);if(c)return c}return null},s=i(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)t[e++]=i[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,i=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=n.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(i){let l=e.objectIndex;switch(i){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===l){l=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[i]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[i]}if(l!==void 0){if(t[l]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[l]}}let a=t[s];if(a===void 0){let l=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+l+"."+s+" but it wasn't found.",t);return}let o=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}c=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=r}else a.fromArray!==void 0&&a.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(c=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=s;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Ce.Composite=Wl;Ce.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Ce.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Ce.prototype.GetterByBindingType=[Ce.prototype._getValue_direct,Ce.prototype._getValue_array,Ce.prototype._getValue_arrayElement,Ce.prototype._getValue_toArray];Ce.prototype.SetterByBindingTypeAndVersioning=[[Ce.prototype._setValue_direct,Ce.prototype._setValue_direct_setNeedsUpdate,Ce.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Ce.prototype._setValue_array,Ce.prototype._setValue_array_setNeedsUpdate,Ce.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Ce.prototype._setValue_arrayElement,Ce.prototype._setValue_arrayElement_setNeedsUpdate,Ce.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Ce.prototype._setValue_fromArray,Ce.prototype._setValue_fromArray_setNeedsUpdate,Ce.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var vM=new Float32Array(1);typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Xl}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Xl);var _t=n=>document.getElementById(n),he=(n,t,e)=>Math.max(t,Math.min(e,n)),ke=(n,t,e)=>n+(t-n)*e,It=(n,t,e)=>{let i=he((e-n)/(t-n),0,1);return i*i*(3-2*i)},ys=(n,t,e)=>Math.exp(-(((n-t)/e)**2)),sh=n=>(n%=Math.PI*2,n>Math.PI&&(n-=Math.PI*2),n<-Math.PI&&(n+=Math.PI*2),n),Wo=1,ue=()=>(Wo=Wo*16807%2147483647,(Wo-1)/2147483646),$t=(n,t)=>n+ue()*(t-n);function pr(n,t,e){let i=Math.imul(n|0,374761393)^Math.imul(t|0,668265263)^Math.imul(e|0,1442695041);return i=Math.imul(i^i>>>13,1274126177),i^=i>>>16,(i>>>0)/4294967296}function Ci(n,t,e,i){let s=Math.floor(n),r=Math.floor(t),a=n-s,o=t-r,c=a*a*(3-2*a),l=o*o*(3-2*o),h=x=>e?(x%e+e)%e:x,u=pr(h(s),h(r),i),f=pr(h(s+1),h(r),i),d=pr(h(s),h(r+1),i),p=pr(h(s+1),h(r+1),i);return ke(ke(u,f,c),ke(d,p,c),l)}function Ti(n,t,e=4,i=0,s=0){let r=.5,a=1,o=0,c=0;for(let l=0;l<e;l++)o+=r*Ci(n*a,t*a,i?i*a:0,s+l*17),c+=r,r*=.5,a*=2;return o/c}var Ma="ontouchstart"in window||navigator.maxTouchPoints>0;Ma&&document.body.classList.add("touch");var Eh="corridaCaninaTurbo1",z={musicMode:0,vib:!0,mode:0,owned:[],looks:{},stats:{},ach:[],daily:null,trophies:{},coins:400,up:{},best:{},dog:0,track:0,diff:1,laps:3,qual:Ma?1:2,music:!0,cam:0,assist:!0};try{Object.assign(z,JSON.parse(localStorage.getItem(Eh)||"{}"))}catch{}z.music===!1&&z.musicMode===0&&!("musicMode"in JSON.parse((()=>{try{return localStorage.getItem(Eh)||"{}"}catch{return"{}"}})()))&&(z.musicMode=4);function rn(){try{localStorage.setItem(Eh,JSON.stringify(z))}catch{}}var Xn=new Zr({canvas:_t("game"),antialias:!0,powerPreference:"high-performance"});Xn.outputColorSpace=Ae;Xn.toneMapping=$l;Xn.shadowMap.enabled=!0;Xn.shadowMap.type=Yl;var jy=Math.min(8,Xn.capabilities.getMaxAnisotropy()),nn=new Jr,pe=new xn(66,1,.2,2600),Jo=new No(16777215,5596740,.4);nn.add(Jo);var vn=new Oo(16777215,3);vn.castShadow=!0;Object.assign(vn.shadow.camera,{left:-42,right:42,top:42,bottom:-42,near:1,far:340});vn.shadow.bias=-4e-4;vn.shadow.normalBias=.05;nn.add(vn,vn.target);var rh=new P(.4,.6,.3).normalize(),gs={zen:{value:new Ft},hor:{value:new Ft},gnd:{value:new Ft},sunCol:{value:new Ft},sunDir:{value:new P},haze:{value:.5}},xd=new Hn({uniforms:gs,side:un,depthWrite:!1,fog:!1,vertexShader:"varying vec3 vD; void main(){ vD = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }",fragmentShader:`uniform vec3 zen, hor, gnd, sunCol, sunDir; uniform float haze; varying vec3 vD;
    void main(){
      vec3 d = normalize(vD); float h = d.y;
      vec3 c = h > 0.0 ? mix(hor, zen, pow(h, 0.5)) : mix(hor, gnd, pow(min(-h * 3.0, 1.0), 0.7));
      float sd = max(dot(d, normalize(sunDir)), 0.0);
      c += sunCol * (pow(sd, 900.0) * 14.0 + pow(sd, 40.0) * 0.45 * haze + pow(sd, 5.0) * 0.22 * haze * (1.0 - max(h, 0.0)));
      gl_FragColor = vec4(c, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`}),cc=new Ct(new le(1e3,32,16),xd);cc.frustumCulled=!1;cc.renderOrder=-10;nn.add(cc);var Qy=new ar(Xn),gr=null;function tv(){let n=new Jr;n.add(new Ct(new le(50,32,16),xd)),gr&&gr.dispose(),gr=Qy.fromScene(n,.02,.1,200),_d()}function _d(){let n=z.qual===0;nn.environment=n?null:gr&&gr.texture,Jo.intensity=At.light.hemi+(n?1.1:0)}var Sh=[{n:"BAIXA",pr:.75,sh:0},{n:"M\xC9DIA",pr:1.25,sh:1024},{n:"ALTA",pr:2,sh:2048}];function yd(){let n=Sh[z.qual];Xn.setPixelRatio(Math.min(devicePixelRatio,n.pr)),Xn.shadowMap.enabled=n.sh>0,vn.castShadow=n.sh>0,n.sh&&(vn.shadow.mapSize.set(n.sh,n.sh),vn.shadow.map&&(vn.shadow.map.dispose(),vn.shadow.map=null)),gr&&_d(),nn.traverse(t=>{t.material&&[].concat(t.material).forEach(e=>e.needsUpdate=!0)}),vd()}function vd(){Xn.setSize(innerWidth,innerHeight,!1),pe.aspect=innerWidth/innerHeight,pe.updateProjectionMatrix()}addEventListener("resize",vd);function bh(n,t){let e=document.createElement("canvas");e.width=e.height=n;let i=e.getContext("2d"),s=i.createImageData(n,n),r=s.data;for(let a=0;a<n;a++)for(let o=0;o<n;o++){let c=t(o,a),l=(a*n+o)*4;r[l]=c[0],r[l+1]=c[1],r[l+2]=c[2],r[l+3]=c[3]??255}return i.putImageData(s,0,0),e}function sn(n,t=1,e=1,i=!0){let s=new Kn(n);return i&&(s.colorSpace=Ae),s.wrapS=s.wrapT=Wr,s.repeat.set(t,e),s.anisotropy=jy,s}function ze(n,t,e){let i=document.createElement("canvas");return i.width=n,i.height=t,e(i.getContext("2d"),n,t),i}var Md=(()=>{let n=ze(256,256,(t,e,i)=>{t.fillStyle="#ececec",t.fillRect(0,0,e,i);for(let s=0;s<9e3;s++){let r=Math.random()*e,a=Math.random()*i,o=3+Math.random()*8,c=185+Math.random()*70|0;t.strokeStyle=`rgba(${c},${c},${c},.55)`,t.lineWidth=.7+Math.random()*.8,t.beginPath(),t.moveTo(r,a),t.lineTo(r+(Math.random()-.5)*2,a+o),t.stroke()}});return sn(n,2,2)})(),Th=new Kn(ze(64,64,n=>{let t=n.createRadialGradient(32,32,2,32,32,32);t.addColorStop(0,"rgba(0,0,0,.6)"),t.addColorStop(1,"rgba(0,0,0,0)"),n.fillStyle=t,n.fillRect(0,0,64,64)})),wh=new Kn(ze(64,64,n=>{let t=n.createRadialGradient(32,32,0,32,32,32);t.addColorStop(0,"rgba(255,255,255,1)"),t.addColorStop(.4,"rgba(255,255,255,.6)"),t.addColorStop(1,"rgba(255,255,255,0)"),n.fillStyle=t,n.fillRect(0,0,64,64)})),Ko=class{constructor(t,e){this.max=t,this.n=0,this.pos=new Float32Array(t*3),this.col=new Float32Array(t*3),this.size=new Float32Array(t),this.alpha=new Float32Array(t),this.vel=new Float32Array(t*3),this.life=new Float32Array(t),this.ml=new Float32Array(t),this.s0=new Float32Array(t),this.s1=new Float32Array(t),this.a0=new Float32Array(t),this.grav=new Float32Array(t),this.drag=new Float32Array(t);let i=new Ue,s=(r,a)=>{let o=new Pe(r,a);return o.setUsage(Wf),o};i.setAttribute("position",s(this.pos,3)),i.setAttribute("pcolor",s(this.col,3)),i.setAttribute("psize",s(this.size,1)),i.setAttribute("palpha",s(this.alpha,1)),this.geo=i,this.mat=new Hn({uniforms:{uScale:{value:500},map:{value:wh}},vertexShader:`attribute vec3 pcolor; attribute float psize; attribute float palpha; uniform float uScale; varying vec3 vC; varying float vA;
        void main(){ vC = pcolor; vA = palpha; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_PointSize = psize * uScale / max(0.1, -mv.z); gl_Position = projectionMatrix * mv; }`,fragmentShader:`uniform sampler2D map; varying vec3 vC; varying float vA;
        void main(){ float a = texture2D(map, gl_PointCoord).a * vA; if (a < 0.01) discard; gl_FragColor = vec4(vC, a); }`,transparent:!0,depthWrite:!1,blending:e?Gi:zi}),this.points=new jr(i,this.mat),this.points.frustumCulled=!1,nn.add(this.points)}spawn(t,e,i,s,r,a,o,c,l,h,u=1,f=0,d=1){if(this.n>=this.max)return;let p=this.n++,x=p*3;this.pos[x]=t,this.pos[x+1]=e,this.pos[x+2]=i,this.vel[x]=s,this.vel[x+1]=r,this.vel[x+2]=a,this.col[x]=h[0],this.col[x+1]=h[1],this.col[x+2]=h[2],this.life[p]=this.ml[p]=o,this.s0[p]=c,this.s1[p]=l,this.a0[p]=u,this.grav[p]=f,this.drag[p]=d,this.size[p]=c,this.alpha[p]=0}copy(t,e){for(let i=0;i<3;i++)this.pos[t*3+i]=this.pos[e*3+i],this.vel[t*3+i]=this.vel[e*3+i],this.col[t*3+i]=this.col[e*3+i];this.life[t]=this.life[e],this.ml[t]=this.ml[e],this.s0[t]=this.s0[e],this.s1[t]=this.s1[e],this.a0[t]=this.a0[e],this.grav[t]=this.grav[e],this.drag[t]=this.drag[e],this.size[t]=this.size[e],this.alpha[t]=this.alpha[e]}update(t){for(let e=0;e<this.n;e++){if(this.life[e]-=t,this.life[e]<=0){this.n--,e<this.n&&(this.copy(e,this.n),e--);continue}let i=e*3,s=Math.exp(-this.drag[e]*t);this.vel[i]*=s,this.vel[i+1]=this.vel[i+1]*s-this.grav[e]*t,this.vel[i+2]*=s,this.pos[i]+=this.vel[i]*t,this.pos[i+1]+=this.vel[i+1]*t,this.pos[i+2]+=this.vel[i+2]*t,this.pos[i+1]<.02&&(this.pos[i+1]=.02,this.vel[i+1]*=-.3);let r=1-this.life[e]/this.ml[e];this.size[e]=ke(this.s0[e],this.s1[e],r),this.alpha[e]=this.a0[e]*Math.min(1,r*10)*(1-r)}this.geo.setDrawRange(0,this.n);for(let e of["position","pcolor","psize","palpha"])this.geo.attributes[e].needsUpdate=!0;this.mat.uniforms.uScale.value=Xn.domElement.height/(2*Math.tan(Xf.degToRad(pe.fov)/2))}clear(){this.n=0}},ci=new Ko(1400,!1),In=new Ko(1200,!0);function Ms(n,t){let e=Math.abs(2*n-1);return Math.pow(Math.max(0,1-Math.pow(e,t)),1/t)}function An(n,t,e){let i=new Float32Array((n+1)*t*3),s=new Float32Array((n+1)*t*2),r=[],a=0,o=0;for(let l=0;l<=n;l++){let h=l/n;for(let u=0;u<t;u++){let f=e(h,u/t*Math.PI*2);i[a++]=f[0],i[a++]=f[1],i[a++]=f[2],s[o++]=u/t*2,s[o++]=h*2}}for(let l=0;l<n;l++)for(let h=0;h<t;h++){let u=l*t+h,f=l*t+(h+1)%t,d=u+t,p=f+t;r.push(u,f,d,f,p,d)}let c=new Ue;return c.setAttribute("position",new Pe(i,3)),c.setAttribute("uv",new Pe(s,2)),c.setIndex(r),c.computeVertexNormals(),c}function la(n,t,e,i=1){let s=Math.min(t,e)*.8,r=An(10,12,(a,o)=>{let c=ke(t,e,a)*Ms(a,4);return[Math.cos(o)*c,Math.sin(o)*c*i,-s+a*(n+2*s)]});return r.rotateX(Math.PI/2),r}function wi(n,t,e,i=14){let s=new le(1,i,Math.round(i*.75));return s.scale(n,t,e),s}function fr(n,t,e,i=1){let s=Ms(t,2.4),r=It(.3,.85,t),a=ke(n.rumpW,n.chW,r),o=ke(n.rumpH,n.chH,r),c=Math.sin(e),l=Math.cos(e),h=c*o*s;return c<0?h*=1-n.waist*ys(t,.36,.2):h+=n.arch*ys(t,.38,.22)*s,[l*a*s*i,ke(n.rumpY,0,r)+h*i,(t-.5)*n.len]}function eh(n,t){let[e,i,s]=n.skull,[r,a,o,c]=n.muzzle,l=e*.5,h=l+r,u=Math.sqrt(Math.max(0,1-(t/e)**2)),f=1;t>l&&(f=Math.pow(Math.max(0,1-Math.pow((t-l)/r,3)),1/3));let d=It(-e*.6,l,t);return{w:Math.max(i*u,a*f*d),h:Math.max(s*u,o*f*d),yc:-c*It(l-.03,l+.05,t),zStop:l,zEnd:Math.max(h,e)}}var ae=n=>new Ft(n),Gn={shepherd:{base:ae(12615482),dark:ae(2037779),light:ae(14726010)},dalmatian:{base:ae(15855592),dark:ae(1446671)},caramel:{base:ae(12611626),dark:ae(7224597),light:ae(15782042)},grey:{base:ae(8160401),light:ae(15856110)},husky:{base:ae(4673373),dark:ae(2764600),light:ae(15921904)},pug:{base:ae(14003058),dark:ae(2235674),light:ae(15255958)},pinscher:{base:ae(1446158),light:ae(11097887)},pitbull:{base:ae(9987647),light:ae(15986406),dark:ae(7226663)},boar:{base:ae(5061936),dark:ae(2366228),light:ae(8152916),hoof:ae(1446157)},opossum:{base:ae(8552314),light:ae(15526111),dark:ae(2235675),pink:ae(15321026)},gecko:{base:ae(15778634),dark:ae(2760469),light:ae(16116952),band:ae(14272488)},tegu:{base:ae(1250067),light:ae(15526367),belly:ae(14210508)}};function Ed(n,t,e){let i=t.cy,s=t.part==="head"?It(t.zStop-.03,t.zStop+.05,t.lz):0;switch(n.coat){case"shepherd":{let r=Gn.shepherd;if(t.part==="ear")return e.copy(r.dark);if(t.part==="head"){let a=It(.01,.07,t.ly)*It(t.zStop+.02,t.zStop-.05,t.lz);return e.copy(r.base).lerp(r.dark,Math.max(s*.9,a*.65))}if(t.part==="body"){let a=It(i,i+.08,t.y)*It(n.len/2,n.len/2-.22,t.z);return e.copy(r.base).lerp(r.light,It(i-n.chH*.2,i-n.chH*.8,t.y)*.6),e.lerp(r.dark,a)}return t.part==="neck"?e.copy(r.base).lerp(r.dark,It(0,.05,t.ly)*.6):t.part==="tail"?e.copy(r.base).lerp(r.dark,.72):e.copy(r.base)}case"dalmatian":{let r=Gn.dalmatian;if(t.part==="ear")return e.copy(r.dark).lerp(r.base,.1);for(let a of t.spots){let o=t.x-a[0],c=t.y-a[1],l=t.z-a[2];if(o*o+c*c+l*l<a[3]*a[3])return e.copy(r.dark)}return e.copy(r.base)}case"caramel":{let r=Gn.caramel;if(t.part==="ear")return e.copy(r.base).lerp(r.dark,.35);if(t.part==="head")return e.copy(r.base).lerp(r.light,Math.max(s*.75,It(0,-.035,t.ly)*.7));if(t.part==="body"){let a=It(i-n.chH*.1,i-n.chH*.7,t.y),o=It(n.len/2-.2,n.len/2-.05,t.z)*It(i+n.chH*.2,i-n.chH*.2,t.y);return e.copy(r.base).lerp(r.light,Math.max(a,o)*.85)}return t.part==="neck"?e.copy(r.base).lerp(r.light,It(0,-.03,t.ly)*.8):t.part==="paw"||t.part==="leg"&&t.seg>=2?e.copy(r.light):t.part==="tail"?e.copy(r.base).lerp(r.light,t.seg===3?.8:0):e.copy(r.base)}case"grey":{let r=Gn.grey;return t.part==="body"?e.copy(r.base).lerp(r.light,It(n.len/2-.22,n.len/2-.08,t.z)*It(i+n.chH*.1,i-n.chH*.3,t.y)*.9):t.part==="neck"?e.copy(r.base).lerp(r.light,It(0,-.03,t.ly)*.85):t.part==="paw"?e.copy(r.light):t.part==="head"?e.copy(r.base).lerp(r.light,It(.012,0,Math.abs(t.lx))*It(t.zStop-.05,t.zStop,t.lz)*.7):e.copy(r.base)}case"husky":{let r=Gn.husky;if(t.part==="ear")return e.copy(r.dark);if(t.part==="head"){let a=It(-.005,.045,t.ly)*It(t.zStop+.01,t.zStop-.03,t.lz),o=It(.022,.006,Math.abs(t.lx));return e.copy(r.light).lerp(r.base,a*(1-o*.9))}return t.part==="body"?e.copy(r.light).lerp(r.base,It(i-n.chH*.25,i+n.chH*.25,t.y)):t.part==="neck"?e.copy(r.light).lerp(r.base,It(-.01,.04,t.ly)):t.part==="tail"?e.copy(r.light).lerp(r.base,It(-.015,.02,t.ly)):t.part==="leg"&&t.seg===0&&!t.front?e.copy(r.base).lerp(r.light,.35):e.copy(r.light)}case"pug":{let r=Gn.pug;return t.part==="ear"?e.copy(r.dark):t.part==="head"?e.copy(r.base).lerp(r.dark,It(t.zStop-.05,t.zStop+.005,t.lz)*.95):t.part==="body"?e.copy(r.base).lerp(r.light,It(i,i-n.chH*.7,t.y)*.4):e.copy(r.base)}case"pinscher":{let r=Gn.pinscher;if(t.part==="ear")return e.copy(r.base);if(t.part==="head"){let a=Math.max(0,1-Math.hypot(Math.abs(t.lx)-.02,t.ly-.028,t.lz-(t.zStop-.01))/.012);return e.copy(r.base).lerp(r.light,Math.max(s*.95,It(-.005,-.03,t.ly)*.9,a))}return t.part==="body"?e.copy(r.base).lerp(r.light,It(n.len/2-.12,n.len/2-.03,t.z)*It(i,i-n.chH*.5,t.y)):t.part==="neck"?e.copy(r.base).lerp(r.light,It(0,-.02,t.ly)*.9):t.part==="paw"||t.part==="leg"&&t.seg>=1?e.copy(r.light):e.copy(r.base)}case"boar":{let r=Gn.boar;return t.part==="ear"||t.part==="tail"?e.copy(r.dark):t.part==="paw"?e.copy(r.hoof):t.part==="head"?e.copy(r.base).lerp(r.light,It(0,-.04,t.ly)*.5).lerp(r.dark,s*.45):t.part==="body"?e.copy(r.base).lerp(r.dark,It(i+n.chH*.2,i+n.chH*.9,t.y)*.8).lerp(r.light,It(i-n.chH*.4,i-n.chH,t.y)*.35):t.part==="neck"?e.copy(r.base).lerp(r.dark,It(0,.05,t.ly)*.7):t.part==="leg"?e.copy(r.base).lerp(r.dark,t.seg>=1?.7:.2):e.copy(r.base)}case"opossum":{let r=Gn.opossum,a=Ci(t.x*220+t.z*130,t.y*220,0,13);if(t.part==="ear")return e.copy(t.ly>n.earL*.55?r.light:r.dark);if(t.part==="head"){let[o,c,l]=n.skull,h=It(.016,.006,Math.abs(t.ly-l*.3))*It(c*.25,c*.45,Math.abs(t.lx))*It(t.zStop+.03,t.zStop-.01,t.lz),u=It(.012,.004,Math.abs(t.lx))*It(l*.3,l*.7,t.ly)*It(t.zStop,t.zStop-.04,t.lz);return e.copy(r.light).lerp(r.pink,s*It(t.zStop+n.muzzle[0]*.6,t.zStop+n.muzzle[0],t.lz)).lerp(r.dark,Math.max(h,u))}return t.part==="body"?e.copy(r.base).lerp(r.light,a>.62?.55:0).lerp(r.light,It(i-n.chH*.3,i-n.chH*.8,t.y)*.6):t.part==="neck"?e.copy(r.light).lerp(r.base,It(0,.05,t.ly)*.6):t.part==="leg"?e.copy(t.seg>=1?r.dark:r.base):t.part==="paw"?e.copy(r.pink):t.part==="tail"?e.copy(t.seg===0?r.dark:r.pink):e.copy(r.base)}case"gecko":{let r=Gn.gecko;if(t.part==="paw")return e.copy(r.light);for(let a of t.spots){let o=t.x-a[0],c=t.y-a[1],l=t.z-a[2];if(o*o+c*c+l*l<a[3]*a[3])return e.copy(r.dark)}return t.part==="body"&&t.ly<-n.chH*.35?e.copy(r.light):t.part==="tail"?e.copy(r.base).lerp(r.band,Math.sin(t.z*60)>.2?.7:.15).lerp(r.light,It(0,-.03,t.ly)*.6):t.part==="head"&&t.ly<-.012?e.copy(r.light):e.copy(r.base)}case"tegu":{let r=Gn.tegu,a=Ci(t.x*260+t.z*150,t.y*260+t.z*90,0,11);if(t.part==="body"||t.part==="tail"){if(t.ly<-n.chH*.45)return e.copy(r.belly).lerp(r.base,Math.sin(t.z*70)>.6?.8:0);let o=Math.sin(t.z*(t.part==="tail"?32:42)+Ci(t.x*30,t.z*30,0,5)*2.5)>.35;return e.copy(o&&a>.35?r.light:r.base)}return t.part==="head"?e.copy(t.ly<-.018?r.belly:a>.72?r.light:r.base):t.part==="leg"||t.part==="paw"?e.copy(a>.6?r.light:r.base):e.copy(r.base)}case"pitbull":{let r=Gn.pitbull;return t.part==="ear"?e.copy(r.dark):t.part==="head"?e.copy(r.base).lerp(r.light,It(.012,.004,Math.abs(t.lx))*It(t.zStop-.06,t.zStop,t.lz)*.9):t.part==="body"?e.copy(r.base).lerp(r.light,It(n.len/2-.2,n.len/2-.06,t.z)*It(i+n.chH*.2,i-n.chH*.3,t.y)):t.part==="neck"?e.copy(r.base).lerp(r.light,It(0,-.03,t.ly)):t.part==="paw"||t.part==="leg"&&t.seg===2?e.copy(r.light):e.copy(r.base)}}return e.set(16777215)}var Fe=[{id:"rex",name:"REX",raca:"PASTOR ALEM\xC3O",coat:"shepherd",color:"#e53935",pitch:.85,eye:3875856,len:.8,chH:.16,chW:.12,rumpH:.13,rumpW:.11,rumpY:0,waist:.3,arch:.01,backY:.6,bone:.028,neck:.2,neckA:.85,skull:[.1,.075,.07],muzzle:[.12,.04,.038,.025],ear:"erect",earW:.05,earL:.12,tail:[.52,.035,-1,.22],spd:4,acc:3,han:3,jmp:3},{id:"pingo",name:"PINGO",raca:"D\xC1LMATA",coat:"dalmatian",color:"#1e63ff",pitch:1,eye:2758411,len:.78,chH:.15,chW:.11,rumpH:.12,rumpW:.1,rumpY:0,waist:.35,arch:0,backY:.62,bone:.026,neck:.2,neckA:.8,skull:[.095,.072,.07],muzzle:[.115,.042,.04,.022],ear:"floppy",earW:.045,earL:.11,tail:[.45,.028,-.35,.06],spd:3,acc:4,han:3,jmp:3},{id:"caramelo",name:"CARAMELO",raca:"VIRA-LATA",coat:"caramel",color:"#16a34a",pitch:1.05,eye:3021324,len:.7,chH:.14,chW:.11,rumpH:.12,rumpW:.1,rumpY:0,waist:.28,arch:0,backY:.52,bone:.026,neck:.18,neckA:.8,skull:[.09,.075,.072],muzzle:[.1,.043,.04,.022],ear:"fold",earW:.045,earL:.09,tail:[.42,.03,.9,.55],spd:3,acc:3,han:4,jmp:3},{id:"flecha",name:"FLECHA",raca:"GALGO",coat:"grey",color:"#f59e0b",pitch:.95,eye:2364682,len:.82,chH:.17,chW:.085,rumpH:.1,rumpW:.08,rumpY:.02,waist:.62,arch:.035,backY:.68,bone:.022,neck:.24,neckA:.75,skull:[.1,.058,.058],muzzle:[.16,.032,.032,.018],ear:"rose",earW:.035,earL:.08,tail:[.62,.022,-1.2,.2],spd:5,acc:2,han:2,jmp:4},{id:"nevasca",name:"NEVASCA",raca:"HUSKY SIBERIANO",coat:"husky",color:"#8b5cf6",pitch:.8,eye:4891647,len:.75,chH:.15,chW:.12,rumpH:.13,rumpW:.11,rumpY:0,waist:.2,arch:0,backY:.58,bone:.028,neck:.18,neckA:.85,skull:[.095,.08,.075],muzzle:[.1,.044,.042,.022],ear:"erect",earW:.045,earL:.09,tail:[.45,.05,.8,.5],spd:4,acc:4,han:3,jmp:2},{id:"bolinha",name:"BOLINHA",raca:"PUG",coat:"pug",color:"#84cc16",pitch:1.35,eye:1707526,eyeR:.028,len:.5,chH:.15,chW:.14,rumpH:.13,rumpW:.12,rumpY:.01,waist:.05,arch:0,backY:.38,bone:.03,neck:.08,neckA:.7,skull:[.1,.105,.095],muzzle:[.03,.06,.045,.03],ear:"floppy",earW:.04,earL:.07,tail:[.2,.035,1.5,1.3],spd:2,acc:5,han:4,jmp:2},{id:"pitiquin",name:"PITIQUIN",raca:"PINSCHER",coat:"pinscher",color:"#06b6d4",pitch:1.7,eye:1182213,eyeR:.017,len:.42,chH:.095,chW:.068,rumpH:.08,rumpW:.062,rumpY:.005,waist:.35,arch:0,backY:.37,bone:.016,neck:.12,neckA:.95,skull:[.058,.045,.044],muzzle:[.06,.021,.021,.012],ear:"erect",earW:.034,earL:.08,tail:[.1,.018,1.2,.1],spd:3,acc:5,han:3,jmp:2},{id:"princesa",name:"PRINCESA",raca:"PITBULL",coat:"pitbull",color:"#ff4fa3",pitch:.9,eye:5911828,nose:7027246,crown:!0,len:.72,chH:.17,chW:.14,rumpH:.13,rumpW:.115,rumpY:0,waist:.25,arch:0,backY:.52,bone:.034,neck:.14,neckA:.75,skull:[.1,.1,.085],muzzle:[.08,.058,.05,.03],ear:"rose",earW:.04,earL:.06,tail:[.4,.035,-.6,.1],spd:4,acc:4,han:2,jmp:3},{id:"linda",name:"LINDA",raca:"JAVALI",coat:"boar",color:"#0f766e",pitch:.8,voice:"grunt",mass:1.8,eye:1707526,eyeR:.014,snoutDisc:!0,tusks:!0,mane:!0,headDown:.3,len:.82,chH:.21,chW:.15,rumpH:.17,rumpW:.135,rumpY:.01,waist:.05,arch:.03,backY:.5,bone:.032,neck:.1,neckA:.3,skull:[.11,.085,.09],muzzle:[.2,.045,.045,.03],ear:"erect",earW:.042,earL:.07,tail:[.2,.012,-1.2,.1],spd:4,acc:4,han:2,jmp:3},{id:"emilly",name:"EMILLY",raca:"SARU\xCA",coat:"opossum",noTongue:!0,color:"#be123c",pitch:2.2,voice:"hiss",mass:.8,eye:525830,eyeR:.016,nose:15179946,len:.6,chH:.13,chW:.11,rumpH:.145,rumpW:.125,rumpY:.025,waist:.05,arch:.035,backY:.35,bone:.02,neck:.08,neckA:.35,headDown:.15,skull:[.08,.06,.055],muzzle:[.13,.026,.024,.018],ear:"round",earW:.035,earL:.055,tail:[.6,.026,-.45,.2],spd:3,acc:4,han:4,jmp:2},{id:"taissa",name:"TAISSA",raca:"LAGARTIXA",kind:"lizard",coat:"gecko",color:"#facc15",pitch:1.8,voice:"hiss",mass:.6,scale:1.3,eye:1840914,eyeR:.024,len:.42,chW:.085,chH:.05,backY:.09,headL:[.15,.058,.036],bone:.013,legU:.1,gearS:.55,tailL:.42,tailR:.042,spd:2,acc:5,han:5,jmp:1},{id:"tiffany",name:"TIFFANY",raca:"TEI\xDA",kind:"lizard",coat:"tegu",color:"#f97316",pitch:1,voice:"hiss",mass:1.2,forked:!0,eye:657930,eyeR:.011,len:.68,chW:.13,chH:.075,backY:.13,headL:[.2,.068,.048],bone:.02,legU:.13,gearS:.8,tailL:.9,tailR:.068,spd:4,acc:3,han:4,jmp:2}];function Sd(n,t){let e=new Kn(ze(64,64,i=>{i.fillStyle="#fff",i.beginPath(),i.arc(32,32,29,0,7),i.fill(),i.lineWidth=6,i.strokeStyle=t,i.stroke(),i.fillStyle="#111",i.font="bold 34px Arial",i.textAlign="center",i.textBaseline="middle",i.fillText(String(n),32,34)}));return e.colorSpace=Ae,e}var bd=new re({color:1708560,roughness:.5}),ah=new re({color:1315346,roughness:.35}),Td=new re({color:14704762,roughness:.4}),jo=new re({color:12897496,roughness:.25,metalness:.6}),wd=new re({color:13703722,roughness:.3,metalness:.6}),Ad=new Bn({color:6737151,transparent:!0,opacity:.85,blending:Gi,depthWrite:!1}),Ah=new Bn({color:16769357}),lc=new Kn(ze(64,64,n=>{n.fillStyle="#ffcc00",n.beginPath(),n.arc(32,32,28,0,7),n.fill(),n.fillStyle="#111",n.font="bold 44px Arial",n.textAlign="center",n.textBaseline="middle",n.fillText("!",32,35)}));lc.colorSpace=Ae;var oh=new re({color:3818063,roughness:.4,metalness:.5}),Rh=new re({color:16742938,roughness:.4,metalness:.3,emissive:4200448}),Qo=new re({color:14753066,roughness:.3,metalness:.4}),Rd=(()=>{let n=ze(128,128,(t,e,i)=>{t.fillStyle="#e8e8e8",t.fillRect(0,0,e,i);for(let s=0;s<16;s++)for(let r=0;r<16;r++){let a=r*8+s%2*4,o=s*8,c=175+Math.random()*60|0;t.fillStyle=`rgb(${c},${c},${c})`,t.beginPath(),t.ellipse(a,o,3.6,3.1,0,0,7),t.fill()}});return sn(n,3,3)})(),rd=new Set([Md,Rd,bd,ah,Td,jo,wd,Ad,Ah,lc,Th,wh,oh,Rh,Qo]);function Cd(n,t,e,i=1){let s=new bt;s.position.set(0,t,e),s.scale.setScalar(i),n.add(s),t=0,e=0;let r=[];for(let h of[-1,1]){let u=new Ct(new kt(.026,.026,.16,12),jo);u.rotation.x=Math.PI/2,u.position.set(h*.034,t+.02,e),u.castShadow=!0,s.add(u);let f=new Ct(new le(.026,10,6,0,Math.PI*2,0,Math.PI/2),wd);f.rotation.x=Math.PI/2,f.position.set(h*.034,t+.02,e+.08),s.add(f);let d=new Ct(new kt(.012,.018,.03,8),jo);d.rotation.x=Math.PI/2,d.position.set(h*.034,t+.02,e-.095),s.add(d);let p=new Ct(new Je(.02,.2,8),Ad);p.rotation.x=-Math.PI/2,p.position.set(h*.034,t+.02,e-.21),p.visible=!1,s.add(p),r.push(p)}let a=new bt;a.position.set(0,t+.058,e+.015),s.add(a);let o=new Ct(new de(.075,.012,.09),oh);o.position.y=-.012,a.add(o);let c=[];[[-.02,.012],[.02,.012],[0,.044]].forEach(([h,u])=>{let f=new Ct(new kt(.018,.018,.15,12,1,!0),oh);f.material.side=He,f.rotation.x=Math.PI/2,f.position.set(h,u,0),f.castShadow=!0,a.add(f);let d=new Ct(new kt(.0195,.0195,.014,12),Rh);d.rotation.x=Math.PI/2,d.position.set(h,u,.06),a.add(d);let p=new Ct(new Je(.014,.034,10),Qo);p.rotation.x=Math.PI/2,p.position.set(h,u,.082),a.add(p),c.push(p)});let l=new $e;return l.position.set(0,.03,.12),a.add(l),{flames:r,launcher:{g:a,noses:c,muzzle:l}}}var Xo=2.3;function ev(n,t,e){let i=new bt,s=new bt,r=new bt;i.add(s),s.add(r);let a=new re({vertexColors:!0,map:Md,roughness:.88}),o=[],c=(v,_,L,k={},W=a)=>{let Z=new Ct(v,W);return Z.userData={part:L,...k},Z.castShadow=!0,_.add(Z),W===a&&o.push(Z),Z},l=n.backY-n.chH*.9,h=c(An(28,22,(v,_)=>fr(n,v,_)),r,"body");h.position.y=l;let[u,f,d]=n.skull,[p,x,g,m]=n.muzzle,S=new bt;S.position.set(0,l+n.chH*.3,n.len/2-.07),S.rotation.x=-n.neckA,r.add(S),c(An(10,16,(v,_)=>{let L=Ms(.5+v*.5,3)*.3+.7*(v<.9?1:Ms(.5+(v-.9)*5,2)),k=ke(n.chW*.72,f*.8,v)*L,W=ke(n.chH*.62,d*.85,v)*L;return[Math.cos(_)*k,Math.sin(_)*W,-.04+v*(n.neck+.06)]}),S,"neck");let y=new bt;y.position.set(0,0,n.neck),y.rotation.x=n.neckA-.12+(n.headDown||0),S.add(y);let b=new bt;b.position.set(0,d*.2,u*.55),y.add(b);let C=eh(n,0);c(An(34,22,(v,_)=>{let L=-u+v*(C.zEnd+u),k=eh(n,L),W=Math.sin(_);return[Math.cos(_)*k.w,k.yc+W*k.h*(W<0?.88:1),L]}),b,"head");let A=n.eye===4891647?new re({color:4891647,roughness:.05,emissive:664640}):new re({color:n.eye,roughness:.06}),R=n.eyeR||f*.24,O=[0,0,0];{let v=C.zStop-u*.08,_=eh(n,v),L=.42;for(let k of[-1,1]){let W=new Ct(new le(R,12,9),A);W.position.set(k*Math.cos(L)*_.w*.9,_.yc+Math.sin(L)*_.h*.9,v+R*.3),b.add(W),k>0&&(O=[W.position.x,W.position.y,W.position.z]);let Z=new Ct(new le(R*1.12,12,6,0,Math.PI*2,0,Math.PI*.42),bd);Z.position.copy(W.position),Z.rotation.x=-.2,b.add(Z)}}let E=Math.max(C.zStop+p-x*.25,u*.97),M=new Ct(wi(x*.62,x*.42,x*.4),n.nose?new re({color:n.nose,roughness:.35}):ah);if(M.position.set(0,-m+g*.52,E),b.add(M),n.snoutDisc){M.visible=!1;let v=new re({color:12157816,roughness:.55}),_=new Ct(new kt(x*.95,x*1,.02,22),v);_.rotation.x=Math.PI/2,_.position.set(0,-m*.9,C.zStop+p-.004),b.add(_);for(let L of[-1,1]){let k=new Ct(new le(x*.2,8,6),ah);k.scale.z=.4,k.position.set(L*x*.35,-m*.9,C.zStop+p+.007),b.add(k)}}if(n.tusks){let v=new re({color:15985366,roughness:.35});for(let _ of[-1,1]){let L=new Ct(new Je(.009,.06,8),v);L.position.set(_*x*.95,-m-g*.35,C.zStop+p*.62),L.rotation.set(-.5,0,-_*.55),L.castShadow=!0,b.add(L)}}if(n.crown){let v=new re({color:16762173,roughness:.3,metalness:.6,emissive:3810304});var U=new bt;U.position.set(0,d*.95,-u*.1),U.rotation.x=-.15,b.add(U),U.add(new Ct(new kt(.032,.036,.018,16,1,!0),v));for(let _=0;_<5;_++){let L=_/5*Math.PI*2,k=new Ct(new Je(.009,.026,6),v);k.position.set(Math.cos(L)*.032,.02,Math.sin(L)*.032),U.add(k);let W=new Ct(new le(.005,8,6),new re({color:16723338,roughness:.1,emissive:5570594}));W.position.set(Math.cos(L)*.035,.002,Math.sin(L)*.035),U.add(W)}U.traverse(_=>{_.isMesh&&(_.castShadow=!0)})}let H=new bt;H.position.set(0,-m-g*.75,C.zStop+p*.35),b.add(H);let rt=new Ct(wi(x*.55,.008,.06),Td);rt.position.set(0,-.02,.02),rt.rotation.x=.9,H.add(rt);let I=[];for(let v of[-1,1]){let _=new bt;if(_.position.set(v*f*.55,d*.7,-u*.28),b.add(_),n.ear==="round"){let L=An(8,12,(k,W)=>{let Z=n.earW*Math.pow(Math.sin(Math.PI*(.06+.94*k)),.55);return[Math.cos(W)*Z,Math.sin(W)*.01,k*n.earL]});L.rotateX(-Math.PI/2),c(L,_,"ear"),_.rotation.set(-.15,0,-v*.45)}else if(n.ear==="erect"||n.ear==="fold"){let L=An(8,12,(k,W)=>{let Z=n.earW*Math.pow(1-k,.85)*(k<.12?.75+2*k:1);return[Math.cos(W)*Z,Math.sin(W)*(.018*(1-k*.6)),k*n.earL]});L.rotateX(-Math.PI/2),c(L,_,"ear"),_.rotation.set(n.ear==="fold"?.55:-.12,0,-v*.28)}else{let L=An(8,12,(k,W)=>{let Z=n.earW*Math.pow(Math.sin(Math.PI*(.12+.88*k)),.7);return[Math.cos(W)*Z,Math.sin(W)*.013,k*n.earL]});L.rotateX(Math.PI/2),c(L,_,"ear"),_.rotation.set(n.ear==="rose"?1.3:.05,0,v*.35)}I.push({piv:_,type:n.ear,rx:_.rotation.x,rz:_.rotation.z,sx:v})}let F=[],B=n.bone;for(let v of[{f:1,sx:-1,off:0},{f:1,sx:1,off:.55},{f:0,sx:-1,off:Math.PI+.2},{f:0,sx:1,off:Math.PI+.75}]){let _=new bt;v.f?_.position.set(v.sx*n.chW*.6,l-n.chH*.2,n.len/2-.11):_.position.set(v.sx*n.rumpW*.62,l+n.rumpY,-n.len/2+.13),r.add(_);let L=_.position.y,k=L*(v.f?.44:.42),W=L*.44,Z=L*(v.f?.15:.28);c(la(k,v.f?B*2:B*2.6,v.f?B*1.25:B*1.35,v.f?1.15:1.35),_,"leg",{front:v.f,seg:0});let Et=new bt;Et.position.y=-k,_.add(Et),c(la(W,B*1.1,B*.78,1.1),Et,"leg",{front:v.f,seg:1});let lt=new bt;lt.position.y=-W,Et.add(lt),c(la(Z,B*.82,B*.72,1.1),lt,"leg",{front:v.f,seg:2});let St=c(wi(B*1.15,B*.72,B*1.55),lt,"paw",{front:v.f});St.position.set(0,-Z-B*.35,B*.7);let Ot=v.f?.45:-.55,Yt=v.f?-.45:1.15,at=v.f?-.22:-.6;_.rotation.x=Ot,Et.rotation.x=Yt,lt.rotation.x=at,F.push({hip:_,knee:Et,ank:lt,paw:St,front:v.f,off:v.off,rh:Ot,rk:Yt,ra:at})}let[et,j,J,it]=n.tail,nt=new bt;nt.position.set(0,l+n.rumpY+n.rumpH*.55,-n.len/2+.04),r.add(nt);let gt=[],$=nt;for(let v=0;v<4;v++){let _=j*(1-v/4*.55),L=j*(1-(v+1)/4*.55),k=et/4,W=An(6,10,(Et,lt)=>{let St=ke(_,L,Et)*Ms(Et,3);return[Math.cos(lt)*St,Math.sin(lt)*St,-_*.6+Et*(k+_*1.2)]});W.rotateY(Math.PI);let Z=new bt;Z.position.z=v?-k:0,$.add(Z),c(W,Z,"tail",{seg:v}),Z.rotation.x=v?it:J,gt.push(Z),$=Z}let Q=new re({color:e,roughness:.45,metalness:.15,side:He}),ut=new Ct(An(8,22,(v,_)=>fr(n,ke(.47,.72,v),_,1.07)),Q);ut.position.y=l,ut.castShadow=!0,r.add(ut);let Pt=new re({map:Sd(t,e),transparent:!0,roughness:.5});for(let v of[-1,1]){let _=fr(n,.6,v>0?0:Math.PI,1.08),L=new Ct(new _n(.12,.12),Pt);L.position.set(_[0]+v*.004,l+_[1],_[2]),L.rotation.y=v*Math.PI/2,r.add(L)}let Mt=l+fr(n,.52,Math.PI/2,1.07)[1],zt=fr(n,.5,0)[2],{flames:tt,launcher:ct}=Cd(r,Mt,zt);if(n.mane){let v=new re({color:1971986,roughness:.95});for(let _=0;_<16;_++){let L=ke(.28,.98,_/15),k=fr(n,L,Math.PI/2);if(Math.abs(k[2]-zt)<.1)continue;let W=new Ct(new Je(.014,.06+.02*Math.sin(_),5),v);W.position.set(0,l+k[1]+.012,k[2]),W.rotation.x=-.5,W.castShadow=!0,r.add(W)}}let mt=new bt;mt.position.set(0,d*2.2,0),b.add(mt);for(let v=0;v<4;v++){let _=new Ct(new sa(.025),Ah);_.position.set(Math.cos(v*1.57)*.09,0,Math.sin(v*1.57)*.09),mt.add(_)}mt.visible=!1;let w=new or(new ls({map:lc,depthTest:!1}));w.scale.set(.13,.13,1),w.position.set(0,d*2.8,0),w.visible=!1,b.add(w),s.updateMatrixWorld(!0);let st=new zn;for(let v of F)st.setFromObject(v.paw),v.hip.position.y-=st.min.y;s.updateMatrixWorld(!0);let Y=[];if(n.coat==="dalmatian")for(let v=0;v<300;v++)Y.push([$t(-.2,.2),$t(.02,.8),$t(-.6,.75),$t(.012,.03)]);let K=new P,q=new Ft;for(let v of o){let _=v.geometry.attributes.position,L=new Float32Array(_.count*3);for(let k=0;k<_.count;k++){K.fromBufferAttribute(_,k);let W=K.x,Z=K.y,Et=K.z;K.applyMatrix4(v.matrixWorld),Ed(n,{part:v.userData.part,front:v.userData.front,seg:v.userData.seg,zStop:C.zStop,lx:W,ly:Z,lz:Et,x:K.x,y:K.y,z:K.z,cy:l,spots:Y},q);let lt=(.9+.2*Ci(K.x*45+K.z*17,K.y*45,0,3))*(v.userData.part==="body"?1-.1*It(l,l+n.chH,K.y):1);L[k*3]=q.r*lt,L[k*3+1]=q.g*lt,L[k*3+2]=q.b*lt}v.geometry.setAttribute("color",new Pe(L,3))}s.scale.setScalar(Xo);let Rt=new Ct(new _n(1,1),new Bn({map:Th,transparent:!0,depthWrite:!1}));Rt.rotation.x=-Math.PI/2,Rt.position.y=.04,Rt.scale.set(n.chW*5*Xo,n.len*1.5*Xo,1),i.add(Rt);let xt={hat:[0,d*.9,-u*.12],s:f,eye:O,er:R,cape:[0,l+n.chH*.98,n.len/2-.15],capeW:n.chW,capeL:n.len};return{root:i,model:s,body:r,torso:h,neckPiv:S,headPiv:y,head:b,legs:F,tails:gt,ears:I,tongue:H,flames:tt,stars:mt,excl:w,blob:Rt,b:n,launcher:ct,anim:pv,vestMat:Q,hi:xt,crown:typeof U<"u"?U:null}}var Es={hat:{n:"CHAP\xC9US",items:[["none","NENHUM",0],["bone","BON\xC9",150],["festa","CHAP\xC9U DE FESTA",200],["cartola","CARTOLA",300],["cowboy","CHAP\xC9U DE CAUB\xD3I",350],["capacete","CAPACETE DE CORRIDA",450],["coroa","COROA DE REI",800]]},glasses:{n:"\xD3CULOS",items:[["none","NENHUM",0],["escuro","\xD3CULOS ESCUROS",150],["nerd","\xD3CULOS DE NERD",200],["aviador","AVIADOR",250],["coracao","CORA\xC7\xC3O",300]]},cape:{n:"CAPAS",items:[["none","NENHUMA",0],["vermelha","CAPA VERMELHA",300],["azul","CAPA AZUL",300],["roxa","CAPA ROXA",350],["dourada","CAPA DOURADA",600]]},vest:{n:"COLETES",items:[["padrao","COR ORIGINAL",0],["preto","PRETO",100],["branco","BRANCO",100],["vermelho","VERMELHO",100],["azul","AZUL",100],["verde","VERDE",100],["roxo","ROXO",100],["rosa","ROSA",100],["dourado","DOURADO",300]]},trail:{n:"RASTROS",items:[["none","NENHUM",0],["bolhas","BOLHAS",350],["coracoes","CORA\xC7\xD5ES",450],["estrelas","ESTRELAS",500],["fogo","FOGO",550],["arcoiris","ARCO-\xCDRIS",700]]}},Pd={preto:1842207,branco:15921906,vermelho:14163754,azul:2056191,verde:1483594,roxo:8141549,rosa:16732067,dourado:16762173},Ld={vermelha:"#d81f2a",azul:"#1f5fff",roxa:"#7c3aed",dourada:"#ffc53d"},nv={bolhas:"#9fdcff",coracoes:"#ff5f9e",estrelas:"#ffe14d",fogo:"#ff7a1a",arcoiris:"linear-gradient(90deg,#f33,#fc3,#3c6,#39f,#c3f)"},iv={bone:"#d81f2a",festa:"#ff4fa3",cartola:"#1a1a1a",cowboy:"#8a5a2b",capacete:"#f4f4f4",coroa:"#ffc53d"},sv={escuro:"#111",nerd:"#333",aviador:"#c9a24a",coracao:"#ff5f9e"},rv={hat:"none",glasses:"none",cape:"none",vest:"padrao",trail:"none"},av=(n,t)=>Es[n].items.find(e=>e[0]===t)[2]===0||z.owned.includes(n+":"+t);function hc(n){return Object.assign({},rv,z.looks[n.id]||{})}function Id(){let n=(t,e)=>Math.random()<e?Es[t].items[1+(Math.random()*(Es[t].items.length-1)|0)][0]:Es[t].items[0][0];return{hat:n("hat",.35),glasses:n("glasses",.25),cape:n("cape",.12),vest:"padrao",trail:n("trail",.15)}}function on(n,t=.5,e=0,i={}){return new re({color:n,roughness:t,metalness:e,...i})}function ov(n,t){let e=new bt,i=(s,r,a=0,o=0,c=0)=>{let l=new Ct(s,r);return l.position.set(a,o,c),l.castShadow=!0,e.add(l),l};if(n==="bone")i(new le(t*.95,18,10,0,Math.PI*2,0,Math.PI/2),on(14163754,.6)).scale.y=.75,i(new de(t*1.3,t*.06,t*.9),on(16053492,.6),0,t*.03,t*1.05),i(new le(t*.12,8,6),on(16053492),0,t*.72,0);else if(n==="festa"){let s=new Kn(ze(64,64,r=>{for(let a=0;a<8;a++)r.fillStyle=a%2?"#ffe14d":"#ff4fa3",r.fillRect(0,a*8,64,8)}));s.colorSpace=Ae,i(new Je(t*.6,t*1.9,20),on(16777215,.6,0,{map:s}),0,t*.9,0),i(new le(t*.2,10,8),on(3526911,.9),0,t*1.9,0)}else if(n==="cartola"){let s=on(1381653,.45);i(new kt(t*1.25,t*1.25,t*.08,24),s,0,t*.02,0),i(new kt(t*.72,t*.76,t*1.4,24),s,0,t*.72,0),i(new kt(t*.78,t*.78,t*.26,24),on(14163754,.5),0,t*.22,0)}else if(n==="cowboy"){let s=on(9067051,.8);i(new kt(t*1.7,t*1.7,t*.07,28),s).scale.z=.85,i(new kt(t*.72,t*.85,t*.95,20),s,0,t*.48,0),i(new kt(t*.87,t*.87,t*.2,20),on(2824718,.6),0,t*.14,0)}else if(n==="capacete")i(new le(t*1.25,22,12,0,Math.PI*2,0,Math.PI*.55),on(16053492,.15,.2),0,-t*.25,0),i(new le(t*1.27,22,12,-.3,.6,0,Math.PI*.55),on(14163754,.2),0,-t*.25,0),i(new de(t*1.2,t*.35,t*.1),on(1120810,.05,.3),0,t*.25,t*1.05);else if(n==="coroa"){let s=on(16762173,.3,.6,{emissive:3810304});i(new kt(t*.82,t*.88,t*.42,24,1,!0),s,0,t*.2,0).material.side=He;for(let r=0;r<7;r++){let a=r/7*Math.PI*2;i(new Je(t*.16,t*.42,6),s,Math.cos(a)*t*.82,t*.6,Math.sin(a)*t*.82),i(new le(t*.1,8,6),on(r%2?2976767:14753096,.1),Math.cos(a)*t*.86,t*.22,Math.sin(a)*t*.86)}}return e.rotation.x=-.15,e}function cv(n,t){let e=new bt,[i,s,r]=t.eye,a=t.er*1.7,o=r+t.er*.95,c=on({escuro:1118481,nerd:1710618,aviador:13214282,coracao:16736158}[n],.3,n==="aviador"?.7:.1),l=on({escuro:328965,nerd:13625599,aviador:3877400,coracao:16752324}[n],.05,.2,{transparent:!0,opacity:n==="nerd"?.35:.85});for(let h of[-1,1])if(n==="coracao"){let u=new Xi,f=a*1.1;u.moveTo(0,-f),u.bezierCurveTo(f*1.2,-f*.2,f*.9,f*1,0,f*.45),u.bezierCurveTo(-f*.9,f*1,-f*1.2,-f*.2,0,-f);let d=new Ct(new fs(u,{depth:a*.15,bevelEnabled:!1}),l);d.position.set(h*i,s,o),e.add(d)}else{let u=new Ct(new kt(a,a,a*.12,20),l);u.rotation.x=Math.PI/2,u.position.set(h*i,s,o),e.add(u),n==="aviador"&&u.scale.set(1,1,1.2);let f=new Ct(new lr(a,a*(n==="nerd"?.22:.13),8,24),c);f.position.set(h*i,s,o),e.add(f)}if(i>a){let h=new Ct(new de(i*2-a*1.6,a*.18,a*.18),c);h.position.set(0,s+a*.25,o),e.add(h)}return e}function lv(n,t,e){let i=Ld[n],s=new Kn(ze(64,96,c=>{let l=c.createLinearGradient(0,0,0,96);l.addColorStop(0,i),l.addColorStop(1,n==="dourada"?"#b8860b":"#00000088"),c.fillStyle=i,c.fillRect(0,0,64,96),c.fillStyle=l,c.fillRect(0,0,64,96),c.fillStyle="rgba(255,255,255,.85)",c.beginPath(),c.ellipse(32,54,8,7,0,0,7),c.fill();for(let[h,u]of[[-9,-8],[-3,-12],[3,-12],[9,-8]])c.beginPath(),c.ellipse(32+h,54+u,3,3.6,0,0,7),c.fill()}));s.colorSpace=Ae;let r=new _n(t*2.3,e*.55,1,6);r.translate(0,-e*.275,0);let a=r.attributes.position;for(let c=0;c<a.count;c++){let l=a.getY(c);a.setX(c,a.getX(c)*(1+-l/e*.6))}let o=new Ct(r,on(16777215,.6,n==="dourada"?.4:0,{map:s,side:He}));return o.castShadow=!0,o}function uc(n,t){n.lookG&&n.lookG.forEach(i=>{i.parent&&i.parent.remove(i),yr(i)}),n.lookG=[],n.cape=null,n.look=t,n.crown&&(n.crown.visible=t.hat==="none"),n.vestMat.color.set(t.vest==="padrao"?n.b.color:Pd[t.vest]),n.vestMat.metalness=t.vest==="dourado"?.7:.15;let e=n.hi;if(t.hat!=="none"){let i=ov(t.hat,e.s);i.position.set(...e.hat),n.head.add(i),n.lookG.push(i)}if(t.glasses!=="none"){let i=cv(t.glasses,e);n.head.add(i),n.lookG.push(i)}if(t.cape!=="none"){let i=new bt;i.position.set(...e.cape),i.add(lv(t.cape,e.capeW,e.capeL)),i.rotation.x=1.3,n.body.add(i),n.lookG.push(i),n.cape=i}}var Go=new Ft;function hv(n,t){let e=n.look&&n.look.trail,i=Math.hypot(n.vx,n.vz);if(!e||e==="none"||i<6||Math.random()>t*30)return;let s=n.x-Math.sin(n.h)*1.4+(Math.random()-.5)*.8,r=n.z-Math.cos(n.h)*1.4+(Math.random()-.5)*.8,a=.5+n.y+Math.random()*.6;e==="bolhas"?ci.spawn(s,a,r,Math.random()-.5,1.5,Math.random()-.5,1.4,.35,.6,[.65,.88,1],.55,-1.5,1):e==="coracoes"?In.spawn(s,a,r,0,1.2,0,.9,.45,.25,[1,.3,.6],.9,-.5,1):e==="estrelas"?In.spawn(s,a,r,(Math.random()-.5)*2,1,(Math.random()-.5)*2,.7,.3,.05,[1,.92,.4],1,0,1):e==="fogo"?In.spawn(s,.35+n.y,r,0,2.5,0,.45,.6,.15,Math.random()<.5?[1,.45,.1]:[1,.8,.2],1,-2,1):e==="arcoiris"&&(Go.setHSL((Cn*.6+Math.random()*.1)%1,.9,.6),In.spawn(s,a,r,0,.3,0,.8,.5,.35,[Go.r,Go.g,Go.b],.9,0,1))}function Dd(n,t,e){return n.kind==="lizard"?uv(n,t,e):ev(n,t,e)}function uv(n,t,e){let i=new bt,s=new bt,r=new bt;i.add(s),s.add(r);let a=new re({vertexColors:!0,map:Rd,roughness:n.coat==="tegu"?.42:.6}),o=[],c=(tt,ct,mt,w={},st=a)=>{let Y=new Ct(tt,st);return Y.userData={part:mt,...w},Y.castShadow=!0,ct.add(Y),st===a&&o.push(Y),Y},l=n.len,h=n.chW,u=n.chH,f=n.backY,d=c(An(26,20,(tt,ct)=>{let mt=Ms(tt,2.2),w=Math.sin(ct);return[Math.cos(ct)*h*mt*(1-.15*ys(tt,.1,.15)),w*u*mt*(w<0?.8:1),(tt-.5)*l]}),r,"body");d.position.y=f;let[p,x,g]=n.headL,m=new bt;m.position.set(0,f+u*.15,l/2-.03),r.add(m);let S=m;c(An(8,16,(tt,ct)=>{let mt=ke(h*.8,x*.95,tt),w=ke(u*.8,g*.95,tt);return[Math.cos(ct)*mt,Math.sin(ct)*w,-.05+tt*.09]}),m,"neck");let y=new bt;y.position.set(0,0,.04+p*.3),m.add(y),c(An(24,18,(tt,ct)=>{let mt=-p*.3+tt*p*1.3,w=Math.pow(Math.max(0,1-Math.pow(Math.abs(2*tt-1),3)),1/3),st=x*(1-.45*tt*tt)*w,Y=g*(1-.3*tt)*w,K=Math.sin(ct);return[Math.cos(ct)*st,-g*.15*tt+K*Y*(K<0?.75:1),mt]}),y,"head");let b=new re({color:n.eye,roughness:.05});for(let tt of[-1,1]){let ct=new Ct(new le(n.eyeR,14,10),b);ct.position.set(tt*x*.8,g*.42,p*.12),y.add(ct);let mt=new Ct(new le(n.eyeR*1.15,12,6,0,Math.PI*2,0,Math.PI*.35),a);mt.position.copy(ct.position),mt.rotation.z=-tt*.5,mt.userData={part:"head"},y.add(mt),o.push(mt)}let C=new bt;C.position.set(0,-g*.35,p*.95),y.add(C);let A=new re({color:n.forked?7172019:14711434,roughness:.4}),R=new Ct(new kt(.004,.005,.07,6),A);if(R.rotation.x=Math.PI/2,R.position.z=.035,C.add(R),n.forked)for(let tt of[-1,1]){let ct=new Ct(new kt(.0025,.0035,.03,5),A);ct.rotation.set(Math.PI/2,0,tt*.4),ct.position.set(tt*.006,0,.08),C.add(ct)}C.visible=!1;let O=[],E=n.bone,M=Math.PI/2-.18;for(let tt of[{f:1,sx:-1,off:0},{f:1,sx:1,off:Math.PI},{f:0,sx:-1,off:Math.PI},{f:0,sx:1,off:0}]){let ct=new bt;ct.position.set(tt.sx*h*.78,f-u*.2,(tt.f?1:-1)*l*.3),r.add(ct);let mt=new bt;mt.rotation.z=tt.sx*M,ct.add(mt);let w=n.legU;c(la(w,E*1.7,E*1.15,1.1),mt,"leg",{front:tt.f,seg:0});let st=new bt;st.position.y=-w,st.rotation.z=tt.sx*(.12-M),mt.add(st);let Y=Math.max(.025,f-u*.2-w*Math.sin(Math.PI/2-M)-E*.5);c(la(Y,E*1.15,E*.85),st,"leg",{front:tt.f,seg:1});let K=new bt;K.position.y=-Y,K.rotation.z=-tt.sx*.12,st.add(K);let q=c(wi(E*1.3,E*.5,E*1.2),K,"paw",{front:tt.f});for(let Rt=0;Rt<5;Rt++){let xt=(Rt-2)*.42+(tt.f?.15:-.1)*-tt.sx,v=c(wi(E*.32,E*.28,E*1.15),K,"paw",{front:tt.f});v.position.set(Math.sin(xt)*E*1.5,0,Math.cos(xt)*E*1.5),v.rotation.y=xt,n.coat==="gecko"&&c(new le(E*.42,8,6),K,"paw",{front:tt.f}).position.set(Math.sin(xt)*E*2.5,0,Math.cos(xt)*E*2.5)}O.push({yaw:ct,out:mt,knee:st,paw:q,front:tt.f,sx:tt.sx,off:tt.off,rest:mt.rotation.z})}let U=[],H=7,rt=n.tailL/H,I=new bt;I.position.set(0,f,-l/2+.03),r.add(I);for(let tt=0;tt<H;tt++){let ct=n.tailR*(1-tt/H*.88),mt=n.tailR*(1-(tt+1)/H*.88),w=An(6,12,(Y,K)=>{let q=ke(ct,mt,Y)*Ms(Y,3);return[Math.cos(K)*q*1.1,Math.sin(K)*q*.85,-ct*.6+Y*(rt+ct*1.2)]});w.rotateY(Math.PI);let st=new bt;st.position.z=tt?-rt:0,I.add(st),c(w,st,"tail",{seg:tt}),st.rotation.x=tt?.05:-.28,U.push(st),I=st}let F=new re({color:e,roughness:.45,metalness:.15}),B=new Ct(new le(1,22,10,0,Math.PI*2,0,Math.PI/2),F);B.scale.set(h*1.05,u*.45,l*.26),B.position.set(0,f+u*.7,0),B.castShadow=!0,r.add(B);let et=new re({map:Sd(t,e),transparent:!0,roughness:.5,side:He});for(let tt of[-1,1]){let ct=new Ct(new _n(.075,.075),et);ct.position.set(tt*(h*.98+.004),f+u*.2,0),ct.rotation.y=tt*Math.PI/2,r.add(ct)}let{flames:j,launcher:J}=Cd(r,f+u+.005,-.01,n.gearS||1),it=new bt;it.position.set(0,g*3,0),y.add(it);for(let tt=0;tt<4;tt++){let ct=new Ct(new sa(.02),Ah);ct.position.set(Math.cos(tt*1.57)*.07,0,Math.sin(tt*1.57)*.07),it.add(ct)}it.visible=!1;let nt=new or(new ls({map:lc,depthTest:!1}));nt.scale.set(.11,.11,1),nt.position.set(0,g*4.2,0),nt.visible=!1,y.add(nt),s.updateMatrixWorld(!0);let gt=new zn;for(let tt of O)gt.setFromObject(tt.paw),tt.yaw.position.y-=gt.min.y;s.updateMatrixWorld(!0);let $=[];if(n.coat==="gecko")for(let tt=0;tt<420;tt++)$.push([$t(-.12,.12),$t(.02,.2),$t(-.7,.45),$t(.006,.013)]);let Q=new P,ut=new Ft;for(let tt of o){let ct=tt.geometry.attributes.position,mt=new Float32Array(ct.count*3);for(let w=0;w<ct.count;w++){Q.fromBufferAttribute(ct,w);let st=Q.x,Y=Q.y,K=Q.z;Q.applyMatrix4(tt.matrixWorld),Ed(n,{part:tt.userData.part,front:tt.userData.front,seg:tt.userData.seg,zStop:0,lx:st,ly:Y,lz:K,x:Q.x,y:Q.y,z:Q.z,cy:f,spots:$},ut);let q=.92+.16*Ci(Q.x*60+Q.z*23,Q.y*60,0,3);mt[w*3]=ut.r*q,mt[w*3+1]=ut.g*q,mt[w*3+2]=ut.b*q}tt.geometry.setAttribute("color",new Pe(mt,3))}let Pt=Xo*(n.scale||1);s.scale.setScalar(Pt);let Mt=new Ct(new _n(1,1),new Bn({map:Th,transparent:!0,depthWrite:!1}));Mt.rotation.x=-Math.PI/2,Mt.position.y=.04,Mt.scale.set(h*6*Pt,(l+n.tailL*.6)*1.3*Pt,1),i.add(Mt);let zt={hat:[0,g*.92,p*.02],s:x*.85,eye:[x*.8,g*.42,p*.12],er:n.eyeR,cape:[0,f+u*.95,l*.28],capeW:h,capeL:l};return{root:i,model:s,body:r,torso:d,neckPiv:m,headPiv:S,head:y,legs:O,tails:U,ears:[],tongue:C,flames:j,stars:it,excl:nt,blob:Mt,b:n,launcher:J,anim:dv,vestMat:F,hi:zt,crown:null}}function fv(n,t,e){for(let i of n.flames)i.visible=t.nitro,t.nitro&&i.scale.set(1,.7+Math.random()*.6,1);n.stars.visible=t.stun>0,t.stun>0&&(n.stars.rotation.y=e*7),n.excl.visible=t.spook>0,n.blob.material.opacity=1/(1+t.y*.6),n.cape&&(n.cape.rotation.x=1.3+he(t.v/14,0,1)*.35+Math.sin(e*13)*.06*he(t.v/14,0,1))}function dv(n,t,e){let i=he(t.v/10,0,1),s=t.y>.05,r=t.phase*1.25;for(let c of n.legs){if(s){c.yaw.rotation.y=(c.front?.7:-.7)*-c.sx,c.out.rotation.z=c.rest+c.sx*.35;continue}let l=r+c.off;c.yaw.rotation.y=-c.sx*Math.sin(l)*.65*i,c.out.rotation.z=c.rest+c.sx*Math.max(0,Math.cos(l))*.35*i}let a=i>.05?i:.25;n.body.rotation.y=Math.sin(r)*.13*i,n.body.position.y=t.idle?Math.max(0,Math.sin(e*2.6))*.018:i*.015,n.neckPiv.rotation.y=-Math.sin(r)*.18*i+(t.idle?Math.sin(e*.8)*.35:he(-t.yawRate*.2,-.4,.4)),n.neckPiv.rotation.x=s?-.2:t.idle?-Math.max(0,Math.sin(e*2.6))*.12:0,n.tails.forEach((c,l)=>{c.rotation.y=Math.sin((i>.05?r:e*1.4)-l*.8)*(.2+.05*l)*a,l===0&&(c.rotation.x=s?.1:-.28)});let o=n.b.forked?Math.sin(e*2.3+n.b.len*10)>.9:Math.sin(e*1.3)>.97;n.tongue.visible=o,o&&(n.tongue.scale.z=.6+Math.abs(Math.sin(e*30))*.6),n.model.rotation.z=he(-t.yawRate*.1,-.2,.2)+(t.stun>0?Math.sin(e*18)*.15:0),fv(n,t,e)}function pv(n,t,e){let i=n.b,s=he(t.v/12,0,1),r=t.y>.05;for(let o of n.legs){let c=t.phase+o.off,l=Math.sin(c),h=Math.max(0,-Math.cos(c)),u=o.rh,f=o.rk,d=o.ra;r?o.front?(u=-.8,f=.1,d=-.1):(u=.9,f=.2,d=-.3):s>.01&&(o.front?(u+=l*.8*s,f+=(h*1.2-.1)*s,d+=h*.9*s):(u+=l*.75*s,f+=h*.7*s,d-=h*.8*s)),o.hip.rotation.x=u,o.knee.rotation.x=f,o.ank.rotation.x=d}n.body.position.y=s*.035*Math.cos(t.phase)*(r?0:1),n.body.rotation.x=s*.06*Math.sin(t.phase+.8)+(r?he(-t.vy*.03,-.35,.35):0),n.model.rotation.z=he(-t.yawRate*.16,-.32,.32)+(t.stun>0?Math.sin(e*18)*.15:0),n.neckPiv.rotation.x=-i.neckA+.28*s+Math.sin(t.phase)*.07*s,n.headPiv.rotation.x=i.neckA-.12+(i.headDown||0)-.22*s,n.head.rotation.y=he(-t.yawRate*.22,-.45,.45)+(t.idle?Math.sin(e*.7)*.35:0);for(let o of n.ears)o.type==="erect"||o.type==="fold"||o.type==="round"?o.piv.rotation.x=o.rx-.5*s+(t.idle?Math.max(0,Math.sin(e*3+o.sx))*.1:0):o.piv.rotation.x=o.rx+.9*s+Math.sin(t.phase*2)*.18*s;let a=1-s*.75;n.tails.forEach((o,c)=>{o.rotation.y=Math.sin(e*11-c*.6)*(c?.2:.45)*a,c===0&&(o.rotation.x=ke(i.tail[2],-.2,s*.6)+Math.sin(t.phase)*.1*s)}),n.tongue.visible=!i.noTongue&&(t.v>6||t.idle),n.tongue.rotation.x=Math.sin(t.phase*2)*.25*s+(t.idle?Math.sin(e*9)*.1:0),n.torso.scale.y=1+Math.sin(e*(t.v>1?9:3.5))*.012;for(let o of n.flames)o.visible=t.nitro,t.nitro&&o.scale.set(1,.7+Math.random()*.6,1);n.stars.visible=t.stun>0,t.stun>0&&(n.stars.rotation.y=e*7),n.excl.visible=t.spook>0,n.blob.material.opacity=1/(1+t.y*.6),n.cape&&(n.cape.rotation.x=1.3+he(t.v/14,0,1)*.35+Math.sin(e*13)*.06*he(t.v/14,0,1))}var As=[{id:"parque",name:"PARQUE CENTRAL",W:18,grip:1,hills:55,surface:"dirt",ground:[92,138,58],trees:"broad",puddle:"mud",ctrl:[[0,-130],[90,-140],[165,-105],[185,-30],[140,25],[150,100],[95,160],[0,150],[-55,105],[-120,140],[-180,85],[-170,0],[-115,-60],[-80,-120]],sky:{zen:2976720,hor:12376047,gnd:7043676,sun:16773336,dir:[.45,.62,.3],haze:.5},fog:[12376047,180,900],light:{sun:3.2,col:16773854,hemi:.35},rail:16053492,curb:["#d62828","#ffffff"],stand:[10133931,3039156],mtn:[5334079,7168597]},{id:"praia",name:"PRAIA DO LATIDO",W:18,grip:.9,hills:14,surface:"sand",ground:[226,204,158],trees:"palm",puddle:"water",sea:-128,ctrl:[[-200,-40],[-120,-90],[0,-100],[120,-95],[200,-60],[230,10],[190,70],[110,80],[60,40],[0,50],[-50,110],[-130,120],[-210,60]],sky:{zen:2964358,hor:16753768,gnd:9071192,sun:16756848,dir:[.2,.09,-.97],haze:1.3},fog:[15770748,160,850],light:{sun:2.8,col:16758405,hemi:.3},rail:9132587,curb:["#1e88e5","#ffffff"],stand:[12028762,1019816],mtn:[8022610,6253386]},{id:"neve",name:"PICO NEVADO",W:18,grip:.78,hills:80,surface:"snow",ground:[236,241,248],trees:"pine",puddle:"ice",snow:!0,ctrl:[[0,-150],[100,-160],[170,-110],[150,-40],[200,20],[180,110],[100,150],[40,100],[-20,140],[-110,150],[-170,90],[-130,30],[-190,-40],[-120,-120]],sky:{zen:6260408,hor:14542834,gnd:13621474,sun:16774890,dir:[-.4,.42,.5],haze:.8},fog:[14542834,110,620],light:{sun:2.4,col:15922943,hemi:.5},rail:13840175,curb:["#d32f2f","#ffffff"],stand:[9268835,12000284],mtn:[5923954,7173508]}],At=As[0],Nt=18,Le=1,Xe=1400,Ye=[],Qn=[],Ts=[],vs=[];function mv(n){let t=new ta(n.ctrl.map(e=>new P(e[0],0,e[1])),!0,"centripetal");Le=t.getLength(),Ye.length=Qn.length=Ts.length=vs.length=0;for(let e=0;e<Xe;e++){let i=e/Xe,s=t.getPointAt(i),r=t.getTangentAt(i);r.y=0,r.normalize(),Ye.push(s),Qn.push(r),Ts.push(new P(-r.z,0,r.x)),e%6===0&&vs.push(s)}}var fc=n=>(n%Le+Le)%Le,Mn=n=>(n=fc(n),n>Le/2?n-Le:n),ad=new P,Vo=new P,od=new P;function br(n){let t=fc(n)/Le*Xe,e=Math.floor(t)%Xe,i=(e+1)%Xe,s=t-Math.floor(t);return ad.copy(Ye[e]).lerp(Ye[i],s),Vo.copy(Qn[e]).lerp(Qn[i],s).normalize(),od.set(-Vo.z,0,Vo.x),{p:ad,t:Vo,r:od}}function Ve(n,t,e=0){let i=br(n);return new P(i.p.x+i.r.x*t,e,i.p.z+i.r.z*t)}function ri(n){let t=br(n);return Math.atan2(t.t.x,t.t.z)}function Ch(n,t){let e=!1;for(let i=0,s=vs.length-1;i<vs.length;s=i++){let r=vs[i],a=vs[s];r.z>t!=a.z>t&&n<(a.x-r.x)*(t-r.z)/(a.z-r.z)+r.x&&(e=!e)}return e}function Ph(n,t){let e=1/0;for(let i of vs){let s=i.x-n,r=i.z-t,a=s*s+r*r;a<e&&(e=a)}return Math.sqrt(e)}function _s(n,t){let e=Ph(n,t);if(At.sea!==void 0&&t<At.sea)return Math.max(-7,-(At.sea-t)*.09)*It(Nt/2+6,Nt/2+22,e);let i=It(Nt/2+16,Nt/2+110,e)*It(70,150,Math.hypot(n-Ye[0].x,t-Ye[0].z));return i<=0||Ch(n,t)?0:i*Math.max(0,Ti(n*.004+31,t*.004+17,4)-.3)*At.hills}var Re=null,Lh=[],Ih=[],ha=null,tc=null,Dh=[],Ai=null,xr=null,$i=[],ch=[],ec=[],nc=[],_r=[],ma=[],ga=[],lh=null,ua=null,pt=(n,t=.85,e=0,i={})=>new re({color:n,roughness:t,metalness:e,...i});function Tt(n,t,e=!0,i=!0,s=Re){let r=new Ct(n,t);return r.castShadow=e,r.receiveShadow=i,s.add(r),r}function Tn(n,t,e,i=!0){let s=new Ao(n,t,e);return s.castShadow=i,s.receiveShadow=!0,s.frustumCulled=!1,Re.add(s),s}var cd=new Se,ld=new si,gv=new sr,te=new P,xv=new P;function wn(n,t,e,i,s,r,a,o,c,l,h){ld.setFromEuler(gv.set(r,a,o)),cd.compose(te.set(e,i,s),ld,xv.set(c,l??c,h??c)),n.setMatrixAt(t,cd)}function yr(n){n.traverse(t=>{t.geometry&&t.geometry.dispose(),t.material&&[].concat(t.material).forEach(e=>{if(!rd.has(e)){for(let i of["map","bumpMap","normalMap","emissiveMap"])e[i]&&!rd.has(e[i])&&e[i].dispose();e.dispose()}})})}function oa(n,t,e,i,s,r=!0){let a=[],o=[],c=[];for(let h=0;h<=Xe;h++){let u=h%Xe,f=Ye[u],d=Ts[u];a.push(f.x+d.x*n,e,f.z+d.z*n,f.x+d.x*t,e,f.z+d.z*t);let p=h/Xe*Le/i;if(o.push(0,p,1,p),h<Xe){let x=h*2;c.push(x,x+1,x+2,x+1,x+3,x+2)}}let l=new Ue;return l.setAttribute("position",new ce(a,3)),l.setAttribute("uv",new ce(o,2)),l.setIndex(c),l.computeVertexNormals(),Tt(l,s,!1,r)}function hd(n,t,e,i){let s=[],r=[];for(let c=0;c<=Xe;c+=2){let l=c%Xe,h=Ye[l],u=Ts[l];s.push(h.x+u.x*n,t,h.z+u.z*n,h.x+u.x*n,e,h.z+u.z*n)}let a=s.length/6;for(let c=0;c<a-1;c++){let l=c*2;r.push(l,l+2,l+1,l+1,l+2,l+3)}let o=new Ue;o.setAttribute("position",new ce(s,3)),o.setIndex(r),o.computeVertexNormals(),Tt(o,i,!0,!0)}function _v(n){let e=As.indexOf(At)*13,i=bh(256,(r,a)=>{let o=Ti(r/32,a/32,5,8,e),c=Ti(r/8,a/8,3,32,e+5),l=pr(r,a,e+9),h=1-.07*ys(r/256,.33,.07)-.07*ys(r/256,.67,.07);if(n==="dirt"){let d=132+o*70+c*18,p=90+o*50+c*14,x=56+o*32+c*8;return l>.985?(d+=40,p+=36,x+=30):l<.012&&(d-=40,p-=34,x-=24),[d*h,p*h,x*h]}if(n==="sand"){let d=Math.sin(a*.45+o*9)*7;return[(178+o*30+d)*h,(146+o*26+d)*h,(102+o*20+d*.6)*h]}let u=l>.992?20:0,f=1-.1*ys(r/256,.25,.05)-.1*ys(r/256,.75,.05);return[(158+o*34+u)*h*f,(172+o*26+u)*h*f,(196+o*16+u)*h*f]}),s=i.getContext("2d");for(let r=0;r<70;r++){let a=30+ue()*196,o=ue()*256,c=ue()*.4-.2;s.save(),s.translate(a,o),s.rotate(c),s.fillStyle=n==="snow"?"rgba(120,140,170,.22)":"rgba(40,24,10,.22)",s.beginPath(),s.ellipse(0,4,4,3.5,0,0,7),s.fill();for(let[l,h]of[[-4,-2],[-1.4,-4.5],[1.4,-4.5],[4,-2]])s.beginPath(),s.ellipse(l,h,1.5,1.8,0,0,7),s.fill();s.restore()}return i}function yv(){let[n,t,e]=At.ground,i=As.indexOf(At)*7+3,s=bh(256,(r,a)=>{let o=Ti(r/16,a/16,4,16,i),c=pr(r,a,i),l=.78+o*.4+(c-.5)*(At.ground[0]<150?.22:.08);return[n*l,t*l,e*l]});if(At.trees==="broad"){let r=s.getContext("2d");for(let a=0;a<2600;a++){let o=ue()*256,c=ue()*256,l=110+ue()*90|0;r.strokeStyle=`rgba(${l*.55|0},${l},${l*.35|0},.5)`,r.lineWidth=1,r.beginPath(),r.moveTo(o,c),r.lineTo(o+ue()*2-1,c-2-ue()*3),r.stroke()}}return s}function Uh(n){Re&&(nn.remove(Re),yr(Re)),ci.clear(),In.clear(),At=As[n],Nt=At.W,Wo=1e3+n*77,mv(At),Re=new bt,nn.add(Re),ga=[],Lh=[],Ih=[],Dh=[];let t=At.sky;gs.zen.value.setHex(t.zen),gs.hor.value.setHex(t.hor),gs.gnd.value.setHex(t.gnd),gs.sunCol.value.setHex(t.sun),rh.set(...t.dir).normalize(),gs.sunDir.value.copy(rh),gs.haze.value=t.haze,nn.fog=new bo(At.fog[0],At.fog[1],At.fog[2]),vn.color.setHex(At.light.col),vn.intensity=At.light.sun,Jo.color.setHex(t.hor),Jo.groundColor.setHex(t.gnd),tv(),vv(),Mv(),Ev(),Sv(),bv(),wv(),Rv(),Cv(),Pv(),Lv(),Uv(),Nv(),zv(),Kv(),Bv(),Ai&&(nn.remove(Ai),Ai.geometry.dispose(),Ai=null),At.snow&&Iv()}function vv(){let t=z.qual===0?100:150,e=new _n(1700,1700,t,t);e.rotateX(-Math.PI/2);let i=e.attributes.position,s=e.attributes.uv,r=new Float32Array(i.count*3);for(let c=0;c<i.count;c++){let l=i.getX(c),h=i.getZ(c),u=_s(l,h);i.setY(c,u),s.setXY(c,l/9,h/9);let f=.82+.36*Ti(l*.012,h*.012,3,0,5),d=f,p=f,x=f;if(At.id==="parque"){let g=It(.55,.75,Ti(l*.006+5,h*.006,3));d+=g*.25,x-=g*.1}if(At.id==="praia"&&u<-.3&&(d*=.8,p*=.78,x*=.72),At.id==="neve"&&u>20){let g=It(.62,.72,Ti(l*.03,h*.03,2));d-=g*.45,p-=g*.42,x-=g*.38}r[c*3]=d,r[c*3+1]=p,r[c*3+2]=x}e.setAttribute("color",new Pe(r,3)),e.computeVertexNormals();let a=sn(yv());Tt(e,new re({map:a,vertexColors:!0,roughness:At.id==="neve"?.7:1}),!1,!0);let o=Tt(new _n(9e3,9e3),new re({color:new Ft(`rgb(${At.ground.join(",")})`).multiplyScalar(.8),roughness:1}),!1,!1);if(o.rotation.x=-Math.PI/2,o.position.y=At.sea!==void 0?-8:-.4,xr=null,At.sea!==void 0){let c=bh(128,(h,u)=>{let f=(x,g)=>Ti(x/16,g/16,3,8,77),d=f(h+1,u)-f(h-1,u),p=f(h,u+1)-f(h,u-1);return[128-d*400,128-p*400,255]});xr=sn(c,40,40,!1);let l=Tt(new _n(4e3,4e3),new re({color:1007490,roughness:.12,metalness:.1,normalMap:xr,normalScale:new ht(.6,.6)}),!1,!1);l.rotation.x=-Math.PI/2,l.position.set(0,-1.1,-1400)}}function Mv(){let n=_v(At.surface),t=sn(n),e=At.surface==="snow"?.55:.95;oa(-Nt/2,Nt/2,.03,Nt,new re({map:t,bumpMap:sn(n,1,1,!1),bumpScale:1.2,roughness:e}));let i=sn(ze(4,8,a=>{a.fillStyle=At.curb[0],a.fillRect(0,0,4,4),a.fillStyle=At.curb[1],a.fillRect(0,4,4,4)}));i.magFilter=tn;let s=new re({map:i,roughness:.6});oa(-Nt/2-1.3,-Nt/2,.05,6,s),oa(Nt/2,Nt/2+1.3,.05,6,s);let r=new re({map:t,roughness:1,color:13619151});oa(-Nt/2-2.6,-Nt/2-1.3,.035,Nt,r),oa(Nt/2+1.3,Nt/2+2.6,.035,Nt,r)}function Ev(){let n=At.id==="praia",t=pt(At.rail,n?.9:.35,n?0:.3,{side:He});for(let r of[-1,1])hd(r*(Nt/2+2.6),.95,1.12,t),hd(r*(Nt/2+2.6),.45,.58,t);let e=Math.floor(Le/4)*2,i=Tn(new kt(.08,.1,1.25,5),pt(n?7029795:14606046,.5,n?0:.6),e),s=0;for(let r=0;r<Le-2&&s<e-1;r+=4)for(let a of[-1,1]){let o=Ve(r,a*(Nt/2+2.6));wn(i,s++,o.x,.62,o.z,0,0,0,1)}i.count=s}function Sv(){let n=sn(ze(16,4,o=>{for(let c=0;c<16;c++)for(let l=0;l<4;l++)o.fillStyle=(c+l)%2?"#111":"#f4f4f4",o.fillRect(c,l,1,1)}));n.magFilter=tn;let t=new Ct(new _n(Nt,2.4),pt(16777215,.6,0,{map:n}));t.rotation.x=-Math.PI/2,t.receiveShadow=!0;let e=new bt;e.add(t),e.position.copy(Ve(0,0,.06)),e.rotation.y=ri(0),Re.add(e);let i=new bt,s=pt(2830134,.35,.8);for(let o of[-1,1])Tt(new de(.9,11,.9),s,!0,!0,i).position.set(o*(Nt/2+3.2),5.5,0),Tt(new de(1.8,.6,1.8),pt(5593958,.6,.4),!0,!0,i).position.set(o*(Nt/2+3.2),.3,0);let r=sn(ze(512,64,(o,c,l)=>{let h=o.createLinearGradient(0,0,0,l);h.addColorStop(0,"#1a1f2b"),h.addColorStop(1,"#0c0f16"),o.fillStyle=h,o.fillRect(0,0,c,l),o.fillStyle="#ff7a1a",o.fillRect(0,0,c,4),o.fillRect(0,l-4,c,4),o.font="italic 900 38px Arial",o.textAlign="center",o.textBaseline="middle",o.fillStyle="#fff",o.fillText(`LARGADA \xB7 ${At.name}`,c/2,l/2+2)})),a=pt(16777215,.4,0,{map:r,emissive:16777215,emissiveMap:r,emissiveIntensity:.35});Tt(new de(Nt+7.3,2.2,.6),[s,s,s,s,a,a],!0,!0,i).position.set(0,10,0);for(let o=0;o<3;o++){let c=new re({color:2230280,emissive:0,roughness:.3});Tt(new le(.42,16,12),c,!1,!1,i).position.set((o-1)*1.2,8.2,-.3),Tt(new de(1.05,1.05,.5),s,!1,!1,i).position.set((o-1)*1.2,8.2,.05),Lh.push(c)}i.position.copy(Ve(0,0)),i.rotation.y=ri(0),Re.add(i)}function hh(n,t){Lh.forEach((e,i)=>{let s=t||i<n,r=s?t?1113952:16719904:2230280;e.color.setHex(r),e.emissive.setHex(s?r:0),e.emissiveIntensity=s?2.2:0})}function Ud(){return Ch(Ye[0].x+Ts[0].x*30,Ye[0].z+Ts[0].z*30)?-1:1}function bv(){let n=Ud(),t=new de(1,1,1),e={concrete:[],seat:[],roof:[],pillar:[]},i=[],s=(l,h,u,f,d,p,x,g)=>{let m=Ve(h,u,f);l.push([m.x,m.y,m.z,g,d,p,x])};for(let l=-52;l<=52;l+=4){let h=ri(l);for(let u=0;u<7;u++){let f=n*(Nt/2+7+u*1.6);s(e.concrete,l,f,.4*(u+1),1.7,.8*(u+1),4.02,h),s(e.seat,l,f+n*.3,.8*(u+1)+.12,.5,.25,3.9,h);for(let d of[-1.3,0,1.3]){if(ue()<.15)continue;let p=br(l+d);i.push({x:p.p.x+p.r.x*(f+n*.2),z:p.p.z+p.r.z*(f+n*.2),y:.8*(u+1)+.2,ph:ue()*6,yaw:h})}}s(e.roof,l,n*(Nt/2+13),11.5,14,.3,4.05,h),s(e.concrete,l,n*(Nt/2+19),5.75,.4,11.5,4.05,h),l%16===0&&s(e.pillar,l,n*(Nt/2+7.2),5.75,.4,11.5,.4,h)}let r={concrete:pt(At.stand[0],.9),seat:pt(At.stand[1],.5),roof:pt(15263976,.4,.5),pillar:pt(3817287,.4,.7)};for(let l in e){let h=Tn(t,r[l],e[l].length);e[l].forEach((u,f)=>wn(h,f,u[0],u[1],u[2],0,u[3],0,u[4],u[5],u[6]))}let a=[15022389,2001125,16635957,4431943,16777215,16740419,9315498,44225,2171169],o=[15843965,14724201,9262372,13010498,16767916,7029286];ha=Tn(new kt(.26,.32,.95,6),pt(16777215,.8),i.length,!1),tc=Tn(new le(.21,7,5),pt(16777215,.7),i.length,!1);let c=new Ft;i.forEach((l,h)=>{ha.setColorAt(h,c.setHex(a[ue()*a.length|0])),tc.setColorAt(h,c.setHex(o[ue()*o.length|0])),Ih.push(l)}),ga.push([Ye[0].x,Ye[0].z,80])}var xa=.3;function Tv(n){ha&&(Ih.forEach((t,e)=>{let i=Math.max(0,Math.sin(n*8+t.ph))*.4*xa;wn(ha,e,t.x,t.y+.47+i,t.z,0,t.yaw,0,1),wn(tc,e,t.x,t.y+1.15+i,t.z,0,0,0,1)}),ha.instanceMatrix.needsUpdate=tc.instanceMatrix.needsUpdate=!0)}function wv(){let n=Ud();[["RA\xC7\xC3O CROCK","energia para campe\xF5es","#ffcc00","#c62828"],["OSSO DE OURO","o petisco oficial","#101a3a","#ffc53d"],["PET SHOP 2000","tudo para seu c\xE3o","#00a6c8","#ffffff"],["LATIDO FM","97.5 \xB7 a r\xE1dio do auau","#e91e63","#ffffff"],["TURBO DOG","nitro para patas","#111111","#76ff03"],["COLEIRA MAX","aperta sem machucar","#ff8f00","#1a1a1a"],["VET 24H","plant\xE3o veterin\xE1rio","#ffffff","#1565c0"],["PETISCO BOM","sabor bacon","#2e7d32","#ffffff"]].forEach((e,i)=>{let s=Le*(.1+i*.105),r=sn(ze(256,128,(p,x,g)=>{p.fillStyle=e[2],p.fillRect(0,0,x,g);let m=p.createLinearGradient(0,0,0,g);m.addColorStop(0,"rgba(255,255,255,.18)"),m.addColorStop(1,"rgba(0,0,0,.18)"),p.fillStyle=m,p.fillRect(0,0,x,g),p.fillStyle=e[3],p.fillRect(0,g-10,x,10),p.font="italic 900 38px Arial",p.textAlign="center",p.fillText(e[0],x/2,62),p.font="600 18px Arial",p.fillText(e[1].toUpperCase(),x/2,94)})),a=new bt,o=pt(2764341,.5,.6);Tt(new de(12,6,.35),[o,o,o,o,pt(16777215,.5,0,{map:r}),o],!0,!0,a).position.y=6.5;for(let p of[-4,4])Tt(new de(.35,4,.35),o,!0,!0,a).position.set(p,2,0);let c=br(s),l=n*(Nt/2+10),h=c.p.x+c.r.x*l,u=c.p.z+c.r.z*l,f=c.r.x,d=c.r.z;a.position.set(h,_s(h,u),u),a.rotation.y=Math.atan2(-n*f,-n*d),Re.add(a)})}function Av(n){let t=[];for(let i=-260;i<=260;i+=12)for(let s=-260;s<=260;s+=12){if(!Ch(i,s))continue;let r=Ph(i,s);r>Nt/2+22&&t.push([i,s,r])}t.sort((i,s)=>s[2]-i[2]);let e=[];for(let i of t)if(e.every(s=>Math.hypot(s[0]-i[0],s[1]-i[1])>55)&&e.push(i),e.length>=n)break;return e}function Rv(){let n=Av(4),t=(e,i,s)=>{if(!n[i])return;let[r,a]=n[i];e.position.set(r,0,a),e.rotation.y=ue()*6,Re.add(e),ga.push([r,a,s])};if(At.id==="parque"){{let e=new bt,i=pt(13209170,.8),s=pt(10558749,.6);Tt(new de(14,10,14),i,!0,!0,e).position.y=5;let r=new Xi;r.moveTo(-8.5,0),r.lineTo(0,6.5),r.lineTo(8.5,0),r.lineTo(-8.5,0),Tt(new fs(r,{depth:16,bevelEnabled:!1}),s,!0,!0,e).position.set(0,10,-8);let a=Tt(new kt(3,3,.4,20,1,!1,0,Math.PI),pt(1708042,1),!1,!0,e);a.rotation.set(Math.PI/2,Math.PI/2,0),a.position.set(0,4,7.05),Tt(new de(6,4,.4),pt(1708042,1),!1,!0,e).position.set(0,2,7.05),Tt(new kt(2.2,1.6,1.2,20),pt(13840175,.35,.3),!0,!0,e).position.set(6,.6,12),t(e,0,22)}{let e=new bt,i=pt(14163750,.35,.4),s=pt(15909166,.3,.8);Tt(new kt(3.6,4,1.2,24),i,!0,!0,e).position.y=.6,Tt(new kt(2.6,2.8,9,24),i,!0,!0,e).position.y=5.5,Tt(new le(2.7,24,12,0,Math.PI*2,0,Math.PI/2),i,!0,!0,e).position.y=10,Tt(new kt(.7,.9,1.4,12),s,!0,!0,e).position.y=13;for(let r of[-1,1]){let a=Tt(new kt(1,1,2,14),s,!0,!0,e);a.rotation.z=Math.PI/2,a.position.set(r*3.2,7,0)}t(e,1,12)}{let e=new bt,i=Tt(new hs(26,40),pt(12167034,1),!1,!0,e);i.rotation.x=-Math.PI/2,i.position.y=.04;let s=Tt(new hs(23,40),pt(2781071,.08,.1),!1,!0,e);s.rotation.x=-Math.PI/2,s.position.y=.08,t(e,2,30)}{let e=new bt,i=pt(15985362,.45),s=Tt(new kt(1.4,1.4,12,20),i,!0,!0,e);s.rotation.z=Math.PI/2,s.position.y=2.4;for(let r of[-6,6])for(let a of[-1.4,1.4])Tt(new le(2.2,20,14),i,!0,!0,e).position.set(r,2.4,a);t(e,3,12)}}else if(At.id==="praia"){{let e=new bt,i=sn(ze(8,64,s=>{for(let r=0;r<8;r++)s.fillStyle=r%2?"#f4f4f4":"#d32f2f",s.fillRect(0,r*8,8,8)}));Tt(new kt(3,4.2,26,24),pt(16777215,.5,0,{map:i}),!0,!0,e).position.y=13,Tt(new kt(3.6,3.6,.6,24),pt(2236962,.5,.6),!0,!0,e).position.y=26.3,Tt(new kt(2.4,2.4,3,16),pt(16774064,.1,0,{emissive:16769674,emissiveIntensity:1.5}),!1,!1,e).position.y=28,Tt(new Je(3,3,16),pt(12000284,.5,.3),!0,!0,e).position.y=31,t(e,0,14)}{let e=new bt,i=pt(14268286,1);Tt(new de(14,5,14),i,!0,!0,e).position.y=2.5;for(let[s,r]of[[-7,-7],[7,-7],[-7,7],[7,7]])Tt(new kt(2.2,2.6,9,12),i,!0,!0,e).position.set(s,4.5,r),Tt(new Je(2.6,3.5,12),i,!0,!0,e).position.set(s,10.7,r);Tt(new kt(3,3.4,11,14),i,!0,!0,e).position.set(0,5.5,0),t(e,1,16)}{let e=new bt,i=[15022389,2001125,16635957,4431943,16740419];for(let s=0;s<7;s++){let r=$t(-14,14),a=$t(-14,14);Tt(new kt(.12,.12,5,8),pt(15658734,.4,.5),!0,!0,e).position.set(r,2.5,a),Tt(new Je(3.2,1.4,12,1,!0),pt(i[s%5],.6,0,{side:He}),!0,!0,e).position.set(r,5.2,a);let o=Tt(new de(1.6,.05,3),pt(i[(s+2)%5],.9),!1,!0,e);o.position.set(r+2,.05,a),o.rotation.y=ue()}t(e,2,20)}}else{{let e=new bt,i=pt(7162413,.9),s=pt(16054527,.6);Tt(new de(14,8,11),i,!0,!0,e).position.y=4;let r=new Xi;r.moveTo(-8.5,0),r.lineTo(0,6),r.lineTo(8.5,0),r.lineTo(-8.5,0),Tt(new fs(r,{depth:13,bevelEnabled:!1}),s,!0,!0,e).position.set(0,8,-6.5),Tt(new de(1.6,6,1.6),pt(7829367,.9),!0,!0,e).position.set(4,12,0);let a=pt(16765562,.3,0,{emissive:16756800,emissiveIntensity:1.2});for(let o of[-4,4])Tt(new de(2,2,.2),a,!1,!1,e).position.set(o,4.5,5.55);t(e,0,16)}{let e=new bt,i=pt(16251647,.6);for(let s=0;s<3;s++){let r=(s-1)*7,a=1+s*.15;Tt(new le(2*a,20,14),i,!0,!0,e).position.set(r,1.8*a,0),Tt(new le(1.4*a,20,14),i,!0,!0,e).position.set(r,4.4*a,0),Tt(new le(.95*a,20,14),i,!0,!0,e).position.set(r,6.4*a,0);let o=Tt(new Je(.18*a,1*a,10),pt(16742938,.6),!0,!0,e);o.rotation.x=Math.PI/2,o.position.set(r,6.4*a,1.3*a),Tt(new kt(.7*a,.7*a,1.2*a,16),pt(1710618,.5),!0,!0,e).position.set(r,7.6*a,0)}t(e,1,14)}{let e=new bt,i=Tt(new hs(24,40),pt(12575999,.05,.1),!1,!0,e);i.rotation.x=-Math.PI/2,i.position.y=.06,t(e,2,28)}}}function Cv(){let n=z.qual===0,t=(o,c,l)=>{let h=[],u=0;for(;h.length<o&&u++<o*25;){let f=$t(-l,l),d=$t(-l,l),p=Ph(f,d);p<c||ga.some(x=>Math.hypot(f-x[0],d-x[1])<x[2])||At.sea!==void 0&&d<At.sea+4||h.push([f,d,p])}return h},e=n?130:z.qual===1?220:320,i=new Ft;if(At.trees==="broad"){let o=t(e,Nt/2+9,520),c=Tn(new kt(.3,.5,1,7).translate(0,.5,0),pt(5913894,.95),o.length),l=new cr(1,1);{let u=l.attributes.position;for(let f=0;f<u.count;f++){te.fromBufferAttribute(u,f);let d=.82+.3*Ci(te.x*2.3+5,te.y*2.3+te.z*1.7,0,9);u.setXYZ(f,te.x*d,te.y*d,te.z*d)}l.computeVertexNormals()}let h=Tn(l,pt(16777215,.9),o.length*3);o.forEach(([u,f],d)=>{let p=$t(.8,1.4),x=_s(u,f),g=5*p;wn(c,d,u,x,f,0,0,0,p,g,p);for(let m=0;m<3;m++){let S=2.6*p*$t(.8,1.1);wn(h,d*3+m,u+$t(-1.2,1.2)*p,x+g+S*.5+m*1.1*p,f+$t(-1.2,1.2)*p,ue()*3,ue()*3,0,S,S*$t(.8,1),S),h.setColorAt(d*3+m,i.setHSL($t(.22,.32),$t(.45,.65),$t(.18,.3)))}})}else if(At.trees==="pine"){let o=t(e*1.2|0,Nt/2+9,520),c=Tn(new kt(.25,.4,1,6).translate(0,.5,0),pt(4862498,.95),o.length),l=new Je(1,1,10,3).translate(0,.5,0);{let u=l.attributes.position,f=new Float32Array(u.count*3);for(let d=0;d<u.count;d++){let p=u.getY(d)>.45;f[d*3]=p?1:.3,f[d*3+1]=p?1:.42,f[d*3+2]=p?1.05:.3}l.setAttribute("color",new Pe(f,3))}let h=Tn(l,pt(16777215,.85,0,{vertexColors:!0}),o.length*3);o.forEach(([u,f],d)=>{let p=$t(.8,1.6),x=_s(u,f);wn(c,d,u,x,f,0,0,0,p,3*p,p);for(let g=0;g<3;g++){let m=(3.4-g*.9)*p;wn(h,d*3+g,u,x+(2.2+g*2.6)*p,f,0,ue()*3,0,m,4.2*p,m),h.setColorAt(d*3+g,i.setHSL(.36,.25,$t(.62,.8)))}})}else{let o=t(e*.7|0,Nt/2+8,480),c=Tn(new kt(.28,.34,1.6,8).translate(0,.8,0),pt(9071176,.9),o.length*7),l=new _n(1,1,1,8);{let f=l.attributes.position;for(let d=0;d<f.count;d++){let p=f.getX(d),x=f.getY(d)+.5;f.setXYZ(d,p*(1-x*.8)*1.2,-x*x*1.6,x*4.8)}l.computeVertexNormals()}let h=Tn(l,pt(4164142,.8,0,{side:He}),o.length*8),u=Tn(new le(.28,8,6),pt(5913114,.7),o.length*3);o.forEach(([f,d],p)=>{let x=$t(.05,.22),g=ue()*6.28,m=f,S=_s(f,d),y=d;for(let b=0;b<7;b++){let C=x*(b+1)*.35;wn(c,p*7+b,m,S,y,Math.cos(g)*C,0,-Math.sin(g)*C,1-b*.05),m+=Math.sin(g)*Math.sin(C)*1.5,y+=Math.cos(g)*Math.sin(C)*1.5,S+=Math.cos(C)*1.5*(1-b*.05)}for(let b=0;b<8;b++)wn(h,p*8+b,m,S,y,0,b/8*6.28+ue()*.3,0,1.2,1,1.2),h.setColorAt(p*8+b,i.setHSL($t(.24,.3),.55,$t(.25,.35)));for(let b=0;b<3;b++)wn(u,p*3+b,m+Math.cos(b*2)*.4,S-.3,y+Math.sin(b*2)*.4,0,0,0,1)})}let s=t(n?40:90,Nt/2+6,420),r=new cr(1,1);{let o=r.attributes.position;for(let c=0;c<o.count;c++){te.fromBufferAttribute(o,c);let l=.7+.5*Ci(te.x*2+3,te.y*2+te.z*2,0,4);o.setXYZ(c,te.x*l,te.y*l*.7,te.z*l)}r.computeVertexNormals()}let a=Tn(r,pt(At.id==="neve"?8160660:9274745,.95,0,{flatShading:!0}),s.length);if(s.forEach(([o,c],l)=>{let h=$t(.6,2.4);wn(a,l,o,_s(o,c)+h*.2,c,ue(),ue()*6,0,h,h,h)}),At.id!=="neve"){let o=n?700:At.id==="praia"?900:z.qual===1?1800:3200,c=new Ue,l=[];for(let f=0;f<5;f++){let d=f/5*Math.PI,p=Math.cos(d)*.12,x=Math.sin(d)*.12,g=$t(-.25,.25);l.push(-p,0,-x,p,0,x,g*1.4,.7+ue()*.4,g)}c.setAttribute("position",new ce(l,3)),c.computeVertexNormals();let h=Tn(c,pt(16777215,.9,0,{side:He}),o,!1),u=0;for(let f=0;f<o*3&&u<o;f++){let d=ue()*Le,p=ue()<.5?-1:1,x=p*(Nt/2+3+ue()*ue()*40),g=Ve(d,x);ga.some(m=>Math.hypot(g.x-m[0],g.z-m[1])<m[2])||At.sea!==void 0&&g.z<At.sea||(wn(h,u,g.x,_s(g.x,g.z),g.z,0,ue()*6,0,$t(.7,1.6)),h.setColorAt(u++,At.id==="praia"?i.setHSL(.2,.35,$t(.35,.5)):i.setHSL($t(.2,.3),$t(.4,.6),$t(.2,.34))))}h.count=u}}function Pv(){for(let n=0;n<26;n++){let t=n/26*Math.PI*2+$t(-.1,.1),e=$t(700,880),i=Math.cos(t)*e,s=Math.sin(t)*e;if(At.sea!==void 0&&s<-250)continue;let r=$t(110,260)*(At.id==="neve"?1.35:1),a=$t(140,240),o=new Je(a,r,18,6,!0),c=o.attributes.position,l=new Float32Array(c.count*3),h=new Ft(At.mtn[n%2]),u=new Ft(15922682),f=new Ft;for(let d=0;d<c.count;d++){te.fromBufferAttribute(c,d);let p=(te.y+r/2)/r,x=Ti(te.x*.02+n*7,te.z*.02+te.y*.02,4),g=1+(x-.5)*.5*(1-p*.5);c.setXYZ(d,te.x*g,te.y+(x-.5)*r*.12,te.z*g),f.copy(h).lerp(u,It(.62-x*.2,.75-x*.2,p)*(At.id==="praia"?0:1)),l[d*3]=f.r,l[d*3+1]=f.g,l[d*3+2]=f.b}o.setAttribute("color",new Pe(l,3)),o.computeVertexNormals(),Tt(o,pt(16777215,.95,0,{vertexColors:!0,flatShading:!0}),!1,!1).position.set(i,r/2-4,s)}}function Lv(){let n=new Kn(ze(256,128,e=>{for(let i=0;i<26;i++){let s=40+ue()*176,r=50+ue()*40,a=18+ue()*30,o=e.createRadialGradient(s,r,0,s,r,a);o.addColorStop(0,"rgba(255,255,255,.9)"),o.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=o,e.fillRect(0,0,256,128)}}));n.colorSpace=Ae;let t=At.id==="praia"?16763040:16777215;for(let e=0;e<18;e++){let i=new or(new ls({map:n,color:t,fog:!1,depthWrite:!1,transparent:!0,opacity:$t(.6,.95)})),s=ue()*6.28,r=$t(450,900);i.position.set(Math.cos(s)*r,$t(160,300),Math.sin(s)*r),i.scale.set($t(220,380),$t(90,140),1),Re.add(i),Dh.push(i)}}function Iv(){let n=z.qual===0?700:1600,t=new Float32Array(n*3);for(let i=0;i<n;i++)t[i*3]=$t(-60,60),t[i*3+1]=$t(0,40),t[i*3+2]=$t(-60,60);let e=new Ue;e.setAttribute("position",new Pe(t,3)),Ai=new jr(e,new Kr({size:.22,map:wh,transparent:!0,depthWrite:!1,color:16777215})),Ai.frustumCulled=!1,nn.add(Ai)}function Dv(n){let t=new bt,e=new Ct(new kt(.14,.14,.9,12),n);e.rotation.z=Math.PI/2,t.add(e);for(let i of[-.45,.45])for(let s of[-.13,.13]){let r=new Ct(new le(.2,12,10),n);r.position.set(i,s,0),t.add(r)}return t.traverse(i=>{i.isMesh&&(i.castShadow=!0)}),t}function Uv(){$i=[],ch=[],ec=[],nc=[],_r=[],ma=[];let n=[["pad",.06,-3],["hurdle",.13],["coins",.19,-4],["puddle",.26,4],["nitro",.32],["ramp",.4],["coins",.46,3],["hurdle",.52],["puddle",.59,-3.5],["pad",.65,3],["nitro",.71],["coins",.77,0],["hurdle",.83],["puddle",.89,2.5],["nitro",.95],["ammo",.23],["ammo",.62],["ammo",.925]];ua=sn(ze(64,64,h=>{h.fillStyle="#062a3a",h.fillRect(0,0,64,64),h.strokeStyle="#35d0ff",h.lineWidth=9;for(let u of[10,42])h.beginPath(),h.moveTo(8,u+18),h.lineTo(32,u),h.lineTo(56,u+18),h.stroke()}),1,2);let t=sn(ze(64,4,h=>{for(let u=0;u<8;u++)h.fillStyle=u%2?"#ffffff":"#e53935",h.fillRect(u*8,0,8,4)}),3,1),e={mud:pt(3876372,.15,0),water:pt(3833768,.05,.1,{transparent:!0,opacity:.85}),ice:pt(13496063,.03,.2)}[At.puddle],i=pt(2060287,.25,.7),s=pt(3526911,.2,0,{emissive:3526911,emissiveIntensity:1.2}),r=new Bn({color:3526911,transparent:!0,opacity:.45,blending:Gi,depthWrite:!1,side:He}),a=pt(16762173,.28,.55,{emissive:4861952});_a=[];let o=sn(ze(64,64,h=>{h.fillStyle="#3f4a2c",h.fillRect(0,0,64,64),h.strokeStyle="#2a3120",h.lineWidth=4,h.strokeRect(2,2,60,60),h.beginPath(),h.moveTo(2,2),h.lineTo(62,62),h.moveTo(62,2),h.lineTo(2,62),h.stroke(),h.fillStyle="#ffcc00",h.fillRect(16,26,32,12),h.fillStyle="#111",h.font="bold 10px Arial",h.textAlign="center",h.fillText("M\xCDSSIL",32,35)})),c=pt(16777215,.7,.1,{map:o}),l=pt(16777215,.3,0,{map:ua,emissive:16777215,emissiveMap:ua,emissiveIntensity:1.4});for(let[h,u,f=0]of n){let d=Le*u;if(h==="hurdle"){let p=new bt,x=new bt;Tt(new de(Nt+1,.2,.2),pt(16777215,.4,0,{map:t}),!0,!0,x),x.position.y=.95,p.add(x);for(let g of[-1,1])Tt(new de(.22,1.4,.22),pt(15790320,.4,.3),!0,!0,p).position.set(g*(Nt/2+.6),.7,0),Tt(new de(.3,.12,1.4),pt(3355443,.5,.5),!0,!0,p).position.set(g*(Nt/2+.6),.06,0);p.position.copy(Ve(d,0)),p.rotation.y=ri(d),Re.add(p),$i.push({s:d,bar:x,fall:0})}else if(h==="ramp"){let p=new Xi;p.moveTo(-3,0),p.lineTo(3,0),p.lineTo(3,1.1),p.lineTo(-3,0);let x=new fs(p,{depth:Nt,bevelEnabled:!1});x.translate(0,0,-Nt/2),x.rotateY(-Math.PI/2);let g=sn(ze(64,64,S=>{S.fillStyle="#ffb300",S.fillRect(0,0,64,64),S.fillStyle="#1a1a1a";for(let y=-64;y<128;y+=22)S.beginPath(),S.moveTo(y,0),S.lineTo(y+11,0),S.lineTo(y+75,64),S.lineTo(y+64,64),S.fill()}),.25,.25),m=Tt(x,pt(16777215,.6,.2,{map:g}));m.position.copy(Ve(d,0,.02)),m.rotation.y=ri(d),ch.push({s:d+3})}else if(h==="pad"){let p=Tt(new _n(4.2,7),l,!1,!0);p.rotation.x=-Math.PI/2;let x=new bt;x.add(p),x.position.copy(Ve(d,f,.07)),x.rotation.y=ri(d),Re.add(x),ec.push({s:d,d:f})}else if(h==="puddle"){let x=Tt(new hs(3.3,32),e,!1,!0);x.rotation.x=-Math.PI/2;let g=new bt;g.add(x),g.scale.set(.8,1,1.4),g.position.copy(Ve(d,f,.06)),g.rotation.y=ri(d),Re.add(g),nc.push({s:d,d:f,r:3.3,type:At.puddle})}else if(h==="nitro")for(let p of[-5,0,5]){let x=new bt;Tt(new kt(.42,.42,1.2,20),i,!0,!0,x),Tt(new kt(.44,.44,.3,20),s,!1,!1,x),Tt(new kt(.15,.2,.25,12),jo,!1,!1,x).position.y=.72;let g=Tt(new ra(.8,1.1,32),r,!1,!1,x);g.rotation.x=-Math.PI/2,g.position.y=-1.15,x.position.copy(Ve(d,p,1.3)),Re.add(x),_r.push({s:d,d:p,g:x,cd:0})}else if(h==="ammo")for(let p of[-5,0,5]){let x=new bt;Tt(new de(1.1,.8,1.1),c,!0,!0,x);let g=Vd();g.visible=!0,g.scale.setScalar(.55),g.position.y=.7,g.rotation.x=-Math.PI/2,x.add(g);let m=Tt(new ra(.9,1.2,32),new Bn({color:16734778,transparent:!0,opacity:.45,blending:Gi,depthWrite:!1,side:He}),!1,!1,x);m.rotation.x=-Math.PI/2,m.position.y=-1,x.position.copy(Ve(d,p,1.1)),Re.add(x),_a.push({s:d,d:p,g:x,cd:0})}else if(h==="coins")for(let p=0;p<6;p++){let x=Dv(a);x.scale.setScalar(1.1);let g=d+p*4;x.position.copy(Ve(g,f,1.1)),Re.add(x),ma.push({s:g,d:f,g:x,taken:!1})}}}var vr=[];function Nv(){vr=[],[[.36,1,0],[.555,-1,3.2]].forEach(([n,t,e])=>{let i=Le*n,s=new bt,r=new bt,a=new bt;s.position.copy(Ve(i,0)),s.rotation.y=ri(i),s.add(r),r.add(a),Re.add(s);let o=1.3,c="";if(At.id==="parque"){o=1.2,c="ATROPELADO PELO FENO!";let f=sn(ze(64,64,p=>{p.fillStyle="#d9b44a",p.fillRect(0,0,64,64);for(let x=0;x<220;x++){p.strokeStyle=Math.random()<.5?"#b8912f":"#f0d27a",p.beginPath();let g=Math.random()*64,m=Math.random()*64;p.moveTo(g,m),p.lineTo(g+Math.random()*10-5,m+Math.random()*3),p.stroke()}})),d=Tt(new kt(o,o,2.2,24),pt(16777215,.95,0,{map:f}),!0,!0,a);d.rotation.x=Math.PI/2;for(let p of[-.5,.5]){let x=Tt(new lr(o+.01,.05,6,32),pt(8014622,.8),!1,!1,a);x.position.z=p}}else if(At.id==="praia"){o=1.35,c="BOLADA DE PRAIA!";let f=sn(ze(128,64,d=>{["#e53935","#ffffff","#1e88e5","#ffffff","#fdd835","#ffffff"].forEach((x,g)=>{d.fillStyle=x,d.fillRect(g*128/6,0,128/6+1,64)})}));Tt(new le(o,28,18),pt(16777215,.35,0,{map:f}),!0,!0,a)}else{o=1.5,c="ATROPELADO PELA BOLA DE NEVE!";let f=new cr(o,3),d=f.attributes.position;for(let p=0;p<d.count;p++){te.fromBufferAttribute(d,p);let x=.92+.12*Ci(te.x*2+4,te.y*2+te.z*2,0,7);d.setXYZ(p,te.x*x,te.y*x,te.z*x)}f.computeVertexNormals(),Tt(f,pt(16054527,.6),!0,!0,a)}let l=new bt,h=sn(ze(64,64,f=>{f.fillStyle="#ffcc00",f.beginPath(),f.moveTo(32,3),f.lineTo(61,32),f.lineTo(32,61),f.lineTo(3,32),f.fill(),f.fillStyle="#111",f.beginPath(),f.arc(32,36,11,0,7),f.fill(),f.fillRect(12,46,40,4)}));Tt(new de(1.6,1.6,.08),[pt(3355443),pt(3355443),pt(3355443),pt(3355443),pt(16777215,.5,0,{map:h}),pt(3355443)],!0,!0,l).position.y=2.6,Tt(new kt(.06,.06,2,6),pt(7829367,.5,.6),!0,!0,l).position.y=1;let u=Ve(i-25,-(Nt/2+3.4));l.position.set(u.x,0,u.z),l.rotation.y=ri(i)+Math.PI,Re.add(l),vr.push({s:i,dir:t,off:e,r:o,roller:r,active:!1,d:0,hitMsg:c,period:7.5})})}function Nh(n){for(let t of vr){let e=((n+t.off)%t.period+t.period)%t.period,i=3.6,s=Nt/2+6,r=Math.min(1,e/i);t.d=t.dir*ke(-s,s,r),t.active=e<i&&Math.abs(t.d)<Nt/2+1,t.roller.visible=e<i+.4,t.roller.position.set(-t.d,t.r,0),t.roller.rotation.z=t.d/t.r}}var Ov={parque:{name:"POMBO",plural:"POMBOS",body:9213349,wing:10397622,tip:3817288,head:5205859,beak:3355443,pitch:1},praia:{name:"GAIVOTA",plural:"GAIVOTAS",body:16185074,wing:12173770,tip:1710618,head:16777215,beak:15907118,pitch:1.4},neve:{name:"CORVO",plural:"CORVOS",body:1382172,wing:1842982,tip:789776,head:1382172,beak:2105376,pitch:.7}},Si=()=>Ov[At.id],Ss=[],fa=8;function Fv(n){let t=new bt,e=a=>pt(a,.6,.05),i=(a,o,c,l,h,u=t)=>{let f=new Ct(a,o);return f.position.set(c,l,h),f.castShadow=!0,u.add(f),f};i(wi(.2,.19,.38),e(n.body),0,0,0),i(new le(.14,14,10),e(n.head),0,.14,.33);let s=i(new Je(.045,.14,8),e(n.beak),0,.12,.5);s.rotation.x=Math.PI/2;for(let a of[-1,1])i(new le(.03,8,6),pt(657930,.1),a*.09,.18,.42);i(wi(.14,.025,.24),e(n.tip),0,.02,-.44);let r=[];for(let a of[-1,1]){let o=new bt;o.position.set(a*.14,.08,.04),t.add(o),i(wi(.42,.02,.2),e(n.wing),a*.4,0,0,o),i(wi(.18,.018,.12),e(n.tip),a*.78,0,-.05,o),r.push({piv:o,sx:a})}for(let a of[-1,1]){let o=i(new kt(.012,.012,.16,5),pt(13662784,.6),a*.06,-.2,-.05);o.rotation.x=.8}return t.scale.setScalar(1.7),{g:t,wings:r}}function zv(){Ss=[],fa=7;for(let n=0;n<4;n++){let t=Fv(Si());t.g.visible=!1,Re.add(t.g),Ss.push({...t,state:"off",pos:new P,vel:new P,t:0,target:null,phase:Math.random()*6})}}function Yo(n,t){n.state="flee",n.t=0;let e=n.pos.x-t.x,i=n.pos.z-t.z,s=Math.hypot(e,i)||1;n.vel.set(e/s*22,14,i/s*22),n.target&&(n.target.birdT=0),Dt.squawk(Si().pitch,ot?he(1-Math.hypot(n.pos.x-ot.x,n.pos.z-ot.z)/60,0,1):1);for(let r=0;r<8;r++)ci.spawn(n.pos.x,n.pos.y,n.pos.z,(Math.random()-.5)*6,Math.random()*3,(Math.random()-.5)*6,1.2,.25,.15,[.95,.95,.95],.9,3,1.5)}var ms=new P;function Nd(n,t){if(t&&Wn>5){fa-=n;let e=Ss.filter(i=>i.state==="approach"||i.state==="harass").length;if(fa<=0&&e<1+z.diff){fa=6+Math.random()*5-z.diff;let i=Ss.find(r=>r.state==="off"),s=me.filter(r=>!r.finished&&r.birdT<=0);if(i&&s.length){let r=s.includes(ot)&&Math.random()<.5?ot:s[Math.random()*s.length|0],a=br(r.dist+55+Math.random()*20),o=(Math.random()-.5)*30;i.pos.set(a.p.x+a.r.x*o,16+Math.random()*6,a.p.z+a.r.z*o),i.vel.set(0,0,0),i.state="approach",i.t=0,i.target=r,i.g.visible=!0,r.isPlayer&&be(`CUIDADO: ${Si().name}!`,"o")}}}for(let e of Ss){if(e.state==="off")continue;e.t+=n,e.phase+=n*(e.state==="harass"?22:15);let i=e.target;if(e.state==="approach"||e.state==="harass")if(!i||i.finished||!t)Yo(e,e.pos);else{i.D.head.getWorldPosition(ms);let r=Math.sin(i.h),a=Math.cos(i.h);if(e.state==="approach"){te.set(ms.x+r*1.2-e.pos.x,ms.y+.8-e.pos.y,ms.z+a*1.2-e.pos.z);let o=te.length(),c=Math.hypot(i.vx,i.vz)+16;e.vel.lerp(te.multiplyScalar(c/Math.max(o,.01)),1-Math.exp(-3*n)),e.pos.addScaledVector(e.vel,n),o<2.4&&(e.state="harass",e.t=0,i.isPlayer?(be(`${Si().name} NA CARA! LATE!`,"r"),Dt.squawk(Si().pitch,1),Ln([20,30,20,30,20])):Yi(`${Si().name} ATACANDO ${i.b.name}!`)),e.t>12&&Yo(e,e.pos)}else{let o=e.t*5;te.set(ms.x+r*1.3+Math.cos(o)*.9,ms.y+.55+Math.sin(e.t*9)*.25,ms.z+a*1.3+Math.sin(o)*.9),e.vel.copy(te).sub(e.pos).divideScalar(Math.max(n,.001)).clampLength(0,80),e.pos.lerp(te,1-Math.exp(-10*n)),i.birdT=.25,Math.random()<n*1.5&&Dt.squawk(Si().pitch,i.isPlayer?.6:.2),e.t>6&&Yo(e,e.pos)}}else e.state==="flee"&&(e.vel.y+=n*4,e.pos.addScaledVector(e.vel,n),e.t>4&&(e.state="off",e.g.visible=!1));e.g.position.copy(e.pos),e.vel.lengthSq()>1&&e.g.rotation.set(-he(e.vel.y*.03,-.5,.5),Math.atan2(e.vel.x,e.vel.z),0);let s=Math.sin(e.phase)*(e.state==="flee"?.9:.7);for(let r of e.wings)r.piv.rotation.z=r.sx*s}}function Od(){for(let n of Ss)n.state="off",n.g.visible=!1,n.target=null;fa=7}function Bv(){let n=1/0,t=-1/0,e=1/0,i=-1/0;for(let o of Ye)n=Math.min(n,o.x),t=Math.max(t,o.x),e=Math.min(e,o.z),i=Math.max(i,o.z);let s=216/Math.max(t-n,i-e),r=128-(n+t)/2*s,a=128-(e+i)/2*s;lh={f:(o,c)=>[o*s+r,c*s+a],canvas:ze(256,256,o=>{o.lineJoin="round",o.beginPath();for(let c=0;c<=Xe;c+=8){let l=Ye[c%Xe],h=l.x*s+r,u=l.z*s+a;c?o.lineTo(h,u):o.moveTo(h,u)}o.closePath(),o.lineWidth=16,o.strokeStyle="rgba(0,0,0,.55)",o.stroke(),o.lineWidth=9,o.strokeStyle="rgba(255,255,255,.9)",o.stroke(),o.fillStyle="#ff7a1a",o.fillRect(Ye[0].x*s+r-6,Ye[0].z*s+a-6,12,12)})}}var Fd=[{name:"REDLINE AGOG",src:"musica/redline-agog.mp3"},{name:"APEX PURSUIT",src:"musica/apex-pursuit.mp3"}],zd=["TODAS","REDLINE AGOG","APEX PURSUIT","8-BIT","DESLIGADA"],Pn=new Audio;Pn.preload="none";Pn.volume=.6;var uh=Math.random()<.5?0:1,fh=!1;Pn.addEventListener("ended",()=>{z.musicMode===0&&(uh=(uh+1)%Fd.length,dc(!0))});Pn.addEventListener("error",()=>{Pn.getAttribute("src")&&(fh=!0,dc())});function dc(n){let t=z.musicMode,e=t<=2&&!fh;if(Dt.ctx&&Dt.setMusic(t===3||t<=2&&fh),e){let i=Fd[t===0?uh:t-1];Pn.getAttribute("src")!==i.src&&(Pn.src=i.src,n=!0),Pn.loop=t!==0;let s=Pn.play();s&&s.catch(()=>{}),n&&Dt.ctx&&be("\u266A "+i.name,"c")}else Pn.pause()}function Bd(){z.musicMode=(z.musicMode+1)%zd.length,rn(),dc(!0)}var Dt={ctx:null,master:null,music:null,sfx:null,nb:null,loops:{},timer:null,init(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}let n=window.AudioContext||window.webkitAudioContext;if(!n)return;let t=this.ctx=new n;this.master=t.createGain(),this.master.gain.value=.75;let e=t.createDynamicsCompressor();this.master.connect(e).connect(t.destination),this.music=t.createGain(),this.music.gain.value=0;let i=t.createBiquadFilter();i.type="lowpass",i.frequency.value=3200,this.music.connect(i).connect(this.master),this.sfx=t.createGain(),this.sfx.connect(this.master);let s=t.createBuffer(1,t.sampleRate*2,t.sampleRate),r=s.getChannelData(0);for(let a=0;a<r.length;a++)r[a]=Math.random()*2-1;this.nb=s,this.loops.wind=this.loopNoise("highpass",900,.5),this.loops.skid=this.loopNoise("bandpass",2400,2.5),this.loops.nitro=this.loopNoise("lowpass",500,1),this.loops.crowd=this.loopNoise("bandpass",750,.7),this.setLoop("crowd",.035),this.startMusic(),dc()},loopNoise(n,t,e){let i=this.ctx,s=i.createBufferSource();s.buffer=this.nb,s.loop=!0;let r=i.createBiquadFilter();r.type=n,r.frequency.value=t,r.Q.value=e;let a=i.createGain();return a.gain.value=0,s.connect(r).connect(a).connect(this.sfx),s.start(0,Math.random()),{g:a,f:r}},setLoop(n,t,e){let i=this.loops[n];i&&(i.g.gain.setTargetAtTime(t,this.ctx.currentTime,.06),e&&i.f.frequency.setTargetAtTime(e,this.ctx.currentTime,.1))},tone(n,t,e="square",i=.2,s=0,r=0,a=null){if(!this.ctx)return;let o=this.ctx,c=r||o.currentTime,l=o.createOscillator(),h=o.createGain();l.type=e,l.frequency.setValueAtTime(n,c),s&&l.frequency.exponentialRampToValueAtTime(s,c+t),h.gain.setValueAtTime(i,c),h.gain.exponentialRampToValueAtTime(.001,c+t),l.connect(h).connect(a||this.sfx),l.start(c),l.stop(c+t+.03)},noise(n,t,e,i=0,s=null,r="bandpass"){if(!this.ctx)return;let a=this.ctx,o=i||a.currentTime,c=a.createBufferSource();c.buffer=this.nb;let l=a.createBiquadFilter();l.type=r,l.frequency.value=e,l.Q.value=1.2;let h=a.createGain();h.gain.setValueAtTime(t,o),h.gain.exponentialRampToValueAtTime(.001,o+n),c.connect(l).connect(h).connect(s||this.sfx),c.start(o,Math.random()),c.stop(o+n+.03)},bark(n=1,t=1){if(!this.ctx||t<.02)return;let e=this.ctx.currentTime;for(let i=0;i<2;i++){let s=e+i*.19;this.tone(560*n,.13,"sawtooth",.2*t,230*n,s),this.tone(280*n,.13,"triangle",.18*t,140*n,s),this.noise(.1,.25*t,1300*n,s)}},voice(n,t=1){if(!this.ctx||t<.02)return;let e=this.ctx.currentTime,i=n.pitch||1;if(n.voice==="hiss")for(let s=0;s<2;s++)this.noise(.32,.32*t,3800*i,e+s*.36,null,"highpass"),this.noise(.3,.12*t,1600*i,e+s*.36);else if(n.voice==="grunt")for(let s=0;s<3;s++){let r=e+s*.17;this.tone(190*i,.12,"square",.12*t,110*i,r),this.tone(95*i,.12,"sawtooth",.12*t,70*i,r),this.noise(.1,.2*t,500,r,null,"lowpass")}else this.bark(i,t)},boom(n=1){!this.ctx||n<.02||(this.noise(.8,.6*n,120,0,null,"lowpass"),this.noise(.4,.4*n,900),this.tone(90,.6,"sine",.4*n,30))},launch(n=1){!this.ctx||n<.02||(this.noise(.5,.35*n,1400),this.tone(300,.35,"sawtooth",.08*n,900))},reload(){let n=this.ctx?this.ctx.currentTime:0;this.noise(.05,.3,3e3,n),this.noise(.06,.3,1800,n+.12),this.tone(700,.1,"square",.06,0,n+.12)},lockon(){this.tone(1760,.06,"square",.07)},squawk(n=1,t=1){if(!this.ctx||t<.03)return;let e=this.ctx.currentTime;for(let i=0;i<2;i++)this.tone(1300*n,.09,"sawtooth",.09*t,800*n,e+i*.12),this.noise(.07,.12*t,2500*n,e+i*.12)},beep(n){this.tone(n?1320:660,n?.6:.25,"square",.14)},jump(){this.noise(.18,.14,700),this.tone(220,.16,"sine",.12,420)},land(){this.noise(.12,.25,180,0,null,"lowpass")},paw(n,t){this.noise(.05,.05+n*.05,t==="snow"?1500:t==="sand"?700:260,0,null,"lowpass")},pickup(){let n=this.ctx?this.ctx.currentTime:0;[523,784,1047].forEach((t,e)=>this.tone(t,.16,"triangle",.14,0,n+e*.05)),this.tone(300,.4,"sawtooth",.05,1200)},coin(){let n=this.ctx?this.ctx.currentTime:0;this.tone(1568,.08,"square",.07,0,n),this.tone(2093,.2,"square",.07,0,n+.06)},boost(){this.tone(180,.5,"sawtooth",.12,900),this.noise(.5,.22,1200)},splash(){this.noise(.35,.3,900)},trip(){this.tone(300,.45,"sawtooth",.14,70),this.noise(.25,.3,300)},thud(){this.noise(.14,.35,150,0,null,"lowpass")},lap(){let n=this.ctx?this.ctx.currentTime:0;[880,1175].forEach((t,e)=>this.tone(t,.18,"square",.1,0,n+e*.12))},fanfare(){if(!this.ctx)return;let n=this.ctx.currentTime;[[523,0],[659,.12],[784,.24],[1047,.36],[784,.56],[1047,.68]].forEach(([t,e])=>this.tone(t,.25,"square",.1,0,n+e)),this.cheer()},cheer(){if(!this.ctx)return;let n=this.loops.crowd.g.gain,t=this.ctx.currentTime;n.cancelScheduledValues(t),n.setValueAtTime(.22,t),n.linearRampToValueAtTime(.035,t+4)},setMusic(n){this.music&&this.music.gain.setTargetAtTime(n?.22:0,this.ctx.currentTime,.1)},startMusic(){if(this.timer||!this.ctx)return;let n=a=>440*Math.pow(2,(a-69)/12),t=[[45,[0,3,7]],[41,[0,4,7]],[48,[0,4,7]],[43,[0,4,7]]],e=[76,0,76,79,0,76,74,72,72,0,72,76,0,72,71,69,72,0,72,76,0,79,77,76,74,0,74,79,0,78,79,0],i=60/124/4,s=0,r=this.ctx.currentTime+.1;this.timer=setInterval(()=>{if(!(!this.ctx||this.ctx.state!=="running"))for(;r<this.ctx.currentTime+.15;){let a=(s>>4)%4,o=s%16,[c,l]=t[a],h=this.music;o%2===0&&this.tone(n(c-12+(o%4===2?12:0)),i*1.8,"sawtooth",.22,0,r,h),this.tone(n(c+24+l[o%3]+(o%6>2?12:0)),i*.9,"square",.035,0,r,h);let u=e[(s>>1)%32];s%2===0&&u&&(s>>6)%2&&this.tone(n(u),i*1.8,"triangle",.09,0,r,h),o%4===0&&this.tone(150,.16,"sine",.5,40,r,h),(o===4||o===12)&&this.noise(.14,.3,1800,r,h),o%2===1&&this.noise(.03,.08,8e3,r,h,"highpass"),r+=i,s++}},25)}},qi=[{n:"F\xC1CIL",k:.93,miss:.25,upOff:-1,reward:.8},{n:"NORMAL",k:.98,miss:.12,upOff:0,reward:1},{n:"DIF\xCDCIL",k:1.03,miss:.05,upOff:1,reward:1.3}],Hv=[{id:"motor",name:"MOTOR",desc:"Mais velocidade m\xE1xima"},{id:"acel",name:"M\xDASCULOS",desc:"Arranca e acelera mais r\xE1pido"},{id:"grip",name:"GARRAS",desc:"Mais ader\xEAncia nas curvas e no drift"},{id:"nitro",name:"TANQUE DE NITRO",desc:"Nitro dura mais e empurra mais forte"},{id:"pulo",name:"MOLAS",desc:"Pula mais alto e mais longe"}],Hd=[150,280,450,700,1e3],kv=2.6,Gv=30,Vv=1;function pc(n){return z.up[n.id]||(z.up[n.id]={motor:0,acel:0,grip:0,nitro:0,pulo:0})}function Wv(n,t){return{maxV:30+n.spd*1.8+t.motor*1.4,accel:9+n.acc*2.4+t.acel*1.9,grip:5.5+n.han*.8+t.grip*.7,turn:1.5+n.han*.06+t.grip*.05,jumpV:9.6+n.jmp*.75+t.pulo*.5,nitroDrain:30*(1-t.nitro*.09),nitroPow:1.3+t.nitro*.03}}var Xv={throttle:0,brake:!1,steer:0,drift:!1,nitro:!1,jump:!1,bark:!1,fire:!1},dh=class{constructor(t,e,i,s){this.b=t,this.num=e,this.isPlayer=i,this.D=Dd(t,e,t.color),nn.add(this.D.root),this.look=i?hc(t):Id(),uc(this.D,this.look),Object.assign(this,Wv(t,s)),this.skill=i?1:qi[z.diff].k*(.98+Math.random()*.04),this.x=0,this.z=0,this.h=0,this.vx=0,this.vz=0,this.y=0,this.vy=0,this.yawRate=0,this.s=0,this.idx=0,this.dist=0,this.d=0,this.speed=0,this.slide=0,this.nitro=30,this.nitroOn=!1,this.drifting=!1,this.driftDir=0,this.driftT=0,this.mini=0,this.pad=0,this.stun=0,this.spook=0,this.barkCD=2,this.slip=0,this.surf=null,this.phase=Math.random()*6,this.lastStep=0,this.finished=!1,this.finishTime=0,this.lastLap=1,this.prevJump=!1,this.prevBark=!1,this.air=!1,this.rampAir=!1,this.ammo=1,this.fireCD=0,this.prevFire=!1,this.missHits=0,this.flip=0,this.lockT=0,this.lane=(Math.random()-.5)*8,this.laneT=1+Math.random()*3,this.aiNitro=!1,this.jumpPlan=new Map,this.minis=0,this.scared=0,this.cleanJumps=0,this.cans=0,this.hits=0,this.birdT=0,this.hitCD=0,this.driftScore=0,this.coins=0,this.lapStart=0,this.bestLap=0,this.pressT=null,this.wrongT=0}get lap(){return he(Math.floor(this.dist/Le)+1,1,z.laps)}place(t,e){this.dist=t,this.s=fc(t),this.idx=Math.round(this.s/Le*Xe)%Xe;let i=Ve(t,e);this.x=i.x,this.z=i.z,this.d=e,this.h=ri(t)}dispose(){nn.remove(this.D.root),yr(this.D.root)}},me=[],ot=null,We=null,fn=null;function Yv(n){let t=n.idx,e=1/0;for(let l=-40;l<=40;l++){let h=(n.idx+l+Xe)%Xe,u=n.x-Ye[h].x,f=n.z-Ye[h].z,d=u*u+f*f;d<e&&(e=d,t=h)}n.idx=t;let i=Ye[t],s=Qn[t],r=Ts[t],a=n.x-i.x,o=n.z-i.z,c=fc(t*Le/Xe+a*s.x+o*s.z);n.d=a*r.x+o*r.z,n.dist+=Mn(c-n.s),n.s=c}function xs(n,t){if(!n.drifting||(n.drifting=!1,t))return;let e=n.driftT>2?2:n.driftT>.9?1:0,i=Math.round(n.driftT*140);n.driftScore+=i,e&&(n.minis++,n.isPlayer&&Ln(e===2?[25,30,25]:25),n.mini=e===2?1.5:.8,n.nitro=Math.min(100,n.nitro+e*8),n.isPlayer&&(be(e===2?"SUPER MINI-TURBO!":"MINI-TURBO!",e===2?"o":"c"),Dt.boost())),n.isPlayer&&i>60&&be(`DRIFT +${i}`,"g")}var $v=n=>n.voice==="hiss"?"CHIADO!":n.voice==="grunt"?"RONCO!":"LATIDO!",qv=n=>n.voice==="hiss"?"SSSSSS!":n.voice==="grunt"?"OINC OINC!":"AU AU!";function Zv(n){n.barkCD=6;let t=Math.sin(n.h),e=Math.cos(n.h);Dt.voice(n.b,ot?he(1-Math.hypot(n.x-ot.x,n.z-ot.z)/60,0,1):1);let i=0;for(let a of me){if(a===n||a.stun>0)continue;let o=a.x-n.x,c=a.z-n.z;Math.hypot(o,c)<12&&o*t+c*e>-2&&(a.spook=1.1,i++,a.isPlayer&&be("ASSUSTADO!","r"))}let s=0;for(let a of Ss)a.state!=="approach"&&a.state!=="harass"||Math.hypot(a.pos.x-n.x,a.pos.z-n.z)<15&&(Yo(a,n),s++);s&&(n.scared+=s,n.nitro=Math.min(100,n.nitro+10*s),n.isPlayer&&be(`ESPANTOU ${s>1?s+" "+Si().plural:"O "+Si().name}! +NITRO`,"v"));let r=n.D.head.getWorldPosition(te);for(let a=0;a<26;a++){let o=a/26*6.28;In.spawn(r.x,r.y,r.z,Math.cos(o)*14,.5,Math.sin(o)*14,.45,.5,1.4,[1,.85,.4],.8,0,3)}n.isPlayer&&!s&&be(i?`${$v(n.b)} ${i} ASSUSTADO${i>1?"S":""}`:qv(n.b),"g")}function ph(n,t,e){let i=n.dist,s=n.y>.02;n.stun>0&&(n.stun-=e,t=Xv),n.spook>0&&(n.spook-=e,t={...t,nitro:!1,steer:he(t.steer+Math.sin(Cn*16+n.num)*.7,-1,1)});let r=t.jump&&!n.prevJump;n.prevJump=t.jump;let a=t.bark&&!n.prevBark;n.prevBark=t.bark,n.barkCD-=e,a&&n.barkCD<=0&&Zv(n);let o=t.fire&&!n.prevFire;n.prevFire=t.fire,n.fireCD-=e,n.flip=Math.max(0,n.flip-e),o&&jv(n);let c=Math.abs(n.d)>Nt/2+.4,l=n.grip*At.grip*(c?.8:1),h=c?.62:1;!s&&n.surf==="mud"?(l*=.5,h*=.62):!s&&n.surf==="water"?(l*=.8,h*=.72):!s&&n.surf==="ice"&&(l*=.22),n.hitCD=Math.max(0,n.hitCD-e),n.birdT>0&&(n.birdT-=e,t={...t,steer:he(t.steer+Math.sin(Cn*11+n.num*2)*.45,-1,1)}),n.nitroOn=t.nitro&&n.nitro>.5&&n.stun<=0,n.nitroOn&&(n.nitro=Math.max(0,n.nitro-n.nitroDrain*e)),n.mini=Math.max(0,n.mini-e),n.pad=Math.max(0,n.pad-e);let u=1;!n.isPlayer&&ot&&!ot.finished&&(u=1+he((ot.dist-n.dist)/220,-.07,.07));let f=n.maxV*n.skill*u*h*(n.nitroOn?n.nitroPow:1)*(n.mini>0?1.15:1)*(n.pad>0?1.22:1)*(n.slip>.5?1.06:1)*(n.spook>0?.72:1)*(n.birdT>0?.7:1)*(n.finished?.5:1),d=n.vx*Math.sin(n.h)+n.vz*Math.cos(n.h),p=Math.max(.45,he(Math.abs(d)/7,0,1))*(1-.3*he(Math.abs(d)/70,0,1));!n.drifting&&t.drift&&t.steer!==0&&d>16&&!s&&n.stun<=0&&(n.drifting=!0,n.driftDir=Math.sign(t.steer),n.driftT=0),n.drifting&&(!t.drift||d<10)&&xs(n,!1);let x;n.drifting?(n.driftT+=e,x=-n.driftDir*n.turn*p*(.8+.5*t.steer*n.driftDir),n.nitro=Math.min(100,n.nitro+8*e)):x=-t.steer*n.turn*p*(d<-1?-1:1),s&&(x*=.35),n.yawRate=ke(n.yawRate,x,1-Math.exp(-(n.drifting?6:12)*e)),n.h+=n.yawRate*e;let g=Math.abs(n.d)>Nt/2+1.6;if(n.isPlayer&&!n.drifting&&!s&&(z.assist&&!t.steer&&d>3||g)){let M=Ve(n.dist+8+d*.35,he(n.d,-Nt/2+2,Nt/2-2)),U=sh(Math.atan2(M.x-n.x,M.z-n.z)-n.h);n.h+=he(U,-1,1)*(g?3:1.8)*e}let m=Math.sin(n.h),S=Math.cos(n.h),y=-S,b=m;d=n.vx*m+n.vz*S;let C=n.vx*y+n.vz*b;if(s)C*=Math.exp(-.4*e);else if(t.throttle>0&&d<f&&(d+=(n.accel*(n.nitroOn?1.7:1)*t.throttle*(1-.55*he(d/f,0,1))+(n.mini>0?14:0)+(n.pad>.6?30:0))*e),t.throttle||(d-=Math.sign(d)*Math.min(Math.abs(d),7*e)),t.brake&&(d=d>0?Math.max(0,d-38*e):Math.max(-9,d-12*e)),t.drift&&!n.drifting&&d>4&&(d-=10*e),d>f&&(d=Math.max(f,d-(d-f)*2.2*e-2*e)),n.drifting){let M=d*d+C*C;C*=Math.exp(-(2.6+n.grip*.1)*e),d=Math.max(d,Math.sqrt(Math.max(0,M*(1-.12*e)-C*C)))}else C*=Math.exp(-l*e);if(n.vx=m*d+y*C,n.vz=S*d+b*C,n.x+=n.vx*e,n.z+=n.vz*e,n.speed=d,n.slide=C,r&&!s&&n.stun<=0&&(n.vy=n.jumpV,n.isPlayer&&Dt.jump(),n.drifting&&xs(n,!1)),n.vy-=Gv*e,n.y+=n.vy*e,n.y<=0){if(s){n.isPlayer&&n.vy<-8&&(Dt.land(),Ei(.12)),n.rampAir&&(n.rampAir=!1,n.nitro=Math.min(100,n.nitro+12),n.isPlayer&&be("SALTO! +NITRO","c"));for(let M=0;M<10;M++)kd(n,1.4)}n.y=0,n.vy=0}n.air=n.y>.02;let A=he(Math.abs(d)/12,0,1);n.phase+=e*(A>.02?4+Math.abs(d)*.33:0),Yv(n);let R=Nt/2+2.1;if(Math.abs(n.d)>R){let M=Math.sign(n.d),U=br(n.s),H=Math.abs(n.d)-R;n.x-=U.r.x*M*H,n.z-=U.r.z*M*H,n.d=M*R;let rt=(n.vx*U.r.x+n.vz*U.r.z)*M;if(rt>0){n.vx-=U.r.x*M*rt*1.3,n.vz-=U.r.z*M*rt*1.3,n.vx*=.95,n.vz*=.95;let I=Math.sin(n.h)*U.t.x+Math.cos(n.h)*U.t.z>=0?1:-1;n.h+=sh(Math.atan2(U.t.x*I,U.t.z*I)-n.h)*.3,n.isPlayer&&rt>6&&(Ei(.3),Dt.thud(),Ln(35)),rt>8&&xs(n,!0)}}let O=n.s;for(let M of $i)Math.floor((i-M.s)/Le)<Math.floor((n.dist-M.s)/Le)&&Math.abs(n.d)<Nt/2+.6&&(n.y<.55&&n.stun<=0?(n.stun=1,n.vx*=.25,n.vz*=.25,n.vy=3,M.fall=1,xs(n,!0),n.nitroOn=!1,n.hits++,n.isPlayer&&(Dt.trip(),be("TROPE\xC7OU!","r"),Ei(.4),Ln(70))):n.y>=.55&&(n.nitro=Math.min(100,n.nitro+10),n.cleanJumps++,n.isPlayer&&be("PULO LIMPO! +NITRO","v")));for(let M of ch)Math.floor((i-M.s)/Le)<Math.floor((n.dist-M.s)/Le)&&Math.abs(n.d)<Nt/2&&n.y<.4&&(n.vy=9+Math.max(0,d)*.13,n.y=1.1,n.rampAir=!0,n.isPlayer&&(Dt.jump(),Ei(.15)));for(let M of ec)n.pad>.5||n.y>.5||Math.abs(Mn(O-M.s))<3.5&&Math.abs(n.d-M.d)<2.2&&(n.pad=1.1,n.isPlayer&&(Dt.boost(),be("TURBO!","c"),Ei(.1)));let E=n.surf;if(n.surf=null,!n.air)for(let M of nc){let U=Mn(O-M.s)/1.4,H=(n.d-M.d)/.8;U*U+H*H<M.r*M.r&&(n.surf=M.type)}if(n.isPlayer&&n.surf&&n.surf!==E&&(n.surf==="ice"?be("GELO!","c"):(Dt.splash(),be(n.surf==="mud"?"LAMA!":"SPLASH!","r"))),n.surf&&n.surf!=="ice"&&Math.abs(d)>6&&Math.random()<.6){let M=n.surf==="mud"?[.25,.15,.07]:[.75,.88,1];ci.spawn(n.x,.3,n.z,(Math.random()-.5)*6,3+Math.random()*3,(Math.random()-.5)*6,.6,.3,.6,M,.9,14,1)}for(let M of vr)!M.active||n.hitCD>0||n.stun>0||n.y>M.r*1.25||Math.abs(Mn(O-M.s))<M.r+.7&&Math.abs(n.d-M.d)<M.r+.8&&(n.stun=.9,n.hitCD=2,n.vx*=.3,n.vz*=.3,n.vy=5,n.hits++,xs(n,!0),n.isPlayer?(Dt.thud(),Dt.trip(),Ei(.5),be(M.hitMsg,"r"),Ln([80,40,80])):Yi(`BOLADA EM ${n.b.name}!`));for(let M of _r){if(M.cd>0||n.y>2.4)continue;let U=Mn(O-M.s),H=n.d-M.d;U*U+H*H<3.2&&(M.cd=8,M.g.visible=!1,n.nitro=Math.min(100,n.nitro+35),n.cans++,n.isPlayer&&(Dt.pickup(),be("NITRO +35","c"),Ln(15)))}for(let M of _a){if(M.cd>0||n.y>2.4||n.ammo>=3)continue;let U=Mn(O-M.s),H=n.d-M.d;U*U+H*H<3.4&&(M.cd=9,M.g.visible=!1,n.ammo++,n.isPlayer&&(Dt.reload(),be(`M\xCDSSIL +1 (${n.ammo}/3)`,"o"),Ln(15)))}if(n.isPlayer)for(let M of ma){if(M.taken||n.y>2.6)continue;let U=Mn(O-M.s),H=n.d-M.d;U*U+H*H<3.4&&(M.taken=!0,M.g.visible=!1,n.coins++,Dt.coin())}if(!n.finished&&n.dist>=z.laps*Le){n.finished=!0,n.finishTime=Wn;let M=Wn-n.lapStart;(!n.bestLap||M<n.bestLap)&&(n.bestLap=M),xs(n,!1),n.isPlayer&&uM()}else if(!n.finished&&n.lap>n.lastLap){let M=Wn-n.lapStart;(!n.bestLap||M<n.bestLap)&&(n.bestLap=M),n.lapStart=Wn,n.lastLap=n.lap,n.isPlayer&&(Dt.lap(),Fh(n.lap===z.laps?"\xDALTIMA VOLTA":`VOLTA ${n.lap}`,1400,`melhor volta ${Er(n.bestLap)}`))}if(n.isPlayer&&!n.air&&A>.1){let M=Math.floor(n.phase/Math.PI);M!==n.lastStep&&(n.lastStep=M,Dt.paw(A,At.surface))}}function kd(n,t=1){let e=At.surface==="snow"?[.92,.95,1]:At.surface==="sand"?[.85,.75,.55]:[.55,.4,.27],i=n.x-Math.sin(n.h)*1.2,s=n.z-Math.cos(n.h)*1.2;ci.spawn(i+(Math.random()-.5)*1.2,.2,s+(Math.random()-.5)*1.2,(Math.random()-.5)*3*t-n.vx*.05,(.8+Math.random()*1.5)*t,(Math.random()-.5)*3*t-n.vz*.05,.9+Math.random()*.6,.6*t,2.4*t,e,.45,-.5,1.5)}function Jv(n,t){hv(n,t);let e=Math.hypot(n.vx,n.vz);if(!n.air&&e>8&&Math.random()<t*e*(n.drifting?1.6:.5)*(z.qual===0?.5:1)&&kd(n,n.drifting?1.3:1),n.drifting&&!n.air){let i=n.driftT>2?2:n.driftT>.9?1:0,s=i===2?[1,.35,.9]:i===1?[.3,.8,1]:[1,.85,.4];for(let r of[-1,1]){let a=n.x-Math.sin(n.h)*1+Math.cos(n.h)*r*.3,o=n.z-Math.cos(n.h)*1-Math.sin(n.h)*r*.3;In.spawn(a,.15,o,(Math.random()-.5)*5-n.vx*.1,2+Math.random()*3,(Math.random()-.5)*5-n.vz*.1,.35,i?.35:.22,.05,s,1,12,1)}}if(n.nitroOn)for(let i of n.D.flames){let s=i.getWorldPosition(te);In.spawn(s.x,s.y,s.z,-Math.sin(n.h)*8+(Math.random()-.5),Math.random()-.5,-Math.cos(n.h)*8+(Math.random()-.5),.25,.45,.1,Math.random()<.5?[1,.5,.15]:[.35,.75,1],1,0,2)}if(n.mini>0||n.pad>0){let i=n.D.body.getWorldPosition(te);In.spawn(i.x,i.y+.4,i.z,-n.vx*.3,.5,-n.vz*.3,.3,.8,.2,n.pad>0?[.3,.85,1]:[1,.55,.2],.7,0,1)}}function mh(n,t){let e=n.s;n.laneT-=t,n.laneT<=0&&(n.lane=(Math.random()-.5)*10,n.laneT=2+Math.random()*3);let i=n.lane;if(n.nitro<60)for(let p of _r){let x=Mn(p.s-e);if(p.cd<=0&&x>0&&x<40){i=p.d;break}}for(let p of ec){let x=Mn(p.s-e);if(x>0&&x<35){i=p.d;break}}for(let p of nc){let x=Mn(p.s-e);x>-3&&x<30&&Math.abs(i-p.d)<p.r+2&&(i=p.d+(i>=p.d?1:-1)*(p.r+2.6))}for(let p of me){if(p===n)continue;let x=Mn(p.dist-n.dist);x>0&&x<6&&Math.abs(p.d-n.d)<2.2&&(i+=n.d>=p.d?2.6:-2.6)}i=he(i,-Nt/2+1.5,Nt/2-1.5);let s=7+Math.max(0,n.speed)*.42,r=Ve(n.dist+s,i),a=sh(Math.atan2(r.x-n.x,r.z-n.z)-n.h),o=he(-a*2.6,-1,1),l=1-Qn[n.idx].dot(Qn[(n.idx+40)%Xe])>.2&&n.speed>n.maxV*.9?.4:1,h=!1;for(let p=0;p<$i.length;p++){let x=Mn($i[p].s-e),g=p+":"+Math.floor((n.dist-$i[p].s)/Le);n.jumpPlan.has(g)||n.jumpPlan.set(g,Math.random()<qi[z.diff].miss?-1:.2+Math.random()*.14);let m=n.jumpPlan.get(g);m>0&&x>0&&x<n.speed*m+1&&(h=!0)}let u=Qn[n.idx].dot(Qn[(n.idx+80)%Xe])>.94;u&&n.nitro>35&&(n.aiNitro=!0),(!u||n.nitro<5)&&(n.aiNitro=!1);for(let p of vr){if(!p.active)continue;let x=Mn(p.s-e);x>0&&x<n.speed*.3+p.r+1&&Math.abs(p.d-n.d)<p.r+2.5&&Math.random()>qi[z.diff].miss*t*30&&(h=!0)}let f=n.birdT>0&&n.barkCD<=0&&Math.random()<t*(.8+z.diff*.8);if(n.barkCD<=0&&Math.random()<t*(.25+z.diff*.2))for(let p of me){if(p===n)continue;let x=Mn(p.dist-n.dist);x>1&&x<9&&Math.abs(p.d-n.d)<4&&(f=!0)}let d=!1;return n.ammo>0&&n.fireCD<=0&&Wn>4&&Math.random()<t*(.5+z.diff*.45)&&Xd(n)&&(d=!0),{throttle:l,brake:!1,steer:o,drift:!1,nitro:n.aiNitro,jump:h,bark:f,fire:d}}function Gd(n){for(let t=0;t<me.length;t++)for(let e=t+1;e<me.length;e++){let i=me[t],s=me[e],r=s.x-i.x,a=s.z-i.z,o=r*r+a*a,c=Vv*2;if(o<c*c&&Math.abs(i.y-s.y)<1.2){let l=Math.sqrt(o)||.01,h=r/l,u=a/l,f=(c-l)/2,d=(s.b.mass||1)/((i.b.mass||1)+(s.b.mass||1))*2,p=2-d;i.x-=h*f*d,i.z-=u*f*d,s.x+=h*f*p,s.z+=u*f*p;let x=(s.vx-i.vx)*h+(s.vz-i.vz)*u;if(x<0){let g=i.b.mass||1,m=s.b.mass||1,S=-1.3*x/(1/g+1/m);i.vx-=S/g*h,i.vz-=S/g*u,s.vx+=S/m*h,s.vz+=S/m*u,(i.isPlayer||s.isPlayer)&&-x>5&&(Dt.thud(),Ei(.2))}}}for(let t of me){let e=Math.sin(t.h),i=Math.cos(t.h),s=!1;for(let r of me){if(r===t||r.speed<15)continue;let a=r.x-t.x,o=r.z-t.z,c=a*e+o*i,l=Math.abs(a*i-o*e);if(c>2.5&&c<14&&l<1.8){s=!0;break}}t.slip=s?t.slip+n:0,t.slip>.5&&(t.nitro=Math.min(100,t.nitro+5*n))}}var bs=[],Mr=[],_a=[];function Vd(){let n=new bt,t=new Ct(new kt(.14,.14,.9,14),pt(15658734,.35,.5));t.rotation.x=Math.PI/2,n.add(t);let e=new Ct(new Je(.14,.34,14),Qo);e.rotation.x=Math.PI/2,e.position.z=.62,n.add(e);let i=new Ct(new kt(.145,.145,.1,14),Rh);i.rotation.x=Math.PI/2,i.position.z=.2,n.add(i);for(let r=0;r<4;r++){let a=new Ct(new de(.02,.3,.22),Qo);a.rotation.z=r*Math.PI/2,a.position.z=-.38,a.translateY(.15),n.add(a)}let s=new Ct(new Je(.12,.6,10),new Bn({color:16752704,transparent:!0,opacity:.9,blending:Gi,depthWrite:!1}));return s.rotation.x=-Math.PI/2,s.position.z=-.75,n.add(s),n.traverse(r=>{r.isMesh&&(r.castShadow=!0)}),n.visible=!1,n}function Kv(){Mr=[],bs=[];for(let n=0;n<10;n++){let t=Vd();Re.add(t),Mr.push(t)}}function Wd(){for(let n of bs)n.mesh.visible=!1,Mr.push(n.mesh);bs=[];for(let n of me)n.lockT=0}function Xd(n){let t=Math.sin(n.h),e=Math.cos(n.h),i=null,s=95;for(let r of me){if(r===n||r.finished)continue;let a=r.x-n.x,o=r.z-n.z,c=Math.hypot(a,o);c<s&&c>2&&(a*t+o*e)/c>.55&&(s=c,i=r)}return i}function jv(n){if(n.ammo<=0||n.fireCD>0||n.stun>0||!Mr.length){n.isPlayer&&n.ammo<=0&&be("SEM M\xCDSSEIS! PEGUE AS CAIXAS","r");return}n.ammo--,n.fireCD=.7;let t=Mr.pop(),e=n.D.launcher.muzzle.getWorldPosition(new P),i=Xd(n),s=Math.sin(n.h),r=Math.cos(n.h),a=Math.max(0,n.speed)+38;t.visible=!0,t.position.copy(e),bs.push({mesh:t,pos:e,vel:new P(s*a,3,r*a),owner:n,target:i,t:0});let o=ot?he(1-Math.hypot(n.x-ot.x,n.z-ot.z)/70,0,1):1;Dt.launch(o);for(let c=0;c<12;c++)ci.spawn(e.x,e.y,e.z,(Math.random()-.5)*4-s*6,Math.random()*2,(Math.random()-.5)*4-r*6,.8,.5,1.6,[.8,.8,.8],.6,-1,2);n.isPlayer&&be(i?`M\xCDSSIL NO ${i.b.name}!`:"M\xCDSSIL!","o"),i&&i.isPlayer&&(be(`${n.b.name} ATIROU EM VOC\xCA!`,"r"),Dt.lockon())}var nh=new P;function Yd(n){for(let t=bs.length-1;t>=0;t--){let e=bs[t];e.t+=n;let i=e.target&&!e.target.finished?e.target:null,s=Math.max(62,e.vel.length());i?(nh.set(i.x,1.1+i.y,i.z).sub(e.pos).normalize().multiplyScalar(s),e.vel.lerp(nh,1-Math.exp(-(e.t<.25?1:3.4)*n)),i.isPlayer&&(i.lockT=.3)):e.vel.y+=(1.2-e.pos.y)*n*4,e.vel.setLength(Math.min(s+25*n,80)),e.pos.addScaledVector(e.vel,n),e.pos.y<.5&&(e.pos.y=.5,e.vel.y=Math.abs(e.vel.y)*.3),e.mesh.position.copy(e.pos),e.mesh.lookAt(nh.copy(e.pos).add(e.vel)),In.spawn(e.pos.x,e.pos.y,e.pos.z,-e.vel.x*.05,.3,-e.vel.z*.05,.25,.7,.2,Math.random()<.5?[1,.6,.2]:[1,.9,.5],1,0,2),Math.random()<.7&&ci.spawn(e.pos.x,e.pos.y,e.pos.z,Math.random()-.5,Math.random(),Math.random()-.5,1.2,.5,2.2,[.75,.75,.78],.45,-.6,1.5);let r=null;for(let a of me)if(!(a===e.owner&&e.t<1.5)&&Math.hypot(a.x-e.pos.x,a.z-e.pos.z)<1.8&&Math.abs(a.y+1-e.pos.y)<1.8){r=a;break}(r||e.t>3.2)&&(Qv(e,r),bs.splice(t,1))}}function Qv(n,t){n.mesh.visible=!1,Mr.push(n.mesh);let e=n.pos;for(let s=0;s<40;s++){let r=Math.random()*6.28,a=Math.random()*10;In.spawn(e.x,e.y,e.z,Math.cos(r)*a,Math.random()*9,Math.sin(r)*a,.5+Math.random()*.4,1.4,.3,Math.random()<.5?[1,.55,.15]:[1,.85,.3],1,6,2.5)}for(let s=0;s<18;s++)ci.spawn(e.x,e.y,e.z,(Math.random()-.5)*7,Math.random()*5,(Math.random()-.5)*7,1.6,1.2,3.6,[.3,.28,.27],.7,-1.5,1.8);let i=ot?Math.hypot(e.x-ot.x,e.z-ot.z):0;Dt.boom(he(1-i/90,0,1)),i<25&&Ei(.6*(1-i/25)),t&&(t.stun=1.4,t.flip=1,t.vx*=.2,t.vz*=.2,t.vy=8,t.nitroOn=!1,t.hits++,xs(t,!0),n.owner!==t&&n.owner.missHits++,t.isPlayer?(be("ATINGIDO POR UM M\xCDSSIL!","r"),Ei(.8),Ln([100,50,160])):!n.owner.isPlayer&&n.owner!==t&&Yi(`${n.owner.b.name} ACERTOU ${t.b.name} COM UM M\xCDSSIL!`),n.owner.isPlayer&&t!==n.owner&&(be(`ACERTOU ${t.b.name}!`,"v"),n.owner.nitro=Math.min(100,n.owner.nitro+10)))}function da(n){n.D.root.position.set(n.x,0,n.z),n.D.root.rotation.y=n.h,n.D.launcher.noses.forEach((t,e)=>{t.visible=e<n.ammo}),n.D.model.rotation.x=n.flip>0?-(1-n.flip)*Math.PI*2:0,n.D.model.position.y=n.y,n.D.anim(n.D,{v:Math.hypot(n.vx,n.vz),y:n.y,vy:n.vy,phase:n.phase,yawRate:n.yawRate,stun:n.stun,spook:n.spook,nitro:n.nitroOn,idle:!1},Cn+n.num)}var Oh=["ATR\xC1S","ALTA","CACHORRO"],Mi=new P(0,0,1),ih=new P,bi=new P,mr=0;function Ei(n){mr=Math.max(mr,n)}function gh(n,t,e=!1){let i=Math.hypot(n.vx,n.vz),s=Math.sin(n.h),r=Math.cos(n.h);if(i>4&&(s=s*.55+n.vx/i*.45,r=r*.55+n.vz/i*.45),bi.set(s,0,r).normalize(),Mi.lerp(bi,e?1:1-Math.exp(-4.5*t)).normalize(),z.cam===2){let o=n.D.head.getWorldPosition(bi);pe.position.set(o.x-Mi.x*.3,o.y+.55,o.z-Mi.z*.3),ih.set(n.x+Mi.x*25,1.2+n.y*.3,n.z+Mi.z*25)}else{let o=(z.cam?11.5:6.6)+i*.025,c=z.cam?6:2.7;bi.set(n.x-Mi.x*o,c+n.y*.5,n.z-Mi.z*o),pe.position.lerp(bi,e?1:1-Math.exp(-8*t)),ih.set(n.x+Mi.x*5,1.3+n.y*.6,n.z+Mi.z*5)}mr>.001&&(pe.position.x+=(Math.random()-.5)*mr,pe.position.y+=(Math.random()-.5)*mr,mr*=Math.exp(-7*t)),pe.lookAt(ih);let a=64+i*.18+(n.nitroOn?10:0)+(n.pad>0||n.mini>0?5:0);pe.fov=ke(pe.fov,a,1-Math.exp(-3*t)),pe.updateProjectionMatrix()}var Gt="loading",Wn=0,pa=0,Ri=0,xh=-1,ud="race",Cn=0,dr=0,Er=n=>{let t=Math.floor(n/60),e=Math.floor(n%60),i=Math.floor(n*100%100);return`${t}:${String(e).padStart(2,"0")}.${String(i).padStart(2,"0")}`};function be(n,t=""){let e=document.createElement("div");e.className="pop "+t,e.textContent=n;let i=_t("pops");for(i.appendChild(e);i.children.length>3;)i.firstChild.remove();setTimeout(()=>e.remove(),1300)}var fd=null;function Fh(n,t=1200,e=""){let i=_t("big");i.innerHTML=n+(e?`<small>${e}</small>`:""),i.classList.remove("pop"),i.offsetWidth,i.classList.add("pop"),clearTimeout(fd),t&&(fd=setTimeout(()=>{i.innerHTML=""},t))}function Ln(n){if(z.vib&&navigator.vibrate)try{navigator.vibrate(n)}catch{}}function ye(n,t){_t(n).hidden=!t}function Tr(){document.querySelectorAll(".cval").forEach(n=>n.textContent=z.coins.toLocaleString("pt-BR"))}function mc(){We&&(nn.remove(We.root),yr(We.root));let n=Fe[z.dog];We=Dd(n,1,n.color),uc(We,hc(n)),nn.add(We.root);let t=Ve(22,0);if(!fn||fn.parent!==Re){fn=new bt,Tt(new kt(3.2,3.4,.3,48),pt(2764600,.3,.8),!0,!0,fn).position.y=.15;let e=Tt(new lr(3.3,.06,8,64),pt(16742938,.3,0,{emissive:16742938,emissiveIntensity:1.5}),!1,!1,fn);e.rotation.x=Math.PI/2,e.position.y=.3,Re.add(fn)}fn.position.copy(t),We.root.position.set(t.x,.3,t.z)}function wr(){let n=Fe[z.dog],t=pc(n);_t("dogName").textContent=n.name,_t("dogBreed").textContent=n.raca;let e=[["VELOCIDADE",n.spd,t.motor],["ACELERA\xC7\xC3O",n.acc,t.acel],["CURVAS",n.han,t.grip],["PULO",n.jmp,t.pulo]];_t("stats").innerHTML=e.map(([i,s,r])=>`<div class="stat"><span>${i}</span><div class="cells">${Array.from({length:10},(a,o)=>`<span class="${o<s?"b":o<s+r?"u":""}"></span>`).join("")}</div></div>`).join(""),_t("trackName").textContent=As[z.track].name.split(" ")[0],_t("diffName").textContent=qi[z.diff].n,_t("lapsName").textContent=z.laps,_t("modeName").textContent=z.mode?"COPA":"CORRIDA",z.mode&&(_t("trackName").textContent="TODAS"),_t("startBtn").textContent=z.mode?"COME\xC7AR COPA":"CORRER",Tr()}function $d(){let n=Fe[z.dog],t=pc(n);_t("garageDog").textContent=`${n.name} \xB7 ${n.raca}`,_t("upList").innerHTML=Hv.map(e=>{let i=t[e.id],s=Hd[i],r=i>=5;return`<div class="up panel"><h3>${e.name}</h3><p>${e.desc}</p><div class="pips">${[0,1,2,3,4].map(a=>`<span class="${a<i?"on":""}"></span>`).join("")}</div>
      <button data-up="${e.id}" ${r||z.coins<s?"disabled":""}>${r?"M\xC1XIMO":"MELHORAR<br>"+s}</button></div>`}).join(""),Tr()}_t("upList").addEventListener("click",n=>{let t=n.target.closest("button[data-up]");if(!t||t.disabled)return;let e=Fe[z.dog],i=pc(e),s=t.dataset.up,r=Hd[i[s]];z.coins<r||i[s]>=5||(z.coins-=r,i[s]++,i[s]>=5&&(z.stats.maxUp=1),rn(),Ea(),Dt.init(),Dt.pickup(),Dt.voice(e,.6),$d())});function oi(){Bh(),Gt="menu",["hud","results","pause","touch","lights","garage","shop","missions","cupEnd"].forEach(n=>ye(n,!1)),ye("menu",!0),_t("big").innerHTML="",_t("pops").innerHTML="",Wh(0,0),Dt.ctx&&["wind","skid","nitro"].forEach(n=>Dt.setLoop(n,0)),Gh(),mc(),wr()}var Rn="hat",$o="daily";function tM(){Gt="shop",["menu"].forEach(n=>ye(n,!1)),ye("shop",!0),zh()}function zh(){let n=Fe[z.dog],t=hc(n);_t("shopDog").textContent=`${n.name} \xB7 ${n.raca}`,_t("shopTabs").innerHTML=Object.entries(Es).map(([e,i])=>`<button data-c="${e}" class="${e===Rn?"on":""}">${i.n}</button>`).join(""),_t("shopList").innerHTML=Es[Rn].items.map(([e,i,s])=>{let r=av(Rn,e),a=t[Rn]===e,o=Rn==="vest"?e==="padrao"?n.color:"#"+Pd[e].toString(16).padStart(6,"0"):Rn==="cape"?Ld[e]||"transparent":Rn==="trail"?nv[e]||"transparent":Rn==="hat"?iv[e]||"transparent":sv[e]||"transparent",c=a?'<button class="eq" disabled>EM USO</button>':r?`<button data-eq="${e}">USAR</button>`:`<button data-buy="${e}" ${z.coins<s?"disabled":""}>COMPRAR ${s}</button>`;return`<div class="item panel"><span class="sw" style="background:${o}"></span><div><h4>${i}</h4><small>${r?a?"equipado no "+n.name:"seu":s+" ossos de ouro"}</small></div>${c}</div>`}).join(""),Tr()}_t("shopTabs").addEventListener("click",n=>{let t=n.target.closest("button[data-c]");t&&(Rn=t.dataset.c,zh())});_t("shopList").addEventListener("click",n=>{let t=n.target.closest("button");if(!t||t.disabled)return;let e=Fe[z.dog],i=hc(e);if(t.dataset.buy){let s=Es[Rn].items.find(r=>r[0]===t.dataset.buy);if(z.coins<s[2])return;z.coins-=s[2],z.owned.push(Rn+":"+s[0]),Vn("bought"),Dt.init(),Dt.pickup(),Ln(30),i[Rn]=s[0]}else t.dataset.eq&&(i[Rn]=t.dataset.eq,Dt.init(),Dt.beep(!1));z.looks[e.id]=i,rn(),We&&uc(We,i),Ea(),zh()});function eM(){Gt="missions",ye("menu",!1),ye("missions",!0),Qd(),qd(),Tr()}function qd(){Gh(),document.querySelectorAll("#missTabs button").forEach(s=>s.classList.toggle("on",s.dataset.t===$o));let n=new Date,t=new Date(n);t.setHours(24,0,0,0);let e=Math.floor((t-n)/36e5),i=Math.floor((t-n)/6e4)%60;_t("dailyTag").textContent=$o==="daily"?`NOVAS MISS\xD5ES EM ${e}H ${i}MIN`:`${z.ach.length} DE ${vh.length} CONQUISTAS`,$o==="daily"?_t("missList").innerHTML=z.daily.ids.map(s=>{let r=sc.find(c=>c.id===s),a=Math.min(jd(r),r.n),o=z.daily.claimed.includes(s);return`<div class="item panel ${o?"done":""}"><span class="sw" style="background:${o?"var(--good)":"transparent"}"></span><div><h4>${r.txt}</h4><div class="bar2"><i style="width:${a/r.n*100}%"></i></div><small>${a}/${r.n}</small></div><span class="rw">${o?"RECEBIDO":"+"+_h}</span></div>`}).join("")+`<div class="item panel ${z.daily.bonus?"done":""}"><span class="sw" style="background:${z.daily.bonus?"var(--good)":"transparent"}"></span><div><h4>B\xF4nus: complete as 3 miss\xF5es</h4><small>${z.daily.claimed.length}/3</small></div><span class="rw">${z.daily.bonus?"RECEBIDO":"+"+yh}</span></div>`:_t("missList").innerHTML=vh.map(s=>{let r=z.ach.includes(s.id),a=Math.min(s.v(),s.g);return`<div class="item panel ${r?"done":""}"><span class="sw" style="background:${r?"var(--gold)":"transparent"}"></span><div><h4>${s.n}</h4><small>${s.d}${r?"":" \xB7 "+a+"/"+s.g}</small>${r?"":`<div class="bar2"><i style="width:${a/s.g*100}%"></i></div>`}</div><span class="rw">${r?"\u2713":"+"+s.r}</span></div>`}).join("")}_t("missTabs").addEventListener("click",n=>{let t=n.target.closest("button[data-t]");t&&($o=t.dataset.t,qd())});function ic(){Gt==="results"&&(Bh(),mc()),Gt="garage",["menu","results"].forEach(n=>ye(n,!1)),ye("garage",!0),$d()}function Bh(){Wd(),me.forEach(n=>n.dispose()),me=[],ot=null,Od()}function Zd(n){z.track=n,rn(),ye("loading",!0),requestAnimationFrame(()=>requestAnimationFrame(()=>{Uh(z.track),fn=null,mc(),wr(),ye("loading",!1)}))}function ws(){Dt.init(),Bh(),We&&(nn.remove(We.root),yr(We.root),We=null),fn&&(Re.remove(fn),yr(fn),fn=null),pe.clearViewOffset();let n=pc(Fe[z.dog]),t=Object.values(n).reduce((r,a)=>r+a,0)/5,e=oe?[z.dog,...oe.rivals]:[z.dog,...Fe.map((r,a)=>a).filter(r=>r!==z.dog).sort(()=>Math.random()-.5).slice(0,5)],i=[5,...[0,1,2,3,4].sort(()=>Math.random()-.5)];e.forEach((r,a)=>{let o=Fe[r],c=n;if(a){let d=()=>he(Math.round(t+qi[z.diff].upOff+(Math.random()*2-1)),0,5);c={motor:d(),acel:d(),grip:d(),nitro:d(),pulo:d()}}let l=new dh(o,a+1,a===0,c),h=i[a],u=Math.floor(h/2),f=h%2;l.place(-5-u*6.5-f*2.5,f?3.6:-3.6),oe&&a&&oe.looks[o.id]&&(l.look=oe.looks[o.id],uc(l.D,l.look)),l.lane=l.d,me.push(l),a||(ot=l)}),$i.forEach(r=>{r.fall=0,r.bar.rotation.x=0,r.bar.position.y=.95}),_r.forEach(r=>{r.cd=0,r.g.visible=!0}),_a.forEach(r=>{r.cd=0,r.g.visible=!0}),ma.forEach(r=>{r.taken=!1,r.g.visible=!0}),Zo=null,ca=5,Mh=!1,ac=0,rc=0,_t("narr").classList.remove("on"),_t("cupTag").textContent=oe?`COPA \xB7 CORRIDA ${oe.idx+1}/${oe.tracks.length}`:"",Wd(),ci.clear(),In.clear(),Od(),iM(),_t("goals").classList.remove("mini"),Wn=0,pa=4,xh=4,Ri=0,Gt="countdown",me.forEach(da),pe.fov=64,gh(ot,.016,!0),["menu","results","pause","garage"].forEach(r=>ye(r,!1)),ye("hud",!0),ye("lights",!0),Ma&&ye("touch",!0),_t("lapT").textContent=z.laps,_t("posOf").textContent="DE "+me.length,_t("lights").querySelectorAll("span").forEach(r=>r.className=""),hh(0,!1);let s=z.best[At.id+"_"+z.laps];_t("bestLap").textContent=s?"RECORDE "+Er(s):"",xa=.6}var nM=[{id:"mini",txt:"Fa\xE7a 3 mini-turbos no drift",n:3,v:n=>n.minis},{id:"scare",txt:"Espante 2 bichos com o latido",n:2,v:n=>n.scared},{id:"jumps",txt:"Pule 3 barreiras sem trope\xE7ar",n:3,v:n=>n.cleanJumps},{id:"coins",txt:"Pegue 10 ossos de ouro",n:10,v:n=>n.coins},{id:"cans",txt:"Pegue 3 latas de nitro",n:3,v:n=>n.cans},{id:"missile",txt:"Acerte 2 m\xEDsseis nos rivais",n:2,v:n=>n.missHits},{id:"clean",txt:"Termine sem trope\xE7ar nem ser atingido",final:!0,ok:(n,t)=>n.finished&&n.hits===0,bad:n=>n.hits>0},{id:"podium",txt:"Termine no p\xF3dio",final:!0,ok:(n,t)=>n.finished&&t<=3}],Hh=120,ai=[],qo=0;function iM(){ai=nM.slice().sort(()=>Math.random()-.5).slice(0,3).map(n=>({g:n,done:!1})),qo=9,kh()}function Jd(n,t){let e=n.g,i=n.done?"\u2713":"",s="";return e.final?e.bad&&e.bad(ot)&&(i="\u2717"):s=`${Math.min(e.v(ot),e.n)}/${e.n}`,`<div class="${n.done?"ok":i==="\u2717"?"no":""}"><i>${i}</i><span>${e.txt}</span><b>${n.done?"+"+Hh:s}</b></div>`}function kh(){let n=ai.map(e=>Jd(e)).join(""),t=ai.filter(e=>e.done).length;_t("goals").innerHTML=`<div class="gh">DESAFIOS <b>${t}/${ai.length}</b></div>`+n,_t("pauseGoals").innerHTML=`<div class="gh">DESAFIOS <b>${t}/${ai.length}</b></div>`+n}function Kd(n){let t=!1;for(let i of ai)i.done||i.g.final||i.g.v(ot)>=i.g.n&&(i.done=!0,t=!0,be(`DESAFIO CUMPRIDO! +${Hh}`,"g"),Dt.lap(),qo=4);qo-=n;let e=qo>0;_t("goals").classList.toggle("mini",!e),(t||Math.random()<n*4)&&kh()}function yn(n){return z.stats[n]||0}function Vn(n,t=1){z.stats[n]=(z.stats[n]||0)+t}var sc=[{id:"win",txt:"Ven\xE7a 1 corrida",n:1,stat:"wins"},{id:"podium",txt:"Chegue ao p\xF3dio 2 vezes",n:2,stat:"podiums"},{id:"races",txt:"Complete 3 corridas",n:3,stat:"races"},{id:"minis",txt:"Fa\xE7a 8 mini-turbos",n:8,stat:"minis"},{id:"missiles",txt:"Acerte 4 m\xEDsseis",n:4,stat:"missHits"},{id:"birds",txt:"Espante 4 bichos voadores",n:4,stat:"scared"},{id:"coins",txt:"Pegue 25 ossos de ouro na pista",n:25,stat:"coins"},{id:"jumps",txt:"Pule 8 barreiras sem trope\xE7ar",n:8,stat:"cleanJumps"},{id:"cans",txt:"Pegue 6 latas de nitro",n:6,stat:"cans"}],_h=250,yh=300;function sM(){let n=new Date;return`${n.getFullYear()}-${n.getMonth()+1}-${n.getDate()}`}function Gh(){let n=sM();if(z.daily&&z.daily.date===n)return;let t=7;for(let r of n)t=t*31+r.charCodeAt(0)>>>0;let e=sc.slice();for(let r=e.length-1;r>0;r--){t=t*1103515245+12345>>>0;let a=t%(r+1);[e[r],e[a]]=[e[a],e[r]]}let i=e.slice(0,3).map(r=>r.id),s={};i.forEach(r=>{let a=sc.find(o=>o.id===r);s[a.stat]=yn(a.stat)}),z.daily={date:n,ids:i,base:s,claimed:[],bonus:!1},rn()}function jd(n){return Math.max(0,yn(n.stat)-(z.daily.base[n.stat]||0))}function Qd(){Gh();let n=[];for(let t of z.daily.ids){let e=sc.find(i=>i.id===t);!z.daily.claimed.includes(t)&&jd(e)>=e.n&&(z.daily.claimed.push(t),z.coins+=_h,n.push([`Miss\xE3o di\xE1ria: ${e.txt}`,_h]))}return!z.daily.bonus&&z.daily.claimed.length===z.daily.ids.length&&(z.daily.bonus=!0,z.coins+=yh,n.push(["Todas as miss\xF5es do dia",yh])),n}var vh=[{id:"first",n:"Primeira corrida",d:"Complete uma corrida",v:()=>yn("races"),g:1,r:100},{id:"win1",n:"Primeira vit\xF3ria",d:"Ven\xE7a uma corrida",v:()=>yn("wins"),g:1,r:200},{id:"win10",n:"Campe\xE3o de verdade",d:"Ven\xE7a 10 corridas",v:()=>yn("wins"),g:10,r:800},{id:"podium10",n:"Fregu\xEAs do p\xF3dio",d:"Chegue ao p\xF3dio 10 vezes",v:()=>yn("podiums"),g:10,r:400},{id:"minis50",n:"Rei do drift",d:"Fa\xE7a 50 mini-turbos",v:()=>yn("minis"),g:50,r:500},{id:"miss20",n:"Mira de \xE1guia",d:"Acerte 20 m\xEDsseis",v:()=>yn("missHits"),g:20,r:500},{id:"birds30",n:"Espantalho",d:"Espante 30 bichos voadores",v:()=>yn("scared"),g:30,r:500},{id:"coins200",n:"Garimpeiro",d:"Pegue 200 ossos de ouro na pista",v:()=>yn("coins"),g:200,r:500},{id:"jumps50",n:"Saltador",d:"Pule 50 barreiras sem trope\xE7ar",v:()=>yn("cleanJumps"),g:50,r:400},{id:"cup1",n:"Ta\xE7a na estante",d:"Ven\xE7a um campeonato",v:()=>yn("cups"),g:1,r:1e3},{id:"cupHard",n:"Lenda das pistas",d:"Ven\xE7a um campeonato no dif\xEDcil",v:()=>yn("cupsHard"),g:1,r:2e3},{id:"tracks",n:"Turista",d:"Ven\xE7a nas 3 pistas",v:()=>(z.stats.tracksWon||[]).length,g:3,r:600},{id:"zoo",n:"Zool\xF3gico completo",d:"Ven\xE7a com 6 corredores diferentes",v:()=>(z.stats.breedsWon||[]).length,g:6,r:1200},{id:"style",n:"Estiloso",d:"Compre 5 itens na loja",v:()=>yn("bought"),g:5,r:300},{id:"tuned",n:"Tunado",d:"Deixe uma melhoria no n\xEDvel m\xE1ximo",v:()=>yn("maxUp"),g:1,r:300}];function Ea(n){let t=[];for(let e of vh)z.ach.includes(e.id)||e.v()<e.g||(z.ach.push(e.id),z.coins+=e.r,t.push([`Conquista: ${e.n}`,e.r]),n||be(`CONQUISTA: ${e.n.toUpperCase()}! +${e.r}`,"g"));return t.length&&rn(),t}function rM(n){let t=ot,e=z.stats;Vn("races"),n===1&&Vn("wins"),n<=3&&Vn("podiums"),Vn("minis",t.minis),Vn("missHits",t.missHits),Vn("scared",t.scared),Vn("coins",t.coins),Vn("cleanJumps",t.cleanJumps),Vn("cans",t.cans),n===1&&(e.tracksWon=e.tracksWon||[],e.tracksWon.includes(At.id)||e.tracksWon.push(At.id),e.breedsWon=e.breedsWon||[],e.breedsWon.includes(t.b.id)||e.breedsWon.push(t.b.id))}var aM=[10,7,5,3,2,1],oM=[1e3,600,400,0,0,0],oe=null;function cM(){Dt.init();let n=Fe.map((t,e)=>e).filter(t=>t!==z.dog).sort(()=>Math.random()-.5).slice(0,5);oe={idx:0,tracks:[0,1,2],rivals:n,pts:{},looks:{}},n.forEach(t=>oe.looks[Fe[t].id]=Id()),tp(0,ws)}function tp(n,t){ye("loading",!0),requestAnimationFrame(()=>requestAnimationFrame(()=>{z.track=n,rn(),Uh(n),fn=null,ye("loading",!1),t()}))}function ep(n){return[Fe[z.dog].id,...oe.rivals.map(i=>Fe[i].id)].map(i=>({b:Fe.find(s=>s.id===i),p:oe.pts[i]||0})).sort((i,s)=>s.p-i.p).map((i,s)=>`<tr class="${i.b.id===Fe[z.dog].id?"me":""}"><td class="disp">${s+1}\xBA</td><td><i style="background:${i.b.color}"></i></td><td>${i.b.name}${i.b.id===Fe[z.dog].id?" \xB7 VOC\xCA":""}</td><td class="mono">${i.p} pts</td></tr>`).join("")}function lM(n){let t=["#ffc53d","#d7dde6","#cd7f32"][n-1]||"#555b66",e=["#b8860b","#9aa3ae","#8b5a2b"][n-1]||"#333";return`<svg viewBox="0 0 120 140" role="img" aria-label="trof\xE9u"><path fill="${e}" d="M22 20h-14c0 22 10 34 26 36l2-8c-9-2-14-11-14-20zm76 0h14c0 22-10 34-26 36l-2-8c9-2 14-11 14-20z"/>
    <path fill="${t}" d="M24 10h72v26c0 24-16 40-36 42-20-2-36-18-36-42z"/><rect x="52" y="76" width="16" height="22" fill="${e}"/>
    <rect x="34" y="96" width="52" height="12" rx="3" fill="${t}"/><rect x="26" y="108" width="68" height="18" rx="4" fill="${e}"/>
    <text x="60" y="52" text-anchor="middle" font-family="Russo One, Arial Black, sans-serif" font-size="26" fill="${e}">${n<=3?n+"\xBA":""}</text></svg>`}function hM(){let e=[Fe[z.dog].id,...oe.rivals.map(a=>Fe[a].id)].map(a=>({id:a,p:oe.pts[a]||0})).sort((a,o)=>o.p-a.p).findIndex(a=>a.id===Fe[z.dog].id)+1,i=Math.round(oM[e-1]*qi[z.diff].reward);z.coins+=i,e===1&&(Vn("cups"),z.diff===2&&Vn("cupsHard"));let s=z.trophies[z.diff];(!s||e<s)&&(z.trophies[z.diff]=e);let r=Ea(!0);rn(),Tr(),_t("cupTitle").textContent=e===1?"CAMPE\xC3O DA COPA!":e<=3?`${e}\xBA LUGAR NA COPA`:`${e}\xBA LUGAR`,_t("trophy").innerHTML=lM(e),_t("cupTable").innerHTML=ep(),_t("cupReward").innerHTML=(i?`PR\xCAMIO DA COPA +${i}`:"SEM PR\xCAMIO DESTA VEZ")+r.map(([a,o])=>`<br>${a.toUpperCase()} +${o}`).join(""),ye("results",!1),ye("cupEnd",!0),e===1&&(Dt.fanfare(),Ln([60,40,60,40,140]))}function np(){oe=null,ye("cupEnd",!1),oi()}function Vh(){return me.slice().sort((n,t)=>n.finished&&t.finished?n.finishTime-t.finishTime:n.finished?-1:t.finished?1:t.dist-n.dist)}function uM(){let n=Vh().indexOf(ot)+1;Gt="finished",Ri=0,Dt.fanfare(),xa=1.3,Fh(n===1?"VIT\xD3RIA!":"CHEGADA!",3800,`${n}\xBA LUGAR \xB7 ${Er(ot.finishTime)}`),setTimeout(()=>ot&&Dt.voice(ot.b),700)}function ip(){Gt="results",_t("big").innerHTML="",["hud","touch","lights"].forEach(d=>ye(d,!1)),Wh(0,0),["wind","skid","nitro"].forEach(d=>Dt.setLoop(d,0));let n=Vh(),t=n.indexOf(ot)+1;_t("resTitle").textContent=t===1?"CAMPE\xC3O!":t<=3?"P\xD3DIO!":`${t}\xBA LUGAR`,_t("resTable").innerHTML=n.map((d,p)=>`<tr class="${d===ot?"me":""}"><td class="disp">${p+1}\xBA</td><td><i style="background:${d.b.color}"></i></td><td>${d.b.name}${d===ot?" \xB7 VOC\xCA":""}</td><td class="mono">${d.finished?Er(d.finishTime):"\u2014"}</td></tr>`).join("");let e={1:.5,3:1,5:1.5,7:2}[z.laps]||1,i=Math.round([500,350,250,180,130,100][t-1]*e*qi[z.diff].reward),s=ot.coins*15,r=Math.round(ot.driftScore/20);for(let d of ai)d.g.final&&!d.done&&(d.done=d.g.ok(ot,t));let a=ai.filter(d=>d.done).length,o=a*Hh;kh(),rM(t);let c=[...Qd(),...Ea(!0)],l=c.reduce((d,p)=>d+p[1],0),h=i+s+r+o+l;z.coins+=h-l,t===1&&Ln([60,40,60,40,120]),oe&&(n.forEach((d,p)=>{oe.pts[d.b.id]=(oe.pts[d.b.id]||0)+aM[p]}),_t("cupMid").innerHTML=`<tr><td colspan="4" class="lbl">COPA \xB7 CORRIDA ${oe.idx+1} DE ${oe.tracks.length}</td></tr>`+ep()),ye("cupPanel",!!oe),_t("resAgain").textContent=oe?oe.idx<oe.tracks.length-1?"PR\xD3XIMA PISTA":"VER TROF\xC9U":"DE NOVO",_t("resMenu").textContent=oe?"SAIR DA COPA":"MENU",ye("resGarage",!oe),_t("rewards").innerHTML=`<div><span>${t}\xBA lugar</span><b>+${i}</b></div><div><span>Ossos de ouro \xD7 ${ot.coins}</span><b>+${s}</b></div><div><span>Drift (${ot.driftScore} pts)</span><b>+${r}</b></div><div><span>Desafios ${a}/${ai.length}</span><b>+${o}</b></div>`+c.map(([d,p])=>`<div><span>${d}</span><b>+${p}</b></div>`).join("")+`<div class="goalsRes">${ai.map(d=>Jd(d)).join("")}</div><div class="tot"><span>TOTAL</span><b class="disp">+${h}</b></div>`;let u=At.id+"_"+z.laps,f=z.best[u];ot.finished&&(!f||ot.finishTime<f)?(z.best[u]=ot.finishTime,_t("recordMsg").textContent="NOVO RECORDE DA PISTA!"):_t("recordMsg").textContent=f?"RECORDE "+Er(f):"",rn(),Tr(),ye("results",!0)}function Sr(n){n&&(Gt==="race"||Gt==="countdown"||Gt==="finished")?(ud=Gt,Gt="paused",ye("pause",!0),Rs(),Pn.volume=.25,Dt.ctx&&["wind","skid","nitro"].forEach(t=>Dt.setLoop(t,0))):!n&&Gt==="paused"&&(Gt=ud,ye("pause",!1),Pn.volume=.6)}function Rs(){_t("camBtn").textContent="C\xC2MERA: "+Oh[z.cam],_t("assistBtn").textContent="ASSIST\xCANCIA: "+(z.assist?"LIGADA":"DESLIGADA"),_t("qualBtn").textContent="GR\xC1FICOS: "+Sh[z.qual].n,_t("vibBtn").textContent="VIBRA\xC7\xC3O: "+(z.vib?"LIGADA":"DESLIGADA"),_t("musicBtn").textContent="M\xDASICA: "+zd[z.musicMode]}var fM=_t("map").getContext("2d");function dM(){let n=_t("map"),t=Math.min(devicePixelRatio,2),e=Math.round(n.clientWidth*t);n.width!==e&&(n.width=n.height=e);let i=fM;i.setTransform(1,0,0,1,0,0),i.clearRect(0,0,e,e),i.save(),i.scale(e/256,e/256),i.drawImage(lh.canvas,0,0);for(let s of me.slice().sort(r=>r.isPlayer?1:-1)){let[r,a]=lh.f(s.x,s.z),o=s.isPlayer?9:7;i.beginPath(),i.arc(r,a,o,0,7),i.fillStyle="#000",i.fill(),i.beginPath(),i.arc(r,a,o-2.5,0,7),i.fillStyle=s.isPlayer?"#ffffff":s.b.color,i.fill()}i.restore()}var pM=_t("gauge").getContext("2d");function mM(){let n=_t("gauge"),t=Math.min(devicePixelRatio,2),e=Math.round(n.clientWidth*t);n.width!==e&&(n.width=n.height=e);let i=pM;i.setTransform(1,0,0,1,0,0),i.clearRect(0,0,e,e),i.save(),i.scale(e/220,e/220);let s=110,r=112,a=Math.PI*.75,o=Math.PI*2.25;i.fillStyle="rgba(10,14,24,.62)",i.beginPath(),i.arc(s,r,104,0,7),i.fill(),i.strokeStyle="rgba(255,255,255,.16)",i.lineWidth=1,i.stroke();let c=Math.abs(ot.speed)*kv,l=he(c/180,0,1);for(let u=0;u<=9;u++){let f=a+(o-a)*u/9,d=u%3?88:84;i.strokeStyle=u/9<=l?"#fff":"rgba(255,255,255,.35)",i.lineWidth=u%3?2:3,i.beginPath(),i.moveTo(s+Math.cos(f)*94,r+Math.sin(f)*94),i.lineTo(s+Math.cos(f)*d,r+Math.sin(f)*d),i.stroke()}i.lineCap="round",i.lineWidth=10,i.strokeStyle="rgba(255,255,255,.1)",i.beginPath(),i.arc(s,r,76,a,o),i.stroke();let h=i.createLinearGradient(20,0,200,0);h.addColorStop(0,"#ffffff"),h.addColorStop(.7,"#ffb36b"),h.addColorStop(1,"#ff4d1a"),i.strokeStyle=h,i.beginPath(),i.arc(s,r,76,a,a+(o-a)*Math.max(.001,l)),i.stroke(),i.lineWidth=7,i.strokeStyle="rgba(255,255,255,.1)",i.beginPath(),i.arc(s,r,61,a,o),i.stroke(),i.strokeStyle=ot.nitroOn?"#35d0ff":"#ff7a1a",i.beginPath(),i.arc(s,r,61,a,a+(o-a)*Math.max(.001,ot.nitro/100)),i.stroke(),i.fillStyle="#fff",i.textAlign="center",i.font='46px "Russo One", sans-serif',i.fillText(Math.round(c),s,r+12),i.font="700 14px Rajdhani, sans-serif",i.fillStyle="#9aa7bf",i.fillText("KM/H",s,r+32),i.fillStyle=ot.nitro>99?"#35d0ff":"#ff9a4d",i.fillText(`NITRO ${Math.round(ot.nitro)}%`,s,r+52);for(let u=0;u<3;u++){let f=s-24+u*24,d=r+66;i.fillStyle=u<ot.ammo?"#ff4d5e":"rgba(255,255,255,.15)",i.beginPath(),i.moveTo(f,d-9),i.lineTo(f+5,d-3),i.lineTo(f+5,d+8),i.lineTo(f-5,d+8),i.lineTo(f-5,d-3),i.closePath(),i.fill()}if(ot.drifting){let u=ot.driftT>2?2:ot.driftT>.9?1:0;i.fillStyle=["#ffd97a","#35d0ff","#ff5ae0"][u],i.font='17px "Russo One", sans-serif',i.fillText("DRIFT",s,r-34)}else ot.barkCD<=0&&(i.fillStyle="#ffc53d",i.font="700 13px Rajdhani, sans-serif",i.fillText("LATIDO PRONTO",s,r-34));i.restore()}var dd="",rc=0,ac=0,Zo=null,ca=0,Mh=!1;function Yi(n,t){if(!ot||ac>0&&!t)return;let e=_t("narr");e.textContent=n,e.classList.add("on"),rc=2.6,ac=t?1.2:2.4}function gM(n,t){if(rc-=t,ac-=t,rc<=0&&_t("narr").classList.remove("on"),Gt!=="race"||Wn<3){Zo=n[0],ca=n.indexOf(ot);return}let e=n[0],i=n.indexOf(ot);e!==Zo&&!e.finished?e.isPlayer?Yi("VOC\xCA EST\xC1 NA LIDERAN\xC7A!",!0):Yi(`${e.b.name} ASSUMIU A LIDERAN\xC7A!`,!0):i<ca&&n[i+1]?Yi(`VOC\xCA ULTRAPASSOU ${n[i+1].b.name}!`):i>ca&&n[i-1]&&!n[i-1].finished&&Yi(`${n[i-1].b.name} ULTRAPASSOU VOC\xCA!`),!Mh&&e.finished&&(Mh=!0,e.isPlayer||Yi(`${e.b.name} VENCEU A CORRIDA!`,!0)),Zo=e,ca=i}function pd(n){let t=Vh(),e=t.indexOf(ot)+1;_t("lap").textContent=ot.lap,_t("time").textContent=Er(Gt==="finished"?ot.finishTime:Wn),_t("pos").innerHTML=e+"<sup>\xBA</sup>";let i=t.map((r,a)=>`<li class="${r.isPlayer?"me":""}"><span class="n">${a+1}</span><i style="background:${r.b.color}"></i>${r.b.name}</li>`).join("");i!==dd&&(_t("board").innerHTML=i,dd=i),gM(t,n),_t("chipSlip").hidden=!(ot.slip>.5);let s=Qn[ot.idx].x*Math.sin(ot.h)+Qn[ot.idx].z*Math.cos(ot.h)<-.3&&Math.hypot(ot.vx,ot.vz)>3;ot.wrongT=s?ot.wrongT+n:0,_t("chipWrong").hidden=ot.wrongT<1,ot.lockT-=n,_t("chipMissile").hidden=!(ot.lockT>0),ot.lockT>0&&Math.random()<n*6&&Dt.lockon(),_t("tMn").textContent=ot.ammo,dM(),mM()}var md=_t("fx"),xM=_t("vig");function Wh(n,t){md.style.opacity=n,xM.style.opacity=t,n>0&&(md.style.transform=`rotate(${Math.random()*6}deg)`)}var ya={},va={left:!1,right:!1,brake:!1,drift:!1,nitro:!1,jump:!1,bark:!1,fire:!1};addEventListener("keydown",n=>{["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space","Enter"].includes(n.code)&&n.preventDefault(),ya[n.code]=!0,!n.repeat&&(Dt.init(),Gt==="menu"?((n.code==="ArrowLeft"||n.code==="KeyA")&&oc(-1),(n.code==="ArrowRight"||n.code==="KeyD")&&oc(1),(n.code==="Enter"||n.code==="Space")&&ws(),n.code==="KeyG"&&ic(),n.code==="KeyT"&&Zd((z.track+1)%As.length)):Gt==="garage"||Gt==="shop"||Gt==="missions"?(n.code==="Escape"||n.code==="Enter")&&oi():Gt==="results"?_t("cupEnd").hidden?((n.code==="Enter"||n.code==="Space")&&sp(),n.code==="Escape"&&(oe=null,oi()),n.code==="KeyG"&&!oe&&ic()):["Enter","Space","Escape"].includes(n.code)&&np():Gt==="paused"?((n.code==="Escape"||n.code==="KeyP")&&Sr(!1),n.code==="KeyQ"&&oi()):(Gt==="race"||Gt==="countdown"||Gt==="finished")&&(n.code==="Escape"||n.code==="KeyP")&&Sr(!0),n.code==="KeyC"&&(z.cam=(z.cam+1)%Oh.length,rn()),n.code==="KeyM"&&(Bd(),Gt==="paused"&&Rs()))});addEventListener("keyup",n=>{ya[n.code]=!1});addEventListener("blur",()=>{for(let n in ya)ya[n]=!1;for(let n in va)va[n]=!1;Sr(!0)});document.addEventListener("visibilitychange",()=>{document.hidden&&Sr(!0)});function Zi(n,t){let e=_t(n),i=r=>{r.preventDefault(),Dt.init(),va[t]=!0,e.classList.add("on");try{e.setPointerCapture(r.pointerId)}catch{}},s=r=>{r.preventDefault(),va[t]=!1,e.classList.remove("on")};e.addEventListener("pointerdown",i),e.addEventListener("pointerup",s),e.addEventListener("pointercancel",s),e.addEventListener("contextmenu",r=>r.preventDefault())}Zi("tL","left");Zi("tR","right");Zi("tS","brake");Zi("tD","drift");Zi("tN","nitro");Zi("tJ","jump");Zi("tB","bark");Zi("tM","fire");var Te=(n,t)=>_t(n).addEventListener("click",e=>{e.stopPropagation(),e.currentTarget.blur(),Dt.init(),t()});function oc(n){z.dog=(z.dog+n+Fe.length)%Fe.length,rn(),mc(),wr(),Dt.voice(Fe[z.dog],.8)}Te("prevDog",()=>oc(-1));Te("nextDog",()=>oc(1));Te("trackBtn",()=>Zd((z.track+1)%As.length));Te("diffBtn",()=>{z.diff=(z.diff+1)%qi.length,rn(),wr(),Dt.beep(!1)});Te("lapsBtn",()=>{z.laps=z.laps>=7?1:z.laps+2,rn(),wr(),Dt.beep(!1)});Te("garageBtn",ic);Te("garageBack",oi);Te("startBtn",()=>z.mode?cM():ws());Te("modeBtn",()=>{z.mode=1-z.mode,rn(),wr(),Dt.beep(!1)});Te("shopBtn",tM);Te("shopBack",()=>{Ea(),oi()});Te("missBtn",eM);Te("missBack",oi);Te("pauseBtn",()=>Sr(!0));Te("resumeBtn",()=>Sr(!1));Te("restartBtn",()=>{ye("pause",!1),ws()});Te("quitBtn",()=>{oe=null,oi()});Te("vibBtn",()=>{z.vib=!z.vib,rn(),Rs(),Ln(40)});Te("camBtn",()=>{z.cam=(z.cam+1)%Oh.length,rn(),Rs()});Te("assistBtn",()=>{z.assist=!z.assist,rn(),Rs()});Te("qualBtn",()=>{z.qual=(z.qual+1)%Sh.length,rn(),yd(),Rs()});Te("musicBtn",()=>{Bd(),Rs()});Te("resAgain",sp);function sp(){if(!oe)return ws();oe.idx<oe.tracks.length-1?(oe.idx++,tp(oe.tracks[oe.idx],ws)):hM()}Te("resMenu",()=>{oe=null,oi()});Te("cupDone",np);Te("resGarage",ic);function gd(){let n=ya,t=va,e=n.ArrowLeft||n.KeyA||t.left,i=n.ArrowRight||n.KeyD||t.right,s=!!(n.ArrowDown||n.KeyS||t.brake);return{throttle:n.ArrowUp||n.KeyW||Ma&&!s?1:0,brake:s,steer:(i?1:0)-(e?1:0),drift:!!(n.ShiftLeft||n.ShiftRight||t.drift),nitro:!!(n.KeyN||n.ControlLeft||n.ControlRight||t.nitro),jump:!!(n.Space||t.jump),bark:!!(n.KeyB||n.KeyE||t.bark),fire:!!(n.KeyF||n.KeyX||t.fire)}}var _M=new Fo;function rp(){requestAnimationFrame(rp);let n=Math.min(_M.getDelta(),.05);if(Cn+=n,Gt!=="paused"){for(let e of Dh)e.position.x+=n*2,e.position.x>950&&(e.position.x=-950);for(let e of _a)e.g.rotation.y+=n*1.5,e.g.position.y=1.1+Math.sin(Cn*3+e.s)*.12,e.cd>0&&(e.cd-=n,e.cd<=0&&(e.g.visible=!0));for(let e of _r)e.g.rotation.y+=n*2,e.g.position.y=1.3+Math.sin(Cn*3+e.s)*.15,e.cd>0&&(e.cd-=n,e.cd<=0&&(e.g.visible=!0));for(let e of ma)e.g.rotation.y+=n*3;for(let e of $i)if(e.fall>0){e.fall=Math.max(0,e.fall-n*.5);let i=It(0,.25,1-e.fall)*(e.fall>.1?1:e.fall*10);e.bar.rotation.x=i*1.4,e.bar.position.y=.95-i*.8}if(ua&&(ua.offset.y-=n*1.5),Nh(Cn),Nd(n,Gt==="race"),(Gt==="race"||Gt==="finished"||Gt==="results")&&Yd(n),xr&&(xr.offset.x+=n*.01,xr.offset.y+=n*.006),Tv(Cn),xa=ke(xa,.35,n*.25),ci.update(n),In.update(n),Ai){let e=Ai.geometry.attributes.position,i=e.array,s=pe.position;for(let r=0;r<i.length;r+=3)i[r+1]-=n*(3+r%7*.3),i[r]+=Math.sin(Cn+r)*n*.5,i[r+1]<s.y-15&&(i[r+1]+=40),i[r]<s.x-60&&(i[r]+=120),i[r]>s.x+60&&(i[r]-=120),i[r+2]<s.z-60&&(i[r+2]+=120),i[r+2]>s.z+60&&(i[r+2]-=120);e.needsUpdate=!0}}if(Gt==="menu"||Gt==="garage"||Gt==="shop"||Gt==="missions"){if(dr+=n*.35,We&&fn){fn.rotation.y+=n*.4,We.root.rotation.y=fn.rotation.y,We.anim(We,{v:0,y:0,vy:0,phase:0,yawRate:0,stun:0,spook:0,nitro:!1,idle:!0},Cn);let e=We.root.position,i=innerWidth,s=innerHeight,r=s>i*1.05,a=r?8.2:6.4;pe.position.set(e.x+Math.cos(dr*.4)*a,2.4,e.z+Math.sin(dr*.4)*a),pe.lookAt(e.x,1.1,e.z),pe.fov=50,r?pe.setViewOffset(i,s,0,s*.14,i,s):i>820?pe.setViewOffset(i,s,Math.min(220,i*.18),0,i,s):pe.clearViewOffset(),pe.updateProjectionMatrix()}}else if(Gt==="countdown"){pa-=n;let e=Math.ceil(pa-1);if(!Ma){let i=gd();i.throttle&&ot.pressT===null&&(ot.pressT=pa),i.throttle||(ot.pressT=null)}if(e!==xh){xh=e;let i=_t("lights").querySelectorAll("span");e>0&&e<=3&&(i[3-e].className="r",hh(4-e,!1),Dt.beep(!1)),e<=0&&(i.forEach(s=>s.className="g"),hh(3,!0),Dt.beep(!0),Fh("VAI!",900),Gt="race",setTimeout(()=>ye("lights",!1),900),ot.pressT!==null&&(ot.pressT<=.6?(ot.mini=1.2,be("LARGADA PERFEITA!","v"),Dt.boost(),Ln(40)):ot.pressT>1.4&&(ot.stun=.7,be("QUEIMOU A LARGADA!","r"))),me.forEach(s=>{!s.isPlayer&&Math.random()<.35&&(s.mini=.8)}))}me.forEach(da),gh(ot,n),pd(n)}else if(Gt==="race"||Gt==="finished"){Wn+=n;for(let e of me)ph(e,e.isPlayer&&!e.finished?gd():mh(e,n),n);Gd(n);for(let e of me)da(e),Jv(e,n);if(Gt==="finished"){Ri+=n;let e=ot.D.root.position,i=Ri*.45+ot.h+Math.PI;bi.set(e.x+Math.sin(i)*8,3.2,e.z+Math.cos(i)*8),pe.position.lerp(bi,1-Math.exp(-3*n)),pe.lookAt(e.x,1.3+ot.y,e.z),(Ri>7||Ri>3.5&&me.every(s=>s.finished))&&ip()}else gh(ot,n);if(Gt!=="results"){pd(n),Kd(n);let e=Math.hypot(ot.vx,ot.vz);Wh(ot.nitroOn?.55:ot.pad>0||ot.mini>0?.3:he((e-40)/40,0,.18),ot.nitroOn?1:0),Dt.ctx&&(Dt.setLoop("wind",he(e/60,0,1)*.12,700+e*30),Dt.setLoop("skid",ot.drifting&&!ot.air?.16:ot.surf==="ice"&&Math.abs(ot.slide)>3?.08:0),Dt.setLoop("nitro",ot.nitroOn?.3:0))}}else if(Gt==="results"){for(let i of me)ph(i,mh(i,n),n),da(i);let e=ot.D.root.position;dr+=n*.3,bi.set(e.x+Math.cos(dr)*12,6,e.z+Math.sin(dr)*12),pe.position.lerp(bi,1-Math.exp(-2*n)),pe.lookAt(e.x,1,e.z)}cc.position.copy(pe.position);let t=ot?ot.D.root.position:We?We.root.position:Ye[0];vn.target.position.copy(t),vn.position.copy(t).addScaledVector(rh,150),Xn.render(nn,pe)}yd();Uh(z.track);oi();ye("loading",!1);rp();function yM(n,t){let e=.016666666666666666;for(let i=0;i<n&&(Gt==="race"||Gt==="finished");i+=e){Wn+=e,Cn+=e,Nh(Cn),Nd(e,Gt==="race"),Yd(e);for(let s of me)ph(s,s.isPlayer&&!s.finished?t(ot,Wn):mh(s,e),e);Gd(e),Gt==="race"&&Kd(e),Gt==="finished"&&(Ri+=e,(Ri>7||Ri>3.5&&me.every(s=>s.finished))&&ip())}me.forEach(da)}window.__game={sim:yM,bgm:Pn,debugBall(){let n=vr[0];Nh(n.period-n.off+1.4-n.period*50);let t=Ve(n.s-14,-4,3.5),e=Ve(n.s,0,1);pe.position.copy(t),pe.lookAt(e)},skipCountdown(){pa=.01},get state(){return Gt},get player(){return ot},get runners(){return me},startRace:ws,save:z,renderer:Xn,scene:nn,camera:pe,get L(){return Le}};})();
/*! Bundled license information:

three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2023 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
