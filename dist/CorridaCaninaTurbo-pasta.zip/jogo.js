(()=>{var wl="160";var Ld=0,wh=1,Id=2;var of=1,Al=2,ri=3,Di=0,an=1,ke=2;var Ci=0,Pi=1,Ui=2,Ah=3,Rh=4,Dd=5,qi=100,Ud=101,Nd=102,Ch=103,Ph=104,Od=200,Fd=201,zd=202,Bd=203,Nc=204,Oc=205,Hd=206,kd=207,Gd=208,Vd=209,Wd=210,Xd=211,Yd=212,qd=213,$d=214,Zd=0,Jd=1,Kd=2,qo=3,jd=4,Qd=5,tp=6,ep=7,af=0,np=1,ip=2,Li=0,sp=1,rp=2,op=3,Rl=4,ap=5,cp=6;var cf=300,Ws=301,Xs=302,Fc=303,zc=304,Aa=306,Ir=1e3,Bn=1001,Bc=1002,Ze=1003,Lh=1004;var ec=1005;var wn=1006,lp=1007;var Dr=1008;var Ii=1009,hp=1010,up=1011,Cl=1012,lf=1013,Ai=1014,Ri=1015,Ur=1016,hf=1017,uf=1018,Ji=1020,fp=1021,Hn=1023,dp=1024,pp=1025,Ki=1026,Ys=1027,mp=1028,ff=1029,gp=1030,df=1031,pf=1033,nc=33776,ic=33777,sc=33778,rc=33779,Ih=35840,Dh=35841,Uh=35842,Nh=35843,mf=36196,Oh=37492,Fh=37496,zh=37808,Bh=37809,Hh=37810,kh=37811,Gh=37812,Vh=37813,Wh=37814,Xh=37815,Yh=37816,qh=37817,$h=37818,Zh=37819,Jh=37820,Kh=37821,oc=36492,jh=36494,Qh=36495,xp=36283,tu=36284,eu=36285,nu=36286;var $o=2300,Zo=2301,ac=2302,iu=2400,su=2401,ru=2402;var gf=3e3,ji=3001,_p=3200,yp=3201,xf=0,vp=1,An="",Ce="srgb",ci="srgb-linear",Pl="display-p3",Ra="display-p3-linear",Jo="linear",Ee="srgb",Ko="rec709",jo="p3";var _s=7680;var ou=519,Mp=512,Ep=513,Sp=514,_f=515,bp=516,Tp=517,wp=518,Ap=519,Hc=35044,yf=35048;var au="300 es",kc=1035,ai=2e3,Qo=2001,Ni=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let i=this._listeners;i[t]===void 0&&(i[t]=[]),i[t].indexOf(e)===-1&&i[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let i=this._listeners;return i[t]!==void 0&&i[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let s=this._listeners[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let i=this._listeners[t.type];if(i!==void 0){t.target=this;let s=i.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,t);t.target=null}}},rn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],cu=1234567,Tr=Math.PI/180,Nr=180/Math.PI;function $n(){let n=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(rn[n&255]+rn[n>>8&255]+rn[n>>16&255]+rn[n>>24&255]+"-"+rn[t&255]+rn[t>>8&255]+"-"+rn[t>>16&15|64]+rn[t>>24&255]+"-"+rn[e&63|128]+rn[e>>8&255]+"-"+rn[e>>16&255]+rn[e>>24&255]+rn[i&255]+rn[i>>8&255]+rn[i>>16&255]+rn[i>>24&255]).toLowerCase()}function Qe(n,t,e){return Math.max(t,Math.min(e,n))}function Ll(n,t){return(n%t+t)%t}function Rp(n,t,e,i,s){return i+(n-t)*(s-i)/(e-t)}function Cp(n,t,e){return n!==t?(e-n)/(t-n):0}function wr(n,t,e){return(1-e)*n+e*t}function Pp(n,t,e,i){return wr(n,t,1-Math.exp(-e*i))}function Lp(n,t=1){return t-Math.abs(Ll(n,t*2)-t)}function Ip(n,t,e){return n<=t?0:n>=e?1:(n=(n-t)/(e-t),n*n*(3-2*n))}function Dp(n,t,e){return n<=t?0:n>=e?1:(n=(n-t)/(e-t),n*n*n*(n*(n*6-15)+10))}function Up(n,t){return n+Math.floor(Math.random()*(t-n+1))}function Np(n,t){return n+Math.random()*(t-n)}function Op(n){return n*(.5-Math.random())}function Fp(n){n!==void 0&&(cu=n);let t=cu+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function zp(n){return n*Tr}function Bp(n){return n*Nr}function Gc(n){return(n&n-1)===0&&n!==0}function Hp(n){return Math.pow(2,Math.ceil(Math.log(n)/Math.LN2))}function ta(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function kp(n,t,e,i,s){let r=Math.cos,a=Math.sin,o=r(e/2),c=a(e/2),l=r((t+i)/2),h=a((t+i)/2),u=r((t-i)/2),f=a((t-i)/2),d=r((i-t)/2),p=a((i-t)/2);switch(s){case"XYX":n.set(o*h,c*u,c*f,o*l);break;case"YZY":n.set(c*f,o*h,c*u,o*l);break;case"ZXZ":n.set(c*u,c*f,o*h,o*l);break;case"XZX":n.set(o*h,c*p,c*d,o*l);break;case"YXY":n.set(c*d,o*h,c*p,o*l);break;case"ZYZ":n.set(c*p,c*d,o*h,o*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function qn(n,t){switch(t.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function pe(n,t){switch(t.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}var vf={DEG2RAD:Tr,RAD2DEG:Nr,generateUUID:$n,clamp:Qe,euclideanModulo:Ll,mapLinear:Rp,inverseLerp:Cp,lerp:wr,damp:Pp,pingpong:Lp,smoothstep:Ip,smootherstep:Dp,randInt:Up,randFloat:Np,randFloatSpread:Op,seededRandom:Fp,degToRad:zp,radToDeg:Bp,isPowerOfTwo:Gc,ceilPowerOfTwo:Hp,floorPowerOfTwo:ta,setQuaternionFromProperEuler:kp,normalize:pe,denormalize:qn},ut=class n{constructor(t=0,e=0){n.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,i=this.y,s=t.elements;return this.x=s[0]*e+s[3]*i+s[6],this.y=s[1]*e+s[4]*i+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let i=this.dot(t)/e;return Math.acos(Qe(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,i=this.y-t.y;return e*e+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let i=Math.cos(e),s=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*i-a*s+t.x,this.y=r*s+a*i+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},ie=class n{constructor(t,e,i,s,r,a,o,c,l){n.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,i,s,r,a,o,c,l)}set(t,e,i,s,r,a,o,c,l){let h=this.elements;return h[0]=t,h[1]=s,h[2]=o,h[3]=e,h[4]=r,h[5]=c,h[6]=i,h[7]=a,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],this}extractBasis(t,e,i){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let i=t.elements,s=e.elements,r=this.elements,a=i[0],o=i[3],c=i[6],l=i[1],h=i[4],u=i[7],f=i[2],d=i[5],p=i[8],x=s[0],g=s[3],m=s[6],S=s[1],_=s[4],b=s[7],C=s[2],A=s[5],R=s[8];return r[0]=a*x+o*S+c*C,r[3]=a*g+o*_+c*A,r[6]=a*m+o*b+c*R,r[1]=l*x+h*S+u*C,r[4]=l*g+h*_+u*A,r[7]=l*m+h*b+u*R,r[2]=f*x+d*S+p*C,r[5]=f*g+d*_+p*A,r[8]=f*m+d*b+p*R,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8];return e*a*h-e*o*l-i*r*h+i*o*c+s*r*l-s*a*c}invert(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8],u=h*a-o*l,f=o*c-h*r,d=l*r-a*c,p=e*u+i*f+s*d;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let x=1/p;return t[0]=u*x,t[1]=(s*l-h*i)*x,t[2]=(o*i-s*a)*x,t[3]=f*x,t[4]=(h*e-s*c)*x,t[5]=(s*r-o*e)*x,t[6]=d*x,t[7]=(i*c-l*e)*x,t[8]=(a*e-i*r)*x,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,i,s,r,a,o){let c=Math.cos(r),l=Math.sin(r);return this.set(i*c,i*l,-i*(c*a+l*o)+a+t,-s*l,s*c,-s*(-l*a+c*o)+o+e,0,0,1),this}scale(t,e){return this.premultiply(cc.makeScale(t,e)),this}rotate(t){return this.premultiply(cc.makeRotation(-t)),this}translate(t,e){return this.premultiply(cc.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,i,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,i=t.elements;for(let s=0;s<9;s++)if(e[s]!==i[s])return!1;return!0}fromArray(t,e=0){for(let i=0;i<9;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){let i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t}clone(){return new this.constructor().fromArray(this.elements)}},cc=new ie;function Mf(n){for(let t=n.length-1;t>=0;--t)if(n[t]>=65535)return!0;return!1}function ea(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function Gp(){let n=ea("canvas");return n.style.display="block",n}var lu={};function Ar(n){n in lu||(lu[n]=!0,console.warn(n))}var hu=new ie().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),uu=new ie().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),mo={[ci]:{transfer:Jo,primaries:Ko,toReference:n=>n,fromReference:n=>n},[Ce]:{transfer:Ee,primaries:Ko,toReference:n=>n.convertSRGBToLinear(),fromReference:n=>n.convertLinearToSRGB()},[Ra]:{transfer:Jo,primaries:jo,toReference:n=>n.applyMatrix3(uu),fromReference:n=>n.applyMatrix3(hu)},[Pl]:{transfer:Ee,primaries:jo,toReference:n=>n.convertSRGBToLinear().applyMatrix3(uu),fromReference:n=>n.applyMatrix3(hu).convertLinearToSRGB()}},Vp=new Set([ci,Ra]),me={enabled:!0,_workingColorSpace:ci,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(n){if(!Vp.has(n))throw new Error(`Unsupported working color space, "${n}".`);this._workingColorSpace=n},convert:function(n,t,e){if(this.enabled===!1||t===e||!t||!e)return n;let i=mo[t].toReference,s=mo[e].fromReference;return s(i(n))},fromWorkingColorSpace:function(n,t){return this.convert(n,this._workingColorSpace,t)},toWorkingColorSpace:function(n,t){return this.convert(n,t,this._workingColorSpace)},getPrimaries:function(n){return mo[n].primaries},getTransfer:function(n){return n===An?Jo:mo[n].transfer}};function Gs(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function lc(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}var ys,na=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{ys===void 0&&(ys=ea("canvas")),ys.width=t.width,ys.height=t.height;let i=ys.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),e=ys}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=ea("canvas");e.width=t.width,e.height=t.height;let i=e.getContext("2d");i.drawImage(t,0,0,t.width,t.height);let s=i.getImageData(0,0,t.width,t.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=Gs(r[a]/255)*255;return i.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let i=0;i<e.length;i++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[i]=Math.floor(Gs(e[i]/255)*255):e[i]=Gs(e[i]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},Wp=0,ia=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Wp++}),this.uuid=$n(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let i={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(hc(s[a].image)):r.push(hc(s[a]))}else r=hc(s);i.url=r}return e||(t.images[this.uuid]=i),i}};function hc(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?na.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Xp=0,Rn=class n extends Ni{constructor(t=n.DEFAULT_IMAGE,e=n.DEFAULT_MAPPING,i=Bn,s=Bn,r=wn,a=Dr,o=Hn,c=Ii,l=n.DEFAULT_ANISOTROPY,h=An){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Xp++}),this.uuid=$n(),this.name="",this.source=new ia(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=i,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=c,this.offset=new ut(0,0),this.repeat=new ut(1,1),this.center=new ut(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new ie,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(Ar("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===ji?Ce:An),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),e||(t.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==cf)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Ir:t.x=t.x-Math.floor(t.x);break;case Bn:t.x=t.x<0?0:1;break;case Bc:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Ir:t.y=t.y-Math.floor(t.y);break;case Bn:t.y=t.y<0?0:1;break;case Bc:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return Ar("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===Ce?ji:gf}set encoding(t){Ar("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===ji?Ce:An}};Rn.DEFAULT_IMAGE=null;Rn.DEFAULT_MAPPING=cf;Rn.DEFAULT_ANISOTROPY=1;var Je=class n{constructor(t=0,e=0,i=0,s=1){n.prototype.isVector4=!0,this.x=t,this.y=e,this.z=i,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,i,s){return this.x=t,this.y=e,this.z=i,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,i=this.y,s=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*i+a[8]*s+a[12]*r,this.y=a[1]*e+a[5]*i+a[9]*s+a[13]*r,this.z=a[2]*e+a[6]*i+a[10]*s+a[14]*r,this.w=a[3]*e+a[7]*i+a[11]*s+a[15]*r,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,i,s,r,c=t.elements,l=c[0],h=c[4],u=c[8],f=c[1],d=c[5],p=c[9],x=c[2],g=c[6],m=c[10];if(Math.abs(h-f)<.01&&Math.abs(u-x)<.01&&Math.abs(p-g)<.01){if(Math.abs(h+f)<.1&&Math.abs(u+x)<.1&&Math.abs(p+g)<.1&&Math.abs(l+d+m-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let _=(l+1)/2,b=(d+1)/2,C=(m+1)/2,A=(h+f)/4,R=(u+x)/4,F=(p+g)/4;return _>b&&_>C?_<.01?(i=0,s=.707106781,r=.707106781):(i=Math.sqrt(_),s=A/i,r=R/i):b>C?b<.01?(i=.707106781,s=0,r=.707106781):(s=Math.sqrt(b),i=A/s,r=F/s):C<.01?(i=.707106781,s=.707106781,r=0):(r=Math.sqrt(C),i=R/r,s=F/r),this.set(i,s,r,e),this}let S=Math.sqrt((g-p)*(g-p)+(u-x)*(u-x)+(f-h)*(f-h));return Math.abs(S)<.001&&(S=1),this.x=(g-p)/S,this.y=(u-x)/S,this.z=(f-h)/S,this.w=Math.acos((l+d+m-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this.w=t.w+(e.w-t.w)*i,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Vc=class extends Ni{constructor(t=1,e=1,i={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new Je(0,0,t,e),this.scissorTest=!1,this.viewport=new Je(0,0,t,e);let s={width:t,height:e,depth:1};i.encoding!==void 0&&(Ar("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===ji?Ce:An),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:wn,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new Rn(s,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(t,e,i=1){(this.width!==t||this.height!==e||this.depth!==i)&&(this.width=t,this.height=e,this.depth=i,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new ia(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},li=class extends Vc{constructor(t=1,e=1,i={}){super(t,e,i),this.isWebGLRenderTarget=!0}},sa=class extends Rn{constructor(t=null,e=1,i=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=Ze,this.minFilter=Ze,this.wrapR=Bn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Wc=class extends Rn{constructor(t=null,e=1,i=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=Ze,this.minFilter=Ze,this.wrapR=Bn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Zn=class{constructor(t=0,e=0,i=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=i,this._w=s}static slerpFlat(t,e,i,s,r,a,o){let c=i[s+0],l=i[s+1],h=i[s+2],u=i[s+3],f=r[a+0],d=r[a+1],p=r[a+2],x=r[a+3];if(o===0){t[e+0]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u;return}if(o===1){t[e+0]=f,t[e+1]=d,t[e+2]=p,t[e+3]=x;return}if(u!==x||c!==f||l!==d||h!==p){let g=1-o,m=c*f+l*d+h*p+u*x,S=m>=0?1:-1,_=1-m*m;if(_>Number.EPSILON){let C=Math.sqrt(_),A=Math.atan2(C,m*S);g=Math.sin(g*A)/C,o=Math.sin(o*A)/C}let b=o*S;if(c=c*g+f*b,l=l*g+d*b,h=h*g+p*b,u=u*g+x*b,g===1-o){let C=1/Math.sqrt(c*c+l*l+h*h+u*u);c*=C,l*=C,h*=C,u*=C}}t[e]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,i,s,r,a){let o=i[s],c=i[s+1],l=i[s+2],h=i[s+3],u=r[a],f=r[a+1],d=r[a+2],p=r[a+3];return t[e]=o*p+h*u+c*d-l*f,t[e+1]=c*p+h*f+l*u-o*d,t[e+2]=l*p+h*d+o*f-c*u,t[e+3]=h*p-o*u-c*f-l*d,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,i,s){return this._x=t,this._y=e,this._z=i,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let i=t._x,s=t._y,r=t._z,a=t._order,o=Math.cos,c=Math.sin,l=o(i/2),h=o(s/2),u=o(r/2),f=c(i/2),d=c(s/2),p=c(r/2);switch(a){case"XYZ":this._x=f*h*u+l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u-f*d*p;break;case"YXZ":this._x=f*h*u+l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u+f*d*p;break;case"ZXY":this._x=f*h*u-l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u-f*d*p;break;case"ZYX":this._x=f*h*u-l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u+f*d*p;break;case"YZX":this._x=f*h*u+l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u-f*d*p;break;case"XZY":this._x=f*h*u-l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u+f*d*p;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let i=e/2,s=Math.sin(i);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,i=e[0],s=e[4],r=e[8],a=e[1],o=e[5],c=e[9],l=e[2],h=e[6],u=e[10],f=i+o+u;if(f>0){let d=.5/Math.sqrt(f+1);this._w=.25/d,this._x=(h-c)*d,this._y=(r-l)*d,this._z=(a-s)*d}else if(i>o&&i>u){let d=2*Math.sqrt(1+i-o-u);this._w=(h-c)/d,this._x=.25*d,this._y=(s+a)/d,this._z=(r+l)/d}else if(o>u){let d=2*Math.sqrt(1+o-i-u);this._w=(r-l)/d,this._x=(s+a)/d,this._y=.25*d,this._z=(c+h)/d}else{let d=2*Math.sqrt(1+u-i-o);this._w=(a-s)/d,this._x=(r+l)/d,this._y=(c+h)/d,this._z=.25*d}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let i=t.dot(e)+1;return i<Number.EPSILON?(i=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=i):(this._x=0,this._y=-t.z,this._z=t.y,this._w=i)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=i),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Qe(this.dot(t),-1,1)))}rotateTowards(t,e){let i=this.angleTo(t);if(i===0)return this;let s=Math.min(1,e/i);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let i=t._x,s=t._y,r=t._z,a=t._w,o=e._x,c=e._y,l=e._z,h=e._w;return this._x=i*h+a*o+s*l-r*c,this._y=s*h+a*c+r*o-i*l,this._z=r*h+a*l+i*c-s*o,this._w=a*h-i*o-s*c-r*l,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let i=this._x,s=this._y,r=this._z,a=this._w,o=a*t._w+i*t._x+s*t._y+r*t._z;if(o<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,o=-o):this.copy(t),o>=1)return this._w=a,this._x=i,this._y=s,this._z=r,this;let c=1-o*o;if(c<=Number.EPSILON){let d=1-e;return this._w=d*a+e*this._w,this._x=d*i+e*this._x,this._y=d*s+e*this._y,this._z=d*r+e*this._z,this.normalize(),this}let l=Math.sqrt(c),h=Math.atan2(l,o),u=Math.sin((1-e)*h)/l,f=Math.sin(e*h)/l;return this._w=a*u+this._w*f,this._x=i*u+this._x*f,this._y=s*u+this._y*f,this._z=r*u+this._z*f,this._onChangeCallback(),this}slerpQuaternions(t,e,i){return this.copy(t).slerp(e,i)}random(){let t=Math.random(),e=Math.sqrt(1-t),i=Math.sqrt(t),s=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(e*Math.cos(s),i*Math.sin(r),i*Math.cos(r),e*Math.sin(s))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},L=class n{constructor(t=0,e=0,i=0){n.prototype.isVector3=!0,this.x=t,this.y=e,this.z=i}set(t,e,i){return i===void 0&&(i=this.z),this.x=t,this.y=e,this.z=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(fu.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(fu.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,i=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*i+r[6]*s,this.y=r[1]*e+r[4]*i+r[7]*s,this.z=r[2]*e+r[5]*i+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,i=this.y,s=this.z,r=t.elements,a=1/(r[3]*e+r[7]*i+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*i+r[8]*s+r[12])*a,this.y=(r[1]*e+r[5]*i+r[9]*s+r[13])*a,this.z=(r[2]*e+r[6]*i+r[10]*s+r[14])*a,this}applyQuaternion(t){let e=this.x,i=this.y,s=this.z,r=t.x,a=t.y,o=t.z,c=t.w,l=2*(a*s-o*i),h=2*(o*e-r*s),u=2*(r*i-a*e);return this.x=e+c*l+a*u-o*h,this.y=i+c*h+o*l-r*u,this.z=s+c*u+r*h-a*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,i=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*i+r[8]*s,this.y=r[1]*e+r[5]*i+r[9]*s,this.z=r[2]*e+r[6]*i+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let i=t.x,s=t.y,r=t.z,a=e.x,o=e.y,c=e.z;return this.x=s*c-r*o,this.y=r*a-i*c,this.z=i*o-s*a,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let i=t.dot(this)/e;return this.copy(t).multiplyScalar(i)}projectOnPlane(t){return uc.copy(this).projectOnVector(t),this.sub(uc)}reflect(t){return this.sub(uc.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let i=this.dot(t)/e;return Math.acos(Qe(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,i=this.y-t.y,s=this.z-t.z;return e*e+i*i+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,i){let s=Math.sin(e)*t;return this.x=s*Math.sin(i),this.y=Math.cos(e)*t,this.z=s*Math.cos(i),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,i){return this.x=t*Math.sin(e),this.y=i,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),i=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=i,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,i=Math.sqrt(1-t**2);return this.x=i*Math.cos(e),this.y=i*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},uc=new L,fu=new Zn,Cn=class{constructor(t=new L(1/0,1/0,1/0),e=new L(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e+=3)this.expandByPoint(On.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,i=t.count;e<i;e++)this.expandByPoint(On.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let i=On.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(i),this.max.copy(t).add(i),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let i=t.geometry;if(i!==void 0){let r=i.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,On):On.fromBufferAttribute(r,a),On.applyMatrix4(t.matrixWorld),this.expandByPoint(On);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),go.copy(t.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),go.copy(i.boundingBox)),go.applyMatrix4(t.matrixWorld),this.union(go)}let s=t.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,On),On.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,i;return t.normal.x>0?(e=t.normal.x*this.min.x,i=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,i=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,i+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,i+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,i+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,i+=t.normal.z*this.min.z),e<=-t.constant&&i>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(gr),xo.subVectors(this.max,gr),vs.subVectors(t.a,gr),Ms.subVectors(t.b,gr),Es.subVectors(t.c,gr),Ei.subVectors(Ms,vs),Si.subVectors(Es,Ms),Gi.subVectors(vs,Es);let e=[0,-Ei.z,Ei.y,0,-Si.z,Si.y,0,-Gi.z,Gi.y,Ei.z,0,-Ei.x,Si.z,0,-Si.x,Gi.z,0,-Gi.x,-Ei.y,Ei.x,0,-Si.y,Si.x,0,-Gi.y,Gi.x,0];return!fc(e,vs,Ms,Es,xo)||(e=[1,0,0,0,1,0,0,0,1],!fc(e,vs,Ms,Es,xo))?!1:(_o.crossVectors(Ei,Si),e=[_o.x,_o.y,_o.z],fc(e,vs,Ms,Es,xo))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,On).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(On).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(ti[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),ti[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),ti[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),ti[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),ti[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),ti[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),ti[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),ti[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(ti),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},ti=[new L,new L,new L,new L,new L,new L,new L,new L],On=new L,go=new Cn,vs=new L,Ms=new L,Es=new L,Ei=new L,Si=new L,Gi=new L,gr=new L,xo=new L,_o=new L,Vi=new L;function fc(n,t,e,i,s){for(let r=0,a=n.length-3;r<=a;r+=3){Vi.fromArray(n,r);let o=s.x*Math.abs(Vi.x)+s.y*Math.abs(Vi.y)+s.z*Math.abs(Vi.z),c=t.dot(Vi),l=e.dot(Vi),h=i.dot(Vi);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>o)return!1}return!0}var Yp=new Cn,xr=new L,dc=new L,Oi=class{constructor(t=new L,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let i=this.center;e!==void 0?i.copy(e):Yp.setFromPoints(t).getCenter(i);let s=0;for(let r=0,a=t.length;r<a;r++)s=Math.max(s,i.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let i=this.center.distanceToSquared(t);return e.copy(t),i>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;xr.subVectors(t,this.center);let e=xr.lengthSq();if(e>this.radius*this.radius){let i=Math.sqrt(e),s=(i-this.radius)*.5;this.center.addScaledVector(xr,s/i),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(dc.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(xr.copy(t.center).add(dc)),this.expandByPoint(xr.copy(t.center).sub(dc))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},ei=new L,pc=new L,yo=new L,bi=new L,mc=new L,vo=new L,gc=new L,ra=class{constructor(t=new L,e=new L(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,ei)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let i=e.dot(this.direction);return i<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=ei.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(ei.copy(this.origin).addScaledVector(this.direction,e),ei.distanceToSquared(t))}distanceSqToSegment(t,e,i,s){pc.copy(t).add(e).multiplyScalar(.5),yo.copy(e).sub(t).normalize(),bi.copy(this.origin).sub(pc);let r=t.distanceTo(e)*.5,a=-this.direction.dot(yo),o=bi.dot(this.direction),c=-bi.dot(yo),l=bi.lengthSq(),h=Math.abs(1-a*a),u,f,d,p;if(h>0)if(u=a*c-o,f=a*o-c,p=r*h,u>=0)if(f>=-p)if(f<=p){let x=1/h;u*=x,f*=x,d=u*(u+a*f+2*o)+f*(a*u+f+2*c)+l}else f=r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;else f=-r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;else f<=-p?(u=Math.max(0,-(-a*r+o)),f=u>0?-r:Math.min(Math.max(-r,-c),r),d=-u*u+f*(f+2*c)+l):f<=p?(u=0,f=Math.min(Math.max(-r,-c),r),d=f*(f+2*c)+l):(u=Math.max(0,-(a*r+o)),f=u>0?r:Math.min(Math.max(-r,-c),r),d=-u*u+f*(f+2*c)+l);else f=a>0?-r:r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;return i&&i.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(pc).addScaledVector(yo,f),d}intersectSphere(t,e){ei.subVectors(t.center,this.origin);let i=ei.dot(this.direction),s=ei.dot(ei)-i*i,r=t.radius*t.radius;if(s>r)return null;let a=Math.sqrt(r-s),o=i-a,c=i+a;return c<0?null:o<0?this.at(c,e):this.at(o,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let i=-(this.origin.dot(t.normal)+t.constant)/e;return i>=0?i:null}intersectPlane(t,e){let i=this.distanceToPlane(t);return i===null?null:this.at(i,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let i,s,r,a,o,c,l=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,f=this.origin;return l>=0?(i=(t.min.x-f.x)*l,s=(t.max.x-f.x)*l):(i=(t.max.x-f.x)*l,s=(t.min.x-f.x)*l),h>=0?(r=(t.min.y-f.y)*h,a=(t.max.y-f.y)*h):(r=(t.max.y-f.y)*h,a=(t.min.y-f.y)*h),i>a||r>s||((r>i||isNaN(i))&&(i=r),(a<s||isNaN(s))&&(s=a),u>=0?(o=(t.min.z-f.z)*u,c=(t.max.z-f.z)*u):(o=(t.max.z-f.z)*u,c=(t.min.z-f.z)*u),i>c||o>s)||((o>i||i!==i)&&(i=o),(c<s||s!==s)&&(s=c),s<0)?null:this.at(i>=0?i:s,e)}intersectsBox(t){return this.intersectBox(t,ei)!==null}intersectTriangle(t,e,i,s,r){mc.subVectors(e,t),vo.subVectors(i,t),gc.crossVectors(mc,vo);let a=this.direction.dot(gc),o;if(a>0){if(s)return null;o=1}else if(a<0)o=-1,a=-a;else return null;bi.subVectors(this.origin,t);let c=o*this.direction.dot(vo.crossVectors(bi,vo));if(c<0)return null;let l=o*this.direction.dot(mc.cross(bi));if(l<0||c+l>a)return null;let h=-o*bi.dot(gc);return h<0?null:this.at(h/a,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Me=class n{constructor(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g){n.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g)}set(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g){let m=this.elements;return m[0]=t,m[4]=e,m[8]=i,m[12]=s,m[1]=r,m[5]=a,m[9]=o,m[13]=c,m[2]=l,m[6]=h,m[10]=u,m[14]=f,m[3]=d,m[7]=p,m[11]=x,m[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new n().fromArray(this.elements)}copy(t){let e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],e[9]=i[9],e[10]=i[10],e[11]=i[11],e[12]=i[12],e[13]=i[13],e[14]=i[14],e[15]=i[15],this}copyPosition(t){let e=this.elements,i=t.elements;return e[12]=i[12],e[13]=i[13],e[14]=i[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,i){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(t,e,i){return this.set(t.x,e.x,i.x,0,t.y,e.y,i.y,0,t.z,e.z,i.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,i=t.elements,s=1/Ss.setFromMatrixColumn(t,0).length(),r=1/Ss.setFromMatrixColumn(t,1).length(),a=1/Ss.setFromMatrixColumn(t,2).length();return e[0]=i[0]*s,e[1]=i[1]*s,e[2]=i[2]*s,e[3]=0,e[4]=i[4]*r,e[5]=i[5]*r,e[6]=i[6]*r,e[7]=0,e[8]=i[8]*a,e[9]=i[9]*a,e[10]=i[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,i=t.x,s=t.y,r=t.z,a=Math.cos(i),o=Math.sin(i),c=Math.cos(s),l=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){let f=a*h,d=a*u,p=o*h,x=o*u;e[0]=c*h,e[4]=-c*u,e[8]=l,e[1]=d+p*l,e[5]=f-x*l,e[9]=-o*c,e[2]=x-f*l,e[6]=p+d*l,e[10]=a*c}else if(t.order==="YXZ"){let f=c*h,d=c*u,p=l*h,x=l*u;e[0]=f+x*o,e[4]=p*o-d,e[8]=a*l,e[1]=a*u,e[5]=a*h,e[9]=-o,e[2]=d*o-p,e[6]=x+f*o,e[10]=a*c}else if(t.order==="ZXY"){let f=c*h,d=c*u,p=l*h,x=l*u;e[0]=f-x*o,e[4]=-a*u,e[8]=p+d*o,e[1]=d+p*o,e[5]=a*h,e[9]=x-f*o,e[2]=-a*l,e[6]=o,e[10]=a*c}else if(t.order==="ZYX"){let f=a*h,d=a*u,p=o*h,x=o*u;e[0]=c*h,e[4]=p*l-d,e[8]=f*l+x,e[1]=c*u,e[5]=x*l+f,e[9]=d*l-p,e[2]=-l,e[6]=o*c,e[10]=a*c}else if(t.order==="YZX"){let f=a*c,d=a*l,p=o*c,x=o*l;e[0]=c*h,e[4]=x-f*u,e[8]=p*u+d,e[1]=u,e[5]=a*h,e[9]=-o*h,e[2]=-l*h,e[6]=d*u+p,e[10]=f-x*u}else if(t.order==="XZY"){let f=a*c,d=a*l,p=o*c,x=o*l;e[0]=c*h,e[4]=-u,e[8]=l*h,e[1]=f*u+x,e[5]=a*h,e[9]=d*u-p,e[2]=p*u-d,e[6]=o*h,e[10]=x*u+f}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(qp,t,$p)}lookAt(t,e,i){let s=this.elements;return _n.subVectors(t,e),_n.lengthSq()===0&&(_n.z=1),_n.normalize(),Ti.crossVectors(i,_n),Ti.lengthSq()===0&&(Math.abs(i.z)===1?_n.x+=1e-4:_n.z+=1e-4,_n.normalize(),Ti.crossVectors(i,_n)),Ti.normalize(),Mo.crossVectors(_n,Ti),s[0]=Ti.x,s[4]=Mo.x,s[8]=_n.x,s[1]=Ti.y,s[5]=Mo.y,s[9]=_n.y,s[2]=Ti.z,s[6]=Mo.z,s[10]=_n.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let i=t.elements,s=e.elements,r=this.elements,a=i[0],o=i[4],c=i[8],l=i[12],h=i[1],u=i[5],f=i[9],d=i[13],p=i[2],x=i[6],g=i[10],m=i[14],S=i[3],_=i[7],b=i[11],C=i[15],A=s[0],R=s[4],F=s[8],E=s[12],v=s[1],N=s[5],B=s[9],rt=s[13],P=s[2],z=s[6],G=s[10],et=s[14],J=s[3],$=s[7],nt=s[11],it=s[15];return r[0]=a*A+o*v+c*P+l*J,r[4]=a*R+o*N+c*z+l*$,r[8]=a*F+o*B+c*G+l*nt,r[12]=a*E+o*rt+c*et+l*it,r[1]=h*A+u*v+f*P+d*J,r[5]=h*R+u*N+f*z+d*$,r[9]=h*F+u*B+f*G+d*nt,r[13]=h*E+u*rt+f*et+d*it,r[2]=p*A+x*v+g*P+m*J,r[6]=p*R+x*N+g*z+m*$,r[10]=p*F+x*B+g*G+m*nt,r[14]=p*E+x*rt+g*et+m*it,r[3]=S*A+_*v+b*P+C*J,r[7]=S*R+_*N+b*z+C*$,r[11]=S*F+_*B+b*G+C*nt,r[15]=S*E+_*rt+b*et+C*it,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],i=t[4],s=t[8],r=t[12],a=t[1],o=t[5],c=t[9],l=t[13],h=t[2],u=t[6],f=t[10],d=t[14],p=t[3],x=t[7],g=t[11],m=t[15];return p*(+r*c*u-s*l*u-r*o*f+i*l*f+s*o*d-i*c*d)+x*(+e*c*d-e*l*f+r*a*f-s*a*d+s*l*h-r*c*h)+g*(+e*l*u-e*o*d-r*a*u+i*a*d+r*o*h-i*l*h)+m*(-s*o*h-e*c*u+e*o*f+s*a*u-i*a*f+i*c*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,i){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=i),this}invert(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8],u=t[9],f=t[10],d=t[11],p=t[12],x=t[13],g=t[14],m=t[15],S=u*g*l-x*f*l+x*c*d-o*g*d-u*c*m+o*f*m,_=p*f*l-h*g*l-p*c*d+a*g*d+h*c*m-a*f*m,b=h*x*l-p*u*l+p*o*d-a*x*d-h*o*m+a*u*m,C=p*u*c-h*x*c-p*o*f+a*x*f+h*o*g-a*u*g,A=e*S+i*_+s*b+r*C;if(A===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let R=1/A;return t[0]=S*R,t[1]=(x*f*r-u*g*r-x*s*d+i*g*d+u*s*m-i*f*m)*R,t[2]=(o*g*r-x*c*r+x*s*l-i*g*l-o*s*m+i*c*m)*R,t[3]=(u*c*r-o*f*r-u*s*l+i*f*l+o*s*d-i*c*d)*R,t[4]=_*R,t[5]=(h*g*r-p*f*r+p*s*d-e*g*d-h*s*m+e*f*m)*R,t[6]=(p*c*r-a*g*r-p*s*l+e*g*l+a*s*m-e*c*m)*R,t[7]=(a*f*r-h*c*r+h*s*l-e*f*l-a*s*d+e*c*d)*R,t[8]=b*R,t[9]=(p*u*r-h*x*r-p*i*d+e*x*d+h*i*m-e*u*m)*R,t[10]=(a*x*r-p*o*r+p*i*l-e*x*l-a*i*m+e*o*m)*R,t[11]=(h*o*r-a*u*r-h*i*l+e*u*l+a*i*d-e*o*d)*R,t[12]=C*R,t[13]=(h*x*s-p*u*s+p*i*f-e*x*f-h*i*g+e*u*g)*R,t[14]=(p*o*s-a*x*s-p*i*c+e*x*c+a*i*g-e*o*g)*R,t[15]=(a*u*s-h*o*s+h*i*c-e*u*c-a*i*f+e*o*f)*R,this}scale(t){let e=this.elements,i=t.x,s=t.y,r=t.z;return e[0]*=i,e[4]*=s,e[8]*=r,e[1]*=i,e[5]*=s,e[9]*=r,e[2]*=i,e[6]*=s,e[10]*=r,e[3]*=i,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],i=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,i,s))}makeTranslation(t,e,i){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,i,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),i=Math.sin(t);return this.set(1,0,0,0,0,e,-i,0,0,i,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,0,i,0,0,1,0,0,-i,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,0,i,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let i=Math.cos(e),s=Math.sin(e),r=1-i,a=t.x,o=t.y,c=t.z,l=r*a,h=r*o;return this.set(l*a+i,l*o-s*c,l*c+s*o,0,l*o+s*c,h*o+i,h*c-s*a,0,l*c-s*o,h*c+s*a,r*c*c+i,0,0,0,0,1),this}makeScale(t,e,i){return this.set(t,0,0,0,0,e,0,0,0,0,i,0,0,0,0,1),this}makeShear(t,e,i,s,r,a){return this.set(1,i,r,0,t,1,a,0,e,s,1,0,0,0,0,1),this}compose(t,e,i){let s=this.elements,r=e._x,a=e._y,o=e._z,c=e._w,l=r+r,h=a+a,u=o+o,f=r*l,d=r*h,p=r*u,x=a*h,g=a*u,m=o*u,S=c*l,_=c*h,b=c*u,C=i.x,A=i.y,R=i.z;return s[0]=(1-(x+m))*C,s[1]=(d+b)*C,s[2]=(p-_)*C,s[3]=0,s[4]=(d-b)*A,s[5]=(1-(f+m))*A,s[6]=(g+S)*A,s[7]=0,s[8]=(p+_)*R,s[9]=(g-S)*R,s[10]=(1-(f+x))*R,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,i){let s=this.elements,r=Ss.set(s[0],s[1],s[2]).length(),a=Ss.set(s[4],s[5],s[6]).length(),o=Ss.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],Fn.copy(this);let l=1/r,h=1/a,u=1/o;return Fn.elements[0]*=l,Fn.elements[1]*=l,Fn.elements[2]*=l,Fn.elements[4]*=h,Fn.elements[5]*=h,Fn.elements[6]*=h,Fn.elements[8]*=u,Fn.elements[9]*=u,Fn.elements[10]*=u,e.setFromRotationMatrix(Fn),i.x=r,i.y=a,i.z=o,this}makePerspective(t,e,i,s,r,a,o=ai){let c=this.elements,l=2*r/(e-t),h=2*r/(i-s),u=(e+t)/(e-t),f=(i+s)/(i-s),d,p;if(o===ai)d=-(a+r)/(a-r),p=-2*a*r/(a-r);else if(o===Qo)d=-a/(a-r),p=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=l,c[4]=0,c[8]=u,c[12]=0,c[1]=0,c[5]=h,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=d,c[14]=p,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,i,s,r,a,o=ai){let c=this.elements,l=1/(e-t),h=1/(i-s),u=1/(a-r),f=(e+t)*l,d=(i+s)*h,p,x;if(o===ai)p=(a+r)*u,x=-2*u;else if(o===Qo)p=r*u,x=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-f,c[1]=0,c[5]=2*h,c[9]=0,c[13]=-d,c[2]=0,c[6]=0,c[10]=x,c[14]=-p,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){let e=this.elements,i=t.elements;for(let s=0;s<16;s++)if(e[s]!==i[s])return!1;return!0}fromArray(t,e=0){for(let i=0;i<16;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){let i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t[e+9]=i[9],t[e+10]=i[10],t[e+11]=i[11],t[e+12]=i[12],t[e+13]=i[13],t[e+14]=i[14],t[e+15]=i[15],t}},Ss=new L,Fn=new Me,qp=new L(0,0,0),$p=new L(1,1,1),Ti=new L,Mo=new L,_n=new L,du=new Me,pu=new Zn,qs=class n{constructor(t=0,e=0,i=0,s=n.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=i,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,i,s=this._order){return this._x=t,this._y=e,this._z=i,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,i=!0){let s=t.elements,r=s[0],a=s[4],o=s[8],c=s[1],l=s[5],h=s[9],u=s[2],f=s[6],d=s[10];switch(e){case"XYZ":this._y=Math.asin(Qe(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,d),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(f,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Qe(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,d),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Qe(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(-u,d),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-Qe(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(f,d),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(Qe(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(o,d));break;case"XZY":this._z=Math.asin(-Qe(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(f,l),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,d),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,i===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,i){return du.makeRotationFromQuaternion(t),this.setFromRotationMatrix(du,e,i)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return pu.setFromEuler(this),this.setFromQuaternion(pu,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};qs.DEFAULT_ORDER="XYZ";var oa=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Zp=0,mu=new L,bs=new Zn,ni=new Me,Eo=new L,_r=new L,Jp=new L,Kp=new Zn,gu=new L(1,0,0),xu=new L(0,1,0),_u=new L(0,0,1),jp={type:"added"},Qp={type:"removed"},Ge=class n extends Ni{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Zp++}),this.uuid=$n(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=n.DEFAULT_UP.clone();let t=new L,e=new qs,i=new Zn,s=new L(1,1,1);function r(){i.setFromEuler(e,!1)}function a(){e.setFromQuaternion(i,void 0,!1)}e._onChange(r),i._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Me},normalMatrix:{value:new ie}}),this.matrix=new Me,this.matrixWorld=new Me,this.matrixAutoUpdate=n.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=n.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new oa,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return bs.setFromAxisAngle(t,e),this.quaternion.multiply(bs),this}rotateOnWorldAxis(t,e){return bs.setFromAxisAngle(t,e),this.quaternion.premultiply(bs),this}rotateX(t){return this.rotateOnAxis(gu,t)}rotateY(t){return this.rotateOnAxis(xu,t)}rotateZ(t){return this.rotateOnAxis(_u,t)}translateOnAxis(t,e){return mu.copy(t).applyQuaternion(this.quaternion),this.position.add(mu.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(gu,t)}translateY(t){return this.translateOnAxis(xu,t)}translateZ(t){return this.translateOnAxis(_u,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(ni.copy(this.matrixWorld).invert())}lookAt(t,e,i){t.isVector3?Eo.copy(t):Eo.set(t,e,i);let s=this.parent;this.updateWorldMatrix(!0,!1),_r.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ni.lookAt(_r,Eo,this.up):ni.lookAt(Eo,_r,this.up),this.quaternion.setFromRotationMatrix(ni),s&&(ni.extractRotation(s.matrixWorld),bs.setFromRotationMatrix(ni),this.quaternion.premultiply(bs.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(jp)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Qp)),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),ni.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),ni.multiply(t.parent.matrixWorld)),t.applyMatrix4(ni),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let i=0,s=this.children.length;i<s;i++){let a=this.children[i].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,i=[]){this[t]===e&&i.push(this);let s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(t,e,i);return i}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(_r,t,Jp),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(_r,Kp,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let i=0,s=e.length;i<s;i++)e[i].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let i=0,s=e.length;i<s;i++)e[i].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let i=0,s=e.length;i<s;i++){let r=e[i];(r.matrixWorldAutoUpdate===!0||t===!0)&&r.updateMatrixWorld(t)}}updateWorldMatrix(t,e){let i=this.parent;if(t===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){let s=this.children;for(let r=0,a=s.length;r<a;r++){let o=s[r];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(t){let e=t===void 0||typeof t=="string",i={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),s.maxGeometryCount=this._maxGeometryCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let c=o.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){let u=c[l];r(t.shapes,u)}else r(t.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let c=0,l=this.material.length;c<l;c++)o.push(r(t.materials,this.material[c]));s.material=o}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){let c=this.animations[o];s.animations.push(r(t.animations,c))}}if(e){let o=a(t.geometries),c=a(t.materials),l=a(t.textures),h=a(t.images),u=a(t.shapes),f=a(t.skeletons),d=a(t.animations),p=a(t.nodes);o.length>0&&(i.geometries=o),c.length>0&&(i.materials=c),l.length>0&&(i.textures=l),h.length>0&&(i.images=h),u.length>0&&(i.shapes=u),f.length>0&&(i.skeletons=f),d.length>0&&(i.animations=d),p.length>0&&(i.nodes=p)}return i.object=s,i;function a(o){let c=[];for(let l in o){let h=o[l];delete h.metadata,c.push(h)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let i=0;i<t.children.length;i++){let s=t.children[i];this.add(s.clone())}return this}};Ge.DEFAULT_UP=new L(0,1,0);Ge.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ge.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var zn=new L,ii=new L,xc=new L,si=new L,Ts=new L,ws=new L,yu=new L,_c=new L,yc=new L,vc=new L,So=!1,Zi=class n{constructor(t=new L,e=new L,i=new L){this.a=t,this.b=e,this.c=i}static getNormal(t,e,i,s){s.subVectors(i,e),zn.subVectors(t,e),s.cross(zn);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,i,s,r){zn.subVectors(s,e),ii.subVectors(i,e),xc.subVectors(t,e);let a=zn.dot(zn),o=zn.dot(ii),c=zn.dot(xc),l=ii.dot(ii),h=ii.dot(xc),u=a*l-o*o;if(u===0)return r.set(0,0,0),null;let f=1/u,d=(l*c-o*h)*f,p=(a*h-o*c)*f;return r.set(1-d-p,p,d)}static containsPoint(t,e,i,s){return this.getBarycoord(t,e,i,s,si)===null?!1:si.x>=0&&si.y>=0&&si.x+si.y<=1}static getUV(t,e,i,s,r,a,o,c){return So===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),So=!0),this.getInterpolation(t,e,i,s,r,a,o,c)}static getInterpolation(t,e,i,s,r,a,o,c){return this.getBarycoord(t,e,i,s,si)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,si.x),c.addScaledVector(a,si.y),c.addScaledVector(o,si.z),c)}static isFrontFacing(t,e,i,s){return zn.subVectors(i,e),ii.subVectors(t,e),zn.cross(ii).dot(s)<0}set(t,e,i){return this.a.copy(t),this.b.copy(e),this.c.copy(i),this}setFromPointsAndIndices(t,e,i,s){return this.a.copy(t[e]),this.b.copy(t[i]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,i,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,i),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return zn.subVectors(this.c,this.b),ii.subVectors(this.a,this.b),zn.cross(ii).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return n.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return n.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,i,s,r){return So===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),So=!0),n.getInterpolation(t,this.a,this.b,this.c,e,i,s,r)}getInterpolation(t,e,i,s,r){return n.getInterpolation(t,this.a,this.b,this.c,e,i,s,r)}containsPoint(t){return n.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return n.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let i=this.a,s=this.b,r=this.c,a,o;Ts.subVectors(s,i),ws.subVectors(r,i),_c.subVectors(t,i);let c=Ts.dot(_c),l=ws.dot(_c);if(c<=0&&l<=0)return e.copy(i);yc.subVectors(t,s);let h=Ts.dot(yc),u=ws.dot(yc);if(h>=0&&u<=h)return e.copy(s);let f=c*u-h*l;if(f<=0&&c>=0&&h<=0)return a=c/(c-h),e.copy(i).addScaledVector(Ts,a);vc.subVectors(t,r);let d=Ts.dot(vc),p=ws.dot(vc);if(p>=0&&d<=p)return e.copy(r);let x=d*l-c*p;if(x<=0&&l>=0&&p<=0)return o=l/(l-p),e.copy(i).addScaledVector(ws,o);let g=h*p-d*u;if(g<=0&&u-h>=0&&d-p>=0)return yu.subVectors(r,s),o=(u-h)/(u-h+(d-p)),e.copy(s).addScaledVector(yu,o);let m=1/(g+x+f);return a=x*m,o=f*m,e.copy(i).addScaledVector(Ts,a).addScaledVector(ws,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},Ef={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},wi={h:0,s:0,l:0},bo={h:0,s:0,l:0};function Mc(n,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?n+(t-n)*6*e:e<1/2?t:e<2/3?n+(t-n)*6*(2/3-e):n}var Ft=class{constructor(t,e,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,i)}set(t,e,i){if(e===void 0&&i===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,i);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Ce){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,me.toWorkingColorSpace(this,e),this}setRGB(t,e,i,s=me.workingColorSpace){return this.r=t,this.g=e,this.b=i,me.toWorkingColorSpace(this,s),this}setHSL(t,e,i,s=me.workingColorSpace){if(t=Ll(t,1),e=Qe(e,0,1),i=Qe(i,0,1),e===0)this.r=this.g=this.b=i;else{let r=i<=.5?i*(1+e):i+e-i*e,a=2*i-r;this.r=Mc(a,r,t+1/3),this.g=Mc(a,r,t),this.b=Mc(a,r,t-1/3)}return me.toWorkingColorSpace(this,s),this}setStyle(t,e=Ce){function i(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Ce){let i=Ef[t.toLowerCase()];return i!==void 0?this.setHex(i,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Gs(t.r),this.g=Gs(t.g),this.b=Gs(t.b),this}copyLinearToSRGB(t){return this.r=lc(t.r),this.g=lc(t.g),this.b=lc(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Ce){return me.fromWorkingColorSpace(on.copy(this),t),Math.round(Qe(on.r*255,0,255))*65536+Math.round(Qe(on.g*255,0,255))*256+Math.round(Qe(on.b*255,0,255))}getHexString(t=Ce){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=me.workingColorSpace){me.fromWorkingColorSpace(on.copy(this),e);let i=on.r,s=on.g,r=on.b,a=Math.max(i,s,r),o=Math.min(i,s,r),c,l,h=(o+a)/2;if(o===a)c=0,l=0;else{let u=a-o;switch(l=h<=.5?u/(a+o):u/(2-a-o),a){case i:c=(s-r)/u+(s<r?6:0);break;case s:c=(r-i)/u+2;break;case r:c=(i-s)/u+4;break}c/=6}return t.h=c,t.s=l,t.l=h,t}getRGB(t,e=me.workingColorSpace){return me.fromWorkingColorSpace(on.copy(this),e),t.r=on.r,t.g=on.g,t.b=on.b,t}getStyle(t=Ce){me.fromWorkingColorSpace(on.copy(this),t);let e=on.r,i=on.g,s=on.b;return t!==Ce?`color(${t} ${e.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(i*255)},${Math.round(s*255)})`}offsetHSL(t,e,i){return this.getHSL(wi),this.setHSL(wi.h+t,wi.s+e,wi.l+i)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,i){return this.r=t.r+(e.r-t.r)*i,this.g=t.g+(e.g-t.g)*i,this.b=t.b+(e.b-t.b)*i,this}lerpHSL(t,e){this.getHSL(wi),t.getHSL(bo);let i=wr(wi.h,bo.h,e),s=wr(wi.s,bo.s,e),r=wr(wi.l,bo.l,e);return this.setHSL(i,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,i=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*i+r[6]*s,this.g=r[1]*e+r[4]*i+r[7]*s,this.b=r[2]*e+r[5]*i+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},on=new Ft;Ft.NAMES=Ef;var tm=0,hi=class extends Ni{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:tm++}),this.uuid=$n(),this.name="",this.type="Material",this.blending=Pi,this.side=Di,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Nc,this.blendDst=Oc,this.blendEquation=qi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ft(0,0,0),this.blendAlpha=0,this.depthFunc=qo,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=ou,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=_s,this.stencilZFail=_s,this.stencilZPass=_s,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let i=t[e];if(i===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(i):s&&s.isVector3&&i&&i.isVector3?s.copy(i):this[e]=i}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(t).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(t).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(t).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(t).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(t).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Pi&&(i.blending=this.blending),this.side!==Di&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==Nc&&(i.blendSrc=this.blendSrc),this.blendDst!==Oc&&(i.blendDst=this.blendDst),this.blendEquation!==qi&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==qo&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==ou&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==_s&&(i.stencilFail=this.stencilFail),this.stencilZFail!==_s&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==_s&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function s(r){let a=[];for(let o in r){let c=r[o];delete c.metadata,a.push(c)}return a}if(e){let r=s(t.textures),a=s(t.images);r.length>0&&(i.textures=r),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,i=null;if(e!==null){let s=e.length;i=new Array(s);for(let r=0;r!==s;++r)i[r]=e[r].clone()}return this.clippingPlanes=i,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},Pn=class extends hi{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ft(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=af,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var Oe=new L,To=new ut,we=class{constructor(t,e,i=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=i,this.usage=Hc,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Ri,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,i){t*=this.itemSize,i*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[i+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,i=this.count;e<i;e++)To.fromBufferAttribute(this,e),To.applyMatrix3(t),this.setXY(e,To.x,To.y);else if(this.itemSize===3)for(let e=0,i=this.count;e<i;e++)Oe.fromBufferAttribute(this,e),Oe.applyMatrix3(t),this.setXYZ(e,Oe.x,Oe.y,Oe.z);return this}applyMatrix4(t){for(let e=0,i=this.count;e<i;e++)Oe.fromBufferAttribute(this,e),Oe.applyMatrix4(t),this.setXYZ(e,Oe.x,Oe.y,Oe.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)Oe.fromBufferAttribute(this,e),Oe.applyNormalMatrix(t),this.setXYZ(e,Oe.x,Oe.y,Oe.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)Oe.fromBufferAttribute(this,e),Oe.transformDirection(t),this.setXYZ(e,Oe.x,Oe.y,Oe.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let i=this.array[t*this.itemSize+e];return this.normalized&&(i=qn(i,this.array)),i}setComponent(t,e,i){return this.normalized&&(i=pe(i,this.array)),this.array[t*this.itemSize+e]=i,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=qn(e,this.array)),e}setX(t,e){return this.normalized&&(e=pe(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=qn(e,this.array)),e}setY(t,e){return this.normalized&&(e=pe(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=qn(e,this.array)),e}setZ(t,e){return this.normalized&&(e=pe(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=qn(e,this.array)),e}setW(t,e){return this.normalized&&(e=pe(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,i){return t*=this.itemSize,this.normalized&&(e=pe(e,this.array),i=pe(i,this.array)),this.array[t+0]=e,this.array[t+1]=i,this}setXYZ(t,e,i,s){return t*=this.itemSize,this.normalized&&(e=pe(e,this.array),i=pe(i,this.array),s=pe(s,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this}setXYZW(t,e,i,s,r){return t*=this.itemSize,this.normalized&&(e=pe(e,this.array),i=pe(i,this.array),s=pe(s,this.array),r=pe(r,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==Hc&&(t.usage=this.usage),t}};var aa=class extends we{constructor(t,e,i){super(new Uint16Array(t),e,i)}};var ca=class extends we{constructor(t,e,i){super(new Uint32Array(t),e,i)}};var ae=class extends we{constructor(t,e,i){super(new Float32Array(t),e,i)}};var em=0,Tn=new Me,Ec=new Ge,As=new L,yn=new Cn,yr=new Cn,$e=new L,Le=class n extends Ni{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:em++}),this.uuid=$n(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Mf(t)?ca:aa)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,i=0){this.groups.push({start:t,count:e,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let i=this.attributes.normal;if(i!==void 0){let r=new ie().getNormalMatrix(t);i.applyNormalMatrix(r),i.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return Tn.makeRotationFromQuaternion(t),this.applyMatrix4(Tn),this}rotateX(t){return Tn.makeRotationX(t),this.applyMatrix4(Tn),this}rotateY(t){return Tn.makeRotationY(t),this.applyMatrix4(Tn),this}rotateZ(t){return Tn.makeRotationZ(t),this.applyMatrix4(Tn),this}translate(t,e,i){return Tn.makeTranslation(t,e,i),this.applyMatrix4(Tn),this}scale(t,e,i){return Tn.makeScale(t,e,i),this.applyMatrix4(Tn),this}lookAt(t){return Ec.lookAt(t),Ec.updateMatrix(),this.applyMatrix4(Ec.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(As).negate(),this.translate(As.x,As.y,As.z),this}setFromPoints(t){let e=[];for(let i=0,s=t.length;i<s;i++){let r=t[i];e.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new ae(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Cn);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new L(-1/0,-1/0,-1/0),new L(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let i=0,s=e.length;i<s;i++){let r=e[i];yn.setFromBufferAttribute(r),this.morphTargetsRelative?($e.addVectors(this.boundingBox.min,yn.min),this.boundingBox.expandByPoint($e),$e.addVectors(this.boundingBox.max,yn.max),this.boundingBox.expandByPoint($e)):(this.boundingBox.expandByPoint(yn.min),this.boundingBox.expandByPoint(yn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Oi);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new L,1/0);return}if(t){let i=this.boundingSphere.center;if(yn.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){let o=e[r];yr.setFromBufferAttribute(o),this.morphTargetsRelative?($e.addVectors(yn.min,yr.min),yn.expandByPoint($e),$e.addVectors(yn.max,yr.max),yn.expandByPoint($e)):(yn.expandByPoint(yr.min),yn.expandByPoint(yr.max))}yn.getCenter(i);let s=0;for(let r=0,a=t.count;r<a;r++)$e.fromBufferAttribute(t,r),s=Math.max(s,i.distanceToSquared($e));if(e)for(let r=0,a=e.length;r<a;r++){let o=e[r],c=this.morphTargetsRelative;for(let l=0,h=o.count;l<h;l++)$e.fromBufferAttribute(o,l),c&&(As.fromBufferAttribute(t,l),$e.add(As)),s=Math.max(s,i.distanceToSquared($e))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let i=t.array,s=e.position.array,r=e.normal.array,a=e.uv.array,o=s.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new we(new Float32Array(4*o),4));let c=this.getAttribute("tangent").array,l=[],h=[];for(let v=0;v<o;v++)l[v]=new L,h[v]=new L;let u=new L,f=new L,d=new L,p=new ut,x=new ut,g=new ut,m=new L,S=new L;function _(v,N,B){u.fromArray(s,v*3),f.fromArray(s,N*3),d.fromArray(s,B*3),p.fromArray(a,v*2),x.fromArray(a,N*2),g.fromArray(a,B*2),f.sub(u),d.sub(u),x.sub(p),g.sub(p);let rt=1/(x.x*g.y-g.x*x.y);isFinite(rt)&&(m.copy(f).multiplyScalar(g.y).addScaledVector(d,-x.y).multiplyScalar(rt),S.copy(d).multiplyScalar(x.x).addScaledVector(f,-g.x).multiplyScalar(rt),l[v].add(m),l[N].add(m),l[B].add(m),h[v].add(S),h[N].add(S),h[B].add(S))}let b=this.groups;b.length===0&&(b=[{start:0,count:i.length}]);for(let v=0,N=b.length;v<N;++v){let B=b[v],rt=B.start,P=B.count;for(let z=rt,G=rt+P;z<G;z+=3)_(i[z+0],i[z+1],i[z+2])}let C=new L,A=new L,R=new L,F=new L;function E(v){R.fromArray(r,v*3),F.copy(R);let N=l[v];C.copy(N),C.sub(R.multiplyScalar(R.dot(N))).normalize(),A.crossVectors(F,N);let rt=A.dot(h[v])<0?-1:1;c[v*4]=C.x,c[v*4+1]=C.y,c[v*4+2]=C.z,c[v*4+3]=rt}for(let v=0,N=b.length;v<N;++v){let B=b[v],rt=B.start,P=B.count;for(let z=rt,G=rt+P;z<G;z+=3)E(i[z+0]),E(i[z+1]),E(i[z+2])}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new we(new Float32Array(e.count*3),3),this.setAttribute("normal",i);else for(let f=0,d=i.count;f<d;f++)i.setXYZ(f,0,0,0);let s=new L,r=new L,a=new L,o=new L,c=new L,l=new L,h=new L,u=new L;if(t)for(let f=0,d=t.count;f<d;f+=3){let p=t.getX(f+0),x=t.getX(f+1),g=t.getX(f+2);s.fromBufferAttribute(e,p),r.fromBufferAttribute(e,x),a.fromBufferAttribute(e,g),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),o.fromBufferAttribute(i,p),c.fromBufferAttribute(i,x),l.fromBufferAttribute(i,g),o.add(h),c.add(h),l.add(h),i.setXYZ(p,o.x,o.y,o.z),i.setXYZ(x,c.x,c.y,c.z),i.setXYZ(g,l.x,l.y,l.z)}else for(let f=0,d=e.count;f<d;f+=3)s.fromBufferAttribute(e,f+0),r.fromBufferAttribute(e,f+1),a.fromBufferAttribute(e,f+2),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),i.setXYZ(f+0,h.x,h.y,h.z),i.setXYZ(f+1,h.x,h.y,h.z),i.setXYZ(f+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,i=t.count;e<i;e++)$e.fromBufferAttribute(t,e),$e.normalize(),t.setXYZ(e,$e.x,$e.y,$e.z)}toNonIndexed(){function t(o,c){let l=o.array,h=o.itemSize,u=o.normalized,f=new l.constructor(c.length*h),d=0,p=0;for(let x=0,g=c.length;x<g;x++){o.isInterleavedBufferAttribute?d=c[x]*o.data.stride+o.offset:d=c[x]*h;for(let m=0;m<h;m++)f[p++]=l[d++]}return new we(f,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new n,i=this.index.array,s=this.attributes;for(let o in s){let c=s[o],l=t(c,i);e.setAttribute(o,l)}let r=this.morphAttributes;for(let o in r){let c=[],l=r[o];for(let h=0,u=l.length;h<u;h++){let f=l[h],d=t(f,i);c.push(d)}e.morphAttributes[o]=c}e.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,c=a.length;o<c;o++){let l=a[o];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let c=this.parameters;for(let l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let i=this.attributes;for(let c in i){let l=i[c];t.data.attributes[c]=l.toJSON(t.data)}let s={},r=!1;for(let c in this.morphAttributes){let l=this.morphAttributes[c],h=[];for(let u=0,f=l.length;u<f;u++){let d=l[u];h.push(d.toJSON(t.data))}h.length>0&&(s[c]=h,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(t.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let i=t.index;i!==null&&this.setIndex(i.clone(e));let s=t.attributes;for(let l in s){let h=s[l];this.setAttribute(l,h.clone(e))}let r=t.morphAttributes;for(let l in r){let h=[],u=r[l];for(let f=0,d=u.length;f<d;f++)h.push(u[f].clone(e));this.morphAttributes[l]=h}this.morphTargetsRelative=t.morphTargetsRelative;let a=t.groups;for(let l=0,h=a.length;l<h;l++){let u=a[l];this.addGroup(u.start,u.count,u.materialIndex)}let o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());let c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},vu=new Me,Wi=new ra,wo=new Oi,Mu=new L,Rs=new L,Cs=new L,Ps=new L,Sc=new L,Ao=new L,Ro=new ut,Co=new ut,Po=new ut,Eu=new L,Su=new L,bu=new L,Lo=new L,Io=new L,It=class extends Ge{constructor(t=new Le,e=new Pn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){let s=e[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){let o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){let i=this.geometry,s=i.attributes.position,r=i.morphAttributes.position,a=i.morphTargetsRelative;e.fromBufferAttribute(s,t);let o=this.morphTargetInfluences;if(r&&o){Ao.set(0,0,0);for(let c=0,l=r.length;c<l;c++){let h=o[c],u=r[c];h!==0&&(Sc.fromBufferAttribute(u,t),a?Ao.addScaledVector(Sc,h):Ao.addScaledVector(Sc.sub(e),h))}e.add(Ao)}return e}raycast(t,e){let i=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),wo.copy(i.boundingSphere),wo.applyMatrix4(r),Wi.copy(t.ray).recast(t.near),!(wo.containsPoint(Wi.origin)===!1&&(Wi.intersectSphere(wo,Mu)===null||Wi.origin.distanceToSquared(Mu)>(t.far-t.near)**2))&&(vu.copy(r).invert(),Wi.copy(t.ray).applyMatrix4(vu),!(i.boundingBox!==null&&Wi.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(t,e,Wi)))}_computeIntersections(t,e,i){let s,r=this.geometry,a=this.material,o=r.index,c=r.attributes.position,l=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,f=r.groups,d=r.drawRange;if(o!==null)if(Array.isArray(a))for(let p=0,x=f.length;p<x;p++){let g=f[p],m=a[g.materialIndex],S=Math.max(g.start,d.start),_=Math.min(o.count,Math.min(g.start+g.count,d.start+d.count));for(let b=S,C=_;b<C;b+=3){let A=o.getX(b),R=o.getX(b+1),F=o.getX(b+2);s=Do(this,m,t,i,l,h,u,A,R,F),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let p=Math.max(0,d.start),x=Math.min(o.count,d.start+d.count);for(let g=p,m=x;g<m;g+=3){let S=o.getX(g),_=o.getX(g+1),b=o.getX(g+2);s=Do(this,a,t,i,l,h,u,S,_,b),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}else if(c!==void 0)if(Array.isArray(a))for(let p=0,x=f.length;p<x;p++){let g=f[p],m=a[g.materialIndex],S=Math.max(g.start,d.start),_=Math.min(c.count,Math.min(g.start+g.count,d.start+d.count));for(let b=S,C=_;b<C;b+=3){let A=b,R=b+1,F=b+2;s=Do(this,m,t,i,l,h,u,A,R,F),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let p=Math.max(0,d.start),x=Math.min(c.count,d.start+d.count);for(let g=p,m=x;g<m;g+=3){let S=g,_=g+1,b=g+2;s=Do(this,a,t,i,l,h,u,S,_,b),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}}};function nm(n,t,e,i,s,r,a,o){let c;if(t.side===an?c=i.intersectTriangle(a,r,s,!0,o):c=i.intersectTriangle(s,r,a,t.side===Di,o),c===null)return null;Io.copy(o),Io.applyMatrix4(n.matrixWorld);let l=e.ray.origin.distanceTo(Io);return l<e.near||l>e.far?null:{distance:l,point:Io.clone(),object:n}}function Do(n,t,e,i,s,r,a,o,c,l){n.getVertexPosition(o,Rs),n.getVertexPosition(c,Cs),n.getVertexPosition(l,Ps);let h=nm(n,t,e,i,Rs,Cs,Ps,Lo);if(h){s&&(Ro.fromBufferAttribute(s,o),Co.fromBufferAttribute(s,c),Po.fromBufferAttribute(s,l),h.uv=Zi.getInterpolation(Lo,Rs,Cs,Ps,Ro,Co,Po,new ut)),r&&(Ro.fromBufferAttribute(r,o),Co.fromBufferAttribute(r,c),Po.fromBufferAttribute(r,l),h.uv1=Zi.getInterpolation(Lo,Rs,Cs,Ps,Ro,Co,Po,new ut),h.uv2=h.uv1),a&&(Eu.fromBufferAttribute(a,o),Su.fromBufferAttribute(a,c),bu.fromBufferAttribute(a,l),h.normal=Zi.getInterpolation(Lo,Rs,Cs,Ps,Eu,Su,bu,new L),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));let u={a:o,b:c,c:l,normal:new L,materialIndex:0};Zi.getNormal(Rs,Cs,Ps,u.normal),h.face=u}return h}var ge=class n extends Le{constructor(t=1,e=1,i=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:i,widthSegments:s,heightSegments:r,depthSegments:a};let o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);let c=[],l=[],h=[],u=[],f=0,d=0;p("z","y","x",-1,-1,i,e,t,a,r,0),p("z","y","x",1,-1,i,e,-t,a,r,1),p("x","z","y",1,1,t,i,e,s,a,2),p("x","z","y",1,-1,t,i,-e,s,a,3),p("x","y","z",1,-1,t,e,i,s,r,4),p("x","y","z",-1,-1,t,e,-i,s,r,5),this.setIndex(c),this.setAttribute("position",new ae(l,3)),this.setAttribute("normal",new ae(h,3)),this.setAttribute("uv",new ae(u,2));function p(x,g,m,S,_,b,C,A,R,F,E){let v=b/R,N=C/F,B=b/2,rt=C/2,P=A/2,z=R+1,G=F+1,et=0,J=0,$=new L;for(let nt=0;nt<G;nt++){let it=nt*N-rt;for(let _t=0;_t<z;_t++){let W=_t*v-B;$[x]=W*S,$[g]=it*_,$[m]=P,l.push($.x,$.y,$.z),$[x]=0,$[g]=0,$[m]=A>0?1:-1,h.push($.x,$.y,$.z),u.push(_t/R),u.push(1-nt/F),et+=1}}for(let nt=0;nt<F;nt++)for(let it=0;it<R;it++){let _t=f+it+z*nt,W=f+it+z*(nt+1),K=f+(it+1)+z*(nt+1),gt=f+(it+1)+z*nt;c.push(_t,W,gt),c.push(W,K,gt),J+=6}o.addGroup(d,J,E),d+=J,f+=et}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function $s(n){let t={};for(let e in n){t[e]={};for(let i in n[e]){let s=n[e][i];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][i]=null):t[e][i]=s.clone():Array.isArray(s)?t[e][i]=s.slice():t[e][i]=s}}return t}function un(n){let t={};for(let e=0;e<n.length;e++){let i=$s(n[e]);for(let s in i)t[s]=i[s]}return t}function im(n){let t=[];for(let e=0;e<n.length;e++)t.push(n[e].clone());return t}function Sf(n){return n.getRenderTarget()===null?n.outputColorSpace:me.workingColorSpace}var sm={clone:$s,merge:un},rm=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,om=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Ln=class extends hi{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=rm,this.fragmentShader=om,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=$s(t.uniforms),this.uniformsGroups=im(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let a=this.uniforms[s].value;a&&a.isTexture?e.uniforms[s]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[s]={type:"m4",value:a.toArray()}:e.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let i={};for(let s in this.extensions)this.extensions[s]===!0&&(i[s]=!0);return Object.keys(i).length>0&&(e.extensions=i),e}},la=class extends Ge{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Me,this.projectionMatrix=new Me,this.projectionMatrixInverse=new Me,this.coordinateSystem=ai}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},fn=class extends la{constructor(t=50,e=1,i=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=i,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=Nr*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(Tr*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Nr*2*Math.atan(Math.tan(Tr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,i,s,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(Tr*.5*this.fov)/this.zoom,i=2*e,s=this.aspect*i,r=-.5*s,a=this.view;if(this.view!==null&&this.view.enabled){let c=a.fullWidth,l=a.fullHeight;r+=a.offsetX*s/c,e-=a.offsetY*i/l,s*=a.width/c,i*=a.height/l}let o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-i,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},Ls=-90,Is=1,Xc=class extends Ge{constructor(t,e,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new fn(Ls,Is,t,e);s.layers=this.layers,this.add(s);let r=new fn(Ls,Is,t,e);r.layers=this.layers,this.add(r);let a=new fn(Ls,Is,t,e);a.layers=this.layers,this.add(a);let o=new fn(Ls,Is,t,e);o.layers=this.layers,this.add(o);let c=new fn(Ls,Is,t,e);c.layers=this.layers,this.add(c);let l=new fn(Ls,Is,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[i,s,r,a,o,c]=e;for(let l of e)this.remove(l);if(t===ai)i.up.set(0,1,0),i.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===Qo)i.up.set(0,-1,0),i.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:i,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,a,o,c,l,h]=this.children,u=t.getRenderTarget(),f=t.getActiveCubeFace(),d=t.getActiveMipmapLevel(),p=t.xr.enabled;t.xr.enabled=!1;let x=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,t.setRenderTarget(i,0,s),t.render(e,r),t.setRenderTarget(i,1,s),t.render(e,a),t.setRenderTarget(i,2,s),t.render(e,o),t.setRenderTarget(i,3,s),t.render(e,c),t.setRenderTarget(i,4,s),t.render(e,l),i.texture.generateMipmaps=x,t.setRenderTarget(i,5,s),t.render(e,h),t.setRenderTarget(u,f,d),t.xr.enabled=p,i.texture.needsPMREMUpdate=!0}},ha=class extends Rn{constructor(t,e,i,s,r,a,o,c,l,h){t=t!==void 0?t:[],e=e!==void 0?e:Ws,super(t,e,i,s,r,a,o,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},Yc=class extends li{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let i={width:t,height:t,depth:1},s=[i,i,i,i,i,i];e.encoding!==void 0&&(Ar("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===ji?Ce:An),this.texture=new ha(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:wn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new ge(5,5,5),r=new Ln({name:"CubemapFromEquirect",uniforms:$s(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:an,blending:Ci});r.uniforms.tEquirect.value=e;let a=new It(s,r),o=e.minFilter;return e.minFilter===Dr&&(e.minFilter=wn),new Xc(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,i,s){let r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,i,s);t.setRenderTarget(r)}},bc=new L,am=new L,cm=new ie,oi=class{constructor(t=new L(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,i,s){return this.normal.set(t,e,i),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,i){let s=bc.subVectors(i,e).cross(am.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let i=t.delta(bc),s=this.normal.dot(i);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(i,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),i=this.distanceToPoint(t.end);return e<0&&i>0||i<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let i=e||cm.getNormalMatrix(t),s=this.coplanarPoint(bc).applyMatrix4(t),r=this.normal.applyMatrix3(i).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},Xi=new Oi,Uo=new L,Or=class{constructor(t=new oi,e=new oi,i=new oi,s=new oi,r=new oi,a=new oi){this.planes=[t,e,i,s,r,a]}set(t,e,i,s,r,a){let o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(i),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(t){let e=this.planes;for(let i=0;i<6;i++)e[i].copy(t.planes[i]);return this}setFromProjectionMatrix(t,e=ai){let i=this.planes,s=t.elements,r=s[0],a=s[1],o=s[2],c=s[3],l=s[4],h=s[5],u=s[6],f=s[7],d=s[8],p=s[9],x=s[10],g=s[11],m=s[12],S=s[13],_=s[14],b=s[15];if(i[0].setComponents(c-r,f-l,g-d,b-m).normalize(),i[1].setComponents(c+r,f+l,g+d,b+m).normalize(),i[2].setComponents(c+a,f+h,g+p,b+S).normalize(),i[3].setComponents(c-a,f-h,g-p,b-S).normalize(),i[4].setComponents(c-o,f-u,g-x,b-_).normalize(),e===ai)i[5].setComponents(c+o,f+u,g+x,b+_).normalize();else if(e===Qo)i[5].setComponents(o,u,x,_).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Xi.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Xi.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Xi)}intersectsSprite(t){return Xi.center.set(0,0,0),Xi.radius=.7071067811865476,Xi.applyMatrix4(t.matrixWorld),this.intersectsSphere(Xi)}intersectsSphere(t){let e=this.planes,i=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(i)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let i=0;i<6;i++){let s=e[i];if(Uo.x=s.normal.x>0?t.max.x:t.min.x,Uo.y=s.normal.y>0?t.max.y:t.min.y,Uo.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(Uo)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let i=0;i<6;i++)if(e[i].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function bf(){let n=null,t=!1,e=null,i=null;function s(r,a){e(r,a),i=n.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(i=n.requestAnimationFrame(s),t=!0)},stop:function(){n.cancelAnimationFrame(i),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){n=r}}}function lm(n,t){let e=t.isWebGL2,i=new WeakMap;function s(l,h){let u=l.array,f=l.usage,d=u.byteLength,p=n.createBuffer();n.bindBuffer(h,p),n.bufferData(h,u,f),l.onUploadCallback();let x;if(u instanceof Float32Array)x=n.FLOAT;else if(u instanceof Uint16Array)if(l.isFloat16BufferAttribute)if(e)x=n.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else x=n.UNSIGNED_SHORT;else if(u instanceof Int16Array)x=n.SHORT;else if(u instanceof Uint32Array)x=n.UNSIGNED_INT;else if(u instanceof Int32Array)x=n.INT;else if(u instanceof Int8Array)x=n.BYTE;else if(u instanceof Uint8Array)x=n.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)x=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:p,type:x,bytesPerElement:u.BYTES_PER_ELEMENT,version:l.version,size:d}}function r(l,h,u){let f=h.array,d=h._updateRange,p=h.updateRanges;if(n.bindBuffer(u,l),d.count===-1&&p.length===0&&n.bufferSubData(u,0,f),p.length!==0){for(let x=0,g=p.length;x<g;x++){let m=p[x];e?n.bufferSubData(u,m.start*f.BYTES_PER_ELEMENT,f,m.start,m.count):n.bufferSubData(u,m.start*f.BYTES_PER_ELEMENT,f.subarray(m.start,m.start+m.count))}h.clearUpdateRanges()}d.count!==-1&&(e?n.bufferSubData(u,d.offset*f.BYTES_PER_ELEMENT,f,d.offset,d.count):n.bufferSubData(u,d.offset*f.BYTES_PER_ELEMENT,f.subarray(d.offset,d.offset+d.count)),d.count=-1),h.onUploadCallback()}function a(l){return l.isInterleavedBufferAttribute&&(l=l.data),i.get(l)}function o(l){l.isInterleavedBufferAttribute&&(l=l.data);let h=i.get(l);h&&(n.deleteBuffer(h.buffer),i.delete(l))}function c(l,h){if(l.isGLBufferAttribute){let f=i.get(l);(!f||f.version<l.version)&&i.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}l.isInterleavedBufferAttribute&&(l=l.data);let u=i.get(l);if(u===void 0)i.set(l,s(l,h));else if(u.version<l.version){if(u.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(u.buffer,l,h),u.version=l.version}}return{get:a,remove:o,update:c}}var mn=class n extends Le{constructor(t=1,e=1,i=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:i,heightSegments:s};let r=t/2,a=e/2,o=Math.floor(i),c=Math.floor(s),l=o+1,h=c+1,u=t/o,f=e/c,d=[],p=[],x=[],g=[];for(let m=0;m<h;m++){let S=m*f-a;for(let _=0;_<l;_++){let b=_*u-r;p.push(b,-S,0),x.push(0,0,1),g.push(_/o),g.push(1-m/c)}}for(let m=0;m<c;m++)for(let S=0;S<o;S++){let _=S+l*m,b=S+l*(m+1),C=S+1+l*(m+1),A=S+1+l*m;d.push(_,b,A),d.push(b,C,A)}this.setIndex(d),this.setAttribute("position",new ae(p,3)),this.setAttribute("normal",new ae(x,3)),this.setAttribute("uv",new ae(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.width,t.height,t.widthSegments,t.heightSegments)}},hm=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,um=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,fm=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,dm=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,pm=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,mm=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,gm=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,xm=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,_m=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,ym=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,vm=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Mm=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Em=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Sm=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bm=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Tm=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,wm=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Am=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Rm=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Cm=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Pm=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Lm=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Im=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Dm=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Um=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Nm=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Om=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Fm=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,zm=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Bm=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Hm="gl_FragColor = linearToOutputTexel( gl_FragColor );",km=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Gm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Vm=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Wm=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Xm=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Ym=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,qm=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,$m=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Zm=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Jm=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Km=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,jm=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,Qm=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,t0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,e0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,n0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,i0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,s0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,r0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,o0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,a0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,c0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,l0=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,h0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,u0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,f0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,d0=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,p0=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,m0=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,g0=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,x0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,_0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,y0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,v0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,M0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,E0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,S0=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,b0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,T0=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,w0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,A0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,R0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,C0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,P0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,L0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,I0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,D0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,U0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,N0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,O0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,F0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,z0=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,B0=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,H0=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,k0=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,G0=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,V0=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,W0=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,X0=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,Y0=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,q0=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,$0=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Z0=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,J0=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,K0=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,j0=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Q0=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,tg=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,eg=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,ng=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,ig=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,sg=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,rg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,og=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,ag=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,cg=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,lg=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,hg=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ug=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fg=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,dg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,pg=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,mg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,gg=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,xg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,_g=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,yg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,vg=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Mg=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Eg=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Sg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,bg=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tg=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,wg=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ag=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Rg=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Cg=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Pg=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Lg=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ig=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Dg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Ug=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ng=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Og=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Fg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,zg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Bg=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Hg=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,kg=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Gg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,jt={alphahash_fragment:hm,alphahash_pars_fragment:um,alphamap_fragment:fm,alphamap_pars_fragment:dm,alphatest_fragment:pm,alphatest_pars_fragment:mm,aomap_fragment:gm,aomap_pars_fragment:xm,batching_pars_vertex:_m,batching_vertex:ym,begin_vertex:vm,beginnormal_vertex:Mm,bsdfs:Em,iridescence_fragment:Sm,bumpmap_pars_fragment:bm,clipping_planes_fragment:Tm,clipping_planes_pars_fragment:wm,clipping_planes_pars_vertex:Am,clipping_planes_vertex:Rm,color_fragment:Cm,color_pars_fragment:Pm,color_pars_vertex:Lm,color_vertex:Im,common:Dm,cube_uv_reflection_fragment:Um,defaultnormal_vertex:Nm,displacementmap_pars_vertex:Om,displacementmap_vertex:Fm,emissivemap_fragment:zm,emissivemap_pars_fragment:Bm,colorspace_fragment:Hm,colorspace_pars_fragment:km,envmap_fragment:Gm,envmap_common_pars_fragment:Vm,envmap_pars_fragment:Wm,envmap_pars_vertex:Xm,envmap_physical_pars_fragment:i0,envmap_vertex:Ym,fog_vertex:qm,fog_pars_vertex:$m,fog_fragment:Zm,fog_pars_fragment:Jm,gradientmap_pars_fragment:Km,lightmap_fragment:jm,lightmap_pars_fragment:Qm,lights_lambert_fragment:t0,lights_lambert_pars_fragment:e0,lights_pars_begin:n0,lights_toon_fragment:s0,lights_toon_pars_fragment:r0,lights_phong_fragment:o0,lights_phong_pars_fragment:a0,lights_physical_fragment:c0,lights_physical_pars_fragment:l0,lights_fragment_begin:h0,lights_fragment_maps:u0,lights_fragment_end:f0,logdepthbuf_fragment:d0,logdepthbuf_pars_fragment:p0,logdepthbuf_pars_vertex:m0,logdepthbuf_vertex:g0,map_fragment:x0,map_pars_fragment:_0,map_particle_fragment:y0,map_particle_pars_fragment:v0,metalnessmap_fragment:M0,metalnessmap_pars_fragment:E0,morphcolor_vertex:S0,morphnormal_vertex:b0,morphtarget_pars_vertex:T0,morphtarget_vertex:w0,normal_fragment_begin:A0,normal_fragment_maps:R0,normal_pars_fragment:C0,normal_pars_vertex:P0,normal_vertex:L0,normalmap_pars_fragment:I0,clearcoat_normal_fragment_begin:D0,clearcoat_normal_fragment_maps:U0,clearcoat_pars_fragment:N0,iridescence_pars_fragment:O0,opaque_fragment:F0,packing:z0,premultiplied_alpha_fragment:B0,project_vertex:H0,dithering_fragment:k0,dithering_pars_fragment:G0,roughnessmap_fragment:V0,roughnessmap_pars_fragment:W0,shadowmap_pars_fragment:X0,shadowmap_pars_vertex:Y0,shadowmap_vertex:q0,shadowmask_pars_fragment:$0,skinbase_vertex:Z0,skinning_pars_vertex:J0,skinning_vertex:K0,skinnormal_vertex:j0,specularmap_fragment:Q0,specularmap_pars_fragment:tg,tonemapping_fragment:eg,tonemapping_pars_fragment:ng,transmission_fragment:ig,transmission_pars_fragment:sg,uv_pars_fragment:rg,uv_pars_vertex:og,uv_vertex:ag,worldpos_vertex:cg,background_vert:lg,background_frag:hg,backgroundCube_vert:ug,backgroundCube_frag:fg,cube_vert:dg,cube_frag:pg,depth_vert:mg,depth_frag:gg,distanceRGBA_vert:xg,distanceRGBA_frag:_g,equirect_vert:yg,equirect_frag:vg,linedashed_vert:Mg,linedashed_frag:Eg,meshbasic_vert:Sg,meshbasic_frag:bg,meshlambert_vert:Tg,meshlambert_frag:wg,meshmatcap_vert:Ag,meshmatcap_frag:Rg,meshnormal_vert:Cg,meshnormal_frag:Pg,meshphong_vert:Lg,meshphong_frag:Ig,meshphysical_vert:Dg,meshphysical_frag:Ug,meshtoon_vert:Ng,meshtoon_frag:Og,points_vert:Fg,points_frag:zg,shadow_vert:Bg,shadow_frag:Hg,sprite_vert:kg,sprite_frag:Gg},pt={common:{diffuse:{value:new Ft(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new ie},alphaMap:{value:null},alphaMapTransform:{value:new ie},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new ie}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new ie}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new ie}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new ie},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new ie},normalScale:{value:new ut(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new ie},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new ie}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new ie}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new ie}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ft(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ft(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new ie},alphaTest:{value:0},uvTransform:{value:new ie}},sprite:{diffuse:{value:new Ft(16777215)},opacity:{value:1},center:{value:new ut(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new ie},alphaMap:{value:null},alphaMapTransform:{value:new ie},alphaTest:{value:0}}},Yn={basic:{uniforms:un([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.fog]),vertexShader:jt.meshbasic_vert,fragmentShader:jt.meshbasic_frag},lambert:{uniforms:un([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,pt.lights,{emissive:{value:new Ft(0)}}]),vertexShader:jt.meshlambert_vert,fragmentShader:jt.meshlambert_frag},phong:{uniforms:un([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,pt.lights,{emissive:{value:new Ft(0)},specular:{value:new Ft(1118481)},shininess:{value:30}}]),vertexShader:jt.meshphong_vert,fragmentShader:jt.meshphong_frag},standard:{uniforms:un([pt.common,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.roughnessmap,pt.metalnessmap,pt.fog,pt.lights,{emissive:{value:new Ft(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:jt.meshphysical_vert,fragmentShader:jt.meshphysical_frag},toon:{uniforms:un([pt.common,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.gradientmap,pt.fog,pt.lights,{emissive:{value:new Ft(0)}}]),vertexShader:jt.meshtoon_vert,fragmentShader:jt.meshtoon_frag},matcap:{uniforms:un([pt.common,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,{matcap:{value:null}}]),vertexShader:jt.meshmatcap_vert,fragmentShader:jt.meshmatcap_frag},points:{uniforms:un([pt.points,pt.fog]),vertexShader:jt.points_vert,fragmentShader:jt.points_frag},dashed:{uniforms:un([pt.common,pt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:jt.linedashed_vert,fragmentShader:jt.linedashed_frag},depth:{uniforms:un([pt.common,pt.displacementmap]),vertexShader:jt.depth_vert,fragmentShader:jt.depth_frag},normal:{uniforms:un([pt.common,pt.bumpmap,pt.normalmap,pt.displacementmap,{opacity:{value:1}}]),vertexShader:jt.meshnormal_vert,fragmentShader:jt.meshnormal_frag},sprite:{uniforms:un([pt.sprite,pt.fog]),vertexShader:jt.sprite_vert,fragmentShader:jt.sprite_frag},background:{uniforms:{uvTransform:{value:new ie},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:jt.background_vert,fragmentShader:jt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:jt.backgroundCube_vert,fragmentShader:jt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:jt.cube_vert,fragmentShader:jt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:jt.equirect_vert,fragmentShader:jt.equirect_frag},distanceRGBA:{uniforms:un([pt.common,pt.displacementmap,{referencePosition:{value:new L},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:jt.distanceRGBA_vert,fragmentShader:jt.distanceRGBA_frag},shadow:{uniforms:un([pt.lights,pt.fog,{color:{value:new Ft(0)},opacity:{value:1}}]),vertexShader:jt.shadow_vert,fragmentShader:jt.shadow_frag}};Yn.physical={uniforms:un([Yn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new ie},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new ie},clearcoatNormalScale:{value:new ut(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new ie},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new ie},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new ie},sheen:{value:0},sheenColor:{value:new Ft(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new ie},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new ie},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new ie},transmissionSamplerSize:{value:new ut},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new ie},attenuationDistance:{value:0},attenuationColor:{value:new Ft(0)},specularColor:{value:new Ft(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new ie},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new ie},anisotropyVector:{value:new ut},anisotropyMap:{value:null},anisotropyMapTransform:{value:new ie}}]),vertexShader:jt.meshphysical_vert,fragmentShader:jt.meshphysical_frag};var No={r:0,b:0,g:0};function Vg(n,t,e,i,s,r,a){let o=new Ft(0),c=r===!0?0:1,l,h,u=null,f=0,d=null;function p(g,m){let S=!1,_=m.isScene===!0?m.background:null;_&&_.isTexture&&(_=(m.backgroundBlurriness>0?e:t).get(_)),_===null?x(o,c):_&&_.isColor&&(x(_,1),S=!0);let b=n.xr.getEnvironmentBlendMode();b==="additive"?i.buffers.color.setClear(0,0,0,1,a):b==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(n.autoClear||S)&&n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil),_&&(_.isCubeTexture||_.mapping===Aa)?(h===void 0&&(h=new It(new ge(1,1,1),new Ln({name:"BackgroundCubeMaterial",uniforms:$s(Yn.backgroundCube.uniforms),vertexShader:Yn.backgroundCube.vertexShader,fragmentShader:Yn.backgroundCube.fragmentShader,side:an,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(C,A,R){this.matrixWorld.copyPosition(R.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),h.material.uniforms.envMap.value=_,h.material.uniforms.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=m.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,h.material.toneMapped=me.getTransfer(_.colorSpace)!==Ee,(u!==_||f!==_.version||d!==n.toneMapping)&&(h.material.needsUpdate=!0,u=_,f=_.version,d=n.toneMapping),h.layers.enableAll(),g.unshift(h,h.geometry,h.material,0,0,null)):_&&_.isTexture&&(l===void 0&&(l=new It(new mn(2,2),new Ln({name:"BackgroundMaterial",uniforms:$s(Yn.background.uniforms),vertexShader:Yn.background.vertexShader,fragmentShader:Yn.background.fragmentShader,side:Di,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(l)),l.material.uniforms.t2D.value=_,l.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,l.material.toneMapped=me.getTransfer(_.colorSpace)!==Ee,_.matrixAutoUpdate===!0&&_.updateMatrix(),l.material.uniforms.uvTransform.value.copy(_.matrix),(u!==_||f!==_.version||d!==n.toneMapping)&&(l.material.needsUpdate=!0,u=_,f=_.version,d=n.toneMapping),l.layers.enableAll(),g.unshift(l,l.geometry,l.material,0,0,null))}function x(g,m){g.getRGB(No,Sf(n)),i.buffers.color.setClear(No.r,No.g,No.b,m,a)}return{getClearColor:function(){return o},setClearColor:function(g,m=1){o.set(g),c=m,x(o,c)},getClearAlpha:function(){return c},setClearAlpha:function(g){c=g,x(o,c)},render:p}}function Wg(n,t,e,i){let s=n.getParameter(n.MAX_VERTEX_ATTRIBS),r=i.isWebGL2?null:t.get("OES_vertex_array_object"),a=i.isWebGL2||r!==null,o={},c=g(null),l=c,h=!1;function u(P,z,G,et,J){let $=!1;if(a){let nt=x(et,G,z);l!==nt&&(l=nt,d(l.object)),$=m(P,et,G,J),$&&S(P,et,G,J)}else{let nt=z.wireframe===!0;(l.geometry!==et.id||l.program!==G.id||l.wireframe!==nt)&&(l.geometry=et.id,l.program=G.id,l.wireframe=nt,$=!0)}J!==null&&e.update(J,n.ELEMENT_ARRAY_BUFFER),($||h)&&(h=!1,F(P,z,G,et),J!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,e.get(J).buffer))}function f(){return i.isWebGL2?n.createVertexArray():r.createVertexArrayOES()}function d(P){return i.isWebGL2?n.bindVertexArray(P):r.bindVertexArrayOES(P)}function p(P){return i.isWebGL2?n.deleteVertexArray(P):r.deleteVertexArrayOES(P)}function x(P,z,G){let et=G.wireframe===!0,J=o[P.id];J===void 0&&(J={},o[P.id]=J);let $=J[z.id];$===void 0&&($={},J[z.id]=$);let nt=$[et];return nt===void 0&&(nt=g(f()),$[et]=nt),nt}function g(P){let z=[],G=[],et=[];for(let J=0;J<s;J++)z[J]=0,G[J]=0,et[J]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:z,enabledAttributes:G,attributeDivisors:et,object:P,attributes:{},index:null}}function m(P,z,G,et){let J=l.attributes,$=z.attributes,nt=0,it=G.getAttributes();for(let _t in it)if(it[_t].location>=0){let K=J[_t],gt=$[_t];if(gt===void 0&&(_t==="instanceMatrix"&&P.instanceMatrix&&(gt=P.instanceMatrix),_t==="instanceColor"&&P.instanceColor&&(gt=P.instanceColor)),K===void 0||K.attribute!==gt||gt&&K.data!==gt.data)return!0;nt++}return l.attributesNum!==nt||l.index!==et}function S(P,z,G,et){let J={},$=z.attributes,nt=0,it=G.getAttributes();for(let _t in it)if(it[_t].location>=0){let K=$[_t];K===void 0&&(_t==="instanceMatrix"&&P.instanceMatrix&&(K=P.instanceMatrix),_t==="instanceColor"&&P.instanceColor&&(K=P.instanceColor));let gt={};gt.attribute=K,K&&K.data&&(gt.data=K.data),J[_t]=gt,nt++}l.attributes=J,l.attributesNum=nt,l.index=et}function _(){let P=l.newAttributes;for(let z=0,G=P.length;z<G;z++)P[z]=0}function b(P){C(P,0)}function C(P,z){let G=l.newAttributes,et=l.enabledAttributes,J=l.attributeDivisors;G[P]=1,et[P]===0&&(n.enableVertexAttribArray(P),et[P]=1),J[P]!==z&&((i.isWebGL2?n:t.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](P,z),J[P]=z)}function A(){let P=l.newAttributes,z=l.enabledAttributes;for(let G=0,et=z.length;G<et;G++)z[G]!==P[G]&&(n.disableVertexAttribArray(G),z[G]=0)}function R(P,z,G,et,J,$,nt){nt===!0?n.vertexAttribIPointer(P,z,G,J,$):n.vertexAttribPointer(P,z,G,et,J,$)}function F(P,z,G,et){if(i.isWebGL2===!1&&(P.isInstancedMesh||et.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;_();let J=et.attributes,$=G.getAttributes(),nt=z.defaultAttributeValues;for(let it in $){let _t=$[it];if(_t.location>=0){let W=J[it];if(W===void 0&&(it==="instanceMatrix"&&P.instanceMatrix&&(W=P.instanceMatrix),it==="instanceColor"&&P.instanceColor&&(W=P.instanceColor)),W!==void 0){let K=W.normalized,gt=W.itemSize,Rt=e.get(W);if(Rt===void 0)continue;let Mt=Rt.buffer,Z=Rt.type,ht=Rt.bytesPerElement,lt=i.isWebGL2===!0&&(Z===n.INT||Z===n.UNSIGNED_INT||W.gpuType===lf);if(W.isInterleavedBufferAttribute){let Et=W.data,w=Et.stride,Q=W.offset;if(Et.isInstancedInterleavedBuffer){for(let X=0;X<_t.locationSize;X++)C(_t.location+X,Et.meshPerAttribute);P.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=Et.meshPerAttribute*Et.count)}else for(let X=0;X<_t.locationSize;X++)b(_t.location+X);n.bindBuffer(n.ARRAY_BUFFER,Mt);for(let X=0;X<_t.locationSize;X++)R(_t.location+X,gt/_t.locationSize,Z,K,w*ht,(Q+gt/_t.locationSize*X)*ht,lt)}else{if(W.isInstancedBufferAttribute){for(let Et=0;Et<_t.locationSize;Et++)C(_t.location+Et,W.meshPerAttribute);P.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=W.meshPerAttribute*W.count)}else for(let Et=0;Et<_t.locationSize;Et++)b(_t.location+Et);n.bindBuffer(n.ARRAY_BUFFER,Mt);for(let Et=0;Et<_t.locationSize;Et++)R(_t.location+Et,gt/_t.locationSize,Z,K,gt*ht,gt/_t.locationSize*Et*ht,lt)}}else if(nt!==void 0){let K=nt[it];if(K!==void 0)switch(K.length){case 2:n.vertexAttrib2fv(_t.location,K);break;case 3:n.vertexAttrib3fv(_t.location,K);break;case 4:n.vertexAttrib4fv(_t.location,K);break;default:n.vertexAttrib1fv(_t.location,K)}}}}A()}function E(){B();for(let P in o){let z=o[P];for(let G in z){let et=z[G];for(let J in et)p(et[J].object),delete et[J];delete z[G]}delete o[P]}}function v(P){if(o[P.id]===void 0)return;let z=o[P.id];for(let G in z){let et=z[G];for(let J in et)p(et[J].object),delete et[J];delete z[G]}delete o[P.id]}function N(P){for(let z in o){let G=o[z];if(G[P.id]===void 0)continue;let et=G[P.id];for(let J in et)p(et[J].object),delete et[J];delete G[P.id]}}function B(){rt(),h=!0,l!==c&&(l=c,d(l.object))}function rt(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:u,reset:B,resetDefaultState:rt,dispose:E,releaseStatesOfGeometry:v,releaseStatesOfProgram:N,initAttributes:_,enableAttribute:b,disableUnusedAttributes:A}}function Xg(n,t,e,i){let s=i.isWebGL2,r;function a(h){r=h}function o(h,u){n.drawArrays(r,h,u),e.update(u,r,1)}function c(h,u,f){if(f===0)return;let d,p;if(s)d=n,p="drawArraysInstanced";else if(d=t.get("ANGLE_instanced_arrays"),p="drawArraysInstancedANGLE",d===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}d[p](r,h,u,f),e.update(u,r,f)}function l(h,u,f){if(f===0)return;let d=t.get("WEBGL_multi_draw");if(d===null)for(let p=0;p<f;p++)this.render(h[p],u[p]);else{d.multiDrawArraysWEBGL(r,h,0,u,0,f);let p=0;for(let x=0;x<f;x++)p+=u[x];e.update(p,r,1)}}this.setMode=a,this.render=o,this.renderInstances=c,this.renderMultiDraw=l}function Yg(n,t,e){let i;function s(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){let R=t.get("EXT_texture_filter_anisotropic");i=n.getParameter(R.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function r(R){if(R==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";R="mediump"}return R==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let a=typeof WebGL2RenderingContext<"u"&&n.constructor.name==="WebGL2RenderingContext",o=e.precision!==void 0?e.precision:"highp",c=r(o);c!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",c,"instead."),o=c);let l=a||t.has("WEBGL_draw_buffers"),h=e.logarithmicDepthBuffer===!0,u=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),f=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),d=n.getParameter(n.MAX_TEXTURE_SIZE),p=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),x=n.getParameter(n.MAX_VERTEX_ATTRIBS),g=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),m=n.getParameter(n.MAX_VARYING_VECTORS),S=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),_=f>0,b=a||t.has("OES_texture_float"),C=_&&b,A=a?n.getParameter(n.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:l,getMaxAnisotropy:s,getMaxPrecision:r,precision:o,logarithmicDepthBuffer:h,maxTextures:u,maxVertexTextures:f,maxTextureSize:d,maxCubemapSize:p,maxAttributes:x,maxVertexUniforms:g,maxVaryings:m,maxFragmentUniforms:S,vertexTextures:_,floatFragmentTextures:b,floatVertexTextures:C,maxSamples:A}}function qg(n){let t=this,e=null,i=0,s=!1,r=!1,a=new oi,o=new ie,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(u,f){let d=u.length!==0||f||i!==0||s;return s=f,i=u.length,d},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,f){e=h(u,f,0)},this.setState=function(u,f,d){let p=u.clippingPlanes,x=u.clipIntersection,g=u.clipShadows,m=n.get(u);if(!s||p===null||p.length===0||r&&!g)r?h(null):l();else{let S=r?0:i,_=S*4,b=m.clippingState||null;c.value=b,b=h(p,f,_,d);for(let C=0;C!==_;++C)b[C]=e[C];m.clippingState=b,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=S}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=i>0),t.numPlanes=i,t.numIntersection=0}function h(u,f,d,p){let x=u!==null?u.length:0,g=null;if(x!==0){if(g=c.value,p!==!0||g===null){let m=d+x*4,S=f.matrixWorldInverse;o.getNormalMatrix(S),(g===null||g.length<m)&&(g=new Float32Array(m));for(let _=0,b=d;_!==x;++_,b+=4)a.copy(u[_]).applyMatrix4(S,o),a.normal.toArray(g,b),g[b+3]=a.constant}c.value=g,c.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,g}}function $g(n){let t=new WeakMap;function e(a,o){return o===Fc?a.mapping=Ws:o===zc&&(a.mapping=Xs),a}function i(a){if(a&&a.isTexture){let o=a.mapping;if(o===Fc||o===zc)if(t.has(a)){let c=t.get(a).texture;return e(c,a.mapping)}else{let c=a.image;if(c&&c.height>0){let l=new Yc(c.height/2);return l.fromEquirectangularTexture(n,a),t.set(a,l),a.addEventListener("dispose",s),e(l.texture,a.mapping)}else return null}}return a}function s(a){let o=a.target;o.removeEventListener("dispose",s);let c=t.get(o);c!==void 0&&(t.delete(o),c.dispose())}function r(){t=new WeakMap}return{get:i,dispose:r}}var ua=class extends la{constructor(t=-1,e=1,i=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=i,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,i,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=i-t,a=i+t,o=s+e,c=s-e;if(this.view!==null&&this.view.enabled){let l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,a=r+l*this.view.width,o-=h*this.view.offsetY,c=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Bs=4,Tu=[.125,.215,.35,.446,.526,.582],$i=20,Tc=new ua,wu=new Ft,wc=null,Ac=0,Rc=0,Yi=(1+Math.sqrt(5))/2,Ds=1/Yi,Au=[new L(1,1,1),new L(-1,1,1),new L(1,1,-1),new L(-1,1,-1),new L(0,Yi,Ds),new L(0,Yi,-Ds),new L(Ds,0,Yi),new L(-Ds,0,Yi),new L(Yi,Ds,0),new L(-Yi,Ds,0)],Zs=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,i=.1,s=100){wc=this._renderer.getRenderTarget(),Ac=this._renderer.getActiveCubeFace(),Rc=this._renderer.getActiveMipmapLevel(),this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,i,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Pu(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Cu(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(wc,Ac,Rc),t.scissorTest=!1,Oo(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===Ws||t.mapping===Xs?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),wc=this._renderer.getRenderTarget(),Ac=this._renderer.getActiveCubeFace(),Rc=this._renderer.getActiveMipmapLevel();let i=e||this._allocateTargets();return this._textureToCubeUV(t,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,i={magFilter:wn,minFilter:wn,generateMipmaps:!1,type:Ur,format:Hn,colorSpace:ci,depthBuffer:!1},s=Ru(t,e,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Ru(t,e,i);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Zg(r)),this._blurMaterial=Jg(r,t,e)}return s}_compileMaterial(t){let e=new It(this._lodPlanes[0],t);this._renderer.compile(e,Tc)}_sceneToCubeUV(t,e,i,s){let o=new fn(90,1,e,i),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,f=h.toneMapping;h.getClearColor(wu),h.toneMapping=Li,h.autoClear=!1;let d=new Pn({name:"PMREM.Background",side:an,depthWrite:!1,depthTest:!1}),p=new It(new ge,d),x=!1,g=t.background;g?g.isColor&&(d.color.copy(g),t.background=null,x=!0):(d.color.copy(wu),x=!0);for(let m=0;m<6;m++){let S=m%3;S===0?(o.up.set(0,c[m],0),o.lookAt(l[m],0,0)):S===1?(o.up.set(0,0,c[m]),o.lookAt(0,l[m],0)):(o.up.set(0,c[m],0),o.lookAt(0,0,l[m]));let _=this._cubeSize;Oo(s,S*_,m>2?_:0,_,_),h.setRenderTarget(s),x&&h.render(p,o),h.render(t,o)}p.geometry.dispose(),p.material.dispose(),h.toneMapping=f,h.autoClear=u,t.background=g}_textureToCubeUV(t,e){let i=this._renderer,s=t.mapping===Ws||t.mapping===Xs;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Pu()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Cu());let r=s?this._cubemapMaterial:this._equirectMaterial,a=new It(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=t;let c=this._cubeSize;Oo(e,0,0,3*c,2*c),i.setRenderTarget(e),i.render(a,Tc)}_applyPMREM(t){let e=this._renderer,i=e.autoClear;e.autoClear=!1;for(let s=1;s<this._lodPlanes.length;s++){let r=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),a=Au[(s-1)%Au.length];this._blur(t,s-1,s,r,a)}e.autoClear=i}_blur(t,e,i,s,r){let a=this._pingPongRenderTarget;this._halfBlur(t,a,e,i,s,"latitudinal",r),this._halfBlur(a,t,i,i,s,"longitudinal",r)}_halfBlur(t,e,i,s,r,a,o){let c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new It(this._lodPlanes[s],l),f=l.uniforms,d=this._sizeLods[i]-1,p=isFinite(r)?Math.PI/(2*d):2*Math.PI/(2*$i-1),x=r/p,g=isFinite(r)?1+Math.floor(h*x):$i;g>$i&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${$i}`);let m=[],S=0;for(let R=0;R<$i;++R){let F=R/x,E=Math.exp(-F*F/2);m.push(E),R===0?S+=E:R<g&&(S+=2*E)}for(let R=0;R<m.length;R++)m[R]=m[R]/S;f.envMap.value=t.texture,f.samples.value=g,f.weights.value=m,f.latitudinal.value=a==="latitudinal",o&&(f.poleAxis.value=o);let{_lodMax:_}=this;f.dTheta.value=p,f.mipInt.value=_-i;let b=this._sizeLods[s],C=3*b*(s>_-Bs?s-_+Bs:0),A=4*(this._cubeSize-b);Oo(e,C,A,3*b,2*b),c.setRenderTarget(e),c.render(u,Tc)}};function Zg(n){let t=[],e=[],i=[],s=n,r=n-Bs+1+Tu.length;for(let a=0;a<r;a++){let o=Math.pow(2,s);e.push(o);let c=1/o;a>n-Bs?c=Tu[a-n+Bs-1]:a===0&&(c=0),i.push(c);let l=1/(o-2),h=-l,u=1+l,f=[h,h,u,h,u,u,h,h,u,u,h,u],d=6,p=6,x=3,g=2,m=1,S=new Float32Array(x*p*d),_=new Float32Array(g*p*d),b=new Float32Array(m*p*d);for(let A=0;A<d;A++){let R=A%3*2/3-1,F=A>2?0:-1,E=[R,F,0,R+2/3,F,0,R+2/3,F+1,0,R,F,0,R+2/3,F+1,0,R,F+1,0];S.set(E,x*p*A),_.set(f,g*p*A);let v=[A,A,A,A,A,A];b.set(v,m*p*A)}let C=new Le;C.setAttribute("position",new we(S,x)),C.setAttribute("uv",new we(_,g)),C.setAttribute("faceIndex",new we(b,m)),t.push(C),s>Bs&&s--}return{lodPlanes:t,sizeLods:e,sigmas:i}}function Ru(n,t,e){let i=new li(n,t,e);return i.texture.mapping=Aa,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Oo(n,t,e,i,s){n.viewport.set(t,e,i,s),n.scissor.set(t,e,i,s)}function Jg(n,t,e){let i=new Float32Array($i),s=new L(0,1,0);return new Ln({name:"SphericalGaussianBlur",defines:{n:$i,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Il(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Ci,depthTest:!1,depthWrite:!1})}function Cu(){return new Ln({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Il(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ci,depthTest:!1,depthWrite:!1})}function Pu(){return new Ln({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Il(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ci,depthTest:!1,depthWrite:!1})}function Il(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Kg(n){let t=new WeakMap,e=null;function i(o){if(o&&o.isTexture){let c=o.mapping,l=c===Fc||c===zc,h=c===Ws||c===Xs;if(l||h)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let u=t.get(o);return e===null&&(e=new Zs(n)),u=l?e.fromEquirectangular(o,u):e.fromCubemap(o,u),t.set(o,u),u.texture}else{if(t.has(o))return t.get(o).texture;{let u=o.image;if(l&&u&&u.height>0||h&&u&&s(u)){e===null&&(e=new Zs(n));let f=l?e.fromEquirectangular(o):e.fromCubemap(o);return t.set(o,f),o.addEventListener("dispose",r),f.texture}else return null}}}return o}function s(o){let c=0,l=6;for(let h=0;h<l;h++)o[h]!==void 0&&c++;return c===l}function r(o){let c=o.target;c.removeEventListener("dispose",r);let l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:i,dispose:a}}function jg(n){let t={};function e(i){if(t[i]!==void 0)return t[i];let s;switch(i){case"WEBGL_depth_texture":s=n.getExtension("WEBGL_depth_texture")||n.getExtension("MOZ_WEBGL_depth_texture")||n.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=n.getExtension("EXT_texture_filter_anisotropic")||n.getExtension("MOZ_EXT_texture_filter_anisotropic")||n.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=n.getExtension("WEBGL_compressed_texture_s3tc")||n.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=n.getExtension("WEBGL_compressed_texture_pvrtc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=n.getExtension(i)}return t[i]=s,s}return{has:function(i){return e(i)!==null},init:function(i){i.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(i){let s=e(i);return s===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),s}}}function Qg(n,t,e,i){let s={},r=new WeakMap;function a(u){let f=u.target;f.index!==null&&t.remove(f.index);for(let p in f.attributes)t.remove(f.attributes[p]);for(let p in f.morphAttributes){let x=f.morphAttributes[p];for(let g=0,m=x.length;g<m;g++)t.remove(x[g])}f.removeEventListener("dispose",a),delete s[f.id];let d=r.get(f);d&&(t.remove(d),r.delete(f)),i.releaseStatesOfGeometry(f),f.isInstancedBufferGeometry===!0&&delete f._maxInstanceCount,e.memory.geometries--}function o(u,f){return s[f.id]===!0||(f.addEventListener("dispose",a),s[f.id]=!0,e.memory.geometries++),f}function c(u){let f=u.attributes;for(let p in f)t.update(f[p],n.ARRAY_BUFFER);let d=u.morphAttributes;for(let p in d){let x=d[p];for(let g=0,m=x.length;g<m;g++)t.update(x[g],n.ARRAY_BUFFER)}}function l(u){let f=[],d=u.index,p=u.attributes.position,x=0;if(d!==null){let S=d.array;x=d.version;for(let _=0,b=S.length;_<b;_+=3){let C=S[_+0],A=S[_+1],R=S[_+2];f.push(C,A,A,R,R,C)}}else if(p!==void 0){let S=p.array;x=p.version;for(let _=0,b=S.length/3-1;_<b;_+=3){let C=_+0,A=_+1,R=_+2;f.push(C,A,A,R,R,C)}}else return;let g=new(Mf(f)?ca:aa)(f,1);g.version=x;let m=r.get(u);m&&t.remove(m),r.set(u,g)}function h(u){let f=r.get(u);if(f){let d=u.index;d!==null&&f.version<d.version&&l(u)}else l(u);return r.get(u)}return{get:o,update:c,getWireframeAttribute:h}}function tx(n,t,e,i){let s=i.isWebGL2,r;function a(d){r=d}let o,c;function l(d){o=d.type,c=d.bytesPerElement}function h(d,p){n.drawElements(r,p,o,d*c),e.update(p,r,1)}function u(d,p,x){if(x===0)return;let g,m;if(s)g=n,m="drawElementsInstanced";else if(g=t.get("ANGLE_instanced_arrays"),m="drawElementsInstancedANGLE",g===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}g[m](r,p,o,d*c,x),e.update(p,r,x)}function f(d,p,x){if(x===0)return;let g=t.get("WEBGL_multi_draw");if(g===null)for(let m=0;m<x;m++)this.render(d[m]/c,p[m]);else{g.multiDrawElementsWEBGL(r,p,0,o,d,0,x);let m=0;for(let S=0;S<x;S++)m+=p[S];e.update(m,r,1)}}this.setMode=a,this.setIndex=l,this.render=h,this.renderInstances=u,this.renderMultiDraw=f}function ex(n){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,a,o){switch(e.calls++,a){case n.TRIANGLES:e.triangles+=o*(r/3);break;case n.LINES:e.lines+=o*(r/2);break;case n.LINE_STRIP:e.lines+=o*(r-1);break;case n.LINE_LOOP:e.lines+=o*r;break;case n.POINTS:e.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:i}}function nx(n,t){return n[0]-t[0]}function ix(n,t){return Math.abs(t[1])-Math.abs(n[1])}function sx(n,t,e){let i={},s=new Float32Array(8),r=new WeakMap,a=new Je,o=[];for(let l=0;l<8;l++)o[l]=[l,0];function c(l,h,u){let f=l.morphTargetInfluences;if(t.isWebGL2===!0){let d=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,p=d!==void 0?d.length:0,x=r.get(h);if(x===void 0||x.count!==p){let P=function(){B.dispose(),r.delete(h),h.removeEventListener("dispose",P)};x!==void 0&&x.texture.dispose();let S=h.morphAttributes.position!==void 0,_=h.morphAttributes.normal!==void 0,b=h.morphAttributes.color!==void 0,C=h.morphAttributes.position||[],A=h.morphAttributes.normal||[],R=h.morphAttributes.color||[],F=0;S===!0&&(F=1),_===!0&&(F=2),b===!0&&(F=3);let E=h.attributes.position.count*F,v=1;E>t.maxTextureSize&&(v=Math.ceil(E/t.maxTextureSize),E=t.maxTextureSize);let N=new Float32Array(E*v*4*p),B=new sa(N,E,v,p);B.type=Ri,B.needsUpdate=!0;let rt=F*4;for(let z=0;z<p;z++){let G=C[z],et=A[z],J=R[z],$=E*v*4*z;for(let nt=0;nt<G.count;nt++){let it=nt*rt;S===!0&&(a.fromBufferAttribute(G,nt),N[$+it+0]=a.x,N[$+it+1]=a.y,N[$+it+2]=a.z,N[$+it+3]=0),_===!0&&(a.fromBufferAttribute(et,nt),N[$+it+4]=a.x,N[$+it+5]=a.y,N[$+it+6]=a.z,N[$+it+7]=0),b===!0&&(a.fromBufferAttribute(J,nt),N[$+it+8]=a.x,N[$+it+9]=a.y,N[$+it+10]=a.z,N[$+it+11]=J.itemSize===4?a.w:1)}}x={count:p,texture:B,size:new ut(E,v)},r.set(h,x),h.addEventListener("dispose",P)}let g=0;for(let S=0;S<f.length;S++)g+=f[S];let m=h.morphTargetsRelative?1:1-g;u.getUniforms().setValue(n,"morphTargetBaseInfluence",m),u.getUniforms().setValue(n,"morphTargetInfluences",f),u.getUniforms().setValue(n,"morphTargetsTexture",x.texture,e),u.getUniforms().setValue(n,"morphTargetsTextureSize",x.size)}else{let d=f===void 0?0:f.length,p=i[h.id];if(p===void 0||p.length!==d){p=[];for(let _=0;_<d;_++)p[_]=[_,0];i[h.id]=p}for(let _=0;_<d;_++){let b=p[_];b[0]=_,b[1]=f[_]}p.sort(ix);for(let _=0;_<8;_++)_<d&&p[_][1]?(o[_][0]=p[_][0],o[_][1]=p[_][1]):(o[_][0]=Number.MAX_SAFE_INTEGER,o[_][1]=0);o.sort(nx);let x=h.morphAttributes.position,g=h.morphAttributes.normal,m=0;for(let _=0;_<8;_++){let b=o[_],C=b[0],A=b[1];C!==Number.MAX_SAFE_INTEGER&&A?(x&&h.getAttribute("morphTarget"+_)!==x[C]&&h.setAttribute("morphTarget"+_,x[C]),g&&h.getAttribute("morphNormal"+_)!==g[C]&&h.setAttribute("morphNormal"+_,g[C]),s[_]=A,m+=A):(x&&h.hasAttribute("morphTarget"+_)===!0&&h.deleteAttribute("morphTarget"+_),g&&h.hasAttribute("morphNormal"+_)===!0&&h.deleteAttribute("morphNormal"+_),s[_]=0)}let S=h.morphTargetsRelative?1:1-m;u.getUniforms().setValue(n,"morphTargetBaseInfluence",S),u.getUniforms().setValue(n,"morphTargetInfluences",s)}}return{update:c}}function rx(n,t,e,i){let s=new WeakMap;function r(c){let l=i.render.frame,h=c.geometry,u=t.get(c,h);if(s.get(u)!==l&&(t.update(u),s.set(u,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",o)===!1&&c.addEventListener("dispose",o),s.get(c)!==l&&(e.update(c.instanceMatrix,n.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,n.ARRAY_BUFFER),s.set(c,l))),c.isSkinnedMesh){let f=c.skeleton;s.get(f)!==l&&(f.update(),s.set(f,l))}return u}function a(){s=new WeakMap}function o(c){let l=c.target;l.removeEventListener("dispose",o),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:r,dispose:a}}var fa=class extends Rn{constructor(t,e,i,s,r,a,o,c,l,h){if(h=h!==void 0?h:Ki,h!==Ki&&h!==Ys)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&h===Ki&&(i=Ai),i===void 0&&h===Ys&&(i=Ji),super(null,s,r,a,o,c,h,i,l),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=o!==void 0?o:Ze,this.minFilter=c!==void 0?c:Ze,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},Tf=new Rn,wf=new fa(1,1);wf.compareFunction=_f;var Af=new sa,Rf=new Wc,Cf=new ha,Lu=[],Iu=[],Du=new Float32Array(16),Uu=new Float32Array(9),Nu=new Float32Array(4);function tr(n,t,e){let i=n[0];if(i<=0||i>0)return n;let s=t*e,r=Lu[s];if(r===void 0&&(r=new Float32Array(s),Lu[s]=r),t!==0){i.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,n[a].toArray(r,o)}return r}function Ve(n,t){if(n.length!==t.length)return!1;for(let e=0,i=n.length;e<i;e++)if(n[e]!==t[e])return!1;return!0}function We(n,t){for(let e=0,i=t.length;e<i;e++)n[e]=t[e]}function Ca(n,t){let e=Iu[t];e===void 0&&(e=new Int32Array(t),Iu[t]=e);for(let i=0;i!==t;++i)e[i]=n.allocateTextureUnit();return e}function ox(n,t){let e=this.cache;e[0]!==t&&(n.uniform1f(this.addr,t),e[0]=t)}function ax(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;n.uniform2fv(this.addr,t),We(e,t)}}function cx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(n.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Ve(e,t))return;n.uniform3fv(this.addr,t),We(e,t)}}function lx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;n.uniform4fv(this.addr,t),We(e,t)}}function hx(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(Ve(e,t))return;n.uniformMatrix2fv(this.addr,!1,t),We(e,t)}else{if(Ve(e,i))return;Nu.set(i),n.uniformMatrix2fv(this.addr,!1,Nu),We(e,i)}}function ux(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(Ve(e,t))return;n.uniformMatrix3fv(this.addr,!1,t),We(e,t)}else{if(Ve(e,i))return;Uu.set(i),n.uniformMatrix3fv(this.addr,!1,Uu),We(e,i)}}function fx(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(Ve(e,t))return;n.uniformMatrix4fv(this.addr,!1,t),We(e,t)}else{if(Ve(e,i))return;Du.set(i),n.uniformMatrix4fv(this.addr,!1,Du),We(e,i)}}function dx(n,t){let e=this.cache;e[0]!==t&&(n.uniform1i(this.addr,t),e[0]=t)}function px(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;n.uniform2iv(this.addr,t),We(e,t)}}function mx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ve(e,t))return;n.uniform3iv(this.addr,t),We(e,t)}}function gx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;n.uniform4iv(this.addr,t),We(e,t)}}function xx(n,t){let e=this.cache;e[0]!==t&&(n.uniform1ui(this.addr,t),e[0]=t)}function _x(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;n.uniform2uiv(this.addr,t),We(e,t)}}function yx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ve(e,t))return;n.uniform3uiv(this.addr,t),We(e,t)}}function vx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;n.uniform4uiv(this.addr,t),We(e,t)}}function Mx(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s);let r=this.type===n.SAMPLER_2D_SHADOW?wf:Tf;e.setTexture2D(t||r,s)}function Ex(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTexture3D(t||Rf,s)}function Sx(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTextureCube(t||Cf,s)}function bx(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTexture2DArray(t||Af,s)}function Tx(n){switch(n){case 5126:return ox;case 35664:return ax;case 35665:return cx;case 35666:return lx;case 35674:return hx;case 35675:return ux;case 35676:return fx;case 5124:case 35670:return dx;case 35667:case 35671:return px;case 35668:case 35672:return mx;case 35669:case 35673:return gx;case 5125:return xx;case 36294:return _x;case 36295:return yx;case 36296:return vx;case 35678:case 36198:case 36298:case 36306:case 35682:return Mx;case 35679:case 36299:case 36307:return Ex;case 35680:case 36300:case 36308:case 36293:return Sx;case 36289:case 36303:case 36311:case 36292:return bx}}function wx(n,t){n.uniform1fv(this.addr,t)}function Ax(n,t){let e=tr(t,this.size,2);n.uniform2fv(this.addr,e)}function Rx(n,t){let e=tr(t,this.size,3);n.uniform3fv(this.addr,e)}function Cx(n,t){let e=tr(t,this.size,4);n.uniform4fv(this.addr,e)}function Px(n,t){let e=tr(t,this.size,4);n.uniformMatrix2fv(this.addr,!1,e)}function Lx(n,t){let e=tr(t,this.size,9);n.uniformMatrix3fv(this.addr,!1,e)}function Ix(n,t){let e=tr(t,this.size,16);n.uniformMatrix4fv(this.addr,!1,e)}function Dx(n,t){n.uniform1iv(this.addr,t)}function Ux(n,t){n.uniform2iv(this.addr,t)}function Nx(n,t){n.uniform3iv(this.addr,t)}function Ox(n,t){n.uniform4iv(this.addr,t)}function Fx(n,t){n.uniform1uiv(this.addr,t)}function zx(n,t){n.uniform2uiv(this.addr,t)}function Bx(n,t){n.uniform3uiv(this.addr,t)}function Hx(n,t){n.uniform4uiv(this.addr,t)}function kx(n,t,e){let i=this.cache,s=t.length,r=Ca(e,s);Ve(i,r)||(n.uniform1iv(this.addr,r),We(i,r));for(let a=0;a!==s;++a)e.setTexture2D(t[a]||Tf,r[a])}function Gx(n,t,e){let i=this.cache,s=t.length,r=Ca(e,s);Ve(i,r)||(n.uniform1iv(this.addr,r),We(i,r));for(let a=0;a!==s;++a)e.setTexture3D(t[a]||Rf,r[a])}function Vx(n,t,e){let i=this.cache,s=t.length,r=Ca(e,s);Ve(i,r)||(n.uniform1iv(this.addr,r),We(i,r));for(let a=0;a!==s;++a)e.setTextureCube(t[a]||Cf,r[a])}function Wx(n,t,e){let i=this.cache,s=t.length,r=Ca(e,s);Ve(i,r)||(n.uniform1iv(this.addr,r),We(i,r));for(let a=0;a!==s;++a)e.setTexture2DArray(t[a]||Af,r[a])}function Xx(n){switch(n){case 5126:return wx;case 35664:return Ax;case 35665:return Rx;case 35666:return Cx;case 35674:return Px;case 35675:return Lx;case 35676:return Ix;case 5124:case 35670:return Dx;case 35667:case 35671:return Ux;case 35668:case 35672:return Nx;case 35669:case 35673:return Ox;case 5125:return Fx;case 36294:return zx;case 36295:return Bx;case 36296:return Hx;case 35678:case 36198:case 36298:case 36306:case 35682:return kx;case 35679:case 36299:case 36307:return Gx;case 35680:case 36300:case 36308:case 36293:return Vx;case 36289:case 36303:case 36311:case 36292:return Wx}}var qc=class{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.setValue=Tx(e.type)}},$c=class{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Xx(e.type)}},Zc=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,i){let s=this.seq;for(let r=0,a=s.length;r!==a;++r){let o=s[r];o.setValue(t,e[o.id],i)}}},Cc=/(\w+)(\])?(\[|\.)?/g;function Ou(n,t){n.seq.push(t),n.map[t.id]=t}function Yx(n,t,e){let i=n.name,s=i.length;for(Cc.lastIndex=0;;){let r=Cc.exec(i),a=Cc.lastIndex,o=r[1],c=r[2]==="]",l=r[3];if(c&&(o=o|0),l===void 0||l==="["&&a+2===s){Ou(e,l===void 0?new qc(o,n,t):new $c(o,n,t));break}else{let u=e.map[o];u===void 0&&(u=new Zc(o),Ou(e,u)),e=u}}}var Vs=class{constructor(t,e){this.seq=[],this.map={};let i=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<i;++s){let r=t.getActiveUniform(e,s),a=t.getUniformLocation(e,r.name);Yx(r,a,this)}}setValue(t,e,i,s){let r=this.map[e];r!==void 0&&r.setValue(t,i,s)}setOptional(t,e,i){let s=e[i];s!==void 0&&this.setValue(t,i,s)}static upload(t,e,i,s){for(let r=0,a=e.length;r!==a;++r){let o=e[r],c=i[o.id];c.needsUpdate!==!1&&o.setValue(t,c.value,s)}}static seqWithValue(t,e){let i=[];for(let s=0,r=t.length;s!==r;++s){let a=t[s];a.id in e&&i.push(a)}return i}};function Fu(n,t,e){let i=n.createShader(t);return n.shaderSource(i,e),n.compileShader(i),i}var qx=37297,$x=0;function Zx(n,t){let e=n.split(`
`),i=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=s;a<r;a++){let o=a+1;i.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return i.join(`
`)}function Jx(n){let t=me.getPrimaries(me.workingColorSpace),e=me.getPrimaries(n),i;switch(t===e?i="":t===jo&&e===Ko?i="LinearDisplayP3ToLinearSRGB":t===Ko&&e===jo&&(i="LinearSRGBToLinearDisplayP3"),n){case ci:case Ra:return[i,"LinearTransferOETF"];case Ce:case Pl:return[i,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",n),[i,"LinearTransferOETF"]}}function zu(n,t,e){let i=n.getShaderParameter(t,n.COMPILE_STATUS),s=n.getShaderInfoLog(t).trim();if(i&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let a=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+Zx(n.getShaderSource(t),a)}else return s}function Kx(n,t){let e=Jx(t);return`vec4 ${n}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function jx(n,t){let e;switch(t){case sp:e="Linear";break;case rp:e="Reinhard";break;case op:e="OptimizedCineon";break;case Rl:e="ACESFilmic";break;case cp:e="AgX";break;case ap:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+n+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function Qx(n){return[n.extensionDerivatives||n.envMapCubeUVHeight||n.bumpMap||n.normalMapTangentSpace||n.clearcoatNormalMap||n.flatShading||n.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(n.extensionFragDepth||n.logarithmicDepthBuffer)&&n.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",n.extensionDrawBuffers&&n.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(n.extensionShaderTextureLOD||n.envMap||n.transmission)&&n.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Hs).join(`
`)}function t_(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(Hs).join(`
`)}function e_(n){let t=[];for(let e in n){let i=n[e];i!==!1&&t.push("#define "+e+" "+i)}return t.join(`
`)}function n_(n,t){let e={},i=n.getProgramParameter(t,n.ACTIVE_ATTRIBUTES);for(let s=0;s<i;s++){let r=n.getActiveAttrib(t,s),a=r.name,o=1;r.type===n.FLOAT_MAT2&&(o=2),r.type===n.FLOAT_MAT3&&(o=3),r.type===n.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:n.getAttribLocation(t,a),locationSize:o}}return e}function Hs(n){return n!==""}function Bu(n,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Hu(n,t){return n.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var i_=/^[ \t]*#include +<([\w\d./]+)>/gm;function Jc(n){return n.replace(i_,r_)}var s_=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function r_(n,t){let e=jt[t];if(e===void 0){let i=s_.get(t);if(i!==void 0)e=jt[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,i);else throw new Error("Can not resolve #include <"+t+">")}return Jc(e)}var o_=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function ku(n){return n.replace(o_,a_)}function a_(n,t,e,i){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Gu(n){let t="precision "+n.precision+` float;
precision `+n.precision+" int;";return n.precision==="highp"?t+=`
#define HIGH_PRECISION`:n.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function c_(n){let t="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===of?t="SHADOWMAP_TYPE_PCF":n.shadowMapType===Al?t="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===ri&&(t="SHADOWMAP_TYPE_VSM"),t}function l_(n){let t="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case Ws:case Xs:t="ENVMAP_TYPE_CUBE";break;case Aa:t="ENVMAP_TYPE_CUBE_UV";break}return t}function h_(n){let t="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case Xs:t="ENVMAP_MODE_REFRACTION";break}return t}function u_(n){let t="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case af:t="ENVMAP_BLENDING_MULTIPLY";break;case np:t="ENVMAP_BLENDING_MIX";break;case ip:t="ENVMAP_BLENDING_ADD";break}return t}function f_(n){let t=n.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,i=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:i,maxMip:e}}function d_(n,t,e,i){let s=n.getContext(),r=e.defines,a=e.vertexShader,o=e.fragmentShader,c=c_(e),l=l_(e),h=h_(e),u=u_(e),f=f_(e),d=e.isWebGL2?"":Qx(e),p=t_(e),x=e_(r),g=s.createProgram(),m,S,_=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(Hs).join(`
`),m.length>0&&(m+=`
`),S=[d,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(Hs).join(`
`),S.length>0&&(S+=`
`)):(m=[Gu(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Hs).join(`
`),S=[d,Gu(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",f?"#define CUBEUV_TEXEL_WIDTH "+f.texelWidth:"",f?"#define CUBEUV_TEXEL_HEIGHT "+f.texelHeight:"",f?"#define CUBEUV_MAX_MIP "+f.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Li?"#define TONE_MAPPING":"",e.toneMapping!==Li?jt.tonemapping_pars_fragment:"",e.toneMapping!==Li?jx("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",jt.colorspace_pars_fragment,Kx("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Hs).join(`
`)),a=Jc(a),a=Bu(a,e),a=Hu(a,e),o=Jc(o),o=Bu(o,e),o=Hu(o,e),a=ku(a),o=ku(o),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(_=`#version 300 es
`,m=[p,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,S=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===au?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===au?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+S);let b=_+m+a,C=_+S+o,A=Fu(s,s.VERTEX_SHADER,b),R=Fu(s,s.FRAGMENT_SHADER,C);s.attachShader(g,A),s.attachShader(g,R),e.index0AttributeName!==void 0?s.bindAttribLocation(g,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(g,0,"position"),s.linkProgram(g);function F(B){if(n.debug.checkShaderErrors){let rt=s.getProgramInfoLog(g).trim(),P=s.getShaderInfoLog(A).trim(),z=s.getShaderInfoLog(R).trim(),G=!0,et=!0;if(s.getProgramParameter(g,s.LINK_STATUS)===!1)if(G=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(s,g,A,R);else{let J=zu(s,A,"vertex"),$=zu(s,R,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(g,s.VALIDATE_STATUS)+`

Program Info Log: `+rt+`
`+J+`
`+$)}else rt!==""?console.warn("THREE.WebGLProgram: Program Info Log:",rt):(P===""||z==="")&&(et=!1);et&&(B.diagnostics={runnable:G,programLog:rt,vertexShader:{log:P,prefix:m},fragmentShader:{log:z,prefix:S}})}s.deleteShader(A),s.deleteShader(R),E=new Vs(s,g),v=n_(s,g)}let E;this.getUniforms=function(){return E===void 0&&F(this),E};let v;this.getAttributes=function(){return v===void 0&&F(this),v};let N=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return N===!1&&(N=s.getProgramParameter(g,qx)),N},this.destroy=function(){i.releaseStatesOfProgram(this),s.deleteProgram(g),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=$x++,this.cacheKey=t,this.usedTimes=1,this.program=g,this.vertexShader=A,this.fragmentShader=R,this}var p_=0,Kc=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,i=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(i),a=this._getShaderCacheForMaterial(t);return a.has(s)===!1&&(a.add(s),s.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let i of e)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,i=e.get(t);return i===void 0&&(i=new Set,e.set(t,i)),i}_getShaderStage(t){let e=this.shaderCache,i=e.get(t);return i===void 0&&(i=new jc(t),e.set(t,i)),i}},jc=class{constructor(t){this.id=p_++,this.code=t,this.usedTimes=0}};function m_(n,t,e,i,s,r,a){let o=new oa,c=new Kc,l=[],h=s.isWebGL2,u=s.logarithmicDepthBuffer,f=s.vertexTextures,d=s.precision,p={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(E){return E===0?"uv":`uv${E}`}function g(E,v,N,B,rt){let P=B.fog,z=rt.geometry,G=E.isMeshStandardMaterial?B.environment:null,et=(E.isMeshStandardMaterial?e:t).get(E.envMap||G),J=et&&et.mapping===Aa?et.image.height:null,$=p[E.type];E.precision!==null&&(d=s.getMaxPrecision(E.precision),d!==E.precision&&console.warn("THREE.WebGLProgram.getParameters:",E.precision,"not supported, using",d,"instead."));let nt=z.morphAttributes.position||z.morphAttributes.normal||z.morphAttributes.color,it=nt!==void 0?nt.length:0,_t=0;z.morphAttributes.position!==void 0&&(_t=1),z.morphAttributes.normal!==void 0&&(_t=2),z.morphAttributes.color!==void 0&&(_t=3);let W,K,gt,Rt;if($){let cn=Yn[$];W=cn.vertexShader,K=cn.fragmentShader}else W=E.vertexShader,K=E.fragmentShader,c.update(E),gt=c.getVertexShaderID(E),Rt=c.getFragmentShaderID(E);let Mt=n.getRenderTarget(),Z=rt.isInstancedMesh===!0,ht=rt.isBatchedMesh===!0,lt=!!E.map,Et=!!E.matcap,w=!!et,Q=!!E.aoMap,X=!!E.lightMap,ot=!!E.bumpMap,I=!!E.normalMap,Y=!!E.displacementMap,q=!!E.emissiveMap,M=!!E.metalnessMap,y=!!E.roughnessMap,U=E.anisotropy>0,tt=E.clearcoat>0,j=E.iridescence>0,st=E.sheen>0,Ct=E.transmission>0,xt=U&&!!E.anisotropyMap,bt=tt&&!!E.clearcoatMap,Bt=tt&&!!E.clearcoatNormalMap,$t=tt&&!!E.clearcoatRoughnessMap,at=j&&!!E.iridescenceMap,le=j&&!!E.iridescenceThicknessMap,se=st&&!!E.sheenColorMap,Xt=st&&!!E.sheenRoughnessMap,Ot=!!E.specularMap,Pt=!!E.specularColorMap,Kt=!!E.specularIntensityMap,fe=Ct&&!!E.transmissionMap,Ie=Ct&&!!E.thicknessMap,ee=!!E.gradientMap,dt=!!E.alphaMap,D=E.alphaTest>0,yt=!!E.alphaHash,vt=!!E.extensions,Gt=!!z.attributes.uv1,Ht=!!z.attributes.uv2,_e=!!z.attributes.uv3,ye=Li;return E.toneMapped&&(Mt===null||Mt.isXRRenderTarget===!0)&&(ye=n.toneMapping),{isWebGL2:h,shaderID:$,shaderType:E.type,shaderName:E.name,vertexShader:W,fragmentShader:K,defines:E.defines,customVertexShaderID:gt,customFragmentShaderID:Rt,isRawShaderMaterial:E.isRawShaderMaterial===!0,glslVersion:E.glslVersion,precision:d,batching:ht,instancing:Z,instancingColor:Z&&rt.instanceColor!==null,supportsVertexTextures:f,outputColorSpace:Mt===null?n.outputColorSpace:Mt.isXRRenderTarget===!0?Mt.texture.colorSpace:ci,map:lt,matcap:Et,envMap:w,envMapMode:w&&et.mapping,envMapCubeUVHeight:J,aoMap:Q,lightMap:X,bumpMap:ot,normalMap:I,displacementMap:f&&Y,emissiveMap:q,normalMapObjectSpace:I&&E.normalMapType===vp,normalMapTangentSpace:I&&E.normalMapType===xf,metalnessMap:M,roughnessMap:y,anisotropy:U,anisotropyMap:xt,clearcoat:tt,clearcoatMap:bt,clearcoatNormalMap:Bt,clearcoatRoughnessMap:$t,iridescence:j,iridescenceMap:at,iridescenceThicknessMap:le,sheen:st,sheenColorMap:se,sheenRoughnessMap:Xt,specularMap:Ot,specularColorMap:Pt,specularIntensityMap:Kt,transmission:Ct,transmissionMap:fe,thicknessMap:Ie,gradientMap:ee,opaque:E.transparent===!1&&E.blending===Pi,alphaMap:dt,alphaTest:D,alphaHash:yt,combine:E.combine,mapUv:lt&&x(E.map.channel),aoMapUv:Q&&x(E.aoMap.channel),lightMapUv:X&&x(E.lightMap.channel),bumpMapUv:ot&&x(E.bumpMap.channel),normalMapUv:I&&x(E.normalMap.channel),displacementMapUv:Y&&x(E.displacementMap.channel),emissiveMapUv:q&&x(E.emissiveMap.channel),metalnessMapUv:M&&x(E.metalnessMap.channel),roughnessMapUv:y&&x(E.roughnessMap.channel),anisotropyMapUv:xt&&x(E.anisotropyMap.channel),clearcoatMapUv:bt&&x(E.clearcoatMap.channel),clearcoatNormalMapUv:Bt&&x(E.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:$t&&x(E.clearcoatRoughnessMap.channel),iridescenceMapUv:at&&x(E.iridescenceMap.channel),iridescenceThicknessMapUv:le&&x(E.iridescenceThicknessMap.channel),sheenColorMapUv:se&&x(E.sheenColorMap.channel),sheenRoughnessMapUv:Xt&&x(E.sheenRoughnessMap.channel),specularMapUv:Ot&&x(E.specularMap.channel),specularColorMapUv:Pt&&x(E.specularColorMap.channel),specularIntensityMapUv:Kt&&x(E.specularIntensityMap.channel),transmissionMapUv:fe&&x(E.transmissionMap.channel),thicknessMapUv:Ie&&x(E.thicknessMap.channel),alphaMapUv:dt&&x(E.alphaMap.channel),vertexTangents:!!z.attributes.tangent&&(I||U),vertexColors:E.vertexColors,vertexAlphas:E.vertexColors===!0&&!!z.attributes.color&&z.attributes.color.itemSize===4,vertexUv1s:Gt,vertexUv2s:Ht,vertexUv3s:_e,pointsUvs:rt.isPoints===!0&&!!z.attributes.uv&&(lt||dt),fog:!!P,useFog:E.fog===!0,fogExp2:P&&P.isFogExp2,flatShading:E.flatShading===!0,sizeAttenuation:E.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:rt.isSkinnedMesh===!0,morphTargets:z.morphAttributes.position!==void 0,morphNormals:z.morphAttributes.normal!==void 0,morphColors:z.morphAttributes.color!==void 0,morphTargetsCount:it,morphTextureStride:_t,numDirLights:v.directional.length,numPointLights:v.point.length,numSpotLights:v.spot.length,numSpotLightMaps:v.spotLightMap.length,numRectAreaLights:v.rectArea.length,numHemiLights:v.hemi.length,numDirLightShadows:v.directionalShadowMap.length,numPointLightShadows:v.pointShadowMap.length,numSpotLightShadows:v.spotShadowMap.length,numSpotLightShadowsWithMaps:v.numSpotLightShadowsWithMaps,numLightProbes:v.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:E.dithering,shadowMapEnabled:n.shadowMap.enabled&&N.length>0,shadowMapType:n.shadowMap.type,toneMapping:ye,useLegacyLights:n._useLegacyLights,decodeVideoTexture:lt&&E.map.isVideoTexture===!0&&me.getTransfer(E.map.colorSpace)===Ee,premultipliedAlpha:E.premultipliedAlpha,doubleSided:E.side===ke,flipSided:E.side===an,useDepthPacking:E.depthPacking>=0,depthPacking:E.depthPacking||0,index0AttributeName:E.index0AttributeName,extensionDerivatives:vt&&E.extensions.derivatives===!0,extensionFragDepth:vt&&E.extensions.fragDepth===!0,extensionDrawBuffers:vt&&E.extensions.drawBuffers===!0,extensionShaderTextureLOD:vt&&E.extensions.shaderTextureLOD===!0,extensionClipCullDistance:vt&&E.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:E.customProgramCacheKey()}}function m(E){let v=[];if(E.shaderID?v.push(E.shaderID):(v.push(E.customVertexShaderID),v.push(E.customFragmentShaderID)),E.defines!==void 0)for(let N in E.defines)v.push(N),v.push(E.defines[N]);return E.isRawShaderMaterial===!1&&(S(v,E),_(v,E),v.push(n.outputColorSpace)),v.push(E.customProgramCacheKey),v.join()}function S(E,v){E.push(v.precision),E.push(v.outputColorSpace),E.push(v.envMapMode),E.push(v.envMapCubeUVHeight),E.push(v.mapUv),E.push(v.alphaMapUv),E.push(v.lightMapUv),E.push(v.aoMapUv),E.push(v.bumpMapUv),E.push(v.normalMapUv),E.push(v.displacementMapUv),E.push(v.emissiveMapUv),E.push(v.metalnessMapUv),E.push(v.roughnessMapUv),E.push(v.anisotropyMapUv),E.push(v.clearcoatMapUv),E.push(v.clearcoatNormalMapUv),E.push(v.clearcoatRoughnessMapUv),E.push(v.iridescenceMapUv),E.push(v.iridescenceThicknessMapUv),E.push(v.sheenColorMapUv),E.push(v.sheenRoughnessMapUv),E.push(v.specularMapUv),E.push(v.specularColorMapUv),E.push(v.specularIntensityMapUv),E.push(v.transmissionMapUv),E.push(v.thicknessMapUv),E.push(v.combine),E.push(v.fogExp2),E.push(v.sizeAttenuation),E.push(v.morphTargetsCount),E.push(v.morphAttributeCount),E.push(v.numDirLights),E.push(v.numPointLights),E.push(v.numSpotLights),E.push(v.numSpotLightMaps),E.push(v.numHemiLights),E.push(v.numRectAreaLights),E.push(v.numDirLightShadows),E.push(v.numPointLightShadows),E.push(v.numSpotLightShadows),E.push(v.numSpotLightShadowsWithMaps),E.push(v.numLightProbes),E.push(v.shadowMapType),E.push(v.toneMapping),E.push(v.numClippingPlanes),E.push(v.numClipIntersection),E.push(v.depthPacking)}function _(E,v){o.disableAll(),v.isWebGL2&&o.enable(0),v.supportsVertexTextures&&o.enable(1),v.instancing&&o.enable(2),v.instancingColor&&o.enable(3),v.matcap&&o.enable(4),v.envMap&&o.enable(5),v.normalMapObjectSpace&&o.enable(6),v.normalMapTangentSpace&&o.enable(7),v.clearcoat&&o.enable(8),v.iridescence&&o.enable(9),v.alphaTest&&o.enable(10),v.vertexColors&&o.enable(11),v.vertexAlphas&&o.enable(12),v.vertexUv1s&&o.enable(13),v.vertexUv2s&&o.enable(14),v.vertexUv3s&&o.enable(15),v.vertexTangents&&o.enable(16),v.anisotropy&&o.enable(17),v.alphaHash&&o.enable(18),v.batching&&o.enable(19),E.push(o.mask),o.disableAll(),v.fog&&o.enable(0),v.useFog&&o.enable(1),v.flatShading&&o.enable(2),v.logarithmicDepthBuffer&&o.enable(3),v.skinning&&o.enable(4),v.morphTargets&&o.enable(5),v.morphNormals&&o.enable(6),v.morphColors&&o.enable(7),v.premultipliedAlpha&&o.enable(8),v.shadowMapEnabled&&o.enable(9),v.useLegacyLights&&o.enable(10),v.doubleSided&&o.enable(11),v.flipSided&&o.enable(12),v.useDepthPacking&&o.enable(13),v.dithering&&o.enable(14),v.transmission&&o.enable(15),v.sheen&&o.enable(16),v.opaque&&o.enable(17),v.pointsUvs&&o.enable(18),v.decodeVideoTexture&&o.enable(19),E.push(o.mask)}function b(E){let v=p[E.type],N;if(v){let B=Yn[v];N=sm.clone(B.uniforms)}else N=E.uniforms;return N}function C(E,v){let N;for(let B=0,rt=l.length;B<rt;B++){let P=l[B];if(P.cacheKey===v){N=P,++N.usedTimes;break}}return N===void 0&&(N=new d_(n,v,E,r),l.push(N)),N}function A(E){if(--E.usedTimes===0){let v=l.indexOf(E);l[v]=l[l.length-1],l.pop(),E.destroy()}}function R(E){c.remove(E)}function F(){c.dispose()}return{getParameters:g,getProgramCacheKey:m,getUniforms:b,acquireProgram:C,releaseProgram:A,releaseShaderCache:R,programs:l,dispose:F}}function g_(){let n=new WeakMap;function t(r){let a=n.get(r);return a===void 0&&(a={},n.set(r,a)),a}function e(r){n.delete(r)}function i(r,a,o){n.get(r)[a]=o}function s(){n=new WeakMap}return{get:t,remove:e,update:i,dispose:s}}function x_(n,t){return n.groupOrder!==t.groupOrder?n.groupOrder-t.groupOrder:n.renderOrder!==t.renderOrder?n.renderOrder-t.renderOrder:n.material.id!==t.material.id?n.material.id-t.material.id:n.z!==t.z?n.z-t.z:n.id-t.id}function Vu(n,t){return n.groupOrder!==t.groupOrder?n.groupOrder-t.groupOrder:n.renderOrder!==t.renderOrder?n.renderOrder-t.renderOrder:n.z!==t.z?t.z-n.z:n.id-t.id}function Wu(){let n=[],t=0,e=[],i=[],s=[];function r(){t=0,e.length=0,i.length=0,s.length=0}function a(u,f,d,p,x,g){let m=n[t];return m===void 0?(m={id:u.id,object:u,geometry:f,material:d,groupOrder:p,renderOrder:u.renderOrder,z:x,group:g},n[t]=m):(m.id=u.id,m.object=u,m.geometry=f,m.material=d,m.groupOrder=p,m.renderOrder=u.renderOrder,m.z=x,m.group=g),t++,m}function o(u,f,d,p,x,g){let m=a(u,f,d,p,x,g);d.transmission>0?i.push(m):d.transparent===!0?s.push(m):e.push(m)}function c(u,f,d,p,x,g){let m=a(u,f,d,p,x,g);d.transmission>0?i.unshift(m):d.transparent===!0?s.unshift(m):e.unshift(m)}function l(u,f){e.length>1&&e.sort(u||x_),i.length>1&&i.sort(f||Vu),s.length>1&&s.sort(f||Vu)}function h(){for(let u=t,f=n.length;u<f;u++){let d=n[u];if(d.id===null)break;d.id=null,d.object=null,d.geometry=null,d.material=null,d.group=null}}return{opaque:e,transmissive:i,transparent:s,init:r,push:o,unshift:c,finish:h,sort:l}}function __(){let n=new WeakMap;function t(i,s){let r=n.get(i),a;return r===void 0?(a=new Wu,n.set(i,[a])):s>=r.length?(a=new Wu,r.push(a)):a=r[s],a}function e(){n=new WeakMap}return{get:t,dispose:e}}function y_(){let n={};return{get:function(t){if(n[t.id]!==void 0)return n[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new L,color:new Ft};break;case"SpotLight":e={position:new L,direction:new L,color:new Ft,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new L,color:new Ft,distance:0,decay:0};break;case"HemisphereLight":e={direction:new L,skyColor:new Ft,groundColor:new Ft};break;case"RectAreaLight":e={color:new Ft,position:new L,halfWidth:new L,halfHeight:new L};break}return n[t.id]=e,e}}}function v_(){let n={};return{get:function(t){if(n[t.id]!==void 0)return n[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ut};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ut};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ut,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[t.id]=e,e}}}var M_=0;function E_(n,t){return(t.castShadow?2:0)-(n.castShadow?2:0)+(t.map?1:0)-(n.map?1:0)}function S_(n,t){let e=new y_,i=v_(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)s.probe.push(new L);let r=new L,a=new Me,o=new Me;function c(h,u){let f=0,d=0,p=0;for(let B=0;B<9;B++)s.probe[B].set(0,0,0);let x=0,g=0,m=0,S=0,_=0,b=0,C=0,A=0,R=0,F=0,E=0;h.sort(E_);let v=u===!0?Math.PI:1;for(let B=0,rt=h.length;B<rt;B++){let P=h[B],z=P.color,G=P.intensity,et=P.distance,J=P.shadow&&P.shadow.map?P.shadow.map.texture:null;if(P.isAmbientLight)f+=z.r*G*v,d+=z.g*G*v,p+=z.b*G*v;else if(P.isLightProbe){for(let $=0;$<9;$++)s.probe[$].addScaledVector(P.sh.coefficients[$],G);E++}else if(P.isDirectionalLight){let $=e.get(P);if($.color.copy(P.color).multiplyScalar(P.intensity*v),P.castShadow){let nt=P.shadow,it=i.get(P);it.shadowBias=nt.bias,it.shadowNormalBias=nt.normalBias,it.shadowRadius=nt.radius,it.shadowMapSize=nt.mapSize,s.directionalShadow[x]=it,s.directionalShadowMap[x]=J,s.directionalShadowMatrix[x]=P.shadow.matrix,b++}s.directional[x]=$,x++}else if(P.isSpotLight){let $=e.get(P);$.position.setFromMatrixPosition(P.matrixWorld),$.color.copy(z).multiplyScalar(G*v),$.distance=et,$.coneCos=Math.cos(P.angle),$.penumbraCos=Math.cos(P.angle*(1-P.penumbra)),$.decay=P.decay,s.spot[m]=$;let nt=P.shadow;if(P.map&&(s.spotLightMap[R]=P.map,R++,nt.updateMatrices(P),P.castShadow&&F++),s.spotLightMatrix[m]=nt.matrix,P.castShadow){let it=i.get(P);it.shadowBias=nt.bias,it.shadowNormalBias=nt.normalBias,it.shadowRadius=nt.radius,it.shadowMapSize=nt.mapSize,s.spotShadow[m]=it,s.spotShadowMap[m]=J,A++}m++}else if(P.isRectAreaLight){let $=e.get(P);$.color.copy(z).multiplyScalar(G),$.halfWidth.set(P.width*.5,0,0),$.halfHeight.set(0,P.height*.5,0),s.rectArea[S]=$,S++}else if(P.isPointLight){let $=e.get(P);if($.color.copy(P.color).multiplyScalar(P.intensity*v),$.distance=P.distance,$.decay=P.decay,P.castShadow){let nt=P.shadow,it=i.get(P);it.shadowBias=nt.bias,it.shadowNormalBias=nt.normalBias,it.shadowRadius=nt.radius,it.shadowMapSize=nt.mapSize,it.shadowCameraNear=nt.camera.near,it.shadowCameraFar=nt.camera.far,s.pointShadow[g]=it,s.pointShadowMap[g]=J,s.pointShadowMatrix[g]=P.shadow.matrix,C++}s.point[g]=$,g++}else if(P.isHemisphereLight){let $=e.get(P);$.skyColor.copy(P.color).multiplyScalar(G*v),$.groundColor.copy(P.groundColor).multiplyScalar(G*v),s.hemi[_]=$,_++}}S>0&&(t.isWebGL2?n.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=pt.LTC_FLOAT_1,s.rectAreaLTC2=pt.LTC_FLOAT_2):(s.rectAreaLTC1=pt.LTC_HALF_1,s.rectAreaLTC2=pt.LTC_HALF_2):n.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=pt.LTC_FLOAT_1,s.rectAreaLTC2=pt.LTC_FLOAT_2):n.has("OES_texture_half_float_linear")===!0?(s.rectAreaLTC1=pt.LTC_HALF_1,s.rectAreaLTC2=pt.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),s.ambient[0]=f,s.ambient[1]=d,s.ambient[2]=p;let N=s.hash;(N.directionalLength!==x||N.pointLength!==g||N.spotLength!==m||N.rectAreaLength!==S||N.hemiLength!==_||N.numDirectionalShadows!==b||N.numPointShadows!==C||N.numSpotShadows!==A||N.numSpotMaps!==R||N.numLightProbes!==E)&&(s.directional.length=x,s.spot.length=m,s.rectArea.length=S,s.point.length=g,s.hemi.length=_,s.directionalShadow.length=b,s.directionalShadowMap.length=b,s.pointShadow.length=C,s.pointShadowMap.length=C,s.spotShadow.length=A,s.spotShadowMap.length=A,s.directionalShadowMatrix.length=b,s.pointShadowMatrix.length=C,s.spotLightMatrix.length=A+R-F,s.spotLightMap.length=R,s.numSpotLightShadowsWithMaps=F,s.numLightProbes=E,N.directionalLength=x,N.pointLength=g,N.spotLength=m,N.rectAreaLength=S,N.hemiLength=_,N.numDirectionalShadows=b,N.numPointShadows=C,N.numSpotShadows=A,N.numSpotMaps=R,N.numLightProbes=E,s.version=M_++)}function l(h,u){let f=0,d=0,p=0,x=0,g=0,m=u.matrixWorldInverse;for(let S=0,_=h.length;S<_;S++){let b=h[S];if(b.isDirectionalLight){let C=s.directional[f];C.direction.setFromMatrixPosition(b.matrixWorld),r.setFromMatrixPosition(b.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(m),f++}else if(b.isSpotLight){let C=s.spot[p];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(m),C.direction.setFromMatrixPosition(b.matrixWorld),r.setFromMatrixPosition(b.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(m),p++}else if(b.isRectAreaLight){let C=s.rectArea[x];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(m),o.identity(),a.copy(b.matrixWorld),a.premultiply(m),o.extractRotation(a),C.halfWidth.set(b.width*.5,0,0),C.halfHeight.set(0,b.height*.5,0),C.halfWidth.applyMatrix4(o),C.halfHeight.applyMatrix4(o),x++}else if(b.isPointLight){let C=s.point[d];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(m),d++}else if(b.isHemisphereLight){let C=s.hemi[g];C.direction.setFromMatrixPosition(b.matrixWorld),C.direction.transformDirection(m),g++}}}return{setup:c,setupView:l,state:s}}function Xu(n,t){let e=new S_(n,t),i=[],s=[];function r(){i.length=0,s.length=0}function a(u){i.push(u)}function o(u){s.push(u)}function c(u){e.setup(i,u)}function l(u){e.setupView(i,u)}return{init:r,state:{lightsArray:i,shadowsArray:s,lights:e},setupLights:c,setupLightsView:l,pushLight:a,pushShadow:o}}function b_(n,t){let e=new WeakMap;function i(r,a=0){let o=e.get(r),c;return o===void 0?(c=new Xu(n,t),e.set(r,[c])):a>=o.length?(c=new Xu(n,t),o.push(c)):c=o[a],c}function s(){e=new WeakMap}return{get:i,dispose:s}}var Qc=class extends hi{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=_p,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},tl=class extends hi{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},T_=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,w_=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function A_(n,t,e){let i=new Or,s=new ut,r=new ut,a=new Je,o=new Qc({depthPacking:yp}),c=new tl,l={},h=e.maxTextureSize,u={[Di]:an,[an]:Di,[ke]:ke},f=new Ln({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ut},radius:{value:4}},vertexShader:T_,fragmentShader:w_}),d=f.clone();d.defines.HORIZONTAL_PASS=1;let p=new Le;p.setAttribute("position",new we(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let x=new It(p,f),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=of;let m=this.type;this.render=function(A,R,F){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||A.length===0)return;let E=n.getRenderTarget(),v=n.getActiveCubeFace(),N=n.getActiveMipmapLevel(),B=n.state;B.setBlending(Ci),B.buffers.color.setClear(1,1,1,1),B.buffers.depth.setTest(!0),B.setScissorTest(!1);let rt=m!==ri&&this.type===ri,P=m===ri&&this.type!==ri;for(let z=0,G=A.length;z<G;z++){let et=A[z],J=et.shadow;if(J===void 0){console.warn("THREE.WebGLShadowMap:",et,"has no shadow.");continue}if(J.autoUpdate===!1&&J.needsUpdate===!1)continue;s.copy(J.mapSize);let $=J.getFrameExtents();if(s.multiply($),r.copy(J.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/$.x),s.x=r.x*$.x,J.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/$.y),s.y=r.y*$.y,J.mapSize.y=r.y)),J.map===null||rt===!0||P===!0){let it=this.type!==ri?{minFilter:Ze,magFilter:Ze}:{};J.map!==null&&J.map.dispose(),J.map=new li(s.x,s.y,it),J.map.texture.name=et.name+".shadowMap",J.camera.updateProjectionMatrix()}n.setRenderTarget(J.map),n.clear();let nt=J.getViewportCount();for(let it=0;it<nt;it++){let _t=J.getViewport(it);a.set(r.x*_t.x,r.y*_t.y,r.x*_t.z,r.y*_t.w),B.viewport(a),J.updateMatrices(et,it),i=J.getFrustum(),b(R,F,J.camera,et,this.type)}J.isPointLightShadow!==!0&&this.type===ri&&S(J,F),J.needsUpdate=!1}m=this.type,g.needsUpdate=!1,n.setRenderTarget(E,v,N)};function S(A,R){let F=t.update(x);f.defines.VSM_SAMPLES!==A.blurSamples&&(f.defines.VSM_SAMPLES=A.blurSamples,d.defines.VSM_SAMPLES=A.blurSamples,f.needsUpdate=!0,d.needsUpdate=!0),A.mapPass===null&&(A.mapPass=new li(s.x,s.y)),f.uniforms.shadow_pass.value=A.map.texture,f.uniforms.resolution.value=A.mapSize,f.uniforms.radius.value=A.radius,n.setRenderTarget(A.mapPass),n.clear(),n.renderBufferDirect(R,null,F,f,x,null),d.uniforms.shadow_pass.value=A.mapPass.texture,d.uniforms.resolution.value=A.mapSize,d.uniforms.radius.value=A.radius,n.setRenderTarget(A.map),n.clear(),n.renderBufferDirect(R,null,F,d,x,null)}function _(A,R,F,E){let v=null,N=F.isPointLight===!0?A.customDistanceMaterial:A.customDepthMaterial;if(N!==void 0)v=N;else if(v=F.isPointLight===!0?c:o,n.localClippingEnabled&&R.clipShadows===!0&&Array.isArray(R.clippingPlanes)&&R.clippingPlanes.length!==0||R.displacementMap&&R.displacementScale!==0||R.alphaMap&&R.alphaTest>0||R.map&&R.alphaTest>0){let B=v.uuid,rt=R.uuid,P=l[B];P===void 0&&(P={},l[B]=P);let z=P[rt];z===void 0&&(z=v.clone(),P[rt]=z,R.addEventListener("dispose",C)),v=z}if(v.visible=R.visible,v.wireframe=R.wireframe,E===ri?v.side=R.shadowSide!==null?R.shadowSide:R.side:v.side=R.shadowSide!==null?R.shadowSide:u[R.side],v.alphaMap=R.alphaMap,v.alphaTest=R.alphaTest,v.map=R.map,v.clipShadows=R.clipShadows,v.clippingPlanes=R.clippingPlanes,v.clipIntersection=R.clipIntersection,v.displacementMap=R.displacementMap,v.displacementScale=R.displacementScale,v.displacementBias=R.displacementBias,v.wireframeLinewidth=R.wireframeLinewidth,v.linewidth=R.linewidth,F.isPointLight===!0&&v.isMeshDistanceMaterial===!0){let B=n.properties.get(v);B.light=F}return v}function b(A,R,F,E,v){if(A.visible===!1)return;if(A.layers.test(R.layers)&&(A.isMesh||A.isLine||A.isPoints)&&(A.castShadow||A.receiveShadow&&v===ri)&&(!A.frustumCulled||i.intersectsObject(A))){A.modelViewMatrix.multiplyMatrices(F.matrixWorldInverse,A.matrixWorld);let rt=t.update(A),P=A.material;if(Array.isArray(P)){let z=rt.groups;for(let G=0,et=z.length;G<et;G++){let J=z[G],$=P[J.materialIndex];if($&&$.visible){let nt=_(A,$,E,v);A.onBeforeShadow(n,A,R,F,rt,nt,J),n.renderBufferDirect(F,null,rt,nt,A,J),A.onAfterShadow(n,A,R,F,rt,nt,J)}}}else if(P.visible){let z=_(A,P,E,v);A.onBeforeShadow(n,A,R,F,rt,z,null),n.renderBufferDirect(F,null,rt,z,A,null),A.onAfterShadow(n,A,R,F,rt,z,null)}}let B=A.children;for(let rt=0,P=B.length;rt<P;rt++)b(B[rt],R,F,E,v)}function C(A){A.target.removeEventListener("dispose",C);for(let F in l){let E=l[F],v=A.target.uuid;v in E&&(E[v].dispose(),delete E[v])}}}function R_(n,t,e){let i=e.isWebGL2;function s(){let D=!1,yt=new Je,vt=null,Gt=new Je(0,0,0,0);return{setMask:function(Ht){vt!==Ht&&!D&&(n.colorMask(Ht,Ht,Ht,Ht),vt=Ht)},setLocked:function(Ht){D=Ht},setClear:function(Ht,_e,ye,Ye,cn){cn===!0&&(Ht*=Ye,_e*=Ye,ye*=Ye),yt.set(Ht,_e,ye,Ye),Gt.equals(yt)===!1&&(n.clearColor(Ht,_e,ye,Ye),Gt.copy(yt))},reset:function(){D=!1,vt=null,Gt.set(-1,0,0,0)}}}function r(){let D=!1,yt=null,vt=null,Gt=null;return{setTest:function(Ht){Ht?ht(n.DEPTH_TEST):lt(n.DEPTH_TEST)},setMask:function(Ht){yt!==Ht&&!D&&(n.depthMask(Ht),yt=Ht)},setFunc:function(Ht){if(vt!==Ht){switch(Ht){case Zd:n.depthFunc(n.NEVER);break;case Jd:n.depthFunc(n.ALWAYS);break;case Kd:n.depthFunc(n.LESS);break;case qo:n.depthFunc(n.LEQUAL);break;case jd:n.depthFunc(n.EQUAL);break;case Qd:n.depthFunc(n.GEQUAL);break;case tp:n.depthFunc(n.GREATER);break;case ep:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}vt=Ht}},setLocked:function(Ht){D=Ht},setClear:function(Ht){Gt!==Ht&&(n.clearDepth(Ht),Gt=Ht)},reset:function(){D=!1,yt=null,vt=null,Gt=null}}}function a(){let D=!1,yt=null,vt=null,Gt=null,Ht=null,_e=null,ye=null,Ye=null,cn=null;return{setTest:function(ve){D||(ve?ht(n.STENCIL_TEST):lt(n.STENCIL_TEST))},setMask:function(ve){yt!==ve&&!D&&(n.stencilMask(ve),yt=ve)},setFunc:function(ve,ln,Xn){(vt!==ve||Gt!==ln||Ht!==Xn)&&(n.stencilFunc(ve,ln,Xn),vt=ve,Gt=ln,Ht=Xn)},setOp:function(ve,ln,Xn){(_e!==ve||ye!==ln||Ye!==Xn)&&(n.stencilOp(ve,ln,Xn),_e=ve,ye=ln,Ye=Xn)},setLocked:function(ve){D=ve},setClear:function(ve){cn!==ve&&(n.clearStencil(ve),cn=ve)},reset:function(){D=!1,yt=null,vt=null,Gt=null,Ht=null,_e=null,ye=null,Ye=null,cn=null}}}let o=new s,c=new r,l=new a,h=new WeakMap,u=new WeakMap,f={},d={},p=new WeakMap,x=[],g=null,m=!1,S=null,_=null,b=null,C=null,A=null,R=null,F=null,E=new Ft(0,0,0),v=0,N=!1,B=null,rt=null,P=null,z=null,G=null,et=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS),J=!1,$=0,nt=n.getParameter(n.VERSION);nt.indexOf("WebGL")!==-1?($=parseFloat(/^WebGL (\d)/.exec(nt)[1]),J=$>=1):nt.indexOf("OpenGL ES")!==-1&&($=parseFloat(/^OpenGL ES (\d)/.exec(nt)[1]),J=$>=2);let it=null,_t={},W=n.getParameter(n.SCISSOR_BOX),K=n.getParameter(n.VIEWPORT),gt=new Je().fromArray(W),Rt=new Je().fromArray(K);function Mt(D,yt,vt,Gt){let Ht=new Uint8Array(4),_e=n.createTexture();n.bindTexture(D,_e),n.texParameteri(D,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(D,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let ye=0;ye<vt;ye++)i&&(D===n.TEXTURE_3D||D===n.TEXTURE_2D_ARRAY)?n.texImage3D(yt,0,n.RGBA,1,1,Gt,0,n.RGBA,n.UNSIGNED_BYTE,Ht):n.texImage2D(yt+ye,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Ht);return _e}let Z={};Z[n.TEXTURE_2D]=Mt(n.TEXTURE_2D,n.TEXTURE_2D,1),Z[n.TEXTURE_CUBE_MAP]=Mt(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(Z[n.TEXTURE_2D_ARRAY]=Mt(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),Z[n.TEXTURE_3D]=Mt(n.TEXTURE_3D,n.TEXTURE_3D,1,1)),o.setClear(0,0,0,1),c.setClear(1),l.setClear(0),ht(n.DEPTH_TEST),c.setFunc(qo),q(!1),M(wh),ht(n.CULL_FACE),I(Ci);function ht(D){f[D]!==!0&&(n.enable(D),f[D]=!0)}function lt(D){f[D]!==!1&&(n.disable(D),f[D]=!1)}function Et(D,yt){return d[D]!==yt?(n.bindFramebuffer(D,yt),d[D]=yt,i&&(D===n.DRAW_FRAMEBUFFER&&(d[n.FRAMEBUFFER]=yt),D===n.FRAMEBUFFER&&(d[n.DRAW_FRAMEBUFFER]=yt)),!0):!1}function w(D,yt){let vt=x,Gt=!1;if(D)if(vt=p.get(yt),vt===void 0&&(vt=[],p.set(yt,vt)),D.isWebGLMultipleRenderTargets){let Ht=D.texture;if(vt.length!==Ht.length||vt[0]!==n.COLOR_ATTACHMENT0){for(let _e=0,ye=Ht.length;_e<ye;_e++)vt[_e]=n.COLOR_ATTACHMENT0+_e;vt.length=Ht.length,Gt=!0}}else vt[0]!==n.COLOR_ATTACHMENT0&&(vt[0]=n.COLOR_ATTACHMENT0,Gt=!0);else vt[0]!==n.BACK&&(vt[0]=n.BACK,Gt=!0);Gt&&(e.isWebGL2?n.drawBuffers(vt):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(vt))}function Q(D){return g!==D?(n.useProgram(D),g=D,!0):!1}let X={[qi]:n.FUNC_ADD,[Ud]:n.FUNC_SUBTRACT,[Nd]:n.FUNC_REVERSE_SUBTRACT};if(i)X[Ch]=n.MIN,X[Ph]=n.MAX;else{let D=t.get("EXT_blend_minmax");D!==null&&(X[Ch]=D.MIN_EXT,X[Ph]=D.MAX_EXT)}let ot={[Od]:n.ZERO,[Fd]:n.ONE,[zd]:n.SRC_COLOR,[Nc]:n.SRC_ALPHA,[Wd]:n.SRC_ALPHA_SATURATE,[Gd]:n.DST_COLOR,[Hd]:n.DST_ALPHA,[Bd]:n.ONE_MINUS_SRC_COLOR,[Oc]:n.ONE_MINUS_SRC_ALPHA,[Vd]:n.ONE_MINUS_DST_COLOR,[kd]:n.ONE_MINUS_DST_ALPHA,[Xd]:n.CONSTANT_COLOR,[Yd]:n.ONE_MINUS_CONSTANT_COLOR,[qd]:n.CONSTANT_ALPHA,[$d]:n.ONE_MINUS_CONSTANT_ALPHA};function I(D,yt,vt,Gt,Ht,_e,ye,Ye,cn,ve){if(D===Ci){m===!0&&(lt(n.BLEND),m=!1);return}if(m===!1&&(ht(n.BLEND),m=!0),D!==Dd){if(D!==S||ve!==N){if((_!==qi||A!==qi)&&(n.blendEquation(n.FUNC_ADD),_=qi,A=qi),ve)switch(D){case Pi:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Ui:n.blendFunc(n.ONE,n.ONE);break;case Ah:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Rh:n.blendFuncSeparate(n.ZERO,n.SRC_COLOR,n.ZERO,n.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}else switch(D){case Pi:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Ui:n.blendFunc(n.SRC_ALPHA,n.ONE);break;case Ah:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Rh:n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}b=null,C=null,R=null,F=null,E.set(0,0,0),v=0,S=D,N=ve}return}Ht=Ht||yt,_e=_e||vt,ye=ye||Gt,(yt!==_||Ht!==A)&&(n.blendEquationSeparate(X[yt],X[Ht]),_=yt,A=Ht),(vt!==b||Gt!==C||_e!==R||ye!==F)&&(n.blendFuncSeparate(ot[vt],ot[Gt],ot[_e],ot[ye]),b=vt,C=Gt,R=_e,F=ye),(Ye.equals(E)===!1||cn!==v)&&(n.blendColor(Ye.r,Ye.g,Ye.b,cn),E.copy(Ye),v=cn),S=D,N=!1}function Y(D,yt){D.side===ke?lt(n.CULL_FACE):ht(n.CULL_FACE);let vt=D.side===an;yt&&(vt=!vt),q(vt),D.blending===Pi&&D.transparent===!1?I(Ci):I(D.blending,D.blendEquation,D.blendSrc,D.blendDst,D.blendEquationAlpha,D.blendSrcAlpha,D.blendDstAlpha,D.blendColor,D.blendAlpha,D.premultipliedAlpha),c.setFunc(D.depthFunc),c.setTest(D.depthTest),c.setMask(D.depthWrite),o.setMask(D.colorWrite);let Gt=D.stencilWrite;l.setTest(Gt),Gt&&(l.setMask(D.stencilWriteMask),l.setFunc(D.stencilFunc,D.stencilRef,D.stencilFuncMask),l.setOp(D.stencilFail,D.stencilZFail,D.stencilZPass)),U(D.polygonOffset,D.polygonOffsetFactor,D.polygonOffsetUnits),D.alphaToCoverage===!0?ht(n.SAMPLE_ALPHA_TO_COVERAGE):lt(n.SAMPLE_ALPHA_TO_COVERAGE)}function q(D){B!==D&&(D?n.frontFace(n.CW):n.frontFace(n.CCW),B=D)}function M(D){D!==Ld?(ht(n.CULL_FACE),D!==rt&&(D===wh?n.cullFace(n.BACK):D===Id?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):lt(n.CULL_FACE),rt=D}function y(D){D!==P&&(J&&n.lineWidth(D),P=D)}function U(D,yt,vt){D?(ht(n.POLYGON_OFFSET_FILL),(z!==yt||G!==vt)&&(n.polygonOffset(yt,vt),z=yt,G=vt)):lt(n.POLYGON_OFFSET_FILL)}function tt(D){D?ht(n.SCISSOR_TEST):lt(n.SCISSOR_TEST)}function j(D){D===void 0&&(D=n.TEXTURE0+et-1),it!==D&&(n.activeTexture(D),it=D)}function st(D,yt,vt){vt===void 0&&(it===null?vt=n.TEXTURE0+et-1:vt=it);let Gt=_t[vt];Gt===void 0&&(Gt={type:void 0,texture:void 0},_t[vt]=Gt),(Gt.type!==D||Gt.texture!==yt)&&(it!==vt&&(n.activeTexture(vt),it=vt),n.bindTexture(D,yt||Z[D]),Gt.type=D,Gt.texture=yt)}function Ct(){let D=_t[it];D!==void 0&&D.type!==void 0&&(n.bindTexture(D.type,null),D.type=void 0,D.texture=void 0)}function xt(){try{n.compressedTexImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function bt(){try{n.compressedTexImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Bt(){try{n.texSubImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function $t(){try{n.texSubImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function at(){try{n.compressedTexSubImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function le(){try{n.compressedTexSubImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function se(){try{n.texStorage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Xt(){try{n.texStorage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ot(){try{n.texImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Pt(){try{n.texImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Kt(D){gt.equals(D)===!1&&(n.scissor(D.x,D.y,D.z,D.w),gt.copy(D))}function fe(D){Rt.equals(D)===!1&&(n.viewport(D.x,D.y,D.z,D.w),Rt.copy(D))}function Ie(D,yt){let vt=u.get(yt);vt===void 0&&(vt=new WeakMap,u.set(yt,vt));let Gt=vt.get(D);Gt===void 0&&(Gt=n.getUniformBlockIndex(yt,D.name),vt.set(D,Gt))}function ee(D,yt){let Gt=u.get(yt).get(D);h.get(yt)!==Gt&&(n.uniformBlockBinding(yt,Gt,D.__bindingPointIndex),h.set(yt,Gt))}function dt(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),i===!0&&(n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null)),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),f={},it=null,_t={},d={},p=new WeakMap,x=[],g=null,m=!1,S=null,_=null,b=null,C=null,A=null,R=null,F=null,E=new Ft(0,0,0),v=0,N=!1,B=null,rt=null,P=null,z=null,G=null,gt.set(0,0,n.canvas.width,n.canvas.height),Rt.set(0,0,n.canvas.width,n.canvas.height),o.reset(),c.reset(),l.reset()}return{buffers:{color:o,depth:c,stencil:l},enable:ht,disable:lt,bindFramebuffer:Et,drawBuffers:w,useProgram:Q,setBlending:I,setMaterial:Y,setFlipSided:q,setCullFace:M,setLineWidth:y,setPolygonOffset:U,setScissorTest:tt,activeTexture:j,bindTexture:st,unbindTexture:Ct,compressedTexImage2D:xt,compressedTexImage3D:bt,texImage2D:Ot,texImage3D:Pt,updateUBOMapping:Ie,uniformBlockBinding:ee,texStorage2D:se,texStorage3D:Xt,texSubImage2D:Bt,texSubImage3D:$t,compressedTexSubImage2D:at,compressedTexSubImage3D:le,scissor:Kt,viewport:fe,reset:dt}}function C_(n,t,e,i,s,r,a){let o=s.isWebGL2,c=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap,u,f=new WeakMap,d=!1;try{d=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function p(M,y){return d?new OffscreenCanvas(M,y):ea("canvas")}function x(M,y,U,tt){let j=1;if((M.width>tt||M.height>tt)&&(j=tt/Math.max(M.width,M.height)),j<1||y===!0)if(typeof HTMLImageElement<"u"&&M instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&M instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&M instanceof ImageBitmap){let st=y?ta:Math.floor,Ct=st(j*M.width),xt=st(j*M.height);u===void 0&&(u=p(Ct,xt));let bt=U?p(Ct,xt):u;return bt.width=Ct,bt.height=xt,bt.getContext("2d").drawImage(M,0,0,Ct,xt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+M.width+"x"+M.height+") to ("+Ct+"x"+xt+")."),bt}else return"data"in M&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+M.width+"x"+M.height+")."),M;return M}function g(M){return Gc(M.width)&&Gc(M.height)}function m(M){return o?!1:M.wrapS!==Bn||M.wrapT!==Bn||M.minFilter!==Ze&&M.minFilter!==wn}function S(M,y){return M.generateMipmaps&&y&&M.minFilter!==Ze&&M.minFilter!==wn}function _(M){n.generateMipmap(M)}function b(M,y,U,tt,j=!1){if(o===!1)return y;if(M!==null){if(n[M]!==void 0)return n[M];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+M+"'")}let st=y;if(y===n.RED&&(U===n.FLOAT&&(st=n.R32F),U===n.HALF_FLOAT&&(st=n.R16F),U===n.UNSIGNED_BYTE&&(st=n.R8)),y===n.RED_INTEGER&&(U===n.UNSIGNED_BYTE&&(st=n.R8UI),U===n.UNSIGNED_SHORT&&(st=n.R16UI),U===n.UNSIGNED_INT&&(st=n.R32UI),U===n.BYTE&&(st=n.R8I),U===n.SHORT&&(st=n.R16I),U===n.INT&&(st=n.R32I)),y===n.RG&&(U===n.FLOAT&&(st=n.RG32F),U===n.HALF_FLOAT&&(st=n.RG16F),U===n.UNSIGNED_BYTE&&(st=n.RG8)),y===n.RGBA){let Ct=j?Jo:me.getTransfer(tt);U===n.FLOAT&&(st=n.RGBA32F),U===n.HALF_FLOAT&&(st=n.RGBA16F),U===n.UNSIGNED_BYTE&&(st=Ct===Ee?n.SRGB8_ALPHA8:n.RGBA8),U===n.UNSIGNED_SHORT_4_4_4_4&&(st=n.RGBA4),U===n.UNSIGNED_SHORT_5_5_5_1&&(st=n.RGB5_A1)}return(st===n.R16F||st===n.R32F||st===n.RG16F||st===n.RG32F||st===n.RGBA16F||st===n.RGBA32F)&&t.get("EXT_color_buffer_float"),st}function C(M,y,U){return S(M,U)===!0||M.isFramebufferTexture&&M.minFilter!==Ze&&M.minFilter!==wn?Math.log2(Math.max(y.width,y.height))+1:M.mipmaps!==void 0&&M.mipmaps.length>0?M.mipmaps.length:M.isCompressedTexture&&Array.isArray(M.image)?y.mipmaps.length:1}function A(M){return M===Ze||M===Lh||M===ec?n.NEAREST:n.LINEAR}function R(M){let y=M.target;y.removeEventListener("dispose",R),E(y),y.isVideoTexture&&h.delete(y)}function F(M){let y=M.target;y.removeEventListener("dispose",F),N(y)}function E(M){let y=i.get(M);if(y.__webglInit===void 0)return;let U=M.source,tt=f.get(U);if(tt){let j=tt[y.__cacheKey];j.usedTimes--,j.usedTimes===0&&v(M),Object.keys(tt).length===0&&f.delete(U)}i.remove(M)}function v(M){let y=i.get(M);n.deleteTexture(y.__webglTexture);let U=M.source,tt=f.get(U);delete tt[y.__cacheKey],a.memory.textures--}function N(M){let y=M.texture,U=i.get(M),tt=i.get(y);if(tt.__webglTexture!==void 0&&(n.deleteTexture(tt.__webglTexture),a.memory.textures--),M.depthTexture&&M.depthTexture.dispose(),M.isWebGLCubeRenderTarget)for(let j=0;j<6;j++){if(Array.isArray(U.__webglFramebuffer[j]))for(let st=0;st<U.__webglFramebuffer[j].length;st++)n.deleteFramebuffer(U.__webglFramebuffer[j][st]);else n.deleteFramebuffer(U.__webglFramebuffer[j]);U.__webglDepthbuffer&&n.deleteRenderbuffer(U.__webglDepthbuffer[j])}else{if(Array.isArray(U.__webglFramebuffer))for(let j=0;j<U.__webglFramebuffer.length;j++)n.deleteFramebuffer(U.__webglFramebuffer[j]);else n.deleteFramebuffer(U.__webglFramebuffer);if(U.__webglDepthbuffer&&n.deleteRenderbuffer(U.__webglDepthbuffer),U.__webglMultisampledFramebuffer&&n.deleteFramebuffer(U.__webglMultisampledFramebuffer),U.__webglColorRenderbuffer)for(let j=0;j<U.__webglColorRenderbuffer.length;j++)U.__webglColorRenderbuffer[j]&&n.deleteRenderbuffer(U.__webglColorRenderbuffer[j]);U.__webglDepthRenderbuffer&&n.deleteRenderbuffer(U.__webglDepthRenderbuffer)}if(M.isWebGLMultipleRenderTargets)for(let j=0,st=y.length;j<st;j++){let Ct=i.get(y[j]);Ct.__webglTexture&&(n.deleteTexture(Ct.__webglTexture),a.memory.textures--),i.remove(y[j])}i.remove(y),i.remove(M)}let B=0;function rt(){B=0}function P(){let M=B;return M>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+M+" texture units while this GPU supports only "+s.maxTextures),B+=1,M}function z(M){let y=[];return y.push(M.wrapS),y.push(M.wrapT),y.push(M.wrapR||0),y.push(M.magFilter),y.push(M.minFilter),y.push(M.anisotropy),y.push(M.internalFormat),y.push(M.format),y.push(M.type),y.push(M.generateMipmaps),y.push(M.premultiplyAlpha),y.push(M.flipY),y.push(M.unpackAlignment),y.push(M.colorSpace),y.join()}function G(M,y){let U=i.get(M);if(M.isVideoTexture&&Y(M),M.isRenderTargetTexture===!1&&M.version>0&&U.__version!==M.version){let tt=M.image;if(tt===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(tt.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{gt(U,M,y);return}}e.bindTexture(n.TEXTURE_2D,U.__webglTexture,n.TEXTURE0+y)}function et(M,y){let U=i.get(M);if(M.version>0&&U.__version!==M.version){gt(U,M,y);return}e.bindTexture(n.TEXTURE_2D_ARRAY,U.__webglTexture,n.TEXTURE0+y)}function J(M,y){let U=i.get(M);if(M.version>0&&U.__version!==M.version){gt(U,M,y);return}e.bindTexture(n.TEXTURE_3D,U.__webglTexture,n.TEXTURE0+y)}function $(M,y){let U=i.get(M);if(M.version>0&&U.__version!==M.version){Rt(U,M,y);return}e.bindTexture(n.TEXTURE_CUBE_MAP,U.__webglTexture,n.TEXTURE0+y)}let nt={[Ir]:n.REPEAT,[Bn]:n.CLAMP_TO_EDGE,[Bc]:n.MIRRORED_REPEAT},it={[Ze]:n.NEAREST,[Lh]:n.NEAREST_MIPMAP_NEAREST,[ec]:n.NEAREST_MIPMAP_LINEAR,[wn]:n.LINEAR,[lp]:n.LINEAR_MIPMAP_NEAREST,[Dr]:n.LINEAR_MIPMAP_LINEAR},_t={[Mp]:n.NEVER,[Ap]:n.ALWAYS,[Ep]:n.LESS,[_f]:n.LEQUAL,[Sp]:n.EQUAL,[wp]:n.GEQUAL,[bp]:n.GREATER,[Tp]:n.NOTEQUAL};function W(M,y,U){if(U?(n.texParameteri(M,n.TEXTURE_WRAP_S,nt[y.wrapS]),n.texParameteri(M,n.TEXTURE_WRAP_T,nt[y.wrapT]),(M===n.TEXTURE_3D||M===n.TEXTURE_2D_ARRAY)&&n.texParameteri(M,n.TEXTURE_WRAP_R,nt[y.wrapR]),n.texParameteri(M,n.TEXTURE_MAG_FILTER,it[y.magFilter]),n.texParameteri(M,n.TEXTURE_MIN_FILTER,it[y.minFilter])):(n.texParameteri(M,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(M,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE),(M===n.TEXTURE_3D||M===n.TEXTURE_2D_ARRAY)&&n.texParameteri(M,n.TEXTURE_WRAP_R,n.CLAMP_TO_EDGE),(y.wrapS!==Bn||y.wrapT!==Bn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),n.texParameteri(M,n.TEXTURE_MAG_FILTER,A(y.magFilter)),n.texParameteri(M,n.TEXTURE_MIN_FILTER,A(y.minFilter)),y.minFilter!==Ze&&y.minFilter!==wn&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),y.compareFunction&&(n.texParameteri(M,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(M,n.TEXTURE_COMPARE_FUNC,_t[y.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){let tt=t.get("EXT_texture_filter_anisotropic");if(y.magFilter===Ze||y.minFilter!==ec&&y.minFilter!==Dr||y.type===Ri&&t.has("OES_texture_float_linear")===!1||o===!1&&y.type===Ur&&t.has("OES_texture_half_float_linear")===!1)return;(y.anisotropy>1||i.get(y).__currentAnisotropy)&&(n.texParameterf(M,tt.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(y.anisotropy,s.getMaxAnisotropy())),i.get(y).__currentAnisotropy=y.anisotropy)}}function K(M,y){let U=!1;M.__webglInit===void 0&&(M.__webglInit=!0,y.addEventListener("dispose",R));let tt=y.source,j=f.get(tt);j===void 0&&(j={},f.set(tt,j));let st=z(y);if(st!==M.__cacheKey){j[st]===void 0&&(j[st]={texture:n.createTexture(),usedTimes:0},a.memory.textures++,U=!0),j[st].usedTimes++;let Ct=j[M.__cacheKey];Ct!==void 0&&(j[M.__cacheKey].usedTimes--,Ct.usedTimes===0&&v(y)),M.__cacheKey=st,M.__webglTexture=j[st].texture}return U}function gt(M,y,U){let tt=n.TEXTURE_2D;(y.isDataArrayTexture||y.isCompressedArrayTexture)&&(tt=n.TEXTURE_2D_ARRAY),y.isData3DTexture&&(tt=n.TEXTURE_3D);let j=K(M,y),st=y.source;e.bindTexture(tt,M.__webglTexture,n.TEXTURE0+U);let Ct=i.get(st);if(st.version!==Ct.__version||j===!0){e.activeTexture(n.TEXTURE0+U);let xt=me.getPrimaries(me.workingColorSpace),bt=y.colorSpace===An?null:me.getPrimaries(y.colorSpace),Bt=y.colorSpace===An||xt===bt?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,y.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,y.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Bt);let $t=m(y)&&g(y.image)===!1,at=x(y.image,$t,!1,s.maxTextureSize);at=q(y,at);let le=g(at)||o,se=r.convert(y.format,y.colorSpace),Xt=r.convert(y.type),Ot=b(y.internalFormat,se,Xt,y.colorSpace,y.isVideoTexture);W(tt,y,le);let Pt,Kt=y.mipmaps,fe=o&&y.isVideoTexture!==!0&&Ot!==mf,Ie=Ct.__version===void 0||j===!0,ee=C(y,at,le);if(y.isDepthTexture)Ot=n.DEPTH_COMPONENT,o?y.type===Ri?Ot=n.DEPTH_COMPONENT32F:y.type===Ai?Ot=n.DEPTH_COMPONENT24:y.type===Ji?Ot=n.DEPTH24_STENCIL8:Ot=n.DEPTH_COMPONENT16:y.type===Ri&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),y.format===Ki&&Ot===n.DEPTH_COMPONENT&&y.type!==Cl&&y.type!==Ai&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),y.type=Ai,Xt=r.convert(y.type)),y.format===Ys&&Ot===n.DEPTH_COMPONENT&&(Ot=n.DEPTH_STENCIL,y.type!==Ji&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),y.type=Ji,Xt=r.convert(y.type))),Ie&&(fe?e.texStorage2D(n.TEXTURE_2D,1,Ot,at.width,at.height):e.texImage2D(n.TEXTURE_2D,0,Ot,at.width,at.height,0,se,Xt,null));else if(y.isDataTexture)if(Kt.length>0&&le){fe&&Ie&&e.texStorage2D(n.TEXTURE_2D,ee,Ot,Kt[0].width,Kt[0].height);for(let dt=0,D=Kt.length;dt<D;dt++)Pt=Kt[dt],fe?e.texSubImage2D(n.TEXTURE_2D,dt,0,0,Pt.width,Pt.height,se,Xt,Pt.data):e.texImage2D(n.TEXTURE_2D,dt,Ot,Pt.width,Pt.height,0,se,Xt,Pt.data);y.generateMipmaps=!1}else fe?(Ie&&e.texStorage2D(n.TEXTURE_2D,ee,Ot,at.width,at.height),e.texSubImage2D(n.TEXTURE_2D,0,0,0,at.width,at.height,se,Xt,at.data)):e.texImage2D(n.TEXTURE_2D,0,Ot,at.width,at.height,0,se,Xt,at.data);else if(y.isCompressedTexture)if(y.isCompressedArrayTexture){fe&&Ie&&e.texStorage3D(n.TEXTURE_2D_ARRAY,ee,Ot,Kt[0].width,Kt[0].height,at.depth);for(let dt=0,D=Kt.length;dt<D;dt++)Pt=Kt[dt],y.format!==Hn?se!==null?fe?e.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,dt,0,0,0,Pt.width,Pt.height,at.depth,se,Pt.data,0,0):e.compressedTexImage3D(n.TEXTURE_2D_ARRAY,dt,Ot,Pt.width,Pt.height,at.depth,0,Pt.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):fe?e.texSubImage3D(n.TEXTURE_2D_ARRAY,dt,0,0,0,Pt.width,Pt.height,at.depth,se,Xt,Pt.data):e.texImage3D(n.TEXTURE_2D_ARRAY,dt,Ot,Pt.width,Pt.height,at.depth,0,se,Xt,Pt.data)}else{fe&&Ie&&e.texStorage2D(n.TEXTURE_2D,ee,Ot,Kt[0].width,Kt[0].height);for(let dt=0,D=Kt.length;dt<D;dt++)Pt=Kt[dt],y.format!==Hn?se!==null?fe?e.compressedTexSubImage2D(n.TEXTURE_2D,dt,0,0,Pt.width,Pt.height,se,Pt.data):e.compressedTexImage2D(n.TEXTURE_2D,dt,Ot,Pt.width,Pt.height,0,Pt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):fe?e.texSubImage2D(n.TEXTURE_2D,dt,0,0,Pt.width,Pt.height,se,Xt,Pt.data):e.texImage2D(n.TEXTURE_2D,dt,Ot,Pt.width,Pt.height,0,se,Xt,Pt.data)}else if(y.isDataArrayTexture)fe?(Ie&&e.texStorage3D(n.TEXTURE_2D_ARRAY,ee,Ot,at.width,at.height,at.depth),e.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,at.width,at.height,at.depth,se,Xt,at.data)):e.texImage3D(n.TEXTURE_2D_ARRAY,0,Ot,at.width,at.height,at.depth,0,se,Xt,at.data);else if(y.isData3DTexture)fe?(Ie&&e.texStorage3D(n.TEXTURE_3D,ee,Ot,at.width,at.height,at.depth),e.texSubImage3D(n.TEXTURE_3D,0,0,0,0,at.width,at.height,at.depth,se,Xt,at.data)):e.texImage3D(n.TEXTURE_3D,0,Ot,at.width,at.height,at.depth,0,se,Xt,at.data);else if(y.isFramebufferTexture){if(Ie)if(fe)e.texStorage2D(n.TEXTURE_2D,ee,Ot,at.width,at.height);else{let dt=at.width,D=at.height;for(let yt=0;yt<ee;yt++)e.texImage2D(n.TEXTURE_2D,yt,Ot,dt,D,0,se,Xt,null),dt>>=1,D>>=1}}else if(Kt.length>0&&le){fe&&Ie&&e.texStorage2D(n.TEXTURE_2D,ee,Ot,Kt[0].width,Kt[0].height);for(let dt=0,D=Kt.length;dt<D;dt++)Pt=Kt[dt],fe?e.texSubImage2D(n.TEXTURE_2D,dt,0,0,se,Xt,Pt):e.texImage2D(n.TEXTURE_2D,dt,Ot,se,Xt,Pt);y.generateMipmaps=!1}else fe?(Ie&&e.texStorage2D(n.TEXTURE_2D,ee,Ot,at.width,at.height),e.texSubImage2D(n.TEXTURE_2D,0,0,0,se,Xt,at)):e.texImage2D(n.TEXTURE_2D,0,Ot,se,Xt,at);S(y,le)&&_(tt),Ct.__version=st.version,y.onUpdate&&y.onUpdate(y)}M.__version=y.version}function Rt(M,y,U){if(y.image.length!==6)return;let tt=K(M,y),j=y.source;e.bindTexture(n.TEXTURE_CUBE_MAP,M.__webglTexture,n.TEXTURE0+U);let st=i.get(j);if(j.version!==st.__version||tt===!0){e.activeTexture(n.TEXTURE0+U);let Ct=me.getPrimaries(me.workingColorSpace),xt=y.colorSpace===An?null:me.getPrimaries(y.colorSpace),bt=y.colorSpace===An||Ct===xt?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,y.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,y.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,bt);let Bt=y.isCompressedTexture||y.image[0].isCompressedTexture,$t=y.image[0]&&y.image[0].isDataTexture,at=[];for(let dt=0;dt<6;dt++)!Bt&&!$t?at[dt]=x(y.image[dt],!1,!0,s.maxCubemapSize):at[dt]=$t?y.image[dt].image:y.image[dt],at[dt]=q(y,at[dt]);let le=at[0],se=g(le)||o,Xt=r.convert(y.format,y.colorSpace),Ot=r.convert(y.type),Pt=b(y.internalFormat,Xt,Ot,y.colorSpace),Kt=o&&y.isVideoTexture!==!0,fe=st.__version===void 0||tt===!0,Ie=C(y,le,se);W(n.TEXTURE_CUBE_MAP,y,se);let ee;if(Bt){Kt&&fe&&e.texStorage2D(n.TEXTURE_CUBE_MAP,Ie,Pt,le.width,le.height);for(let dt=0;dt<6;dt++){ee=at[dt].mipmaps;for(let D=0;D<ee.length;D++){let yt=ee[D];y.format!==Hn?Xt!==null?Kt?e.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,D,0,0,yt.width,yt.height,Xt,yt.data):e.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,D,Pt,yt.width,yt.height,0,yt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Kt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,D,0,0,yt.width,yt.height,Xt,Ot,yt.data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,D,Pt,yt.width,yt.height,0,Xt,Ot,yt.data)}}}else{ee=y.mipmaps,Kt&&fe&&(ee.length>0&&Ie++,e.texStorage2D(n.TEXTURE_CUBE_MAP,Ie,Pt,at[0].width,at[0].height));for(let dt=0;dt<6;dt++)if($t){Kt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,0,0,0,at[dt].width,at[dt].height,Xt,Ot,at[dt].data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,0,Pt,at[dt].width,at[dt].height,0,Xt,Ot,at[dt].data);for(let D=0;D<ee.length;D++){let vt=ee[D].image[dt].image;Kt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,D+1,0,0,vt.width,vt.height,Xt,Ot,vt.data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,D+1,Pt,vt.width,vt.height,0,Xt,Ot,vt.data)}}else{Kt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,0,0,0,Xt,Ot,at[dt]):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,0,Pt,Xt,Ot,at[dt]);for(let D=0;D<ee.length;D++){let yt=ee[D];Kt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,D+1,0,0,Xt,Ot,yt.image[dt]):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,D+1,Pt,Xt,Ot,yt.image[dt])}}}S(y,se)&&_(n.TEXTURE_CUBE_MAP),st.__version=j.version,y.onUpdate&&y.onUpdate(y)}M.__version=y.version}function Mt(M,y,U,tt,j,st){let Ct=r.convert(U.format,U.colorSpace),xt=r.convert(U.type),bt=b(U.internalFormat,Ct,xt,U.colorSpace);if(!i.get(y).__hasExternalTextures){let $t=Math.max(1,y.width>>st),at=Math.max(1,y.height>>st);j===n.TEXTURE_3D||j===n.TEXTURE_2D_ARRAY?e.texImage3D(j,st,bt,$t,at,y.depth,0,Ct,xt,null):e.texImage2D(j,st,bt,$t,at,0,Ct,xt,null)}e.bindFramebuffer(n.FRAMEBUFFER,M),I(y)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,tt,j,i.get(U).__webglTexture,0,ot(y)):(j===n.TEXTURE_2D||j>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&j<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,tt,j,i.get(U).__webglTexture,st),e.bindFramebuffer(n.FRAMEBUFFER,null)}function Z(M,y,U){if(n.bindRenderbuffer(n.RENDERBUFFER,M),y.depthBuffer&&!y.stencilBuffer){let tt=o===!0?n.DEPTH_COMPONENT24:n.DEPTH_COMPONENT16;if(U||I(y)){let j=y.depthTexture;j&&j.isDepthTexture&&(j.type===Ri?tt=n.DEPTH_COMPONENT32F:j.type===Ai&&(tt=n.DEPTH_COMPONENT24));let st=ot(y);I(y)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,st,tt,y.width,y.height):n.renderbufferStorageMultisample(n.RENDERBUFFER,st,tt,y.width,y.height)}else n.renderbufferStorage(n.RENDERBUFFER,tt,y.width,y.height);n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.RENDERBUFFER,M)}else if(y.depthBuffer&&y.stencilBuffer){let tt=ot(y);U&&I(y)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,tt,n.DEPTH24_STENCIL8,y.width,y.height):I(y)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,tt,n.DEPTH24_STENCIL8,y.width,y.height):n.renderbufferStorage(n.RENDERBUFFER,n.DEPTH_STENCIL,y.width,y.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.RENDERBUFFER,M)}else{let tt=y.isWebGLMultipleRenderTargets===!0?y.texture:[y.texture];for(let j=0;j<tt.length;j++){let st=tt[j],Ct=r.convert(st.format,st.colorSpace),xt=r.convert(st.type),bt=b(st.internalFormat,Ct,xt,st.colorSpace),Bt=ot(y);U&&I(y)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,Bt,bt,y.width,y.height):I(y)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Bt,bt,y.width,y.height):n.renderbufferStorage(n.RENDERBUFFER,bt,y.width,y.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function ht(M,y){if(y&&y.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(n.FRAMEBUFFER,M),!(y.depthTexture&&y.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!i.get(y.depthTexture).__webglTexture||y.depthTexture.image.width!==y.width||y.depthTexture.image.height!==y.height)&&(y.depthTexture.image.width=y.width,y.depthTexture.image.height=y.height,y.depthTexture.needsUpdate=!0),G(y.depthTexture,0);let tt=i.get(y.depthTexture).__webglTexture,j=ot(y);if(y.depthTexture.format===Ki)I(y)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,tt,0,j):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,tt,0);else if(y.depthTexture.format===Ys)I(y)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,tt,0,j):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,tt,0);else throw new Error("Unknown depthTexture format")}function lt(M){let y=i.get(M),U=M.isWebGLCubeRenderTarget===!0;if(M.depthTexture&&!y.__autoAllocateDepthBuffer){if(U)throw new Error("target.depthTexture not supported in Cube render targets");ht(y.__webglFramebuffer,M)}else if(U){y.__webglDepthbuffer=[];for(let tt=0;tt<6;tt++)e.bindFramebuffer(n.FRAMEBUFFER,y.__webglFramebuffer[tt]),y.__webglDepthbuffer[tt]=n.createRenderbuffer(),Z(y.__webglDepthbuffer[tt],M,!1)}else e.bindFramebuffer(n.FRAMEBUFFER,y.__webglFramebuffer),y.__webglDepthbuffer=n.createRenderbuffer(),Z(y.__webglDepthbuffer,M,!1);e.bindFramebuffer(n.FRAMEBUFFER,null)}function Et(M,y,U){let tt=i.get(M);y!==void 0&&Mt(tt.__webglFramebuffer,M,M.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),U!==void 0&&lt(M)}function w(M){let y=M.texture,U=i.get(M),tt=i.get(y);M.addEventListener("dispose",F),M.isWebGLMultipleRenderTargets!==!0&&(tt.__webglTexture===void 0&&(tt.__webglTexture=n.createTexture()),tt.__version=y.version,a.memory.textures++);let j=M.isWebGLCubeRenderTarget===!0,st=M.isWebGLMultipleRenderTargets===!0,Ct=g(M)||o;if(j){U.__webglFramebuffer=[];for(let xt=0;xt<6;xt++)if(o&&y.mipmaps&&y.mipmaps.length>0){U.__webglFramebuffer[xt]=[];for(let bt=0;bt<y.mipmaps.length;bt++)U.__webglFramebuffer[xt][bt]=n.createFramebuffer()}else U.__webglFramebuffer[xt]=n.createFramebuffer()}else{if(o&&y.mipmaps&&y.mipmaps.length>0){U.__webglFramebuffer=[];for(let xt=0;xt<y.mipmaps.length;xt++)U.__webglFramebuffer[xt]=n.createFramebuffer()}else U.__webglFramebuffer=n.createFramebuffer();if(st)if(s.drawBuffers){let xt=M.texture;for(let bt=0,Bt=xt.length;bt<Bt;bt++){let $t=i.get(xt[bt]);$t.__webglTexture===void 0&&($t.__webglTexture=n.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&M.samples>0&&I(M)===!1){let xt=st?y:[y];U.__webglMultisampledFramebuffer=n.createFramebuffer(),U.__webglColorRenderbuffer=[],e.bindFramebuffer(n.FRAMEBUFFER,U.__webglMultisampledFramebuffer);for(let bt=0;bt<xt.length;bt++){let Bt=xt[bt];U.__webglColorRenderbuffer[bt]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,U.__webglColorRenderbuffer[bt]);let $t=r.convert(Bt.format,Bt.colorSpace),at=r.convert(Bt.type),le=b(Bt.internalFormat,$t,at,Bt.colorSpace,M.isXRRenderTarget===!0),se=ot(M);n.renderbufferStorageMultisample(n.RENDERBUFFER,se,le,M.width,M.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+bt,n.RENDERBUFFER,U.__webglColorRenderbuffer[bt])}n.bindRenderbuffer(n.RENDERBUFFER,null),M.depthBuffer&&(U.__webglDepthRenderbuffer=n.createRenderbuffer(),Z(U.__webglDepthRenderbuffer,M,!0)),e.bindFramebuffer(n.FRAMEBUFFER,null)}}if(j){e.bindTexture(n.TEXTURE_CUBE_MAP,tt.__webglTexture),W(n.TEXTURE_CUBE_MAP,y,Ct);for(let xt=0;xt<6;xt++)if(o&&y.mipmaps&&y.mipmaps.length>0)for(let bt=0;bt<y.mipmaps.length;bt++)Mt(U.__webglFramebuffer[xt][bt],M,y,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+xt,bt);else Mt(U.__webglFramebuffer[xt],M,y,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+xt,0);S(y,Ct)&&_(n.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(st){let xt=M.texture;for(let bt=0,Bt=xt.length;bt<Bt;bt++){let $t=xt[bt],at=i.get($t);e.bindTexture(n.TEXTURE_2D,at.__webglTexture),W(n.TEXTURE_2D,$t,Ct),Mt(U.__webglFramebuffer,M,$t,n.COLOR_ATTACHMENT0+bt,n.TEXTURE_2D,0),S($t,Ct)&&_(n.TEXTURE_2D)}e.unbindTexture()}else{let xt=n.TEXTURE_2D;if((M.isWebGL3DRenderTarget||M.isWebGLArrayRenderTarget)&&(o?xt=M.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(xt,tt.__webglTexture),W(xt,y,Ct),o&&y.mipmaps&&y.mipmaps.length>0)for(let bt=0;bt<y.mipmaps.length;bt++)Mt(U.__webglFramebuffer[bt],M,y,n.COLOR_ATTACHMENT0,xt,bt);else Mt(U.__webglFramebuffer,M,y,n.COLOR_ATTACHMENT0,xt,0);S(y,Ct)&&_(xt),e.unbindTexture()}M.depthBuffer&&lt(M)}function Q(M){let y=g(M)||o,U=M.isWebGLMultipleRenderTargets===!0?M.texture:[M.texture];for(let tt=0,j=U.length;tt<j;tt++){let st=U[tt];if(S(st,y)){let Ct=M.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:n.TEXTURE_2D,xt=i.get(st).__webglTexture;e.bindTexture(Ct,xt),_(Ct),e.unbindTexture()}}}function X(M){if(o&&M.samples>0&&I(M)===!1){let y=M.isWebGLMultipleRenderTargets?M.texture:[M.texture],U=M.width,tt=M.height,j=n.COLOR_BUFFER_BIT,st=[],Ct=M.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,xt=i.get(M),bt=M.isWebGLMultipleRenderTargets===!0;if(bt)for(let Bt=0;Bt<y.length;Bt++)e.bindFramebuffer(n.FRAMEBUFFER,xt.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Bt,n.RENDERBUFFER,null),e.bindFramebuffer(n.FRAMEBUFFER,xt.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Bt,n.TEXTURE_2D,null,0);e.bindFramebuffer(n.READ_FRAMEBUFFER,xt.__webglMultisampledFramebuffer),e.bindFramebuffer(n.DRAW_FRAMEBUFFER,xt.__webglFramebuffer);for(let Bt=0;Bt<y.length;Bt++){st.push(n.COLOR_ATTACHMENT0+Bt),M.depthBuffer&&st.push(Ct);let $t=xt.__ignoreDepthValues!==void 0?xt.__ignoreDepthValues:!1;if($t===!1&&(M.depthBuffer&&(j|=n.DEPTH_BUFFER_BIT),M.stencilBuffer&&(j|=n.STENCIL_BUFFER_BIT)),bt&&n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,xt.__webglColorRenderbuffer[Bt]),$t===!0&&(n.invalidateFramebuffer(n.READ_FRAMEBUFFER,[Ct]),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[Ct])),bt){let at=i.get(y[Bt]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,at,0)}n.blitFramebuffer(0,0,U,tt,0,0,U,tt,j,n.NEAREST),l&&n.invalidateFramebuffer(n.READ_FRAMEBUFFER,st)}if(e.bindFramebuffer(n.READ_FRAMEBUFFER,null),e.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),bt)for(let Bt=0;Bt<y.length;Bt++){e.bindFramebuffer(n.FRAMEBUFFER,xt.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Bt,n.RENDERBUFFER,xt.__webglColorRenderbuffer[Bt]);let $t=i.get(y[Bt]).__webglTexture;e.bindFramebuffer(n.FRAMEBUFFER,xt.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Bt,n.TEXTURE_2D,$t,0)}e.bindFramebuffer(n.DRAW_FRAMEBUFFER,xt.__webglMultisampledFramebuffer)}}function ot(M){return Math.min(s.maxSamples,M.samples)}function I(M){let y=i.get(M);return o&&M.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&y.__useRenderToTexture!==!1}function Y(M){let y=a.render.frame;h.get(M)!==y&&(h.set(M,y),M.update())}function q(M,y){let U=M.colorSpace,tt=M.format,j=M.type;return M.isCompressedTexture===!0||M.isVideoTexture===!0||M.format===kc||U!==ci&&U!==An&&(me.getTransfer(U)===Ee?o===!1?t.has("EXT_sRGB")===!0&&tt===Hn?(M.format=kc,M.minFilter=wn,M.generateMipmaps=!1):y=na.sRGBToLinear(y):(tt!==Hn||j!==Ii)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",U)),y}this.allocateTextureUnit=P,this.resetTextureUnits=rt,this.setTexture2D=G,this.setTexture2DArray=et,this.setTexture3D=J,this.setTextureCube=$,this.rebindTextures=Et,this.setupRenderTarget=w,this.updateRenderTargetMipmap=Q,this.updateMultisampleRenderTarget=X,this.setupDepthRenderbuffer=lt,this.setupFrameBufferTexture=Mt,this.useMultisampledRTT=I}function P_(n,t,e){let i=e.isWebGL2;function s(r,a=An){let o,c=me.getTransfer(a);if(r===Ii)return n.UNSIGNED_BYTE;if(r===hf)return n.UNSIGNED_SHORT_4_4_4_4;if(r===uf)return n.UNSIGNED_SHORT_5_5_5_1;if(r===hp)return n.BYTE;if(r===up)return n.SHORT;if(r===Cl)return n.UNSIGNED_SHORT;if(r===lf)return n.INT;if(r===Ai)return n.UNSIGNED_INT;if(r===Ri)return n.FLOAT;if(r===Ur)return i?n.HALF_FLOAT:(o=t.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(r===fp)return n.ALPHA;if(r===Hn)return n.RGBA;if(r===dp)return n.LUMINANCE;if(r===pp)return n.LUMINANCE_ALPHA;if(r===Ki)return n.DEPTH_COMPONENT;if(r===Ys)return n.DEPTH_STENCIL;if(r===kc)return o=t.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(r===mp)return n.RED;if(r===ff)return n.RED_INTEGER;if(r===gp)return n.RG;if(r===df)return n.RG_INTEGER;if(r===pf)return n.RGBA_INTEGER;if(r===nc||r===ic||r===sc||r===rc)if(c===Ee)if(o=t.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(r===nc)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===ic)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===sc)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===rc)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=t.get("WEBGL_compressed_texture_s3tc"),o!==null){if(r===nc)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===ic)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===sc)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===rc)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===Ih||r===Dh||r===Uh||r===Nh)if(o=t.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(r===Ih)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===Dh)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===Uh)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===Nh)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===mf)return o=t.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===Oh||r===Fh)if(o=t.get("WEBGL_compressed_texture_etc"),o!==null){if(r===Oh)return c===Ee?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(r===Fh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===zh||r===Bh||r===Hh||r===kh||r===Gh||r===Vh||r===Wh||r===Xh||r===Yh||r===qh||r===$h||r===Zh||r===Jh||r===Kh)if(o=t.get("WEBGL_compressed_texture_astc"),o!==null){if(r===zh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===Bh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Hh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===kh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Gh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===Vh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===Wh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Xh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===Yh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===qh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===$h)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Zh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Jh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===Kh)return c===Ee?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===oc||r===jh||r===Qh)if(o=t.get("EXT_texture_compression_bptc"),o!==null){if(r===oc)return c===Ee?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===jh)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===Qh)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===xp||r===tu||r===eu||r===nu)if(o=t.get("EXT_texture_compression_rgtc"),o!==null){if(r===oc)return o.COMPRESSED_RED_RGTC1_EXT;if(r===tu)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===eu)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===nu)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===Ji?i?n.UNSIGNED_INT_24_8:(o=t.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):n[r]!==void 0?n[r]:null}return{convert:s}}var el=class extends fn{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},wt=class extends Ge{constructor(){super(),this.isGroup=!0,this.type="Group"}},L_={type:"move"},Rr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new wt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new wt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new L,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new L),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new wt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new L,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new L),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let i of t.hand.values())this._getHandJoint(e,i)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,i){let s=null,r=null,a=null,o=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){a=!0;for(let x of t.hand.values()){let g=e.getJointPose(x,i),m=this._getHandJoint(l,x);g!==null&&(m.matrix.fromArray(g.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,m.jointRadius=g.radius),m.visible=g!==null}let h=l.joints["index-finger-tip"],u=l.joints["thumb-tip"],f=h.position.distanceTo(u.position),d=.02,p=.005;l.inputState.pinching&&f>d+p?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&f<=d-p&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,i),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));o!==null&&(s=e.getPose(t.targetRaySpace,i),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(L_)))}return o!==null&&(o.visible=s!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let i=new wt;i.matrixAutoUpdate=!1,i.visible=!1,t.joints[e.jointName]=i,t.add(i)}return t.joints[e.jointName]}},nl=class extends Ni{constructor(t,e){super();let i=this,s=null,r=1,a=null,o="local-floor",c=1,l=null,h=null,u=null,f=null,d=null,p=null,x=e.getContextAttributes(),g=null,m=null,S=[],_=[],b=new ut,C=null,A=new fn;A.layers.enable(1),A.viewport=new Je;let R=new fn;R.layers.enable(2),R.viewport=new Je;let F=[A,R],E=new el;E.layers.enable(1),E.layers.enable(2);let v=null,N=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(W){let K=S[W];return K===void 0&&(K=new Rr,S[W]=K),K.getTargetRaySpace()},this.getControllerGrip=function(W){let K=S[W];return K===void 0&&(K=new Rr,S[W]=K),K.getGripSpace()},this.getHand=function(W){let K=S[W];return K===void 0&&(K=new Rr,S[W]=K),K.getHandSpace()};function B(W){let K=_.indexOf(W.inputSource);if(K===-1)return;let gt=S[K];gt!==void 0&&(gt.update(W.inputSource,W.frame,l||a),gt.dispatchEvent({type:W.type,data:W.inputSource}))}function rt(){s.removeEventListener("select",B),s.removeEventListener("selectstart",B),s.removeEventListener("selectend",B),s.removeEventListener("squeeze",B),s.removeEventListener("squeezestart",B),s.removeEventListener("squeezeend",B),s.removeEventListener("end",rt),s.removeEventListener("inputsourceschange",P);for(let W=0;W<S.length;W++){let K=_[W];K!==null&&(_[W]=null,S[W].disconnect(K))}v=null,N=null,t.setRenderTarget(g),d=null,f=null,u=null,s=null,m=null,_t.stop(),i.isPresenting=!1,t.setPixelRatio(C),t.setSize(b.width,b.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(W){r=W,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(W){o=W,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(W){l=W},this.getBaseLayer=function(){return f!==null?f:d},this.getBinding=function(){return u},this.getFrame=function(){return p},this.getSession=function(){return s},this.setSession=async function(W){if(s=W,s!==null){if(g=t.getRenderTarget(),s.addEventListener("select",B),s.addEventListener("selectstart",B),s.addEventListener("selectend",B),s.addEventListener("squeeze",B),s.addEventListener("squeezestart",B),s.addEventListener("squeezeend",B),s.addEventListener("end",rt),s.addEventListener("inputsourceschange",P),x.xrCompatible!==!0&&await e.makeXRCompatible(),C=t.getPixelRatio(),t.getSize(b),s.renderState.layers===void 0||t.capabilities.isWebGL2===!1){let K={antialias:s.renderState.layers===void 0?x.antialias:!0,alpha:!0,depth:x.depth,stencil:x.stencil,framebufferScaleFactor:r};d=new XRWebGLLayer(s,e,K),s.updateRenderState({baseLayer:d}),t.setPixelRatio(1),t.setSize(d.framebufferWidth,d.framebufferHeight,!1),m=new li(d.framebufferWidth,d.framebufferHeight,{format:Hn,type:Ii,colorSpace:t.outputColorSpace,stencilBuffer:x.stencil})}else{let K=null,gt=null,Rt=null;x.depth&&(Rt=x.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,K=x.stencil?Ys:Ki,gt=x.stencil?Ji:Ai);let Mt={colorFormat:e.RGBA8,depthFormat:Rt,scaleFactor:r};u=new XRWebGLBinding(s,e),f=u.createProjectionLayer(Mt),s.updateRenderState({layers:[f]}),t.setPixelRatio(1),t.setSize(f.textureWidth,f.textureHeight,!1),m=new li(f.textureWidth,f.textureHeight,{format:Hn,type:Ii,depthTexture:new fa(f.textureWidth,f.textureHeight,gt,void 0,void 0,void 0,void 0,void 0,void 0,K),stencilBuffer:x.stencil,colorSpace:t.outputColorSpace,samples:x.antialias?4:0});let Z=t.properties.get(m);Z.__ignoreDepthValues=f.ignoreDepthValues}m.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await s.requestReferenceSpace(o),_t.setContext(s),_t.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode};function P(W){for(let K=0;K<W.removed.length;K++){let gt=W.removed[K],Rt=_.indexOf(gt);Rt>=0&&(_[Rt]=null,S[Rt].disconnect(gt))}for(let K=0;K<W.added.length;K++){let gt=W.added[K],Rt=_.indexOf(gt);if(Rt===-1){for(let Z=0;Z<S.length;Z++)if(Z>=_.length){_.push(gt),Rt=Z;break}else if(_[Z]===null){_[Z]=gt,Rt=Z;break}if(Rt===-1)break}let Mt=S[Rt];Mt&&Mt.connect(gt)}}let z=new L,G=new L;function et(W,K,gt){z.setFromMatrixPosition(K.matrixWorld),G.setFromMatrixPosition(gt.matrixWorld);let Rt=z.distanceTo(G),Mt=K.projectionMatrix.elements,Z=gt.projectionMatrix.elements,ht=Mt[14]/(Mt[10]-1),lt=Mt[14]/(Mt[10]+1),Et=(Mt[9]+1)/Mt[5],w=(Mt[9]-1)/Mt[5],Q=(Mt[8]-1)/Mt[0],X=(Z[8]+1)/Z[0],ot=ht*Q,I=ht*X,Y=Rt/(-Q+X),q=Y*-Q;K.matrixWorld.decompose(W.position,W.quaternion,W.scale),W.translateX(q),W.translateZ(Y),W.matrixWorld.compose(W.position,W.quaternion,W.scale),W.matrixWorldInverse.copy(W.matrixWorld).invert();let M=ht+Y,y=lt+Y,U=ot-q,tt=I+(Rt-q),j=Et*lt/y*M,st=w*lt/y*M;W.projectionMatrix.makePerspective(U,tt,j,st,M,y),W.projectionMatrixInverse.copy(W.projectionMatrix).invert()}function J(W,K){K===null?W.matrixWorld.copy(W.matrix):W.matrixWorld.multiplyMatrices(K.matrixWorld,W.matrix),W.matrixWorldInverse.copy(W.matrixWorld).invert()}this.updateCamera=function(W){if(s===null)return;E.near=R.near=A.near=W.near,E.far=R.far=A.far=W.far,(v!==E.near||N!==E.far)&&(s.updateRenderState({depthNear:E.near,depthFar:E.far}),v=E.near,N=E.far);let K=W.parent,gt=E.cameras;J(E,K);for(let Rt=0;Rt<gt.length;Rt++)J(gt[Rt],K);gt.length===2?et(E,A,R):E.projectionMatrix.copy(A.projectionMatrix),$(W,E,K)};function $(W,K,gt){gt===null?W.matrix.copy(K.matrixWorld):(W.matrix.copy(gt.matrixWorld),W.matrix.invert(),W.matrix.multiply(K.matrixWorld)),W.matrix.decompose(W.position,W.quaternion,W.scale),W.updateMatrixWorld(!0),W.projectionMatrix.copy(K.projectionMatrix),W.projectionMatrixInverse.copy(K.projectionMatrixInverse),W.isPerspectiveCamera&&(W.fov=Nr*2*Math.atan(1/W.projectionMatrix.elements[5]),W.zoom=1)}this.getCamera=function(){return E},this.getFoveation=function(){if(!(f===null&&d===null))return c},this.setFoveation=function(W){c=W,f!==null&&(f.fixedFoveation=W),d!==null&&d.fixedFoveation!==void 0&&(d.fixedFoveation=W)};let nt=null;function it(W,K){if(h=K.getViewerPose(l||a),p=K,h!==null){let gt=h.views;d!==null&&(t.setRenderTargetFramebuffer(m,d.framebuffer),t.setRenderTarget(m));let Rt=!1;gt.length!==E.cameras.length&&(E.cameras.length=0,Rt=!0);for(let Mt=0;Mt<gt.length;Mt++){let Z=gt[Mt],ht=null;if(d!==null)ht=d.getViewport(Z);else{let Et=u.getViewSubImage(f,Z);ht=Et.viewport,Mt===0&&(t.setRenderTargetTextures(m,Et.colorTexture,f.ignoreDepthValues?void 0:Et.depthStencilTexture),t.setRenderTarget(m))}let lt=F[Mt];lt===void 0&&(lt=new fn,lt.layers.enable(Mt),lt.viewport=new Je,F[Mt]=lt),lt.matrix.fromArray(Z.transform.matrix),lt.matrix.decompose(lt.position,lt.quaternion,lt.scale),lt.projectionMatrix.fromArray(Z.projectionMatrix),lt.projectionMatrixInverse.copy(lt.projectionMatrix).invert(),lt.viewport.set(ht.x,ht.y,ht.width,ht.height),Mt===0&&(E.matrix.copy(lt.matrix),E.matrix.decompose(E.position,E.quaternion,E.scale)),Rt===!0&&E.cameras.push(lt)}}for(let gt=0;gt<S.length;gt++){let Rt=_[gt],Mt=S[gt];Rt!==null&&Mt!==void 0&&Mt.update(Rt,K,l||a)}nt&&nt(W,K),K.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:K}),p=null}let _t=new bf;_t.setAnimationLoop(it),this.setAnimationLoop=function(W){nt=W},this.dispose=function(){}}};function I_(n,t){function e(g,m){g.matrixAutoUpdate===!0&&g.updateMatrix(),m.value.copy(g.matrix)}function i(g,m){m.color.getRGB(g.fogColor.value,Sf(n)),m.isFog?(g.fogNear.value=m.near,g.fogFar.value=m.far):m.isFogExp2&&(g.fogDensity.value=m.density)}function s(g,m,S,_,b){m.isMeshBasicMaterial||m.isMeshLambertMaterial?r(g,m):m.isMeshToonMaterial?(r(g,m),u(g,m)):m.isMeshPhongMaterial?(r(g,m),h(g,m)):m.isMeshStandardMaterial?(r(g,m),f(g,m),m.isMeshPhysicalMaterial&&d(g,m,b)):m.isMeshMatcapMaterial?(r(g,m),p(g,m)):m.isMeshDepthMaterial?r(g,m):m.isMeshDistanceMaterial?(r(g,m),x(g,m)):m.isMeshNormalMaterial?r(g,m):m.isLineBasicMaterial?(a(g,m),m.isLineDashedMaterial&&o(g,m)):m.isPointsMaterial?c(g,m,S,_):m.isSpriteMaterial?l(g,m):m.isShadowMaterial?(g.color.value.copy(m.color),g.opacity.value=m.opacity):m.isShaderMaterial&&(m.uniformsNeedUpdate=!1)}function r(g,m){g.opacity.value=m.opacity,m.color&&g.diffuse.value.copy(m.color),m.emissive&&g.emissive.value.copy(m.emissive).multiplyScalar(m.emissiveIntensity),m.map&&(g.map.value=m.map,e(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.bumpMap&&(g.bumpMap.value=m.bumpMap,e(m.bumpMap,g.bumpMapTransform),g.bumpScale.value=m.bumpScale,m.side===an&&(g.bumpScale.value*=-1)),m.normalMap&&(g.normalMap.value=m.normalMap,e(m.normalMap,g.normalMapTransform),g.normalScale.value.copy(m.normalScale),m.side===an&&g.normalScale.value.negate()),m.displacementMap&&(g.displacementMap.value=m.displacementMap,e(m.displacementMap,g.displacementMapTransform),g.displacementScale.value=m.displacementScale,g.displacementBias.value=m.displacementBias),m.emissiveMap&&(g.emissiveMap.value=m.emissiveMap,e(m.emissiveMap,g.emissiveMapTransform)),m.specularMap&&(g.specularMap.value=m.specularMap,e(m.specularMap,g.specularMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest);let S=t.get(m).envMap;if(S&&(g.envMap.value=S,g.flipEnvMap.value=S.isCubeTexture&&S.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=m.reflectivity,g.ior.value=m.ior,g.refractionRatio.value=m.refractionRatio),m.lightMap){g.lightMap.value=m.lightMap;let _=n._useLegacyLights===!0?Math.PI:1;g.lightMapIntensity.value=m.lightMapIntensity*_,e(m.lightMap,g.lightMapTransform)}m.aoMap&&(g.aoMap.value=m.aoMap,g.aoMapIntensity.value=m.aoMapIntensity,e(m.aoMap,g.aoMapTransform))}function a(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,m.map&&(g.map.value=m.map,e(m.map,g.mapTransform))}function o(g,m){g.dashSize.value=m.dashSize,g.totalSize.value=m.dashSize+m.gapSize,g.scale.value=m.scale}function c(g,m,S,_){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.size.value=m.size*S,g.scale.value=_*.5,m.map&&(g.map.value=m.map,e(m.map,g.uvTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function l(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.rotation.value=m.rotation,m.map&&(g.map.value=m.map,e(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function h(g,m){g.specular.value.copy(m.specular),g.shininess.value=Math.max(m.shininess,1e-4)}function u(g,m){m.gradientMap&&(g.gradientMap.value=m.gradientMap)}function f(g,m){g.metalness.value=m.metalness,m.metalnessMap&&(g.metalnessMap.value=m.metalnessMap,e(m.metalnessMap,g.metalnessMapTransform)),g.roughness.value=m.roughness,m.roughnessMap&&(g.roughnessMap.value=m.roughnessMap,e(m.roughnessMap,g.roughnessMapTransform)),t.get(m).envMap&&(g.envMapIntensity.value=m.envMapIntensity)}function d(g,m,S){g.ior.value=m.ior,m.sheen>0&&(g.sheenColor.value.copy(m.sheenColor).multiplyScalar(m.sheen),g.sheenRoughness.value=m.sheenRoughness,m.sheenColorMap&&(g.sheenColorMap.value=m.sheenColorMap,e(m.sheenColorMap,g.sheenColorMapTransform)),m.sheenRoughnessMap&&(g.sheenRoughnessMap.value=m.sheenRoughnessMap,e(m.sheenRoughnessMap,g.sheenRoughnessMapTransform))),m.clearcoat>0&&(g.clearcoat.value=m.clearcoat,g.clearcoatRoughness.value=m.clearcoatRoughness,m.clearcoatMap&&(g.clearcoatMap.value=m.clearcoatMap,e(m.clearcoatMap,g.clearcoatMapTransform)),m.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=m.clearcoatRoughnessMap,e(m.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),m.clearcoatNormalMap&&(g.clearcoatNormalMap.value=m.clearcoatNormalMap,e(m.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(m.clearcoatNormalScale),m.side===an&&g.clearcoatNormalScale.value.negate())),m.iridescence>0&&(g.iridescence.value=m.iridescence,g.iridescenceIOR.value=m.iridescenceIOR,g.iridescenceThicknessMinimum.value=m.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=m.iridescenceThicknessRange[1],m.iridescenceMap&&(g.iridescenceMap.value=m.iridescenceMap,e(m.iridescenceMap,g.iridescenceMapTransform)),m.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=m.iridescenceThicknessMap,e(m.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),m.transmission>0&&(g.transmission.value=m.transmission,g.transmissionSamplerMap.value=S.texture,g.transmissionSamplerSize.value.set(S.width,S.height),m.transmissionMap&&(g.transmissionMap.value=m.transmissionMap,e(m.transmissionMap,g.transmissionMapTransform)),g.thickness.value=m.thickness,m.thicknessMap&&(g.thicknessMap.value=m.thicknessMap,e(m.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=m.attenuationDistance,g.attenuationColor.value.copy(m.attenuationColor)),m.anisotropy>0&&(g.anisotropyVector.value.set(m.anisotropy*Math.cos(m.anisotropyRotation),m.anisotropy*Math.sin(m.anisotropyRotation)),m.anisotropyMap&&(g.anisotropyMap.value=m.anisotropyMap,e(m.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=m.specularIntensity,g.specularColor.value.copy(m.specularColor),m.specularColorMap&&(g.specularColorMap.value=m.specularColorMap,e(m.specularColorMap,g.specularColorMapTransform)),m.specularIntensityMap&&(g.specularIntensityMap.value=m.specularIntensityMap,e(m.specularIntensityMap,g.specularIntensityMapTransform))}function p(g,m){m.matcap&&(g.matcap.value=m.matcap)}function x(g,m){let S=t.get(m).light;g.referencePosition.value.setFromMatrixPosition(S.matrixWorld),g.nearDistance.value=S.shadow.camera.near,g.farDistance.value=S.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:s}}function D_(n,t,e,i){let s={},r={},a=[],o=e.isWebGL2?n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS):0;function c(S,_){let b=_.program;i.uniformBlockBinding(S,b)}function l(S,_){let b=s[S.id];b===void 0&&(p(S),b=h(S),s[S.id]=b,S.addEventListener("dispose",g));let C=_.program;i.updateUBOMapping(S,C);let A=t.render.frame;r[S.id]!==A&&(f(S),r[S.id]=A)}function h(S){let _=u();S.__bindingPointIndex=_;let b=n.createBuffer(),C=S.__size,A=S.usage;return n.bindBuffer(n.UNIFORM_BUFFER,b),n.bufferData(n.UNIFORM_BUFFER,C,A),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,_,b),b}function u(){for(let S=0;S<o;S++)if(a.indexOf(S)===-1)return a.push(S),S;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function f(S){let _=s[S.id],b=S.uniforms,C=S.__cache;n.bindBuffer(n.UNIFORM_BUFFER,_);for(let A=0,R=b.length;A<R;A++){let F=Array.isArray(b[A])?b[A]:[b[A]];for(let E=0,v=F.length;E<v;E++){let N=F[E];if(d(N,A,E,C)===!0){let B=N.__offset,rt=Array.isArray(N.value)?N.value:[N.value],P=0;for(let z=0;z<rt.length;z++){let G=rt[z],et=x(G);typeof G=="number"||typeof G=="boolean"?(N.__data[0]=G,n.bufferSubData(n.UNIFORM_BUFFER,B+P,N.__data)):G.isMatrix3?(N.__data[0]=G.elements[0],N.__data[1]=G.elements[1],N.__data[2]=G.elements[2],N.__data[3]=0,N.__data[4]=G.elements[3],N.__data[5]=G.elements[4],N.__data[6]=G.elements[5],N.__data[7]=0,N.__data[8]=G.elements[6],N.__data[9]=G.elements[7],N.__data[10]=G.elements[8],N.__data[11]=0):(G.toArray(N.__data,P),P+=et.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,B,N.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function d(S,_,b,C){let A=S.value,R=_+"_"+b;if(C[R]===void 0)return typeof A=="number"||typeof A=="boolean"?C[R]=A:C[R]=A.clone(),!0;{let F=C[R];if(typeof A=="number"||typeof A=="boolean"){if(F!==A)return C[R]=A,!0}else if(F.equals(A)===!1)return F.copy(A),!0}return!1}function p(S){let _=S.uniforms,b=0,C=16;for(let R=0,F=_.length;R<F;R++){let E=Array.isArray(_[R])?_[R]:[_[R]];for(let v=0,N=E.length;v<N;v++){let B=E[v],rt=Array.isArray(B.value)?B.value:[B.value];for(let P=0,z=rt.length;P<z;P++){let G=rt[P],et=x(G),J=b%C;J!==0&&C-J<et.boundary&&(b+=C-J),B.__data=new Float32Array(et.storage/Float32Array.BYTES_PER_ELEMENT),B.__offset=b,b+=et.storage}}}let A=b%C;return A>0&&(b+=C-A),S.__size=b,S.__cache={},this}function x(S){let _={boundary:0,storage:0};return typeof S=="number"||typeof S=="boolean"?(_.boundary=4,_.storage=4):S.isVector2?(_.boundary=8,_.storage=8):S.isVector3||S.isColor?(_.boundary=16,_.storage=12):S.isVector4?(_.boundary=16,_.storage=16):S.isMatrix3?(_.boundary=48,_.storage=48):S.isMatrix4?(_.boundary=64,_.storage=64):S.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",S),_}function g(S){let _=S.target;_.removeEventListener("dispose",g);let b=a.indexOf(_.__bindingPointIndex);a.splice(b,1),n.deleteBuffer(s[_.id]),delete s[_.id],delete r[_.id]}function m(){for(let S in s)n.deleteBuffer(s[S]);a=[],s={},r={}}return{bind:c,update:l,dispose:m}}var Fr=class{constructor(t={}){let{canvas:e=Gp(),context:i=null,depth:s=!0,stencil:r=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1}=t;this.isWebGLRenderer=!0;let f;i!==null?f=i.getContextAttributes().alpha:f=a;let d=new Uint32Array(4),p=new Int32Array(4),x=null,g=null,m=[],S=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Ce,this._useLegacyLights=!1,this.toneMapping=Li,this.toneMappingExposure=1;let _=this,b=!1,C=0,A=0,R=null,F=-1,E=null,v=new Je,N=new Je,B=null,rt=new Ft(0),P=0,z=e.width,G=e.height,et=1,J=null,$=null,nt=new Je(0,0,z,G),it=new Je(0,0,z,G),_t=!1,W=new Or,K=!1,gt=!1,Rt=null,Mt=new Me,Z=new ut,ht=new L,lt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function Et(){return R===null?et:1}let w=i;function Q(T,O){for(let k=0;k<T.length;k++){let V=T[k],H=e.getContext(V,O);if(H!==null)return H}return null}try{let T={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${wl}`),e.addEventListener("webglcontextlost",dt,!1),e.addEventListener("webglcontextrestored",D,!1),e.addEventListener("webglcontextcreationerror",yt,!1),w===null){let O=["webgl2","webgl","experimental-webgl"];if(_.isWebGL1Renderer===!0&&O.shift(),w=Q(O,T),w===null)throw Q(O)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&w instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),w.getShaderPrecisionFormat===void 0&&(w.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(T){throw console.error("THREE.WebGLRenderer: "+T.message),T}let X,ot,I,Y,q,M,y,U,tt,j,st,Ct,xt,bt,Bt,$t,at,le,se,Xt,Ot,Pt,Kt,fe;function Ie(){X=new jg(w),ot=new Yg(w,X,t),X.init(ot),Pt=new P_(w,X,ot),I=new R_(w,X,ot),Y=new ex(w),q=new g_,M=new C_(w,X,I,q,ot,Pt,Y),y=new $g(_),U=new Kg(_),tt=new lm(w,ot),Kt=new Wg(w,X,tt,ot),j=new Qg(w,tt,Y,Kt),st=new rx(w,j,tt,Y),se=new sx(w,ot,M),$t=new qg(q),Ct=new m_(_,y,U,X,ot,Kt,$t),xt=new I_(_,q),bt=new __,Bt=new b_(X,ot),le=new Vg(_,y,U,I,st,f,c),at=new A_(_,st,ot),fe=new D_(w,Y,ot,I),Xt=new Xg(w,X,Y,ot),Ot=new tx(w,X,Y,ot),Y.programs=Ct.programs,_.capabilities=ot,_.extensions=X,_.properties=q,_.renderLists=bt,_.shadowMap=at,_.state=I,_.info=Y}Ie();let ee=new nl(_,w);this.xr=ee,this.getContext=function(){return w},this.getContextAttributes=function(){return w.getContextAttributes()},this.forceContextLoss=function(){let T=X.get("WEBGL_lose_context");T&&T.loseContext()},this.forceContextRestore=function(){let T=X.get("WEBGL_lose_context");T&&T.restoreContext()},this.getPixelRatio=function(){return et},this.setPixelRatio=function(T){T!==void 0&&(et=T,this.setSize(z,G,!1))},this.getSize=function(T){return T.set(z,G)},this.setSize=function(T,O,k=!0){if(ee.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}z=T,G=O,e.width=Math.floor(T*et),e.height=Math.floor(O*et),k===!0&&(e.style.width=T+"px",e.style.height=O+"px"),this.setViewport(0,0,T,O)},this.getDrawingBufferSize=function(T){return T.set(z*et,G*et).floor()},this.setDrawingBufferSize=function(T,O,k){z=T,G=O,et=k,e.width=Math.floor(T*k),e.height=Math.floor(O*k),this.setViewport(0,0,T,O)},this.getCurrentViewport=function(T){return T.copy(v)},this.getViewport=function(T){return T.copy(nt)},this.setViewport=function(T,O,k,V){T.isVector4?nt.set(T.x,T.y,T.z,T.w):nt.set(T,O,k,V),I.viewport(v.copy(nt).multiplyScalar(et).floor())},this.getScissor=function(T){return T.copy(it)},this.setScissor=function(T,O,k,V){T.isVector4?it.set(T.x,T.y,T.z,T.w):it.set(T,O,k,V),I.scissor(N.copy(it).multiplyScalar(et).floor())},this.getScissorTest=function(){return _t},this.setScissorTest=function(T){I.setScissorTest(_t=T)},this.setOpaqueSort=function(T){J=T},this.setTransparentSort=function(T){$=T},this.getClearColor=function(T){return T.copy(le.getClearColor())},this.setClearColor=function(){le.setClearColor.apply(le,arguments)},this.getClearAlpha=function(){return le.getClearAlpha()},this.setClearAlpha=function(){le.setClearAlpha.apply(le,arguments)},this.clear=function(T=!0,O=!0,k=!0){let V=0;if(T){let H=!1;if(R!==null){let Tt=R.texture.format;H=Tt===pf||Tt===df||Tt===ff}if(H){let Tt=R.texture.type,Dt=Tt===Ii||Tt===Ai||Tt===Cl||Tt===Ji||Tt===hf||Tt===uf,kt=le.getClearColor(),Vt=le.getClearAlpha(),Qt=kt.r,Yt=kt.g,Zt=kt.b;Dt?(d[0]=Qt,d[1]=Yt,d[2]=Zt,d[3]=Vt,w.clearBufferuiv(w.COLOR,0,d)):(p[0]=Qt,p[1]=Yt,p[2]=Zt,p[3]=Vt,w.clearBufferiv(w.COLOR,0,p))}else V|=w.COLOR_BUFFER_BIT}O&&(V|=w.DEPTH_BUFFER_BIT),k&&(V|=w.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),w.clear(V)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",dt,!1),e.removeEventListener("webglcontextrestored",D,!1),e.removeEventListener("webglcontextcreationerror",yt,!1),bt.dispose(),Bt.dispose(),q.dispose(),y.dispose(),U.dispose(),st.dispose(),Kt.dispose(),fe.dispose(),Ct.dispose(),ee.dispose(),ee.removeEventListener("sessionstart",cn),ee.removeEventListener("sessionend",ve),Rt&&(Rt.dispose(),Rt=null),ln.stop()};function dt(T){T.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),b=!0}function D(){console.log("THREE.WebGLRenderer: Context Restored."),b=!1;let T=Y.autoReset,O=at.enabled,k=at.autoUpdate,V=at.needsUpdate,H=at.type;Ie(),Y.autoReset=T,at.enabled=O,at.autoUpdate=k,at.needsUpdate=V,at.type=H}function yt(T){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",T.statusMessage)}function vt(T){let O=T.target;O.removeEventListener("dispose",vt),Gt(O)}function Gt(T){Ht(T),q.remove(T)}function Ht(T){let O=q.get(T).programs;O!==void 0&&(O.forEach(function(k){Ct.releaseProgram(k)}),T.isShaderMaterial&&Ct.releaseShaderCache(T))}this.renderBufferDirect=function(T,O,k,V,H,Tt){O===null&&(O=lt);let Dt=H.isMesh&&H.matrixWorld.determinant()<0,kt=Ad(T,O,k,V,H);I.setMaterial(V,Dt);let Vt=k.index,Qt=1;if(V.wireframe===!0){if(Vt=j.getWireframeAttribute(k),Vt===void 0)return;Qt=2}let Yt=k.drawRange,Zt=k.attributes.position,Ue=Yt.start*Qt,xn=(Yt.start+Yt.count)*Qt;Tt!==null&&(Ue=Math.max(Ue,Tt.start*Qt),xn=Math.min(xn,(Tt.start+Tt.count)*Qt)),Vt!==null?(Ue=Math.max(Ue,0),xn=Math.min(xn,Vt.count)):Zt!=null&&(Ue=Math.max(Ue,0),xn=Math.min(xn,Zt.count));let qe=xn-Ue;if(qe<0||qe===1/0)return;Kt.setup(H,V,kt,k,Vt);let Qn,Re=Xt;if(Vt!==null&&(Qn=tt.get(Vt),Re=Ot,Re.setIndex(Qn)),H.isMesh)V.wireframe===!0?(I.setLineWidth(V.wireframeLinewidth*Et()),Re.setMode(w.LINES)):Re.setMode(w.TRIANGLES);else if(H.isLine){let ne=V.linewidth;ne===void 0&&(ne=1),I.setLineWidth(ne*Et()),H.isLineSegments?Re.setMode(w.LINES):H.isLineLoop?Re.setMode(w.LINE_LOOP):Re.setMode(w.LINE_STRIP)}else H.isPoints?Re.setMode(w.POINTS):H.isSprite&&Re.setMode(w.TRIANGLES);if(H.isBatchedMesh)Re.renderMultiDraw(H._multiDrawStarts,H._multiDrawCounts,H._multiDrawCount);else if(H.isInstancedMesh)Re.renderInstances(Ue,qe,H.count);else if(k.isInstancedBufferGeometry){let ne=k._maxInstanceCount!==void 0?k._maxInstanceCount:1/0,Ka=Math.min(k.instanceCount,ne);Re.renderInstances(Ue,qe,Ka)}else Re.render(Ue,qe)};function _e(T,O,k){T.transparent===!0&&T.side===ke&&T.forceSinglePass===!1?(T.side=an,T.needsUpdate=!0,po(T,O,k),T.side=Di,T.needsUpdate=!0,po(T,O,k),T.side=ke):po(T,O,k)}this.compile=function(T,O,k=null){k===null&&(k=T),g=Bt.get(k),g.init(),S.push(g),k.traverseVisible(function(H){H.isLight&&H.layers.test(O.layers)&&(g.pushLight(H),H.castShadow&&g.pushShadow(H))}),T!==k&&T.traverseVisible(function(H){H.isLight&&H.layers.test(O.layers)&&(g.pushLight(H),H.castShadow&&g.pushShadow(H))}),g.setupLights(_._useLegacyLights);let V=new Set;return T.traverse(function(H){let Tt=H.material;if(Tt)if(Array.isArray(Tt))for(let Dt=0;Dt<Tt.length;Dt++){let kt=Tt[Dt];_e(kt,k,H),V.add(kt)}else _e(Tt,k,H),V.add(Tt)}),S.pop(),g=null,V},this.compileAsync=function(T,O,k=null){let V=this.compile(T,O,k);return new Promise(H=>{function Tt(){if(V.forEach(function(Dt){q.get(Dt).currentProgram.isReady()&&V.delete(Dt)}),V.size===0){H(T);return}setTimeout(Tt,10)}X.get("KHR_parallel_shader_compile")!==null?Tt():setTimeout(Tt,10)})};let ye=null;function Ye(T){ye&&ye(T)}function cn(){ln.stop()}function ve(){ln.start()}let ln=new bf;ln.setAnimationLoop(Ye),typeof self<"u"&&ln.setContext(self),this.setAnimationLoop=function(T){ye=T,ee.setAnimationLoop(T),T===null?ln.stop():ln.start()},ee.addEventListener("sessionstart",cn),ee.addEventListener("sessionend",ve),this.render=function(T,O){if(O!==void 0&&O.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(b===!0)return;T.matrixWorldAutoUpdate===!0&&T.updateMatrixWorld(),O.parent===null&&O.matrixWorldAutoUpdate===!0&&O.updateMatrixWorld(),ee.enabled===!0&&ee.isPresenting===!0&&(ee.cameraAutoUpdate===!0&&ee.updateCamera(O),O=ee.getCamera()),T.isScene===!0&&T.onBeforeRender(_,T,O,R),g=Bt.get(T,S.length),g.init(),S.push(g),Mt.multiplyMatrices(O.projectionMatrix,O.matrixWorldInverse),W.setFromProjectionMatrix(Mt),gt=this.localClippingEnabled,K=$t.init(this.clippingPlanes,gt),x=bt.get(T,m.length),x.init(),m.push(x),Xn(T,O,0,_.sortObjects),x.finish(),_.sortObjects===!0&&x.sort(J,$),this.info.render.frame++,K===!0&&$t.beginShadows();let k=g.state.shadowsArray;if(at.render(k,T,O),K===!0&&$t.endShadows(),this.info.autoReset===!0&&this.info.reset(),le.render(x,T),g.setupLights(_._useLegacyLights),O.isArrayCamera){let V=O.cameras;for(let H=0,Tt=V.length;H<Tt;H++){let Dt=V[H];vh(x,T,Dt,Dt.viewport)}}else vh(x,T,O);R!==null&&(M.updateMultisampleRenderTarget(R),M.updateRenderTargetMipmap(R)),T.isScene===!0&&T.onAfterRender(_,T,O),Kt.resetDefaultState(),F=-1,E=null,S.pop(),S.length>0?g=S[S.length-1]:g=null,m.pop(),m.length>0?x=m[m.length-1]:x=null};function Xn(T,O,k,V){if(T.visible===!1)return;if(T.layers.test(O.layers)){if(T.isGroup)k=T.renderOrder;else if(T.isLOD)T.autoUpdate===!0&&T.update(O);else if(T.isLight)g.pushLight(T),T.castShadow&&g.pushShadow(T);else if(T.isSprite){if(!T.frustumCulled||W.intersectsSprite(T)){V&&ht.setFromMatrixPosition(T.matrixWorld).applyMatrix4(Mt);let Dt=st.update(T),kt=T.material;kt.visible&&x.push(T,Dt,kt,k,ht.z,null)}}else if((T.isMesh||T.isLine||T.isPoints)&&(!T.frustumCulled||W.intersectsObject(T))){let Dt=st.update(T),kt=T.material;if(V&&(T.boundingSphere!==void 0?(T.boundingSphere===null&&T.computeBoundingSphere(),ht.copy(T.boundingSphere.center)):(Dt.boundingSphere===null&&Dt.computeBoundingSphere(),ht.copy(Dt.boundingSphere.center)),ht.applyMatrix4(T.matrixWorld).applyMatrix4(Mt)),Array.isArray(kt)){let Vt=Dt.groups;for(let Qt=0,Yt=Vt.length;Qt<Yt;Qt++){let Zt=Vt[Qt],Ue=kt[Zt.materialIndex];Ue&&Ue.visible&&x.push(T,Dt,Ue,k,ht.z,Zt)}}else kt.visible&&x.push(T,Dt,kt,k,ht.z,null)}}let Tt=T.children;for(let Dt=0,kt=Tt.length;Dt<kt;Dt++)Xn(Tt[Dt],O,k,V)}function vh(T,O,k,V){let H=T.opaque,Tt=T.transmissive,Dt=T.transparent;g.setupLightsView(k),K===!0&&$t.setGlobalState(_.clippingPlanes,k),Tt.length>0&&wd(H,Tt,O,k),V&&I.viewport(v.copy(V)),H.length>0&&fo(H,O,k),Tt.length>0&&fo(Tt,O,k),Dt.length>0&&fo(Dt,O,k),I.buffers.depth.setTest(!0),I.buffers.depth.setMask(!0),I.buffers.color.setMask(!0),I.setPolygonOffset(!1)}function wd(T,O,k,V){if((k.isScene===!0?k.overrideMaterial:null)!==null)return;let Tt=ot.isWebGL2;Rt===null&&(Rt=new li(1,1,{generateMipmaps:!0,type:X.has("EXT_color_buffer_half_float")?Ur:Ii,minFilter:Dr,samples:Tt?4:0})),_.getDrawingBufferSize(Z),Tt?Rt.setSize(Z.x,Z.y):Rt.setSize(ta(Z.x),ta(Z.y));let Dt=_.getRenderTarget();_.setRenderTarget(Rt),_.getClearColor(rt),P=_.getClearAlpha(),P<1&&_.setClearColor(16777215,.5),_.clear();let kt=_.toneMapping;_.toneMapping=Li,fo(T,k,V),M.updateMultisampleRenderTarget(Rt),M.updateRenderTargetMipmap(Rt);let Vt=!1;for(let Qt=0,Yt=O.length;Qt<Yt;Qt++){let Zt=O[Qt],Ue=Zt.object,xn=Zt.geometry,qe=Zt.material,Qn=Zt.group;if(qe.side===ke&&Ue.layers.test(V.layers)){let Re=qe.side;qe.side=an,qe.needsUpdate=!0,Mh(Ue,k,V,xn,qe,Qn),qe.side=Re,qe.needsUpdate=!0,Vt=!0}}Vt===!0&&(M.updateMultisampleRenderTarget(Rt),M.updateRenderTargetMipmap(Rt)),_.setRenderTarget(Dt),_.setClearColor(rt,P),_.toneMapping=kt}function fo(T,O,k){let V=O.isScene===!0?O.overrideMaterial:null;for(let H=0,Tt=T.length;H<Tt;H++){let Dt=T[H],kt=Dt.object,Vt=Dt.geometry,Qt=V===null?Dt.material:V,Yt=Dt.group;kt.layers.test(k.layers)&&Mh(kt,O,k,Vt,Qt,Yt)}}function Mh(T,O,k,V,H,Tt){T.onBeforeRender(_,O,k,V,H,Tt),T.modelViewMatrix.multiplyMatrices(k.matrixWorldInverse,T.matrixWorld),T.normalMatrix.getNormalMatrix(T.modelViewMatrix),H.onBeforeRender(_,O,k,V,T,Tt),H.transparent===!0&&H.side===ke&&H.forceSinglePass===!1?(H.side=an,H.needsUpdate=!0,_.renderBufferDirect(k,O,V,H,T,Tt),H.side=Di,H.needsUpdate=!0,_.renderBufferDirect(k,O,V,H,T,Tt),H.side=ke):_.renderBufferDirect(k,O,V,H,T,Tt),T.onAfterRender(_,O,k,V,H,Tt)}function po(T,O,k){O.isScene!==!0&&(O=lt);let V=q.get(T),H=g.state.lights,Tt=g.state.shadowsArray,Dt=H.state.version,kt=Ct.getParameters(T,H.state,Tt,O,k),Vt=Ct.getProgramCacheKey(kt),Qt=V.programs;V.environment=T.isMeshStandardMaterial?O.environment:null,V.fog=O.fog,V.envMap=(T.isMeshStandardMaterial?U:y).get(T.envMap||V.environment),Qt===void 0&&(T.addEventListener("dispose",vt),Qt=new Map,V.programs=Qt);let Yt=Qt.get(Vt);if(Yt!==void 0){if(V.currentProgram===Yt&&V.lightsStateVersion===Dt)return Sh(T,kt),Yt}else kt.uniforms=Ct.getUniforms(T),T.onBuild(k,kt,_),T.onBeforeCompile(kt,_),Yt=Ct.acquireProgram(kt,Vt),Qt.set(Vt,Yt),V.uniforms=kt.uniforms;let Zt=V.uniforms;return(!T.isShaderMaterial&&!T.isRawShaderMaterial||T.clipping===!0)&&(Zt.clippingPlanes=$t.uniform),Sh(T,kt),V.needsLights=Cd(T),V.lightsStateVersion=Dt,V.needsLights&&(Zt.ambientLightColor.value=H.state.ambient,Zt.lightProbe.value=H.state.probe,Zt.directionalLights.value=H.state.directional,Zt.directionalLightShadows.value=H.state.directionalShadow,Zt.spotLights.value=H.state.spot,Zt.spotLightShadows.value=H.state.spotShadow,Zt.rectAreaLights.value=H.state.rectArea,Zt.ltc_1.value=H.state.rectAreaLTC1,Zt.ltc_2.value=H.state.rectAreaLTC2,Zt.pointLights.value=H.state.point,Zt.pointLightShadows.value=H.state.pointShadow,Zt.hemisphereLights.value=H.state.hemi,Zt.directionalShadowMap.value=H.state.directionalShadowMap,Zt.directionalShadowMatrix.value=H.state.directionalShadowMatrix,Zt.spotShadowMap.value=H.state.spotShadowMap,Zt.spotLightMatrix.value=H.state.spotLightMatrix,Zt.spotLightMap.value=H.state.spotLightMap,Zt.pointShadowMap.value=H.state.pointShadowMap,Zt.pointShadowMatrix.value=H.state.pointShadowMatrix),V.currentProgram=Yt,V.uniformsList=null,Yt}function Eh(T){if(T.uniformsList===null){let O=T.currentProgram.getUniforms();T.uniformsList=Vs.seqWithValue(O.seq,T.uniforms)}return T.uniformsList}function Sh(T,O){let k=q.get(T);k.outputColorSpace=O.outputColorSpace,k.batching=O.batching,k.instancing=O.instancing,k.instancingColor=O.instancingColor,k.skinning=O.skinning,k.morphTargets=O.morphTargets,k.morphNormals=O.morphNormals,k.morphColors=O.morphColors,k.morphTargetsCount=O.morphTargetsCount,k.numClippingPlanes=O.numClippingPlanes,k.numIntersection=O.numClipIntersection,k.vertexAlphas=O.vertexAlphas,k.vertexTangents=O.vertexTangents,k.toneMapping=O.toneMapping}function Ad(T,O,k,V,H){O.isScene!==!0&&(O=lt),M.resetTextureUnits();let Tt=O.fog,Dt=V.isMeshStandardMaterial?O.environment:null,kt=R===null?_.outputColorSpace:R.isXRRenderTarget===!0?R.texture.colorSpace:ci,Vt=(V.isMeshStandardMaterial?U:y).get(V.envMap||Dt),Qt=V.vertexColors===!0&&!!k.attributes.color&&k.attributes.color.itemSize===4,Yt=!!k.attributes.tangent&&(!!V.normalMap||V.anisotropy>0),Zt=!!k.morphAttributes.position,Ue=!!k.morphAttributes.normal,xn=!!k.morphAttributes.color,qe=Li;V.toneMapped&&(R===null||R.isXRRenderTarget===!0)&&(qe=_.toneMapping);let Qn=k.morphAttributes.position||k.morphAttributes.normal||k.morphAttributes.color,Re=Qn!==void 0?Qn.length:0,ne=q.get(V),Ka=g.state.lights;if(K===!0&&(gt===!0||T!==E)){let bn=T===E&&V.id===F;$t.setState(V,T,bn)}let De=!1;V.version===ne.__version?(ne.needsLights&&ne.lightsStateVersion!==Ka.state.version||ne.outputColorSpace!==kt||H.isBatchedMesh&&ne.batching===!1||!H.isBatchedMesh&&ne.batching===!0||H.isInstancedMesh&&ne.instancing===!1||!H.isInstancedMesh&&ne.instancing===!0||H.isSkinnedMesh&&ne.skinning===!1||!H.isSkinnedMesh&&ne.skinning===!0||H.isInstancedMesh&&ne.instancingColor===!0&&H.instanceColor===null||H.isInstancedMesh&&ne.instancingColor===!1&&H.instanceColor!==null||ne.envMap!==Vt||V.fog===!0&&ne.fog!==Tt||ne.numClippingPlanes!==void 0&&(ne.numClippingPlanes!==$t.numPlanes||ne.numIntersection!==$t.numIntersection)||ne.vertexAlphas!==Qt||ne.vertexTangents!==Yt||ne.morphTargets!==Zt||ne.morphNormals!==Ue||ne.morphColors!==xn||ne.toneMapping!==qe||ot.isWebGL2===!0&&ne.morphTargetsCount!==Re)&&(De=!0):(De=!0,ne.__version=V.version);let Hi=ne.currentProgram;De===!0&&(Hi=po(V,O,H));let bh=!1,mr=!1,ja=!1,sn=Hi.getUniforms(),ki=ne.uniforms;if(I.useProgram(Hi.program)&&(bh=!0,mr=!0,ja=!0),V.id!==F&&(F=V.id,mr=!0),bh||E!==T){sn.setValue(w,"projectionMatrix",T.projectionMatrix),sn.setValue(w,"viewMatrix",T.matrixWorldInverse);let bn=sn.map.cameraPosition;bn!==void 0&&bn.setValue(w,ht.setFromMatrixPosition(T.matrixWorld)),ot.logarithmicDepthBuffer&&sn.setValue(w,"logDepthBufFC",2/(Math.log(T.far+1)/Math.LN2)),(V.isMeshPhongMaterial||V.isMeshToonMaterial||V.isMeshLambertMaterial||V.isMeshBasicMaterial||V.isMeshStandardMaterial||V.isShaderMaterial)&&sn.setValue(w,"isOrthographic",T.isOrthographicCamera===!0),E!==T&&(E=T,mr=!0,ja=!0)}if(H.isSkinnedMesh){sn.setOptional(w,H,"bindMatrix"),sn.setOptional(w,H,"bindMatrixInverse");let bn=H.skeleton;bn&&(ot.floatVertexTextures?(bn.boneTexture===null&&bn.computeBoneTexture(),sn.setValue(w,"boneTexture",bn.boneTexture,M)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}H.isBatchedMesh&&(sn.setOptional(w,H,"batchingTexture"),sn.setValue(w,"batchingTexture",H._matricesTexture,M));let Qa=k.morphAttributes;if((Qa.position!==void 0||Qa.normal!==void 0||Qa.color!==void 0&&ot.isWebGL2===!0)&&se.update(H,k,Hi),(mr||ne.receiveShadow!==H.receiveShadow)&&(ne.receiveShadow=H.receiveShadow,sn.setValue(w,"receiveShadow",H.receiveShadow)),V.isMeshGouraudMaterial&&V.envMap!==null&&(ki.envMap.value=Vt,ki.flipEnvMap.value=Vt.isCubeTexture&&Vt.isRenderTargetTexture===!1?-1:1),mr&&(sn.setValue(w,"toneMappingExposure",_.toneMappingExposure),ne.needsLights&&Rd(ki,ja),Tt&&V.fog===!0&&xt.refreshFogUniforms(ki,Tt),xt.refreshMaterialUniforms(ki,V,et,G,Rt),Vs.upload(w,Eh(ne),ki,M)),V.isShaderMaterial&&V.uniformsNeedUpdate===!0&&(Vs.upload(w,Eh(ne),ki,M),V.uniformsNeedUpdate=!1),V.isSpriteMaterial&&sn.setValue(w,"center",H.center),sn.setValue(w,"modelViewMatrix",H.modelViewMatrix),sn.setValue(w,"normalMatrix",H.normalMatrix),sn.setValue(w,"modelMatrix",H.matrixWorld),V.isShaderMaterial||V.isRawShaderMaterial){let bn=V.uniformsGroups;for(let tc=0,Pd=bn.length;tc<Pd;tc++)if(ot.isWebGL2){let Th=bn[tc];fe.update(Th,Hi),fe.bind(Th,Hi)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Hi}function Rd(T,O){T.ambientLightColor.needsUpdate=O,T.lightProbe.needsUpdate=O,T.directionalLights.needsUpdate=O,T.directionalLightShadows.needsUpdate=O,T.pointLights.needsUpdate=O,T.pointLightShadows.needsUpdate=O,T.spotLights.needsUpdate=O,T.spotLightShadows.needsUpdate=O,T.rectAreaLights.needsUpdate=O,T.hemisphereLights.needsUpdate=O}function Cd(T){return T.isMeshLambertMaterial||T.isMeshToonMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isShadowMaterial||T.isShaderMaterial&&T.lights===!0}this.getActiveCubeFace=function(){return C},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return R},this.setRenderTargetTextures=function(T,O,k){q.get(T.texture).__webglTexture=O,q.get(T.depthTexture).__webglTexture=k;let V=q.get(T);V.__hasExternalTextures=!0,V.__hasExternalTextures&&(V.__autoAllocateDepthBuffer=k===void 0,V.__autoAllocateDepthBuffer||X.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),V.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(T,O){let k=q.get(T);k.__webglFramebuffer=O,k.__useDefaultFramebuffer=O===void 0},this.setRenderTarget=function(T,O=0,k=0){R=T,C=O,A=k;let V=!0,H=null,Tt=!1,Dt=!1;if(T){let Vt=q.get(T);Vt.__useDefaultFramebuffer!==void 0?(I.bindFramebuffer(w.FRAMEBUFFER,null),V=!1):Vt.__webglFramebuffer===void 0?M.setupRenderTarget(T):Vt.__hasExternalTextures&&M.rebindTextures(T,q.get(T.texture).__webglTexture,q.get(T.depthTexture).__webglTexture);let Qt=T.texture;(Qt.isData3DTexture||Qt.isDataArrayTexture||Qt.isCompressedArrayTexture)&&(Dt=!0);let Yt=q.get(T).__webglFramebuffer;T.isWebGLCubeRenderTarget?(Array.isArray(Yt[O])?H=Yt[O][k]:H=Yt[O],Tt=!0):ot.isWebGL2&&T.samples>0&&M.useMultisampledRTT(T)===!1?H=q.get(T).__webglMultisampledFramebuffer:Array.isArray(Yt)?H=Yt[k]:H=Yt,v.copy(T.viewport),N.copy(T.scissor),B=T.scissorTest}else v.copy(nt).multiplyScalar(et).floor(),N.copy(it).multiplyScalar(et).floor(),B=_t;if(I.bindFramebuffer(w.FRAMEBUFFER,H)&&ot.drawBuffers&&V&&I.drawBuffers(T,H),I.viewport(v),I.scissor(N),I.setScissorTest(B),Tt){let Vt=q.get(T.texture);w.framebufferTexture2D(w.FRAMEBUFFER,w.COLOR_ATTACHMENT0,w.TEXTURE_CUBE_MAP_POSITIVE_X+O,Vt.__webglTexture,k)}else if(Dt){let Vt=q.get(T.texture),Qt=O||0;w.framebufferTextureLayer(w.FRAMEBUFFER,w.COLOR_ATTACHMENT0,Vt.__webglTexture,k||0,Qt)}F=-1},this.readRenderTargetPixels=function(T,O,k,V,H,Tt,Dt){if(!(T&&T.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let kt=q.get(T).__webglFramebuffer;if(T.isWebGLCubeRenderTarget&&Dt!==void 0&&(kt=kt[Dt]),kt){I.bindFramebuffer(w.FRAMEBUFFER,kt);try{let Vt=T.texture,Qt=Vt.format,Yt=Vt.type;if(Qt!==Hn&&Pt.convert(Qt)!==w.getParameter(w.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let Zt=Yt===Ur&&(X.has("EXT_color_buffer_half_float")||ot.isWebGL2&&X.has("EXT_color_buffer_float"));if(Yt!==Ii&&Pt.convert(Yt)!==w.getParameter(w.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Yt===Ri&&(ot.isWebGL2||X.has("OES_texture_float")||X.has("WEBGL_color_buffer_float")))&&!Zt){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}O>=0&&O<=T.width-V&&k>=0&&k<=T.height-H&&w.readPixels(O,k,V,H,Pt.convert(Qt),Pt.convert(Yt),Tt)}finally{let Vt=R!==null?q.get(R).__webglFramebuffer:null;I.bindFramebuffer(w.FRAMEBUFFER,Vt)}}},this.copyFramebufferToTexture=function(T,O,k=0){let V=Math.pow(2,-k),H=Math.floor(O.image.width*V),Tt=Math.floor(O.image.height*V);M.setTexture2D(O,0),w.copyTexSubImage2D(w.TEXTURE_2D,k,0,0,T.x,T.y,H,Tt),I.unbindTexture()},this.copyTextureToTexture=function(T,O,k,V=0){let H=O.image.width,Tt=O.image.height,Dt=Pt.convert(k.format),kt=Pt.convert(k.type);M.setTexture2D(k,0),w.pixelStorei(w.UNPACK_FLIP_Y_WEBGL,k.flipY),w.pixelStorei(w.UNPACK_PREMULTIPLY_ALPHA_WEBGL,k.premultiplyAlpha),w.pixelStorei(w.UNPACK_ALIGNMENT,k.unpackAlignment),O.isDataTexture?w.texSubImage2D(w.TEXTURE_2D,V,T.x,T.y,H,Tt,Dt,kt,O.image.data):O.isCompressedTexture?w.compressedTexSubImage2D(w.TEXTURE_2D,V,T.x,T.y,O.mipmaps[0].width,O.mipmaps[0].height,Dt,O.mipmaps[0].data):w.texSubImage2D(w.TEXTURE_2D,V,T.x,T.y,Dt,kt,O.image),V===0&&k.generateMipmaps&&w.generateMipmap(w.TEXTURE_2D),I.unbindTexture()},this.copyTextureToTexture3D=function(T,O,k,V,H=0){if(_.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let Tt=T.max.x-T.min.x+1,Dt=T.max.y-T.min.y+1,kt=T.max.z-T.min.z+1,Vt=Pt.convert(V.format),Qt=Pt.convert(V.type),Yt;if(V.isData3DTexture)M.setTexture3D(V,0),Yt=w.TEXTURE_3D;else if(V.isDataArrayTexture||V.isCompressedArrayTexture)M.setTexture2DArray(V,0),Yt=w.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}w.pixelStorei(w.UNPACK_FLIP_Y_WEBGL,V.flipY),w.pixelStorei(w.UNPACK_PREMULTIPLY_ALPHA_WEBGL,V.premultiplyAlpha),w.pixelStorei(w.UNPACK_ALIGNMENT,V.unpackAlignment);let Zt=w.getParameter(w.UNPACK_ROW_LENGTH),Ue=w.getParameter(w.UNPACK_IMAGE_HEIGHT),xn=w.getParameter(w.UNPACK_SKIP_PIXELS),qe=w.getParameter(w.UNPACK_SKIP_ROWS),Qn=w.getParameter(w.UNPACK_SKIP_IMAGES),Re=k.isCompressedTexture?k.mipmaps[H]:k.image;w.pixelStorei(w.UNPACK_ROW_LENGTH,Re.width),w.pixelStorei(w.UNPACK_IMAGE_HEIGHT,Re.height),w.pixelStorei(w.UNPACK_SKIP_PIXELS,T.min.x),w.pixelStorei(w.UNPACK_SKIP_ROWS,T.min.y),w.pixelStorei(w.UNPACK_SKIP_IMAGES,T.min.z),k.isDataTexture||k.isData3DTexture?w.texSubImage3D(Yt,H,O.x,O.y,O.z,Tt,Dt,kt,Vt,Qt,Re.data):k.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),w.compressedTexSubImage3D(Yt,H,O.x,O.y,O.z,Tt,Dt,kt,Vt,Re.data)):w.texSubImage3D(Yt,H,O.x,O.y,O.z,Tt,Dt,kt,Vt,Qt,Re),w.pixelStorei(w.UNPACK_ROW_LENGTH,Zt),w.pixelStorei(w.UNPACK_IMAGE_HEIGHT,Ue),w.pixelStorei(w.UNPACK_SKIP_PIXELS,xn),w.pixelStorei(w.UNPACK_SKIP_ROWS,qe),w.pixelStorei(w.UNPACK_SKIP_IMAGES,Qn),H===0&&V.generateMipmaps&&w.generateMipmap(Yt),I.unbindTexture()},this.initTexture=function(T){T.isCubeTexture?M.setTextureCube(T,0):T.isData3DTexture?M.setTexture3D(T,0):T.isDataArrayTexture||T.isCompressedArrayTexture?M.setTexture2DArray(T,0):M.setTexture2D(T,0),I.unbindTexture()},this.resetState=function(){C=0,A=0,R=null,I.reset(),Kt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ai}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=t===Pl?"display-p3":"srgb",e.unpackColorSpace=me.workingColorSpace===Ra?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===Ce?ji:gf}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===ji?Ce:ci}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}},il=class extends Fr{};il.prototype.isWebGL1Renderer=!0;var da=class n{constructor(t,e=1,i=1e3){this.isFog=!0,this.name="",this.color=new Ft(t),this.near=e,this.far=i}clone(){return new n(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},zr=class extends Ge{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}},sl=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=Hc,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=$n()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,i){t*=this.stride,i*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[i+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=$n()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(e,this.stride);return i.setUsage(this.usage),i}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=$n()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},hn=new L,pa=class n{constructor(t,e,i,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=i,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,i=this.data.count;e<i;e++)hn.fromBufferAttribute(this,e),hn.applyMatrix4(t),this.setXYZ(e,hn.x,hn.y,hn.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)hn.fromBufferAttribute(this,e),hn.applyNormalMatrix(t),this.setXYZ(e,hn.x,hn.y,hn.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)hn.fromBufferAttribute(this,e),hn.transformDirection(t),this.setXYZ(e,hn.x,hn.y,hn.z);return this}setX(t,e){return this.normalized&&(e=pe(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=pe(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=pe(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=pe(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=qn(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=qn(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=qn(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=qn(e,this.array)),e}setXY(t,e,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=pe(e,this.array),i=pe(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this}setXYZ(t,e,i,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=pe(e,this.array),i=pe(i,this.array),s=pe(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this}setXYZW(t,e,i,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=pe(e,this.array),i=pe(i,this.array),s=pe(s,this.array),r=pe(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let i=0;i<this.count;i++){let s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new we(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new n(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let i=0;i<this.count;i++){let s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},Qi=class extends hi{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Ft(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Us,vr=new L,Ns=new L,Os=new L,Fs=new ut,Mr=new ut,Pf=new Me,Fo=new L,Er=new L,zo=new L,Yu=new ut,Pc=new ut,qu=new ut,Js=class extends Ge{constructor(t=new Qi){if(super(),this.isSprite=!0,this.type="Sprite",Us===void 0){Us=new Le;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new sl(e,5);Us.setIndex([0,1,2,0,2,3]),Us.setAttribute("position",new pa(i,3,0,!1)),Us.setAttribute("uv",new pa(i,2,3,!1))}this.geometry=Us,this.material=t,this.center=new ut(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ns.setFromMatrixScale(this.matrixWorld),Pf.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),Os.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ns.multiplyScalar(-Os.z);let i=this.material.rotation,s,r;i!==0&&(r=Math.cos(i),s=Math.sin(i));let a=this.center;Bo(Fo.set(-.5,-.5,0),Os,a,Ns,s,r),Bo(Er.set(.5,-.5,0),Os,a,Ns,s,r),Bo(zo.set(.5,.5,0),Os,a,Ns,s,r),Yu.set(0,0),Pc.set(1,0),qu.set(1,1);let o=t.ray.intersectTriangle(Fo,Er,zo,!1,vr);if(o===null&&(Bo(Er.set(-.5,.5,0),Os,a,Ns,s,r),Pc.set(0,1),o=t.ray.intersectTriangle(Fo,zo,Er,!1,vr),o===null))return;let c=t.ray.origin.distanceTo(vr);c<t.near||c>t.far||e.push({distance:c,point:vr.clone(),uv:Zi.getInterpolation(vr,Fo,Er,zo,Yu,Pc,qu,new ut),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function Bo(n,t,e,i,s,r){Fs.subVectors(n,e).addScalar(.5).multiply(i),s!==void 0?(Mr.x=r*Fs.x-s*Fs.y,Mr.y=s*Fs.x+r*Fs.y):Mr.copy(Fs),n.copy(t),n.x+=Mr.x,n.y+=Mr.y,n.applyMatrix4(Pf)}var ma=class extends we{constructor(t,e,i,s=1){super(t,e,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},zs=new Me,$u=new Me,Ho=[],Zu=new Cn,U_=new Me,Sr=new It,br=new Oi,ga=class extends It{constructor(t,e,i){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new ma(new Float32Array(i*16),16),this.instanceColor=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<i;s++)this.setMatrixAt(s,U_)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new Cn),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,zs),Zu.copy(t.boundingBox).applyMatrix4(zs),this.boundingBox.union(Zu)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Oi),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,zs),br.copy(t.boundingSphere).applyMatrix4(zs),this.boundingSphere.union(br)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}raycast(t,e){let i=this.matrixWorld,s=this.count;if(Sr.geometry=this.geometry,Sr.material=this.material,Sr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),br.copy(this.boundingSphere),br.applyMatrix4(i),t.ray.intersectsSphere(br)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,zs),$u.multiplyMatrices(i,zs),Sr.matrixWorld=$u,Sr.raycast(t,Ho);for(let a=0,o=Ho.length;a<o;a++){let c=Ho[a];c.instanceId=r,c.object=this,e.push(c)}Ho.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new ma(new Float32Array(this.instanceMatrix.count*3),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var Br=class extends hi{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Ft(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Ju=new Me,rl=new ra,ko=new Oi,Go=new L,Hr=class extends Ge{constructor(t=new Le,e=new Br){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){let i=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),ko.copy(i.boundingSphere),ko.applyMatrix4(s),ko.radius+=r,t.ray.intersectsSphere(ko)===!1)return;Ju.copy(s).invert(),rl.copy(t.ray).applyMatrix4(Ju);let o=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=i.index,u=i.attributes.position;if(l!==null){let f=Math.max(0,a.start),d=Math.min(l.count,a.start+a.count);for(let p=f,x=d;p<x;p++){let g=l.getX(p);Go.fromBufferAttribute(u,g),Ku(Go,g,c,s,t,e,this)}}else{let f=Math.max(0,a.start),d=Math.min(u.count,a.start+a.count);for(let p=f,x=d;p<x;p++)Go.fromBufferAttribute(u,p),Ku(Go,p,c,s,t,e,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){let s=e[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){let o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}};function Ku(n,t,e,i,s,r,a){let o=rl.distanceSqToPoint(n);if(o<e){let c=new L;rl.closestPointToPoint(n,c),c.applyMatrix4(i);let l=s.ray.origin.distanceTo(c);if(l<s.near||l>s.far)return;r.push({distance:l,distanceToRay:Math.sqrt(o),point:c,index:t,face:null,object:a})}}var ui=class extends Rn{constructor(t,e,i,s,r,a,o,c,l){super(t,e,i,s,r,a,o,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}},In=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){let i=this.getUtoTmapping(t);return this.getPoint(i,e)}getPoints(t=5){let e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return e}getSpacedPoints(t=5){let e=[];for(let i=0;i<=t;i++)e.push(this.getPointAt(i/t));return e}getLength(){let t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let e=[],i,s=this.getPoint(0),r=0;e.push(0);for(let a=1;a<=t;a++)i=this.getPoint(a/t),r+=i.distanceTo(s),e.push(r),s=i;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){let i=this.getLengths(),s=0,r=i.length,a;e?a=e:a=t*i[r-1];let o=0,c=r-1,l;for(;o<=c;)if(s=Math.floor(o+(c-o)/2),l=i[s]-a,l<0)o=s+1;else if(l>0)c=s-1;else{c=s;break}if(s=c,i[s]===a)return s/(r-1);let h=i[s],f=i[s+1]-h,d=(a-h)/f;return(s+d)/(r-1)}getTangent(t,e){let s=t-1e-4,r=t+1e-4;s<0&&(s=0),r>1&&(r=1);let a=this.getPoint(s),o=this.getPoint(r),c=e||(a.isVector2?new ut:new L);return c.copy(o).sub(a).normalize(),c}getTangentAt(t,e){let i=this.getUtoTmapping(t);return this.getTangent(i,e)}computeFrenetFrames(t,e){let i=new L,s=[],r=[],a=[],o=new L,c=new Me;for(let d=0;d<=t;d++){let p=d/t;s[d]=this.getTangentAt(p,new L)}r[0]=new L,a[0]=new L;let l=Number.MAX_VALUE,h=Math.abs(s[0].x),u=Math.abs(s[0].y),f=Math.abs(s[0].z);h<=l&&(l=h,i.set(1,0,0)),u<=l&&(l=u,i.set(0,1,0)),f<=l&&i.set(0,0,1),o.crossVectors(s[0],i).normalize(),r[0].crossVectors(s[0],o),a[0].crossVectors(s[0],r[0]);for(let d=1;d<=t;d++){if(r[d]=r[d-1].clone(),a[d]=a[d-1].clone(),o.crossVectors(s[d-1],s[d]),o.length()>Number.EPSILON){o.normalize();let p=Math.acos(Qe(s[d-1].dot(s[d]),-1,1));r[d].applyMatrix4(c.makeRotationAxis(o,p))}a[d].crossVectors(s[d],r[d])}if(e===!0){let d=Math.acos(Qe(r[0].dot(r[t]),-1,1));d/=t,s[0].dot(o.crossVectors(r[0],r[t]))>0&&(d=-d);for(let p=1;p<=t;p++)r[p].applyMatrix4(c.makeRotationAxis(s[p],d*p)),a[p].crossVectors(s[p],r[p])}return{tangents:s,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){let t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}},kr=class extends In{constructor(t=0,e=0,i=1,s=1,r=0,a=Math.PI*2,o=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=i,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=c}getPoint(t,e){let i=e||new ut,s=Math.PI*2,r=this.aEndAngle-this.aStartAngle,a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(a?r=0:r=s),this.aClockwise===!0&&!a&&(r===s?r=-s:r=r-s);let o=this.aStartAngle+t*r,c=this.aX+this.xRadius*Math.cos(o),l=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),f=c-this.aX,d=l-this.aY;c=f*h-d*u+this.aX,l=f*u+d*h+this.aY}return i.set(c,l)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){let t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}},ol=class extends kr{constructor(t,e,i,s,r,a){super(t,e,i,i,s,r,a),this.isArcCurve=!0,this.type="ArcCurve"}};function Dl(){let n=0,t=0,e=0,i=0;function s(r,a,o,c){n=r,t=o,e=-3*r+3*a-2*o-c,i=2*r-2*a+o+c}return{initCatmullRom:function(r,a,o,c,l){s(a,o,l*(o-r),l*(c-a))},initNonuniformCatmullRom:function(r,a,o,c,l,h,u){let f=(a-r)/l-(o-r)/(l+h)+(o-a)/h,d=(o-a)/h-(c-a)/(h+u)+(c-o)/u;f*=h,d*=h,s(a,o,f,d)},calc:function(r){let a=r*r,o=a*r;return n+t*r+e*a+i*o}}}var Vo=new L,Lc=new Dl,Ic=new Dl,Dc=new Dl,Gr=class extends In{constructor(t=[],e=!1,i="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=i,this.tension=s}getPoint(t,e=new L){let i=e,s=this.points,r=s.length,a=(r-(this.closed?0:1))*t,o=Math.floor(a),c=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/r)+1)*r:c===0&&o===r-1&&(o=r-2,c=1);let l,h;this.closed||o>0?l=s[(o-1)%r]:(Vo.subVectors(s[0],s[1]).add(s[0]),l=Vo);let u=s[o%r],f=s[(o+1)%r];if(this.closed||o+2<r?h=s[(o+2)%r]:(Vo.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=Vo),this.curveType==="centripetal"||this.curveType==="chordal"){let d=this.curveType==="chordal"?.5:.25,p=Math.pow(l.distanceToSquared(u),d),x=Math.pow(u.distanceToSquared(f),d),g=Math.pow(f.distanceToSquared(h),d);x<1e-4&&(x=1),p<1e-4&&(p=x),g<1e-4&&(g=x),Lc.initNonuniformCatmullRom(l.x,u.x,f.x,h.x,p,x,g),Ic.initNonuniformCatmullRom(l.y,u.y,f.y,h.y,p,x,g),Dc.initNonuniformCatmullRom(l.z,u.z,f.z,h.z,p,x,g)}else this.curveType==="catmullrom"&&(Lc.initCatmullRom(l.x,u.x,f.x,h.x,this.tension),Ic.initCatmullRom(l.y,u.y,f.y,h.y,this.tension),Dc.initCatmullRom(l.z,u.z,f.z,h.z,this.tension));return i.set(Lc.calc(c),Ic.calc(c),Dc.calc(c)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(s.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){let s=this.points[e];t.points.push(s.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(new L().fromArray(s))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}};function ju(n,t,e,i,s){let r=(i-t)*.5,a=(s-e)*.5,o=n*n,c=n*o;return(2*e-2*i+r+a)*c+(-3*e+3*i-2*r-a)*o+r*n+e}function N_(n,t){let e=1-n;return e*e*t}function O_(n,t){return 2*(1-n)*n*t}function F_(n,t){return n*n*t}function Cr(n,t,e,i){return N_(n,t)+O_(n,e)+F_(n,i)}function z_(n,t){let e=1-n;return e*e*e*t}function B_(n,t){let e=1-n;return 3*e*e*n*t}function H_(n,t){return 3*(1-n)*n*n*t}function k_(n,t){return n*n*n*t}function Pr(n,t,e,i,s){return z_(n,t)+B_(n,e)+H_(n,i)+k_(n,s)}var xa=class extends In{constructor(t=new ut,e=new ut,i=new ut,s=new ut){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=i,this.v3=s}getPoint(t,e=new ut){let i=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(Pr(t,s.x,r.x,a.x,o.x),Pr(t,s.y,r.y,a.y,o.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},al=class extends In{constructor(t=new L,e=new L,i=new L,s=new L){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=i,this.v3=s}getPoint(t,e=new L){let i=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(Pr(t,s.x,r.x,a.x,o.x),Pr(t,s.y,r.y,a.y,o.y),Pr(t,s.z,r.z,a.z,o.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},_a=class extends In{constructor(t=new ut,e=new ut){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new ut){let i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new ut){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},cl=class extends In{constructor(t=new L,e=new L){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new L){let i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new L){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},ya=class extends In{constructor(t=new ut,e=new ut,i=new ut){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new ut){let i=e,s=this.v0,r=this.v1,a=this.v2;return i.set(Cr(t,s.x,r.x,a.x),Cr(t,s.y,r.y,a.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},ll=class extends In{constructor(t=new L,e=new L,i=new L){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new L){let i=e,s=this.v0,r=this.v1,a=this.v2;return i.set(Cr(t,s.x,r.x,a.x),Cr(t,s.y,r.y,a.y),Cr(t,s.z,r.z,a.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},va=class extends In{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new ut){let i=e,s=this.points,r=(s.length-1)*t,a=Math.floor(r),o=r-a,c=s[a===0?a:a-1],l=s[a],h=s[a>s.length-2?s.length-1:a+1],u=s[a>s.length-3?s.length-1:a+2];return i.set(ju(o,c.x,l.x,h.x,u.x),ju(o,c.y,l.y,h.y,u.y)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){let s=this.points[e];t.points.push(s.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(new ut().fromArray(s))}return this}},hl=Object.freeze({__proto__:null,ArcCurve:ol,CatmullRomCurve3:Gr,CubicBezierCurve:xa,CubicBezierCurve3:al,EllipseCurve:kr,LineCurve:_a,LineCurve3:cl,QuadraticBezierCurve:ya,QuadraticBezierCurve3:ll,SplineCurve:va}),ul=class extends In{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){let i=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new hl[i](e,t))}return this}getPoint(t,e){let i=t*this.getLength(),s=this.getCurveLengths(),r=0;for(;r<s.length;){if(s[r]>=i){let a=s[r]-i,o=this.curves[r],c=o.getLength(),l=c===0?0:1-a/c;return o.getPointAt(l,e)}r++}return null}getLength(){let t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let t=[],e=0;for(let i=0,s=this.curves.length;i<s;i++)e+=this.curves[i].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){let e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){let e=[],i;for(let s=0,r=this.curves;s<r.length;s++){let a=r[s],o=a.isEllipseCurve?t*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?t*a.points.length:t,c=a.getPoints(o);for(let l=0;l<c.length;l++){let h=c[l];i&&i.equals(h)||(e.push(h),i=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){let s=t.curves[e];this.curves.push(s.clone())}return this.autoClose=t.autoClose,this}toJSON(){let t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,i=this.curves.length;e<i;e++){let s=this.curves[e];t.curves.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){let s=t.curves[e];this.curves.push(new hl[s.type]().fromJSON(s))}return this}},Ma=class extends ul{constructor(t){super(),this.type="Path",this.currentPoint=new ut,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,i=t.length;e<i;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){let i=new _a(this.currentPoint.clone(),new ut(t,e));return this.curves.push(i),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,i,s){let r=new ya(this.currentPoint.clone(),new ut(t,e),new ut(i,s));return this.curves.push(r),this.currentPoint.set(i,s),this}bezierCurveTo(t,e,i,s,r,a){let o=new xa(this.currentPoint.clone(),new ut(t,e),new ut(i,s),new ut(r,a));return this.curves.push(o),this.currentPoint.set(r,a),this}splineThru(t){let e=[this.currentPoint.clone()].concat(t),i=new va(e);return this.curves.push(i),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,i,s,r,a){let o=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(t+o,e+c,i,s,r,a),this}absarc(t,e,i,s,r,a){return this.absellipse(t,e,i,i,s,r,a),this}ellipse(t,e,i,s,r,a,o,c){let l=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+l,e+h,i,s,r,a,o,c),this}absellipse(t,e,i,s,r,a,o,c){let l=new kr(t,e,i,s,r,a,o,c);if(this.curves.length>0){let u=l.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(l);let h=l.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){let t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}};var ts=class n extends Le{constructor(t=1,e=32,i=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:i,thetaLength:s},e=Math.max(3,e);let r=[],a=[],o=[],c=[],l=new L,h=new ut;a.push(0,0,0),o.push(0,0,1),c.push(.5,.5);for(let u=0,f=3;u<=e;u++,f+=3){let d=i+u/e*s;l.x=t*Math.cos(d),l.y=t*Math.sin(d),a.push(l.x,l.y,l.z),o.push(0,0,1),h.x=(a[f]/t+1)/2,h.y=(a[f+1]/t+1)/2,c.push(h.x,h.y)}for(let u=1;u<=e;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new ae(a,3)),this.setAttribute("normal",new ae(o,3)),this.setAttribute("uv",new ae(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.segments,t.thetaStart,t.thetaLength)}},Jt=class n extends Le{constructor(t=1,e=1,i=1,s=32,r=1,a=!1,o=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:i,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:c};let l=this;s=Math.floor(s),r=Math.floor(r);let h=[],u=[],f=[],d=[],p=0,x=[],g=i/2,m=0;S(),a===!1&&(t>0&&_(!0),e>0&&_(!1)),this.setIndex(h),this.setAttribute("position",new ae(u,3)),this.setAttribute("normal",new ae(f,3)),this.setAttribute("uv",new ae(d,2));function S(){let b=new L,C=new L,A=0,R=(e-t)/i;for(let F=0;F<=r;F++){let E=[],v=F/r,N=v*(e-t)+t;for(let B=0;B<=s;B++){let rt=B/s,P=rt*c+o,z=Math.sin(P),G=Math.cos(P);C.x=N*z,C.y=-v*i+g,C.z=N*G,u.push(C.x,C.y,C.z),b.set(z,R,G).normalize(),f.push(b.x,b.y,b.z),d.push(rt,1-v),E.push(p++)}x.push(E)}for(let F=0;F<s;F++)for(let E=0;E<r;E++){let v=x[E][F],N=x[E+1][F],B=x[E+1][F+1],rt=x[E][F+1];h.push(v,N,rt),h.push(N,B,rt),A+=6}l.addGroup(m,A,0),m+=A}function _(b){let C=p,A=new ut,R=new L,F=0,E=b===!0?t:e,v=b===!0?1:-1;for(let B=1;B<=s;B++)u.push(0,g*v,0),f.push(0,v,0),d.push(.5,.5),p++;let N=p;for(let B=0;B<=s;B++){let P=B/s*c+o,z=Math.cos(P),G=Math.sin(P);R.x=E*G,R.y=g*v,R.z=E*z,u.push(R.x,R.y,R.z),f.push(0,v,0),A.x=z*.5+.5,A.y=G*.5*v+.5,d.push(A.x,A.y),p++}for(let B=0;B<s;B++){let rt=C+B,P=N+B;b===!0?h.push(P,P+1,rt):h.push(P+1,P,rt),F+=3}l.addGroup(m,F,b===!0?1:2),m+=F}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},tn=class n extends Jt{constructor(t=1,e=1,i=32,s=1,r=!1,a=0,o=Math.PI*2){super(0,t,e,i,s,r,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:i,heightSegments:s,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(t){return new n(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Ea=class n extends Le{constructor(t=[],e=[],i=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:i,detail:s};let r=[],a=[];o(s),l(i),h(),this.setAttribute("position",new ae(r,3)),this.setAttribute("normal",new ae(r.slice(),3)),this.setAttribute("uv",new ae(a,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(S){let _=new L,b=new L,C=new L;for(let A=0;A<e.length;A+=3)d(e[A+0],_),d(e[A+1],b),d(e[A+2],C),c(_,b,C,S)}function c(S,_,b,C){let A=C+1,R=[];for(let F=0;F<=A;F++){R[F]=[];let E=S.clone().lerp(b,F/A),v=_.clone().lerp(b,F/A),N=A-F;for(let B=0;B<=N;B++)B===0&&F===A?R[F][B]=E:R[F][B]=E.clone().lerp(v,B/N)}for(let F=0;F<A;F++)for(let E=0;E<2*(A-F)-1;E++){let v=Math.floor(E/2);E%2===0?(f(R[F][v+1]),f(R[F+1][v]),f(R[F][v])):(f(R[F][v+1]),f(R[F+1][v+1]),f(R[F+1][v]))}}function l(S){let _=new L;for(let b=0;b<r.length;b+=3)_.x=r[b+0],_.y=r[b+1],_.z=r[b+2],_.normalize().multiplyScalar(S),r[b+0]=_.x,r[b+1]=_.y,r[b+2]=_.z}function h(){let S=new L;for(let _=0;_<r.length;_+=3){S.x=r[_+0],S.y=r[_+1],S.z=r[_+2];let b=g(S)/2/Math.PI+.5,C=m(S)/Math.PI+.5;a.push(b,1-C)}p(),u()}function u(){for(let S=0;S<a.length;S+=6){let _=a[S+0],b=a[S+2],C=a[S+4],A=Math.max(_,b,C),R=Math.min(_,b,C);A>.9&&R<.1&&(_<.2&&(a[S+0]+=1),b<.2&&(a[S+2]+=1),C<.2&&(a[S+4]+=1))}}function f(S){r.push(S.x,S.y,S.z)}function d(S,_){let b=S*3;_.x=t[b+0],_.y=t[b+1],_.z=t[b+2]}function p(){let S=new L,_=new L,b=new L,C=new L,A=new ut,R=new ut,F=new ut;for(let E=0,v=0;E<r.length;E+=9,v+=6){S.set(r[E+0],r[E+1],r[E+2]),_.set(r[E+3],r[E+4],r[E+5]),b.set(r[E+6],r[E+7],r[E+8]),A.set(a[v+0],a[v+1]),R.set(a[v+2],a[v+3]),F.set(a[v+4],a[v+5]),C.copy(S).add(_).add(b).divideScalar(3);let N=g(C);x(A,v+0,S,N),x(R,v+2,_,N),x(F,v+4,b,N)}}function x(S,_,b,C){C<0&&S.x===1&&(a[_]=S.x-1),b.x===0&&b.z===0&&(a[_]=C/2/Math.PI+.5)}function g(S){return Math.atan2(S.z,-S.x)}function m(S){return Math.atan2(-S.y,Math.sqrt(S.x*S.x+S.z*S.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.vertices,t.indices,t.radius,t.details)}};var es=class extends Ma{constructor(t){super(t),this.uuid=$n(),this.type="Shape",this.holes=[]}getPointsHoles(t){let e=[];for(let i=0,s=this.holes.length;i<s;i++)e[i]=this.holes[i].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){let s=t.holes[e];this.holes.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,i=this.holes.length;e<i;e++){let s=this.holes[e];t.holes.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){let s=t.holes[e];this.holes.push(new Ma().fromJSON(s))}return this}},G_={triangulate:function(n,t,e=2){let i=t&&t.length,s=i?t[0]*e:n.length,r=Lf(n,0,s,e,!0),a=[];if(!r||r.next===r.prev)return a;let o,c,l,h,u,f,d;if(i&&(r=q_(n,t,r,e)),n.length>80*e){o=l=n[0],c=h=n[1];for(let p=e;p<s;p+=e)u=n[p],f=n[p+1],u<o&&(o=u),f<c&&(c=f),u>l&&(l=u),f>h&&(h=f);d=Math.max(l-o,h-c),d=d!==0?32767/d:0}return Vr(r,a,e,o,c,d,0),a}};function Lf(n,t,e,i,s){let r,a;if(s===sy(n,t,e,i)>0)for(r=t;r<e;r+=i)a=Qu(r,n[r],n[r+1],a);else for(r=e-i;r>=t;r-=i)a=Qu(r,n[r],n[r+1],a);return a&&Pa(a,a.next)&&(Xr(a),a=a.next),a}function ns(n,t){if(!n)return n;t||(t=n);let e=n,i;do if(i=!1,!e.steiner&&(Pa(e,e.next)||Pe(e.prev,e,e.next)===0)){if(Xr(e),e=t=e.prev,e===e.next)break;i=!0}else e=e.next;while(i||e!==t);return t}function Vr(n,t,e,i,s,r,a){if(!n)return;!a&&r&&j_(n,i,s,r);let o=n,c,l;for(;n.prev!==n.next;){if(c=n.prev,l=n.next,r?W_(n,i,s,r):V_(n)){t.push(c.i/e|0),t.push(n.i/e|0),t.push(l.i/e|0),Xr(n),n=l.next,o=l.next;continue}if(n=l,n===o){a?a===1?(n=X_(ns(n),t,e),Vr(n,t,e,i,s,r,2)):a===2&&Y_(n,t,e,i,s,r):Vr(ns(n),t,e,i,s,r,1);break}}}function V_(n){let t=n.prev,e=n,i=n.next;if(Pe(t,e,i)>=0)return!1;let s=t.x,r=e.x,a=i.x,o=t.y,c=e.y,l=i.y,h=s<r?s<a?s:a:r<a?r:a,u=o<c?o<l?o:l:c<l?c:l,f=s>r?s>a?s:a:r>a?r:a,d=o>c?o>l?o:l:c>l?c:l,p=i.next;for(;p!==t;){if(p.x>=h&&p.x<=f&&p.y>=u&&p.y<=d&&ks(s,o,r,c,a,l,p.x,p.y)&&Pe(p.prev,p,p.next)>=0)return!1;p=p.next}return!0}function W_(n,t,e,i){let s=n.prev,r=n,a=n.next;if(Pe(s,r,a)>=0)return!1;let o=s.x,c=r.x,l=a.x,h=s.y,u=r.y,f=a.y,d=o<c?o<l?o:l:c<l?c:l,p=h<u?h<f?h:f:u<f?u:f,x=o>c?o>l?o:l:c>l?c:l,g=h>u?h>f?h:f:u>f?u:f,m=fl(d,p,t,e,i),S=fl(x,g,t,e,i),_=n.prevZ,b=n.nextZ;for(;_&&_.z>=m&&b&&b.z<=S;){if(_.x>=d&&_.x<=x&&_.y>=p&&_.y<=g&&_!==s&&_!==a&&ks(o,h,c,u,l,f,_.x,_.y)&&Pe(_.prev,_,_.next)>=0||(_=_.prevZ,b.x>=d&&b.x<=x&&b.y>=p&&b.y<=g&&b!==s&&b!==a&&ks(o,h,c,u,l,f,b.x,b.y)&&Pe(b.prev,b,b.next)>=0))return!1;b=b.nextZ}for(;_&&_.z>=m;){if(_.x>=d&&_.x<=x&&_.y>=p&&_.y<=g&&_!==s&&_!==a&&ks(o,h,c,u,l,f,_.x,_.y)&&Pe(_.prev,_,_.next)>=0)return!1;_=_.prevZ}for(;b&&b.z<=S;){if(b.x>=d&&b.x<=x&&b.y>=p&&b.y<=g&&b!==s&&b!==a&&ks(o,h,c,u,l,f,b.x,b.y)&&Pe(b.prev,b,b.next)>=0)return!1;b=b.nextZ}return!0}function X_(n,t,e){let i=n;do{let s=i.prev,r=i.next.next;!Pa(s,r)&&If(s,i,i.next,r)&&Wr(s,r)&&Wr(r,s)&&(t.push(s.i/e|0),t.push(i.i/e|0),t.push(r.i/e|0),Xr(i),Xr(i.next),i=n=r),i=i.next}while(i!==n);return ns(i)}function Y_(n,t,e,i,s,r){let a=n;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&ey(a,o)){let c=Df(a,o);a=ns(a,a.next),c=ns(c,c.next),Vr(a,t,e,i,s,r,0),Vr(c,t,e,i,s,r,0);return}o=o.next}a=a.next}while(a!==n)}function q_(n,t,e,i){let s=[],r,a,o,c,l;for(r=0,a=t.length;r<a;r++)o=t[r]*i,c=r<a-1?t[r+1]*i:n.length,l=Lf(n,o,c,i,!1),l===l.next&&(l.steiner=!0),s.push(ty(l));for(s.sort($_),r=0;r<s.length;r++)e=Z_(s[r],e);return e}function $_(n,t){return n.x-t.x}function Z_(n,t){let e=J_(n,t);if(!e)return t;let i=Df(e,n);return ns(i,i.next),ns(e,e.next)}function J_(n,t){let e=t,i=-1/0,s,r=n.x,a=n.y;do{if(a<=e.y&&a>=e.next.y&&e.next.y!==e.y){let f=e.x+(a-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(f<=r&&f>i&&(i=f,s=e.x<e.next.x?e:e.next,f===r))return s}e=e.next}while(e!==t);if(!s)return null;let o=s,c=s.x,l=s.y,h=1/0,u;e=s;do r>=e.x&&e.x>=c&&r!==e.x&&ks(a<l?r:i,a,c,l,a<l?i:r,a,e.x,e.y)&&(u=Math.abs(a-e.y)/(r-e.x),Wr(e,n)&&(u<h||u===h&&(e.x>s.x||e.x===s.x&&K_(s,e)))&&(s=e,h=u)),e=e.next;while(e!==o);return s}function K_(n,t){return Pe(n.prev,n,t.prev)<0&&Pe(t.next,n,n.next)<0}function j_(n,t,e,i){let s=n;do s.z===0&&(s.z=fl(s.x,s.y,t,e,i)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==n);s.prevZ.nextZ=null,s.prevZ=null,Q_(s)}function Q_(n){let t,e,i,s,r,a,o,c,l=1;do{for(e=n,n=null,r=null,a=0;e;){for(a++,i=e,o=0,t=0;t<l&&(o++,i=i.nextZ,!!i);t++);for(c=l;o>0||c>0&&i;)o!==0&&(c===0||!i||e.z<=i.z)?(s=e,e=e.nextZ,o--):(s=i,i=i.nextZ,c--),r?r.nextZ=s:n=s,s.prevZ=r,r=s;e=i}r.nextZ=null,l*=2}while(a>1);return n}function fl(n,t,e,i,s){return n=(n-e)*s|0,t=(t-i)*s|0,n=(n|n<<8)&16711935,n=(n|n<<4)&252645135,n=(n|n<<2)&858993459,n=(n|n<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,n|t<<1}function ty(n){let t=n,e=n;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==n);return e}function ks(n,t,e,i,s,r,a,o){return(s-a)*(t-o)>=(n-a)*(r-o)&&(n-a)*(i-o)>=(e-a)*(t-o)&&(e-a)*(r-o)>=(s-a)*(i-o)}function ey(n,t){return n.next.i!==t.i&&n.prev.i!==t.i&&!ny(n,t)&&(Wr(n,t)&&Wr(t,n)&&iy(n,t)&&(Pe(n.prev,n,t.prev)||Pe(n,t.prev,t))||Pa(n,t)&&Pe(n.prev,n,n.next)>0&&Pe(t.prev,t,t.next)>0)}function Pe(n,t,e){return(t.y-n.y)*(e.x-t.x)-(t.x-n.x)*(e.y-t.y)}function Pa(n,t){return n.x===t.x&&n.y===t.y}function If(n,t,e,i){let s=Xo(Pe(n,t,e)),r=Xo(Pe(n,t,i)),a=Xo(Pe(e,i,n)),o=Xo(Pe(e,i,t));return!!(s!==r&&a!==o||s===0&&Wo(n,e,t)||r===0&&Wo(n,i,t)||a===0&&Wo(e,n,i)||o===0&&Wo(e,t,i))}function Wo(n,t,e){return t.x<=Math.max(n.x,e.x)&&t.x>=Math.min(n.x,e.x)&&t.y<=Math.max(n.y,e.y)&&t.y>=Math.min(n.y,e.y)}function Xo(n){return n>0?1:n<0?-1:0}function ny(n,t){let e=n;do{if(e.i!==n.i&&e.next.i!==n.i&&e.i!==t.i&&e.next.i!==t.i&&If(e,e.next,n,t))return!0;e=e.next}while(e!==n);return!1}function Wr(n,t){return Pe(n.prev,n,n.next)<0?Pe(n,t,n.next)>=0&&Pe(n,n.prev,t)>=0:Pe(n,t,n.prev)<0||Pe(n,n.next,t)<0}function iy(n,t){let e=n,i=!1,s=(n.x+t.x)/2,r=(n.y+t.y)/2;do e.y>r!=e.next.y>r&&e.next.y!==e.y&&s<(e.next.x-e.x)*(r-e.y)/(e.next.y-e.y)+e.x&&(i=!i),e=e.next;while(e!==n);return i}function Df(n,t){let e=new dl(n.i,n.x,n.y),i=new dl(t.i,t.x,t.y),s=n.next,r=t.prev;return n.next=t,t.prev=n,e.next=s,s.prev=e,i.next=e,e.prev=i,r.next=i,i.prev=r,i}function Qu(n,t,e,i){let s=new dl(n,t,e);return i?(s.next=i.next,s.prev=i,i.next.prev=s,i.next=s):(s.prev=s,s.next=s),s}function Xr(n){n.next.prev=n.prev,n.prev.next=n.next,n.prevZ&&(n.prevZ.nextZ=n.nextZ),n.nextZ&&(n.nextZ.prevZ=n.prevZ)}function dl(n,t,e){this.i=n,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function sy(n,t,e,i){let s=0;for(let r=t,a=e-i;r<e;r+=i)s+=(n[a]-n[r])*(n[r+1]+n[a+1]),a=r;return s}var Lr=class n{static area(t){let e=t.length,i=0;for(let s=e-1,r=0;r<e;s=r++)i+=t[s].x*t[r].y-t[r].x*t[s].y;return i*.5}static isClockWise(t){return n.area(t)<0}static triangulateShape(t,e){let i=[],s=[],r=[];tf(t),ef(i,t);let a=t.length;e.forEach(tf);for(let c=0;c<e.length;c++)s.push(a),a+=e[c].length,ef(i,e[c]);let o=G_.triangulate(i,s);for(let c=0;c<o.length;c+=3)r.push(o.slice(c,c+3));return r}};function tf(n){let t=n.length;t>2&&n[t-1].equals(n[0])&&n.pop()}function ef(n,t){for(let e=0;e<t.length;e++)n.push(t[e].x),n.push(t[e].y)}var Ks=class n extends Le{constructor(t=new es([new ut(.5,.5),new ut(-.5,.5),new ut(-.5,-.5),new ut(.5,-.5)]),e={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];let i=this,s=[],r=[];for(let o=0,c=t.length;o<c;o++){let l=t[o];a(l)}this.setAttribute("position",new ae(s,3)),this.setAttribute("uv",new ae(r,2)),this.computeVertexNormals();function a(o){let c=[],l=e.curveSegments!==void 0?e.curveSegments:12,h=e.steps!==void 0?e.steps:1,u=e.depth!==void 0?e.depth:1,f=e.bevelEnabled!==void 0?e.bevelEnabled:!0,d=e.bevelThickness!==void 0?e.bevelThickness:.2,p=e.bevelSize!==void 0?e.bevelSize:d-.1,x=e.bevelOffset!==void 0?e.bevelOffset:0,g=e.bevelSegments!==void 0?e.bevelSegments:3,m=e.extrudePath,S=e.UVGenerator!==void 0?e.UVGenerator:ry,_,b=!1,C,A,R,F;m&&(_=m.getSpacedPoints(h),b=!0,f=!1,C=m.computeFrenetFrames(h,!1),A=new L,R=new L,F=new L),f||(g=0,d=0,p=0,x=0);let E=o.extractPoints(l),v=E.shape,N=E.holes;if(!Lr.isClockWise(v)){v=v.reverse();for(let w=0,Q=N.length;w<Q;w++){let X=N[w];Lr.isClockWise(X)&&(N[w]=X.reverse())}}let rt=Lr.triangulateShape(v,N),P=v;for(let w=0,Q=N.length;w<Q;w++){let X=N[w];v=v.concat(X)}function z(w,Q,X){return Q||console.error("THREE.ExtrudeGeometry: vec does not exist"),w.clone().addScaledVector(Q,X)}let G=v.length,et=rt.length;function J(w,Q,X){let ot,I,Y,q=w.x-Q.x,M=w.y-Q.y,y=X.x-w.x,U=X.y-w.y,tt=q*q+M*M,j=q*U-M*y;if(Math.abs(j)>Number.EPSILON){let st=Math.sqrt(tt),Ct=Math.sqrt(y*y+U*U),xt=Q.x-M/st,bt=Q.y+q/st,Bt=X.x-U/Ct,$t=X.y+y/Ct,at=((Bt-xt)*U-($t-bt)*y)/(q*U-M*y);ot=xt+q*at-w.x,I=bt+M*at-w.y;let le=ot*ot+I*I;if(le<=2)return new ut(ot,I);Y=Math.sqrt(le/2)}else{let st=!1;q>Number.EPSILON?y>Number.EPSILON&&(st=!0):q<-Number.EPSILON?y<-Number.EPSILON&&(st=!0):Math.sign(M)===Math.sign(U)&&(st=!0),st?(ot=-M,I=q,Y=Math.sqrt(tt)):(ot=q,I=M,Y=Math.sqrt(tt/2))}return new ut(ot/Y,I/Y)}let $=[];for(let w=0,Q=P.length,X=Q-1,ot=w+1;w<Q;w++,X++,ot++)X===Q&&(X=0),ot===Q&&(ot=0),$[w]=J(P[w],P[X],P[ot]);let nt=[],it,_t=$.concat();for(let w=0,Q=N.length;w<Q;w++){let X=N[w];it=[];for(let ot=0,I=X.length,Y=I-1,q=ot+1;ot<I;ot++,Y++,q++)Y===I&&(Y=0),q===I&&(q=0),it[ot]=J(X[ot],X[Y],X[q]);nt.push(it),_t=_t.concat(it)}for(let w=0;w<g;w++){let Q=w/g,X=d*Math.cos(Q*Math.PI/2),ot=p*Math.sin(Q*Math.PI/2)+x;for(let I=0,Y=P.length;I<Y;I++){let q=z(P[I],$[I],ot);Mt(q.x,q.y,-X)}for(let I=0,Y=N.length;I<Y;I++){let q=N[I];it=nt[I];for(let M=0,y=q.length;M<y;M++){let U=z(q[M],it[M],ot);Mt(U.x,U.y,-X)}}}let W=p+x;for(let w=0;w<G;w++){let Q=f?z(v[w],_t[w],W):v[w];b?(R.copy(C.normals[0]).multiplyScalar(Q.x),A.copy(C.binormals[0]).multiplyScalar(Q.y),F.copy(_[0]).add(R).add(A),Mt(F.x,F.y,F.z)):Mt(Q.x,Q.y,0)}for(let w=1;w<=h;w++)for(let Q=0;Q<G;Q++){let X=f?z(v[Q],_t[Q],W):v[Q];b?(R.copy(C.normals[w]).multiplyScalar(X.x),A.copy(C.binormals[w]).multiplyScalar(X.y),F.copy(_[w]).add(R).add(A),Mt(F.x,F.y,F.z)):Mt(X.x,X.y,u/h*w)}for(let w=g-1;w>=0;w--){let Q=w/g,X=d*Math.cos(Q*Math.PI/2),ot=p*Math.sin(Q*Math.PI/2)+x;for(let I=0,Y=P.length;I<Y;I++){let q=z(P[I],$[I],ot);Mt(q.x,q.y,u+X)}for(let I=0,Y=N.length;I<Y;I++){let q=N[I];it=nt[I];for(let M=0,y=q.length;M<y;M++){let U=z(q[M],it[M],ot);b?Mt(U.x,U.y+_[h-1].y,_[h-1].x+X):Mt(U.x,U.y,u+X)}}}K(),gt();function K(){let w=s.length/3;if(f){let Q=0,X=G*Q;for(let ot=0;ot<et;ot++){let I=rt[ot];Z(I[2]+X,I[1]+X,I[0]+X)}Q=h+g*2,X=G*Q;for(let ot=0;ot<et;ot++){let I=rt[ot];Z(I[0]+X,I[1]+X,I[2]+X)}}else{for(let Q=0;Q<et;Q++){let X=rt[Q];Z(X[2],X[1],X[0])}for(let Q=0;Q<et;Q++){let X=rt[Q];Z(X[0]+G*h,X[1]+G*h,X[2]+G*h)}}i.addGroup(w,s.length/3-w,0)}function gt(){let w=s.length/3,Q=0;Rt(P,Q),Q+=P.length;for(let X=0,ot=N.length;X<ot;X++){let I=N[X];Rt(I,Q),Q+=I.length}i.addGroup(w,s.length/3-w,1)}function Rt(w,Q){let X=w.length;for(;--X>=0;){let ot=X,I=X-1;I<0&&(I=w.length-1);for(let Y=0,q=h+g*2;Y<q;Y++){let M=G*Y,y=G*(Y+1),U=Q+ot+M,tt=Q+I+M,j=Q+I+y,st=Q+ot+y;ht(U,tt,j,st)}}}function Mt(w,Q,X){c.push(w),c.push(Q),c.push(X)}function Z(w,Q,X){lt(w),lt(Q),lt(X);let ot=s.length/3,I=S.generateTopUV(i,s,ot-3,ot-2,ot-1);Et(I[0]),Et(I[1]),Et(I[2])}function ht(w,Q,X,ot){lt(w),lt(Q),lt(ot),lt(Q),lt(X),lt(ot);let I=s.length/3,Y=S.generateSideWallUV(i,s,I-6,I-3,I-2,I-1);Et(Y[0]),Et(Y[1]),Et(Y[3]),Et(Y[1]),Et(Y[2]),Et(Y[3])}function lt(w){s.push(c[w*3+0]),s.push(c[w*3+1]),s.push(c[w*3+2])}function Et(w){r.push(w.x),r.push(w.y)}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes,i=this.parameters.options;return oy(e,i,t)}static fromJSON(t,e){let i=[];for(let r=0,a=t.shapes.length;r<a;r++){let o=e[t.shapes[r]];i.push(o)}let s=t.options.extrudePath;return s!==void 0&&(t.options.extrudePath=new hl[s.type]().fromJSON(s)),new n(i,t.options)}},ry={generateTopUV:function(n,t,e,i,s){let r=t[e*3],a=t[e*3+1],o=t[i*3],c=t[i*3+1],l=t[s*3],h=t[s*3+1];return[new ut(r,a),new ut(o,c),new ut(l,h)]},generateSideWallUV:function(n,t,e,i,s,r){let a=t[e*3],o=t[e*3+1],c=t[e*3+2],l=t[i*3],h=t[i*3+1],u=t[i*3+2],f=t[s*3],d=t[s*3+1],p=t[s*3+2],x=t[r*3],g=t[r*3+1],m=t[r*3+2];return Math.abs(o-h)<Math.abs(a-l)?[new ut(a,1-c),new ut(l,1-u),new ut(f,1-p),new ut(x,1-m)]:[new ut(o,1-c),new ut(h,1-u),new ut(d,1-p),new ut(g,1-m)]}};function oy(n,t,e){if(e.shapes=[],Array.isArray(n))for(let i=0,s=n.length;i<s;i++){let r=n[i];e.shapes.push(r.uuid)}else e.shapes.push(n.uuid);return e.options=Object.assign({},t),t.extrudePath!==void 0&&(e.options.extrudePath=t.extrudePath.toJSON()),e}var js=class n extends Ea{constructor(t=1,e=0){let i=(1+Math.sqrt(5))/2,s=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new n(t.radius,t.detail)}},Yr=class n extends Ea{constructor(t=1,e=0){let i=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(i,s,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new n(t.radius,t.detail)}},qr=class n extends Le{constructor(t=.5,e=1,i=32,s=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:i,phiSegments:s,thetaStart:r,thetaLength:a},i=Math.max(3,i),s=Math.max(1,s);let o=[],c=[],l=[],h=[],u=t,f=(e-t)/s,d=new L,p=new ut;for(let x=0;x<=s;x++){for(let g=0;g<=i;g++){let m=r+g/i*a;d.x=u*Math.cos(m),d.y=u*Math.sin(m),c.push(d.x,d.y,d.z),l.push(0,0,1),p.x=(d.x/e+1)/2,p.y=(d.y/e+1)/2,h.push(p.x,p.y)}u+=f}for(let x=0;x<s;x++){let g=x*(i+1);for(let m=0;m<i;m++){let S=m+g,_=S,b=S+i+1,C=S+i+2,A=S+1;o.push(_,b,A),o.push(b,C,A)}}this.setIndex(o),this.setAttribute("position",new ae(c,3)),this.setAttribute("normal",new ae(l,3)),this.setAttribute("uv",new ae(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}};var xe=class n extends Le{constructor(t=1,e=32,i=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:i,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),i=Math.max(2,Math.floor(i));let c=Math.min(a+o,Math.PI),l=0,h=[],u=new L,f=new L,d=[],p=[],x=[],g=[];for(let m=0;m<=i;m++){let S=[],_=m/i,b=0;m===0&&a===0?b=.5/e:m===i&&c===Math.PI&&(b=-.5/e);for(let C=0;C<=e;C++){let A=C/e;u.x=-t*Math.cos(s+A*r)*Math.sin(a+_*o),u.y=t*Math.cos(a+_*o),u.z=t*Math.sin(s+A*r)*Math.sin(a+_*o),p.push(u.x,u.y,u.z),f.copy(u).normalize(),x.push(f.x,f.y,f.z),g.push(A+b,1-_),S.push(l++)}h.push(S)}for(let m=0;m<i;m++)for(let S=0;S<e;S++){let _=h[m][S+1],b=h[m][S],C=h[m+1][S],A=h[m+1][S+1];(m!==0||a>0)&&d.push(_,b,A),(m!==i-1||c<Math.PI)&&d.push(b,C,A)}this.setIndex(d),this.setAttribute("position",new ae(p,3)),this.setAttribute("normal",new ae(x,3)),this.setAttribute("uv",new ae(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var $r=class n extends Le{constructor(t=1,e=.4,i=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:i,tubularSegments:s,arc:r},i=Math.floor(i),s=Math.floor(s);let a=[],o=[],c=[],l=[],h=new L,u=new L,f=new L;for(let d=0;d<=i;d++)for(let p=0;p<=s;p++){let x=p/s*r,g=d/i*Math.PI*2;u.x=(t+e*Math.cos(g))*Math.cos(x),u.y=(t+e*Math.cos(g))*Math.sin(x),u.z=e*Math.sin(g),o.push(u.x,u.y,u.z),h.x=t*Math.cos(x),h.y=t*Math.sin(x),f.subVectors(u,h).normalize(),c.push(f.x,f.y,f.z),l.push(p/s),l.push(d/i)}for(let d=1;d<=i;d++)for(let p=1;p<=s;p++){let x=(s+1)*d+p-1,g=(s+1)*(d-1)+p-1,m=(s+1)*(d-1)+p,S=(s+1)*d+p;a.push(x,g,S),a.push(g,m,S)}this.setIndex(a),this.setAttribute("position",new ae(o,3)),this.setAttribute("normal",new ae(c,3)),this.setAttribute("uv",new ae(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}};var oe=class extends hi{constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new Ft(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ft(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=xf,this.normalScale=new ut(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}};function Yo(n,t,e){return!n||!e&&n.constructor===t?n:typeof t.BYTES_PER_ELEMENT=="number"?new t(n):Array.prototype.slice.call(n)}function ay(n){return ArrayBuffer.isView(n)&&!(n instanceof DataView)}var Qs=class{constructor(t,e,i,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(i),this.sampleValues=e,this.valueSize=i,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,i=this._cachedIndex,s=e[i],r=e[i-1];n:{t:{let a;e:{i:if(!(t<s)){for(let o=i+2;;){if(s===void 0){if(t<r)break i;return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)}if(i===o)break;if(r=s,s=e[++i],t<s)break t}a=e.length;break e}if(!(t>=r)){let o=e[1];t<o&&(i=2,r=o);for(let c=i-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===c)break;if(s=r,r=e[--i-1],t>=r)break t}a=i,i=0;break e}break n}for(;i<a;){let o=i+a>>>1;t<e[o]?a=o:i=o+1}if(s=e[i],r=e[i-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)}this._cachedIndex=i,this.intervalChanged_(i,r,s)}return this.interpolate_(i,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,i=this.sampleValues,s=this.valueSize,r=t*s;for(let a=0;a!==s;++a)e[a]=i[r+a];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},pl=class extends Qs{constructor(t,e,i,s){super(t,e,i,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:iu,endingEnd:iu}}intervalChanged_(t,e,i){let s=this.parameterPositions,r=t-2,a=t+1,o=s[r],c=s[a];if(o===void 0)switch(this.getSettings_().endingStart){case su:r=t,o=2*e-i;break;case ru:r=s.length-2,o=e+s[r]-s[r+1];break;default:r=t,o=i}if(c===void 0)switch(this.getSettings_().endingEnd){case su:a=t,c=2*i-e;break;case ru:a=1,c=i+s[1]-s[0];break;default:a=t-1,c=e}let l=(i-e)*.5,h=this.valueSize;this._weightPrev=l/(e-o),this._weightNext=l/(c-i),this._offsetPrev=r*h,this._offsetNext=a*h}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=t*o,l=c-o,h=this._offsetPrev,u=this._offsetNext,f=this._weightPrev,d=this._weightNext,p=(i-e)/(s-e),x=p*p,g=x*p,m=-f*g+2*f*x-f*p,S=(1+f)*g+(-1.5-2*f)*x+(-.5+f)*p+1,_=(-1-d)*g+(1.5+d)*x+.5*p,b=d*g-d*x;for(let C=0;C!==o;++C)r[C]=m*a[h+C]+S*a[l+C]+_*a[c+C]+b*a[u+C];return r}},ml=class extends Qs{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=t*o,l=c-o,h=(i-e)/(s-e),u=1-h;for(let f=0;f!==o;++f)r[f]=a[l+f]*u+a[c+f]*h;return r}},gl=class extends Qs{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t){return this.copySampleValue_(t-1)}},kn=class{constructor(t,e,i,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=Yo(e,this.TimeBufferType),this.values=Yo(i,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,i;if(e.toJSON!==this.toJSON)i=e.toJSON(t);else{i={name:t.name,times:Yo(t.times,Array),values:Yo(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(i.interpolation=s)}return i.type=t.ValueTypeName,i}InterpolantFactoryMethodDiscrete(t){return new gl(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new ml(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new pl(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case $o:e=this.InterpolantFactoryMethodDiscrete;break;case Zo:e=this.InterpolantFactoryMethodLinear;break;case ac:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let i="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(i);return console.warn("THREE.KeyframeTrack:",i),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return $o;case this.InterpolantFactoryMethodLinear:return Zo;case this.InterpolantFactoryMethodSmooth:return ac}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let i=0,s=e.length;i!==s;++i)e[i]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let i=0,s=e.length;i!==s;++i)e[i]*=t}return this}trim(t,e){let i=this.times,s=i.length,r=0,a=s-1;for(;r!==s&&i[r]<t;)++r;for(;a!==-1&&i[a]>e;)--a;if(++a,r!==0||a!==s){r>=a&&(a=Math.max(a,1),r=a-1);let o=this.getValueSize();this.times=i.slice(r,a),this.values=this.values.slice(r*o,a*o)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let i=this.times,s=this.values,r=i.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let a=null;for(let o=0;o!==r;o++){let c=i[o];if(typeof c=="number"&&isNaN(c)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,c),t=!1;break}if(a!==null&&a>c){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,c,a),t=!1;break}a=c}if(s!==void 0&&ay(s))for(let o=0,c=s.length;o!==c;++o){let l=s[o];if(isNaN(l)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,l),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),i=this.getValueSize(),s=this.getInterpolation()===ac,r=t.length-1,a=1;for(let o=1;o<r;++o){let c=!1,l=t[o],h=t[o+1];if(l!==h&&(o!==1||l!==t[0]))if(s)c=!0;else{let u=o*i,f=u-i,d=u+i;for(let p=0;p!==i;++p){let x=e[u+p];if(x!==e[f+p]||x!==e[d+p]){c=!0;break}}}if(c){if(o!==a){t[a]=t[o];let u=o*i,f=a*i;for(let d=0;d!==i;++d)e[f+d]=e[u+d]}++a}}if(r>0){t[a]=t[r];for(let o=r*i,c=a*i,l=0;l!==i;++l)e[c+l]=e[o+l];++a}return a!==t.length?(this.times=t.slice(0,a),this.values=e.slice(0,a*i)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),i=this.constructor,s=new i(this.name,t,e);return s.createInterpolant=this.createInterpolant,s}};kn.prototype.TimeBufferType=Float32Array;kn.prototype.ValueBufferType=Float32Array;kn.prototype.DefaultInterpolation=Zo;var is=class extends kn{};is.prototype.ValueTypeName="bool";is.prototype.ValueBufferType=Array;is.prototype.DefaultInterpolation=$o;is.prototype.InterpolantFactoryMethodLinear=void 0;is.prototype.InterpolantFactoryMethodSmooth=void 0;var xl=class extends kn{};xl.prototype.ValueTypeName="color";var _l=class extends kn{};_l.prototype.ValueTypeName="number";var yl=class extends Qs{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=(i-e)/(s-e),l=t*o;for(let h=l+o;l!==h;l+=4)Zn.slerpFlat(r,0,a,l-o,a,l,c);return r}},Zr=class extends kn{InterpolantFactoryMethodLinear(t){return new yl(this.times,this.values,this.getValueSize(),t)}};Zr.prototype.ValueTypeName="quaternion";Zr.prototype.DefaultInterpolation=Zo;Zr.prototype.InterpolantFactoryMethodSmooth=void 0;var ss=class extends kn{};ss.prototype.ValueTypeName="string";ss.prototype.ValueBufferType=Array;ss.prototype.DefaultInterpolation=$o;ss.prototype.InterpolantFactoryMethodLinear=void 0;ss.prototype.InterpolantFactoryMethodSmooth=void 0;var vl=class extends kn{};vl.prototype.ValueTypeName="vector";var Ml=class{constructor(t,e,i){let s=this,r=!1,a=0,o=0,c,l=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=i,this.itemStart=function(h){o++,r===!1&&s.onStart!==void 0&&s.onStart(h,a,o),r=!0},this.itemEnd=function(h){a++,s.onProgress!==void 0&&s.onProgress(h,a,o),a===o&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return c?c(h):h},this.setURLModifier=function(h){return c=h,this},this.addHandler=function(h,u){return l.push(h,u),this},this.removeHandler=function(h){let u=l.indexOf(h);return u!==-1&&l.splice(u,2),this},this.getHandler=function(h){for(let u=0,f=l.length;u<f;u+=2){let d=l[u],p=l[u+1];if(d.global&&(d.lastIndex=0),d.test(h))return p}return null}}},cy=new Ml,El=class{constructor(t){this.manager=t!==void 0?t:cy,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let i=this;return new Promise(function(s,r){i.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};El.DEFAULT_MATERIAL_NAME="__DEFAULT";var Sa=class extends Ge{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Ft(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}},ba=class extends Sa{constructor(t,e,i){super(t,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Ge.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ft(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},Uc=new Me,nf=new L,sf=new L,Sl=class{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new ut(512,512),this.map=null,this.mapPass=null,this.matrix=new Me,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Or,this._frameExtents=new ut(1,1),this._viewportCount=1,this._viewports=[new Je(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,i=this.matrix;nf.setFromMatrixPosition(t.matrixWorld),e.position.copy(nf),sf.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(sf),e.updateMatrixWorld(),Uc.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Uc),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(Uc)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var bl=class extends Sl{constructor(){super(new ua(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Ta=class extends Sa{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Ge.DEFAULT_UP),this.updateMatrix(),this.target=new Ge,this.shadow=new bl}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var wa=class{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=rf(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let e=rf();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}};function rf(){return(typeof performance>"u"?Date:performance).now()}var Ul="\\[\\]\\.:\\/",ly=new RegExp("["+Ul+"]","g"),Nl="[^"+Ul+"]",hy="[^"+Ul.replace("\\.","")+"]",uy=/((?:WC+[\/:])*)/.source.replace("WC",Nl),fy=/(WCOD+)?/.source.replace("WCOD",hy),dy=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Nl),py=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Nl),my=new RegExp("^"+uy+fy+dy+py+"$"),gy=["material","materials","bones","map"],Tl=class{constructor(t,e,i){let s=i||Te.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let i=this._targetGroup.nCachedObjects_,s=this._bindings[i];s!==void 0&&s.getValue(t,e)}setValue(t,e){let i=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=i.length;s!==r;++s)i[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,i=t.length;e!==i;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,i=t.length;e!==i;++e)t[e].unbind()}},Te=class n{constructor(t,e,i){this.path=e,this.parsedPath=i||n.parseTrackName(e),this.node=n.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,i){return t&&t.isAnimationObjectGroup?new n.Composite(t,e,i):new n(t,e,i)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(ly,"")}static parseTrackName(t){let e=my.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let i={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=i.nodeName&&i.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=i.nodeName.substring(s+1);gy.indexOf(r)!==-1&&(i.nodeName=i.nodeName.substring(0,s),i.objectName=r)}if(i.propertyName===null||i.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return i}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let i=t.skeleton.getBoneByName(e);if(i!==void 0)return i}if(t.children){let i=function(r){for(let a=0;a<r.length;a++){let o=r[a];if(o.name===e||o.uuid===e)return o;let c=i(o.children);if(c)return c}return null},s=i(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)t[e++]=i[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,i=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=n.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(i){let l=e.objectIndex;switch(i){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===l){l=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[i]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[i]}if(l!==void 0){if(t[l]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[l]}}let a=t[s];if(a===void 0){let l=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+l+"."+s+" but it wasn't found.",t);return}let o=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}c=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=r}else a.fromArray!==void 0&&a.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(c=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=s;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Te.Composite=Tl;Te.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Te.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Te.prototype.GetterByBindingType=[Te.prototype._getValue_direct,Te.prototype._getValue_array,Te.prototype._getValue_arrayElement,Te.prototype._getValue_toArray];Te.prototype.SetterByBindingTypeAndVersioning=[[Te.prototype._setValue_direct,Te.prototype._setValue_direct_setNeedsUpdate,Te.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Te.prototype._setValue_array,Te.prototype._setValue_array_setNeedsUpdate,Te.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Te.prototype._setValue_arrayElement,Te.prototype._setValue_arrayElement_setNeedsUpdate,Te.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Te.prototype._setValue_fromArray,Te.prototype._setValue_fromArray_setNeedsUpdate,Te.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var Mv=new Float32Array(1);typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:wl}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=wl);var zt=n=>document.getElementById(n),de=(n,t,e)=>Math.max(t,Math.min(e,n)),Ne=(n,t,e)=>n+(t-n)*e,Lt=(n,t,e)=>{let i=de((e-n)/(t-n),0,1);return i*i*(3-2*i)},ls=(n,t,e)=>Math.exp(-(((n-t)/e)**2)),Bl=n=>(n%=Math.PI*2,n>Math.PI&&(n-=Math.PI*2),n<-Math.PI&&(n+=Math.PI*2),n),Ia=1,ce=()=>(Ia=Ia*16807%2147483647,(Ia-1)/2147483646),Wt=(n,t)=>n+ce()*(t-n);function ir(n,t,e){let i=Math.imul(n|0,374761393)^Math.imul(t|0,668265263)^Math.imul(e|0,1442695041);return i=Math.imul(i^i>>>13,1274126177),i^=i>>>16,(i>>>0)/4294967296}function yi(n,t,e,i){let s=Math.floor(n),r=Math.floor(t),a=n-s,o=t-r,c=a*a*(3-2*a),l=o*o*(3-2*o),h=x=>e?(x%e+e)%e:x,u=ir(h(s),h(r),i),f=ir(h(s+1),h(r),i),d=ir(h(s),h(r+1),i),p=ir(h(s+1),h(r+1),i);return Ne(Ne(u,f,c),Ne(d,p,c),l)}function mi(n,t,e=4,i=0,s=0){let r=.5,a=1,o=0,c=0;for(let l=0;l<e;l++)o+=r*yi(n*a,t*a,i?i*a:0,s+l*17),c+=r,r*=.5,a*=2;return o/c}var ho="ontouchstart"in window||navigator.maxTouchPoints>0;ho&&document.body.classList.add("touch");var Ql="corridaCaninaTurbo1",ft={musicMode:0,coins:400,up:{},best:{},dog:0,track:0,diff:1,laps:3,qual:ho?1:2,music:!0,cam:0,assist:!0};try{Object.assign(ft,JSON.parse(localStorage.getItem(Ql)||"{}"))}catch{}ft.music===!1&&ft.musicMode===0&&!("musicMode"in JSON.parse((()=>{try{return localStorage.getItem(Ql)||"{}"}catch{return"{}"}})()))&&(ft.musicMode=4);function Wn(){try{localStorage.setItem(Ql,JSON.stringify(ft))}catch{}}var Nn=new Fr({canvas:zt("game"),antialias:!0,powerPreference:"high-performance"});Nn.outputColorSpace=Ce;Nn.toneMapping=Rl;Nn.shadowMap.enabled=!0;Nn.shadowMap.type=Al;var _y=Math.min(8,Nn.capabilities.getMaxAnisotropy()),Ke=new zr,he=new fn(66,1,.2,2600),Oa=new ba(16777215,5596740,.4);Ke.add(Oa);var pn=new Ta(16777215,3);pn.castShadow=!0;Object.assign(pn.shadow.camera,{left:-42,right:42,top:42,bottom:-42,near:1,far:340});pn.shadow.bias=-4e-4;pn.shadow.normalBias=.05;Ke.add(pn,pn.target);var Hl=new L(.4,.6,.3).normalize(),os={zen:{value:new Ft},hor:{value:new Ft},gnd:{value:new Ft},sunCol:{value:new Ft},sunDir:{value:new L},haze:{value:.5}},Yf=new Ln({uniforms:os,side:an,depthWrite:!1,fog:!1,vertexShader:"varying vec3 vD; void main(){ vD = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }",fragmentShader:`uniform vec3 zen, hor, gnd, sunCol, sunDir; uniform float haze; varying vec3 vD;
    void main(){
      vec3 d = normalize(vD); float h = d.y;
      vec3 c = h > 0.0 ? mix(hor, zen, pow(h, 0.5)) : mix(hor, gnd, pow(min(-h * 3.0, 1.0), 0.7));
      float sd = max(dot(d, normalize(sunDir)), 0.0);
      c += sunCol * (pow(sd, 900.0) * 14.0 + pow(sd, 40.0) * 0.45 * haze + pow(sd, 5.0) * 0.22 * haze * (1.0 - max(h, 0.0)));
      gl_FragColor = vec4(c, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`}),Xa=new It(new xe(1e3,32,16),Yf);Xa.frustumCulled=!1;Xa.renderOrder=-10;Ke.add(Xa);var yy=new Zs(Nn),rr=null;function vy(){let n=new zr;n.add(new It(new xe(50,32,16),Yf)),rr&&rr.dispose(),rr=yy.fromScene(n,.02,.1,200),qf()}function qf(){let n=ft.qual===0;Ke.environment=n?null:rr&&rr.texture,Oa.intensity=At.light.hemi+(n?1.1:0)}var th=[{n:"BAIXA",pr:.75,sh:0},{n:"M\xC9DIA",pr:1.25,sh:1024},{n:"ALTA",pr:2,sh:2048}];function $f(){let n=th[ft.qual];Nn.setPixelRatio(Math.min(devicePixelRatio,n.pr)),Nn.shadowMap.enabled=n.sh>0,pn.castShadow=n.sh>0,n.sh&&(pn.shadow.mapSize.set(n.sh,n.sh),pn.shadow.map&&(pn.shadow.map.dispose(),pn.shadow.map=null)),rr&&qf(),Ke.traverse(t=>{t.material&&[].concat(t.material).forEach(e=>e.needsUpdate=!0)}),Zf()}function Zf(){Nn.setSize(innerWidth,innerHeight,!1),he.aspect=innerWidth/innerHeight,he.updateProjectionMatrix()}addEventListener("resize",Zf);function eh(n,t){let e=document.createElement("canvas");e.width=e.height=n;let i=e.getContext("2d"),s=i.createImageData(n,n),r=s.data;for(let a=0;a<n;a++)for(let o=0;o<n;o++){let c=t(o,a),l=(a*n+o)*4;r[l]=c[0],r[l+1]=c[1],r[l+2]=c[2],r[l+3]=c[3]??255}return i.putImageData(s,0,0),e}function je(n,t=1,e=1,i=!0){let s=new ui(n);return i&&(s.colorSpace=Ce),s.wrapS=s.wrapT=Ir,s.repeat.set(t,e),s.anisotropy=_y,s}function ze(n,t,e){let i=document.createElement("canvas");return i.width=n,i.height=t,e(i.getContext("2d"),n,t),i}var Jf=(()=>{let n=ze(256,256,(t,e,i)=>{t.fillStyle="#ececec",t.fillRect(0,0,e,i);for(let s=0;s<9e3;s++){let r=Math.random()*e,a=Math.random()*i,o=3+Math.random()*8,c=185+Math.random()*70|0;t.strokeStyle=`rgba(${c},${c},${c},.55)`,t.lineWidth=.7+Math.random()*.8,t.beginPath(),t.moveTo(r,a),t.lineTo(r+(Math.random()-.5)*2,a+o),t.stroke()}});return je(n,2,2)})(),nh=new ui(ze(64,64,n=>{let t=n.createRadialGradient(32,32,2,32,32,32);t.addColorStop(0,"rgba(0,0,0,.6)"),t.addColorStop(1,"rgba(0,0,0,0)"),n.fillStyle=t,n.fillRect(0,0,64,64)})),ih=new ui(ze(64,64,n=>{let t=n.createRadialGradient(32,32,0,32,32,32);t.addColorStop(0,"rgba(255,255,255,1)"),t.addColorStop(.4,"rgba(255,255,255,.6)"),t.addColorStop(1,"rgba(255,255,255,0)"),n.fillStyle=t,n.fillRect(0,0,64,64)})),Fa=class{constructor(t,e){this.max=t,this.n=0,this.pos=new Float32Array(t*3),this.col=new Float32Array(t*3),this.size=new Float32Array(t),this.alpha=new Float32Array(t),this.vel=new Float32Array(t*3),this.life=new Float32Array(t),this.ml=new Float32Array(t),this.s0=new Float32Array(t),this.s1=new Float32Array(t),this.a0=new Float32Array(t),this.grav=new Float32Array(t),this.drag=new Float32Array(t);let i=new Le,s=(r,a)=>{let o=new we(r,a);return o.setUsage(yf),o};i.setAttribute("position",s(this.pos,3)),i.setAttribute("pcolor",s(this.col,3)),i.setAttribute("psize",s(this.size,1)),i.setAttribute("palpha",s(this.alpha,1)),this.geo=i,this.mat=new Ln({uniforms:{uScale:{value:500},map:{value:ih}},vertexShader:`attribute vec3 pcolor; attribute float psize; attribute float palpha; uniform float uScale; varying vec3 vC; varying float vA;
        void main(){ vC = pcolor; vA = palpha; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_PointSize = psize * uScale / max(0.1, -mv.z); gl_Position = projectionMatrix * mv; }`,fragmentShader:`uniform sampler2D map; varying vec3 vC; varying float vA;
        void main(){ float a = texture2D(map, gl_PointCoord).a * vA; if (a < 0.01) discard; gl_FragColor = vec4(vC, a); }`,transparent:!0,depthWrite:!1,blending:e?Ui:Pi}),this.points=new Hr(i,this.mat),this.points.frustumCulled=!1,Ke.add(this.points)}spawn(t,e,i,s,r,a,o,c,l,h,u=1,f=0,d=1){if(this.n>=this.max)return;let p=this.n++,x=p*3;this.pos[x]=t,this.pos[x+1]=e,this.pos[x+2]=i,this.vel[x]=s,this.vel[x+1]=r,this.vel[x+2]=a,this.col[x]=h[0],this.col[x+1]=h[1],this.col[x+2]=h[2],this.life[p]=this.ml[p]=o,this.s0[p]=c,this.s1[p]=l,this.a0[p]=u,this.grav[p]=f,this.drag[p]=d,this.size[p]=c,this.alpha[p]=0}copy(t,e){for(let i=0;i<3;i++)this.pos[t*3+i]=this.pos[e*3+i],this.vel[t*3+i]=this.vel[e*3+i],this.col[t*3+i]=this.col[e*3+i];this.life[t]=this.life[e],this.ml[t]=this.ml[e],this.s0[t]=this.s0[e],this.s1[t]=this.s1[e],this.a0[t]=this.a0[e],this.grav[t]=this.grav[e],this.drag[t]=this.drag[e],this.size[t]=this.size[e],this.alpha[t]=this.alpha[e]}update(t){for(let e=0;e<this.n;e++){if(this.life[e]-=t,this.life[e]<=0){this.n--,e<this.n&&(this.copy(e,this.n),e--);continue}let i=e*3,s=Math.exp(-this.drag[e]*t);this.vel[i]*=s,this.vel[i+1]=this.vel[i+1]*s-this.grav[e]*t,this.vel[i+2]*=s,this.pos[i]+=this.vel[i]*t,this.pos[i+1]+=this.vel[i+1]*t,this.pos[i+2]+=this.vel[i+2]*t,this.pos[i+1]<.02&&(this.pos[i+1]=.02,this.vel[i+1]*=-.3);let r=1-this.life[e]/this.ml[e];this.size[e]=Ne(this.s0[e],this.s1[e],r),this.alpha[e]=this.a0[e]*Math.min(1,r*10)*(1-r)}this.geo.setDrawRange(0,this.n);for(let e of["position","pcolor","psize","palpha"])this.geo.attributes[e].needsUpdate=!0;this.mat.uniforms.uScale.value=Nn.domElement.height/(2*Math.tan(vf.degToRad(he.fov)/2))}clear(){this.n=0}},Mi=new Fa(1400,!1),vi=new Fa(1200,!0);function us(n,t){let e=Math.abs(2*n-1);return Math.pow(Math.max(0,1-Math.pow(e,t)),1/t)}function En(n,t,e){let i=new Float32Array((n+1)*t*3),s=new Float32Array((n+1)*t*2),r=[],a=0,o=0;for(let l=0;l<=n;l++){let h=l/n;for(let u=0;u<t;u++){let f=e(h,u/t*Math.PI*2);i[a++]=f[0],i[a++]=f[1],i[a++]=f[2],s[o++]=u/t*2,s[o++]=h*2}}for(let l=0;l<n;l++)for(let h=0;h<t;h++){let u=l*t+h,f=l*t+(h+1)%t,d=u+t,p=f+t;r.push(u,f,d,f,p,d)}let c=new Le;return c.setAttribute("position",new we(i,3)),c.setAttribute("uv",new we(s,2)),c.setIndex(r),c.computeVertexNormals(),c}function Kr(n,t,e,i=1){let s=Math.min(t,e)*.8,r=En(10,12,(a,o)=>{let c=Ne(t,e,a)*us(a,4);return[Math.cos(o)*c,Math.sin(o)*c*i,-s+a*(n+2*s)]});return r.rotateX(Math.PI/2),r}function gi(n,t,e,i=14){let s=new xe(1,i,Math.round(i*.75));return s.scale(n,t,e),s}function er(n,t,e,i=1){let s=us(t,2.4),r=Lt(.3,.85,t),a=Ne(n.rumpW,n.chW,r),o=Ne(n.rumpH,n.chH,r),c=Math.sin(e),l=Math.cos(e),h=c*o*s;return c<0?h*=1-n.waist*ls(t,.36,.2):h+=n.arch*ls(t,.38,.22)*s,[l*a*s*i,Ne(n.rumpY,0,r)+h*i,(t-.5)*n.len]}function Ol(n,t){let[e,i,s]=n.skull,[r,a,o,c]=n.muzzle,l=e*.5,h=l+r,u=Math.sqrt(Math.max(0,1-(t/e)**2)),f=1;t>l&&(f=Math.pow(Math.max(0,1-Math.pow((t-l)/r,3)),1/3));let d=Lt(-e*.6,l,t);return{w:Math.max(i*u,a*f*d),h:Math.max(s*u,o*f*d),yc:-c*Lt(l-.03,l+.05,t),zStop:l,zEnd:Math.max(h,e)}}var re=n=>new Ft(n),Dn={shepherd:{base:re(12615482),dark:re(2037779),light:re(14726010)},dalmatian:{base:re(15855592),dark:re(1446671)},caramel:{base:re(12611626),dark:re(7224597),light:re(15782042)},grey:{base:re(8160401),light:re(15856110)},husky:{base:re(4673373),dark:re(2764600),light:re(15921904)},pug:{base:re(14003058),dark:re(2235674),light:re(15255958)},pinscher:{base:re(1446158),light:re(11097887)},pitbull:{base:re(9987647),light:re(15986406),dark:re(7226663)},boar:{base:re(5061936),dark:re(2366228),light:re(8152916),hoof:re(1446157)},opossum:{base:re(8552314),light:re(15526111),dark:re(2235675),pink:re(15321026)},gecko:{base:re(15778634),dark:re(2760469),light:re(16116952),band:re(14272488)},tegu:{base:re(1250067),light:re(15526367),belly:re(14210508)}};function Kf(n,t,e){let i=t.cy,s=t.part==="head"?Lt(t.zStop-.03,t.zStop+.05,t.lz):0;switch(n.coat){case"shepherd":{let r=Dn.shepherd;if(t.part==="ear")return e.copy(r.dark);if(t.part==="head"){let a=Lt(.01,.07,t.ly)*Lt(t.zStop+.02,t.zStop-.05,t.lz);return e.copy(r.base).lerp(r.dark,Math.max(s*.9,a*.65))}if(t.part==="body"){let a=Lt(i,i+.08,t.y)*Lt(n.len/2,n.len/2-.22,t.z);return e.copy(r.base).lerp(r.light,Lt(i-n.chH*.2,i-n.chH*.8,t.y)*.6),e.lerp(r.dark,a)}return t.part==="neck"?e.copy(r.base).lerp(r.dark,Lt(0,.05,t.ly)*.6):t.part==="tail"?e.copy(r.base).lerp(r.dark,.72):e.copy(r.base)}case"dalmatian":{let r=Dn.dalmatian;if(t.part==="ear")return e.copy(r.dark).lerp(r.base,.1);for(let a of t.spots){let o=t.x-a[0],c=t.y-a[1],l=t.z-a[2];if(o*o+c*c+l*l<a[3]*a[3])return e.copy(r.dark)}return e.copy(r.base)}case"caramel":{let r=Dn.caramel;if(t.part==="ear")return e.copy(r.base).lerp(r.dark,.35);if(t.part==="head")return e.copy(r.base).lerp(r.light,Math.max(s*.75,Lt(0,-.035,t.ly)*.7));if(t.part==="body"){let a=Lt(i-n.chH*.1,i-n.chH*.7,t.y),o=Lt(n.len/2-.2,n.len/2-.05,t.z)*Lt(i+n.chH*.2,i-n.chH*.2,t.y);return e.copy(r.base).lerp(r.light,Math.max(a,o)*.85)}return t.part==="neck"?e.copy(r.base).lerp(r.light,Lt(0,-.03,t.ly)*.8):t.part==="paw"||t.part==="leg"&&t.seg>=2?e.copy(r.light):t.part==="tail"?e.copy(r.base).lerp(r.light,t.seg===3?.8:0):e.copy(r.base)}case"grey":{let r=Dn.grey;return t.part==="body"?e.copy(r.base).lerp(r.light,Lt(n.len/2-.22,n.len/2-.08,t.z)*Lt(i+n.chH*.1,i-n.chH*.3,t.y)*.9):t.part==="neck"?e.copy(r.base).lerp(r.light,Lt(0,-.03,t.ly)*.85):t.part==="paw"?e.copy(r.light):t.part==="head"?e.copy(r.base).lerp(r.light,Lt(.012,0,Math.abs(t.lx))*Lt(t.zStop-.05,t.zStop,t.lz)*.7):e.copy(r.base)}case"husky":{let r=Dn.husky;if(t.part==="ear")return e.copy(r.dark);if(t.part==="head"){let a=Lt(-.005,.045,t.ly)*Lt(t.zStop+.01,t.zStop-.03,t.lz),o=Lt(.022,.006,Math.abs(t.lx));return e.copy(r.light).lerp(r.base,a*(1-o*.9))}return t.part==="body"?e.copy(r.light).lerp(r.base,Lt(i-n.chH*.25,i+n.chH*.25,t.y)):t.part==="neck"?e.copy(r.light).lerp(r.base,Lt(-.01,.04,t.ly)):t.part==="tail"?e.copy(r.light).lerp(r.base,Lt(-.015,.02,t.ly)):t.part==="leg"&&t.seg===0&&!t.front?e.copy(r.base).lerp(r.light,.35):e.copy(r.light)}case"pug":{let r=Dn.pug;return t.part==="ear"?e.copy(r.dark):t.part==="head"?e.copy(r.base).lerp(r.dark,Lt(t.zStop-.05,t.zStop+.005,t.lz)*.95):t.part==="body"?e.copy(r.base).lerp(r.light,Lt(i,i-n.chH*.7,t.y)*.4):e.copy(r.base)}case"pinscher":{let r=Dn.pinscher;if(t.part==="ear")return e.copy(r.base);if(t.part==="head"){let a=Math.max(0,1-Math.hypot(Math.abs(t.lx)-.02,t.ly-.028,t.lz-(t.zStop-.01))/.012);return e.copy(r.base).lerp(r.light,Math.max(s*.95,Lt(-.005,-.03,t.ly)*.9,a))}return t.part==="body"?e.copy(r.base).lerp(r.light,Lt(n.len/2-.12,n.len/2-.03,t.z)*Lt(i,i-n.chH*.5,t.y)):t.part==="neck"?e.copy(r.base).lerp(r.light,Lt(0,-.02,t.ly)*.9):t.part==="paw"||t.part==="leg"&&t.seg>=1?e.copy(r.light):e.copy(r.base)}case"boar":{let r=Dn.boar;return t.part==="ear"||t.part==="tail"?e.copy(r.dark):t.part==="paw"?e.copy(r.hoof):t.part==="head"?e.copy(r.base).lerp(r.light,Lt(0,-.04,t.ly)*.5).lerp(r.dark,s*.45):t.part==="body"?e.copy(r.base).lerp(r.dark,Lt(i+n.chH*.2,i+n.chH*.9,t.y)*.8).lerp(r.light,Lt(i-n.chH*.4,i-n.chH,t.y)*.35):t.part==="neck"?e.copy(r.base).lerp(r.dark,Lt(0,.05,t.ly)*.7):t.part==="leg"?e.copy(r.base).lerp(r.dark,t.seg>=1?.7:.2):e.copy(r.base)}case"opossum":{let r=Dn.opossum,a=yi(t.x*220+t.z*130,t.y*220,0,13);if(t.part==="ear")return e.copy(t.ly>n.earL*.55?r.light:r.dark);if(t.part==="head"){let[o,c,l]=n.skull,h=Lt(.016,.006,Math.abs(t.ly-l*.3))*Lt(c*.25,c*.45,Math.abs(t.lx))*Lt(t.zStop+.03,t.zStop-.01,t.lz),u=Lt(.012,.004,Math.abs(t.lx))*Lt(l*.3,l*.7,t.ly)*Lt(t.zStop,t.zStop-.04,t.lz);return e.copy(r.light).lerp(r.pink,s*Lt(t.zStop+n.muzzle[0]*.6,t.zStop+n.muzzle[0],t.lz)).lerp(r.dark,Math.max(h,u))}return t.part==="body"?e.copy(r.base).lerp(r.light,a>.62?.55:0).lerp(r.light,Lt(i-n.chH*.3,i-n.chH*.8,t.y)*.6):t.part==="neck"?e.copy(r.light).lerp(r.base,Lt(0,.05,t.ly)*.6):t.part==="leg"?e.copy(t.seg>=1?r.dark:r.base):t.part==="paw"?e.copy(r.pink):t.part==="tail"?e.copy(t.seg===0?r.dark:r.pink):e.copy(r.base)}case"gecko":{let r=Dn.gecko;if(t.part==="paw")return e.copy(r.light);for(let a of t.spots){let o=t.x-a[0],c=t.y-a[1],l=t.z-a[2];if(o*o+c*c+l*l<a[3]*a[3])return e.copy(r.dark)}return t.part==="body"&&t.ly<-n.chH*.35?e.copy(r.light):t.part==="tail"?e.copy(r.base).lerp(r.band,Math.sin(t.z*60)>.2?.7:.15).lerp(r.light,Lt(0,-.03,t.ly)*.6):t.part==="head"&&t.ly<-.012?e.copy(r.light):e.copy(r.base)}case"tegu":{let r=Dn.tegu,a=yi(t.x*260+t.z*150,t.y*260+t.z*90,0,11);if(t.part==="body"||t.part==="tail"){if(t.ly<-n.chH*.45)return e.copy(r.belly).lerp(r.base,Math.sin(t.z*70)>.6?.8:0);let o=Math.sin(t.z*(t.part==="tail"?32:42)+yi(t.x*30,t.z*30,0,5)*2.5)>.35;return e.copy(o&&a>.35?r.light:r.base)}return t.part==="head"?e.copy(t.ly<-.018?r.belly:a>.72?r.light:r.base):t.part==="leg"||t.part==="paw"?e.copy(a>.6?r.light:r.base):e.copy(r.base)}case"pitbull":{let r=Dn.pitbull;return t.part==="ear"?e.copy(r.dark):t.part==="head"?e.copy(r.base).lerp(r.light,Lt(.012,.004,Math.abs(t.lx))*Lt(t.zStop-.06,t.zStop,t.lz)*.9):t.part==="body"?e.copy(r.base).lerp(r.light,Lt(n.len/2-.2,n.len/2-.06,t.z)*Lt(i+n.chH*.2,i-n.chH*.3,t.y)):t.part==="neck"?e.copy(r.base).lerp(r.light,Lt(0,-.03,t.ly)):t.part==="paw"||t.part==="leg"&&t.seg===2?e.copy(r.light):e.copy(r.base)}}return e.set(16777215)}var jn=[{id:"rex",name:"REX",raca:"PASTOR ALEM\xC3O",coat:"shepherd",color:"#e53935",pitch:.85,eye:3875856,len:.8,chH:.16,chW:.12,rumpH:.13,rumpW:.11,rumpY:0,waist:.3,arch:.01,backY:.6,bone:.028,neck:.2,neckA:.85,skull:[.1,.075,.07],muzzle:[.12,.04,.038,.025],ear:"erect",earW:.05,earL:.12,tail:[.52,.035,-1,.22],spd:4,acc:3,han:3,jmp:3},{id:"pingo",name:"PINGO",raca:"D\xC1LMATA",coat:"dalmatian",color:"#1e63ff",pitch:1,eye:2758411,len:.78,chH:.15,chW:.11,rumpH:.12,rumpW:.1,rumpY:0,waist:.35,arch:0,backY:.62,bone:.026,neck:.2,neckA:.8,skull:[.095,.072,.07],muzzle:[.115,.042,.04,.022],ear:"floppy",earW:.045,earL:.11,tail:[.45,.028,-.35,.06],spd:3,acc:4,han:3,jmp:3},{id:"caramelo",name:"CARAMELO",raca:"VIRA-LATA",coat:"caramel",color:"#16a34a",pitch:1.05,eye:3021324,len:.7,chH:.14,chW:.11,rumpH:.12,rumpW:.1,rumpY:0,waist:.28,arch:0,backY:.52,bone:.026,neck:.18,neckA:.8,skull:[.09,.075,.072],muzzle:[.1,.043,.04,.022],ear:"fold",earW:.045,earL:.09,tail:[.42,.03,.9,.55],spd:3,acc:3,han:4,jmp:3},{id:"flecha",name:"FLECHA",raca:"GALGO",coat:"grey",color:"#f59e0b",pitch:.95,eye:2364682,len:.82,chH:.17,chW:.085,rumpH:.1,rumpW:.08,rumpY:.02,waist:.62,arch:.035,backY:.68,bone:.022,neck:.24,neckA:.75,skull:[.1,.058,.058],muzzle:[.16,.032,.032,.018],ear:"rose",earW:.035,earL:.08,tail:[.62,.022,-1.2,.2],spd:5,acc:2,han:2,jmp:4},{id:"nevasca",name:"NEVASCA",raca:"HUSKY SIBERIANO",coat:"husky",color:"#8b5cf6",pitch:.8,eye:4891647,len:.75,chH:.15,chW:.12,rumpH:.13,rumpW:.11,rumpY:0,waist:.2,arch:0,backY:.58,bone:.028,neck:.18,neckA:.85,skull:[.095,.08,.075],muzzle:[.1,.044,.042,.022],ear:"erect",earW:.045,earL:.09,tail:[.45,.05,.8,.5],spd:4,acc:4,han:3,jmp:2},{id:"bolinha",name:"BOLINHA",raca:"PUG",coat:"pug",color:"#84cc16",pitch:1.35,eye:1707526,eyeR:.028,len:.5,chH:.15,chW:.14,rumpH:.13,rumpW:.12,rumpY:.01,waist:.05,arch:0,backY:.38,bone:.03,neck:.08,neckA:.7,skull:[.1,.105,.095],muzzle:[.03,.06,.045,.03],ear:"floppy",earW:.04,earL:.07,tail:[.2,.035,1.5,1.3],spd:2,acc:5,han:4,jmp:2},{id:"pitiquin",name:"PITIQUIN",raca:"PINSCHER",coat:"pinscher",color:"#06b6d4",pitch:1.7,eye:1182213,eyeR:.017,len:.42,chH:.095,chW:.068,rumpH:.08,rumpW:.062,rumpY:.005,waist:.35,arch:0,backY:.37,bone:.016,neck:.12,neckA:.95,skull:[.058,.045,.044],muzzle:[.06,.021,.021,.012],ear:"erect",earW:.034,earL:.08,tail:[.1,.018,1.2,.1],spd:3,acc:5,han:3,jmp:2},{id:"princesa",name:"PRINCESA",raca:"PITBULL",coat:"pitbull",color:"#ff4fa3",pitch:.9,eye:5911828,nose:7027246,crown:!0,len:.72,chH:.17,chW:.14,rumpH:.13,rumpW:.115,rumpY:0,waist:.25,arch:0,backY:.52,bone:.034,neck:.14,neckA:.75,skull:[.1,.1,.085],muzzle:[.08,.058,.05,.03],ear:"rose",earW:.04,earL:.06,tail:[.4,.035,-.6,.1],spd:4,acc:4,han:2,jmp:3},{id:"linda",name:"LINDA",raca:"JAVALI",coat:"boar",color:"#0f766e",pitch:.8,voice:"grunt",mass:1.8,eye:1707526,eyeR:.014,snoutDisc:!0,tusks:!0,mane:!0,headDown:.3,len:.82,chH:.21,chW:.15,rumpH:.17,rumpW:.135,rumpY:.01,waist:.05,arch:.03,backY:.5,bone:.032,neck:.1,neckA:.3,skull:[.11,.085,.09],muzzle:[.2,.045,.045,.03],ear:"erect",earW:.042,earL:.07,tail:[.2,.012,-1.2,.1],spd:4,acc:4,han:2,jmp:3},{id:"emilly",name:"EMILLY",raca:"SARU\xCA",coat:"opossum",noTongue:!0,color:"#be123c",pitch:2.2,voice:"hiss",mass:.8,eye:525830,eyeR:.016,nose:15179946,len:.6,chH:.13,chW:.11,rumpH:.145,rumpW:.125,rumpY:.025,waist:.05,arch:.035,backY:.35,bone:.02,neck:.08,neckA:.35,headDown:.15,skull:[.08,.06,.055],muzzle:[.13,.026,.024,.018],ear:"round",earW:.035,earL:.055,tail:[.6,.026,-.45,.2],spd:3,acc:4,han:4,jmp:2},{id:"taissa",name:"TAISSA",raca:"LAGARTIXA",kind:"lizard",coat:"gecko",color:"#facc15",pitch:1.8,voice:"hiss",mass:.6,scale:1.3,eye:1840914,eyeR:.024,len:.42,chW:.085,chH:.05,backY:.09,headL:[.15,.058,.036],bone:.013,legU:.1,gearS:.55,tailL:.42,tailR:.042,spd:2,acc:5,han:5,jmp:1},{id:"tiffany",name:"TIFFANY",raca:"TEI\xDA",kind:"lizard",coat:"tegu",color:"#f97316",pitch:1,voice:"hiss",mass:1.2,forked:!0,eye:657930,eyeR:.011,len:.68,chW:.13,chH:.075,backY:.13,headL:[.2,.068,.048],bone:.02,legU:.13,gearS:.8,tailL:.9,tailR:.068,spd:4,acc:3,han:4,jmp:2}];function jf(n,t){let e=new ui(ze(64,64,i=>{i.fillStyle="#fff",i.beginPath(),i.arc(32,32,29,0,7),i.fill(),i.lineWidth=6,i.strokeStyle=t,i.stroke(),i.fillStyle="#111",i.font="bold 34px Arial",i.textAlign="center",i.textBaseline="middle",i.fillText(String(n),32,34)}));return e.colorSpace=Ce,e}var Qf=new oe({color:1708560,roughness:.5}),kl=new oe({color:1315346,roughness:.35}),td=new oe({color:14704762,roughness:.4}),za=new oe({color:12897496,roughness:.25,metalness:.6}),ed=new oe({color:13703722,roughness:.3,metalness:.6}),nd=new Pn({color:6737151,transparent:!0,opacity:.85,blending:Ui,depthWrite:!1}),sh=new Pn({color:16769357}),Ya=new ui(ze(64,64,n=>{n.fillStyle="#ffcc00",n.beginPath(),n.arc(32,32,28,0,7),n.fill(),n.fillStyle="#111",n.font="bold 44px Arial",n.textAlign="center",n.textBaseline="middle",n.fillText("!",32,35)}));Ya.colorSpace=Ce;var Gl=new oe({color:3818063,roughness:.4,metalness:.5}),rh=new oe({color:16742938,roughness:.4,metalness:.3,emissive:4200448}),Ba=new oe({color:14753066,roughness:.3,metalness:.4}),id=(()=>{let n=ze(128,128,(t,e,i)=>{t.fillStyle="#e8e8e8",t.fillRect(0,0,e,i);for(let s=0;s<16;s++)for(let r=0;r<16;r++){let a=r*8+s%2*4,o=s*8,c=175+Math.random()*60|0;t.fillStyle=`rgb(${c},${c},${c})`,t.beginPath(),t.ellipse(a,o,3.6,3.1,0,0,7),t.fill()}});return je(n,3,3)})(),Uf=new Set([Jf,id,Qf,kl,td,za,ed,nd,sh,Ya,nh,ih,Gl,rh,Ba]);function sd(n,t,e,i=1){let s=new wt;s.position.set(0,t,e),s.scale.setScalar(i),n.add(s),t=0,e=0;let r=[];for(let h of[-1,1]){let u=new It(new Jt(.026,.026,.16,12),za);u.rotation.x=Math.PI/2,u.position.set(h*.034,t+.02,e),u.castShadow=!0,s.add(u);let f=new It(new xe(.026,10,6,0,Math.PI*2,0,Math.PI/2),ed);f.rotation.x=Math.PI/2,f.position.set(h*.034,t+.02,e+.08),s.add(f);let d=new It(new Jt(.012,.018,.03,8),za);d.rotation.x=Math.PI/2,d.position.set(h*.034,t+.02,e-.095),s.add(d);let p=new It(new tn(.02,.2,8),nd);p.rotation.x=-Math.PI/2,p.position.set(h*.034,t+.02,e-.21),p.visible=!1,s.add(p),r.push(p)}let a=new wt;a.position.set(0,t+.058,e+.015),s.add(a);let o=new It(new ge(.075,.012,.09),Gl);o.position.y=-.012,a.add(o);let c=[];[[-.02,.012],[.02,.012],[0,.044]].forEach(([h,u])=>{let f=new It(new Jt(.018,.018,.15,12,1,!0),Gl);f.material.side=ke,f.rotation.x=Math.PI/2,f.position.set(h,u,0),f.castShadow=!0,a.add(f);let d=new It(new Jt(.0195,.0195,.014,12),rh);d.rotation.x=Math.PI/2,d.position.set(h,u,.06),a.add(d);let p=new It(new tn(.014,.034,10),Ba);p.rotation.x=Math.PI/2,p.position.set(h,u,.082),a.add(p),c.push(p)});let l=new Ge;return l.position.set(0,.03,.12),a.add(l),{flames:r,launcher:{g:a,noses:c,muzzle:l}}}var Da=2.3;function My(n,t,e){let i=new wt,s=new wt,r=new wt;i.add(s),s.add(r);let a=new oe({vertexColors:!0,map:Jf,roughness:.88}),o=[],c=(I,Y,q,M={},y=a)=>{let U=new It(I,y);return U.userData={part:q,...M},U.castShadow=!0,Y.add(U),y===a&&o.push(U),U},l=n.backY-n.chH*.9,h=c(En(28,22,(I,Y)=>er(n,I,Y)),r,"body");h.position.y=l;let[u,f,d]=n.skull,[p,x,g,m]=n.muzzle,S=new wt;S.position.set(0,l+n.chH*.3,n.len/2-.07),S.rotation.x=-n.neckA,r.add(S),c(En(10,16,(I,Y)=>{let q=us(.5+I*.5,3)*.3+.7*(I<.9?1:us(.5+(I-.9)*5,2)),M=Ne(n.chW*.72,f*.8,I)*q,y=Ne(n.chH*.62,d*.85,I)*q;return[Math.cos(Y)*M,Math.sin(Y)*y,-.04+I*(n.neck+.06)]}),S,"neck");let _=new wt;_.position.set(0,0,n.neck),_.rotation.x=n.neckA-.12+(n.headDown||0),S.add(_);let b=new wt;b.position.set(0,d*.2,u*.55),_.add(b);let C=Ol(n,0);c(En(34,22,(I,Y)=>{let q=-u+I*(C.zEnd+u),M=Ol(n,q),y=Math.sin(Y);return[Math.cos(Y)*M.w,M.yc+y*M.h*(y<0?.88:1),q]}),b,"head");let A=n.eye===4891647?new oe({color:4891647,roughness:.05,emissive:664640}):new oe({color:n.eye,roughness:.06}),R=n.eyeR||f*.24;{let I=C.zStop-u*.08,Y=Ol(n,I),q=.42;for(let M of[-1,1]){let y=new It(new xe(R,12,9),A);y.position.set(M*Math.cos(q)*Y.w*.9,Y.yc+Math.sin(q)*Y.h*.9,I+R*.3),b.add(y);let U=new It(new xe(R*1.12,12,6,0,Math.PI*2,0,Math.PI*.42),Qf);U.position.copy(y.position),U.rotation.x=-.2,b.add(U)}}let F=Math.max(C.zStop+p-x*.25,u*.97),E=new It(gi(x*.62,x*.42,x*.4),n.nose?new oe({color:n.nose,roughness:.35}):kl);if(E.position.set(0,-m+g*.52,F),b.add(E),n.snoutDisc){E.visible=!1;let I=new oe({color:12157816,roughness:.55}),Y=new It(new Jt(x*.95,x*1,.02,22),I);Y.rotation.x=Math.PI/2,Y.position.set(0,-m*.9,C.zStop+p-.004),b.add(Y);for(let q of[-1,1]){let M=new It(new xe(x*.2,8,6),kl);M.scale.z=.4,M.position.set(q*x*.35,-m*.9,C.zStop+p+.007),b.add(M)}}if(n.tusks){let I=new oe({color:15985366,roughness:.35});for(let Y of[-1,1]){let q=new It(new tn(.009,.06,8),I);q.position.set(Y*x*.95,-m-g*.35,C.zStop+p*.62),q.rotation.set(-.5,0,-Y*.55),q.castShadow=!0,b.add(q)}}if(n.crown){let I=new oe({color:16762173,roughness:.3,metalness:.6,emissive:3810304}),Y=new wt;Y.position.set(0,d*.95,-u*.1),Y.rotation.x=-.15,b.add(Y),Y.add(new It(new Jt(.032,.036,.018,16,1,!0),I));for(let q=0;q<5;q++){let M=q/5*Math.PI*2,y=new It(new tn(.009,.026,6),I);y.position.set(Math.cos(M)*.032,.02,Math.sin(M)*.032),Y.add(y);let U=new It(new xe(.005,8,6),new oe({color:16723338,roughness:.1,emissive:5570594}));U.position.set(Math.cos(M)*.035,.002,Math.sin(M)*.035),Y.add(U)}Y.traverse(q=>{q.isMesh&&(q.castShadow=!0)})}let v=new wt;v.position.set(0,-m-g*.75,C.zStop+p*.35),b.add(v);let N=new It(gi(x*.55,.008,.06),td);N.position.set(0,-.02,.02),N.rotation.x=.9,v.add(N);let B=[];for(let I of[-1,1]){let Y=new wt;if(Y.position.set(I*f*.55,d*.7,-u*.28),b.add(Y),n.ear==="round"){let q=En(8,12,(M,y)=>{let U=n.earW*Math.pow(Math.sin(Math.PI*(.06+.94*M)),.55);return[Math.cos(y)*U,Math.sin(y)*.01,M*n.earL]});q.rotateX(-Math.PI/2),c(q,Y,"ear"),Y.rotation.set(-.15,0,-I*.45)}else if(n.ear==="erect"||n.ear==="fold"){let q=En(8,12,(M,y)=>{let U=n.earW*Math.pow(1-M,.85)*(M<.12?.75+2*M:1);return[Math.cos(y)*U,Math.sin(y)*(.018*(1-M*.6)),M*n.earL]});q.rotateX(-Math.PI/2),c(q,Y,"ear"),Y.rotation.set(n.ear==="fold"?.55:-.12,0,-I*.28)}else{let q=En(8,12,(M,y)=>{let U=n.earW*Math.pow(Math.sin(Math.PI*(.12+.88*M)),.7);return[Math.cos(y)*U,Math.sin(y)*.013,M*n.earL]});q.rotateX(Math.PI/2),c(q,Y,"ear"),Y.rotation.set(n.ear==="rose"?1.3:.05,0,I*.35)}B.push({piv:Y,type:n.ear,rx:Y.rotation.x,rz:Y.rotation.z,sx:I})}let rt=[],P=n.bone;for(let I of[{f:1,sx:-1,off:0},{f:1,sx:1,off:.55},{f:0,sx:-1,off:Math.PI+.2},{f:0,sx:1,off:Math.PI+.75}]){let Y=new wt;I.f?Y.position.set(I.sx*n.chW*.6,l-n.chH*.2,n.len/2-.11):Y.position.set(I.sx*n.rumpW*.62,l+n.rumpY,-n.len/2+.13),r.add(Y);let q=Y.position.y,M=q*(I.f?.44:.42),y=q*.44,U=q*(I.f?.15:.28);c(Kr(M,I.f?P*2:P*2.6,I.f?P*1.25:P*1.35,I.f?1.15:1.35),Y,"leg",{front:I.f,seg:0});let tt=new wt;tt.position.y=-M,Y.add(tt),c(Kr(y,P*1.1,P*.78,1.1),tt,"leg",{front:I.f,seg:1});let j=new wt;j.position.y=-y,tt.add(j),c(Kr(U,P*.82,P*.72,1.1),j,"leg",{front:I.f,seg:2});let st=c(gi(P*1.15,P*.72,P*1.55),j,"paw",{front:I.f});st.position.set(0,-U-P*.35,P*.7);let Ct=I.f?.45:-.55,xt=I.f?-.45:1.15,bt=I.f?-.22:-.6;Y.rotation.x=Ct,tt.rotation.x=xt,j.rotation.x=bt,rt.push({hip:Y,knee:tt,ank:j,paw:st,front:I.f,off:I.off,rh:Ct,rk:xt,ra:bt})}let[z,G,et,J]=n.tail,$=new wt;$.position.set(0,l+n.rumpY+n.rumpH*.55,-n.len/2+.04),r.add($);let nt=[],it=$;for(let I=0;I<4;I++){let Y=G*(1-I/4*.55),q=G*(1-(I+1)/4*.55),M=z/4,y=En(6,10,(tt,j)=>{let st=Ne(Y,q,tt)*us(tt,3);return[Math.cos(j)*st,Math.sin(j)*st,-Y*.6+tt*(M+Y*1.2)]});y.rotateY(Math.PI);let U=new wt;U.position.z=I?-M:0,it.add(U),c(y,U,"tail",{seg:I}),U.rotation.x=I?J:et,nt.push(U),it=U}let _t=new oe({color:e,roughness:.45,metalness:.15,side:ke}),W=new It(En(8,22,(I,Y)=>er(n,Ne(.47,.72,I),Y,1.07)),_t);W.position.y=l,W.castShadow=!0,r.add(W);let K=new oe({map:jf(t,e),transparent:!0,roughness:.5});for(let I of[-1,1]){let Y=er(n,.6,I>0?0:Math.PI,1.08),q=new It(new mn(.12,.12),K);q.position.set(Y[0]+I*.004,l+Y[1],Y[2]),q.rotation.y=I*Math.PI/2,r.add(q)}let gt=l+er(n,.52,Math.PI/2,1.07)[1],Rt=er(n,.5,0)[2],{flames:Mt,launcher:Z}=sd(r,gt,Rt);if(n.mane){let I=new oe({color:1971986,roughness:.95});for(let Y=0;Y<16;Y++){let q=Ne(.28,.98,Y/15),M=er(n,q,Math.PI/2);if(Math.abs(M[2]-Rt)<.1)continue;let y=new It(new tn(.014,.06+.02*Math.sin(Y),5),I);y.position.set(0,l+M[1]+.012,M[2]),y.rotation.x=-.5,y.castShadow=!0,r.add(y)}}let ht=new wt;ht.position.set(0,d*2.2,0),b.add(ht);for(let I=0;I<4;I++){let Y=new It(new Yr(.025),sh);Y.position.set(Math.cos(I*1.57)*.09,0,Math.sin(I*1.57)*.09),ht.add(Y)}ht.visible=!1;let lt=new Js(new Qi({map:Ya,depthTest:!1}));lt.scale.set(.13,.13,1),lt.position.set(0,d*2.8,0),lt.visible=!1,b.add(lt),s.updateMatrixWorld(!0);let Et=new Cn;for(let I of rt)Et.setFromObject(I.paw),I.hip.position.y-=Et.min.y;s.updateMatrixWorld(!0);let w=[];if(n.coat==="dalmatian")for(let I=0;I<300;I++)w.push([Wt(-.2,.2),Wt(.02,.8),Wt(-.6,.75),Wt(.012,.03)]);let Q=new L,X=new Ft;for(let I of o){let Y=I.geometry.attributes.position,q=new Float32Array(Y.count*3);for(let M=0;M<Y.count;M++){Q.fromBufferAttribute(Y,M);let y=Q.x,U=Q.y,tt=Q.z;Q.applyMatrix4(I.matrixWorld),Kf(n,{part:I.userData.part,front:I.userData.front,seg:I.userData.seg,zStop:C.zStop,lx:y,ly:U,lz:tt,x:Q.x,y:Q.y,z:Q.z,cy:l,spots:w},X);let j=(.9+.2*yi(Q.x*45+Q.z*17,Q.y*45,0,3))*(I.userData.part==="body"?1-.1*Lt(l,l+n.chH,Q.y):1);q[M*3]=X.r*j,q[M*3+1]=X.g*j,q[M*3+2]=X.b*j}I.geometry.setAttribute("color",new we(q,3))}s.scale.setScalar(Da);let ot=new It(new mn(1,1),new Pn({map:nh,transparent:!0,depthWrite:!1}));return ot.rotation.x=-Math.PI/2,ot.position.y=.04,ot.scale.set(n.chW*5*Da,n.len*1.5*Da,1),i.add(ot),{root:i,model:s,body:r,torso:h,neckPiv:S,headPiv:_,head:b,legs:rt,tails:nt,ears:B,tongue:v,flames:Mt,stars:ht,excl:lt,blob:ot,b:n,launcher:Z,anim:Ty}}function rd(n,t,e){return n.kind==="lizard"?Ey(n,t,e):My(n,t,e)}function Ey(n,t,e){let i=new wt,s=new wt,r=new wt;i.add(s),s.add(r);let a=new oe({vertexColors:!0,map:id,roughness:n.coat==="tegu"?.42:.6}),o=[],c=(Z,ht,lt,Et={},w=a)=>{let Q=new It(Z,w);return Q.userData={part:lt,...Et},Q.castShadow=!0,ht.add(Q),w===a&&o.push(Q),Q},l=n.len,h=n.chW,u=n.chH,f=n.backY,d=c(En(26,20,(Z,ht)=>{let lt=us(Z,2.2),Et=Math.sin(ht);return[Math.cos(ht)*h*lt*(1-.15*ls(Z,.1,.15)),Et*u*lt*(Et<0?.8:1),(Z-.5)*l]}),r,"body");d.position.y=f;let[p,x,g]=n.headL,m=new wt;m.position.set(0,f+u*.15,l/2-.03),r.add(m);let S=m;c(En(8,16,(Z,ht)=>{let lt=Ne(h*.8,x*.95,Z),Et=Ne(u*.8,g*.95,Z);return[Math.cos(ht)*lt,Math.sin(ht)*Et,-.05+Z*.09]}),m,"neck");let _=new wt;_.position.set(0,0,.04+p*.3),m.add(_),c(En(24,18,(Z,ht)=>{let lt=-p*.3+Z*p*1.3,Et=Math.pow(Math.max(0,1-Math.pow(Math.abs(2*Z-1),3)),1/3),w=x*(1-.45*Z*Z)*Et,Q=g*(1-.3*Z)*Et,X=Math.sin(ht);return[Math.cos(ht)*w,-g*.15*Z+X*Q*(X<0?.75:1),lt]}),_,"head");let b=new oe({color:n.eye,roughness:.05});for(let Z of[-1,1]){let ht=new It(new xe(n.eyeR,14,10),b);ht.position.set(Z*x*.8,g*.42,p*.12),_.add(ht);let lt=new It(new xe(n.eyeR*1.15,12,6,0,Math.PI*2,0,Math.PI*.35),a);lt.position.copy(ht.position),lt.rotation.z=-Z*.5,lt.userData={part:"head"},_.add(lt),o.push(lt)}let C=new wt;C.position.set(0,-g*.35,p*.95),_.add(C);let A=new oe({color:n.forked?7172019:14711434,roughness:.4}),R=new It(new Jt(.004,.005,.07,6),A);if(R.rotation.x=Math.PI/2,R.position.z=.035,C.add(R),n.forked)for(let Z of[-1,1]){let ht=new It(new Jt(.0025,.0035,.03,5),A);ht.rotation.set(Math.PI/2,0,Z*.4),ht.position.set(Z*.006,0,.08),C.add(ht)}C.visible=!1;let F=[],E=n.bone,v=Math.PI/2-.18;for(let Z of[{f:1,sx:-1,off:0},{f:1,sx:1,off:Math.PI},{f:0,sx:-1,off:Math.PI},{f:0,sx:1,off:0}]){let ht=new wt;ht.position.set(Z.sx*h*.78,f-u*.2,(Z.f?1:-1)*l*.3),r.add(ht);let lt=new wt;lt.rotation.z=Z.sx*v,ht.add(lt);let Et=n.legU;c(Kr(Et,E*1.7,E*1.15,1.1),lt,"leg",{front:Z.f,seg:0});let w=new wt;w.position.y=-Et,w.rotation.z=Z.sx*(.12-v),lt.add(w);let Q=Math.max(.025,f-u*.2-Et*Math.sin(Math.PI/2-v)-E*.5);c(Kr(Q,E*1.15,E*.85),w,"leg",{front:Z.f,seg:1});let X=new wt;X.position.y=-Q,X.rotation.z=-Z.sx*.12,w.add(X);let ot=c(gi(E*1.3,E*.5,E*1.2),X,"paw",{front:Z.f});for(let I=0;I<5;I++){let Y=(I-2)*.42+(Z.f?.15:-.1)*-Z.sx,q=c(gi(E*.32,E*.28,E*1.15),X,"paw",{front:Z.f});q.position.set(Math.sin(Y)*E*1.5,0,Math.cos(Y)*E*1.5),q.rotation.y=Y,n.coat==="gecko"&&c(new xe(E*.42,8,6),X,"paw",{front:Z.f}).position.set(Math.sin(Y)*E*2.5,0,Math.cos(Y)*E*2.5)}F.push({yaw:ht,out:lt,knee:w,paw:ot,front:Z.f,sx:Z.sx,off:Z.off,rest:lt.rotation.z})}let N=[],B=7,rt=n.tailL/B,P=new wt;P.position.set(0,f,-l/2+.03),r.add(P);for(let Z=0;Z<B;Z++){let ht=n.tailR*(1-Z/B*.88),lt=n.tailR*(1-(Z+1)/B*.88),Et=En(6,12,(Q,X)=>{let ot=Ne(ht,lt,Q)*us(Q,3);return[Math.cos(X)*ot*1.1,Math.sin(X)*ot*.85,-ht*.6+Q*(rt+ht*1.2)]});Et.rotateY(Math.PI);let w=new wt;w.position.z=Z?-rt:0,P.add(w),c(Et,w,"tail",{seg:Z}),w.rotation.x=Z?.05:-.28,N.push(w),P=w}let z=new oe({color:e,roughness:.45,metalness:.15}),G=new It(new xe(1,22,10,0,Math.PI*2,0,Math.PI/2),z);G.scale.set(h*1.05,u*.45,l*.26),G.position.set(0,f+u*.7,0),G.castShadow=!0,r.add(G);let et=new oe({map:jf(t,e),transparent:!0,roughness:.5,side:ke});for(let Z of[-1,1]){let ht=new It(new mn(.075,.075),et);ht.position.set(Z*(h*.98+.004),f+u*.2,0),ht.rotation.y=Z*Math.PI/2,r.add(ht)}let{flames:J,launcher:$}=sd(r,f+u+.005,-.01,n.gearS||1),nt=new wt;nt.position.set(0,g*3,0),_.add(nt);for(let Z=0;Z<4;Z++){let ht=new It(new Yr(.02),sh);ht.position.set(Math.cos(Z*1.57)*.07,0,Math.sin(Z*1.57)*.07),nt.add(ht)}nt.visible=!1;let it=new Js(new Qi({map:Ya,depthTest:!1}));it.scale.set(.11,.11,1),it.position.set(0,g*4.2,0),it.visible=!1,_.add(it),s.updateMatrixWorld(!0);let _t=new Cn;for(let Z of F)_t.setFromObject(Z.paw),Z.yaw.position.y-=_t.min.y;s.updateMatrixWorld(!0);let W=[];if(n.coat==="gecko")for(let Z=0;Z<420;Z++)W.push([Wt(-.12,.12),Wt(.02,.2),Wt(-.7,.45),Wt(.006,.013)]);let K=new L,gt=new Ft;for(let Z of o){let ht=Z.geometry.attributes.position,lt=new Float32Array(ht.count*3);for(let Et=0;Et<ht.count;Et++){K.fromBufferAttribute(ht,Et);let w=K.x,Q=K.y,X=K.z;K.applyMatrix4(Z.matrixWorld),Kf(n,{part:Z.userData.part,front:Z.userData.front,seg:Z.userData.seg,zStop:0,lx:w,ly:Q,lz:X,x:K.x,y:K.y,z:K.z,cy:f,spots:W},gt);let ot=.92+.16*yi(K.x*60+K.z*23,K.y*60,0,3);lt[Et*3]=gt.r*ot,lt[Et*3+1]=gt.g*ot,lt[Et*3+2]=gt.b*ot}Z.geometry.setAttribute("color",new we(lt,3))}let Rt=Da*(n.scale||1);s.scale.setScalar(Rt);let Mt=new It(new mn(1,1),new Pn({map:nh,transparent:!0,depthWrite:!1}));return Mt.rotation.x=-Math.PI/2,Mt.position.y=.04,Mt.scale.set(h*6*Rt,(l+n.tailL*.6)*1.3*Rt,1),i.add(Mt),{root:i,model:s,body:r,torso:d,neckPiv:m,headPiv:S,head:_,legs:F,tails:N,ears:[],tongue:C,flames:J,stars:nt,excl:it,blob:Mt,b:n,launcher:$,anim:by}}function Sy(n,t,e){for(let i of n.flames)i.visible=t.nitro,t.nitro&&i.scale.set(1,.7+Math.random()*.6,1);n.stars.visible=t.stun>0,t.stun>0&&(n.stars.rotation.y=e*7),n.excl.visible=t.spook>0,n.blob.material.opacity=1/(1+t.y*.6)}function by(n,t,e){let i=de(t.v/10,0,1),s=t.y>.05,r=t.phase*1.25;for(let c of n.legs){if(s){c.yaw.rotation.y=(c.front?.7:-.7)*-c.sx,c.out.rotation.z=c.rest+c.sx*.35;continue}let l=r+c.off;c.yaw.rotation.y=-c.sx*Math.sin(l)*.65*i,c.out.rotation.z=c.rest+c.sx*Math.max(0,Math.cos(l))*.35*i}let a=i>.05?i:.25;n.body.rotation.y=Math.sin(r)*.13*i,n.body.position.y=t.idle?Math.max(0,Math.sin(e*2.6))*.018:i*.015,n.neckPiv.rotation.y=-Math.sin(r)*.18*i+(t.idle?Math.sin(e*.8)*.35:de(-t.yawRate*.2,-.4,.4)),n.neckPiv.rotation.x=s?-.2:t.idle?-Math.max(0,Math.sin(e*2.6))*.12:0,n.tails.forEach((c,l)=>{c.rotation.y=Math.sin((i>.05?r:e*1.4)-l*.8)*(.2+.05*l)*a,l===0&&(c.rotation.x=s?.1:-.28)});let o=n.b.forked?Math.sin(e*2.3+n.b.len*10)>.9:Math.sin(e*1.3)>.97;n.tongue.visible=o,o&&(n.tongue.scale.z=.6+Math.abs(Math.sin(e*30))*.6),n.model.rotation.z=de(-t.yawRate*.1,-.2,.2)+(t.stun>0?Math.sin(e*18)*.15:0),Sy(n,t,e)}function Ty(n,t,e){let i=n.b,s=de(t.v/12,0,1),r=t.y>.05;for(let o of n.legs){let c=t.phase+o.off,l=Math.sin(c),h=Math.max(0,-Math.cos(c)),u=o.rh,f=o.rk,d=o.ra;r?o.front?(u=-.8,f=.1,d=-.1):(u=.9,f=.2,d=-.3):s>.01&&(o.front?(u+=l*.8*s,f+=(h*1.2-.1)*s,d+=h*.9*s):(u+=l*.75*s,f+=h*.7*s,d-=h*.8*s)),o.hip.rotation.x=u,o.knee.rotation.x=f,o.ank.rotation.x=d}n.body.position.y=s*.035*Math.cos(t.phase)*(r?0:1),n.body.rotation.x=s*.06*Math.sin(t.phase+.8)+(r?de(-t.vy*.03,-.35,.35):0),n.model.rotation.z=de(-t.yawRate*.16,-.32,.32)+(t.stun>0?Math.sin(e*18)*.15:0),n.neckPiv.rotation.x=-i.neckA+.28*s+Math.sin(t.phase)*.07*s,n.headPiv.rotation.x=i.neckA-.12+(i.headDown||0)-.22*s,n.head.rotation.y=de(-t.yawRate*.22,-.45,.45)+(t.idle?Math.sin(e*.7)*.35:0);for(let o of n.ears)o.type==="erect"||o.type==="fold"||o.type==="round"?o.piv.rotation.x=o.rx-.5*s+(t.idle?Math.max(0,Math.sin(e*3+o.sx))*.1:0):o.piv.rotation.x=o.rx+.9*s+Math.sin(t.phase*2)*.18*s;let a=1-s*.75;n.tails.forEach((o,c)=>{o.rotation.y=Math.sin(e*11-c*.6)*(c?.2:.45)*a,c===0&&(o.rotation.x=Ne(i.tail[2],-.2,s*.6)+Math.sin(t.phase)*.1*s)}),n.tongue.visible=!i.noTongue&&(t.v>6||t.idle),n.tongue.rotation.x=Math.sin(t.phase*2)*.25*s+(t.idle?Math.sin(e*9)*.1:0),n.torso.scale.y=1+Math.sin(e*(t.v>1?9:3.5))*.012;for(let o of n.flames)o.visible=t.nitro,t.nitro&&o.scale.set(1,.7+Math.random()*.6,1);n.stars.visible=t.stun>0,t.stun>0&&(n.stars.rotation.y=e*7),n.excl.visible=t.spook>0,n.blob.material.opacity=1/(1+t.y*.6)}var xs=[{id:"parque",name:"PARQUE CENTRAL",W:18,grip:1,hills:55,surface:"dirt",ground:[92,138,58],trees:"broad",puddle:"mud",ctrl:[[0,-130],[90,-140],[165,-105],[185,-30],[140,25],[150,100],[95,160],[0,150],[-55,105],[-120,140],[-180,85],[-170,0],[-115,-60],[-80,-120]],sky:{zen:2976720,hor:12376047,gnd:7043676,sun:16773336,dir:[.45,.62,.3],haze:.5},fog:[12376047,180,900],light:{sun:3.2,col:16773854,hemi:.35},rail:16053492,curb:["#d62828","#ffffff"],stand:[10133931,3039156],mtn:[5334079,7168597]},{id:"praia",name:"PRAIA DO LATIDO",W:18,grip:.9,hills:14,surface:"sand",ground:[226,204,158],trees:"palm",puddle:"water",sea:-128,ctrl:[[-200,-40],[-120,-90],[0,-100],[120,-95],[200,-60],[230,10],[190,70],[110,80],[60,40],[0,50],[-50,110],[-130,120],[-210,60]],sky:{zen:2964358,hor:16753768,gnd:9071192,sun:16756848,dir:[.2,.09,-.97],haze:1.3},fog:[15770748,160,850],light:{sun:2.8,col:16758405,hemi:.3},rail:9132587,curb:["#1e88e5","#ffffff"],stand:[12028762,1019816],mtn:[8022610,6253386]},{id:"neve",name:"PICO NEVADO",W:18,grip:.78,hills:80,surface:"snow",ground:[236,241,248],trees:"pine",puddle:"ice",snow:!0,ctrl:[[0,-150],[100,-160],[170,-110],[150,-40],[200,20],[180,110],[100,150],[40,100],[-20,140],[-110,150],[-170,90],[-130,30],[-190,-40],[-120,-120]],sky:{zen:6260408,hor:14542834,gnd:13621474,sun:16774890,dir:[-.4,.42,.5],haze:.8},fog:[14542834,110,620],light:{sun:2.4,col:15922943,hemi:.5},rail:13840175,curb:["#d32f2f","#ffffff"],stand:[9268835,12000284],mtn:[5923954,7173508]}],At=xs[0],Ut=18,Ae=1,Be=1400,He=[],Gn=[],ms=[],hs=[];function wy(n){let t=new Gr(n.ctrl.map(e=>new L(e[0],0,e[1])),!0,"centripetal");Ae=t.getLength(),He.length=Gn.length=ms.length=hs.length=0;for(let e=0;e<Be;e++){let i=e/Be,s=t.getPointAt(i),r=t.getTangentAt(i);r.y=0,r.normalize(),He.push(s),Gn.push(r),ms.push(new L(-r.z,0,r.x)),e%6===0&&hs.push(s)}}var qa=n=>(n%Ae+Ae)%Ae,gn=n=>(n=qa(n),n>Ae/2?n-Ae:n),Nf=new L,La=new L,Of=new L;function dr(n){let t=qa(n)/Ae*Be,e=Math.floor(t)%Be,i=(e+1)%Be,s=t-Math.floor(t);return Nf.copy(He[e]).lerp(He[i],s),La.copy(Gn[e]).lerp(Gn[i],s).normalize(),Of.set(-La.z,0,La.x),{p:Nf,t:La,r:Of}}function Fe(n,t,e=0){let i=dr(n);return new L(i.p.x+i.r.x*t,e,i.p.z+i.r.z*t)}function Jn(n){let t=dr(n);return Math.atan2(t.t.x,t.t.z)}function oh(n,t){let e=!1;for(let i=0,s=hs.length-1;i<hs.length;s=i++){let r=hs[i],a=hs[s];r.z>t!=a.z>t&&n<(a.x-r.x)*(t-r.z)/(a.z-r.z)+r.x&&(e=!e)}return e}function ah(n,t){let e=1/0;for(let i of hs){let s=i.x-n,r=i.z-t,a=s*s+r*r;a<e&&(e=a)}return Math.sqrt(e)}function cs(n,t){let e=ah(n,t);if(At.sea!==void 0&&t<At.sea)return Math.max(-7,-(At.sea-t)*.09)*Lt(Ut/2+6,Ut/2+22,e);let i=Lt(Ut/2+16,Ut/2+110,e)*Lt(70,150,Math.hypot(n-He[0].x,t-He[0].z));return i<=0||oh(n,t)?0:i*Math.max(0,mi(n*.004+31,t*.004+17,4)-.3)*At.hills}var be=null,ch=[],lh=[],jr=null,Ha=null,hh=[],xi=null,or=null,zi=[],Vl=[],ka=[],Ga=[],ar=[],io=[],so=[],Wl=null,Qr=null,mt=(n,t=.85,e=0,i={})=>new oe({color:n,roughness:t,metalness:e,...i});function St(n,t,e=!0,i=!0,s=be){let r=new It(n,t);return r.castShadow=e,r.receiveShadow=i,s.add(r),r}function vn(n,t,e,i=!0){let s=new ga(n,t,e);return s.castShadow=i,s.receiveShadow=!0,s.frustumCulled=!1,be.add(s),s}var Ff=new Me,zf=new Zn,Ay=new qs,te=new L,Ry=new L;function Mn(n,t,e,i,s,r,a,o,c,l,h){zf.setFromEuler(Ay.set(r,a,o)),Ff.compose(te.set(e,i,s),zf,Ry.set(c,l??c,h??c)),n.setMatrixAt(t,Ff)}function ro(n){n.traverse(t=>{t.geometry&&t.geometry.dispose(),t.material&&[].concat(t.material).forEach(e=>{if(!Uf.has(e)){for(let i of["map","bumpMap","normalMap","emissiveMap"])e[i]&&!Uf.has(e[i])&&e[i].dispose();e.dispose()}})})}function Jr(n,t,e,i,s,r=!0){let a=[],o=[],c=[];for(let h=0;h<=Be;h++){let u=h%Be,f=He[u],d=ms[u];a.push(f.x+d.x*n,e,f.z+d.z*n,f.x+d.x*t,e,f.z+d.z*t);let p=h/Be*Ae/i;if(o.push(0,p,1,p),h<Be){let x=h*2;c.push(x,x+1,x+2,x+1,x+3,x+2)}}let l=new Le;return l.setAttribute("position",new ae(a,3)),l.setAttribute("uv",new ae(o,2)),l.setIndex(c),l.computeVertexNormals(),St(l,s,!1,r)}function Bf(n,t,e,i){let s=[],r=[];for(let c=0;c<=Be;c+=2){let l=c%Be,h=He[l],u=ms[l];s.push(h.x+u.x*n,t,h.z+u.z*n,h.x+u.x*n,e,h.z+u.z*n)}let a=s.length/6;for(let c=0;c<a-1;c++){let l=c*2;r.push(l,l+2,l+1,l+1,l+2,l+3)}let o=new Le;o.setAttribute("position",new ae(s,3)),o.setIndex(r),o.computeVertexNormals(),St(o,i,!0,!0)}function Cy(n){let e=xs.indexOf(At)*13,i=eh(256,(r,a)=>{let o=mi(r/32,a/32,5,8,e),c=mi(r/8,a/8,3,32,e+5),l=ir(r,a,e+9),h=1-.07*ls(r/256,.33,.07)-.07*ls(r/256,.67,.07);if(n==="dirt"){let d=132+o*70+c*18,p=90+o*50+c*14,x=56+o*32+c*8;return l>.985?(d+=40,p+=36,x+=30):l<.012&&(d-=40,p-=34,x-=24),[d*h,p*h,x*h]}if(n==="sand"){let d=Math.sin(a*.45+o*9)*7;return[(178+o*30+d)*h,(146+o*26+d)*h,(102+o*20+d*.6)*h]}let u=l>.992?20:0,f=1-.1*ls(r/256,.25,.05)-.1*ls(r/256,.75,.05);return[(158+o*34+u)*h*f,(172+o*26+u)*h*f,(196+o*16+u)*h*f]}),s=i.getContext("2d");for(let r=0;r<70;r++){let a=30+ce()*196,o=ce()*256,c=ce()*.4-.2;s.save(),s.translate(a,o),s.rotate(c),s.fillStyle=n==="snow"?"rgba(120,140,170,.22)":"rgba(40,24,10,.22)",s.beginPath(),s.ellipse(0,4,4,3.5,0,0,7),s.fill();for(let[l,h]of[[-4,-2],[-1.4,-4.5],[1.4,-4.5],[4,-2]])s.beginPath(),s.ellipse(l,h,1.5,1.8,0,0,7),s.fill();s.restore()}return i}function Py(){let[n,t,e]=At.ground,i=xs.indexOf(At)*7+3,s=eh(256,(r,a)=>{let o=mi(r/16,a/16,4,16,i),c=ir(r,a,i),l=.78+o*.4+(c-.5)*(At.ground[0]<150?.22:.08);return[n*l,t*l,e*l]});if(At.trees==="broad"){let r=s.getContext("2d");for(let a=0;a<2600;a++){let o=ce()*256,c=ce()*256,l=110+ce()*90|0;r.strokeStyle=`rgba(${l*.55|0},${l},${l*.35|0},.5)`,r.lineWidth=1,r.beginPath(),r.moveTo(o,c),r.lineTo(o+ce()*2-1,c-2-ce()*3),r.stroke()}}return s}function od(n){be&&(Ke.remove(be),ro(be)),Mi.clear(),vi.clear(),At=xs[n],Ut=At.W,Ia=1e3+n*77,wy(At),be=new wt,Ke.add(be),so=[],ch=[],lh=[],hh=[];let t=At.sky;os.zen.value.setHex(t.zen),os.hor.value.setHex(t.hor),os.gnd.value.setHex(t.gnd),os.sunCol.value.setHex(t.sun),Hl.set(...t.dir).normalize(),os.sunDir.value.copy(Hl),os.haze.value=t.haze,Ke.fog=new da(At.fog[0],At.fog[1],At.fog[2]),pn.color.setHex(At.light.col),pn.intensity=At.light.sun,Oa.color.setHex(t.hor),Oa.groundColor.setHex(t.gnd),vy(),Ly(),Iy(),Dy(),Uy(),Ny(),Fy(),By(),Hy(),ky(),Gy(),Xy(),Yy(),Zy(),cv(),Jy(),xi&&(Ke.remove(xi),xi.geometry.dispose(),xi=null),At.snow&&Vy()}function Ly(){let t=ft.qual===0?100:150,e=new mn(1700,1700,t,t);e.rotateX(-Math.PI/2);let i=e.attributes.position,s=e.attributes.uv,r=new Float32Array(i.count*3);for(let c=0;c<i.count;c++){let l=i.getX(c),h=i.getZ(c),u=cs(l,h);i.setY(c,u),s.setXY(c,l/9,h/9);let f=.82+.36*mi(l*.012,h*.012,3,0,5),d=f,p=f,x=f;if(At.id==="parque"){let g=Lt(.55,.75,mi(l*.006+5,h*.006,3));d+=g*.25,x-=g*.1}if(At.id==="praia"&&u<-.3&&(d*=.8,p*=.78,x*=.72),At.id==="neve"&&u>20){let g=Lt(.62,.72,mi(l*.03,h*.03,2));d-=g*.45,p-=g*.42,x-=g*.38}r[c*3]=d,r[c*3+1]=p,r[c*3+2]=x}e.setAttribute("color",new we(r,3)),e.computeVertexNormals();let a=je(Py());St(e,new oe({map:a,vertexColors:!0,roughness:At.id==="neve"?.7:1}),!1,!0);let o=St(new mn(9e3,9e3),new oe({color:new Ft(`rgb(${At.ground.join(",")})`).multiplyScalar(.8),roughness:1}),!1,!1);if(o.rotation.x=-Math.PI/2,o.position.y=At.sea!==void 0?-8:-.4,or=null,At.sea!==void 0){let c=eh(128,(h,u)=>{let f=(x,g)=>mi(x/16,g/16,3,8,77),d=f(h+1,u)-f(h-1,u),p=f(h,u+1)-f(h,u-1);return[128-d*400,128-p*400,255]});or=je(c,40,40,!1);let l=St(new mn(4e3,4e3),new oe({color:1007490,roughness:.12,metalness:.1,normalMap:or,normalScale:new ut(.6,.6)}),!1,!1);l.rotation.x=-Math.PI/2,l.position.set(0,-1.1,-1400)}}function Iy(){let n=Cy(At.surface),t=je(n),e=At.surface==="snow"?.55:.95;Jr(-Ut/2,Ut/2,.03,Ut,new oe({map:t,bumpMap:je(n,1,1,!1),bumpScale:1.2,roughness:e}));let i=je(ze(4,8,a=>{a.fillStyle=At.curb[0],a.fillRect(0,0,4,4),a.fillStyle=At.curb[1],a.fillRect(0,4,4,4)}));i.magFilter=Ze;let s=new oe({map:i,roughness:.6});Jr(-Ut/2-1.3,-Ut/2,.05,6,s),Jr(Ut/2,Ut/2+1.3,.05,6,s);let r=new oe({map:t,roughness:1,color:13619151});Jr(-Ut/2-2.6,-Ut/2-1.3,.035,Ut,r),Jr(Ut/2+1.3,Ut/2+2.6,.035,Ut,r)}function Dy(){let n=At.id==="praia",t=mt(At.rail,n?.9:.35,n?0:.3,{side:ke});for(let r of[-1,1])Bf(r*(Ut/2+2.6),.95,1.12,t),Bf(r*(Ut/2+2.6),.45,.58,t);let e=Math.floor(Ae/4)*2,i=vn(new Jt(.08,.1,1.25,5),mt(n?7029795:14606046,.5,n?0:.6),e),s=0;for(let r=0;r<Ae-2&&s<e-1;r+=4)for(let a of[-1,1]){let o=Fe(r,a*(Ut/2+2.6));Mn(i,s++,o.x,.62,o.z,0,0,0,1)}i.count=s}function Uy(){let n=je(ze(16,4,o=>{for(let c=0;c<16;c++)for(let l=0;l<4;l++)o.fillStyle=(c+l)%2?"#111":"#f4f4f4",o.fillRect(c,l,1,1)}));n.magFilter=Ze;let t=new It(new mn(Ut,2.4),mt(16777215,.6,0,{map:n}));t.rotation.x=-Math.PI/2,t.receiveShadow=!0;let e=new wt;e.add(t),e.position.copy(Fe(0,0,.06)),e.rotation.y=Jn(0),be.add(e);let i=new wt,s=mt(2830134,.35,.8);for(let o of[-1,1])St(new ge(.9,11,.9),s,!0,!0,i).position.set(o*(Ut/2+3.2),5.5,0),St(new ge(1.8,.6,1.8),mt(5593958,.6,.4),!0,!0,i).position.set(o*(Ut/2+3.2),.3,0);let r=je(ze(512,64,(o,c,l)=>{let h=o.createLinearGradient(0,0,0,l);h.addColorStop(0,"#1a1f2b"),h.addColorStop(1,"#0c0f16"),o.fillStyle=h,o.fillRect(0,0,c,l),o.fillStyle="#ff7a1a",o.fillRect(0,0,c,4),o.fillRect(0,l-4,c,4),o.font="italic 900 38px Arial",o.textAlign="center",o.textBaseline="middle",o.fillStyle="#fff",o.fillText(`LARGADA \xB7 ${At.name}`,c/2,l/2+2)})),a=mt(16777215,.4,0,{map:r,emissive:16777215,emissiveMap:r,emissiveIntensity:.35});St(new ge(Ut+7.3,2.2,.6),[s,s,s,s,a,a],!0,!0,i).position.set(0,10,0);for(let o=0;o<3;o++){let c=new oe({color:2230280,emissive:0,roughness:.3});St(new xe(.42,16,12),c,!1,!1,i).position.set((o-1)*1.2,8.2,-.3),St(new ge(1.05,1.05,.5),s,!1,!1,i).position.set((o-1)*1.2,8.2,.05),ch.push(c)}i.position.copy(Fe(0,0)),i.rotation.y=Jn(0),be.add(i)}function Xl(n,t){ch.forEach((e,i)=>{let s=t||i<n,r=s?t?1113952:16719904:2230280;e.color.setHex(r),e.emissive.setHex(s?r:0),e.emissiveIntensity=s?2.2:0})}function ad(){return oh(He[0].x+ms[0].x*30,He[0].z+ms[0].z*30)?-1:1}function Ny(){let n=ad(),t=new ge(1,1,1),e={concrete:[],seat:[],roof:[],pillar:[]},i=[],s=(l,h,u,f,d,p,x,g)=>{let m=Fe(h,u,f);l.push([m.x,m.y,m.z,g,d,p,x])};for(let l=-52;l<=52;l+=4){let h=Jn(l);for(let u=0;u<7;u++){let f=n*(Ut/2+7+u*1.6);s(e.concrete,l,f,.4*(u+1),1.7,.8*(u+1),4.02,h),s(e.seat,l,f+n*.3,.8*(u+1)+.12,.5,.25,3.9,h);for(let d of[-1.3,0,1.3]){if(ce()<.15)continue;let p=dr(l+d);i.push({x:p.p.x+p.r.x*(f+n*.2),z:p.p.z+p.r.z*(f+n*.2),y:.8*(u+1)+.2,ph:ce()*6,yaw:h})}}s(e.roof,l,n*(Ut/2+13),11.5,14,.3,4.05,h),s(e.concrete,l,n*(Ut/2+19),5.75,.4,11.5,4.05,h),l%16===0&&s(e.pillar,l,n*(Ut/2+7.2),5.75,.4,11.5,.4,h)}let r={concrete:mt(At.stand[0],.9),seat:mt(At.stand[1],.5),roof:mt(15263976,.4,.5),pillar:mt(3817287,.4,.7)};for(let l in e){let h=vn(t,r[l],e[l].length);e[l].forEach((u,f)=>Mn(h,f,u[0],u[1],u[2],0,u[3],0,u[4],u[5],u[6]))}let a=[15022389,2001125,16635957,4431943,16777215,16740419,9315498,44225,2171169],o=[15843965,14724201,9262372,13010498,16767916,7029286];jr=vn(new Jt(.26,.32,.95,6),mt(16777215,.8),i.length,!1),Ha=vn(new xe(.21,7,5),mt(16777215,.7),i.length,!1);let c=new Ft;i.forEach((l,h)=>{jr.setColorAt(h,c.setHex(a[ce()*a.length|0])),Ha.setColorAt(h,c.setHex(o[ce()*o.length|0])),lh.push(l)}),so.push([He[0].x,He[0].z,80])}var oo=.3;function Oy(n){jr&&(lh.forEach((t,e)=>{let i=Math.max(0,Math.sin(n*8+t.ph))*.4*oo;Mn(jr,e,t.x,t.y+.47+i,t.z,0,t.yaw,0,1),Mn(Ha,e,t.x,t.y+1.15+i,t.z,0,0,0,1)}),jr.instanceMatrix.needsUpdate=Ha.instanceMatrix.needsUpdate=!0)}function Fy(){let n=ad();[["RA\xC7\xC3O CROCK","energia para campe\xF5es","#ffcc00","#c62828"],["OSSO DE OURO","o petisco oficial","#101a3a","#ffc53d"],["PET SHOP 2000","tudo para seu c\xE3o","#00a6c8","#ffffff"],["LATIDO FM","97.5 \xB7 a r\xE1dio do auau","#e91e63","#ffffff"],["TURBO DOG","nitro para patas","#111111","#76ff03"],["COLEIRA MAX","aperta sem machucar","#ff8f00","#1a1a1a"],["VET 24H","plant\xE3o veterin\xE1rio","#ffffff","#1565c0"],["PETISCO BOM","sabor bacon","#2e7d32","#ffffff"]].forEach((e,i)=>{let s=Ae*(.1+i*.105),r=je(ze(256,128,(p,x,g)=>{p.fillStyle=e[2],p.fillRect(0,0,x,g);let m=p.createLinearGradient(0,0,0,g);m.addColorStop(0,"rgba(255,255,255,.18)"),m.addColorStop(1,"rgba(0,0,0,.18)"),p.fillStyle=m,p.fillRect(0,0,x,g),p.fillStyle=e[3],p.fillRect(0,g-10,x,10),p.font="italic 900 38px Arial",p.textAlign="center",p.fillText(e[0],x/2,62),p.font="600 18px Arial",p.fillText(e[1].toUpperCase(),x/2,94)})),a=new wt,o=mt(2764341,.5,.6);St(new ge(12,6,.35),[o,o,o,o,mt(16777215,.5,0,{map:r}),o],!0,!0,a).position.y=6.5;for(let p of[-4,4])St(new ge(.35,4,.35),o,!0,!0,a).position.set(p,2,0);let c=dr(s),l=n*(Ut/2+10),h=c.p.x+c.r.x*l,u=c.p.z+c.r.z*l,f=c.r.x,d=c.r.z;a.position.set(h,cs(h,u),u),a.rotation.y=Math.atan2(-n*f,-n*d),be.add(a)})}function zy(n){let t=[];for(let i=-260;i<=260;i+=12)for(let s=-260;s<=260;s+=12){if(!oh(i,s))continue;let r=ah(i,s);r>Ut/2+22&&t.push([i,s,r])}t.sort((i,s)=>s[2]-i[2]);let e=[];for(let i of t)if(e.every(s=>Math.hypot(s[0]-i[0],s[1]-i[1])>55)&&e.push(i),e.length>=n)break;return e}function By(){let n=zy(4),t=(e,i,s)=>{if(!n[i])return;let[r,a]=n[i];e.position.set(r,0,a),e.rotation.y=ce()*6,be.add(e),so.push([r,a,s])};if(At.id==="parque"){{let e=new wt,i=mt(13209170,.8),s=mt(10558749,.6);St(new ge(14,10,14),i,!0,!0,e).position.y=5;let r=new es;r.moveTo(-8.5,0),r.lineTo(0,6.5),r.lineTo(8.5,0),r.lineTo(-8.5,0),St(new Ks(r,{depth:16,bevelEnabled:!1}),s,!0,!0,e).position.set(0,10,-8);let a=St(new Jt(3,3,.4,20,1,!1,0,Math.PI),mt(1708042,1),!1,!0,e);a.rotation.set(Math.PI/2,Math.PI/2,0),a.position.set(0,4,7.05),St(new ge(6,4,.4),mt(1708042,1),!1,!0,e).position.set(0,2,7.05),St(new Jt(2.2,1.6,1.2,20),mt(13840175,.35,.3),!0,!0,e).position.set(6,.6,12),t(e,0,22)}{let e=new wt,i=mt(14163750,.35,.4),s=mt(15909166,.3,.8);St(new Jt(3.6,4,1.2,24),i,!0,!0,e).position.y=.6,St(new Jt(2.6,2.8,9,24),i,!0,!0,e).position.y=5.5,St(new xe(2.7,24,12,0,Math.PI*2,0,Math.PI/2),i,!0,!0,e).position.y=10,St(new Jt(.7,.9,1.4,12),s,!0,!0,e).position.y=13;for(let r of[-1,1]){let a=St(new Jt(1,1,2,14),s,!0,!0,e);a.rotation.z=Math.PI/2,a.position.set(r*3.2,7,0)}t(e,1,12)}{let e=new wt,i=St(new ts(26,40),mt(12167034,1),!1,!0,e);i.rotation.x=-Math.PI/2,i.position.y=.04;let s=St(new ts(23,40),mt(2781071,.08,.1),!1,!0,e);s.rotation.x=-Math.PI/2,s.position.y=.08,t(e,2,30)}{let e=new wt,i=mt(15985362,.45),s=St(new Jt(1.4,1.4,12,20),i,!0,!0,e);s.rotation.z=Math.PI/2,s.position.y=2.4;for(let r of[-6,6])for(let a of[-1.4,1.4])St(new xe(2.2,20,14),i,!0,!0,e).position.set(r,2.4,a);t(e,3,12)}}else if(At.id==="praia"){{let e=new wt,i=je(ze(8,64,s=>{for(let r=0;r<8;r++)s.fillStyle=r%2?"#f4f4f4":"#d32f2f",s.fillRect(0,r*8,8,8)}));St(new Jt(3,4.2,26,24),mt(16777215,.5,0,{map:i}),!0,!0,e).position.y=13,St(new Jt(3.6,3.6,.6,24),mt(2236962,.5,.6),!0,!0,e).position.y=26.3,St(new Jt(2.4,2.4,3,16),mt(16774064,.1,0,{emissive:16769674,emissiveIntensity:1.5}),!1,!1,e).position.y=28,St(new tn(3,3,16),mt(12000284,.5,.3),!0,!0,e).position.y=31,t(e,0,14)}{let e=new wt,i=mt(14268286,1);St(new ge(14,5,14),i,!0,!0,e).position.y=2.5;for(let[s,r]of[[-7,-7],[7,-7],[-7,7],[7,7]])St(new Jt(2.2,2.6,9,12),i,!0,!0,e).position.set(s,4.5,r),St(new tn(2.6,3.5,12),i,!0,!0,e).position.set(s,10.7,r);St(new Jt(3,3.4,11,14),i,!0,!0,e).position.set(0,5.5,0),t(e,1,16)}{let e=new wt,i=[15022389,2001125,16635957,4431943,16740419];for(let s=0;s<7;s++){let r=Wt(-14,14),a=Wt(-14,14);St(new Jt(.12,.12,5,8),mt(15658734,.4,.5),!0,!0,e).position.set(r,2.5,a),St(new tn(3.2,1.4,12,1,!0),mt(i[s%5],.6,0,{side:ke}),!0,!0,e).position.set(r,5.2,a);let o=St(new ge(1.6,.05,3),mt(i[(s+2)%5],.9),!1,!0,e);o.position.set(r+2,.05,a),o.rotation.y=ce()}t(e,2,20)}}else{{let e=new wt,i=mt(7162413,.9),s=mt(16054527,.6);St(new ge(14,8,11),i,!0,!0,e).position.y=4;let r=new es;r.moveTo(-8.5,0),r.lineTo(0,6),r.lineTo(8.5,0),r.lineTo(-8.5,0),St(new Ks(r,{depth:13,bevelEnabled:!1}),s,!0,!0,e).position.set(0,8,-6.5),St(new ge(1.6,6,1.6),mt(7829367,.9),!0,!0,e).position.set(4,12,0);let a=mt(16765562,.3,0,{emissive:16756800,emissiveIntensity:1.2});for(let o of[-4,4])St(new ge(2,2,.2),a,!1,!1,e).position.set(o,4.5,5.55);t(e,0,16)}{let e=new wt,i=mt(16251647,.6);for(let s=0;s<3;s++){let r=(s-1)*7,a=1+s*.15;St(new xe(2*a,20,14),i,!0,!0,e).position.set(r,1.8*a,0),St(new xe(1.4*a,20,14),i,!0,!0,e).position.set(r,4.4*a,0),St(new xe(.95*a,20,14),i,!0,!0,e).position.set(r,6.4*a,0);let o=St(new tn(.18*a,1*a,10),mt(16742938,.6),!0,!0,e);o.rotation.x=Math.PI/2,o.position.set(r,6.4*a,1.3*a),St(new Jt(.7*a,.7*a,1.2*a,16),mt(1710618,.5),!0,!0,e).position.set(r,7.6*a,0)}t(e,1,14)}{let e=new wt,i=St(new ts(24,40),mt(12575999,.05,.1),!1,!0,e);i.rotation.x=-Math.PI/2,i.position.y=.06,t(e,2,28)}}}function Hy(){let n=ft.qual===0,t=(o,c,l)=>{let h=[],u=0;for(;h.length<o&&u++<o*25;){let f=Wt(-l,l),d=Wt(-l,l),p=ah(f,d);p<c||so.some(x=>Math.hypot(f-x[0],d-x[1])<x[2])||At.sea!==void 0&&d<At.sea+4||h.push([f,d,p])}return h},e=n?130:ft.qual===1?220:320,i=new Ft;if(At.trees==="broad"){let o=t(e,Ut/2+9,520),c=vn(new Jt(.3,.5,1,7).translate(0,.5,0),mt(5913894,.95),o.length),l=new js(1,1);{let u=l.attributes.position;for(let f=0;f<u.count;f++){te.fromBufferAttribute(u,f);let d=.82+.3*yi(te.x*2.3+5,te.y*2.3+te.z*1.7,0,9);u.setXYZ(f,te.x*d,te.y*d,te.z*d)}l.computeVertexNormals()}let h=vn(l,mt(16777215,.9),o.length*3);o.forEach(([u,f],d)=>{let p=Wt(.8,1.4),x=cs(u,f),g=5*p;Mn(c,d,u,x,f,0,0,0,p,g,p);for(let m=0;m<3;m++){let S=2.6*p*Wt(.8,1.1);Mn(h,d*3+m,u+Wt(-1.2,1.2)*p,x+g+S*.5+m*1.1*p,f+Wt(-1.2,1.2)*p,ce()*3,ce()*3,0,S,S*Wt(.8,1),S),h.setColorAt(d*3+m,i.setHSL(Wt(.22,.32),Wt(.45,.65),Wt(.18,.3)))}})}else if(At.trees==="pine"){let o=t(e*1.2|0,Ut/2+9,520),c=vn(new Jt(.25,.4,1,6).translate(0,.5,0),mt(4862498,.95),o.length),l=new tn(1,1,10,3).translate(0,.5,0);{let u=l.attributes.position,f=new Float32Array(u.count*3);for(let d=0;d<u.count;d++){let p=u.getY(d)>.45;f[d*3]=p?1:.3,f[d*3+1]=p?1:.42,f[d*3+2]=p?1.05:.3}l.setAttribute("color",new we(f,3))}let h=vn(l,mt(16777215,.85,0,{vertexColors:!0}),o.length*3);o.forEach(([u,f],d)=>{let p=Wt(.8,1.6),x=cs(u,f);Mn(c,d,u,x,f,0,0,0,p,3*p,p);for(let g=0;g<3;g++){let m=(3.4-g*.9)*p;Mn(h,d*3+g,u,x+(2.2+g*2.6)*p,f,0,ce()*3,0,m,4.2*p,m),h.setColorAt(d*3+g,i.setHSL(.36,.25,Wt(.62,.8)))}})}else{let o=t(e*.7|0,Ut/2+8,480),c=vn(new Jt(.28,.34,1.6,8).translate(0,.8,0),mt(9071176,.9),o.length*7),l=new mn(1,1,1,8);{let f=l.attributes.position;for(let d=0;d<f.count;d++){let p=f.getX(d),x=f.getY(d)+.5;f.setXYZ(d,p*(1-x*.8)*1.2,-x*x*1.6,x*4.8)}l.computeVertexNormals()}let h=vn(l,mt(4164142,.8,0,{side:ke}),o.length*8),u=vn(new xe(.28,8,6),mt(5913114,.7),o.length*3);o.forEach(([f,d],p)=>{let x=Wt(.05,.22),g=ce()*6.28,m=f,S=cs(f,d),_=d;for(let b=0;b<7;b++){let C=x*(b+1)*.35;Mn(c,p*7+b,m,S,_,Math.cos(g)*C,0,-Math.sin(g)*C,1-b*.05),m+=Math.sin(g)*Math.sin(C)*1.5,_+=Math.cos(g)*Math.sin(C)*1.5,S+=Math.cos(C)*1.5*(1-b*.05)}for(let b=0;b<8;b++)Mn(h,p*8+b,m,S,_,0,b/8*6.28+ce()*.3,0,1.2,1,1.2),h.setColorAt(p*8+b,i.setHSL(Wt(.24,.3),.55,Wt(.25,.35)));for(let b=0;b<3;b++)Mn(u,p*3+b,m+Math.cos(b*2)*.4,S-.3,_+Math.sin(b*2)*.4,0,0,0,1)})}let s=t(n?40:90,Ut/2+6,420),r=new js(1,1);{let o=r.attributes.position;for(let c=0;c<o.count;c++){te.fromBufferAttribute(o,c);let l=.7+.5*yi(te.x*2+3,te.y*2+te.z*2,0,4);o.setXYZ(c,te.x*l,te.y*l*.7,te.z*l)}r.computeVertexNormals()}let a=vn(r,mt(At.id==="neve"?8160660:9274745,.95,0,{flatShading:!0}),s.length);if(s.forEach(([o,c],l)=>{let h=Wt(.6,2.4);Mn(a,l,o,cs(o,c)+h*.2,c,ce(),ce()*6,0,h,h,h)}),At.id!=="neve"){let o=n?700:At.id==="praia"?900:ft.qual===1?1800:3200,c=new Le,l=[];for(let f=0;f<5;f++){let d=f/5*Math.PI,p=Math.cos(d)*.12,x=Math.sin(d)*.12,g=Wt(-.25,.25);l.push(-p,0,-x,p,0,x,g*1.4,.7+ce()*.4,g)}c.setAttribute("position",new ae(l,3)),c.computeVertexNormals();let h=vn(c,mt(16777215,.9,0,{side:ke}),o,!1),u=0;for(let f=0;f<o*3&&u<o;f++){let d=ce()*Ae,p=ce()<.5?-1:1,x=p*(Ut/2+3+ce()*ce()*40),g=Fe(d,x);so.some(m=>Math.hypot(g.x-m[0],g.z-m[1])<m[2])||At.sea!==void 0&&g.z<At.sea||(Mn(h,u,g.x,cs(g.x,g.z),g.z,0,ce()*6,0,Wt(.7,1.6)),h.setColorAt(u++,At.id==="praia"?i.setHSL(.2,.35,Wt(.35,.5)):i.setHSL(Wt(.2,.3),Wt(.4,.6),Wt(.2,.34))))}h.count=u}}function ky(){for(let n=0;n<26;n++){let t=n/26*Math.PI*2+Wt(-.1,.1),e=Wt(700,880),i=Math.cos(t)*e,s=Math.sin(t)*e;if(At.sea!==void 0&&s<-250)continue;let r=Wt(110,260)*(At.id==="neve"?1.35:1),a=Wt(140,240),o=new tn(a,r,18,6,!0),c=o.attributes.position,l=new Float32Array(c.count*3),h=new Ft(At.mtn[n%2]),u=new Ft(15922682),f=new Ft;for(let d=0;d<c.count;d++){te.fromBufferAttribute(c,d);let p=(te.y+r/2)/r,x=mi(te.x*.02+n*7,te.z*.02+te.y*.02,4),g=1+(x-.5)*.5*(1-p*.5);c.setXYZ(d,te.x*g,te.y+(x-.5)*r*.12,te.z*g),f.copy(h).lerp(u,Lt(.62-x*.2,.75-x*.2,p)*(At.id==="praia"?0:1)),l[d*3]=f.r,l[d*3+1]=f.g,l[d*3+2]=f.b}o.setAttribute("color",new we(l,3)),o.computeVertexNormals(),St(o,mt(16777215,.95,0,{vertexColors:!0,flatShading:!0}),!1,!1).position.set(i,r/2-4,s)}}function Gy(){let n=new ui(ze(256,128,e=>{for(let i=0;i<26;i++){let s=40+ce()*176,r=50+ce()*40,a=18+ce()*30,o=e.createRadialGradient(s,r,0,s,r,a);o.addColorStop(0,"rgba(255,255,255,.9)"),o.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=o,e.fillRect(0,0,256,128)}}));n.colorSpace=Ce;let t=At.id==="praia"?16763040:16777215;for(let e=0;e<18;e++){let i=new Js(new Qi({map:n,color:t,fog:!1,depthWrite:!1,transparent:!0,opacity:Wt(.6,.95)})),s=ce()*6.28,r=Wt(450,900);i.position.set(Math.cos(s)*r,Wt(160,300),Math.sin(s)*r),i.scale.set(Wt(220,380),Wt(90,140),1),be.add(i),hh.push(i)}}function Vy(){let n=ft.qual===0?700:1600,t=new Float32Array(n*3);for(let i=0;i<n;i++)t[i*3]=Wt(-60,60),t[i*3+1]=Wt(0,40),t[i*3+2]=Wt(-60,60);let e=new Le;e.setAttribute("position",new we(t,3)),xi=new Hr(e,new Br({size:.22,map:ih,transparent:!0,depthWrite:!1,color:16777215})),xi.frustumCulled=!1,Ke.add(xi)}function Wy(n){let t=new wt,e=new It(new Jt(.14,.14,.9,12),n);e.rotation.z=Math.PI/2,t.add(e);for(let i of[-.45,.45])for(let s of[-.13,.13]){let r=new It(new xe(.2,12,10),n);r.position.set(i,s,0),t.add(r)}return t.traverse(i=>{i.isMesh&&(i.castShadow=!0)}),t}function Xy(){zi=[],Vl=[],ka=[],Ga=[],ar=[],io=[];let n=[["pad",.06,-3],["hurdle",.13],["coins",.19,-4],["puddle",.26,4],["nitro",.32],["ramp",.4],["coins",.46,3],["hurdle",.52],["puddle",.59,-3.5],["pad",.65,3],["nitro",.71],["coins",.77,0],["hurdle",.83],["puddle",.89,2.5],["nitro",.95],["ammo",.23],["ammo",.62],["ammo",.925]];Qr=je(ze(64,64,h=>{h.fillStyle="#062a3a",h.fillRect(0,0,64,64),h.strokeStyle="#35d0ff",h.lineWidth=9;for(let u of[10,42])h.beginPath(),h.moveTo(8,u+18),h.lineTo(32,u),h.lineTo(56,u+18),h.stroke()}),1,2);let t=je(ze(64,4,h=>{for(let u=0;u<8;u++)h.fillStyle=u%2?"#ffffff":"#e53935",h.fillRect(u*8,0,8,4)}),3,1),e={mud:mt(3876372,.15,0),water:mt(3833768,.05,.1,{transparent:!0,opacity:.85}),ice:mt(13496063,.03,.2)}[At.puddle],i=mt(2060287,.25,.7),s=mt(3526911,.2,0,{emissive:3526911,emissiveIntensity:1.2}),r=new Pn({color:3526911,transparent:!0,opacity:.45,blending:Ui,depthWrite:!1,side:ke}),a=mt(16762173,.28,.55,{emissive:4861952});ao=[];let o=je(ze(64,64,h=>{h.fillStyle="#3f4a2c",h.fillRect(0,0,64,64),h.strokeStyle="#2a3120",h.lineWidth=4,h.strokeRect(2,2,60,60),h.beginPath(),h.moveTo(2,2),h.lineTo(62,62),h.moveTo(62,2),h.lineTo(2,62),h.stroke(),h.fillStyle="#ffcc00",h.fillRect(16,26,32,12),h.fillStyle="#111",h.font="bold 10px Arial",h.textAlign="center",h.fillText("M\xCDSSIL",32,35)})),c=mt(16777215,.7,.1,{map:o}),l=mt(16777215,.3,0,{map:Qr,emissive:16777215,emissiveMap:Qr,emissiveIntensity:1.4});for(let[h,u,f=0]of n){let d=Ae*u;if(h==="hurdle"){let p=new wt,x=new wt;St(new ge(Ut+1,.2,.2),mt(16777215,.4,0,{map:t}),!0,!0,x),x.position.y=.95,p.add(x);for(let g of[-1,1])St(new ge(.22,1.4,.22),mt(15790320,.4,.3),!0,!0,p).position.set(g*(Ut/2+.6),.7,0),St(new ge(.3,.12,1.4),mt(3355443,.5,.5),!0,!0,p).position.set(g*(Ut/2+.6),.06,0);p.position.copy(Fe(d,0)),p.rotation.y=Jn(d),be.add(p),zi.push({s:d,bar:x,fall:0})}else if(h==="ramp"){let p=new es;p.moveTo(-3,0),p.lineTo(3,0),p.lineTo(3,1.1),p.lineTo(-3,0);let x=new Ks(p,{depth:Ut,bevelEnabled:!1});x.translate(0,0,-Ut/2),x.rotateY(-Math.PI/2);let g=je(ze(64,64,S=>{S.fillStyle="#ffb300",S.fillRect(0,0,64,64),S.fillStyle="#1a1a1a";for(let _=-64;_<128;_+=22)S.beginPath(),S.moveTo(_,0),S.lineTo(_+11,0),S.lineTo(_+75,64),S.lineTo(_+64,64),S.fill()}),.25,.25),m=St(x,mt(16777215,.6,.2,{map:g}));m.position.copy(Fe(d,0,.02)),m.rotation.y=Jn(d),Vl.push({s:d+3})}else if(h==="pad"){let p=St(new mn(4.2,7),l,!1,!0);p.rotation.x=-Math.PI/2;let x=new wt;x.add(p),x.position.copy(Fe(d,f,.07)),x.rotation.y=Jn(d),be.add(x),ka.push({s:d,d:f})}else if(h==="puddle"){let x=St(new ts(3.3,32),e,!1,!0);x.rotation.x=-Math.PI/2;let g=new wt;g.add(x),g.scale.set(.8,1,1.4),g.position.copy(Fe(d,f,.06)),g.rotation.y=Jn(d),be.add(g),Ga.push({s:d,d:f,r:3.3,type:At.puddle})}else if(h==="nitro")for(let p of[-5,0,5]){let x=new wt;St(new Jt(.42,.42,1.2,20),i,!0,!0,x),St(new Jt(.44,.44,.3,20),s,!1,!1,x),St(new Jt(.15,.2,.25,12),za,!1,!1,x).position.y=.72;let g=St(new qr(.8,1.1,32),r,!1,!1,x);g.rotation.x=-Math.PI/2,g.position.y=-1.15,x.position.copy(Fe(d,p,1.3)),be.add(x),ar.push({s:d,d:p,g:x,cd:0})}else if(h==="ammo")for(let p of[-5,0,5]){let x=new wt;St(new ge(1.1,.8,1.1),c,!0,!0,x);let g=gd();g.visible=!0,g.scale.setScalar(.55),g.position.y=.7,g.rotation.x=-Math.PI/2,x.add(g);let m=St(new qr(.9,1.2,32),new Pn({color:16734778,transparent:!0,opacity:.45,blending:Ui,depthWrite:!1,side:ke}),!1,!1,x);m.rotation.x=-Math.PI/2,m.position.y=-1,x.position.copy(Fe(d,p,1.1)),be.add(x),ao.push({s:d,d:p,g:x,cd:0})}else if(h==="coins")for(let p=0;p<6;p++){let x=Wy(a);x.scale.setScalar(1.1);let g=d+p*4;x.position.copy(Fe(g,f,1.1)),be.add(x),io.push({s:g,d:f,g:x,taken:!1})}}}var cr=[];function Yy(){cr=[],[[.36,1,0],[.555,-1,3.2]].forEach(([n,t,e])=>{let i=Ae*n,s=new wt,r=new wt,a=new wt;s.position.copy(Fe(i,0)),s.rotation.y=Jn(i),s.add(r),r.add(a),be.add(s);let o=1.3,c="";if(At.id==="parque"){o=1.2,c="ATROPELADO PELO FENO!";let f=je(ze(64,64,p=>{p.fillStyle="#d9b44a",p.fillRect(0,0,64,64);for(let x=0;x<220;x++){p.strokeStyle=Math.random()<.5?"#b8912f":"#f0d27a",p.beginPath();let g=Math.random()*64,m=Math.random()*64;p.moveTo(g,m),p.lineTo(g+Math.random()*10-5,m+Math.random()*3),p.stroke()}})),d=St(new Jt(o,o,2.2,24),mt(16777215,.95,0,{map:f}),!0,!0,a);d.rotation.x=Math.PI/2;for(let p of[-.5,.5]){let x=St(new $r(o+.01,.05,6,32),mt(8014622,.8),!1,!1,a);x.position.z=p}}else if(At.id==="praia"){o=1.35,c="BOLADA DE PRAIA!";let f=je(ze(128,64,d=>{["#e53935","#ffffff","#1e88e5","#ffffff","#fdd835","#ffffff"].forEach((x,g)=>{d.fillStyle=x,d.fillRect(g*128/6,0,128/6+1,64)})}));St(new xe(o,28,18),mt(16777215,.35,0,{map:f}),!0,!0,a)}else{o=1.5,c="ATROPELADO PELA BOLA DE NEVE!";let f=new js(o,3),d=f.attributes.position;for(let p=0;p<d.count;p++){te.fromBufferAttribute(d,p);let x=.92+.12*yi(te.x*2+4,te.y*2+te.z*2,0,7);d.setXYZ(p,te.x*x,te.y*x,te.z*x)}f.computeVertexNormals(),St(f,mt(16054527,.6),!0,!0,a)}let l=new wt,h=je(ze(64,64,f=>{f.fillStyle="#ffcc00",f.beginPath(),f.moveTo(32,3),f.lineTo(61,32),f.lineTo(32,61),f.lineTo(3,32),f.fill(),f.fillStyle="#111",f.beginPath(),f.arc(32,36,11,0,7),f.fill(),f.fillRect(12,46,40,4)}));St(new ge(1.6,1.6,.08),[mt(3355443),mt(3355443),mt(3355443),mt(3355443),mt(16777215,.5,0,{map:h}),mt(3355443)],!0,!0,l).position.y=2.6,St(new Jt(.06,.06,2,6),mt(7829367,.5,.6),!0,!0,l).position.y=1;let u=Fe(i-25,-(Ut/2+3.4));l.position.set(u.x,0,u.z),l.rotation.y=Jn(i)+Math.PI,be.add(l),cr.push({s:i,dir:t,off:e,r:o,roller:r,active:!1,d:0,hitMsg:c,period:7.5})})}function uh(n){for(let t of cr){let e=((n+t.off)%t.period+t.period)%t.period,i=3.6,s=Ut/2+6,r=Math.min(1,e/i);t.d=t.dir*Ne(-s,s,r),t.active=e<i&&Math.abs(t.d)<Ut/2+1,t.roller.visible=e<i+.4,t.roller.position.set(-t.d,t.r,0),t.roller.rotation.z=t.d/t.r}}var qy={parque:{name:"POMBO",plural:"POMBOS",body:9213349,wing:10397622,tip:3817288,head:5205859,beak:3355443,pitch:1},praia:{name:"GAIVOTA",plural:"GAIVOTAS",body:16185074,wing:12173770,tip:1710618,head:16777215,beak:15907118,pitch:1.4},neve:{name:"CORVO",plural:"CORVOS",body:1382172,wing:1842982,tip:789776,head:1382172,beak:2105376,pitch:.7}},Fi=()=>qy[At.id],fs=[],to=8;function $y(n){let t=new wt,e=a=>mt(a,.6,.05),i=(a,o,c,l,h,u=t)=>{let f=new It(a,o);return f.position.set(c,l,h),f.castShadow=!0,u.add(f),f};i(gi(.2,.19,.38),e(n.body),0,0,0),i(new xe(.14,14,10),e(n.head),0,.14,.33);let s=i(new tn(.045,.14,8),e(n.beak),0,.12,.5);s.rotation.x=Math.PI/2;for(let a of[-1,1])i(new xe(.03,8,6),mt(657930,.1),a*.09,.18,.42);i(gi(.14,.025,.24),e(n.tip),0,.02,-.44);let r=[];for(let a of[-1,1]){let o=new wt;o.position.set(a*.14,.08,.04),t.add(o),i(gi(.42,.02,.2),e(n.wing),a*.4,0,0,o),i(gi(.18,.018,.12),e(n.tip),a*.78,0,-.05,o),r.push({piv:o,sx:a})}for(let a of[-1,1]){let o=i(new Jt(.012,.012,.16,5),mt(13662784,.6),a*.06,-.2,-.05);o.rotation.x=.8}return t.scale.setScalar(1.7),{g:t,wings:r}}function Zy(){fs=[],to=7;for(let n=0;n<4;n++){let t=$y(Fi());t.g.visible=!1,be.add(t.g),fs.push({...t,state:"off",pos:new L,vel:new L,t:0,target:null,phase:Math.random()*6})}}function Ua(n,t){n.state="flee",n.t=0;let e=n.pos.x-t.x,i=n.pos.z-t.z,s=Math.hypot(e,i)||1;n.vel.set(e/s*22,14,i/s*22),n.target&&(n.target.birdT=0),Nt.squawk(Fi().pitch,ct?de(1-Math.hypot(n.pos.x-ct.x,n.pos.z-ct.z)/60,0,1):1);for(let r=0;r<8;r++)Mi.spawn(n.pos.x,n.pos.y,n.pos.z,(Math.random()-.5)*6,Math.random()*3,(Math.random()-.5)*6,1.2,.25,.15,[.95,.95,.95],.9,3,1.5)}var rs=new L;function cd(n,t){if(t&&Vn>5){to-=n;let e=fs.filter(i=>i.state==="approach"||i.state==="harass").length;if(to<=0&&e<1+ft.diff){to=6+Math.random()*5-ft.diff;let i=fs.find(r=>r.state==="off"),s=ue.filter(r=>!r.finished&&r.birdT<=0);if(i&&s.length){let r=s.includes(ct)&&Math.random()<.5?ct:s[Math.random()*s.length|0],a=dr(r.dist+55+Math.random()*20),o=(Math.random()-.5)*30;i.pos.set(a.p.x+a.r.x*o,16+Math.random()*6,a.p.z+a.r.z*o),i.vel.set(0,0,0),i.state="approach",i.t=0,i.target=r,i.g.visible=!0,r.isPlayer&&Se(`CUIDADO: ${Fi().name}!`,"o")}}}for(let e of fs){if(e.state==="off")continue;e.t+=n,e.phase+=n*(e.state==="harass"?22:15);let i=e.target;if(e.state==="approach"||e.state==="harass")if(!i||i.finished||!t)Ua(e,e.pos);else{i.D.head.getWorldPosition(rs);let r=Math.sin(i.h),a=Math.cos(i.h);if(e.state==="approach"){te.set(rs.x+r*1.2-e.pos.x,rs.y+.8-e.pos.y,rs.z+a*1.2-e.pos.z);let o=te.length(),c=Math.hypot(i.vx,i.vz)+16;e.vel.lerp(te.multiplyScalar(c/Math.max(o,.01)),1-Math.exp(-3*n)),e.pos.addScaledVector(e.vel,n),o<2.4&&(e.state="harass",e.t=0,i.isPlayer&&(Se(`${Fi().name} NA CARA! LATE!`,"r"),Nt.squawk(Fi().pitch,1))),e.t>12&&Ua(e,e.pos)}else{let o=e.t*5;te.set(rs.x+r*1.3+Math.cos(o)*.9,rs.y+.55+Math.sin(e.t*9)*.25,rs.z+a*1.3+Math.sin(o)*.9),e.vel.copy(te).sub(e.pos).divideScalar(Math.max(n,.001)).clampLength(0,80),e.pos.lerp(te,1-Math.exp(-10*n)),i.birdT=.25,Math.random()<n*1.5&&Nt.squawk(Fi().pitch,i.isPlayer?.6:.2),e.t>6&&Ua(e,e.pos)}}else e.state==="flee"&&(e.vel.y+=n*4,e.pos.addScaledVector(e.vel,n),e.t>4&&(e.state="off",e.g.visible=!1));e.g.position.copy(e.pos),e.vel.lengthSq()>1&&e.g.rotation.set(-de(e.vel.y*.03,-.5,.5),Math.atan2(e.vel.x,e.vel.z),0);let s=Math.sin(e.phase)*(e.state==="flee"?.9:.7);for(let r of e.wings)r.piv.rotation.z=r.sx*s}}function ld(){for(let n of fs)n.state="off",n.g.visible=!1,n.target=null;to=7}function Jy(){let n=1/0,t=-1/0,e=1/0,i=-1/0;for(let o of He)n=Math.min(n,o.x),t=Math.max(t,o.x),e=Math.min(e,o.z),i=Math.max(i,o.z);let s=216/Math.max(t-n,i-e),r=128-(n+t)/2*s,a=128-(e+i)/2*s;Wl={f:(o,c)=>[o*s+r,c*s+a],canvas:ze(256,256,o=>{o.lineJoin="round",o.beginPath();for(let c=0;c<=Be;c+=8){let l=He[c%Be],h=l.x*s+r,u=l.z*s+a;c?o.lineTo(h,u):o.moveTo(h,u)}o.closePath(),o.lineWidth=16,o.strokeStyle="rgba(0,0,0,.55)",o.stroke(),o.lineWidth=9,o.strokeStyle="rgba(255,255,255,.9)",o.stroke(),o.fillStyle="#ff7a1a",o.fillRect(He[0].x*s+r-6,He[0].z*s+a-6,12,12)})}}var hd=[{name:"REDLINE AGOG",src:"musica/redline-agog.mp3"},{name:"APEX PURSUIT",src:"musica/apex-pursuit.mp3"}],ud=["TODAS","REDLINE AGOG","APEX PURSUIT","8-BIT","DESLIGADA"],Sn=new Audio;Sn.preload="none";Sn.volume=.6;var Yl=Math.random()<.5?0:1,ql=!1;Sn.addEventListener("ended",()=>{ft.musicMode===0&&(Yl=(Yl+1)%hd.length,$a(!0))});Sn.addEventListener("error",()=>{Sn.getAttribute("src")&&(ql=!0,$a())});function $a(n){let t=ft.musicMode,e=t<=2&&!ql;if(Nt.ctx&&Nt.setMusic(t===3||t<=2&&ql),e){let i=hd[t===0?Yl:t-1];Sn.getAttribute("src")!==i.src&&(Sn.src=i.src,n=!0),Sn.loop=t!==0;let s=Sn.play();s&&s.catch(()=>{}),n&&Nt.ctx&&Se("\u266A "+i.name,"c")}else Sn.pause()}function fd(){ft.musicMode=(ft.musicMode+1)%ud.length,Wn(),$a(!0)}var Nt={ctx:null,master:null,music:null,sfx:null,nb:null,loops:{},timer:null,init(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}let n=window.AudioContext||window.webkitAudioContext;if(!n)return;let t=this.ctx=new n;this.master=t.createGain(),this.master.gain.value=.75;let e=t.createDynamicsCompressor();this.master.connect(e).connect(t.destination),this.music=t.createGain(),this.music.gain.value=0;let i=t.createBiquadFilter();i.type="lowpass",i.frequency.value=3200,this.music.connect(i).connect(this.master),this.sfx=t.createGain(),this.sfx.connect(this.master);let s=t.createBuffer(1,t.sampleRate*2,t.sampleRate),r=s.getChannelData(0);for(let a=0;a<r.length;a++)r[a]=Math.random()*2-1;this.nb=s,this.loops.wind=this.loopNoise("highpass",900,.5),this.loops.skid=this.loopNoise("bandpass",2400,2.5),this.loops.nitro=this.loopNoise("lowpass",500,1),this.loops.crowd=this.loopNoise("bandpass",750,.7),this.setLoop("crowd",.035),this.startMusic(),$a()},loopNoise(n,t,e){let i=this.ctx,s=i.createBufferSource();s.buffer=this.nb,s.loop=!0;let r=i.createBiquadFilter();r.type=n,r.frequency.value=t,r.Q.value=e;let a=i.createGain();return a.gain.value=0,s.connect(r).connect(a).connect(this.sfx),s.start(0,Math.random()),{g:a,f:r}},setLoop(n,t,e){let i=this.loops[n];i&&(i.g.gain.setTargetAtTime(t,this.ctx.currentTime,.06),e&&i.f.frequency.setTargetAtTime(e,this.ctx.currentTime,.1))},tone(n,t,e="square",i=.2,s=0,r=0,a=null){if(!this.ctx)return;let o=this.ctx,c=r||o.currentTime,l=o.createOscillator(),h=o.createGain();l.type=e,l.frequency.setValueAtTime(n,c),s&&l.frequency.exponentialRampToValueAtTime(s,c+t),h.gain.setValueAtTime(i,c),h.gain.exponentialRampToValueAtTime(.001,c+t),l.connect(h).connect(a||this.sfx),l.start(c),l.stop(c+t+.03)},noise(n,t,e,i=0,s=null,r="bandpass"){if(!this.ctx)return;let a=this.ctx,o=i||a.currentTime,c=a.createBufferSource();c.buffer=this.nb;let l=a.createBiquadFilter();l.type=r,l.frequency.value=e,l.Q.value=1.2;let h=a.createGain();h.gain.setValueAtTime(t,o),h.gain.exponentialRampToValueAtTime(.001,o+n),c.connect(l).connect(h).connect(s||this.sfx),c.start(o,Math.random()),c.stop(o+n+.03)},bark(n=1,t=1){if(!this.ctx||t<.02)return;let e=this.ctx.currentTime;for(let i=0;i<2;i++){let s=e+i*.19;this.tone(560*n,.13,"sawtooth",.2*t,230*n,s),this.tone(280*n,.13,"triangle",.18*t,140*n,s),this.noise(.1,.25*t,1300*n,s)}},voice(n,t=1){if(!this.ctx||t<.02)return;let e=this.ctx.currentTime,i=n.pitch||1;if(n.voice==="hiss")for(let s=0;s<2;s++)this.noise(.32,.32*t,3800*i,e+s*.36,null,"highpass"),this.noise(.3,.12*t,1600*i,e+s*.36);else if(n.voice==="grunt")for(let s=0;s<3;s++){let r=e+s*.17;this.tone(190*i,.12,"square",.12*t,110*i,r),this.tone(95*i,.12,"sawtooth",.12*t,70*i,r),this.noise(.1,.2*t,500,r,null,"lowpass")}else this.bark(i,t)},boom(n=1){!this.ctx||n<.02||(this.noise(.8,.6*n,120,0,null,"lowpass"),this.noise(.4,.4*n,900),this.tone(90,.6,"sine",.4*n,30))},launch(n=1){!this.ctx||n<.02||(this.noise(.5,.35*n,1400),this.tone(300,.35,"sawtooth",.08*n,900))},reload(){let n=this.ctx?this.ctx.currentTime:0;this.noise(.05,.3,3e3,n),this.noise(.06,.3,1800,n+.12),this.tone(700,.1,"square",.06,0,n+.12)},lockon(){this.tone(1760,.06,"square",.07)},squawk(n=1,t=1){if(!this.ctx||t<.03)return;let e=this.ctx.currentTime;for(let i=0;i<2;i++)this.tone(1300*n,.09,"sawtooth",.09*t,800*n,e+i*.12),this.noise(.07,.12*t,2500*n,e+i*.12)},beep(n){this.tone(n?1320:660,n?.6:.25,"square",.14)},jump(){this.noise(.18,.14,700),this.tone(220,.16,"sine",.12,420)},land(){this.noise(.12,.25,180,0,null,"lowpass")},paw(n,t){this.noise(.05,.05+n*.05,t==="snow"?1500:t==="sand"?700:260,0,null,"lowpass")},pickup(){let n=this.ctx?this.ctx.currentTime:0;[523,784,1047].forEach((t,e)=>this.tone(t,.16,"triangle",.14,0,n+e*.05)),this.tone(300,.4,"sawtooth",.05,1200)},coin(){let n=this.ctx?this.ctx.currentTime:0;this.tone(1568,.08,"square",.07,0,n),this.tone(2093,.2,"square",.07,0,n+.06)},boost(){this.tone(180,.5,"sawtooth",.12,900),this.noise(.5,.22,1200)},splash(){this.noise(.35,.3,900)},trip(){this.tone(300,.45,"sawtooth",.14,70),this.noise(.25,.3,300)},thud(){this.noise(.14,.35,150,0,null,"lowpass")},lap(){let n=this.ctx?this.ctx.currentTime:0;[880,1175].forEach((t,e)=>this.tone(t,.18,"square",.1,0,n+e*.12))},fanfare(){if(!this.ctx)return;let n=this.ctx.currentTime;[[523,0],[659,.12],[784,.24],[1047,.36],[784,.56],[1047,.68]].forEach(([t,e])=>this.tone(t,.25,"square",.1,0,n+e)),this.cheer()},cheer(){if(!this.ctx)return;let n=this.loops.crowd.g.gain,t=this.ctx.currentTime;n.cancelScheduledValues(t),n.setValueAtTime(.22,t),n.linearRampToValueAtTime(.035,t+4)},setMusic(n){this.music&&this.music.gain.setTargetAtTime(n?.22:0,this.ctx.currentTime,.1)},startMusic(){if(this.timer||!this.ctx)return;let n=a=>440*Math.pow(2,(a-69)/12),t=[[45,[0,3,7]],[41,[0,4,7]],[48,[0,4,7]],[43,[0,4,7]]],e=[76,0,76,79,0,76,74,72,72,0,72,76,0,72,71,69,72,0,72,76,0,79,77,76,74,0,74,79,0,78,79,0],i=60/124/4,s=0,r=this.ctx.currentTime+.1;this.timer=setInterval(()=>{if(!(!this.ctx||this.ctx.state!=="running"))for(;r<this.ctx.currentTime+.15;){let a=(s>>4)%4,o=s%16,[c,l]=t[a],h=this.music;o%2===0&&this.tone(n(c-12+(o%4===2?12:0)),i*1.8,"sawtooth",.22,0,r,h),this.tone(n(c+24+l[o%3]+(o%6>2?12:0)),i*.9,"square",.035,0,r,h);let u=e[(s>>1)%32];s%2===0&&u&&(s>>6)%2&&this.tone(n(u),i*1.8,"triangle",.09,0,r,h),o%4===0&&this.tone(150,.16,"sine",.5,40,r,h),(o===4||o===12)&&this.noise(.14,.3,1800,r,h),o%2===1&&this.noise(.03,.08,8e3,r,h,"highpass"),r+=i,s++}},25)}},gs=[{n:"F\xC1CIL",k:.93,miss:.25,upOff:-1,reward:.8},{n:"NORMAL",k:.98,miss:.12,upOff:0,reward:1},{n:"DIF\xCDCIL",k:1.03,miss:.05,upOff:1,reward:1.3}],Ky=[{id:"motor",name:"MOTOR",desc:"Mais velocidade m\xE1xima"},{id:"acel",name:"M\xDASCULOS",desc:"Arranca e acelera mais r\xE1pido"},{id:"grip",name:"GARRAS",desc:"Mais ader\xEAncia nas curvas e no drift"},{id:"nitro",name:"TANQUE DE NITRO",desc:"Nitro dura mais e empurra mais forte"},{id:"pulo",name:"MOLAS",desc:"Pula mais alto e mais longe"}],dd=[150,280,450,700,1e3],jy=2.6,Qy=30,tv=1;function Za(n){return ft.up[n.id]||(ft.up[n.id]={motor:0,acel:0,grip:0,nitro:0,pulo:0})}function ev(n,t){return{maxV:30+n.spd*1.8+t.motor*1.4,accel:9+n.acc*2.4+t.acel*1.9,grip:5.5+n.han*.8+t.grip*.7,turn:1.5+n.han*.06+t.grip*.05,jumpV:9.6+n.jmp*.75+t.pulo*.5,nitroDrain:30*(1-t.nitro*.09),nitroPow:1.3+t.nitro*.03}}var nv={throttle:0,brake:!1,steer:0,drift:!1,nitro:!1,jump:!1,bark:!1,fire:!1},$l=class{constructor(t,e,i,s){this.b=t,this.num=e,this.isPlayer=i,this.D=rd(t,e,t.color),Ke.add(this.D.root),Object.assign(this,ev(t,s)),this.skill=i?1:gs[ft.diff].k*(.98+Math.random()*.04),this.x=0,this.z=0,this.h=0,this.vx=0,this.vz=0,this.y=0,this.vy=0,this.yawRate=0,this.s=0,this.idx=0,this.dist=0,this.d=0,this.speed=0,this.slide=0,this.nitro=30,this.nitroOn=!1,this.drifting=!1,this.driftDir=0,this.driftT=0,this.mini=0,this.pad=0,this.stun=0,this.spook=0,this.barkCD=2,this.slip=0,this.surf=null,this.phase=Math.random()*6,this.lastStep=0,this.finished=!1,this.finishTime=0,this.lastLap=1,this.prevJump=!1,this.prevBark=!1,this.air=!1,this.rampAir=!1,this.ammo=1,this.fireCD=0,this.prevFire=!1,this.missHits=0,this.flip=0,this.lockT=0,this.lane=(Math.random()-.5)*8,this.laneT=1+Math.random()*3,this.aiNitro=!1,this.jumpPlan=new Map,this.minis=0,this.scared=0,this.cleanJumps=0,this.cans=0,this.hits=0,this.birdT=0,this.hitCD=0,this.driftScore=0,this.coins=0,this.lapStart=0,this.bestLap=0,this.pressT=null,this.wrongT=0}get lap(){return de(Math.floor(this.dist/Ae)+1,1,ft.laps)}place(t,e){this.dist=t,this.s=qa(t),this.idx=Math.round(this.s/Ae*Be)%Be;let i=Fe(t,e);this.x=i.x,this.z=i.z,this.d=e,this.h=Jn(t)}dispose(){Ke.remove(this.D.root),ro(this.D.root)}},ue=[],ct=null,en=null,dn=null;function iv(n){let t=n.idx,e=1/0;for(let l=-40;l<=40;l++){let h=(n.idx+l+Be)%Be,u=n.x-He[h].x,f=n.z-He[h].z,d=u*u+f*f;d<e&&(e=d,t=h)}n.idx=t;let i=He[t],s=Gn[t],r=ms[t],a=n.x-i.x,o=n.z-i.z,c=qa(t*Ae/Be+a*s.x+o*s.z);n.d=a*r.x+o*r.z,n.dist+=gn(c-n.s),n.s=c}function as(n,t){if(!n.drifting||(n.drifting=!1,t))return;let e=n.driftT>2?2:n.driftT>.9?1:0,i=Math.round(n.driftT*140);n.driftScore+=i,e&&(n.minis++,n.mini=e===2?1.5:.8,n.nitro=Math.min(100,n.nitro+e*8),n.isPlayer&&(Se(e===2?"SUPER MINI-TURBO!":"MINI-TURBO!",e===2?"o":"c"),Nt.boost())),n.isPlayer&&i>60&&Se(`DRIFT +${i}`,"g")}var sv=n=>n.voice==="hiss"?"CHIADO!":n.voice==="grunt"?"RONCO!":"LATIDO!",rv=n=>n.voice==="hiss"?"SSSSSS!":n.voice==="grunt"?"OINC OINC!":"AU AU!";function ov(n){n.barkCD=6;let t=Math.sin(n.h),e=Math.cos(n.h);Nt.voice(n.b,ct?de(1-Math.hypot(n.x-ct.x,n.z-ct.z)/60,0,1):1);let i=0;for(let a of ue){if(a===n||a.stun>0)continue;let o=a.x-n.x,c=a.z-n.z;Math.hypot(o,c)<12&&o*t+c*e>-2&&(a.spook=1.1,i++,a.isPlayer&&Se("ASSUSTADO!","r"))}let s=0;for(let a of fs)a.state!=="approach"&&a.state!=="harass"||Math.hypot(a.pos.x-n.x,a.pos.z-n.z)<15&&(Ua(a,n),s++);s&&(n.scared+=s,n.nitro=Math.min(100,n.nitro+10*s),n.isPlayer&&Se(`ESPANTOU ${s>1?s+" "+Fi().plural:"O "+Fi().name}! +NITRO`,"v"));let r=n.D.head.getWorldPosition(te);for(let a=0;a<26;a++){let o=a/26*6.28;vi.spawn(r.x,r.y,r.z,Math.cos(o)*14,.5,Math.sin(o)*14,.45,.5,1.4,[1,.85,.4],.8,0,3)}n.isPlayer&&!s&&Se(i?`${sv(n.b)} ${i} ASSUSTADO${i>1?"S":""}`:rv(n.b),"g")}function Zl(n,t,e){let i=n.dist,s=n.y>.02;n.stun>0&&(n.stun-=e,t=nv),n.spook>0&&(n.spook-=e,t={...t,nitro:!1,steer:de(t.steer+Math.sin(Un*16+n.num)*.7,-1,1)});let r=t.jump&&!n.prevJump;n.prevJump=t.jump;let a=t.bark&&!n.prevBark;n.prevBark=t.bark,n.barkCD-=e,a&&n.barkCD<=0&&ov(n);let o=t.fire&&!n.prevFire;n.prevFire=t.fire,n.fireCD-=e,n.flip=Math.max(0,n.flip-e),o&&lv(n);let c=Math.abs(n.d)>Ut/2+.4,l=n.grip*At.grip*(c?.8:1),h=c?.62:1;!s&&n.surf==="mud"?(l*=.5,h*=.62):!s&&n.surf==="water"?(l*=.8,h*=.72):!s&&n.surf==="ice"&&(l*=.22),n.hitCD=Math.max(0,n.hitCD-e),n.birdT>0&&(n.birdT-=e,t={...t,steer:de(t.steer+Math.sin(Un*11+n.num*2)*.45,-1,1)}),n.nitroOn=t.nitro&&n.nitro>.5&&n.stun<=0,n.nitroOn&&(n.nitro=Math.max(0,n.nitro-n.nitroDrain*e)),n.mini=Math.max(0,n.mini-e),n.pad=Math.max(0,n.pad-e);let u=1;!n.isPlayer&&ct&&!ct.finished&&(u=1+de((ct.dist-n.dist)/220,-.07,.07));let f=n.maxV*n.skill*u*h*(n.nitroOn?n.nitroPow:1)*(n.mini>0?1.15:1)*(n.pad>0?1.22:1)*(n.slip>.5?1.06:1)*(n.spook>0?.72:1)*(n.birdT>0?.7:1)*(n.finished?.5:1),d=n.vx*Math.sin(n.h)+n.vz*Math.cos(n.h),p=Math.max(.45,de(Math.abs(d)/7,0,1))*(1-.3*de(Math.abs(d)/70,0,1));!n.drifting&&t.drift&&t.steer!==0&&d>16&&!s&&n.stun<=0&&(n.drifting=!0,n.driftDir=Math.sign(t.steer),n.driftT=0),n.drifting&&(!t.drift||d<10)&&as(n,!1);let x;n.drifting?(n.driftT+=e,x=-n.driftDir*n.turn*p*(.8+.5*t.steer*n.driftDir),n.nitro=Math.min(100,n.nitro+8*e)):x=-t.steer*n.turn*p*(d<-1?-1:1),s&&(x*=.35),n.yawRate=Ne(n.yawRate,x,1-Math.exp(-(n.drifting?6:12)*e)),n.h+=n.yawRate*e;let g=Math.abs(n.d)>Ut/2+1.6;if(n.isPlayer&&!n.drifting&&!s&&(ft.assist&&!t.steer&&d>3||g)){let v=Fe(n.dist+8+d*.35,de(n.d,-Ut/2+2,Ut/2-2)),N=Bl(Math.atan2(v.x-n.x,v.z-n.z)-n.h);n.h+=de(N,-1,1)*(g?3:1.8)*e}let m=Math.sin(n.h),S=Math.cos(n.h),_=-S,b=m;d=n.vx*m+n.vz*S;let C=n.vx*_+n.vz*b;if(s)C*=Math.exp(-.4*e);else if(t.throttle>0&&d<f&&(d+=(n.accel*(n.nitroOn?1.7:1)*t.throttle*(1-.55*de(d/f,0,1))+(n.mini>0?14:0)+(n.pad>.6?30:0))*e),t.throttle||(d-=Math.sign(d)*Math.min(Math.abs(d),7*e)),t.brake&&(d=d>0?Math.max(0,d-38*e):Math.max(-9,d-12*e)),t.drift&&!n.drifting&&d>4&&(d-=10*e),d>f&&(d=Math.max(f,d-(d-f)*2.2*e-2*e)),n.drifting){let v=d*d+C*C;C*=Math.exp(-(2.6+n.grip*.1)*e),d=Math.max(d,Math.sqrt(Math.max(0,v*(1-.12*e)-C*C)))}else C*=Math.exp(-l*e);if(n.vx=m*d+_*C,n.vz=S*d+b*C,n.x+=n.vx*e,n.z+=n.vz*e,n.speed=d,n.slide=C,r&&!s&&n.stun<=0&&(n.vy=n.jumpV,n.isPlayer&&Nt.jump(),n.drifting&&as(n,!1)),n.vy-=Qy*e,n.y+=n.vy*e,n.y<=0){if(s){n.isPlayer&&n.vy<-8&&(Nt.land(),di(.12)),n.rampAir&&(n.rampAir=!1,n.nitro=Math.min(100,n.nitro+12),n.isPlayer&&Se("SALTO! +NITRO","c"));for(let v=0;v<10;v++)pd(n,1.4)}n.y=0,n.vy=0}n.air=n.y>.02;let A=de(Math.abs(d)/12,0,1);n.phase+=e*(A>.02?4+Math.abs(d)*.33:0),iv(n);let R=Ut/2+2.1;if(Math.abs(n.d)>R){let v=Math.sign(n.d),N=dr(n.s),B=Math.abs(n.d)-R;n.x-=N.r.x*v*B,n.z-=N.r.z*v*B,n.d=v*R;let rt=(n.vx*N.r.x+n.vz*N.r.z)*v;if(rt>0){n.vx-=N.r.x*v*rt*1.3,n.vz-=N.r.z*v*rt*1.3,n.vx*=.95,n.vz*=.95;let P=Math.sin(n.h)*N.t.x+Math.cos(n.h)*N.t.z>=0?1:-1;n.h+=Bl(Math.atan2(N.t.x*P,N.t.z*P)-n.h)*.3,n.isPlayer&&rt>6&&(di(.3),Nt.thud()),rt>8&&as(n,!0)}}let F=n.s;for(let v of zi)Math.floor((i-v.s)/Ae)<Math.floor((n.dist-v.s)/Ae)&&Math.abs(n.d)<Ut/2+.6&&(n.y<.55&&n.stun<=0?(n.stun=1,n.vx*=.25,n.vz*=.25,n.vy=3,v.fall=1,as(n,!0),n.nitroOn=!1,n.hits++,n.isPlayer&&(Nt.trip(),Se("TROPE\xC7OU!","r"),di(.4))):n.y>=.55&&(n.nitro=Math.min(100,n.nitro+10),n.cleanJumps++,n.isPlayer&&Se("PULO LIMPO! +NITRO","v")));for(let v of Vl)Math.floor((i-v.s)/Ae)<Math.floor((n.dist-v.s)/Ae)&&Math.abs(n.d)<Ut/2&&n.y<.4&&(n.vy=9+Math.max(0,d)*.13,n.y=1.1,n.rampAir=!0,n.isPlayer&&(Nt.jump(),di(.15)));for(let v of ka)n.pad>.5||n.y>.5||Math.abs(gn(F-v.s))<3.5&&Math.abs(n.d-v.d)<2.2&&(n.pad=1.1,n.isPlayer&&(Nt.boost(),Se("TURBO!","c"),di(.1)));let E=n.surf;if(n.surf=null,!n.air)for(let v of Ga){let N=gn(F-v.s)/1.4,B=(n.d-v.d)/.8;N*N+B*B<v.r*v.r&&(n.surf=v.type)}if(n.isPlayer&&n.surf&&n.surf!==E&&(n.surf==="ice"?Se("GELO!","c"):(Nt.splash(),Se(n.surf==="mud"?"LAMA!":"SPLASH!","r"))),n.surf&&n.surf!=="ice"&&Math.abs(d)>6&&Math.random()<.6){let v=n.surf==="mud"?[.25,.15,.07]:[.75,.88,1];Mi.spawn(n.x,.3,n.z,(Math.random()-.5)*6,3+Math.random()*3,(Math.random()-.5)*6,.6,.3,.6,v,.9,14,1)}for(let v of cr)!v.active||n.hitCD>0||n.stun>0||n.y>v.r*1.25||Math.abs(gn(F-v.s))<v.r+.7&&Math.abs(n.d-v.d)<v.r+.8&&(n.stun=.9,n.hitCD=2,n.vx*=.3,n.vz*=.3,n.vy=5,n.hits++,as(n,!0),n.isPlayer&&(Nt.thud(),Nt.trip(),di(.5),Se(v.hitMsg,"r")));for(let v of ar){if(v.cd>0||n.y>2.4)continue;let N=gn(F-v.s),B=n.d-v.d;N*N+B*B<3.2&&(v.cd=8,v.g.visible=!1,n.nitro=Math.min(100,n.nitro+35),n.cans++,n.isPlayer&&(Nt.pickup(),Se("NITRO +35","c")))}for(let v of ao){if(v.cd>0||n.y>2.4||n.ammo>=3)continue;let N=gn(F-v.s),B=n.d-v.d;N*N+B*B<3.4&&(v.cd=9,v.g.visible=!1,n.ammo++,n.isPlayer&&(Nt.reload(),Se(`M\xCDSSIL +1 (${n.ammo}/3)`,"o")))}if(n.isPlayer)for(let v of io){if(v.taken||n.y>2.6)continue;let N=gn(F-v.s),B=n.d-v.d;N*N+B*B<3.4&&(v.taken=!0,v.g.visible=!1,n.coins++,Nt.coin())}if(!n.finished&&n.dist>=ft.laps*Ae){n.finished=!0,n.finishTime=Vn;let v=Vn-n.lapStart;(!n.bestLap||v<n.bestLap)&&(n.bestLap=v),as(n,!1),n.isPlayer&&dv()}else if(!n.finished&&n.lap>n.lastLap){let v=Vn-n.lapStart;(!n.bestLap||v<n.bestLap)&&(n.bestLap=v),n.lapStart=Vn,n.lastLap=n.lap,n.isPlayer&&(Nt.lap(),dh(n.lap===ft.laps?"\xDALTIMA VOLTA":`VOLTA ${n.lap}`,1400,`melhor volta ${hr(n.bestLap)}`))}if(n.isPlayer&&!n.air&&A>.1){let v=Math.floor(n.phase/Math.PI);v!==n.lastStep&&(n.lastStep=v,Nt.paw(A,At.surface))}}function pd(n,t=1){let e=At.surface==="snow"?[.92,.95,1]:At.surface==="sand"?[.85,.75,.55]:[.55,.4,.27],i=n.x-Math.sin(n.h)*1.2,s=n.z-Math.cos(n.h)*1.2;Mi.spawn(i+(Math.random()-.5)*1.2,.2,s+(Math.random()-.5)*1.2,(Math.random()-.5)*3*t-n.vx*.05,(.8+Math.random()*1.5)*t,(Math.random()-.5)*3*t-n.vz*.05,.9+Math.random()*.6,.6*t,2.4*t,e,.45,-.5,1.5)}function av(n,t){let e=Math.hypot(n.vx,n.vz);if(!n.air&&e>8&&Math.random()<t*e*(n.drifting?1.6:.5)*(ft.qual===0?.5:1)&&pd(n,n.drifting?1.3:1),n.drifting&&!n.air){let i=n.driftT>2?2:n.driftT>.9?1:0,s=i===2?[1,.35,.9]:i===1?[.3,.8,1]:[1,.85,.4];for(let r of[-1,1]){let a=n.x-Math.sin(n.h)*1+Math.cos(n.h)*r*.3,o=n.z-Math.cos(n.h)*1-Math.sin(n.h)*r*.3;vi.spawn(a,.15,o,(Math.random()-.5)*5-n.vx*.1,2+Math.random()*3,(Math.random()-.5)*5-n.vz*.1,.35,i?.35:.22,.05,s,1,12,1)}}if(n.nitroOn)for(let i of n.D.flames){let s=i.getWorldPosition(te);vi.spawn(s.x,s.y,s.z,-Math.sin(n.h)*8+(Math.random()-.5),Math.random()-.5,-Math.cos(n.h)*8+(Math.random()-.5),.25,.45,.1,Math.random()<.5?[1,.5,.15]:[.35,.75,1],1,0,2)}if(n.mini>0||n.pad>0){let i=n.D.body.getWorldPosition(te);vi.spawn(i.x,i.y+.4,i.z,-n.vx*.3,.5,-n.vz*.3,.3,.8,.2,n.pad>0?[.3,.85,1]:[1,.55,.2],.7,0,1)}}function Jl(n,t){let e=n.s;n.laneT-=t,n.laneT<=0&&(n.lane=(Math.random()-.5)*10,n.laneT=2+Math.random()*3);let i=n.lane;if(n.nitro<60)for(let p of ar){let x=gn(p.s-e);if(p.cd<=0&&x>0&&x<40){i=p.d;break}}for(let p of ka){let x=gn(p.s-e);if(x>0&&x<35){i=p.d;break}}for(let p of Ga){let x=gn(p.s-e);x>-3&&x<30&&Math.abs(i-p.d)<p.r+2&&(i=p.d+(i>=p.d?1:-1)*(p.r+2.6))}for(let p of ue){if(p===n)continue;let x=gn(p.dist-n.dist);x>0&&x<6&&Math.abs(p.d-n.d)<2.2&&(i+=n.d>=p.d?2.6:-2.6)}i=de(i,-Ut/2+1.5,Ut/2-1.5);let s=7+Math.max(0,n.speed)*.42,r=Fe(n.dist+s,i),a=Bl(Math.atan2(r.x-n.x,r.z-n.z)-n.h),o=de(-a*2.6,-1,1),l=1-Gn[n.idx].dot(Gn[(n.idx+40)%Be])>.2&&n.speed>n.maxV*.9?.4:1,h=!1;for(let p=0;p<zi.length;p++){let x=gn(zi[p].s-e),g=p+":"+Math.floor((n.dist-zi[p].s)/Ae);n.jumpPlan.has(g)||n.jumpPlan.set(g,Math.random()<gs[ft.diff].miss?-1:.2+Math.random()*.14);let m=n.jumpPlan.get(g);m>0&&x>0&&x<n.speed*m+1&&(h=!0)}let u=Gn[n.idx].dot(Gn[(n.idx+80)%Be])>.94;u&&n.nitro>35&&(n.aiNitro=!0),(!u||n.nitro<5)&&(n.aiNitro=!1);for(let p of cr){if(!p.active)continue;let x=gn(p.s-e);x>0&&x<n.speed*.3+p.r+1&&Math.abs(p.d-n.d)<p.r+2.5&&Math.random()>gs[ft.diff].miss*t*30&&(h=!0)}let f=n.birdT>0&&n.barkCD<=0&&Math.random()<t*(.8+ft.diff*.8);if(n.barkCD<=0&&Math.random()<t*(.25+ft.diff*.2))for(let p of ue){if(p===n)continue;let x=gn(p.dist-n.dist);x>1&&x<9&&Math.abs(p.d-n.d)<4&&(f=!0)}let d=!1;return n.ammo>0&&n.fireCD<=0&&Vn>4&&Math.random()<t*(.5+ft.diff*.45)&&_d(n)&&(d=!0),{throttle:l,brake:!1,steer:o,drift:!1,nitro:n.aiNitro,jump:h,bark:f,fire:d}}function md(n){for(let t=0;t<ue.length;t++)for(let e=t+1;e<ue.length;e++){let i=ue[t],s=ue[e],r=s.x-i.x,a=s.z-i.z,o=r*r+a*a,c=tv*2;if(o<c*c&&Math.abs(i.y-s.y)<1.2){let l=Math.sqrt(o)||.01,h=r/l,u=a/l,f=(c-l)/2,d=(s.b.mass||1)/((i.b.mass||1)+(s.b.mass||1))*2,p=2-d;i.x-=h*f*d,i.z-=u*f*d,s.x+=h*f*p,s.z+=u*f*p;let x=(s.vx-i.vx)*h+(s.vz-i.vz)*u;if(x<0){let g=i.b.mass||1,m=s.b.mass||1,S=-1.3*x/(1/g+1/m);i.vx-=S/g*h,i.vz-=S/g*u,s.vx+=S/m*h,s.vz+=S/m*u,(i.isPlayer||s.isPlayer)&&-x>5&&(Nt.thud(),di(.2))}}}for(let t of ue){let e=Math.sin(t.h),i=Math.cos(t.h),s=!1;for(let r of ue){if(r===t||r.speed<15)continue;let a=r.x-t.x,o=r.z-t.z,c=a*e+o*i,l=Math.abs(a*i-o*e);if(c>2.5&&c<14&&l<1.8){s=!0;break}}t.slip=s?t.slip+n:0,t.slip>.5&&(t.nitro=Math.min(100,t.nitro+5*n))}}var ds=[],lr=[],ao=[];function gd(){let n=new wt,t=new It(new Jt(.14,.14,.9,14),mt(15658734,.35,.5));t.rotation.x=Math.PI/2,n.add(t);let e=new It(new tn(.14,.34,14),Ba);e.rotation.x=Math.PI/2,e.position.z=.62,n.add(e);let i=new It(new Jt(.145,.145,.1,14),rh);i.rotation.x=Math.PI/2,i.position.z=.2,n.add(i);for(let r=0;r<4;r++){let a=new It(new ge(.02,.3,.22),Ba);a.rotation.z=r*Math.PI/2,a.position.z=-.38,a.translateY(.15),n.add(a)}let s=new It(new tn(.12,.6,10),new Pn({color:16752704,transparent:!0,opacity:.9,blending:Ui,depthWrite:!1}));return s.rotation.x=-Math.PI/2,s.position.z=-.75,n.add(s),n.traverse(r=>{r.isMesh&&(r.castShadow=!0)}),n.visible=!1,n}function cv(){lr=[],ds=[];for(let n=0;n<10;n++){let t=gd();be.add(t),lr.push(t)}}function xd(){for(let n of ds)n.mesh.visible=!1,lr.push(n.mesh);ds=[];for(let n of ue)n.lockT=0}function _d(n){let t=Math.sin(n.h),e=Math.cos(n.h),i=null,s=95;for(let r of ue){if(r===n||r.finished)continue;let a=r.x-n.x,o=r.z-n.z,c=Math.hypot(a,o);c<s&&c>2&&(a*t+o*e)/c>.55&&(s=c,i=r)}return i}function lv(n){if(n.ammo<=0||n.fireCD>0||n.stun>0||!lr.length){n.isPlayer&&n.ammo<=0&&Se("SEM M\xCDSSEIS! PEGUE AS CAIXAS","r");return}n.ammo--,n.fireCD=.7;let t=lr.pop(),e=n.D.launcher.muzzle.getWorldPosition(new L),i=_d(n),s=Math.sin(n.h),r=Math.cos(n.h),a=Math.max(0,n.speed)+38;t.visible=!0,t.position.copy(e),ds.push({mesh:t,pos:e,vel:new L(s*a,3,r*a),owner:n,target:i,t:0});let o=ct?de(1-Math.hypot(n.x-ct.x,n.z-ct.z)/70,0,1):1;Nt.launch(o);for(let c=0;c<12;c++)Mi.spawn(e.x,e.y,e.z,(Math.random()-.5)*4-s*6,Math.random()*2,(Math.random()-.5)*4-r*6,.8,.5,1.6,[.8,.8,.8],.6,-1,2);n.isPlayer&&Se(i?`M\xCDSSIL NO ${i.b.name}!`:"M\xCDSSIL!","o"),i&&i.isPlayer&&(Se(`${n.b.name} ATIROU EM VOC\xCA!`,"r"),Nt.lockon())}var Fl=new L;function yd(n){for(let t=ds.length-1;t>=0;t--){let e=ds[t];e.t+=n;let i=e.target&&!e.target.finished?e.target:null,s=Math.max(62,e.vel.length());i?(Fl.set(i.x,1.1+i.y,i.z).sub(e.pos).normalize().multiplyScalar(s),e.vel.lerp(Fl,1-Math.exp(-(e.t<.25?1:3.4)*n)),i.isPlayer&&(i.lockT=.3)):e.vel.y+=(1.2-e.pos.y)*n*4,e.vel.setLength(Math.min(s+25*n,80)),e.pos.addScaledVector(e.vel,n),e.pos.y<.5&&(e.pos.y=.5,e.vel.y=Math.abs(e.vel.y)*.3),e.mesh.position.copy(e.pos),e.mesh.lookAt(Fl.copy(e.pos).add(e.vel)),vi.spawn(e.pos.x,e.pos.y,e.pos.z,-e.vel.x*.05,.3,-e.vel.z*.05,.25,.7,.2,Math.random()<.5?[1,.6,.2]:[1,.9,.5],1,0,2),Math.random()<.7&&Mi.spawn(e.pos.x,e.pos.y,e.pos.z,Math.random()-.5,Math.random(),Math.random()-.5,1.2,.5,2.2,[.75,.75,.78],.45,-.6,1.5);let r=null;for(let a of ue)if(!(a===e.owner&&e.t<1.5)&&Math.hypot(a.x-e.pos.x,a.z-e.pos.z)<1.8&&Math.abs(a.y+1-e.pos.y)<1.8){r=a;break}(r||e.t>3.2)&&(hv(e,r),ds.splice(t,1))}}function hv(n,t){n.mesh.visible=!1,lr.push(n.mesh);let e=n.pos;for(let s=0;s<40;s++){let r=Math.random()*6.28,a=Math.random()*10;vi.spawn(e.x,e.y,e.z,Math.cos(r)*a,Math.random()*9,Math.sin(r)*a,.5+Math.random()*.4,1.4,.3,Math.random()<.5?[1,.55,.15]:[1,.85,.3],1,6,2.5)}for(let s=0;s<18;s++)Mi.spawn(e.x,e.y,e.z,(Math.random()-.5)*7,Math.random()*5,(Math.random()-.5)*7,1.6,1.2,3.6,[.3,.28,.27],.7,-1.5,1.8);let i=ct?Math.hypot(e.x-ct.x,e.z-ct.z):0;Nt.boom(de(1-i/90,0,1)),i<25&&di(.6*(1-i/25)),t&&(t.stun=1.4,t.flip=1,t.vx*=.2,t.vz*=.2,t.vy=8,t.nitroOn=!1,t.hits++,as(t,!0),n.owner!==t&&n.owner.missHits++,t.isPlayer&&(Se("ATINGIDO POR UM M\xCDSSIL!","r"),di(.8)),n.owner.isPlayer&&t!==n.owner&&(Se(`ACERTOU ${t.b.name}!`,"v"),n.owner.nitro=Math.min(100,n.owner.nitro+10)))}function eo(n){n.D.root.position.set(n.x,0,n.z),n.D.root.rotation.y=n.h,n.D.launcher.noses.forEach((t,e)=>{t.visible=e<n.ammo}),n.D.model.rotation.x=n.flip>0?-(1-n.flip)*Math.PI*2:0,n.D.model.position.y=n.y,n.D.anim(n.D,{v:Math.hypot(n.vx,n.vz),y:n.y,vy:n.vy,phase:n.phase,yawRate:n.yawRate,stun:n.stun,spook:n.spook,nitro:n.nitroOn,idle:!1},Un+n.num)}var fh=["ATR\xC1S","ALTA","CACHORRO"],fi=new L(0,0,1),zl=new L,pi=new L,sr=0;function di(n){sr=Math.max(sr,n)}function Kl(n,t,e=!1){let i=Math.hypot(n.vx,n.vz),s=Math.sin(n.h),r=Math.cos(n.h);if(i>4&&(s=s*.55+n.vx/i*.45,r=r*.55+n.vz/i*.45),pi.set(s,0,r).normalize(),fi.lerp(pi,e?1:1-Math.exp(-4.5*t)).normalize(),ft.cam===2){let o=n.D.head.getWorldPosition(pi);he.position.set(o.x-fi.x*.3,o.y+.55,o.z-fi.z*.3),zl.set(n.x+fi.x*25,1.2+n.y*.3,n.z+fi.z*25)}else{let o=(ft.cam?11.5:6.6)+i*.025,c=ft.cam?6:2.7;pi.set(n.x-fi.x*o,c+n.y*.5,n.z-fi.z*o),he.position.lerp(pi,e?1:1-Math.exp(-8*t)),zl.set(n.x+fi.x*5,1.3+n.y*.6,n.z+fi.z*5)}sr>.001&&(he.position.x+=(Math.random()-.5)*sr,he.position.y+=(Math.random()-.5)*sr,sr*=Math.exp(-7*t)),he.lookAt(zl);let a=64+i*.18+(n.nitroOn?10:0)+(n.pad>0||n.mini>0?5:0);he.fov=Ne(he.fov,a,1-Math.exp(-3*t)),he.updateProjectionMatrix()}var qt="loading",Vn=0,no=0,_i=0,jl=-1,Hf="race",Un=0,nr=0,hr=n=>{let t=Math.floor(n/60),e=Math.floor(n%60),i=Math.floor(n*100%100);return`${t}:${String(e).padStart(2,"0")}.${String(i).padStart(2,"0")}`};function Se(n,t=""){let e=document.createElement("div");e.className="pop "+t,e.textContent=n;let i=zt("pops");for(i.appendChild(e);i.children.length>3;)i.firstChild.remove();setTimeout(()=>e.remove(),1300)}var kf=null;function dh(n,t=1200,e=""){let i=zt("big");i.innerHTML=n+(e?`<small>${e}</small>`:""),i.classList.remove("pop"),i.offsetWidth,i.classList.add("pop"),clearTimeout(kf),t&&(kf=setTimeout(()=>{i.innerHTML=""},t))}function nn(n,t){zt(n).hidden=!t}function ph(){document.querySelectorAll(".cval").forEach(n=>n.textContent=ft.coins.toLocaleString("pt-BR"))}function Ja(){en&&(Ke.remove(en.root),ro(en.root));let n=jn[ft.dog];en=rd(n,1,n.color),Ke.add(en.root);let t=Fe(22,0);if(!dn||dn.parent!==be){dn=new wt,St(new Jt(3.2,3.4,.3,48),mt(2764600,.3,.8),!0,!0,dn).position.y=.15;let e=St(new $r(3.3,.06,8,64),mt(16742938,.3,0,{emissive:16742938,emissiveIntensity:1.5}),!1,!1,dn);e.rotation.x=Math.PI/2,e.position.y=.3,be.add(dn)}dn.position.copy(t),en.root.position.set(t.x,.3,t.z)}function uo(){let n=jn[ft.dog],t=Za(n);zt("dogName").textContent=n.name,zt("dogBreed").textContent=n.raca;let e=[["VELOCIDADE",n.spd,t.motor],["ACELERA\xC7\xC3O",n.acc,t.acel],["CURVAS",n.han,t.grip],["PULO",n.jmp,t.pulo]];zt("stats").innerHTML=e.map(([i,s,r])=>`<div class="stat"><span>${i}</span><div class="cells">${Array.from({length:10},(a,o)=>`<span class="${o<s?"b":o<s+r?"u":""}"></span>`).join("")}</div></div>`).join(""),zt("trackName").textContent=xs[ft.track].name.split(" ")[0],zt("diffName").textContent=gs[ft.diff].n,zt("lapsName").textContent=ft.laps,ph()}function vd(){let n=jn[ft.dog],t=Za(n);zt("garageDog").textContent=`${n.name} \xB7 ${n.raca}`,zt("upList").innerHTML=Ky.map(e=>{let i=t[e.id],s=dd[i],r=i>=5;return`<div class="up panel"><h3>${e.name}</h3><p>${e.desc}</p><div class="pips">${[0,1,2,3,4].map(a=>`<span class="${a<i?"on":""}"></span>`).join("")}</div>
      <button data-up="${e.id}" ${r||ft.coins<s?"disabled":""}>${r?"M\xC1XIMO":"MELHORAR<br>"+s}</button></div>`}).join(""),ph()}zt("upList").addEventListener("click",n=>{let t=n.target.closest("button[data-up]");if(!t||t.disabled)return;let e=jn[ft.dog],i=Za(e),s=t.dataset.up,r=dd[i[s]];ft.coins<r||i[s]>=5||(ft.coins-=r,i[s]++,Wn(),Nt.init(),Nt.pickup(),Nt.voice(e,.6),vd())});function ps(){mh(),qt="menu",["hud","results","pause","touch","lights","garage"].forEach(n=>nn(n,!1)),nn("menu",!0),zt("big").innerHTML="",zt("pops").innerHTML="",yh(0,0),Nt.ctx&&["wind","skid","nitro"].forEach(n=>Nt.setLoop(n,0)),Ja(),uo()}function Va(){qt==="results"&&(mh(),Ja()),qt="garage",["menu","results"].forEach(n=>nn(n,!1)),nn("garage",!0),vd()}function mh(){xd(),ue.forEach(n=>n.dispose()),ue=[],ct=null,ld()}function Md(n){ft.track=n,Wn(),nn("loading",!0),requestAnimationFrame(()=>requestAnimationFrame(()=>{od(ft.track),dn=null,Ja(),uo(),nn("loading",!1)}))}function ur(){Nt.init(),mh(),en&&(Ke.remove(en.root),ro(en.root),en=null),dn&&(be.remove(dn),ro(dn),dn=null),he.clearViewOffset();let n=Za(jn[ft.dog]),t=Object.values(n).reduce((r,a)=>r+a,0)/5,e=[ft.dog,...jn.map((r,a)=>a).filter(r=>r!==ft.dog).sort(()=>Math.random()-.5).slice(0,5)],i=[5,...[0,1,2,3,4].sort(()=>Math.random()-.5)];e.forEach((r,a)=>{let o=jn[r],c=n;if(a){let d=()=>de(Math.round(t+gs[ft.diff].upOff+(Math.random()*2-1)),0,5);c={motor:d(),acel:d(),grip:d(),nitro:d(),pulo:d()}}let l=new $l(o,a+1,a===0,c),h=i[a],u=Math.floor(h/2),f=h%2;l.place(-5-u*6.5-f*2.5,f?3.6:-3.6),l.lane=l.d,ue.push(l),a||(ct=l)}),zi.forEach(r=>{r.fall=0,r.bar.rotation.x=0,r.bar.position.y=.95}),ar.forEach(r=>{r.cd=0,r.g.visible=!0}),ao.forEach(r=>{r.cd=0,r.g.visible=!0}),io.forEach(r=>{r.taken=!1,r.g.visible=!0}),xd(),Mi.clear(),vi.clear(),ld(),fv(),zt("goals").classList.remove("mini"),Vn=0,no=4,jl=4,_i=0,qt="countdown",ue.forEach(eo),he.fov=64,Kl(ct,.016,!0),["menu","results","pause","garage"].forEach(r=>nn(r,!1)),nn("hud",!0),nn("lights",!0),ho&&nn("touch",!0),zt("lapT").textContent=ft.laps,zt("posOf").textContent="DE "+ue.length,zt("lights").querySelectorAll("span").forEach(r=>r.className=""),Xl(0,!1);let s=ft.best[At.id+"_"+ft.laps];zt("bestLap").textContent=s?"RECORDE "+hr(s):"",oo=.6}var uv=[{id:"mini",txt:"Fa\xE7a 3 mini-turbos no drift",n:3,v:n=>n.minis},{id:"scare",txt:"Espante 2 bichos com o latido",n:2,v:n=>n.scared},{id:"jumps",txt:"Pule 3 barreiras sem trope\xE7ar",n:3,v:n=>n.cleanJumps},{id:"coins",txt:"Pegue 10 ossos de ouro",n:10,v:n=>n.coins},{id:"cans",txt:"Pegue 3 latas de nitro",n:3,v:n=>n.cans},{id:"missile",txt:"Acerte 2 m\xEDsseis nos rivais",n:2,v:n=>n.missHits},{id:"clean",txt:"Termine sem trope\xE7ar nem ser atingido",final:!0,ok:(n,t)=>n.finished&&n.hits===0,bad:n=>n.hits>0},{id:"podium",txt:"Termine no p\xF3dio",final:!0,ok:(n,t)=>n.finished&&t<=3}],gh=120,Kn=[],Na=0;function fv(){Kn=uv.slice().sort(()=>Math.random()-.5).slice(0,3).map(n=>({g:n,done:!1})),Na=9,xh()}function Ed(n,t){let e=n.g,i=n.done?"\u2713":"",s="";return e.final?e.bad&&e.bad(ct)&&(i="\u2717"):s=`${Math.min(e.v(ct),e.n)}/${e.n}`,`<div class="${n.done?"ok":i==="\u2717"?"no":""}"><i>${i}</i><span>${e.txt}</span><b>${n.done?"+"+gh:s}</b></div>`}function xh(){let n=Kn.map(e=>Ed(e)).join(""),t=Kn.filter(e=>e.done).length;zt("goals").innerHTML=`<div class="gh">DESAFIOS <b>${t}/${Kn.length}</b></div>`+n,zt("pauseGoals").innerHTML=`<div class="gh">DESAFIOS <b>${t}/${Kn.length}</b></div>`+n}function Sd(n){let t=!1;for(let i of Kn)i.done||i.g.final||i.g.v(ct)>=i.g.n&&(i.done=!0,t=!0,Se(`DESAFIO CUMPRIDO! +${gh}`,"g"),Nt.lap(),Na=4);Na-=n;let e=Na>0;zt("goals").classList.toggle("mini",!e),(t||Math.random()<n*4)&&xh()}function _h(){return ue.slice().sort((n,t)=>n.finished&&t.finished?n.finishTime-t.finishTime:n.finished?-1:t.finished?1:t.dist-n.dist)}function dv(){let n=_h().indexOf(ct)+1;qt="finished",_i=0,Nt.fanfare(),oo=1.3,dh(n===1?"VIT\xD3RIA!":"CHEGADA!",3800,`${n}\xBA LUGAR \xB7 ${hr(ct.finishTime)}`),setTimeout(()=>ct&&Nt.voice(ct.b),700)}function bd(){qt="results",zt("big").innerHTML="",["hud","touch","lights"].forEach(u=>nn(u,!1)),yh(0,0),["wind","skid","nitro"].forEach(u=>Nt.setLoop(u,0));let n=_h(),t=n.indexOf(ct)+1;zt("resTitle").textContent=t===1?"CAMPE\xC3O!":t<=3?"P\xD3DIO!":`${t}\xBA LUGAR`,zt("resTable").innerHTML=n.map((u,f)=>`<tr class="${u===ct?"me":""}"><td class="disp">${f+1}\xBA</td><td><i style="background:${u.b.color}"></i></td><td>${u.b.name}${u===ct?" \xB7 VOC\xCA":""}</td><td class="mono">${u.finished?hr(u.finishTime):"\u2014"}</td></tr>`).join("");let e={1:.5,3:1,5:1.5,7:2}[ft.laps]||1,i=Math.round([500,350,250,180,130,100][t-1]*e*gs[ft.diff].reward),s=ct.coins*15,r=Math.round(ct.driftScore/20);for(let u of Kn)u.g.final&&!u.done&&(u.done=u.g.ok(ct,t));let a=Kn.filter(u=>u.done).length,o=a*gh;xh();let c=i+s+r+o;ft.coins+=c,zt("rewards").innerHTML=`<div><span>${t}\xBA lugar</span><b>+${i}</b></div><div><span>Ossos de ouro \xD7 ${ct.coins}</span><b>+${s}</b></div><div><span>Drift (${ct.driftScore} pts)</span><b>+${r}</b></div><div><span>Desafios ${a}/${Kn.length}</span><b>+${o}</b></div><div class="goalsRes">${Kn.map(u=>Ed(u)).join("")}</div><div class="tot"><span>TOTAL</span><b class="disp">+${c}</b></div>`;let l=At.id+"_"+ft.laps,h=ft.best[l];ct.finished&&(!h||ct.finishTime<h)?(ft.best[l]=ct.finishTime,zt("recordMsg").textContent="NOVO RECORDE DA PISTA!"):zt("recordMsg").textContent=h?"RECORDE "+hr(h):"",Wn(),ph(),nn("results",!0)}function fr(n){n&&(qt==="race"||qt==="countdown"||qt==="finished")?(Hf=qt,qt="paused",nn("pause",!0),pr(),Sn.volume=.25,Nt.ctx&&["wind","skid","nitro"].forEach(t=>Nt.setLoop(t,0))):!n&&qt==="paused"&&(qt=Hf,nn("pause",!1),Sn.volume=.6)}function pr(){zt("camBtn").textContent="C\xC2MERA: "+fh[ft.cam],zt("assistBtn").textContent="ASSIST\xCANCIA: "+(ft.assist?"LIGADA":"DESLIGADA"),zt("qualBtn").textContent="GR\xC1FICOS: "+th[ft.qual].n,zt("musicBtn").textContent="M\xDASICA: "+ud[ft.musicMode]}var pv=zt("map").getContext("2d");function mv(){let n=zt("map"),t=Math.min(devicePixelRatio,2),e=Math.round(n.clientWidth*t);n.width!==e&&(n.width=n.height=e);let i=pv;i.setTransform(1,0,0,1,0,0),i.clearRect(0,0,e,e),i.save(),i.scale(e/256,e/256),i.drawImage(Wl.canvas,0,0);for(let s of ue.slice().sort(r=>r.isPlayer?1:-1)){let[r,a]=Wl.f(s.x,s.z),o=s.isPlayer?9:7;i.beginPath(),i.arc(r,a,o,0,7),i.fillStyle="#000",i.fill(),i.beginPath(),i.arc(r,a,o-2.5,0,7),i.fillStyle=s.isPlayer?"#ffffff":s.b.color,i.fill()}i.restore()}var gv=zt("gauge").getContext("2d");function xv(){let n=zt("gauge"),t=Math.min(devicePixelRatio,2),e=Math.round(n.clientWidth*t);n.width!==e&&(n.width=n.height=e);let i=gv;i.setTransform(1,0,0,1,0,0),i.clearRect(0,0,e,e),i.save(),i.scale(e/220,e/220);let s=110,r=112,a=Math.PI*.75,o=Math.PI*2.25;i.fillStyle="rgba(10,14,24,.62)",i.beginPath(),i.arc(s,r,104,0,7),i.fill(),i.strokeStyle="rgba(255,255,255,.16)",i.lineWidth=1,i.stroke();let c=Math.abs(ct.speed)*jy,l=de(c/180,0,1);for(let u=0;u<=9;u++){let f=a+(o-a)*u/9,d=u%3?88:84;i.strokeStyle=u/9<=l?"#fff":"rgba(255,255,255,.35)",i.lineWidth=u%3?2:3,i.beginPath(),i.moveTo(s+Math.cos(f)*94,r+Math.sin(f)*94),i.lineTo(s+Math.cos(f)*d,r+Math.sin(f)*d),i.stroke()}i.lineCap="round",i.lineWidth=10,i.strokeStyle="rgba(255,255,255,.1)",i.beginPath(),i.arc(s,r,76,a,o),i.stroke();let h=i.createLinearGradient(20,0,200,0);h.addColorStop(0,"#ffffff"),h.addColorStop(.7,"#ffb36b"),h.addColorStop(1,"#ff4d1a"),i.strokeStyle=h,i.beginPath(),i.arc(s,r,76,a,a+(o-a)*Math.max(.001,l)),i.stroke(),i.lineWidth=7,i.strokeStyle="rgba(255,255,255,.1)",i.beginPath(),i.arc(s,r,61,a,o),i.stroke(),i.strokeStyle=ct.nitroOn?"#35d0ff":"#ff7a1a",i.beginPath(),i.arc(s,r,61,a,a+(o-a)*Math.max(.001,ct.nitro/100)),i.stroke(),i.fillStyle="#fff",i.textAlign="center",i.font='46px "Russo One", sans-serif',i.fillText(Math.round(c),s,r+12),i.font="700 14px Rajdhani, sans-serif",i.fillStyle="#9aa7bf",i.fillText("KM/H",s,r+32),i.fillStyle=ct.nitro>99?"#35d0ff":"#ff9a4d",i.fillText(`NITRO ${Math.round(ct.nitro)}%`,s,r+52);for(let u=0;u<3;u++){let f=s-24+u*24,d=r+66;i.fillStyle=u<ct.ammo?"#ff4d5e":"rgba(255,255,255,.15)",i.beginPath(),i.moveTo(f,d-9),i.lineTo(f+5,d-3),i.lineTo(f+5,d+8),i.lineTo(f-5,d+8),i.lineTo(f-5,d-3),i.closePath(),i.fill()}if(ct.drifting){let u=ct.driftT>2?2:ct.driftT>.9?1:0;i.fillStyle=["#ffd97a","#35d0ff","#ff5ae0"][u],i.font='17px "Russo One", sans-serif',i.fillText("DRIFT",s,r-34)}else ct.barkCD<=0&&(i.fillStyle="#ffc53d",i.font="700 13px Rajdhani, sans-serif",i.fillText("LATIDO PRONTO",s,r-34));i.restore()}var Gf="";function Vf(n){let t=_h(),e=t.indexOf(ct)+1;zt("lap").textContent=ct.lap,zt("time").textContent=hr(qt==="finished"?ct.finishTime:Vn),zt("pos").innerHTML=e+"<sup>\xBA</sup>";let i=t.map((r,a)=>`<li class="${r.isPlayer?"me":""}"><span class="n">${a+1}</span><i style="background:${r.b.color}"></i>${r.b.name}</li>`).join("");i!==Gf&&(zt("board").innerHTML=i,Gf=i),zt("chipSlip").hidden=!(ct.slip>.5);let s=Gn[ct.idx].x*Math.sin(ct.h)+Gn[ct.idx].z*Math.cos(ct.h)<-.3&&Math.hypot(ct.vx,ct.vz)>3;ct.wrongT=s?ct.wrongT+n:0,zt("chipWrong").hidden=ct.wrongT<1,ct.lockT-=n,zt("chipMissile").hidden=!(ct.lockT>0),ct.lockT>0&&Math.random()<n*6&&Nt.lockon(),zt("tMn").textContent=ct.ammo,mv(),xv()}var Wf=zt("fx"),_v=zt("vig");function yh(n,t){Wf.style.opacity=n,_v.style.opacity=t,n>0&&(Wf.style.transform=`rotate(${Math.random()*6}deg)`)}var co={},lo={left:!1,right:!1,brake:!1,drift:!1,nitro:!1,jump:!1,bark:!1,fire:!1};addEventListener("keydown",n=>{["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space","Enter"].includes(n.code)&&n.preventDefault(),co[n.code]=!0,!n.repeat&&(Nt.init(),qt==="menu"?((n.code==="ArrowLeft"||n.code==="KeyA")&&Wa(-1),(n.code==="ArrowRight"||n.code==="KeyD")&&Wa(1),(n.code==="Enter"||n.code==="Space")&&ur(),n.code==="KeyG"&&Va(),n.code==="KeyT"&&Md((ft.track+1)%xs.length)):qt==="garage"?(n.code==="Escape"||n.code==="Enter")&&ps():qt==="results"?((n.code==="Enter"||n.code==="Space")&&ur(),n.code==="Escape"&&ps(),n.code==="KeyG"&&Va()):qt==="paused"?((n.code==="Escape"||n.code==="KeyP")&&fr(!1),n.code==="KeyQ"&&ps()):(qt==="race"||qt==="countdown"||qt==="finished")&&(n.code==="Escape"||n.code==="KeyP")&&fr(!0),n.code==="KeyC"&&(ft.cam=(ft.cam+1)%fh.length,Wn()),n.code==="KeyM"&&(fd(),qt==="paused"&&pr()))});addEventListener("keyup",n=>{co[n.code]=!1});addEventListener("blur",()=>{for(let n in co)co[n]=!1;for(let n in lo)lo[n]=!1;fr(!0)});document.addEventListener("visibilitychange",()=>{document.hidden&&fr(!0)});function Bi(n,t){let e=zt(n),i=r=>{r.preventDefault(),Nt.init(),lo[t]=!0,e.classList.add("on");try{e.setPointerCapture(r.pointerId)}catch{}},s=r=>{r.preventDefault(),lo[t]=!1,e.classList.remove("on")};e.addEventListener("pointerdown",i),e.addEventListener("pointerup",s),e.addEventListener("pointercancel",s),e.addEventListener("contextmenu",r=>r.preventDefault())}Bi("tL","left");Bi("tR","right");Bi("tS","brake");Bi("tD","drift");Bi("tN","nitro");Bi("tJ","jump");Bi("tB","bark");Bi("tM","fire");var Xe=(n,t)=>zt(n).addEventListener("click",e=>{e.stopPropagation(),e.currentTarget.blur(),Nt.init(),t()});function Wa(n){ft.dog=(ft.dog+n+jn.length)%jn.length,Wn(),Ja(),uo(),Nt.voice(jn[ft.dog],.8)}Xe("prevDog",()=>Wa(-1));Xe("nextDog",()=>Wa(1));Xe("trackBtn",()=>Md((ft.track+1)%xs.length));Xe("diffBtn",()=>{ft.diff=(ft.diff+1)%gs.length,Wn(),uo(),Nt.beep(!1)});Xe("lapsBtn",()=>{ft.laps=ft.laps>=7?1:ft.laps+2,Wn(),uo(),Nt.beep(!1)});Xe("garageBtn",Va);Xe("garageBack",ps);Xe("startBtn",ur);Xe("pauseBtn",()=>fr(!0));Xe("resumeBtn",()=>fr(!1));Xe("restartBtn",()=>{nn("pause",!1),ur()});Xe("quitBtn",ps);Xe("camBtn",()=>{ft.cam=(ft.cam+1)%fh.length,Wn(),pr()});Xe("assistBtn",()=>{ft.assist=!ft.assist,Wn(),pr()});Xe("qualBtn",()=>{ft.qual=(ft.qual+1)%th.length,Wn(),$f(),pr()});Xe("musicBtn",()=>{fd(),pr()});Xe("resAgain",ur);Xe("resMenu",ps);Xe("resGarage",Va);function Xf(){let n=co,t=lo,e=n.ArrowLeft||n.KeyA||t.left,i=n.ArrowRight||n.KeyD||t.right,s=!!(n.ArrowDown||n.KeyS||t.brake);return{throttle:n.ArrowUp||n.KeyW||ho&&!s?1:0,brake:s,steer:(i?1:0)-(e?1:0),drift:!!(n.ShiftLeft||n.ShiftRight||t.drift),nitro:!!(n.KeyN||n.ControlLeft||n.ControlRight||t.nitro),jump:!!(n.Space||t.jump),bark:!!(n.KeyB||n.KeyE||t.bark),fire:!!(n.KeyF||n.KeyX||t.fire)}}var yv=new wa;function Td(){requestAnimationFrame(Td);let n=Math.min(yv.getDelta(),.05);if(Un+=n,qt!=="paused"){for(let e of hh)e.position.x+=n*2,e.position.x>950&&(e.position.x=-950);for(let e of ao)e.g.rotation.y+=n*1.5,e.g.position.y=1.1+Math.sin(Un*3+e.s)*.12,e.cd>0&&(e.cd-=n,e.cd<=0&&(e.g.visible=!0));for(let e of ar)e.g.rotation.y+=n*2,e.g.position.y=1.3+Math.sin(Un*3+e.s)*.15,e.cd>0&&(e.cd-=n,e.cd<=0&&(e.g.visible=!0));for(let e of io)e.g.rotation.y+=n*3;for(let e of zi)if(e.fall>0){e.fall=Math.max(0,e.fall-n*.5);let i=Lt(0,.25,1-e.fall)*(e.fall>.1?1:e.fall*10);e.bar.rotation.x=i*1.4,e.bar.position.y=.95-i*.8}if(Qr&&(Qr.offset.y-=n*1.5),uh(Un),cd(n,qt==="race"),(qt==="race"||qt==="finished"||qt==="results")&&yd(n),or&&(or.offset.x+=n*.01,or.offset.y+=n*.006),Oy(Un),oo=Ne(oo,.35,n*.25),Mi.update(n),vi.update(n),xi){let e=xi.geometry.attributes.position,i=e.array,s=he.position;for(let r=0;r<i.length;r+=3)i[r+1]-=n*(3+r%7*.3),i[r]+=Math.sin(Un+r)*n*.5,i[r+1]<s.y-15&&(i[r+1]+=40),i[r]<s.x-60&&(i[r]+=120),i[r]>s.x+60&&(i[r]-=120),i[r+2]<s.z-60&&(i[r+2]+=120),i[r+2]>s.z+60&&(i[r+2]-=120);e.needsUpdate=!0}}if(qt==="menu"||qt==="garage"){if(nr+=n*.35,en&&dn){dn.rotation.y+=n*.4,en.root.rotation.y=dn.rotation.y,en.anim(en,{v:0,y:0,vy:0,phase:0,yawRate:0,stun:0,spook:0,nitro:!1,idle:!0},Un);let e=en.root.position,i=innerWidth,s=innerHeight,r=s>i*1.05,a=r?8.2:6.4;he.position.set(e.x+Math.cos(nr*.4)*a,2.4,e.z+Math.sin(nr*.4)*a),he.lookAt(e.x,1.1,e.z),he.fov=50,r?he.setViewOffset(i,s,0,s*.14,i,s):i>820?he.setViewOffset(i,s,Math.min(220,i*.18),0,i,s):he.clearViewOffset(),he.updateProjectionMatrix()}}else if(qt==="countdown"){no-=n;let e=Math.ceil(no-1);if(!ho){let i=Xf();i.throttle&&ct.pressT===null&&(ct.pressT=no),i.throttle||(ct.pressT=null)}if(e!==jl){jl=e;let i=zt("lights").querySelectorAll("span");e>0&&e<=3&&(i[3-e].className="r",Xl(4-e,!1),Nt.beep(!1)),e<=0&&(i.forEach(s=>s.className="g"),Xl(3,!0),Nt.beep(!0),dh("VAI!",900),qt="race",setTimeout(()=>nn("lights",!1),900),ct.pressT!==null&&(ct.pressT<=.6?(ct.mini=1.2,Se("LARGADA PERFEITA!","v"),Nt.boost()):ct.pressT>1.4&&(ct.stun=.7,Se("QUEIMOU A LARGADA!","r"))),ue.forEach(s=>{!s.isPlayer&&Math.random()<.35&&(s.mini=.8)}))}ue.forEach(eo),Kl(ct,n),Vf(n)}else if(qt==="race"||qt==="finished"){Vn+=n;for(let e of ue)Zl(e,e.isPlayer&&!e.finished?Xf():Jl(e,n),n);md(n);for(let e of ue)eo(e),av(e,n);if(qt==="finished"){_i+=n;let e=ct.D.root.position,i=_i*.45+ct.h+Math.PI;pi.set(e.x+Math.sin(i)*8,3.2,e.z+Math.cos(i)*8),he.position.lerp(pi,1-Math.exp(-3*n)),he.lookAt(e.x,1.3+ct.y,e.z),(_i>7||_i>3.5&&ue.every(s=>s.finished))&&bd()}else Kl(ct,n);if(qt!=="results"){Vf(n),Sd(n);let e=Math.hypot(ct.vx,ct.vz);yh(ct.nitroOn?.55:ct.pad>0||ct.mini>0?.3:de((e-40)/40,0,.18),ct.nitroOn?1:0),Nt.ctx&&(Nt.setLoop("wind",de(e/60,0,1)*.12,700+e*30),Nt.setLoop("skid",ct.drifting&&!ct.air?.16:ct.surf==="ice"&&Math.abs(ct.slide)>3?.08:0),Nt.setLoop("nitro",ct.nitroOn?.3:0))}}else if(qt==="results"){for(let i of ue)Zl(i,Jl(i,n),n),eo(i);let e=ct.D.root.position;nr+=n*.3,pi.set(e.x+Math.cos(nr)*12,6,e.z+Math.sin(nr)*12),he.position.lerp(pi,1-Math.exp(-2*n)),he.lookAt(e.x,1,e.z)}Xa.position.copy(he.position);let t=ct?ct.D.root.position:en?en.root.position:He[0];pn.target.position.copy(t),pn.position.copy(t).addScaledVector(Hl,150),Nn.render(Ke,he)}$f();od(ft.track);ps();nn("loading",!1);Td();function vv(n,t){let e=.016666666666666666;for(let i=0;i<n&&(qt==="race"||qt==="finished");i+=e){Vn+=e,Un+=e,uh(Un),cd(e,qt==="race"),yd(e);for(let s of ue)Zl(s,s.isPlayer&&!s.finished?t(ct,Vn):Jl(s,e),e);md(e),qt==="race"&&Sd(e),qt==="finished"&&(_i+=e,(_i>7||_i>3.5&&ue.every(s=>s.finished))&&bd())}ue.forEach(eo)}window.__game={sim:vv,bgm:Sn,debugBall(){let n=cr[0];uh(n.period-n.off+1.4-n.period*50);let t=Fe(n.s-14,-4,3.5),e=Fe(n.s,0,1);he.position.copy(t),he.lookAt(e)},skipCountdown(){no=.01},get state(){return qt},get player(){return ct},get runners(){return ue},startRace:ur,save:ft,renderer:Nn,scene:Ke,camera:he,get L(){return Ae}};})();
/*! Bundled license information:

three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2023 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
