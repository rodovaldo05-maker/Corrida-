(()=>{var eh="160";var Sp=0,uu=1,bp=2;var Xf=1,nh=2,Mi=3,$i=0,fn=1,Fe=2;var Vi=0,Wi=1,qi=2,fu=3,du=4,Tp=5,hs=100,wp=101,Ap=102,pu=103,mu=104,Rp=200,Cp=201,Pp=202,Lp=203,hl=204,ul=205,Ip=206,Dp=207,Up=208,Np=209,Op=210,Fp=211,zp=212,Bp=213,Hp=214,kp=0,Gp=1,Vp=2,uo=3,Wp=4,Xp=5,Yp=6,$p=7,Yf=0,qp=1,Zp=2,Xi=0,Jp=1,Kp=2,jp=3,ih=4,Qp=5,t0=6;var $f=300,or=301,cr=302,fl=303,dl=304,Yo=306,jr=1e3,Kn=1001,pl=1002,nn=1003,gu=1004;var Pc=1005;var Fn=1006,e0=1007;var Qr=1008;var Yi=1009,n0=1010,i0=1011,sh=1012,qf=1013,ki=1014,Gi=1015,ta=1016,Zf=1017,Jf=1018,ds=1020,s0=1021,jn=1023,r0=1024,a0=1025,ps=1026,lr=1027,o0=1028,Kf=1029,c0=1030,jf=1031,Qf=1033,Lc=33776,Ic=33777,Dc=33778,Uc=33779,xu=35840,yu=35841,_u=35842,vu=35843,td=36196,Mu=37492,Eu=37496,Su=37808,bu=37809,Tu=37810,wu=37811,Au=37812,Ru=37813,Cu=37814,Pu=37815,Lu=37816,Iu=37817,Du=37818,Uu=37819,Nu=37820,Ou=37821,Nc=36492,Fu=36494,zu=36495,l0=36283,Bu=36284,Hu=36285,ku=36286;var fo=2300,po=2301,Oc=2302,Gu=2400,Vu=2401,Wu=2402;var ed=3e3,ms=3001,h0=3200,u0=3201,nd=0,f0=1,zn="",Ee="srgb",bi="srgb-linear",rh="display-p3",$o="display-p3-linear",mo="linear",Ce="srgb",go="rec709",xo="p3";var Ns=7680;var Xu=519,d0=512,p0=513,m0=514,id=515,g0=516,x0=517,y0=518,_0=519,ml=35044,sd=35048;var Yu="300 es",gl=1035,Si=2e3,yo=2001,Zi=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let i=this._listeners;i[t]===void 0&&(i[t]=[]),i[t].indexOf(e)===-1&&i[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let i=this._listeners;return i[t]!==void 0&&i[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let s=this._listeners[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let i=this._listeners[t.type];if(i!==void 0){t.target=this;let s=i.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,t);t.target=null}}},hn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],$u=1234567,Xr=Math.PI/180,ea=180/Math.PI;function ci(){let n=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(hn[n&255]+hn[n>>8&255]+hn[n>>16&255]+hn[n>>24&255]+"-"+hn[t&255]+hn[t>>8&255]+"-"+hn[t>>16&15|64]+hn[t>>24&255]+"-"+hn[e&63|128]+hn[e>>8&255]+"-"+hn[e>>16&255]+hn[e>>24&255]+hn[i&255]+hn[i>>8&255]+hn[i>>16&255]+hn[i>>24&255]).toLowerCase()}function an(n,t,e){return Math.max(t,Math.min(e,n))}function ah(n,t){return(n%t+t)%t}function v0(n,t,e,i,s){return i+(n-t)*(s-i)/(e-t)}function M0(n,t,e){return n!==t?(e-n)/(t-n):0}function Yr(n,t,e){return(1-e)*n+e*t}function E0(n,t,e,i){return Yr(n,t,1-Math.exp(-e*i))}function S0(n,t=1){return t-Math.abs(ah(n,t*2)-t)}function b0(n,t,e){return n<=t?0:n>=e?1:(n=(n-t)/(e-t),n*n*(3-2*n))}function T0(n,t,e){return n<=t?0:n>=e?1:(n=(n-t)/(e-t),n*n*n*(n*(n*6-15)+10))}function w0(n,t){return n+Math.floor(Math.random()*(t-n+1))}function A0(n,t){return n+Math.random()*(t-n)}function R0(n){return n*(.5-Math.random())}function C0(n){n!==void 0&&($u=n);let t=$u+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function P0(n){return n*Xr}function L0(n){return n*ea}function xl(n){return(n&n-1)===0&&n!==0}function I0(n){return Math.pow(2,Math.ceil(Math.log(n)/Math.LN2))}function _o(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function D0(n,t,e,i,s){let r=Math.cos,a=Math.sin,o=r(e/2),c=a(e/2),l=r((t+i)/2),h=a((t+i)/2),u=r((t-i)/2),f=a((t-i)/2),d=r((i-t)/2),p=a((i-t)/2);switch(s){case"XYX":n.set(o*h,c*u,c*f,o*l);break;case"YZY":n.set(c*f,o*h,c*u,o*l);break;case"ZXZ":n.set(c*u,c*f,o*h,o*l);break;case"XZX":n.set(o*h,c*p,c*d,o*l);break;case"YXY":n.set(c*d,o*h,c*p,o*l);break;case"ZYZ":n.set(c*p,c*d,o*h,o*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function oi(n,t){switch(t.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function ye(n,t){switch(t.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}var rd={DEG2RAD:Xr,RAD2DEG:ea,generateUUID:ci,clamp:an,euclideanModulo:ah,mapLinear:v0,inverseLerp:M0,lerp:Yr,damp:E0,pingpong:S0,smoothstep:b0,smootherstep:T0,randInt:w0,randFloat:A0,randFloatSpread:R0,seededRandom:C0,degToRad:P0,radToDeg:L0,isPowerOfTwo:xl,ceilPowerOfTwo:I0,floorPowerOfTwo:_o,setQuaternionFromProperEuler:D0,normalize:ye,denormalize:oi},ht=class n{constructor(t=0,e=0){n.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,i=this.y,s=t.elements;return this.x=s[0]*e+s[3]*i+s[6],this.y=s[1]*e+s[4]*i+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let i=this.dot(t)/e;return Math.acos(an(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,i=this.y-t.y;return e*e+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let i=Math.cos(e),s=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*i-a*s+t.x,this.y=r*s+a*i+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},re=class n{constructor(t,e,i,s,r,a,o,c,l){n.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,i,s,r,a,o,c,l)}set(t,e,i,s,r,a,o,c,l){let h=this.elements;return h[0]=t,h[1]=s,h[2]=o,h[3]=e,h[4]=r,h[5]=c,h[6]=i,h[7]=a,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],this}extractBasis(t,e,i){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let i=t.elements,s=e.elements,r=this.elements,a=i[0],o=i[3],c=i[6],l=i[1],h=i[4],u=i[7],f=i[2],d=i[5],p=i[8],x=s[0],g=s[3],m=s[6],S=s[1],y=s[4],b=s[7],C=s[2],A=s[5],w=s[8];return r[0]=a*x+o*S+c*C,r[3]=a*g+o*y+c*A,r[6]=a*m+o*b+c*w,r[1]=l*x+h*S+u*C,r[4]=l*g+h*y+u*A,r[7]=l*m+h*b+u*w,r[2]=f*x+d*S+p*C,r[5]=f*g+d*y+p*A,r[8]=f*m+d*b+p*w,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8];return e*a*h-e*o*l-i*r*h+i*o*c+s*r*l-s*a*c}invert(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8],u=h*a-o*l,f=o*c-h*r,d=l*r-a*c,p=e*u+i*f+s*d;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let x=1/p;return t[0]=u*x,t[1]=(s*l-h*i)*x,t[2]=(o*i-s*a)*x,t[3]=f*x,t[4]=(h*e-s*c)*x,t[5]=(s*r-o*e)*x,t[6]=d*x,t[7]=(i*c-l*e)*x,t[8]=(a*e-i*r)*x,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,i,s,r,a,o){let c=Math.cos(r),l=Math.sin(r);return this.set(i*c,i*l,-i*(c*a+l*o)+a+t,-s*l,s*c,-s*(-l*a+c*o)+o+e,0,0,1),this}scale(t,e){return this.premultiply(Fc.makeScale(t,e)),this}rotate(t){return this.premultiply(Fc.makeRotation(-t)),this}translate(t,e){return this.premultiply(Fc.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,i,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,i=t.elements;for(let s=0;s<9;s++)if(e[s]!==i[s])return!1;return!0}fromArray(t,e=0){for(let i=0;i<9;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){let i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t}clone(){return new this.constructor().fromArray(this.elements)}},Fc=new re;function ad(n){for(let t=n.length-1;t>=0;--t)if(n[t]>=65535)return!0;return!1}function vo(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function U0(){let n=vo("canvas");return n.style.display="block",n}var qu={};function $r(n){n in qu||(qu[n]=!0,console.warn(n))}var Zu=new re().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Ju=new re().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),Da={[bi]:{transfer:mo,primaries:go,toReference:n=>n,fromReference:n=>n},[Ee]:{transfer:Ce,primaries:go,toReference:n=>n.convertSRGBToLinear(),fromReference:n=>n.convertLinearToSRGB()},[$o]:{transfer:mo,primaries:xo,toReference:n=>n.applyMatrix3(Ju),fromReference:n=>n.applyMatrix3(Zu)},[rh]:{transfer:Ce,primaries:xo,toReference:n=>n.convertSRGBToLinear().applyMatrix3(Ju),fromReference:n=>n.applyMatrix3(Zu).convertLinearToSRGB()}},N0=new Set([bi,$o]),_e={enabled:!0,_workingColorSpace:bi,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(n){if(!N0.has(n))throw new Error(`Unsupported working color space, "${n}".`);this._workingColorSpace=n},convert:function(n,t,e){if(this.enabled===!1||t===e||!t||!e)return n;let i=Da[t].toReference,s=Da[e].fromReference;return s(i(n))},fromWorkingColorSpace:function(n,t){return this.convert(n,this._workingColorSpace,t)},toWorkingColorSpace:function(n,t){return this.convert(n,t,this._workingColorSpace)},getPrimaries:function(n){return Da[n].primaries},getTransfer:function(n){return n===zn?mo:Da[n].transfer}};function rr(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function zc(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}var Os,Mo=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{Os===void 0&&(Os=vo("canvas")),Os.width=t.width,Os.height=t.height;let i=Os.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),e=Os}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=vo("canvas");e.width=t.width,e.height=t.height;let i=e.getContext("2d");i.drawImage(t,0,0,t.width,t.height);let s=i.getImageData(0,0,t.width,t.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=rr(r[a]/255)*255;return i.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let i=0;i<e.length;i++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[i]=Math.floor(rr(e[i]/255)*255):e[i]=rr(e[i]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},O0=0,Eo=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:O0++}),this.uuid=ci(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let i={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(Bc(s[a].image)):r.push(Bc(s[a]))}else r=Bc(s);i.url=r}return e||(t.images[this.uuid]=i),i}};function Bc(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?Mo.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var F0=0,Bn=class n extends Zi{constructor(t=n.DEFAULT_IMAGE,e=n.DEFAULT_MAPPING,i=Kn,s=Kn,r=Fn,a=Qr,o=jn,c=Yi,l=n.DEFAULT_ANISOTROPY,h=zn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:F0++}),this.uuid=ci(),this.name="",this.source=new Eo(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=i,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=c,this.offset=new ht(0,0),this.repeat=new ht(1,1),this.center=new ht(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new re,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:($r("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===ms?Ee:zn),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),e||(t.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==$f)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case jr:t.x=t.x-Math.floor(t.x);break;case Kn:t.x=t.x<0?0:1;break;case pl:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case jr:t.y=t.y-Math.floor(t.y);break;case Kn:t.y=t.y<0?0:1;break;case pl:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return $r("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===Ee?ms:ed}set encoding(t){$r("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===ms?Ee:zn}};Bn.DEFAULT_IMAGE=null;Bn.DEFAULT_MAPPING=$f;Bn.DEFAULT_ANISOTROPY=1;var Ge=class n{constructor(t=0,e=0,i=0,s=1){n.prototype.isVector4=!0,this.x=t,this.y=e,this.z=i,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,i,s){return this.x=t,this.y=e,this.z=i,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,i=this.y,s=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*i+a[8]*s+a[12]*r,this.y=a[1]*e+a[5]*i+a[9]*s+a[13]*r,this.z=a[2]*e+a[6]*i+a[10]*s+a[14]*r,this.w=a[3]*e+a[7]*i+a[11]*s+a[15]*r,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,i,s,r,c=t.elements,l=c[0],h=c[4],u=c[8],f=c[1],d=c[5],p=c[9],x=c[2],g=c[6],m=c[10];if(Math.abs(h-f)<.01&&Math.abs(u-x)<.01&&Math.abs(p-g)<.01){if(Math.abs(h+f)<.1&&Math.abs(u+x)<.1&&Math.abs(p+g)<.1&&Math.abs(l+d+m-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let y=(l+1)/2,b=(d+1)/2,C=(m+1)/2,A=(h+f)/4,w=(u+x)/4,F=(p+g)/4;return y>b&&y>C?y<.01?(i=0,s=.707106781,r=.707106781):(i=Math.sqrt(y),s=A/i,r=w/i):b>C?b<.01?(i=.707106781,s=0,r=.707106781):(s=Math.sqrt(b),i=A/s,r=F/s):C<.01?(i=.707106781,s=.707106781,r=0):(r=Math.sqrt(C),i=w/r,s=F/r),this.set(i,s,r,e),this}let S=Math.sqrt((g-p)*(g-p)+(u-x)*(u-x)+(f-h)*(f-h));return Math.abs(S)<.001&&(S=1),this.x=(g-p)/S,this.y=(u-x)/S,this.z=(f-h)/S,this.w=Math.acos((l+d+m-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this.w=t.w+(e.w-t.w)*i,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},yl=class extends Zi{constructor(t=1,e=1,i={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new Ge(0,0,t,e),this.scissorTest=!1,this.viewport=new Ge(0,0,t,e);let s={width:t,height:e,depth:1};i.encoding!==void 0&&($r("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===ms?Ee:zn),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Fn,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new Bn(s,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(t,e,i=1){(this.width!==t||this.height!==e||this.depth!==i)&&(this.width=t,this.height=e,this.depth=i,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new Eo(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Ti=class extends yl{constructor(t=1,e=1,i={}){super(t,e,i),this.isWebGLRenderTarget=!0}},So=class extends Bn{constructor(t=null,e=1,i=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=nn,this.minFilter=nn,this.wrapR=Kn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var _l=class extends Bn{constructor(t=null,e=1,i=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=nn,this.minFilter=nn,this.wrapR=Kn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var li=class{constructor(t=0,e=0,i=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=i,this._w=s}static slerpFlat(t,e,i,s,r,a,o){let c=i[s+0],l=i[s+1],h=i[s+2],u=i[s+3],f=r[a+0],d=r[a+1],p=r[a+2],x=r[a+3];if(o===0){t[e+0]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u;return}if(o===1){t[e+0]=f,t[e+1]=d,t[e+2]=p,t[e+3]=x;return}if(u!==x||c!==f||l!==d||h!==p){let g=1-o,m=c*f+l*d+h*p+u*x,S=m>=0?1:-1,y=1-m*m;if(y>Number.EPSILON){let C=Math.sqrt(y),A=Math.atan2(C,m*S);g=Math.sin(g*A)/C,o=Math.sin(o*A)/C}let b=o*S;if(c=c*g+f*b,l=l*g+d*b,h=h*g+p*b,u=u*g+x*b,g===1-o){let C=1/Math.sqrt(c*c+l*l+h*h+u*u);c*=C,l*=C,h*=C,u*=C}}t[e]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,i,s,r,a){let o=i[s],c=i[s+1],l=i[s+2],h=i[s+3],u=r[a],f=r[a+1],d=r[a+2],p=r[a+3];return t[e]=o*p+h*u+c*d-l*f,t[e+1]=c*p+h*f+l*u-o*d,t[e+2]=l*p+h*d+o*f-c*u,t[e+3]=h*p-o*u-c*f-l*d,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,i,s){return this._x=t,this._y=e,this._z=i,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let i=t._x,s=t._y,r=t._z,a=t._order,o=Math.cos,c=Math.sin,l=o(i/2),h=o(s/2),u=o(r/2),f=c(i/2),d=c(s/2),p=c(r/2);switch(a){case"XYZ":this._x=f*h*u+l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u-f*d*p;break;case"YXZ":this._x=f*h*u+l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u+f*d*p;break;case"ZXY":this._x=f*h*u-l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u-f*d*p;break;case"ZYX":this._x=f*h*u-l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u+f*d*p;break;case"YZX":this._x=f*h*u+l*d*p,this._y=l*d*u+f*h*p,this._z=l*h*p-f*d*u,this._w=l*h*u-f*d*p;break;case"XZY":this._x=f*h*u-l*d*p,this._y=l*d*u-f*h*p,this._z=l*h*p+f*d*u,this._w=l*h*u+f*d*p;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let i=e/2,s=Math.sin(i);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,i=e[0],s=e[4],r=e[8],a=e[1],o=e[5],c=e[9],l=e[2],h=e[6],u=e[10],f=i+o+u;if(f>0){let d=.5/Math.sqrt(f+1);this._w=.25/d,this._x=(h-c)*d,this._y=(r-l)*d,this._z=(a-s)*d}else if(i>o&&i>u){let d=2*Math.sqrt(1+i-o-u);this._w=(h-c)/d,this._x=.25*d,this._y=(s+a)/d,this._z=(r+l)/d}else if(o>u){let d=2*Math.sqrt(1+o-i-u);this._w=(r-l)/d,this._x=(s+a)/d,this._y=.25*d,this._z=(c+h)/d}else{let d=2*Math.sqrt(1+u-i-o);this._w=(a-s)/d,this._x=(r+l)/d,this._y=(c+h)/d,this._z=.25*d}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let i=t.dot(e)+1;return i<Number.EPSILON?(i=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=i):(this._x=0,this._y=-t.z,this._z=t.y,this._w=i)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=i),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(an(this.dot(t),-1,1)))}rotateTowards(t,e){let i=this.angleTo(t);if(i===0)return this;let s=Math.min(1,e/i);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let i=t._x,s=t._y,r=t._z,a=t._w,o=e._x,c=e._y,l=e._z,h=e._w;return this._x=i*h+a*o+s*l-r*c,this._y=s*h+a*c+r*o-i*l,this._z=r*h+a*l+i*c-s*o,this._w=a*h-i*o-s*c-r*l,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let i=this._x,s=this._y,r=this._z,a=this._w,o=a*t._w+i*t._x+s*t._y+r*t._z;if(o<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,o=-o):this.copy(t),o>=1)return this._w=a,this._x=i,this._y=s,this._z=r,this;let c=1-o*o;if(c<=Number.EPSILON){let d=1-e;return this._w=d*a+e*this._w,this._x=d*i+e*this._x,this._y=d*s+e*this._y,this._z=d*r+e*this._z,this.normalize(),this}let l=Math.sqrt(c),h=Math.atan2(l,o),u=Math.sin((1-e)*h)/l,f=Math.sin(e*h)/l;return this._w=a*u+this._w*f,this._x=i*u+this._x*f,this._y=s*u+this._y*f,this._z=r*u+this._z*f,this._onChangeCallback(),this}slerpQuaternions(t,e,i){return this.copy(t).slerp(e,i)}random(){let t=Math.random(),e=Math.sqrt(1-t),i=Math.sqrt(t),s=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(e*Math.cos(s),i*Math.sin(r),i*Math.cos(r),e*Math.sin(s))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},L=class n{constructor(t=0,e=0,i=0){n.prototype.isVector3=!0,this.x=t,this.y=e,this.z=i}set(t,e,i){return i===void 0&&(i=this.z),this.x=t,this.y=e,this.z=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Ku.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Ku.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,i=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*i+r[6]*s,this.y=r[1]*e+r[4]*i+r[7]*s,this.z=r[2]*e+r[5]*i+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,i=this.y,s=this.z,r=t.elements,a=1/(r[3]*e+r[7]*i+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*i+r[8]*s+r[12])*a,this.y=(r[1]*e+r[5]*i+r[9]*s+r[13])*a,this.z=(r[2]*e+r[6]*i+r[10]*s+r[14])*a,this}applyQuaternion(t){let e=this.x,i=this.y,s=this.z,r=t.x,a=t.y,o=t.z,c=t.w,l=2*(a*s-o*i),h=2*(o*e-r*s),u=2*(r*i-a*e);return this.x=e+c*l+a*u-o*h,this.y=i+c*h+o*l-r*u,this.z=s+c*u+r*h-a*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,i=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*i+r[8]*s,this.y=r[1]*e+r[5]*i+r[9]*s,this.z=r[2]*e+r[6]*i+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let i=t.x,s=t.y,r=t.z,a=e.x,o=e.y,c=e.z;return this.x=s*c-r*o,this.y=r*a-i*c,this.z=i*o-s*a,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let i=t.dot(this)/e;return this.copy(t).multiplyScalar(i)}projectOnPlane(t){return Hc.copy(this).projectOnVector(t),this.sub(Hc)}reflect(t){return this.sub(Hc.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let i=this.dot(t)/e;return Math.acos(an(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,i=this.y-t.y,s=this.z-t.z;return e*e+i*i+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,i){let s=Math.sin(e)*t;return this.x=s*Math.sin(i),this.y=Math.cos(e)*t,this.z=s*Math.cos(i),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,i){return this.x=t*Math.sin(e),this.y=i,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),i=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=i,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,i=Math.sqrt(1-t**2);return this.x=i*Math.cos(e),this.y=i*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Hc=new L,Ku=new li,Hn=class{constructor(t=new L(1/0,1/0,1/0),e=new L(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e+=3)this.expandByPoint(qn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,i=t.count;e<i;e++)this.expandByPoint(qn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let i=qn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(i),this.max.copy(t).add(i),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let i=t.geometry;if(i!==void 0){let r=i.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,qn):qn.fromBufferAttribute(r,a),qn.applyMatrix4(t.matrixWorld),this.expandByPoint(qn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Ua.copy(t.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Ua.copy(i.boundingBox)),Ua.applyMatrix4(t.matrixWorld),this.union(Ua)}let s=t.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,qn),qn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,i;return t.normal.x>0?(e=t.normal.x*this.min.x,i=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,i=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,i+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,i+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,i+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,i+=t.normal.z*this.min.z),e<=-t.constant&&i>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Or),Na.subVectors(this.max,Or),Fs.subVectors(t.a,Or),zs.subVectors(t.b,Or),Bs.subVectors(t.c,Or),Oi.subVectors(zs,Fs),Fi.subVectors(Bs,zs),rs.subVectors(Fs,Bs);let e=[0,-Oi.z,Oi.y,0,-Fi.z,Fi.y,0,-rs.z,rs.y,Oi.z,0,-Oi.x,Fi.z,0,-Fi.x,rs.z,0,-rs.x,-Oi.y,Oi.x,0,-Fi.y,Fi.x,0,-rs.y,rs.x,0];return!kc(e,Fs,zs,Bs,Na)||(e=[1,0,0,0,1,0,0,0,1],!kc(e,Fs,zs,Bs,Na))?!1:(Oa.crossVectors(Oi,Fi),e=[Oa.x,Oa.y,Oa.z],kc(e,Fs,zs,Bs,Na))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,qn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(qn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(gi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),gi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),gi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),gi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),gi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),gi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),gi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),gi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(gi),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},gi=[new L,new L,new L,new L,new L,new L,new L,new L],qn=new L,Ua=new Hn,Fs=new L,zs=new L,Bs=new L,Oi=new L,Fi=new L,rs=new L,Or=new L,Na=new L,Oa=new L,as=new L;function kc(n,t,e,i,s){for(let r=0,a=n.length-3;r<=a;r+=3){as.fromArray(n,r);let o=s.x*Math.abs(as.x)+s.y*Math.abs(as.y)+s.z*Math.abs(as.z),c=t.dot(as),l=e.dot(as),h=i.dot(as);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>o)return!1}return!0}var z0=new Hn,Fr=new L,Gc=new L,Ji=class{constructor(t=new L,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let i=this.center;e!==void 0?i.copy(e):z0.setFromPoints(t).getCenter(i);let s=0;for(let r=0,a=t.length;r<a;r++)s=Math.max(s,i.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let i=this.center.distanceToSquared(t);return e.copy(t),i>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Fr.subVectors(t,this.center);let e=Fr.lengthSq();if(e>this.radius*this.radius){let i=Math.sqrt(e),s=(i-this.radius)*.5;this.center.addScaledVector(Fr,s/i),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Gc.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Fr.copy(t.center).add(Gc)),this.expandByPoint(Fr.copy(t.center).sub(Gc))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},xi=new L,Vc=new L,Fa=new L,zi=new L,Wc=new L,za=new L,Xc=new L,bo=class{constructor(t=new L,e=new L(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,xi)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let i=e.dot(this.direction);return i<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=xi.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(xi.copy(this.origin).addScaledVector(this.direction,e),xi.distanceToSquared(t))}distanceSqToSegment(t,e,i,s){Vc.copy(t).add(e).multiplyScalar(.5),Fa.copy(e).sub(t).normalize(),zi.copy(this.origin).sub(Vc);let r=t.distanceTo(e)*.5,a=-this.direction.dot(Fa),o=zi.dot(this.direction),c=-zi.dot(Fa),l=zi.lengthSq(),h=Math.abs(1-a*a),u,f,d,p;if(h>0)if(u=a*c-o,f=a*o-c,p=r*h,u>=0)if(f>=-p)if(f<=p){let x=1/h;u*=x,f*=x,d=u*(u+a*f+2*o)+f*(a*u+f+2*c)+l}else f=r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;else f=-r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;else f<=-p?(u=Math.max(0,-(-a*r+o)),f=u>0?-r:Math.min(Math.max(-r,-c),r),d=-u*u+f*(f+2*c)+l):f<=p?(u=0,f=Math.min(Math.max(-r,-c),r),d=f*(f+2*c)+l):(u=Math.max(0,-(a*r+o)),f=u>0?r:Math.min(Math.max(-r,-c),r),d=-u*u+f*(f+2*c)+l);else f=a>0?-r:r,u=Math.max(0,-(a*f+o)),d=-u*u+f*(f+2*c)+l;return i&&i.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(Vc).addScaledVector(Fa,f),d}intersectSphere(t,e){xi.subVectors(t.center,this.origin);let i=xi.dot(this.direction),s=xi.dot(xi)-i*i,r=t.radius*t.radius;if(s>r)return null;let a=Math.sqrt(r-s),o=i-a,c=i+a;return c<0?null:o<0?this.at(c,e):this.at(o,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let i=-(this.origin.dot(t.normal)+t.constant)/e;return i>=0?i:null}intersectPlane(t,e){let i=this.distanceToPlane(t);return i===null?null:this.at(i,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let i,s,r,a,o,c,l=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,f=this.origin;return l>=0?(i=(t.min.x-f.x)*l,s=(t.max.x-f.x)*l):(i=(t.max.x-f.x)*l,s=(t.min.x-f.x)*l),h>=0?(r=(t.min.y-f.y)*h,a=(t.max.y-f.y)*h):(r=(t.max.y-f.y)*h,a=(t.min.y-f.y)*h),i>a||r>s||((r>i||isNaN(i))&&(i=r),(a<s||isNaN(s))&&(s=a),u>=0?(o=(t.min.z-f.z)*u,c=(t.max.z-f.z)*u):(o=(t.max.z-f.z)*u,c=(t.min.z-f.z)*u),i>c||o>s)||((o>i||i!==i)&&(i=o),(c<s||s!==s)&&(s=c),s<0)?null:this.at(i>=0?i:s,e)}intersectsBox(t){return this.intersectBox(t,xi)!==null}intersectTriangle(t,e,i,s,r){Wc.subVectors(e,t),za.subVectors(i,t),Xc.crossVectors(Wc,za);let a=this.direction.dot(Xc),o;if(a>0){if(s)return null;o=1}else if(a<0)o=-1,a=-a;else return null;zi.subVectors(this.origin,t);let c=o*this.direction.dot(za.crossVectors(zi,za));if(c<0)return null;let l=o*this.direction.dot(Wc.cross(zi));if(l<0||c+l>a)return null;let h=-o*zi.dot(Xc);return h<0?null:this.at(h/a,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Ae=class n{constructor(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g){n.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g)}set(t,e,i,s,r,a,o,c,l,h,u,f,d,p,x,g){let m=this.elements;return m[0]=t,m[4]=e,m[8]=i,m[12]=s,m[1]=r,m[5]=a,m[9]=o,m[13]=c,m[2]=l,m[6]=h,m[10]=u,m[14]=f,m[3]=d,m[7]=p,m[11]=x,m[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new n().fromArray(this.elements)}copy(t){let e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],e[9]=i[9],e[10]=i[10],e[11]=i[11],e[12]=i[12],e[13]=i[13],e[14]=i[14],e[15]=i[15],this}copyPosition(t){let e=this.elements,i=t.elements;return e[12]=i[12],e[13]=i[13],e[14]=i[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,i){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(t,e,i){return this.set(t.x,e.x,i.x,0,t.y,e.y,i.y,0,t.z,e.z,i.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,i=t.elements,s=1/Hs.setFromMatrixColumn(t,0).length(),r=1/Hs.setFromMatrixColumn(t,1).length(),a=1/Hs.setFromMatrixColumn(t,2).length();return e[0]=i[0]*s,e[1]=i[1]*s,e[2]=i[2]*s,e[3]=0,e[4]=i[4]*r,e[5]=i[5]*r,e[6]=i[6]*r,e[7]=0,e[8]=i[8]*a,e[9]=i[9]*a,e[10]=i[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,i=t.x,s=t.y,r=t.z,a=Math.cos(i),o=Math.sin(i),c=Math.cos(s),l=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){let f=a*h,d=a*u,p=o*h,x=o*u;e[0]=c*h,e[4]=-c*u,e[8]=l,e[1]=d+p*l,e[5]=f-x*l,e[9]=-o*c,e[2]=x-f*l,e[6]=p+d*l,e[10]=a*c}else if(t.order==="YXZ"){let f=c*h,d=c*u,p=l*h,x=l*u;e[0]=f+x*o,e[4]=p*o-d,e[8]=a*l,e[1]=a*u,e[5]=a*h,e[9]=-o,e[2]=d*o-p,e[6]=x+f*o,e[10]=a*c}else if(t.order==="ZXY"){let f=c*h,d=c*u,p=l*h,x=l*u;e[0]=f-x*o,e[4]=-a*u,e[8]=p+d*o,e[1]=d+p*o,e[5]=a*h,e[9]=x-f*o,e[2]=-a*l,e[6]=o,e[10]=a*c}else if(t.order==="ZYX"){let f=a*h,d=a*u,p=o*h,x=o*u;e[0]=c*h,e[4]=p*l-d,e[8]=f*l+x,e[1]=c*u,e[5]=x*l+f,e[9]=d*l-p,e[2]=-l,e[6]=o*c,e[10]=a*c}else if(t.order==="YZX"){let f=a*c,d=a*l,p=o*c,x=o*l;e[0]=c*h,e[4]=x-f*u,e[8]=p*u+d,e[1]=u,e[5]=a*h,e[9]=-o*h,e[2]=-l*h,e[6]=d*u+p,e[10]=f-x*u}else if(t.order==="XZY"){let f=a*c,d=a*l,p=o*c,x=o*l;e[0]=c*h,e[4]=-u,e[8]=l*h,e[1]=f*u+x,e[5]=a*h,e[9]=d*u-p,e[2]=p*u-d,e[6]=o*h,e[10]=x*u+f}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(B0,t,H0)}lookAt(t,e,i){let s=this.elements;return An.subVectors(t,e),An.lengthSq()===0&&(An.z=1),An.normalize(),Bi.crossVectors(i,An),Bi.lengthSq()===0&&(Math.abs(i.z)===1?An.x+=1e-4:An.z+=1e-4,An.normalize(),Bi.crossVectors(i,An)),Bi.normalize(),Ba.crossVectors(An,Bi),s[0]=Bi.x,s[4]=Ba.x,s[8]=An.x,s[1]=Bi.y,s[5]=Ba.y,s[9]=An.y,s[2]=Bi.z,s[6]=Ba.z,s[10]=An.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let i=t.elements,s=e.elements,r=this.elements,a=i[0],o=i[4],c=i[8],l=i[12],h=i[1],u=i[5],f=i[9],d=i[13],p=i[2],x=i[6],g=i[10],m=i[14],S=i[3],y=i[7],b=i[11],C=i[15],A=s[0],w=s[4],F=s[8],E=s[12],M=s[1],I=s[5],N=s[9],J=s[13],P=s[2],O=s[6],z=s[10],Q=s[14],j=s[3],K=s[7],st=s[11],it=s[15];return r[0]=a*A+o*M+c*P+l*j,r[4]=a*w+o*I+c*O+l*K,r[8]=a*F+o*N+c*z+l*st,r[12]=a*E+o*J+c*Q+l*it,r[1]=h*A+u*M+f*P+d*j,r[5]=h*w+u*I+f*O+d*K,r[9]=h*F+u*N+f*z+d*st,r[13]=h*E+u*J+f*Q+d*it,r[2]=p*A+x*M+g*P+m*j,r[6]=p*w+x*I+g*O+m*K,r[10]=p*F+x*N+g*z+m*st,r[14]=p*E+x*J+g*Q+m*it,r[3]=S*A+y*M+b*P+C*j,r[7]=S*w+y*I+b*O+C*K,r[11]=S*F+y*N+b*z+C*st,r[15]=S*E+y*J+b*Q+C*it,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],i=t[4],s=t[8],r=t[12],a=t[1],o=t[5],c=t[9],l=t[13],h=t[2],u=t[6],f=t[10],d=t[14],p=t[3],x=t[7],g=t[11],m=t[15];return p*(+r*c*u-s*l*u-r*o*f+i*l*f+s*o*d-i*c*d)+x*(+e*c*d-e*l*f+r*a*f-s*a*d+s*l*h-r*c*h)+g*(+e*l*u-e*o*d-r*a*u+i*a*d+r*o*h-i*l*h)+m*(-s*o*h-e*c*u+e*o*f+s*a*u-i*a*f+i*c*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,i){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=i),this}invert(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],h=t[8],u=t[9],f=t[10],d=t[11],p=t[12],x=t[13],g=t[14],m=t[15],S=u*g*l-x*f*l+x*c*d-o*g*d-u*c*m+o*f*m,y=p*f*l-h*g*l-p*c*d+a*g*d+h*c*m-a*f*m,b=h*x*l-p*u*l+p*o*d-a*x*d-h*o*m+a*u*m,C=p*u*c-h*x*c-p*o*f+a*x*f+h*o*g-a*u*g,A=e*S+i*y+s*b+r*C;if(A===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let w=1/A;return t[0]=S*w,t[1]=(x*f*r-u*g*r-x*s*d+i*g*d+u*s*m-i*f*m)*w,t[2]=(o*g*r-x*c*r+x*s*l-i*g*l-o*s*m+i*c*m)*w,t[3]=(u*c*r-o*f*r-u*s*l+i*f*l+o*s*d-i*c*d)*w,t[4]=y*w,t[5]=(h*g*r-p*f*r+p*s*d-e*g*d-h*s*m+e*f*m)*w,t[6]=(p*c*r-a*g*r-p*s*l+e*g*l+a*s*m-e*c*m)*w,t[7]=(a*f*r-h*c*r+h*s*l-e*f*l-a*s*d+e*c*d)*w,t[8]=b*w,t[9]=(p*u*r-h*x*r-p*i*d+e*x*d+h*i*m-e*u*m)*w,t[10]=(a*x*r-p*o*r+p*i*l-e*x*l-a*i*m+e*o*m)*w,t[11]=(h*o*r-a*u*r-h*i*l+e*u*l+a*i*d-e*o*d)*w,t[12]=C*w,t[13]=(h*x*s-p*u*s+p*i*f-e*x*f-h*i*g+e*u*g)*w,t[14]=(p*o*s-a*x*s-p*i*c+e*x*c+a*i*g-e*o*g)*w,t[15]=(a*u*s-h*o*s+h*i*c-e*u*c-a*i*f+e*o*f)*w,this}scale(t){let e=this.elements,i=t.x,s=t.y,r=t.z;return e[0]*=i,e[4]*=s,e[8]*=r,e[1]*=i,e[5]*=s,e[9]*=r,e[2]*=i,e[6]*=s,e[10]*=r,e[3]*=i,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],i=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,i,s))}makeTranslation(t,e,i){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,i,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),i=Math.sin(t);return this.set(1,0,0,0,0,e,-i,0,0,i,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,0,i,0,0,1,0,0,-i,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,0,i,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let i=Math.cos(e),s=Math.sin(e),r=1-i,a=t.x,o=t.y,c=t.z,l=r*a,h=r*o;return this.set(l*a+i,l*o-s*c,l*c+s*o,0,l*o+s*c,h*o+i,h*c-s*a,0,l*c-s*o,h*c+s*a,r*c*c+i,0,0,0,0,1),this}makeScale(t,e,i){return this.set(t,0,0,0,0,e,0,0,0,0,i,0,0,0,0,1),this}makeShear(t,e,i,s,r,a){return this.set(1,i,r,0,t,1,a,0,e,s,1,0,0,0,0,1),this}compose(t,e,i){let s=this.elements,r=e._x,a=e._y,o=e._z,c=e._w,l=r+r,h=a+a,u=o+o,f=r*l,d=r*h,p=r*u,x=a*h,g=a*u,m=o*u,S=c*l,y=c*h,b=c*u,C=i.x,A=i.y,w=i.z;return s[0]=(1-(x+m))*C,s[1]=(d+b)*C,s[2]=(p-y)*C,s[3]=0,s[4]=(d-b)*A,s[5]=(1-(f+m))*A,s[6]=(g+S)*A,s[7]=0,s[8]=(p+y)*w,s[9]=(g-S)*w,s[10]=(1-(f+x))*w,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,i){let s=this.elements,r=Hs.set(s[0],s[1],s[2]).length(),a=Hs.set(s[4],s[5],s[6]).length(),o=Hs.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],Zn.copy(this);let l=1/r,h=1/a,u=1/o;return Zn.elements[0]*=l,Zn.elements[1]*=l,Zn.elements[2]*=l,Zn.elements[4]*=h,Zn.elements[5]*=h,Zn.elements[6]*=h,Zn.elements[8]*=u,Zn.elements[9]*=u,Zn.elements[10]*=u,e.setFromRotationMatrix(Zn),i.x=r,i.y=a,i.z=o,this}makePerspective(t,e,i,s,r,a,o=Si){let c=this.elements,l=2*r/(e-t),h=2*r/(i-s),u=(e+t)/(e-t),f=(i+s)/(i-s),d,p;if(o===Si)d=-(a+r)/(a-r),p=-2*a*r/(a-r);else if(o===yo)d=-a/(a-r),p=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=l,c[4]=0,c[8]=u,c[12]=0,c[1]=0,c[5]=h,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=d,c[14]=p,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,i,s,r,a,o=Si){let c=this.elements,l=1/(e-t),h=1/(i-s),u=1/(a-r),f=(e+t)*l,d=(i+s)*h,p,x;if(o===Si)p=(a+r)*u,x=-2*u;else if(o===yo)p=r*u,x=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-f,c[1]=0,c[5]=2*h,c[9]=0,c[13]=-d,c[2]=0,c[6]=0,c[10]=x,c[14]=-p,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){let e=this.elements,i=t.elements;for(let s=0;s<16;s++)if(e[s]!==i[s])return!1;return!0}fromArray(t,e=0){for(let i=0;i<16;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){let i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t[e+9]=i[9],t[e+10]=i[10],t[e+11]=i[11],t[e+12]=i[12],t[e+13]=i[13],t[e+14]=i[14],t[e+15]=i[15],t}},Hs=new L,Zn=new Ae,B0=new L(0,0,0),H0=new L(1,1,1),Bi=new L,Ba=new L,An=new L,ju=new Ae,Qu=new li,hr=class n{constructor(t=0,e=0,i=0,s=n.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=i,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,i,s=this._order){return this._x=t,this._y=e,this._z=i,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,i=!0){let s=t.elements,r=s[0],a=s[4],o=s[8],c=s[1],l=s[5],h=s[9],u=s[2],f=s[6],d=s[10];switch(e){case"XYZ":this._y=Math.asin(an(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,d),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(f,l),this._z=0);break;case"YXZ":this._x=Math.asin(-an(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,d),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(an(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(-u,d),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-an(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(f,d),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(an(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(o,d));break;case"XZY":this._z=Math.asin(-an(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(f,l),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,d),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,i===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,i){return ju.makeRotationFromQuaternion(t),this.setFromRotationMatrix(ju,e,i)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Qu.setFromEuler(this),this.setFromQuaternion(Qu,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};hr.DEFAULT_ORDER="XYZ";var To=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},k0=0,tf=new L,ks=new li,yi=new Ae,Ha=new L,zr=new L,G0=new L,V0=new li,ef=new L(1,0,0),nf=new L(0,1,0),sf=new L(0,0,1),W0={type:"added"},X0={type:"removed"},qe=class n extends Zi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:k0++}),this.uuid=ci(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=n.DEFAULT_UP.clone();let t=new L,e=new hr,i=new li,s=new L(1,1,1);function r(){i.setFromEuler(e,!1)}function a(){e.setFromQuaternion(i,void 0,!1)}e._onChange(r),i._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Ae},normalMatrix:{value:new re}}),this.matrix=new Ae,this.matrixWorld=new Ae,this.matrixAutoUpdate=n.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=n.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new To,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return ks.setFromAxisAngle(t,e),this.quaternion.multiply(ks),this}rotateOnWorldAxis(t,e){return ks.setFromAxisAngle(t,e),this.quaternion.premultiply(ks),this}rotateX(t){return this.rotateOnAxis(ef,t)}rotateY(t){return this.rotateOnAxis(nf,t)}rotateZ(t){return this.rotateOnAxis(sf,t)}translateOnAxis(t,e){return tf.copy(t).applyQuaternion(this.quaternion),this.position.add(tf.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(ef,t)}translateY(t){return this.translateOnAxis(nf,t)}translateZ(t){return this.translateOnAxis(sf,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(yi.copy(this.matrixWorld).invert())}lookAt(t,e,i){t.isVector3?Ha.copy(t):Ha.set(t,e,i);let s=this.parent;this.updateWorldMatrix(!0,!1),zr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?yi.lookAt(zr,Ha,this.up):yi.lookAt(Ha,zr,this.up),this.quaternion.setFromRotationMatrix(yi),s&&(yi.extractRotation(s.matrixWorld),ks.setFromRotationMatrix(yi),this.quaternion.premultiply(ks.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(W0)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(X0)),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),yi.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),yi.multiply(t.parent.matrixWorld)),t.applyMatrix4(yi),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let i=0,s=this.children.length;i<s;i++){let a=this.children[i].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,i=[]){this[t]===e&&i.push(this);let s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(t,e,i);return i}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(zr,t,G0),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(zr,V0,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let i=0,s=e.length;i<s;i++)e[i].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let i=0,s=e.length;i<s;i++)e[i].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let i=0,s=e.length;i<s;i++){let r=e[i];(r.matrixWorldAutoUpdate===!0||t===!0)&&r.updateMatrixWorld(t)}}updateWorldMatrix(t,e){let i=this.parent;if(t===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){let s=this.children;for(let r=0,a=s.length;r<a;r++){let o=s[r];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(t){let e=t===void 0||typeof t=="string",i={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),s.maxGeometryCount=this._maxGeometryCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let c=o.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){let u=c[l];r(t.shapes,u)}else r(t.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let c=0,l=this.material.length;c<l;c++)o.push(r(t.materials,this.material[c]));s.material=o}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){let c=this.animations[o];s.animations.push(r(t.animations,c))}}if(e){let o=a(t.geometries),c=a(t.materials),l=a(t.textures),h=a(t.images),u=a(t.shapes),f=a(t.skeletons),d=a(t.animations),p=a(t.nodes);o.length>0&&(i.geometries=o),c.length>0&&(i.materials=c),l.length>0&&(i.textures=l),h.length>0&&(i.images=h),u.length>0&&(i.shapes=u),f.length>0&&(i.skeletons=f),d.length>0&&(i.animations=d),p.length>0&&(i.nodes=p)}return i.object=s,i;function a(o){let c=[];for(let l in o){let h=o[l];delete h.metadata,c.push(h)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let i=0;i<t.children.length;i++){let s=t.children[i];this.add(s.clone())}return this}};qe.DEFAULT_UP=new L(0,1,0);qe.DEFAULT_MATRIX_AUTO_UPDATE=!0;qe.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Jn=new L,_i=new L,Yc=new L,vi=new L,Gs=new L,Vs=new L,rf=new L,$c=new L,qc=new L,Zc=new L,ka=!1,fs=class n{constructor(t=new L,e=new L,i=new L){this.a=t,this.b=e,this.c=i}static getNormal(t,e,i,s){s.subVectors(i,e),Jn.subVectors(t,e),s.cross(Jn);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,i,s,r){Jn.subVectors(s,e),_i.subVectors(i,e),Yc.subVectors(t,e);let a=Jn.dot(Jn),o=Jn.dot(_i),c=Jn.dot(Yc),l=_i.dot(_i),h=_i.dot(Yc),u=a*l-o*o;if(u===0)return r.set(0,0,0),null;let f=1/u,d=(l*c-o*h)*f,p=(a*h-o*c)*f;return r.set(1-d-p,p,d)}static containsPoint(t,e,i,s){return this.getBarycoord(t,e,i,s,vi)===null?!1:vi.x>=0&&vi.y>=0&&vi.x+vi.y<=1}static getUV(t,e,i,s,r,a,o,c){return ka===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),ka=!0),this.getInterpolation(t,e,i,s,r,a,o,c)}static getInterpolation(t,e,i,s,r,a,o,c){return this.getBarycoord(t,e,i,s,vi)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,vi.x),c.addScaledVector(a,vi.y),c.addScaledVector(o,vi.z),c)}static isFrontFacing(t,e,i,s){return Jn.subVectors(i,e),_i.subVectors(t,e),Jn.cross(_i).dot(s)<0}set(t,e,i){return this.a.copy(t),this.b.copy(e),this.c.copy(i),this}setFromPointsAndIndices(t,e,i,s){return this.a.copy(t[e]),this.b.copy(t[i]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,i,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,i),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Jn.subVectors(this.c,this.b),_i.subVectors(this.a,this.b),Jn.cross(_i).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return n.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return n.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,i,s,r){return ka===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),ka=!0),n.getInterpolation(t,this.a,this.b,this.c,e,i,s,r)}getInterpolation(t,e,i,s,r){return n.getInterpolation(t,this.a,this.b,this.c,e,i,s,r)}containsPoint(t){return n.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return n.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let i=this.a,s=this.b,r=this.c,a,o;Gs.subVectors(s,i),Vs.subVectors(r,i),$c.subVectors(t,i);let c=Gs.dot($c),l=Vs.dot($c);if(c<=0&&l<=0)return e.copy(i);qc.subVectors(t,s);let h=Gs.dot(qc),u=Vs.dot(qc);if(h>=0&&u<=h)return e.copy(s);let f=c*u-h*l;if(f<=0&&c>=0&&h<=0)return a=c/(c-h),e.copy(i).addScaledVector(Gs,a);Zc.subVectors(t,r);let d=Gs.dot(Zc),p=Vs.dot(Zc);if(p>=0&&d<=p)return e.copy(r);let x=d*l-c*p;if(x<=0&&l>=0&&p<=0)return o=l/(l-p),e.copy(i).addScaledVector(Vs,o);let g=h*p-d*u;if(g<=0&&u-h>=0&&d-p>=0)return rf.subVectors(r,s),o=(u-h)/(u-h+(d-p)),e.copy(s).addScaledVector(rf,o);let m=1/(g+x+f);return a=x*m,o=f*m,e.copy(i).addScaledVector(Gs,a).addScaledVector(Vs,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},od={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Hi={h:0,s:0,l:0},Ga={h:0,s:0,l:0};function Jc(n,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?n+(t-n)*6*e:e<1/2?t:e<2/3?n+(t-n)*6*(2/3-e):n}var Ft=class{constructor(t,e,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,i)}set(t,e,i){if(e===void 0&&i===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,i);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Ee){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,_e.toWorkingColorSpace(this,e),this}setRGB(t,e,i,s=_e.workingColorSpace){return this.r=t,this.g=e,this.b=i,_e.toWorkingColorSpace(this,s),this}setHSL(t,e,i,s=_e.workingColorSpace){if(t=ah(t,1),e=an(e,0,1),i=an(i,0,1),e===0)this.r=this.g=this.b=i;else{let r=i<=.5?i*(1+e):i+e-i*e,a=2*i-r;this.r=Jc(a,r,t+1/3),this.g=Jc(a,r,t),this.b=Jc(a,r,t-1/3)}return _e.toWorkingColorSpace(this,s),this}setStyle(t,e=Ee){function i(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Ee){let i=od[t.toLowerCase()];return i!==void 0?this.setHex(i,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=rr(t.r),this.g=rr(t.g),this.b=rr(t.b),this}copyLinearToSRGB(t){return this.r=zc(t.r),this.g=zc(t.g),this.b=zc(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Ee){return _e.fromWorkingColorSpace(un.copy(this),t),Math.round(an(un.r*255,0,255))*65536+Math.round(an(un.g*255,0,255))*256+Math.round(an(un.b*255,0,255))}getHexString(t=Ee){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=_e.workingColorSpace){_e.fromWorkingColorSpace(un.copy(this),e);let i=un.r,s=un.g,r=un.b,a=Math.max(i,s,r),o=Math.min(i,s,r),c,l,h=(o+a)/2;if(o===a)c=0,l=0;else{let u=a-o;switch(l=h<=.5?u/(a+o):u/(2-a-o),a){case i:c=(s-r)/u+(s<r?6:0);break;case s:c=(r-i)/u+2;break;case r:c=(i-s)/u+4;break}c/=6}return t.h=c,t.s=l,t.l=h,t}getRGB(t,e=_e.workingColorSpace){return _e.fromWorkingColorSpace(un.copy(this),e),t.r=un.r,t.g=un.g,t.b=un.b,t}getStyle(t=Ee){_e.fromWorkingColorSpace(un.copy(this),t);let e=un.r,i=un.g,s=un.b;return t!==Ee?`color(${t} ${e.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(i*255)},${Math.round(s*255)})`}offsetHSL(t,e,i){return this.getHSL(Hi),this.setHSL(Hi.h+t,Hi.s+e,Hi.l+i)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,i){return this.r=t.r+(e.r-t.r)*i,this.g=t.g+(e.g-t.g)*i,this.b=t.b+(e.b-t.b)*i,this}lerpHSL(t,e){this.getHSL(Hi),t.getHSL(Ga);let i=Yr(Hi.h,Ga.h,e),s=Yr(Hi.s,Ga.s,e),r=Yr(Hi.l,Ga.l,e);return this.setHSL(i,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,i=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*i+r[6]*s,this.g=r[1]*e+r[4]*i+r[7]*s,this.b=r[2]*e+r[5]*i+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},un=new Ft;Ft.NAMES=od;var Y0=0,wi=class extends Zi{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Y0++}),this.uuid=ci(),this.name="",this.type="Material",this.blending=Wi,this.side=$i,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=hl,this.blendDst=ul,this.blendEquation=hs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ft(0,0,0),this.blendAlpha=0,this.depthFunc=uo,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Xu,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ns,this.stencilZFail=Ns,this.stencilZPass=Ns,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let i=t[e];if(i===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(i):s&&s.isVector3&&i&&i.isVector3?s.copy(i):this[e]=i}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(t).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(t).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(t).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(t).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(t).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Wi&&(i.blending=this.blending),this.side!==$i&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==hl&&(i.blendSrc=this.blendSrc),this.blendDst!==ul&&(i.blendDst=this.blendDst),this.blendEquation!==hs&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==uo&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Xu&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ns&&(i.stencilFail=this.stencilFail),this.stencilZFail!==Ns&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==Ns&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function s(r){let a=[];for(let o in r){let c=r[o];delete c.metadata,a.push(c)}return a}if(e){let r=s(t.textures),a=s(t.images);r.length>0&&(i.textures=r),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,i=null;if(e!==null){let s=e.length;i=new Array(s);for(let r=0;r!==s;++r)i[r]=e[r].clone()}return this.clippingPlanes=i,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},Cn=class extends wi{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ft(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Yf,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var We=new L,Va=new ht,fe=class{constructor(t,e,i=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=i,this.usage=ml,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Gi,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,i){t*=this.itemSize,i*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[i+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,i=this.count;e<i;e++)Va.fromBufferAttribute(this,e),Va.applyMatrix3(t),this.setXY(e,Va.x,Va.y);else if(this.itemSize===3)for(let e=0,i=this.count;e<i;e++)We.fromBufferAttribute(this,e),We.applyMatrix3(t),this.setXYZ(e,We.x,We.y,We.z);return this}applyMatrix4(t){for(let e=0,i=this.count;e<i;e++)We.fromBufferAttribute(this,e),We.applyMatrix4(t),this.setXYZ(e,We.x,We.y,We.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)We.fromBufferAttribute(this,e),We.applyNormalMatrix(t),this.setXYZ(e,We.x,We.y,We.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)We.fromBufferAttribute(this,e),We.transformDirection(t),this.setXYZ(e,We.x,We.y,We.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let i=this.array[t*this.itemSize+e];return this.normalized&&(i=oi(i,this.array)),i}setComponent(t,e,i){return this.normalized&&(i=ye(i,this.array)),this.array[t*this.itemSize+e]=i,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=oi(e,this.array)),e}setX(t,e){return this.normalized&&(e=ye(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=oi(e,this.array)),e}setY(t,e){return this.normalized&&(e=ye(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=oi(e,this.array)),e}setZ(t,e){return this.normalized&&(e=ye(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=oi(e,this.array)),e}setW(t,e){return this.normalized&&(e=ye(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,i){return t*=this.itemSize,this.normalized&&(e=ye(e,this.array),i=ye(i,this.array)),this.array[t+0]=e,this.array[t+1]=i,this}setXYZ(t,e,i,s){return t*=this.itemSize,this.normalized&&(e=ye(e,this.array),i=ye(i,this.array),s=ye(s,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this}setXYZW(t,e,i,s,r){return t*=this.itemSize,this.normalized&&(e=ye(e,this.array),i=ye(i,this.array),s=ye(s,this.array),r=ye(r,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==ml&&(t.usage=this.usage),t}};var wo=class extends fe{constructor(t,e,i){super(new Uint16Array(t),e,i)}};var Ao=class extends fe{constructor(t,e,i){super(new Uint32Array(t),e,i)}};var he=class extends fe{constructor(t,e,i){super(new Float32Array(t),e,i)}};var $0=0,On=new Ae,Kc=new qe,Ws=new L,Rn=new Hn,Br=new Hn,en=new L,Pe=class n extends Zi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:$0++}),this.uuid=ci(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(ad(t)?Ao:wo)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,i=0){this.groups.push({start:t,count:e,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let i=this.attributes.normal;if(i!==void 0){let r=new re().getNormalMatrix(t);i.applyNormalMatrix(r),i.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return On.makeRotationFromQuaternion(t),this.applyMatrix4(On),this}rotateX(t){return On.makeRotationX(t),this.applyMatrix4(On),this}rotateY(t){return On.makeRotationY(t),this.applyMatrix4(On),this}rotateZ(t){return On.makeRotationZ(t),this.applyMatrix4(On),this}translate(t,e,i){return On.makeTranslation(t,e,i),this.applyMatrix4(On),this}scale(t,e,i){return On.makeScale(t,e,i),this.applyMatrix4(On),this}lookAt(t){return Kc.lookAt(t),Kc.updateMatrix(),this.applyMatrix4(Kc.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ws).negate(),this.translate(Ws.x,Ws.y,Ws.z),this}setFromPoints(t){let e=[];for(let i=0,s=t.length;i<s;i++){let r=t[i];e.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new he(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Hn);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new L(-1/0,-1/0,-1/0),new L(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let i=0,s=e.length;i<s;i++){let r=e[i];Rn.setFromBufferAttribute(r),this.morphTargetsRelative?(en.addVectors(this.boundingBox.min,Rn.min),this.boundingBox.expandByPoint(en),en.addVectors(this.boundingBox.max,Rn.max),this.boundingBox.expandByPoint(en)):(this.boundingBox.expandByPoint(Rn.min),this.boundingBox.expandByPoint(Rn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ji);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new L,1/0);return}if(t){let i=this.boundingSphere.center;if(Rn.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){let o=e[r];Br.setFromBufferAttribute(o),this.morphTargetsRelative?(en.addVectors(Rn.min,Br.min),Rn.expandByPoint(en),en.addVectors(Rn.max,Br.max),Rn.expandByPoint(en)):(Rn.expandByPoint(Br.min),Rn.expandByPoint(Br.max))}Rn.getCenter(i);let s=0;for(let r=0,a=t.count;r<a;r++)en.fromBufferAttribute(t,r),s=Math.max(s,i.distanceToSquared(en));if(e)for(let r=0,a=e.length;r<a;r++){let o=e[r],c=this.morphTargetsRelative;for(let l=0,h=o.count;l<h;l++)en.fromBufferAttribute(o,l),c&&(Ws.fromBufferAttribute(t,l),en.add(Ws)),s=Math.max(s,i.distanceToSquared(en))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let i=t.array,s=e.position.array,r=e.normal.array,a=e.uv.array,o=s.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new fe(new Float32Array(4*o),4));let c=this.getAttribute("tangent").array,l=[],h=[];for(let M=0;M<o;M++)l[M]=new L,h[M]=new L;let u=new L,f=new L,d=new L,p=new ht,x=new ht,g=new ht,m=new L,S=new L;function y(M,I,N){u.fromArray(s,M*3),f.fromArray(s,I*3),d.fromArray(s,N*3),p.fromArray(a,M*2),x.fromArray(a,I*2),g.fromArray(a,N*2),f.sub(u),d.sub(u),x.sub(p),g.sub(p);let J=1/(x.x*g.y-g.x*x.y);isFinite(J)&&(m.copy(f).multiplyScalar(g.y).addScaledVector(d,-x.y).multiplyScalar(J),S.copy(d).multiplyScalar(x.x).addScaledVector(f,-g.x).multiplyScalar(J),l[M].add(m),l[I].add(m),l[N].add(m),h[M].add(S),h[I].add(S),h[N].add(S))}let b=this.groups;b.length===0&&(b=[{start:0,count:i.length}]);for(let M=0,I=b.length;M<I;++M){let N=b[M],J=N.start,P=N.count;for(let O=J,z=J+P;O<z;O+=3)y(i[O+0],i[O+1],i[O+2])}let C=new L,A=new L,w=new L,F=new L;function E(M){w.fromArray(r,M*3),F.copy(w);let I=l[M];C.copy(I),C.sub(w.multiplyScalar(w.dot(I))).normalize(),A.crossVectors(F,I);let J=A.dot(h[M])<0?-1:1;c[M*4]=C.x,c[M*4+1]=C.y,c[M*4+2]=C.z,c[M*4+3]=J}for(let M=0,I=b.length;M<I;++M){let N=b[M],J=N.start,P=N.count;for(let O=J,z=J+P;O<z;O+=3)E(i[O+0]),E(i[O+1]),E(i[O+2])}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new fe(new Float32Array(e.count*3),3),this.setAttribute("normal",i);else for(let f=0,d=i.count;f<d;f++)i.setXYZ(f,0,0,0);let s=new L,r=new L,a=new L,o=new L,c=new L,l=new L,h=new L,u=new L;if(t)for(let f=0,d=t.count;f<d;f+=3){let p=t.getX(f+0),x=t.getX(f+1),g=t.getX(f+2);s.fromBufferAttribute(e,p),r.fromBufferAttribute(e,x),a.fromBufferAttribute(e,g),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),o.fromBufferAttribute(i,p),c.fromBufferAttribute(i,x),l.fromBufferAttribute(i,g),o.add(h),c.add(h),l.add(h),i.setXYZ(p,o.x,o.y,o.z),i.setXYZ(x,c.x,c.y,c.z),i.setXYZ(g,l.x,l.y,l.z)}else for(let f=0,d=e.count;f<d;f+=3)s.fromBufferAttribute(e,f+0),r.fromBufferAttribute(e,f+1),a.fromBufferAttribute(e,f+2),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),i.setXYZ(f+0,h.x,h.y,h.z),i.setXYZ(f+1,h.x,h.y,h.z),i.setXYZ(f+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,i=t.count;e<i;e++)en.fromBufferAttribute(t,e),en.normalize(),t.setXYZ(e,en.x,en.y,en.z)}toNonIndexed(){function t(o,c){let l=o.array,h=o.itemSize,u=o.normalized,f=new l.constructor(c.length*h),d=0,p=0;for(let x=0,g=c.length;x<g;x++){o.isInterleavedBufferAttribute?d=c[x]*o.data.stride+o.offset:d=c[x]*h;for(let m=0;m<h;m++)f[p++]=l[d++]}return new fe(f,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new n,i=this.index.array,s=this.attributes;for(let o in s){let c=s[o],l=t(c,i);e.setAttribute(o,l)}let r=this.morphAttributes;for(let o in r){let c=[],l=r[o];for(let h=0,u=l.length;h<u;h++){let f=l[h],d=t(f,i);c.push(d)}e.morphAttributes[o]=c}e.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,c=a.length;o<c;o++){let l=a[o];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let c=this.parameters;for(let l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let i=this.attributes;for(let c in i){let l=i[c];t.data.attributes[c]=l.toJSON(t.data)}let s={},r=!1;for(let c in this.morphAttributes){let l=this.morphAttributes[c],h=[];for(let u=0,f=l.length;u<f;u++){let d=l[u];h.push(d.toJSON(t.data))}h.length>0&&(s[c]=h,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(t.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let i=t.index;i!==null&&this.setIndex(i.clone(e));let s=t.attributes;for(let l in s){let h=s[l];this.setAttribute(l,h.clone(e))}let r=t.morphAttributes;for(let l in r){let h=[],u=r[l];for(let f=0,d=u.length;f<d;f++)h.push(u[f].clone(e));this.morphAttributes[l]=h}this.morphTargetsRelative=t.morphTargetsRelative;let a=t.groups;for(let l=0,h=a.length;l<h;l++){let u=a[l];this.addGroup(u.start,u.count,u.materialIndex)}let o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());let c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},af=new Ae,os=new bo,Wa=new Ji,of=new L,Xs=new L,Ys=new L,$s=new L,jc=new L,Xa=new L,Ya=new ht,$a=new ht,qa=new ht,cf=new L,lf=new L,hf=new L,Za=new L,Ja=new L,Tt=class extends qe{constructor(t=new Pe,e=new Cn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){let s=e[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){let o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){let i=this.geometry,s=i.attributes.position,r=i.morphAttributes.position,a=i.morphTargetsRelative;e.fromBufferAttribute(s,t);let o=this.morphTargetInfluences;if(r&&o){Xa.set(0,0,0);for(let c=0,l=r.length;c<l;c++){let h=o[c],u=r[c];h!==0&&(jc.fromBufferAttribute(u,t),a?Xa.addScaledVector(jc,h):Xa.addScaledVector(jc.sub(e),h))}e.add(Xa)}return e}raycast(t,e){let i=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Wa.copy(i.boundingSphere),Wa.applyMatrix4(r),os.copy(t.ray).recast(t.near),!(Wa.containsPoint(os.origin)===!1&&(os.intersectSphere(Wa,of)===null||os.origin.distanceToSquared(of)>(t.far-t.near)**2))&&(af.copy(r).invert(),os.copy(t.ray).applyMatrix4(af),!(i.boundingBox!==null&&os.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(t,e,os)))}_computeIntersections(t,e,i){let s,r=this.geometry,a=this.material,o=r.index,c=r.attributes.position,l=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,f=r.groups,d=r.drawRange;if(o!==null)if(Array.isArray(a))for(let p=0,x=f.length;p<x;p++){let g=f[p],m=a[g.materialIndex],S=Math.max(g.start,d.start),y=Math.min(o.count,Math.min(g.start+g.count,d.start+d.count));for(let b=S,C=y;b<C;b+=3){let A=o.getX(b),w=o.getX(b+1),F=o.getX(b+2);s=Ka(this,m,t,i,l,h,u,A,w,F),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let p=Math.max(0,d.start),x=Math.min(o.count,d.start+d.count);for(let g=p,m=x;g<m;g+=3){let S=o.getX(g),y=o.getX(g+1),b=o.getX(g+2);s=Ka(this,a,t,i,l,h,u,S,y,b),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}else if(c!==void 0)if(Array.isArray(a))for(let p=0,x=f.length;p<x;p++){let g=f[p],m=a[g.materialIndex],S=Math.max(g.start,d.start),y=Math.min(c.count,Math.min(g.start+g.count,d.start+d.count));for(let b=S,C=y;b<C;b+=3){let A=b,w=b+1,F=b+2;s=Ka(this,m,t,i,l,h,u,A,w,F),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let p=Math.max(0,d.start),x=Math.min(c.count,d.start+d.count);for(let g=p,m=x;g<m;g+=3){let S=g,y=g+1,b=g+2;s=Ka(this,a,t,i,l,h,u,S,y,b),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}}};function q0(n,t,e,i,s,r,a,o){let c;if(t.side===fn?c=i.intersectTriangle(a,r,s,!0,o):c=i.intersectTriangle(s,r,a,t.side===$i,o),c===null)return null;Ja.copy(o),Ja.applyMatrix4(n.matrixWorld);let l=e.ray.origin.distanceTo(Ja);return l<e.near||l>e.far?null:{distance:l,point:Ja.clone(),object:n}}function Ka(n,t,e,i,s,r,a,o,c,l){n.getVertexPosition(o,Xs),n.getVertexPosition(c,Ys),n.getVertexPosition(l,$s);let h=q0(n,t,e,i,Xs,Ys,$s,Za);if(h){s&&(Ya.fromBufferAttribute(s,o),$a.fromBufferAttribute(s,c),qa.fromBufferAttribute(s,l),h.uv=fs.getInterpolation(Za,Xs,Ys,$s,Ya,$a,qa,new ht)),r&&(Ya.fromBufferAttribute(r,o),$a.fromBufferAttribute(r,c),qa.fromBufferAttribute(r,l),h.uv1=fs.getInterpolation(Za,Xs,Ys,$s,Ya,$a,qa,new ht),h.uv2=h.uv1),a&&(cf.fromBufferAttribute(a,o),lf.fromBufferAttribute(a,c),hf.fromBufferAttribute(a,l),h.normal=fs.getInterpolation(Za,Xs,Ys,$s,cf,lf,hf,new L),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));let u={a:o,b:c,c:l,normal:new L,materialIndex:0};fs.getNormal(Xs,Ys,$s,u.normal),h.face=u}return h}var pe=class n extends Pe{constructor(t=1,e=1,i=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:i,widthSegments:s,heightSegments:r,depthSegments:a};let o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);let c=[],l=[],h=[],u=[],f=0,d=0;p("z","y","x",-1,-1,i,e,t,a,r,0),p("z","y","x",1,-1,i,e,-t,a,r,1),p("x","z","y",1,1,t,i,e,s,a,2),p("x","z","y",1,-1,t,i,-e,s,a,3),p("x","y","z",1,-1,t,e,i,s,r,4),p("x","y","z",-1,-1,t,e,-i,s,r,5),this.setIndex(c),this.setAttribute("position",new he(l,3)),this.setAttribute("normal",new he(h,3)),this.setAttribute("uv",new he(u,2));function p(x,g,m,S,y,b,C,A,w,F,E){let M=b/w,I=C/F,N=b/2,J=C/2,P=A/2,O=w+1,z=F+1,Q=0,j=0,K=new L;for(let st=0;st<z;st++){let it=st*I-J;for(let xt=0;xt<O;xt++){let $=xt*M-N;K[x]=$*S,K[g]=it*y,K[m]=P,l.push(K.x,K.y,K.z),K[x]=0,K[g]=0,K[m]=A>0?1:-1,h.push(K.x,K.y,K.z),u.push(xt/w),u.push(1-st/F),Q+=1}}for(let st=0;st<F;st++)for(let it=0;it<w;it++){let xt=f+it+O*st,$=f+it+O*(st+1),et=f+(it+1)+O*(st+1),ut=f+(it+1)+O*st;c.push(xt,$,ut),c.push($,et,ut),j+=6}o.addGroup(d,j,E),d+=j,f+=Q}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function ur(n){let t={};for(let e in n){t[e]={};for(let i in n[e]){let s=n[e][i];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][i]=null):t[e][i]=s.clone():Array.isArray(s)?t[e][i]=s.slice():t[e][i]=s}}return t}function yn(n){let t={};for(let e=0;e<n.length;e++){let i=ur(n[e]);for(let s in i)t[s]=i[s]}return t}function Z0(n){let t=[];for(let e=0;e<n.length;e++)t.push(n[e].clone());return t}function cd(n){return n.getRenderTarget()===null?n.outputColorSpace:_e.workingColorSpace}var J0={clone:ur,merge:yn},K0=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,j0=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,kn=class extends wi{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=K0,this.fragmentShader=j0,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=ur(t.uniforms),this.uniformsGroups=Z0(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let a=this.uniforms[s].value;a&&a.isTexture?e.uniforms[s]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[s]={type:"m4",value:a.toArray()}:e.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let i={};for(let s in this.extensions)this.extensions[s]===!0&&(i[s]=!0);return Object.keys(i).length>0&&(e.extensions=i),e}},Ro=class extends qe{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Ae,this.projectionMatrix=new Ae,this.projectionMatrixInverse=new Ae,this.coordinateSystem=Si}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},_n=class extends Ro{constructor(t=50,e=1,i=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=i,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=ea*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(Xr*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return ea*2*Math.atan(Math.tan(Xr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,i,s,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(Xr*.5*this.fov)/this.zoom,i=2*e,s=this.aspect*i,r=-.5*s,a=this.view;if(this.view!==null&&this.view.enabled){let c=a.fullWidth,l=a.fullHeight;r+=a.offsetX*s/c,e-=a.offsetY*i/l,s*=a.width/c,i*=a.height/l}let o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-i,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},qs=-90,Zs=1,vl=class extends qe{constructor(t,e,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new _n(qs,Zs,t,e);s.layers=this.layers,this.add(s);let r=new _n(qs,Zs,t,e);r.layers=this.layers,this.add(r);let a=new _n(qs,Zs,t,e);a.layers=this.layers,this.add(a);let o=new _n(qs,Zs,t,e);o.layers=this.layers,this.add(o);let c=new _n(qs,Zs,t,e);c.layers=this.layers,this.add(c);let l=new _n(qs,Zs,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[i,s,r,a,o,c]=e;for(let l of e)this.remove(l);if(t===Si)i.up.set(0,1,0),i.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===yo)i.up.set(0,-1,0),i.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:i,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,a,o,c,l,h]=this.children,u=t.getRenderTarget(),f=t.getActiveCubeFace(),d=t.getActiveMipmapLevel(),p=t.xr.enabled;t.xr.enabled=!1;let x=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,t.setRenderTarget(i,0,s),t.render(e,r),t.setRenderTarget(i,1,s),t.render(e,a),t.setRenderTarget(i,2,s),t.render(e,o),t.setRenderTarget(i,3,s),t.render(e,c),t.setRenderTarget(i,4,s),t.render(e,l),i.texture.generateMipmaps=x,t.setRenderTarget(i,5,s),t.render(e,h),t.setRenderTarget(u,f,d),t.xr.enabled=p,i.texture.needsPMREMUpdate=!0}},Co=class extends Bn{constructor(t,e,i,s,r,a,o,c,l,h){t=t!==void 0?t:[],e=e!==void 0?e:or,super(t,e,i,s,r,a,o,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},Ml=class extends Ti{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let i={width:t,height:t,depth:1},s=[i,i,i,i,i,i];e.encoding!==void 0&&($r("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===ms?Ee:zn),this.texture=new Co(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:Fn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new pe(5,5,5),r=new kn({name:"CubemapFromEquirect",uniforms:ur(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:fn,blending:Vi});r.uniforms.tEquirect.value=e;let a=new Tt(s,r),o=e.minFilter;return e.minFilter===Qr&&(e.minFilter=Fn),new vl(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,i,s){let r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,i,s);t.setRenderTarget(r)}},Qc=new L,Q0=new L,tm=new re,Ei=class{constructor(t=new L(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,i,s){return this.normal.set(t,e,i),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,i){let s=Qc.subVectors(i,e).cross(Q0.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let i=t.delta(Qc),s=this.normal.dot(i);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(i,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),i=this.distanceToPoint(t.end);return e<0&&i>0||i<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let i=e||tm.getNormalMatrix(t),s=this.coplanarPoint(Qc).applyMatrix4(t),r=this.normal.applyMatrix3(i).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},cs=new Ji,ja=new L,na=class{constructor(t=new Ei,e=new Ei,i=new Ei,s=new Ei,r=new Ei,a=new Ei){this.planes=[t,e,i,s,r,a]}set(t,e,i,s,r,a){let o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(i),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(t){let e=this.planes;for(let i=0;i<6;i++)e[i].copy(t.planes[i]);return this}setFromProjectionMatrix(t,e=Si){let i=this.planes,s=t.elements,r=s[0],a=s[1],o=s[2],c=s[3],l=s[4],h=s[5],u=s[6],f=s[7],d=s[8],p=s[9],x=s[10],g=s[11],m=s[12],S=s[13],y=s[14],b=s[15];if(i[0].setComponents(c-r,f-l,g-d,b-m).normalize(),i[1].setComponents(c+r,f+l,g+d,b+m).normalize(),i[2].setComponents(c+a,f+h,g+p,b+S).normalize(),i[3].setComponents(c-a,f-h,g-p,b-S).normalize(),i[4].setComponents(c-o,f-u,g-x,b-y).normalize(),e===Si)i[5].setComponents(c+o,f+u,g+x,b+y).normalize();else if(e===yo)i[5].setComponents(o,u,x,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),cs.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),cs.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(cs)}intersectsSprite(t){return cs.center.set(0,0,0),cs.radius=.7071067811865476,cs.applyMatrix4(t.matrixWorld),this.intersectsSphere(cs)}intersectsSphere(t){let e=this.planes,i=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(i)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let i=0;i<6;i++){let s=e[i];if(ja.x=s.normal.x>0?t.max.x:t.min.x,ja.y=s.normal.y>0?t.max.y:t.min.y,ja.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(ja)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let i=0;i<6;i++)if(e[i].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function ld(){let n=null,t=!1,e=null,i=null;function s(r,a){e(r,a),i=n.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(i=n.requestAnimationFrame(s),t=!0)},stop:function(){n.cancelAnimationFrame(i),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){n=r}}}function em(n,t){let e=t.isWebGL2,i=new WeakMap;function s(l,h){let u=l.array,f=l.usage,d=u.byteLength,p=n.createBuffer();n.bindBuffer(h,p),n.bufferData(h,u,f),l.onUploadCallback();let x;if(u instanceof Float32Array)x=n.FLOAT;else if(u instanceof Uint16Array)if(l.isFloat16BufferAttribute)if(e)x=n.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else x=n.UNSIGNED_SHORT;else if(u instanceof Int16Array)x=n.SHORT;else if(u instanceof Uint32Array)x=n.UNSIGNED_INT;else if(u instanceof Int32Array)x=n.INT;else if(u instanceof Int8Array)x=n.BYTE;else if(u instanceof Uint8Array)x=n.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)x=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:p,type:x,bytesPerElement:u.BYTES_PER_ELEMENT,version:l.version,size:d}}function r(l,h,u){let f=h.array,d=h._updateRange,p=h.updateRanges;if(n.bindBuffer(u,l),d.count===-1&&p.length===0&&n.bufferSubData(u,0,f),p.length!==0){for(let x=0,g=p.length;x<g;x++){let m=p[x];e?n.bufferSubData(u,m.start*f.BYTES_PER_ELEMENT,f,m.start,m.count):n.bufferSubData(u,m.start*f.BYTES_PER_ELEMENT,f.subarray(m.start,m.start+m.count))}h.clearUpdateRanges()}d.count!==-1&&(e?n.bufferSubData(u,d.offset*f.BYTES_PER_ELEMENT,f,d.offset,d.count):n.bufferSubData(u,d.offset*f.BYTES_PER_ELEMENT,f.subarray(d.offset,d.offset+d.count)),d.count=-1),h.onUploadCallback()}function a(l){return l.isInterleavedBufferAttribute&&(l=l.data),i.get(l)}function o(l){l.isInterleavedBufferAttribute&&(l=l.data);let h=i.get(l);h&&(n.deleteBuffer(h.buffer),i.delete(l))}function c(l,h){if(l.isGLBufferAttribute){let f=i.get(l);(!f||f.version<l.version)&&i.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}l.isInterleavedBufferAttribute&&(l=l.data);let u=i.get(l);if(u===void 0)i.set(l,s(l,h));else if(u.version<l.version){if(u.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(u.buffer,l,h),u.version=l.version}}return{get:a,remove:o,update:c}}var on=class n extends Pe{constructor(t=1,e=1,i=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:i,heightSegments:s};let r=t/2,a=e/2,o=Math.floor(i),c=Math.floor(s),l=o+1,h=c+1,u=t/o,f=e/c,d=[],p=[],x=[],g=[];for(let m=0;m<h;m++){let S=m*f-a;for(let y=0;y<l;y++){let b=y*u-r;p.push(b,-S,0),x.push(0,0,1),g.push(y/o),g.push(1-m/c)}}for(let m=0;m<c;m++)for(let S=0;S<o;S++){let y=S+l*m,b=S+l*(m+1),C=S+1+l*(m+1),A=S+1+l*m;d.push(y,b,A),d.push(b,C,A)}this.setIndex(d),this.setAttribute("position",new he(p,3)),this.setAttribute("normal",new he(x,3)),this.setAttribute("uv",new he(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.width,t.height,t.widthSegments,t.heightSegments)}},nm=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,im=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,sm=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,rm=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,am=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,om=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,cm=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,lm=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,hm=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,um=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,fm=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,dm=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,pm=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,mm=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,gm=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,xm=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,ym=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,_m=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,vm=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Mm=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Em=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Sm=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,bm=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Tm=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,wm=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Am=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Rm=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Cm=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Pm=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Lm=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Im="gl_FragColor = linearToOutputTexel( gl_FragColor );",Dm=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Um=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Nm=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Om=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Fm=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,zm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Bm=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Hm=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,km=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Gm=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Vm=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Wm=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,Xm=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Ym=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,$m=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,qm=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Zm=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Jm=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Km=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,jm=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Qm=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,tg=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,eg=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,ng=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,ig=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,sg=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,rg=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,ag=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,og=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,cg=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,lg=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,hg=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,ug=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,fg=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,dg=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,pg=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,mg=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,gg=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,xg=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,yg=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,_g=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,vg=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Mg=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Eg=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Sg=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,bg=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Tg=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,wg=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Ag=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Rg=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Cg=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Pg=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Lg=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Ig=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Dg=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Ug=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Ng=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Og=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Fg=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,zg=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Bg=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Hg=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,kg=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Gg=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Vg=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Wg=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Xg=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Yg=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,$g=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,qg=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Zg=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Jg=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Kg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,jg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Qg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,tx=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,ex=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,nx=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ix=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,sx=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,rx=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,ax=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ox=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,cx=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,lx=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,hx=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,ux=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,fx=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,dx=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,px=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,mx=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,gx=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,xx=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,yx=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_x=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,vx=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Mx=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Ex=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Sx=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,bx=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tx=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,wx=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ax=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Rx=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Cx=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Px=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Lx=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ix=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Dx=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Ux=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Qt={alphahash_fragment:nm,alphahash_pars_fragment:im,alphamap_fragment:sm,alphamap_pars_fragment:rm,alphatest_fragment:am,alphatest_pars_fragment:om,aomap_fragment:cm,aomap_pars_fragment:lm,batching_pars_vertex:hm,batching_vertex:um,begin_vertex:fm,beginnormal_vertex:dm,bsdfs:pm,iridescence_fragment:mm,bumpmap_pars_fragment:gm,clipping_planes_fragment:xm,clipping_planes_pars_fragment:ym,clipping_planes_pars_vertex:_m,clipping_planes_vertex:vm,color_fragment:Mm,color_pars_fragment:Em,color_pars_vertex:Sm,color_vertex:bm,common:Tm,cube_uv_reflection_fragment:wm,defaultnormal_vertex:Am,displacementmap_pars_vertex:Rm,displacementmap_vertex:Cm,emissivemap_fragment:Pm,emissivemap_pars_fragment:Lm,colorspace_fragment:Im,colorspace_pars_fragment:Dm,envmap_fragment:Um,envmap_common_pars_fragment:Nm,envmap_pars_fragment:Om,envmap_pars_vertex:Fm,envmap_physical_pars_fragment:Zm,envmap_vertex:zm,fog_vertex:Bm,fog_pars_vertex:Hm,fog_fragment:km,fog_pars_fragment:Gm,gradientmap_pars_fragment:Vm,lightmap_fragment:Wm,lightmap_pars_fragment:Xm,lights_lambert_fragment:Ym,lights_lambert_pars_fragment:$m,lights_pars_begin:qm,lights_toon_fragment:Jm,lights_toon_pars_fragment:Km,lights_phong_fragment:jm,lights_phong_pars_fragment:Qm,lights_physical_fragment:tg,lights_physical_pars_fragment:eg,lights_fragment_begin:ng,lights_fragment_maps:ig,lights_fragment_end:sg,logdepthbuf_fragment:rg,logdepthbuf_pars_fragment:ag,logdepthbuf_pars_vertex:og,logdepthbuf_vertex:cg,map_fragment:lg,map_pars_fragment:hg,map_particle_fragment:ug,map_particle_pars_fragment:fg,metalnessmap_fragment:dg,metalnessmap_pars_fragment:pg,morphcolor_vertex:mg,morphnormal_vertex:gg,morphtarget_pars_vertex:xg,morphtarget_vertex:yg,normal_fragment_begin:_g,normal_fragment_maps:vg,normal_pars_fragment:Mg,normal_pars_vertex:Eg,normal_vertex:Sg,normalmap_pars_fragment:bg,clearcoat_normal_fragment_begin:Tg,clearcoat_normal_fragment_maps:wg,clearcoat_pars_fragment:Ag,iridescence_pars_fragment:Rg,opaque_fragment:Cg,packing:Pg,premultiplied_alpha_fragment:Lg,project_vertex:Ig,dithering_fragment:Dg,dithering_pars_fragment:Ug,roughnessmap_fragment:Ng,roughnessmap_pars_fragment:Og,shadowmap_pars_fragment:Fg,shadowmap_pars_vertex:zg,shadowmap_vertex:Bg,shadowmask_pars_fragment:Hg,skinbase_vertex:kg,skinning_pars_vertex:Gg,skinning_vertex:Vg,skinnormal_vertex:Wg,specularmap_fragment:Xg,specularmap_pars_fragment:Yg,tonemapping_fragment:$g,tonemapping_pars_fragment:qg,transmission_fragment:Zg,transmission_pars_fragment:Jg,uv_pars_fragment:Kg,uv_pars_vertex:jg,uv_vertex:Qg,worldpos_vertex:tx,background_vert:ex,background_frag:nx,backgroundCube_vert:ix,backgroundCube_frag:sx,cube_vert:rx,cube_frag:ax,depth_vert:ox,depth_frag:cx,distanceRGBA_vert:lx,distanceRGBA_frag:hx,equirect_vert:ux,equirect_frag:fx,linedashed_vert:dx,linedashed_frag:px,meshbasic_vert:mx,meshbasic_frag:gx,meshlambert_vert:xx,meshlambert_frag:yx,meshmatcap_vert:_x,meshmatcap_frag:vx,meshnormal_vert:Mx,meshnormal_frag:Ex,meshphong_vert:Sx,meshphong_frag:bx,meshphysical_vert:Tx,meshphysical_frag:wx,meshtoon_vert:Ax,meshtoon_frag:Rx,points_vert:Cx,points_frag:Px,shadow_vert:Lx,shadow_frag:Ix,sprite_vert:Dx,sprite_frag:Ux},dt={common:{diffuse:{value:new Ft(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new re},alphaMap:{value:null},alphaMapTransform:{value:new re},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new re}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new re}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new re}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new re},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new re},normalScale:{value:new ht(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new re},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new re}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new re}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new re}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ft(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ft(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new re},alphaTest:{value:0},uvTransform:{value:new re}},sprite:{diffuse:{value:new Ft(16777215)},opacity:{value:1},center:{value:new ht(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new re},alphaMap:{value:null},alphaMapTransform:{value:new re},alphaTest:{value:0}}},ai={basic:{uniforms:yn([dt.common,dt.specularmap,dt.envmap,dt.aomap,dt.lightmap,dt.fog]),vertexShader:Qt.meshbasic_vert,fragmentShader:Qt.meshbasic_frag},lambert:{uniforms:yn([dt.common,dt.specularmap,dt.envmap,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.fog,dt.lights,{emissive:{value:new Ft(0)}}]),vertexShader:Qt.meshlambert_vert,fragmentShader:Qt.meshlambert_frag},phong:{uniforms:yn([dt.common,dt.specularmap,dt.envmap,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.fog,dt.lights,{emissive:{value:new Ft(0)},specular:{value:new Ft(1118481)},shininess:{value:30}}]),vertexShader:Qt.meshphong_vert,fragmentShader:Qt.meshphong_frag},standard:{uniforms:yn([dt.common,dt.envmap,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.roughnessmap,dt.metalnessmap,dt.fog,dt.lights,{emissive:{value:new Ft(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Qt.meshphysical_vert,fragmentShader:Qt.meshphysical_frag},toon:{uniforms:yn([dt.common,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.gradientmap,dt.fog,dt.lights,{emissive:{value:new Ft(0)}}]),vertexShader:Qt.meshtoon_vert,fragmentShader:Qt.meshtoon_frag},matcap:{uniforms:yn([dt.common,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.fog,{matcap:{value:null}}]),vertexShader:Qt.meshmatcap_vert,fragmentShader:Qt.meshmatcap_frag},points:{uniforms:yn([dt.points,dt.fog]),vertexShader:Qt.points_vert,fragmentShader:Qt.points_frag},dashed:{uniforms:yn([dt.common,dt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Qt.linedashed_vert,fragmentShader:Qt.linedashed_frag},depth:{uniforms:yn([dt.common,dt.displacementmap]),vertexShader:Qt.depth_vert,fragmentShader:Qt.depth_frag},normal:{uniforms:yn([dt.common,dt.bumpmap,dt.normalmap,dt.displacementmap,{opacity:{value:1}}]),vertexShader:Qt.meshnormal_vert,fragmentShader:Qt.meshnormal_frag},sprite:{uniforms:yn([dt.sprite,dt.fog]),vertexShader:Qt.sprite_vert,fragmentShader:Qt.sprite_frag},background:{uniforms:{uvTransform:{value:new re},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Qt.background_vert,fragmentShader:Qt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Qt.backgroundCube_vert,fragmentShader:Qt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Qt.cube_vert,fragmentShader:Qt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Qt.equirect_vert,fragmentShader:Qt.equirect_frag},distanceRGBA:{uniforms:yn([dt.common,dt.displacementmap,{referencePosition:{value:new L},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Qt.distanceRGBA_vert,fragmentShader:Qt.distanceRGBA_frag},shadow:{uniforms:yn([dt.lights,dt.fog,{color:{value:new Ft(0)},opacity:{value:1}}]),vertexShader:Qt.shadow_vert,fragmentShader:Qt.shadow_frag}};ai.physical={uniforms:yn([ai.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new re},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new re},clearcoatNormalScale:{value:new ht(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new re},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new re},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new re},sheen:{value:0},sheenColor:{value:new Ft(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new re},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new re},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new re},transmissionSamplerSize:{value:new ht},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new re},attenuationDistance:{value:0},attenuationColor:{value:new Ft(0)},specularColor:{value:new Ft(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new re},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new re},anisotropyVector:{value:new ht},anisotropyMap:{value:null},anisotropyMapTransform:{value:new re}}]),vertexShader:Qt.meshphysical_vert,fragmentShader:Qt.meshphysical_frag};var Qa={r:0,b:0,g:0};function Nx(n,t,e,i,s,r,a){let o=new Ft(0),c=r===!0?0:1,l,h,u=null,f=0,d=null;function p(g,m){let S=!1,y=m.isScene===!0?m.background:null;y&&y.isTexture&&(y=(m.backgroundBlurriness>0?e:t).get(y)),y===null?x(o,c):y&&y.isColor&&(x(y,1),S=!0);let b=n.xr.getEnvironmentBlendMode();b==="additive"?i.buffers.color.setClear(0,0,0,1,a):b==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(n.autoClear||S)&&n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil),y&&(y.isCubeTexture||y.mapping===Yo)?(h===void 0&&(h=new Tt(new pe(1,1,1),new kn({name:"BackgroundCubeMaterial",uniforms:ur(ai.backgroundCube.uniforms),vertexShader:ai.backgroundCube.vertexShader,fragmentShader:ai.backgroundCube.fragmentShader,side:fn,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(C,A,w){this.matrixWorld.copyPosition(w.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),h.material.uniforms.envMap.value=y,h.material.uniforms.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=m.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,h.material.toneMapped=_e.getTransfer(y.colorSpace)!==Ce,(u!==y||f!==y.version||d!==n.toneMapping)&&(h.material.needsUpdate=!0,u=y,f=y.version,d=n.toneMapping),h.layers.enableAll(),g.unshift(h,h.geometry,h.material,0,0,null)):y&&y.isTexture&&(l===void 0&&(l=new Tt(new on(2,2),new kn({name:"BackgroundMaterial",uniforms:ur(ai.background.uniforms),vertexShader:ai.background.vertexShader,fragmentShader:ai.background.fragmentShader,side:$i,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(l)),l.material.uniforms.t2D.value=y,l.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,l.material.toneMapped=_e.getTransfer(y.colorSpace)!==Ce,y.matrixAutoUpdate===!0&&y.updateMatrix(),l.material.uniforms.uvTransform.value.copy(y.matrix),(u!==y||f!==y.version||d!==n.toneMapping)&&(l.material.needsUpdate=!0,u=y,f=y.version,d=n.toneMapping),l.layers.enableAll(),g.unshift(l,l.geometry,l.material,0,0,null))}function x(g,m){g.getRGB(Qa,cd(n)),i.buffers.color.setClear(Qa.r,Qa.g,Qa.b,m,a)}return{getClearColor:function(){return o},setClearColor:function(g,m=1){o.set(g),c=m,x(o,c)},getClearAlpha:function(){return c},setClearAlpha:function(g){c=g,x(o,c)},render:p}}function Ox(n,t,e,i){let s=n.getParameter(n.MAX_VERTEX_ATTRIBS),r=i.isWebGL2?null:t.get("OES_vertex_array_object"),a=i.isWebGL2||r!==null,o={},c=g(null),l=c,h=!1;function u(P,O,z,Q,j){let K=!1;if(a){let st=x(Q,z,O);l!==st&&(l=st,d(l.object)),K=m(P,Q,z,j),K&&S(P,Q,z,j)}else{let st=O.wireframe===!0;(l.geometry!==Q.id||l.program!==z.id||l.wireframe!==st)&&(l.geometry=Q.id,l.program=z.id,l.wireframe=st,K=!0)}j!==null&&e.update(j,n.ELEMENT_ARRAY_BUFFER),(K||h)&&(h=!1,F(P,O,z,Q),j!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,e.get(j).buffer))}function f(){return i.isWebGL2?n.createVertexArray():r.createVertexArrayOES()}function d(P){return i.isWebGL2?n.bindVertexArray(P):r.bindVertexArrayOES(P)}function p(P){return i.isWebGL2?n.deleteVertexArray(P):r.deleteVertexArrayOES(P)}function x(P,O,z){let Q=z.wireframe===!0,j=o[P.id];j===void 0&&(j={},o[P.id]=j);let K=j[O.id];K===void 0&&(K={},j[O.id]=K);let st=K[Q];return st===void 0&&(st=g(f()),K[Q]=st),st}function g(P){let O=[],z=[],Q=[];for(let j=0;j<s;j++)O[j]=0,z[j]=0,Q[j]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:O,enabledAttributes:z,attributeDivisors:Q,object:P,attributes:{},index:null}}function m(P,O,z,Q){let j=l.attributes,K=O.attributes,st=0,it=z.getAttributes();for(let xt in it)if(it[xt].location>=0){let et=j[xt],ut=K[xt];if(ut===void 0&&(xt==="instanceMatrix"&&P.instanceMatrix&&(ut=P.instanceMatrix),xt==="instanceColor"&&P.instanceColor&&(ut=P.instanceColor)),et===void 0||et.attribute!==ut||ut&&et.data!==ut.data)return!0;st++}return l.attributesNum!==st||l.index!==Q}function S(P,O,z,Q){let j={},K=O.attributes,st=0,it=z.getAttributes();for(let xt in it)if(it[xt].location>=0){let et=K[xt];et===void 0&&(xt==="instanceMatrix"&&P.instanceMatrix&&(et=P.instanceMatrix),xt==="instanceColor"&&P.instanceColor&&(et=P.instanceColor));let ut={};ut.attribute=et,et&&et.data&&(ut.data=et.data),j[xt]=ut,st++}l.attributes=j,l.attributesNum=st,l.index=Q}function y(){let P=l.newAttributes;for(let O=0,z=P.length;O<z;O++)P[O]=0}function b(P){C(P,0)}function C(P,O){let z=l.newAttributes,Q=l.enabledAttributes,j=l.attributeDivisors;z[P]=1,Q[P]===0&&(n.enableVertexAttribArray(P),Q[P]=1),j[P]!==O&&((i.isWebGL2?n:t.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](P,O),j[P]=O)}function A(){let P=l.newAttributes,O=l.enabledAttributes;for(let z=0,Q=O.length;z<Q;z++)O[z]!==P[z]&&(n.disableVertexAttribArray(z),O[z]=0)}function w(P,O,z,Q,j,K,st){st===!0?n.vertexAttribIPointer(P,O,z,j,K):n.vertexAttribPointer(P,O,z,Q,j,K)}function F(P,O,z,Q){if(i.isWebGL2===!1&&(P.isInstancedMesh||Q.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;y();let j=Q.attributes,K=z.getAttributes(),st=O.defaultAttributeValues;for(let it in K){let xt=K[it];if(xt.location>=0){let $=j[it];if($===void 0&&(it==="instanceMatrix"&&P.instanceMatrix&&($=P.instanceMatrix),it==="instanceColor"&&P.instanceColor&&($=P.instanceColor)),$!==void 0){let et=$.normalized,ut=$.itemSize,Lt=e.get($);if(Lt===void 0)continue;let St=Lt.buffer,Bt=Lt.type,nt=Lt.bytesPerElement,ct=i.isWebGL2===!0&&(Bt===n.INT||Bt===n.UNSIGNED_INT||$.gpuType===qf);if($.isInterleavedBufferAttribute){let gt=$.data,R=gt.stride,rt=$.offset;if(gt.isInstancedInterleavedBuffer){for(let Y=0;Y<xt.locationSize;Y++)C(xt.location+Y,gt.meshPerAttribute);P.isInstancedMesh!==!0&&Q._maxInstanceCount===void 0&&(Q._maxInstanceCount=gt.meshPerAttribute*gt.count)}else for(let Y=0;Y<xt.locationSize;Y++)b(xt.location+Y);n.bindBuffer(n.ARRAY_BUFFER,St);for(let Y=0;Y<xt.locationSize;Y++)w(xt.location+Y,ut/xt.locationSize,Bt,et,R*nt,(rt+ut/xt.locationSize*Y)*nt,ct)}else{if($.isInstancedBufferAttribute){for(let gt=0;gt<xt.locationSize;gt++)C(xt.location+gt,$.meshPerAttribute);P.isInstancedMesh!==!0&&Q._maxInstanceCount===void 0&&(Q._maxInstanceCount=$.meshPerAttribute*$.count)}else for(let gt=0;gt<xt.locationSize;gt++)b(xt.location+gt);n.bindBuffer(n.ARRAY_BUFFER,St);for(let gt=0;gt<xt.locationSize;gt++)w(xt.location+gt,ut/xt.locationSize,Bt,et,ut*nt,ut/xt.locationSize*gt*nt,ct)}}else if(st!==void 0){let et=st[it];if(et!==void 0)switch(et.length){case 2:n.vertexAttrib2fv(xt.location,et);break;case 3:n.vertexAttrib3fv(xt.location,et);break;case 4:n.vertexAttrib4fv(xt.location,et);break;default:n.vertexAttrib1fv(xt.location,et)}}}}A()}function E(){N();for(let P in o){let O=o[P];for(let z in O){let Q=O[z];for(let j in Q)p(Q[j].object),delete Q[j];delete O[z]}delete o[P]}}function M(P){if(o[P.id]===void 0)return;let O=o[P.id];for(let z in O){let Q=O[z];for(let j in Q)p(Q[j].object),delete Q[j];delete O[z]}delete o[P.id]}function I(P){for(let O in o){let z=o[O];if(z[P.id]===void 0)continue;let Q=z[P.id];for(let j in Q)p(Q[j].object),delete Q[j];delete z[P.id]}}function N(){J(),h=!0,l!==c&&(l=c,d(l.object))}function J(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:u,reset:N,resetDefaultState:J,dispose:E,releaseStatesOfGeometry:M,releaseStatesOfProgram:I,initAttributes:y,enableAttribute:b,disableUnusedAttributes:A}}function Fx(n,t,e,i){let s=i.isWebGL2,r;function a(h){r=h}function o(h,u){n.drawArrays(r,h,u),e.update(u,r,1)}function c(h,u,f){if(f===0)return;let d,p;if(s)d=n,p="drawArraysInstanced";else if(d=t.get("ANGLE_instanced_arrays"),p="drawArraysInstancedANGLE",d===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}d[p](r,h,u,f),e.update(u,r,f)}function l(h,u,f){if(f===0)return;let d=t.get("WEBGL_multi_draw");if(d===null)for(let p=0;p<f;p++)this.render(h[p],u[p]);else{d.multiDrawArraysWEBGL(r,h,0,u,0,f);let p=0;for(let x=0;x<f;x++)p+=u[x];e.update(p,r,1)}}this.setMode=a,this.render=o,this.renderInstances=c,this.renderMultiDraw=l}function zx(n,t,e){let i;function s(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){let w=t.get("EXT_texture_filter_anisotropic");i=n.getParameter(w.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function r(w){if(w==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";w="mediump"}return w==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let a=typeof WebGL2RenderingContext<"u"&&n.constructor.name==="WebGL2RenderingContext",o=e.precision!==void 0?e.precision:"highp",c=r(o);c!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",c,"instead."),o=c);let l=a||t.has("WEBGL_draw_buffers"),h=e.logarithmicDepthBuffer===!0,u=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),f=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),d=n.getParameter(n.MAX_TEXTURE_SIZE),p=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),x=n.getParameter(n.MAX_VERTEX_ATTRIBS),g=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),m=n.getParameter(n.MAX_VARYING_VECTORS),S=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),y=f>0,b=a||t.has("OES_texture_float"),C=y&&b,A=a?n.getParameter(n.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:l,getMaxAnisotropy:s,getMaxPrecision:r,precision:o,logarithmicDepthBuffer:h,maxTextures:u,maxVertexTextures:f,maxTextureSize:d,maxCubemapSize:p,maxAttributes:x,maxVertexUniforms:g,maxVaryings:m,maxFragmentUniforms:S,vertexTextures:y,floatFragmentTextures:b,floatVertexTextures:C,maxSamples:A}}function Bx(n){let t=this,e=null,i=0,s=!1,r=!1,a=new Ei,o=new re,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(u,f){let d=u.length!==0||f||i!==0||s;return s=f,i=u.length,d},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,f){e=h(u,f,0)},this.setState=function(u,f,d){let p=u.clippingPlanes,x=u.clipIntersection,g=u.clipShadows,m=n.get(u);if(!s||p===null||p.length===0||r&&!g)r?h(null):l();else{let S=r?0:i,y=S*4,b=m.clippingState||null;c.value=b,b=h(p,f,y,d);for(let C=0;C!==y;++C)b[C]=e[C];m.clippingState=b,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=S}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=i>0),t.numPlanes=i,t.numIntersection=0}function h(u,f,d,p){let x=u!==null?u.length:0,g=null;if(x!==0){if(g=c.value,p!==!0||g===null){let m=d+x*4,S=f.matrixWorldInverse;o.getNormalMatrix(S),(g===null||g.length<m)&&(g=new Float32Array(m));for(let y=0,b=d;y!==x;++y,b+=4)a.copy(u[y]).applyMatrix4(S,o),a.normal.toArray(g,b),g[b+3]=a.constant}c.value=g,c.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,g}}function Hx(n){let t=new WeakMap;function e(a,o){return o===fl?a.mapping=or:o===dl&&(a.mapping=cr),a}function i(a){if(a&&a.isTexture){let o=a.mapping;if(o===fl||o===dl)if(t.has(a)){let c=t.get(a).texture;return e(c,a.mapping)}else{let c=a.image;if(c&&c.height>0){let l=new Ml(c.height/2);return l.fromEquirectangularTexture(n,a),t.set(a,l),a.addEventListener("dispose",s),e(l.texture,a.mapping)}else return null}}return a}function s(a){let o=a.target;o.removeEventListener("dispose",s);let c=t.get(o);c!==void 0&&(t.delete(o),c.dispose())}function r(){t=new WeakMap}return{get:i,dispose:r}}var Po=class extends Ro{constructor(t=-1,e=1,i=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=i,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,i,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=i-t,a=i+t,o=s+e,c=s-e;if(this.view!==null&&this.view.enabled){let l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,a=r+l*this.view.width,o-=h*this.view.offsetY,c=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},nr=4,uf=[.125,.215,.35,.446,.526,.582],us=20,tl=new Po,ff=new Ft,el=null,nl=0,il=0,ls=(1+Math.sqrt(5))/2,Js=1/ls,df=[new L(1,1,1),new L(-1,1,1),new L(1,1,-1),new L(-1,1,-1),new L(0,ls,Js),new L(0,ls,-Js),new L(Js,0,ls),new L(-Js,0,ls),new L(ls,Js,0),new L(-ls,Js,0)],fr=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,i=.1,s=100){el=this._renderer.getRenderTarget(),nl=this._renderer.getActiveCubeFace(),il=this._renderer.getActiveMipmapLevel(),this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,i,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=gf(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=mf(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(el,nl,il),t.scissorTest=!1,to(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===or||t.mapping===cr?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),el=this._renderer.getRenderTarget(),nl=this._renderer.getActiveCubeFace(),il=this._renderer.getActiveMipmapLevel();let i=e||this._allocateTargets();return this._textureToCubeUV(t,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,i={magFilter:Fn,minFilter:Fn,generateMipmaps:!1,type:ta,format:jn,colorSpace:bi,depthBuffer:!1},s=pf(t,e,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=pf(t,e,i);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=kx(r)),this._blurMaterial=Gx(r,t,e)}return s}_compileMaterial(t){let e=new Tt(this._lodPlanes[0],t);this._renderer.compile(e,tl)}_sceneToCubeUV(t,e,i,s){let o=new _n(90,1,e,i),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,f=h.toneMapping;h.getClearColor(ff),h.toneMapping=Xi,h.autoClear=!1;let d=new Cn({name:"PMREM.Background",side:fn,depthWrite:!1,depthTest:!1}),p=new Tt(new pe,d),x=!1,g=t.background;g?g.isColor&&(d.color.copy(g),t.background=null,x=!0):(d.color.copy(ff),x=!0);for(let m=0;m<6;m++){let S=m%3;S===0?(o.up.set(0,c[m],0),o.lookAt(l[m],0,0)):S===1?(o.up.set(0,0,c[m]),o.lookAt(0,l[m],0)):(o.up.set(0,c[m],0),o.lookAt(0,0,l[m]));let y=this._cubeSize;to(s,S*y,m>2?y:0,y,y),h.setRenderTarget(s),x&&h.render(p,o),h.render(t,o)}p.geometry.dispose(),p.material.dispose(),h.toneMapping=f,h.autoClear=u,t.background=g}_textureToCubeUV(t,e){let i=this._renderer,s=t.mapping===or||t.mapping===cr;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=gf()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=mf());let r=s?this._cubemapMaterial:this._equirectMaterial,a=new Tt(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=t;let c=this._cubeSize;to(e,0,0,3*c,2*c),i.setRenderTarget(e),i.render(a,tl)}_applyPMREM(t){let e=this._renderer,i=e.autoClear;e.autoClear=!1;for(let s=1;s<this._lodPlanes.length;s++){let r=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),a=df[(s-1)%df.length];this._blur(t,s-1,s,r,a)}e.autoClear=i}_blur(t,e,i,s,r){let a=this._pingPongRenderTarget;this._halfBlur(t,a,e,i,s,"latitudinal",r),this._halfBlur(a,t,i,i,s,"longitudinal",r)}_halfBlur(t,e,i,s,r,a,o){let c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new Tt(this._lodPlanes[s],l),f=l.uniforms,d=this._sizeLods[i]-1,p=isFinite(r)?Math.PI/(2*d):2*Math.PI/(2*us-1),x=r/p,g=isFinite(r)?1+Math.floor(h*x):us;g>us&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${us}`);let m=[],S=0;for(let w=0;w<us;++w){let F=w/x,E=Math.exp(-F*F/2);m.push(E),w===0?S+=E:w<g&&(S+=2*E)}for(let w=0;w<m.length;w++)m[w]=m[w]/S;f.envMap.value=t.texture,f.samples.value=g,f.weights.value=m,f.latitudinal.value=a==="latitudinal",o&&(f.poleAxis.value=o);let{_lodMax:y}=this;f.dTheta.value=p,f.mipInt.value=y-i;let b=this._sizeLods[s],C=3*b*(s>y-nr?s-y+nr:0),A=4*(this._cubeSize-b);to(e,C,A,3*b,2*b),c.setRenderTarget(e),c.render(u,tl)}};function kx(n){let t=[],e=[],i=[],s=n,r=n-nr+1+uf.length;for(let a=0;a<r;a++){let o=Math.pow(2,s);e.push(o);let c=1/o;a>n-nr?c=uf[a-n+nr-1]:a===0&&(c=0),i.push(c);let l=1/(o-2),h=-l,u=1+l,f=[h,h,u,h,u,u,h,h,u,u,h,u],d=6,p=6,x=3,g=2,m=1,S=new Float32Array(x*p*d),y=new Float32Array(g*p*d),b=new Float32Array(m*p*d);for(let A=0;A<d;A++){let w=A%3*2/3-1,F=A>2?0:-1,E=[w,F,0,w+2/3,F,0,w+2/3,F+1,0,w,F,0,w+2/3,F+1,0,w,F+1,0];S.set(E,x*p*A),y.set(f,g*p*A);let M=[A,A,A,A,A,A];b.set(M,m*p*A)}let C=new Pe;C.setAttribute("position",new fe(S,x)),C.setAttribute("uv",new fe(y,g)),C.setAttribute("faceIndex",new fe(b,m)),t.push(C),s>nr&&s--}return{lodPlanes:t,sizeLods:e,sigmas:i}}function pf(n,t,e){let i=new Ti(n,t,e);return i.texture.mapping=Yo,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function to(n,t,e,i,s){n.viewport.set(t,e,i,s),n.scissor.set(t,e,i,s)}function Gx(n,t,e){let i=new Float32Array(us),s=new L(0,1,0);return new kn({name:"SphericalGaussianBlur",defines:{n:us,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Vi,depthTest:!1,depthWrite:!1})}function mf(){return new kn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Vi,depthTest:!1,depthWrite:!1})}function gf(){return new kn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Vi,depthTest:!1,depthWrite:!1})}function oh(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Vx(n){let t=new WeakMap,e=null;function i(o){if(o&&o.isTexture){let c=o.mapping,l=c===fl||c===dl,h=c===or||c===cr;if(l||h)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let u=t.get(o);return e===null&&(e=new fr(n)),u=l?e.fromEquirectangular(o,u):e.fromCubemap(o,u),t.set(o,u),u.texture}else{if(t.has(o))return t.get(o).texture;{let u=o.image;if(l&&u&&u.height>0||h&&u&&s(u)){e===null&&(e=new fr(n));let f=l?e.fromEquirectangular(o):e.fromCubemap(o);return t.set(o,f),o.addEventListener("dispose",r),f.texture}else return null}}}return o}function s(o){let c=0,l=6;for(let h=0;h<l;h++)o[h]!==void 0&&c++;return c===l}function r(o){let c=o.target;c.removeEventListener("dispose",r);let l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:i,dispose:a}}function Wx(n){let t={};function e(i){if(t[i]!==void 0)return t[i];let s;switch(i){case"WEBGL_depth_texture":s=n.getExtension("WEBGL_depth_texture")||n.getExtension("MOZ_WEBGL_depth_texture")||n.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=n.getExtension("EXT_texture_filter_anisotropic")||n.getExtension("MOZ_EXT_texture_filter_anisotropic")||n.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=n.getExtension("WEBGL_compressed_texture_s3tc")||n.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=n.getExtension("WEBGL_compressed_texture_pvrtc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=n.getExtension(i)}return t[i]=s,s}return{has:function(i){return e(i)!==null},init:function(i){i.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(i){let s=e(i);return s===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),s}}}function Xx(n,t,e,i){let s={},r=new WeakMap;function a(u){let f=u.target;f.index!==null&&t.remove(f.index);for(let p in f.attributes)t.remove(f.attributes[p]);for(let p in f.morphAttributes){let x=f.morphAttributes[p];for(let g=0,m=x.length;g<m;g++)t.remove(x[g])}f.removeEventListener("dispose",a),delete s[f.id];let d=r.get(f);d&&(t.remove(d),r.delete(f)),i.releaseStatesOfGeometry(f),f.isInstancedBufferGeometry===!0&&delete f._maxInstanceCount,e.memory.geometries--}function o(u,f){return s[f.id]===!0||(f.addEventListener("dispose",a),s[f.id]=!0,e.memory.geometries++),f}function c(u){let f=u.attributes;for(let p in f)t.update(f[p],n.ARRAY_BUFFER);let d=u.morphAttributes;for(let p in d){let x=d[p];for(let g=0,m=x.length;g<m;g++)t.update(x[g],n.ARRAY_BUFFER)}}function l(u){let f=[],d=u.index,p=u.attributes.position,x=0;if(d!==null){let S=d.array;x=d.version;for(let y=0,b=S.length;y<b;y+=3){let C=S[y+0],A=S[y+1],w=S[y+2];f.push(C,A,A,w,w,C)}}else if(p!==void 0){let S=p.array;x=p.version;for(let y=0,b=S.length/3-1;y<b;y+=3){let C=y+0,A=y+1,w=y+2;f.push(C,A,A,w,w,C)}}else return;let g=new(ad(f)?Ao:wo)(f,1);g.version=x;let m=r.get(u);m&&t.remove(m),r.set(u,g)}function h(u){let f=r.get(u);if(f){let d=u.index;d!==null&&f.version<d.version&&l(u)}else l(u);return r.get(u)}return{get:o,update:c,getWireframeAttribute:h}}function Yx(n,t,e,i){let s=i.isWebGL2,r;function a(d){r=d}let o,c;function l(d){o=d.type,c=d.bytesPerElement}function h(d,p){n.drawElements(r,p,o,d*c),e.update(p,r,1)}function u(d,p,x){if(x===0)return;let g,m;if(s)g=n,m="drawElementsInstanced";else if(g=t.get("ANGLE_instanced_arrays"),m="drawElementsInstancedANGLE",g===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}g[m](r,p,o,d*c,x),e.update(p,r,x)}function f(d,p,x){if(x===0)return;let g=t.get("WEBGL_multi_draw");if(g===null)for(let m=0;m<x;m++)this.render(d[m]/c,p[m]);else{g.multiDrawElementsWEBGL(r,p,0,o,d,0,x);let m=0;for(let S=0;S<x;S++)m+=p[S];e.update(m,r,1)}}this.setMode=a,this.setIndex=l,this.render=h,this.renderInstances=u,this.renderMultiDraw=f}function $x(n){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,a,o){switch(e.calls++,a){case n.TRIANGLES:e.triangles+=o*(r/3);break;case n.LINES:e.lines+=o*(r/2);break;case n.LINE_STRIP:e.lines+=o*(r-1);break;case n.LINE_LOOP:e.lines+=o*r;break;case n.POINTS:e.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:i}}function qx(n,t){return n[0]-t[0]}function Zx(n,t){return Math.abs(t[1])-Math.abs(n[1])}function Jx(n,t,e){let i={},s=new Float32Array(8),r=new WeakMap,a=new Ge,o=[];for(let l=0;l<8;l++)o[l]=[l,0];function c(l,h,u){let f=l.morphTargetInfluences;if(t.isWebGL2===!0){let d=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,p=d!==void 0?d.length:0,x=r.get(h);if(x===void 0||x.count!==p){let P=function(){N.dispose(),r.delete(h),h.removeEventListener("dispose",P)};x!==void 0&&x.texture.dispose();let S=h.morphAttributes.position!==void 0,y=h.morphAttributes.normal!==void 0,b=h.morphAttributes.color!==void 0,C=h.morphAttributes.position||[],A=h.morphAttributes.normal||[],w=h.morphAttributes.color||[],F=0;S===!0&&(F=1),y===!0&&(F=2),b===!0&&(F=3);let E=h.attributes.position.count*F,M=1;E>t.maxTextureSize&&(M=Math.ceil(E/t.maxTextureSize),E=t.maxTextureSize);let I=new Float32Array(E*M*4*p),N=new So(I,E,M,p);N.type=Gi,N.needsUpdate=!0;let J=F*4;for(let O=0;O<p;O++){let z=C[O],Q=A[O],j=w[O],K=E*M*4*O;for(let st=0;st<z.count;st++){let it=st*J;S===!0&&(a.fromBufferAttribute(z,st),I[K+it+0]=a.x,I[K+it+1]=a.y,I[K+it+2]=a.z,I[K+it+3]=0),y===!0&&(a.fromBufferAttribute(Q,st),I[K+it+4]=a.x,I[K+it+5]=a.y,I[K+it+6]=a.z,I[K+it+7]=0),b===!0&&(a.fromBufferAttribute(j,st),I[K+it+8]=a.x,I[K+it+9]=a.y,I[K+it+10]=a.z,I[K+it+11]=j.itemSize===4?a.w:1)}}x={count:p,texture:N,size:new ht(E,M)},r.set(h,x),h.addEventListener("dispose",P)}let g=0;for(let S=0;S<f.length;S++)g+=f[S];let m=h.morphTargetsRelative?1:1-g;u.getUniforms().setValue(n,"morphTargetBaseInfluence",m),u.getUniforms().setValue(n,"morphTargetInfluences",f),u.getUniforms().setValue(n,"morphTargetsTexture",x.texture,e),u.getUniforms().setValue(n,"morphTargetsTextureSize",x.size)}else{let d=f===void 0?0:f.length,p=i[h.id];if(p===void 0||p.length!==d){p=[];for(let y=0;y<d;y++)p[y]=[y,0];i[h.id]=p}for(let y=0;y<d;y++){let b=p[y];b[0]=y,b[1]=f[y]}p.sort(Zx);for(let y=0;y<8;y++)y<d&&p[y][1]?(o[y][0]=p[y][0],o[y][1]=p[y][1]):(o[y][0]=Number.MAX_SAFE_INTEGER,o[y][1]=0);o.sort(qx);let x=h.morphAttributes.position,g=h.morphAttributes.normal,m=0;for(let y=0;y<8;y++){let b=o[y],C=b[0],A=b[1];C!==Number.MAX_SAFE_INTEGER&&A?(x&&h.getAttribute("morphTarget"+y)!==x[C]&&h.setAttribute("morphTarget"+y,x[C]),g&&h.getAttribute("morphNormal"+y)!==g[C]&&h.setAttribute("morphNormal"+y,g[C]),s[y]=A,m+=A):(x&&h.hasAttribute("morphTarget"+y)===!0&&h.deleteAttribute("morphTarget"+y),g&&h.hasAttribute("morphNormal"+y)===!0&&h.deleteAttribute("morphNormal"+y),s[y]=0)}let S=h.morphTargetsRelative?1:1-m;u.getUniforms().setValue(n,"morphTargetBaseInfluence",S),u.getUniforms().setValue(n,"morphTargetInfluences",s)}}return{update:c}}function Kx(n,t,e,i){let s=new WeakMap;function r(c){let l=i.render.frame,h=c.geometry,u=t.get(c,h);if(s.get(u)!==l&&(t.update(u),s.set(u,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",o)===!1&&c.addEventListener("dispose",o),s.get(c)!==l&&(e.update(c.instanceMatrix,n.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,n.ARRAY_BUFFER),s.set(c,l))),c.isSkinnedMesh){let f=c.skeleton;s.get(f)!==l&&(f.update(),s.set(f,l))}return u}function a(){s=new WeakMap}function o(c){let l=c.target;l.removeEventListener("dispose",o),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:r,dispose:a}}var Lo=class extends Bn{constructor(t,e,i,s,r,a,o,c,l,h){if(h=h!==void 0?h:ps,h!==ps&&h!==lr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&h===ps&&(i=ki),i===void 0&&h===lr&&(i=ds),super(null,s,r,a,o,c,h,i,l),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=o!==void 0?o:nn,this.minFilter=c!==void 0?c:nn,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},hd=new Bn,ud=new Lo(1,1);ud.compareFunction=id;var fd=new So,dd=new _l,pd=new Co,xf=[],yf=[],_f=new Float32Array(16),vf=new Float32Array(9),Mf=new Float32Array(4);function xr(n,t,e){let i=n[0];if(i<=0||i>0)return n;let s=t*e,r=xf[s];if(r===void 0&&(r=new Float32Array(s),xf[s]=r),t!==0){i.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,n[a].toArray(r,o)}return r}function Ze(n,t){if(n.length!==t.length)return!1;for(let e=0,i=n.length;e<i;e++)if(n[e]!==t[e])return!1;return!0}function Je(n,t){for(let e=0,i=t.length;e<i;e++)n[e]=t[e]}function qo(n,t){let e=yf[t];e===void 0&&(e=new Int32Array(t),yf[t]=e);for(let i=0;i!==t;++i)e[i]=n.allocateTextureUnit();return e}function jx(n,t){let e=this.cache;e[0]!==t&&(n.uniform1f(this.addr,t),e[0]=t)}function Qx(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ze(e,t))return;n.uniform2fv(this.addr,t),Je(e,t)}}function ty(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(n.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Ze(e,t))return;n.uniform3fv(this.addr,t),Je(e,t)}}function ey(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ze(e,t))return;n.uniform4fv(this.addr,t),Je(e,t)}}function ny(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(Ze(e,t))return;n.uniformMatrix2fv(this.addr,!1,t),Je(e,t)}else{if(Ze(e,i))return;Mf.set(i),n.uniformMatrix2fv(this.addr,!1,Mf),Je(e,i)}}function iy(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(Ze(e,t))return;n.uniformMatrix3fv(this.addr,!1,t),Je(e,t)}else{if(Ze(e,i))return;vf.set(i),n.uniformMatrix3fv(this.addr,!1,vf),Je(e,i)}}function sy(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(Ze(e,t))return;n.uniformMatrix4fv(this.addr,!1,t),Je(e,t)}else{if(Ze(e,i))return;_f.set(i),n.uniformMatrix4fv(this.addr,!1,_f),Je(e,i)}}function ry(n,t){let e=this.cache;e[0]!==t&&(n.uniform1i(this.addr,t),e[0]=t)}function ay(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ze(e,t))return;n.uniform2iv(this.addr,t),Je(e,t)}}function oy(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ze(e,t))return;n.uniform3iv(this.addr,t),Je(e,t)}}function cy(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ze(e,t))return;n.uniform4iv(this.addr,t),Je(e,t)}}function ly(n,t){let e=this.cache;e[0]!==t&&(n.uniform1ui(this.addr,t),e[0]=t)}function hy(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ze(e,t))return;n.uniform2uiv(this.addr,t),Je(e,t)}}function uy(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ze(e,t))return;n.uniform3uiv(this.addr,t),Je(e,t)}}function fy(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ze(e,t))return;n.uniform4uiv(this.addr,t),Je(e,t)}}function dy(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s);let r=this.type===n.SAMPLER_2D_SHADOW?ud:hd;e.setTexture2D(t||r,s)}function py(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTexture3D(t||dd,s)}function my(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTextureCube(t||pd,s)}function gy(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTexture2DArray(t||fd,s)}function xy(n){switch(n){case 5126:return jx;case 35664:return Qx;case 35665:return ty;case 35666:return ey;case 35674:return ny;case 35675:return iy;case 35676:return sy;case 5124:case 35670:return ry;case 35667:case 35671:return ay;case 35668:case 35672:return oy;case 35669:case 35673:return cy;case 5125:return ly;case 36294:return hy;case 36295:return uy;case 36296:return fy;case 35678:case 36198:case 36298:case 36306:case 35682:return dy;case 35679:case 36299:case 36307:return py;case 35680:case 36300:case 36308:case 36293:return my;case 36289:case 36303:case 36311:case 36292:return gy}}function yy(n,t){n.uniform1fv(this.addr,t)}function _y(n,t){let e=xr(t,this.size,2);n.uniform2fv(this.addr,e)}function vy(n,t){let e=xr(t,this.size,3);n.uniform3fv(this.addr,e)}function My(n,t){let e=xr(t,this.size,4);n.uniform4fv(this.addr,e)}function Ey(n,t){let e=xr(t,this.size,4);n.uniformMatrix2fv(this.addr,!1,e)}function Sy(n,t){let e=xr(t,this.size,9);n.uniformMatrix3fv(this.addr,!1,e)}function by(n,t){let e=xr(t,this.size,16);n.uniformMatrix4fv(this.addr,!1,e)}function Ty(n,t){n.uniform1iv(this.addr,t)}function wy(n,t){n.uniform2iv(this.addr,t)}function Ay(n,t){n.uniform3iv(this.addr,t)}function Ry(n,t){n.uniform4iv(this.addr,t)}function Cy(n,t){n.uniform1uiv(this.addr,t)}function Py(n,t){n.uniform2uiv(this.addr,t)}function Ly(n,t){n.uniform3uiv(this.addr,t)}function Iy(n,t){n.uniform4uiv(this.addr,t)}function Dy(n,t,e){let i=this.cache,s=t.length,r=qo(e,s);Ze(i,r)||(n.uniform1iv(this.addr,r),Je(i,r));for(let a=0;a!==s;++a)e.setTexture2D(t[a]||hd,r[a])}function Uy(n,t,e){let i=this.cache,s=t.length,r=qo(e,s);Ze(i,r)||(n.uniform1iv(this.addr,r),Je(i,r));for(let a=0;a!==s;++a)e.setTexture3D(t[a]||dd,r[a])}function Ny(n,t,e){let i=this.cache,s=t.length,r=qo(e,s);Ze(i,r)||(n.uniform1iv(this.addr,r),Je(i,r));for(let a=0;a!==s;++a)e.setTextureCube(t[a]||pd,r[a])}function Oy(n,t,e){let i=this.cache,s=t.length,r=qo(e,s);Ze(i,r)||(n.uniform1iv(this.addr,r),Je(i,r));for(let a=0;a!==s;++a)e.setTexture2DArray(t[a]||fd,r[a])}function Fy(n){switch(n){case 5126:return yy;case 35664:return _y;case 35665:return vy;case 35666:return My;case 35674:return Ey;case 35675:return Sy;case 35676:return by;case 5124:case 35670:return Ty;case 35667:case 35671:return wy;case 35668:case 35672:return Ay;case 35669:case 35673:return Ry;case 5125:return Cy;case 36294:return Py;case 36295:return Ly;case 36296:return Iy;case 35678:case 36198:case 36298:case 36306:case 35682:return Dy;case 35679:case 36299:case 36307:return Uy;case 35680:case 36300:case 36308:case 36293:return Ny;case 36289:case 36303:case 36311:case 36292:return Oy}}var El=class{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.setValue=xy(e.type)}},Sl=class{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Fy(e.type)}},bl=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,i){let s=this.seq;for(let r=0,a=s.length;r!==a;++r){let o=s[r];o.setValue(t,e[o.id],i)}}},sl=/(\w+)(\])?(\[|\.)?/g;function Ef(n,t){n.seq.push(t),n.map[t.id]=t}function zy(n,t,e){let i=n.name,s=i.length;for(sl.lastIndex=0;;){let r=sl.exec(i),a=sl.lastIndex,o=r[1],c=r[2]==="]",l=r[3];if(c&&(o=o|0),l===void 0||l==="["&&a+2===s){Ef(e,l===void 0?new El(o,n,t):new Sl(o,n,t));break}else{let u=e.map[o];u===void 0&&(u=new bl(o),Ef(e,u)),e=u}}}var ar=class{constructor(t,e){this.seq=[],this.map={};let i=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<i;++s){let r=t.getActiveUniform(e,s),a=t.getUniformLocation(e,r.name);zy(r,a,this)}}setValue(t,e,i,s){let r=this.map[e];r!==void 0&&r.setValue(t,i,s)}setOptional(t,e,i){let s=e[i];s!==void 0&&this.setValue(t,i,s)}static upload(t,e,i,s){for(let r=0,a=e.length;r!==a;++r){let o=e[r],c=i[o.id];c.needsUpdate!==!1&&o.setValue(t,c.value,s)}}static seqWithValue(t,e){let i=[];for(let s=0,r=t.length;s!==r;++s){let a=t[s];a.id in e&&i.push(a)}return i}};function Sf(n,t,e){let i=n.createShader(t);return n.shaderSource(i,e),n.compileShader(i),i}var By=37297,Hy=0;function ky(n,t){let e=n.split(`
`),i=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=s;a<r;a++){let o=a+1;i.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return i.join(`
`)}function Gy(n){let t=_e.getPrimaries(_e.workingColorSpace),e=_e.getPrimaries(n),i;switch(t===e?i="":t===xo&&e===go?i="LinearDisplayP3ToLinearSRGB":t===go&&e===xo&&(i="LinearSRGBToLinearDisplayP3"),n){case bi:case $o:return[i,"LinearTransferOETF"];case Ee:case rh:return[i,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",n),[i,"LinearTransferOETF"]}}function bf(n,t,e){let i=n.getShaderParameter(t,n.COMPILE_STATUS),s=n.getShaderInfoLog(t).trim();if(i&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let a=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+ky(n.getShaderSource(t),a)}else return s}function Vy(n,t){let e=Gy(t);return`vec4 ${n}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function Wy(n,t){let e;switch(t){case Jp:e="Linear";break;case Kp:e="Reinhard";break;case jp:e="OptimizedCineon";break;case ih:e="ACESFilmic";break;case t0:e="AgX";break;case Qp:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+n+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function Xy(n){return[n.extensionDerivatives||n.envMapCubeUVHeight||n.bumpMap||n.normalMapTangentSpace||n.clearcoatNormalMap||n.flatShading||n.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(n.extensionFragDepth||n.logarithmicDepthBuffer)&&n.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",n.extensionDrawBuffers&&n.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(n.extensionShaderTextureLOD||n.envMap||n.transmission)&&n.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(ir).join(`
`)}function Yy(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(ir).join(`
`)}function $y(n){let t=[];for(let e in n){let i=n[e];i!==!1&&t.push("#define "+e+" "+i)}return t.join(`
`)}function qy(n,t){let e={},i=n.getProgramParameter(t,n.ACTIVE_ATTRIBUTES);for(let s=0;s<i;s++){let r=n.getActiveAttrib(t,s),a=r.name,o=1;r.type===n.FLOAT_MAT2&&(o=2),r.type===n.FLOAT_MAT3&&(o=3),r.type===n.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:n.getAttribLocation(t,a),locationSize:o}}return e}function ir(n){return n!==""}function Tf(n,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function wf(n,t){return n.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var Zy=/^[ \t]*#include +<([\w\d./]+)>/gm;function Tl(n){return n.replace(Zy,Ky)}var Jy=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function Ky(n,t){let e=Qt[t];if(e===void 0){let i=Jy.get(t);if(i!==void 0)e=Qt[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,i);else throw new Error("Can not resolve #include <"+t+">")}return Tl(e)}var jy=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Af(n){return n.replace(jy,Qy)}function Qy(n,t,e,i){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Rf(n){let t="precision "+n.precision+` float;
precision `+n.precision+" int;";return n.precision==="highp"?t+=`
#define HIGH_PRECISION`:n.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function t_(n){let t="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===Xf?t="SHADOWMAP_TYPE_PCF":n.shadowMapType===nh?t="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===Mi&&(t="SHADOWMAP_TYPE_VSM"),t}function e_(n){let t="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case or:case cr:t="ENVMAP_TYPE_CUBE";break;case Yo:t="ENVMAP_TYPE_CUBE_UV";break}return t}function n_(n){let t="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case cr:t="ENVMAP_MODE_REFRACTION";break}return t}function i_(n){let t="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case Yf:t="ENVMAP_BLENDING_MULTIPLY";break;case qp:t="ENVMAP_BLENDING_MIX";break;case Zp:t="ENVMAP_BLENDING_ADD";break}return t}function s_(n){let t=n.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,i=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:i,maxMip:e}}function r_(n,t,e,i){let s=n.getContext(),r=e.defines,a=e.vertexShader,o=e.fragmentShader,c=t_(e),l=e_(e),h=n_(e),u=i_(e),f=s_(e),d=e.isWebGL2?"":Xy(e),p=Yy(e),x=$y(r),g=s.createProgram(),m,S,y=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(ir).join(`
`),m.length>0&&(m+=`
`),S=[d,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(ir).join(`
`),S.length>0&&(S+=`
`)):(m=[Rf(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(ir).join(`
`),S=[d,Rf(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",f?"#define CUBEUV_TEXEL_WIDTH "+f.texelWidth:"",f?"#define CUBEUV_TEXEL_HEIGHT "+f.texelHeight:"",f?"#define CUBEUV_MAX_MIP "+f.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Xi?"#define TONE_MAPPING":"",e.toneMapping!==Xi?Qt.tonemapping_pars_fragment:"",e.toneMapping!==Xi?Wy("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Qt.colorspace_pars_fragment,Vy("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(ir).join(`
`)),a=Tl(a),a=Tf(a,e),a=wf(a,e),o=Tl(o),o=Tf(o,e),o=wf(o,e),a=Af(a),o=Af(o),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(y=`#version 300 es
`,m=[p,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,S=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===Yu?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Yu?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+S);let b=y+m+a,C=y+S+o,A=Sf(s,s.VERTEX_SHADER,b),w=Sf(s,s.FRAGMENT_SHADER,C);s.attachShader(g,A),s.attachShader(g,w),e.index0AttributeName!==void 0?s.bindAttribLocation(g,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(g,0,"position"),s.linkProgram(g);function F(N){if(n.debug.checkShaderErrors){let J=s.getProgramInfoLog(g).trim(),P=s.getShaderInfoLog(A).trim(),O=s.getShaderInfoLog(w).trim(),z=!0,Q=!0;if(s.getProgramParameter(g,s.LINK_STATUS)===!1)if(z=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(s,g,A,w);else{let j=bf(s,A,"vertex"),K=bf(s,w,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(g,s.VALIDATE_STATUS)+`

Program Info Log: `+J+`
`+j+`
`+K)}else J!==""?console.warn("THREE.WebGLProgram: Program Info Log:",J):(P===""||O==="")&&(Q=!1);Q&&(N.diagnostics={runnable:z,programLog:J,vertexShader:{log:P,prefix:m},fragmentShader:{log:O,prefix:S}})}s.deleteShader(A),s.deleteShader(w),E=new ar(s,g),M=qy(s,g)}let E;this.getUniforms=function(){return E===void 0&&F(this),E};let M;this.getAttributes=function(){return M===void 0&&F(this),M};let I=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return I===!1&&(I=s.getProgramParameter(g,By)),I},this.destroy=function(){i.releaseStatesOfProgram(this),s.deleteProgram(g),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Hy++,this.cacheKey=t,this.usedTimes=1,this.program=g,this.vertexShader=A,this.fragmentShader=w,this}var a_=0,wl=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,i=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(i),a=this._getShaderCacheForMaterial(t);return a.has(s)===!1&&(a.add(s),s.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let i of e)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,i=e.get(t);return i===void 0&&(i=new Set,e.set(t,i)),i}_getShaderStage(t){let e=this.shaderCache,i=e.get(t);return i===void 0&&(i=new Al(t),e.set(t,i)),i}},Al=class{constructor(t){this.id=a_++,this.code=t,this.usedTimes=0}};function o_(n,t,e,i,s,r,a){let o=new To,c=new wl,l=[],h=s.isWebGL2,u=s.logarithmicDepthBuffer,f=s.vertexTextures,d=s.precision,p={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(E){return E===0?"uv":`uv${E}`}function g(E,M,I,N,J){let P=N.fog,O=J.geometry,z=E.isMeshStandardMaterial?N.environment:null,Q=(E.isMeshStandardMaterial?e:t).get(E.envMap||z),j=Q&&Q.mapping===Yo?Q.image.height:null,K=p[E.type];E.precision!==null&&(d=s.getMaxPrecision(E.precision),d!==E.precision&&console.warn("THREE.WebGLProgram.getParameters:",E.precision,"not supported, using",d,"instead."));let st=O.morphAttributes.position||O.morphAttributes.normal||O.morphAttributes.color,it=st!==void 0?st.length:0,xt=0;O.morphAttributes.position!==void 0&&(xt=1),O.morphAttributes.normal!==void 0&&(xt=2),O.morphAttributes.color!==void 0&&(xt=3);let $,et,ut,Lt;if(K){let mn=ai[K];$=mn.vertexShader,et=mn.fragmentShader}else $=E.vertexShader,et=E.fragmentShader,c.update(E),ut=c.getVertexShaderID(E),Lt=c.getFragmentShaderID(E);let St=n.getRenderTarget(),Bt=J.isInstancedMesh===!0,nt=J.isBatchedMesh===!0,ct=!!E.map,gt=!!E.matcap,R=!!Q,rt=!!E.aoMap,Y=!!E.lightMap,tt=!!E.bumpMap,q=!!E.normalMap,Ct=!!E.displacementMap,yt=!!E.emissiveMap,v=!!E.metalnessMap,_=!!E.roughnessMap,D=E.anisotropy>0,k=E.clearcoat>0,W=E.iridescence>0,Z=E.sheen>0,bt=E.transmission>0,lt=D&&!!E.anisotropyMap,wt=k&&!!E.clearcoatMap,zt=k&&!!E.clearcoatNormalMap,qt=k&&!!E.clearcoatRoughnessMap,at=W&&!!E.iridescenceMap,de=W&&!!E.iridescenceThicknessMap,ae=Z&&!!E.sheenColorMap,Zt=Z&&!!E.sheenRoughnessMap,Ht=!!E.specularMap,Dt=!!E.specularColorMap,jt=!!E.specularIntensityMap,xe=bt&&!!E.transmissionMap,Ne=bt&&!!E.thicknessMap,ie=!!E.gradientMap,ft=!!E.alphaMap,U=E.alphaTest>0,Mt=!!E.alphaHash,Et=!!E.extensions,Xt=!!O.attributes.uv1,Gt=!!O.attributes.uv2,be=!!O.attributes.uv3,Te=Xi;return E.toneMapped&&(St===null||St.isXRRenderTarget===!0)&&(Te=n.toneMapping),{isWebGL2:h,shaderID:K,shaderType:E.type,shaderName:E.name,vertexShader:$,fragmentShader:et,defines:E.defines,customVertexShaderID:ut,customFragmentShaderID:Lt,isRawShaderMaterial:E.isRawShaderMaterial===!0,glslVersion:E.glslVersion,precision:d,batching:nt,instancing:Bt,instancingColor:Bt&&J.instanceColor!==null,supportsVertexTextures:f,outputColorSpace:St===null?n.outputColorSpace:St.isXRRenderTarget===!0?St.texture.colorSpace:bi,map:ct,matcap:gt,envMap:R,envMapMode:R&&Q.mapping,envMapCubeUVHeight:j,aoMap:rt,lightMap:Y,bumpMap:tt,normalMap:q,displacementMap:f&&Ct,emissiveMap:yt,normalMapObjectSpace:q&&E.normalMapType===f0,normalMapTangentSpace:q&&E.normalMapType===nd,metalnessMap:v,roughnessMap:_,anisotropy:D,anisotropyMap:lt,clearcoat:k,clearcoatMap:wt,clearcoatNormalMap:zt,clearcoatRoughnessMap:qt,iridescence:W,iridescenceMap:at,iridescenceThicknessMap:de,sheen:Z,sheenColorMap:ae,sheenRoughnessMap:Zt,specularMap:Ht,specularColorMap:Dt,specularIntensityMap:jt,transmission:bt,transmissionMap:xe,thicknessMap:Ne,gradientMap:ie,opaque:E.transparent===!1&&E.blending===Wi,alphaMap:ft,alphaTest:U,alphaHash:Mt,combine:E.combine,mapUv:ct&&x(E.map.channel),aoMapUv:rt&&x(E.aoMap.channel),lightMapUv:Y&&x(E.lightMap.channel),bumpMapUv:tt&&x(E.bumpMap.channel),normalMapUv:q&&x(E.normalMap.channel),displacementMapUv:Ct&&x(E.displacementMap.channel),emissiveMapUv:yt&&x(E.emissiveMap.channel),metalnessMapUv:v&&x(E.metalnessMap.channel),roughnessMapUv:_&&x(E.roughnessMap.channel),anisotropyMapUv:lt&&x(E.anisotropyMap.channel),clearcoatMapUv:wt&&x(E.clearcoatMap.channel),clearcoatNormalMapUv:zt&&x(E.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:qt&&x(E.clearcoatRoughnessMap.channel),iridescenceMapUv:at&&x(E.iridescenceMap.channel),iridescenceThicknessMapUv:de&&x(E.iridescenceThicknessMap.channel),sheenColorMapUv:ae&&x(E.sheenColorMap.channel),sheenRoughnessMapUv:Zt&&x(E.sheenRoughnessMap.channel),specularMapUv:Ht&&x(E.specularMap.channel),specularColorMapUv:Dt&&x(E.specularColorMap.channel),specularIntensityMapUv:jt&&x(E.specularIntensityMap.channel),transmissionMapUv:xe&&x(E.transmissionMap.channel),thicknessMapUv:Ne&&x(E.thicknessMap.channel),alphaMapUv:ft&&x(E.alphaMap.channel),vertexTangents:!!O.attributes.tangent&&(q||D),vertexColors:E.vertexColors,vertexAlphas:E.vertexColors===!0&&!!O.attributes.color&&O.attributes.color.itemSize===4,vertexUv1s:Xt,vertexUv2s:Gt,vertexUv3s:be,pointsUvs:J.isPoints===!0&&!!O.attributes.uv&&(ct||ft),fog:!!P,useFog:E.fog===!0,fogExp2:P&&P.isFogExp2,flatShading:E.flatShading===!0,sizeAttenuation:E.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:J.isSkinnedMesh===!0,morphTargets:O.morphAttributes.position!==void 0,morphNormals:O.morphAttributes.normal!==void 0,morphColors:O.morphAttributes.color!==void 0,morphTargetsCount:it,morphTextureStride:xt,numDirLights:M.directional.length,numPointLights:M.point.length,numSpotLights:M.spot.length,numSpotLightMaps:M.spotLightMap.length,numRectAreaLights:M.rectArea.length,numHemiLights:M.hemi.length,numDirLightShadows:M.directionalShadowMap.length,numPointLightShadows:M.pointShadowMap.length,numSpotLightShadows:M.spotShadowMap.length,numSpotLightShadowsWithMaps:M.numSpotLightShadowsWithMaps,numLightProbes:M.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:E.dithering,shadowMapEnabled:n.shadowMap.enabled&&I.length>0,shadowMapType:n.shadowMap.type,toneMapping:Te,useLegacyLights:n._useLegacyLights,decodeVideoTexture:ct&&E.map.isVideoTexture===!0&&_e.getTransfer(E.map.colorSpace)===Ce,premultipliedAlpha:E.premultipliedAlpha,doubleSided:E.side===Fe,flipSided:E.side===fn,useDepthPacking:E.depthPacking>=0,depthPacking:E.depthPacking||0,index0AttributeName:E.index0AttributeName,extensionDerivatives:Et&&E.extensions.derivatives===!0,extensionFragDepth:Et&&E.extensions.fragDepth===!0,extensionDrawBuffers:Et&&E.extensions.drawBuffers===!0,extensionShaderTextureLOD:Et&&E.extensions.shaderTextureLOD===!0,extensionClipCullDistance:Et&&E.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:E.customProgramCacheKey()}}function m(E){let M=[];if(E.shaderID?M.push(E.shaderID):(M.push(E.customVertexShaderID),M.push(E.customFragmentShaderID)),E.defines!==void 0)for(let I in E.defines)M.push(I),M.push(E.defines[I]);return E.isRawShaderMaterial===!1&&(S(M,E),y(M,E),M.push(n.outputColorSpace)),M.push(E.customProgramCacheKey),M.join()}function S(E,M){E.push(M.precision),E.push(M.outputColorSpace),E.push(M.envMapMode),E.push(M.envMapCubeUVHeight),E.push(M.mapUv),E.push(M.alphaMapUv),E.push(M.lightMapUv),E.push(M.aoMapUv),E.push(M.bumpMapUv),E.push(M.normalMapUv),E.push(M.displacementMapUv),E.push(M.emissiveMapUv),E.push(M.metalnessMapUv),E.push(M.roughnessMapUv),E.push(M.anisotropyMapUv),E.push(M.clearcoatMapUv),E.push(M.clearcoatNormalMapUv),E.push(M.clearcoatRoughnessMapUv),E.push(M.iridescenceMapUv),E.push(M.iridescenceThicknessMapUv),E.push(M.sheenColorMapUv),E.push(M.sheenRoughnessMapUv),E.push(M.specularMapUv),E.push(M.specularColorMapUv),E.push(M.specularIntensityMapUv),E.push(M.transmissionMapUv),E.push(M.thicknessMapUv),E.push(M.combine),E.push(M.fogExp2),E.push(M.sizeAttenuation),E.push(M.morphTargetsCount),E.push(M.morphAttributeCount),E.push(M.numDirLights),E.push(M.numPointLights),E.push(M.numSpotLights),E.push(M.numSpotLightMaps),E.push(M.numHemiLights),E.push(M.numRectAreaLights),E.push(M.numDirLightShadows),E.push(M.numPointLightShadows),E.push(M.numSpotLightShadows),E.push(M.numSpotLightShadowsWithMaps),E.push(M.numLightProbes),E.push(M.shadowMapType),E.push(M.toneMapping),E.push(M.numClippingPlanes),E.push(M.numClipIntersection),E.push(M.depthPacking)}function y(E,M){o.disableAll(),M.isWebGL2&&o.enable(0),M.supportsVertexTextures&&o.enable(1),M.instancing&&o.enable(2),M.instancingColor&&o.enable(3),M.matcap&&o.enable(4),M.envMap&&o.enable(5),M.normalMapObjectSpace&&o.enable(6),M.normalMapTangentSpace&&o.enable(7),M.clearcoat&&o.enable(8),M.iridescence&&o.enable(9),M.alphaTest&&o.enable(10),M.vertexColors&&o.enable(11),M.vertexAlphas&&o.enable(12),M.vertexUv1s&&o.enable(13),M.vertexUv2s&&o.enable(14),M.vertexUv3s&&o.enable(15),M.vertexTangents&&o.enable(16),M.anisotropy&&o.enable(17),M.alphaHash&&o.enable(18),M.batching&&o.enable(19),E.push(o.mask),o.disableAll(),M.fog&&o.enable(0),M.useFog&&o.enable(1),M.flatShading&&o.enable(2),M.logarithmicDepthBuffer&&o.enable(3),M.skinning&&o.enable(4),M.morphTargets&&o.enable(5),M.morphNormals&&o.enable(6),M.morphColors&&o.enable(7),M.premultipliedAlpha&&o.enable(8),M.shadowMapEnabled&&o.enable(9),M.useLegacyLights&&o.enable(10),M.doubleSided&&o.enable(11),M.flipSided&&o.enable(12),M.useDepthPacking&&o.enable(13),M.dithering&&o.enable(14),M.transmission&&o.enable(15),M.sheen&&o.enable(16),M.opaque&&o.enable(17),M.pointsUvs&&o.enable(18),M.decodeVideoTexture&&o.enable(19),E.push(o.mask)}function b(E){let M=p[E.type],I;if(M){let N=ai[M];I=J0.clone(N.uniforms)}else I=E.uniforms;return I}function C(E,M){let I;for(let N=0,J=l.length;N<J;N++){let P=l[N];if(P.cacheKey===M){I=P,++I.usedTimes;break}}return I===void 0&&(I=new r_(n,M,E,r),l.push(I)),I}function A(E){if(--E.usedTimes===0){let M=l.indexOf(E);l[M]=l[l.length-1],l.pop(),E.destroy()}}function w(E){c.remove(E)}function F(){c.dispose()}return{getParameters:g,getProgramCacheKey:m,getUniforms:b,acquireProgram:C,releaseProgram:A,releaseShaderCache:w,programs:l,dispose:F}}function c_(){let n=new WeakMap;function t(r){let a=n.get(r);return a===void 0&&(a={},n.set(r,a)),a}function e(r){n.delete(r)}function i(r,a,o){n.get(r)[a]=o}function s(){n=new WeakMap}return{get:t,remove:e,update:i,dispose:s}}function l_(n,t){return n.groupOrder!==t.groupOrder?n.groupOrder-t.groupOrder:n.renderOrder!==t.renderOrder?n.renderOrder-t.renderOrder:n.material.id!==t.material.id?n.material.id-t.material.id:n.z!==t.z?n.z-t.z:n.id-t.id}function Cf(n,t){return n.groupOrder!==t.groupOrder?n.groupOrder-t.groupOrder:n.renderOrder!==t.renderOrder?n.renderOrder-t.renderOrder:n.z!==t.z?t.z-n.z:n.id-t.id}function Pf(){let n=[],t=0,e=[],i=[],s=[];function r(){t=0,e.length=0,i.length=0,s.length=0}function a(u,f,d,p,x,g){let m=n[t];return m===void 0?(m={id:u.id,object:u,geometry:f,material:d,groupOrder:p,renderOrder:u.renderOrder,z:x,group:g},n[t]=m):(m.id=u.id,m.object=u,m.geometry=f,m.material=d,m.groupOrder=p,m.renderOrder=u.renderOrder,m.z=x,m.group=g),t++,m}function o(u,f,d,p,x,g){let m=a(u,f,d,p,x,g);d.transmission>0?i.push(m):d.transparent===!0?s.push(m):e.push(m)}function c(u,f,d,p,x,g){let m=a(u,f,d,p,x,g);d.transmission>0?i.unshift(m):d.transparent===!0?s.unshift(m):e.unshift(m)}function l(u,f){e.length>1&&e.sort(u||l_),i.length>1&&i.sort(f||Cf),s.length>1&&s.sort(f||Cf)}function h(){for(let u=t,f=n.length;u<f;u++){let d=n[u];if(d.id===null)break;d.id=null,d.object=null,d.geometry=null,d.material=null,d.group=null}}return{opaque:e,transmissive:i,transparent:s,init:r,push:o,unshift:c,finish:h,sort:l}}function h_(){let n=new WeakMap;function t(i,s){let r=n.get(i),a;return r===void 0?(a=new Pf,n.set(i,[a])):s>=r.length?(a=new Pf,r.push(a)):a=r[s],a}function e(){n=new WeakMap}return{get:t,dispose:e}}function u_(){let n={};return{get:function(t){if(n[t.id]!==void 0)return n[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new L,color:new Ft};break;case"SpotLight":e={position:new L,direction:new L,color:new Ft,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new L,color:new Ft,distance:0,decay:0};break;case"HemisphereLight":e={direction:new L,skyColor:new Ft,groundColor:new Ft};break;case"RectAreaLight":e={color:new Ft,position:new L,halfWidth:new L,halfHeight:new L};break}return n[t.id]=e,e}}}function f_(){let n={};return{get:function(t){if(n[t.id]!==void 0)return n[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[t.id]=e,e}}}var d_=0;function p_(n,t){return(t.castShadow?2:0)-(n.castShadow?2:0)+(t.map?1:0)-(n.map?1:0)}function m_(n,t){let e=new u_,i=f_(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)s.probe.push(new L);let r=new L,a=new Ae,o=new Ae;function c(h,u){let f=0,d=0,p=0;for(let N=0;N<9;N++)s.probe[N].set(0,0,0);let x=0,g=0,m=0,S=0,y=0,b=0,C=0,A=0,w=0,F=0,E=0;h.sort(p_);let M=u===!0?Math.PI:1;for(let N=0,J=h.length;N<J;N++){let P=h[N],O=P.color,z=P.intensity,Q=P.distance,j=P.shadow&&P.shadow.map?P.shadow.map.texture:null;if(P.isAmbientLight)f+=O.r*z*M,d+=O.g*z*M,p+=O.b*z*M;else if(P.isLightProbe){for(let K=0;K<9;K++)s.probe[K].addScaledVector(P.sh.coefficients[K],z);E++}else if(P.isDirectionalLight){let K=e.get(P);if(K.color.copy(P.color).multiplyScalar(P.intensity*M),P.castShadow){let st=P.shadow,it=i.get(P);it.shadowBias=st.bias,it.shadowNormalBias=st.normalBias,it.shadowRadius=st.radius,it.shadowMapSize=st.mapSize,s.directionalShadow[x]=it,s.directionalShadowMap[x]=j,s.directionalShadowMatrix[x]=P.shadow.matrix,b++}s.directional[x]=K,x++}else if(P.isSpotLight){let K=e.get(P);K.position.setFromMatrixPosition(P.matrixWorld),K.color.copy(O).multiplyScalar(z*M),K.distance=Q,K.coneCos=Math.cos(P.angle),K.penumbraCos=Math.cos(P.angle*(1-P.penumbra)),K.decay=P.decay,s.spot[m]=K;let st=P.shadow;if(P.map&&(s.spotLightMap[w]=P.map,w++,st.updateMatrices(P),P.castShadow&&F++),s.spotLightMatrix[m]=st.matrix,P.castShadow){let it=i.get(P);it.shadowBias=st.bias,it.shadowNormalBias=st.normalBias,it.shadowRadius=st.radius,it.shadowMapSize=st.mapSize,s.spotShadow[m]=it,s.spotShadowMap[m]=j,A++}m++}else if(P.isRectAreaLight){let K=e.get(P);K.color.copy(O).multiplyScalar(z),K.halfWidth.set(P.width*.5,0,0),K.halfHeight.set(0,P.height*.5,0),s.rectArea[S]=K,S++}else if(P.isPointLight){let K=e.get(P);if(K.color.copy(P.color).multiplyScalar(P.intensity*M),K.distance=P.distance,K.decay=P.decay,P.castShadow){let st=P.shadow,it=i.get(P);it.shadowBias=st.bias,it.shadowNormalBias=st.normalBias,it.shadowRadius=st.radius,it.shadowMapSize=st.mapSize,it.shadowCameraNear=st.camera.near,it.shadowCameraFar=st.camera.far,s.pointShadow[g]=it,s.pointShadowMap[g]=j,s.pointShadowMatrix[g]=P.shadow.matrix,C++}s.point[g]=K,g++}else if(P.isHemisphereLight){let K=e.get(P);K.skyColor.copy(P.color).multiplyScalar(z*M),K.groundColor.copy(P.groundColor).multiplyScalar(z*M),s.hemi[y]=K,y++}}S>0&&(t.isWebGL2?n.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=dt.LTC_FLOAT_1,s.rectAreaLTC2=dt.LTC_FLOAT_2):(s.rectAreaLTC1=dt.LTC_HALF_1,s.rectAreaLTC2=dt.LTC_HALF_2):n.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=dt.LTC_FLOAT_1,s.rectAreaLTC2=dt.LTC_FLOAT_2):n.has("OES_texture_half_float_linear")===!0?(s.rectAreaLTC1=dt.LTC_HALF_1,s.rectAreaLTC2=dt.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),s.ambient[0]=f,s.ambient[1]=d,s.ambient[2]=p;let I=s.hash;(I.directionalLength!==x||I.pointLength!==g||I.spotLength!==m||I.rectAreaLength!==S||I.hemiLength!==y||I.numDirectionalShadows!==b||I.numPointShadows!==C||I.numSpotShadows!==A||I.numSpotMaps!==w||I.numLightProbes!==E)&&(s.directional.length=x,s.spot.length=m,s.rectArea.length=S,s.point.length=g,s.hemi.length=y,s.directionalShadow.length=b,s.directionalShadowMap.length=b,s.pointShadow.length=C,s.pointShadowMap.length=C,s.spotShadow.length=A,s.spotShadowMap.length=A,s.directionalShadowMatrix.length=b,s.pointShadowMatrix.length=C,s.spotLightMatrix.length=A+w-F,s.spotLightMap.length=w,s.numSpotLightShadowsWithMaps=F,s.numLightProbes=E,I.directionalLength=x,I.pointLength=g,I.spotLength=m,I.rectAreaLength=S,I.hemiLength=y,I.numDirectionalShadows=b,I.numPointShadows=C,I.numSpotShadows=A,I.numSpotMaps=w,I.numLightProbes=E,s.version=d_++)}function l(h,u){let f=0,d=0,p=0,x=0,g=0,m=u.matrixWorldInverse;for(let S=0,y=h.length;S<y;S++){let b=h[S];if(b.isDirectionalLight){let C=s.directional[f];C.direction.setFromMatrixPosition(b.matrixWorld),r.setFromMatrixPosition(b.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(m),f++}else if(b.isSpotLight){let C=s.spot[p];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(m),C.direction.setFromMatrixPosition(b.matrixWorld),r.setFromMatrixPosition(b.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(m),p++}else if(b.isRectAreaLight){let C=s.rectArea[x];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(m),o.identity(),a.copy(b.matrixWorld),a.premultiply(m),o.extractRotation(a),C.halfWidth.set(b.width*.5,0,0),C.halfHeight.set(0,b.height*.5,0),C.halfWidth.applyMatrix4(o),C.halfHeight.applyMatrix4(o),x++}else if(b.isPointLight){let C=s.point[d];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(m),d++}else if(b.isHemisphereLight){let C=s.hemi[g];C.direction.setFromMatrixPosition(b.matrixWorld),C.direction.transformDirection(m),g++}}}return{setup:c,setupView:l,state:s}}function Lf(n,t){let e=new m_(n,t),i=[],s=[];function r(){i.length=0,s.length=0}function a(u){i.push(u)}function o(u){s.push(u)}function c(u){e.setup(i,u)}function l(u){e.setupView(i,u)}return{init:r,state:{lightsArray:i,shadowsArray:s,lights:e},setupLights:c,setupLightsView:l,pushLight:a,pushShadow:o}}function g_(n,t){let e=new WeakMap;function i(r,a=0){let o=e.get(r),c;return o===void 0?(c=new Lf(n,t),e.set(r,[c])):a>=o.length?(c=new Lf(n,t),o.push(c)):c=o[a],c}function s(){e=new WeakMap}return{get:i,dispose:s}}var Rl=class extends wi{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=h0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},Cl=class extends wi{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},x_=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,y_=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function __(n,t,e){let i=new na,s=new ht,r=new ht,a=new Ge,o=new Rl({depthPacking:u0}),c=new Cl,l={},h=e.maxTextureSize,u={[$i]:fn,[fn]:$i,[Fe]:Fe},f=new kn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ht},radius:{value:4}},vertexShader:x_,fragmentShader:y_}),d=f.clone();d.defines.HORIZONTAL_PASS=1;let p=new Pe;p.setAttribute("position",new fe(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let x=new Tt(p,f),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Xf;let m=this.type;this.render=function(A,w,F){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||A.length===0)return;let E=n.getRenderTarget(),M=n.getActiveCubeFace(),I=n.getActiveMipmapLevel(),N=n.state;N.setBlending(Vi),N.buffers.color.setClear(1,1,1,1),N.buffers.depth.setTest(!0),N.setScissorTest(!1);let J=m!==Mi&&this.type===Mi,P=m===Mi&&this.type!==Mi;for(let O=0,z=A.length;O<z;O++){let Q=A[O],j=Q.shadow;if(j===void 0){console.warn("THREE.WebGLShadowMap:",Q,"has no shadow.");continue}if(j.autoUpdate===!1&&j.needsUpdate===!1)continue;s.copy(j.mapSize);let K=j.getFrameExtents();if(s.multiply(K),r.copy(j.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/K.x),s.x=r.x*K.x,j.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/K.y),s.y=r.y*K.y,j.mapSize.y=r.y)),j.map===null||J===!0||P===!0){let it=this.type!==Mi?{minFilter:nn,magFilter:nn}:{};j.map!==null&&j.map.dispose(),j.map=new Ti(s.x,s.y,it),j.map.texture.name=Q.name+".shadowMap",j.camera.updateProjectionMatrix()}n.setRenderTarget(j.map),n.clear();let st=j.getViewportCount();for(let it=0;it<st;it++){let xt=j.getViewport(it);a.set(r.x*xt.x,r.y*xt.y,r.x*xt.z,r.y*xt.w),N.viewport(a),j.updateMatrices(Q,it),i=j.getFrustum(),b(w,F,j.camera,Q,this.type)}j.isPointLightShadow!==!0&&this.type===Mi&&S(j,F),j.needsUpdate=!1}m=this.type,g.needsUpdate=!1,n.setRenderTarget(E,M,I)};function S(A,w){let F=t.update(x);f.defines.VSM_SAMPLES!==A.blurSamples&&(f.defines.VSM_SAMPLES=A.blurSamples,d.defines.VSM_SAMPLES=A.blurSamples,f.needsUpdate=!0,d.needsUpdate=!0),A.mapPass===null&&(A.mapPass=new Ti(s.x,s.y)),f.uniforms.shadow_pass.value=A.map.texture,f.uniforms.resolution.value=A.mapSize,f.uniforms.radius.value=A.radius,n.setRenderTarget(A.mapPass),n.clear(),n.renderBufferDirect(w,null,F,f,x,null),d.uniforms.shadow_pass.value=A.mapPass.texture,d.uniforms.resolution.value=A.mapSize,d.uniforms.radius.value=A.radius,n.setRenderTarget(A.map),n.clear(),n.renderBufferDirect(w,null,F,d,x,null)}function y(A,w,F,E){let M=null,I=F.isPointLight===!0?A.customDistanceMaterial:A.customDepthMaterial;if(I!==void 0)M=I;else if(M=F.isPointLight===!0?c:o,n.localClippingEnabled&&w.clipShadows===!0&&Array.isArray(w.clippingPlanes)&&w.clippingPlanes.length!==0||w.displacementMap&&w.displacementScale!==0||w.alphaMap&&w.alphaTest>0||w.map&&w.alphaTest>0){let N=M.uuid,J=w.uuid,P=l[N];P===void 0&&(P={},l[N]=P);let O=P[J];O===void 0&&(O=M.clone(),P[J]=O,w.addEventListener("dispose",C)),M=O}if(M.visible=w.visible,M.wireframe=w.wireframe,E===Mi?M.side=w.shadowSide!==null?w.shadowSide:w.side:M.side=w.shadowSide!==null?w.shadowSide:u[w.side],M.alphaMap=w.alphaMap,M.alphaTest=w.alphaTest,M.map=w.map,M.clipShadows=w.clipShadows,M.clippingPlanes=w.clippingPlanes,M.clipIntersection=w.clipIntersection,M.displacementMap=w.displacementMap,M.displacementScale=w.displacementScale,M.displacementBias=w.displacementBias,M.wireframeLinewidth=w.wireframeLinewidth,M.linewidth=w.linewidth,F.isPointLight===!0&&M.isMeshDistanceMaterial===!0){let N=n.properties.get(M);N.light=F}return M}function b(A,w,F,E,M){if(A.visible===!1)return;if(A.layers.test(w.layers)&&(A.isMesh||A.isLine||A.isPoints)&&(A.castShadow||A.receiveShadow&&M===Mi)&&(!A.frustumCulled||i.intersectsObject(A))){A.modelViewMatrix.multiplyMatrices(F.matrixWorldInverse,A.matrixWorld);let J=t.update(A),P=A.material;if(Array.isArray(P)){let O=J.groups;for(let z=0,Q=O.length;z<Q;z++){let j=O[z],K=P[j.materialIndex];if(K&&K.visible){let st=y(A,K,E,M);A.onBeforeShadow(n,A,w,F,J,st,j),n.renderBufferDirect(F,null,J,st,A,j),A.onAfterShadow(n,A,w,F,J,st,j)}}}else if(P.visible){let O=y(A,P,E,M);A.onBeforeShadow(n,A,w,F,J,O,null),n.renderBufferDirect(F,null,J,O,A,null),A.onAfterShadow(n,A,w,F,J,O,null)}}let N=A.children;for(let J=0,P=N.length;J<P;J++)b(N[J],w,F,E,M)}function C(A){A.target.removeEventListener("dispose",C);for(let F in l){let E=l[F],M=A.target.uuid;M in E&&(E[M].dispose(),delete E[M])}}}function v_(n,t,e){let i=e.isWebGL2;function s(){let U=!1,Mt=new Ge,Et=null,Xt=new Ge(0,0,0,0);return{setMask:function(Gt){Et!==Gt&&!U&&(n.colorMask(Gt,Gt,Gt,Gt),Et=Gt)},setLocked:function(Gt){U=Gt},setClear:function(Gt,be,Te,Qe,mn){mn===!0&&(Gt*=Qe,be*=Qe,Te*=Qe),Mt.set(Gt,be,Te,Qe),Xt.equals(Mt)===!1&&(n.clearColor(Gt,be,Te,Qe),Xt.copy(Mt))},reset:function(){U=!1,Et=null,Xt.set(-1,0,0,0)}}}function r(){let U=!1,Mt=null,Et=null,Xt=null;return{setTest:function(Gt){Gt?nt(n.DEPTH_TEST):ct(n.DEPTH_TEST)},setMask:function(Gt){Mt!==Gt&&!U&&(n.depthMask(Gt),Mt=Gt)},setFunc:function(Gt){if(Et!==Gt){switch(Gt){case kp:n.depthFunc(n.NEVER);break;case Gp:n.depthFunc(n.ALWAYS);break;case Vp:n.depthFunc(n.LESS);break;case uo:n.depthFunc(n.LEQUAL);break;case Wp:n.depthFunc(n.EQUAL);break;case Xp:n.depthFunc(n.GEQUAL);break;case Yp:n.depthFunc(n.GREATER);break;case $p:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}Et=Gt}},setLocked:function(Gt){U=Gt},setClear:function(Gt){Xt!==Gt&&(n.clearDepth(Gt),Xt=Gt)},reset:function(){U=!1,Mt=null,Et=null,Xt=null}}}function a(){let U=!1,Mt=null,Et=null,Xt=null,Gt=null,be=null,Te=null,Qe=null,mn=null;return{setTest:function(we){U||(we?nt(n.STENCIL_TEST):ct(n.STENCIL_TEST))},setMask:function(we){Mt!==we&&!U&&(n.stencilMask(we),Mt=we)},setFunc:function(we,gn,ri){(Et!==we||Xt!==gn||Gt!==ri)&&(n.stencilFunc(we,gn,ri),Et=we,Xt=gn,Gt=ri)},setOp:function(we,gn,ri){(be!==we||Te!==gn||Qe!==ri)&&(n.stencilOp(we,gn,ri),be=we,Te=gn,Qe=ri)},setLocked:function(we){U=we},setClear:function(we){mn!==we&&(n.clearStencil(we),mn=we)},reset:function(){U=!1,Mt=null,Et=null,Xt=null,Gt=null,be=null,Te=null,Qe=null,mn=null}}}let o=new s,c=new r,l=new a,h=new WeakMap,u=new WeakMap,f={},d={},p=new WeakMap,x=[],g=null,m=!1,S=null,y=null,b=null,C=null,A=null,w=null,F=null,E=new Ft(0,0,0),M=0,I=!1,N=null,J=null,P=null,O=null,z=null,Q=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS),j=!1,K=0,st=n.getParameter(n.VERSION);st.indexOf("WebGL")!==-1?(K=parseFloat(/^WebGL (\d)/.exec(st)[1]),j=K>=1):st.indexOf("OpenGL ES")!==-1&&(K=parseFloat(/^OpenGL ES (\d)/.exec(st)[1]),j=K>=2);let it=null,xt={},$=n.getParameter(n.SCISSOR_BOX),et=n.getParameter(n.VIEWPORT),ut=new Ge().fromArray($),Lt=new Ge().fromArray(et);function St(U,Mt,Et,Xt){let Gt=new Uint8Array(4),be=n.createTexture();n.bindTexture(U,be),n.texParameteri(U,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(U,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let Te=0;Te<Et;Te++)i&&(U===n.TEXTURE_3D||U===n.TEXTURE_2D_ARRAY)?n.texImage3D(Mt,0,n.RGBA,1,1,Xt,0,n.RGBA,n.UNSIGNED_BYTE,Gt):n.texImage2D(Mt+Te,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Gt);return be}let Bt={};Bt[n.TEXTURE_2D]=St(n.TEXTURE_2D,n.TEXTURE_2D,1),Bt[n.TEXTURE_CUBE_MAP]=St(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(Bt[n.TEXTURE_2D_ARRAY]=St(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),Bt[n.TEXTURE_3D]=St(n.TEXTURE_3D,n.TEXTURE_3D,1,1)),o.setClear(0,0,0,1),c.setClear(1),l.setClear(0),nt(n.DEPTH_TEST),c.setFunc(uo),yt(!1),v(uu),nt(n.CULL_FACE),q(Vi);function nt(U){f[U]!==!0&&(n.enable(U),f[U]=!0)}function ct(U){f[U]!==!1&&(n.disable(U),f[U]=!1)}function gt(U,Mt){return d[U]!==Mt?(n.bindFramebuffer(U,Mt),d[U]=Mt,i&&(U===n.DRAW_FRAMEBUFFER&&(d[n.FRAMEBUFFER]=Mt),U===n.FRAMEBUFFER&&(d[n.DRAW_FRAMEBUFFER]=Mt)),!0):!1}function R(U,Mt){let Et=x,Xt=!1;if(U)if(Et=p.get(Mt),Et===void 0&&(Et=[],p.set(Mt,Et)),U.isWebGLMultipleRenderTargets){let Gt=U.texture;if(Et.length!==Gt.length||Et[0]!==n.COLOR_ATTACHMENT0){for(let be=0,Te=Gt.length;be<Te;be++)Et[be]=n.COLOR_ATTACHMENT0+be;Et.length=Gt.length,Xt=!0}}else Et[0]!==n.COLOR_ATTACHMENT0&&(Et[0]=n.COLOR_ATTACHMENT0,Xt=!0);else Et[0]!==n.BACK&&(Et[0]=n.BACK,Xt=!0);Xt&&(e.isWebGL2?n.drawBuffers(Et):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(Et))}function rt(U){return g!==U?(n.useProgram(U),g=U,!0):!1}let Y={[hs]:n.FUNC_ADD,[wp]:n.FUNC_SUBTRACT,[Ap]:n.FUNC_REVERSE_SUBTRACT};if(i)Y[pu]=n.MIN,Y[mu]=n.MAX;else{let U=t.get("EXT_blend_minmax");U!==null&&(Y[pu]=U.MIN_EXT,Y[mu]=U.MAX_EXT)}let tt={[Rp]:n.ZERO,[Cp]:n.ONE,[Pp]:n.SRC_COLOR,[hl]:n.SRC_ALPHA,[Op]:n.SRC_ALPHA_SATURATE,[Up]:n.DST_COLOR,[Ip]:n.DST_ALPHA,[Lp]:n.ONE_MINUS_SRC_COLOR,[ul]:n.ONE_MINUS_SRC_ALPHA,[Np]:n.ONE_MINUS_DST_COLOR,[Dp]:n.ONE_MINUS_DST_ALPHA,[Fp]:n.CONSTANT_COLOR,[zp]:n.ONE_MINUS_CONSTANT_COLOR,[Bp]:n.CONSTANT_ALPHA,[Hp]:n.ONE_MINUS_CONSTANT_ALPHA};function q(U,Mt,Et,Xt,Gt,be,Te,Qe,mn,we){if(U===Vi){m===!0&&(ct(n.BLEND),m=!1);return}if(m===!1&&(nt(n.BLEND),m=!0),U!==Tp){if(U!==S||we!==I){if((y!==hs||A!==hs)&&(n.blendEquation(n.FUNC_ADD),y=hs,A=hs),we)switch(U){case Wi:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case qi:n.blendFunc(n.ONE,n.ONE);break;case fu:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case du:n.blendFuncSeparate(n.ZERO,n.SRC_COLOR,n.ZERO,n.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}else switch(U){case Wi:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case qi:n.blendFunc(n.SRC_ALPHA,n.ONE);break;case fu:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case du:n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}b=null,C=null,w=null,F=null,E.set(0,0,0),M=0,S=U,I=we}return}Gt=Gt||Mt,be=be||Et,Te=Te||Xt,(Mt!==y||Gt!==A)&&(n.blendEquationSeparate(Y[Mt],Y[Gt]),y=Mt,A=Gt),(Et!==b||Xt!==C||be!==w||Te!==F)&&(n.blendFuncSeparate(tt[Et],tt[Xt],tt[be],tt[Te]),b=Et,C=Xt,w=be,F=Te),(Qe.equals(E)===!1||mn!==M)&&(n.blendColor(Qe.r,Qe.g,Qe.b,mn),E.copy(Qe),M=mn),S=U,I=!1}function Ct(U,Mt){U.side===Fe?ct(n.CULL_FACE):nt(n.CULL_FACE);let Et=U.side===fn;Mt&&(Et=!Et),yt(Et),U.blending===Wi&&U.transparent===!1?q(Vi):q(U.blending,U.blendEquation,U.blendSrc,U.blendDst,U.blendEquationAlpha,U.blendSrcAlpha,U.blendDstAlpha,U.blendColor,U.blendAlpha,U.premultipliedAlpha),c.setFunc(U.depthFunc),c.setTest(U.depthTest),c.setMask(U.depthWrite),o.setMask(U.colorWrite);let Xt=U.stencilWrite;l.setTest(Xt),Xt&&(l.setMask(U.stencilWriteMask),l.setFunc(U.stencilFunc,U.stencilRef,U.stencilFuncMask),l.setOp(U.stencilFail,U.stencilZFail,U.stencilZPass)),D(U.polygonOffset,U.polygonOffsetFactor,U.polygonOffsetUnits),U.alphaToCoverage===!0?nt(n.SAMPLE_ALPHA_TO_COVERAGE):ct(n.SAMPLE_ALPHA_TO_COVERAGE)}function yt(U){N!==U&&(U?n.frontFace(n.CW):n.frontFace(n.CCW),N=U)}function v(U){U!==Sp?(nt(n.CULL_FACE),U!==J&&(U===uu?n.cullFace(n.BACK):U===bp?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):ct(n.CULL_FACE),J=U}function _(U){U!==P&&(j&&n.lineWidth(U),P=U)}function D(U,Mt,Et){U?(nt(n.POLYGON_OFFSET_FILL),(O!==Mt||z!==Et)&&(n.polygonOffset(Mt,Et),O=Mt,z=Et)):ct(n.POLYGON_OFFSET_FILL)}function k(U){U?nt(n.SCISSOR_TEST):ct(n.SCISSOR_TEST)}function W(U){U===void 0&&(U=n.TEXTURE0+Q-1),it!==U&&(n.activeTexture(U),it=U)}function Z(U,Mt,Et){Et===void 0&&(it===null?Et=n.TEXTURE0+Q-1:Et=it);let Xt=xt[Et];Xt===void 0&&(Xt={type:void 0,texture:void 0},xt[Et]=Xt),(Xt.type!==U||Xt.texture!==Mt)&&(it!==Et&&(n.activeTexture(Et),it=Et),n.bindTexture(U,Mt||Bt[U]),Xt.type=U,Xt.texture=Mt)}function bt(){let U=xt[it];U!==void 0&&U.type!==void 0&&(n.bindTexture(U.type,null),U.type=void 0,U.texture=void 0)}function lt(){try{n.compressedTexImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function wt(){try{n.compressedTexImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function zt(){try{n.texSubImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function qt(){try{n.texSubImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function at(){try{n.compressedTexSubImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function de(){try{n.compressedTexSubImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function ae(){try{n.texStorage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Zt(){try{n.texStorage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Ht(){try{n.texImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Dt(){try{n.texImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function jt(U){ut.equals(U)===!1&&(n.scissor(U.x,U.y,U.z,U.w),ut.copy(U))}function xe(U){Lt.equals(U)===!1&&(n.viewport(U.x,U.y,U.z,U.w),Lt.copy(U))}function Ne(U,Mt){let Et=u.get(Mt);Et===void 0&&(Et=new WeakMap,u.set(Mt,Et));let Xt=Et.get(U);Xt===void 0&&(Xt=n.getUniformBlockIndex(Mt,U.name),Et.set(U,Xt))}function ie(U,Mt){let Xt=u.get(Mt).get(U);h.get(Mt)!==Xt&&(n.uniformBlockBinding(Mt,Xt,U.__bindingPointIndex),h.set(Mt,Xt))}function ft(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),i===!0&&(n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null)),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),f={},it=null,xt={},d={},p=new WeakMap,x=[],g=null,m=!1,S=null,y=null,b=null,C=null,A=null,w=null,F=null,E=new Ft(0,0,0),M=0,I=!1,N=null,J=null,P=null,O=null,z=null,ut.set(0,0,n.canvas.width,n.canvas.height),Lt.set(0,0,n.canvas.width,n.canvas.height),o.reset(),c.reset(),l.reset()}return{buffers:{color:o,depth:c,stencil:l},enable:nt,disable:ct,bindFramebuffer:gt,drawBuffers:R,useProgram:rt,setBlending:q,setMaterial:Ct,setFlipSided:yt,setCullFace:v,setLineWidth:_,setPolygonOffset:D,setScissorTest:k,activeTexture:W,bindTexture:Z,unbindTexture:bt,compressedTexImage2D:lt,compressedTexImage3D:wt,texImage2D:Ht,texImage3D:Dt,updateUBOMapping:Ne,uniformBlockBinding:ie,texStorage2D:ae,texStorage3D:Zt,texSubImage2D:zt,texSubImage3D:qt,compressedTexSubImage2D:at,compressedTexSubImage3D:de,scissor:jt,viewport:xe,reset:ft}}function M_(n,t,e,i,s,r,a){let o=s.isWebGL2,c=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap,u,f=new WeakMap,d=!1;try{d=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function p(v,_){return d?new OffscreenCanvas(v,_):vo("canvas")}function x(v,_,D,k){let W=1;if((v.width>k||v.height>k)&&(W=k/Math.max(v.width,v.height)),W<1||_===!0)if(typeof HTMLImageElement<"u"&&v instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&v instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&v instanceof ImageBitmap){let Z=_?_o:Math.floor,bt=Z(W*v.width),lt=Z(W*v.height);u===void 0&&(u=p(bt,lt));let wt=D?p(bt,lt):u;return wt.width=bt,wt.height=lt,wt.getContext("2d").drawImage(v,0,0,bt,lt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+v.width+"x"+v.height+") to ("+bt+"x"+lt+")."),wt}else return"data"in v&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+v.width+"x"+v.height+")."),v;return v}function g(v){return xl(v.width)&&xl(v.height)}function m(v){return o?!1:v.wrapS!==Kn||v.wrapT!==Kn||v.minFilter!==nn&&v.minFilter!==Fn}function S(v,_){return v.generateMipmaps&&_&&v.minFilter!==nn&&v.minFilter!==Fn}function y(v){n.generateMipmap(v)}function b(v,_,D,k,W=!1){if(o===!1)return _;if(v!==null){if(n[v]!==void 0)return n[v];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+v+"'")}let Z=_;if(_===n.RED&&(D===n.FLOAT&&(Z=n.R32F),D===n.HALF_FLOAT&&(Z=n.R16F),D===n.UNSIGNED_BYTE&&(Z=n.R8)),_===n.RED_INTEGER&&(D===n.UNSIGNED_BYTE&&(Z=n.R8UI),D===n.UNSIGNED_SHORT&&(Z=n.R16UI),D===n.UNSIGNED_INT&&(Z=n.R32UI),D===n.BYTE&&(Z=n.R8I),D===n.SHORT&&(Z=n.R16I),D===n.INT&&(Z=n.R32I)),_===n.RG&&(D===n.FLOAT&&(Z=n.RG32F),D===n.HALF_FLOAT&&(Z=n.RG16F),D===n.UNSIGNED_BYTE&&(Z=n.RG8)),_===n.RGBA){let bt=W?mo:_e.getTransfer(k);D===n.FLOAT&&(Z=n.RGBA32F),D===n.HALF_FLOAT&&(Z=n.RGBA16F),D===n.UNSIGNED_BYTE&&(Z=bt===Ce?n.SRGB8_ALPHA8:n.RGBA8),D===n.UNSIGNED_SHORT_4_4_4_4&&(Z=n.RGBA4),D===n.UNSIGNED_SHORT_5_5_5_1&&(Z=n.RGB5_A1)}return(Z===n.R16F||Z===n.R32F||Z===n.RG16F||Z===n.RG32F||Z===n.RGBA16F||Z===n.RGBA32F)&&t.get("EXT_color_buffer_float"),Z}function C(v,_,D){return S(v,D)===!0||v.isFramebufferTexture&&v.minFilter!==nn&&v.minFilter!==Fn?Math.log2(Math.max(_.width,_.height))+1:v.mipmaps!==void 0&&v.mipmaps.length>0?v.mipmaps.length:v.isCompressedTexture&&Array.isArray(v.image)?_.mipmaps.length:1}function A(v){return v===nn||v===gu||v===Pc?n.NEAREST:n.LINEAR}function w(v){let _=v.target;_.removeEventListener("dispose",w),E(_),_.isVideoTexture&&h.delete(_)}function F(v){let _=v.target;_.removeEventListener("dispose",F),I(_)}function E(v){let _=i.get(v);if(_.__webglInit===void 0)return;let D=v.source,k=f.get(D);if(k){let W=k[_.__cacheKey];W.usedTimes--,W.usedTimes===0&&M(v),Object.keys(k).length===0&&f.delete(D)}i.remove(v)}function M(v){let _=i.get(v);n.deleteTexture(_.__webglTexture);let D=v.source,k=f.get(D);delete k[_.__cacheKey],a.memory.textures--}function I(v){let _=v.texture,D=i.get(v),k=i.get(_);if(k.__webglTexture!==void 0&&(n.deleteTexture(k.__webglTexture),a.memory.textures--),v.depthTexture&&v.depthTexture.dispose(),v.isWebGLCubeRenderTarget)for(let W=0;W<6;W++){if(Array.isArray(D.__webglFramebuffer[W]))for(let Z=0;Z<D.__webglFramebuffer[W].length;Z++)n.deleteFramebuffer(D.__webglFramebuffer[W][Z]);else n.deleteFramebuffer(D.__webglFramebuffer[W]);D.__webglDepthbuffer&&n.deleteRenderbuffer(D.__webglDepthbuffer[W])}else{if(Array.isArray(D.__webglFramebuffer))for(let W=0;W<D.__webglFramebuffer.length;W++)n.deleteFramebuffer(D.__webglFramebuffer[W]);else n.deleteFramebuffer(D.__webglFramebuffer);if(D.__webglDepthbuffer&&n.deleteRenderbuffer(D.__webglDepthbuffer),D.__webglMultisampledFramebuffer&&n.deleteFramebuffer(D.__webglMultisampledFramebuffer),D.__webglColorRenderbuffer)for(let W=0;W<D.__webglColorRenderbuffer.length;W++)D.__webglColorRenderbuffer[W]&&n.deleteRenderbuffer(D.__webglColorRenderbuffer[W]);D.__webglDepthRenderbuffer&&n.deleteRenderbuffer(D.__webglDepthRenderbuffer)}if(v.isWebGLMultipleRenderTargets)for(let W=0,Z=_.length;W<Z;W++){let bt=i.get(_[W]);bt.__webglTexture&&(n.deleteTexture(bt.__webglTexture),a.memory.textures--),i.remove(_[W])}i.remove(_),i.remove(v)}let N=0;function J(){N=0}function P(){let v=N;return v>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+v+" texture units while this GPU supports only "+s.maxTextures),N+=1,v}function O(v){let _=[];return _.push(v.wrapS),_.push(v.wrapT),_.push(v.wrapR||0),_.push(v.magFilter),_.push(v.minFilter),_.push(v.anisotropy),_.push(v.internalFormat),_.push(v.format),_.push(v.type),_.push(v.generateMipmaps),_.push(v.premultiplyAlpha),_.push(v.flipY),_.push(v.unpackAlignment),_.push(v.colorSpace),_.join()}function z(v,_){let D=i.get(v);if(v.isVideoTexture&&Ct(v),v.isRenderTargetTexture===!1&&v.version>0&&D.__version!==v.version){let k=v.image;if(k===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(k.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{ut(D,v,_);return}}e.bindTexture(n.TEXTURE_2D,D.__webglTexture,n.TEXTURE0+_)}function Q(v,_){let D=i.get(v);if(v.version>0&&D.__version!==v.version){ut(D,v,_);return}e.bindTexture(n.TEXTURE_2D_ARRAY,D.__webglTexture,n.TEXTURE0+_)}function j(v,_){let D=i.get(v);if(v.version>0&&D.__version!==v.version){ut(D,v,_);return}e.bindTexture(n.TEXTURE_3D,D.__webglTexture,n.TEXTURE0+_)}function K(v,_){let D=i.get(v);if(v.version>0&&D.__version!==v.version){Lt(D,v,_);return}e.bindTexture(n.TEXTURE_CUBE_MAP,D.__webglTexture,n.TEXTURE0+_)}let st={[jr]:n.REPEAT,[Kn]:n.CLAMP_TO_EDGE,[pl]:n.MIRRORED_REPEAT},it={[nn]:n.NEAREST,[gu]:n.NEAREST_MIPMAP_NEAREST,[Pc]:n.NEAREST_MIPMAP_LINEAR,[Fn]:n.LINEAR,[e0]:n.LINEAR_MIPMAP_NEAREST,[Qr]:n.LINEAR_MIPMAP_LINEAR},xt={[d0]:n.NEVER,[_0]:n.ALWAYS,[p0]:n.LESS,[id]:n.LEQUAL,[m0]:n.EQUAL,[y0]:n.GEQUAL,[g0]:n.GREATER,[x0]:n.NOTEQUAL};function $(v,_,D){if(D?(n.texParameteri(v,n.TEXTURE_WRAP_S,st[_.wrapS]),n.texParameteri(v,n.TEXTURE_WRAP_T,st[_.wrapT]),(v===n.TEXTURE_3D||v===n.TEXTURE_2D_ARRAY)&&n.texParameteri(v,n.TEXTURE_WRAP_R,st[_.wrapR]),n.texParameteri(v,n.TEXTURE_MAG_FILTER,it[_.magFilter]),n.texParameteri(v,n.TEXTURE_MIN_FILTER,it[_.minFilter])):(n.texParameteri(v,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(v,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE),(v===n.TEXTURE_3D||v===n.TEXTURE_2D_ARRAY)&&n.texParameteri(v,n.TEXTURE_WRAP_R,n.CLAMP_TO_EDGE),(_.wrapS!==Kn||_.wrapT!==Kn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),n.texParameteri(v,n.TEXTURE_MAG_FILTER,A(_.magFilter)),n.texParameteri(v,n.TEXTURE_MIN_FILTER,A(_.minFilter)),_.minFilter!==nn&&_.minFilter!==Fn&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),_.compareFunction&&(n.texParameteri(v,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(v,n.TEXTURE_COMPARE_FUNC,xt[_.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){let k=t.get("EXT_texture_filter_anisotropic");if(_.magFilter===nn||_.minFilter!==Pc&&_.minFilter!==Qr||_.type===Gi&&t.has("OES_texture_float_linear")===!1||o===!1&&_.type===ta&&t.has("OES_texture_half_float_linear")===!1)return;(_.anisotropy>1||i.get(_).__currentAnisotropy)&&(n.texParameterf(v,k.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,s.getMaxAnisotropy())),i.get(_).__currentAnisotropy=_.anisotropy)}}function et(v,_){let D=!1;v.__webglInit===void 0&&(v.__webglInit=!0,_.addEventListener("dispose",w));let k=_.source,W=f.get(k);W===void 0&&(W={},f.set(k,W));let Z=O(_);if(Z!==v.__cacheKey){W[Z]===void 0&&(W[Z]={texture:n.createTexture(),usedTimes:0},a.memory.textures++,D=!0),W[Z].usedTimes++;let bt=W[v.__cacheKey];bt!==void 0&&(W[v.__cacheKey].usedTimes--,bt.usedTimes===0&&M(_)),v.__cacheKey=Z,v.__webglTexture=W[Z].texture}return D}function ut(v,_,D){let k=n.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(k=n.TEXTURE_2D_ARRAY),_.isData3DTexture&&(k=n.TEXTURE_3D);let W=et(v,_),Z=_.source;e.bindTexture(k,v.__webglTexture,n.TEXTURE0+D);let bt=i.get(Z);if(Z.version!==bt.__version||W===!0){e.activeTexture(n.TEXTURE0+D);let lt=_e.getPrimaries(_e.workingColorSpace),wt=_.colorSpace===zn?null:_e.getPrimaries(_.colorSpace),zt=_.colorSpace===zn||lt===wt?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,zt);let qt=m(_)&&g(_.image)===!1,at=x(_.image,qt,!1,s.maxTextureSize);at=yt(_,at);let de=g(at)||o,ae=r.convert(_.format,_.colorSpace),Zt=r.convert(_.type),Ht=b(_.internalFormat,ae,Zt,_.colorSpace,_.isVideoTexture);$(k,_,de);let Dt,jt=_.mipmaps,xe=o&&_.isVideoTexture!==!0&&Ht!==td,Ne=bt.__version===void 0||W===!0,ie=C(_,at,de);if(_.isDepthTexture)Ht=n.DEPTH_COMPONENT,o?_.type===Gi?Ht=n.DEPTH_COMPONENT32F:_.type===ki?Ht=n.DEPTH_COMPONENT24:_.type===ds?Ht=n.DEPTH24_STENCIL8:Ht=n.DEPTH_COMPONENT16:_.type===Gi&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),_.format===ps&&Ht===n.DEPTH_COMPONENT&&_.type!==sh&&_.type!==ki&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),_.type=ki,Zt=r.convert(_.type)),_.format===lr&&Ht===n.DEPTH_COMPONENT&&(Ht=n.DEPTH_STENCIL,_.type!==ds&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),_.type=ds,Zt=r.convert(_.type))),Ne&&(xe?e.texStorage2D(n.TEXTURE_2D,1,Ht,at.width,at.height):e.texImage2D(n.TEXTURE_2D,0,Ht,at.width,at.height,0,ae,Zt,null));else if(_.isDataTexture)if(jt.length>0&&de){xe&&Ne&&e.texStorage2D(n.TEXTURE_2D,ie,Ht,jt[0].width,jt[0].height);for(let ft=0,U=jt.length;ft<U;ft++)Dt=jt[ft],xe?e.texSubImage2D(n.TEXTURE_2D,ft,0,0,Dt.width,Dt.height,ae,Zt,Dt.data):e.texImage2D(n.TEXTURE_2D,ft,Ht,Dt.width,Dt.height,0,ae,Zt,Dt.data);_.generateMipmaps=!1}else xe?(Ne&&e.texStorage2D(n.TEXTURE_2D,ie,Ht,at.width,at.height),e.texSubImage2D(n.TEXTURE_2D,0,0,0,at.width,at.height,ae,Zt,at.data)):e.texImage2D(n.TEXTURE_2D,0,Ht,at.width,at.height,0,ae,Zt,at.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){xe&&Ne&&e.texStorage3D(n.TEXTURE_2D_ARRAY,ie,Ht,jt[0].width,jt[0].height,at.depth);for(let ft=0,U=jt.length;ft<U;ft++)Dt=jt[ft],_.format!==jn?ae!==null?xe?e.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,ft,0,0,0,Dt.width,Dt.height,at.depth,ae,Dt.data,0,0):e.compressedTexImage3D(n.TEXTURE_2D_ARRAY,ft,Ht,Dt.width,Dt.height,at.depth,0,Dt.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):xe?e.texSubImage3D(n.TEXTURE_2D_ARRAY,ft,0,0,0,Dt.width,Dt.height,at.depth,ae,Zt,Dt.data):e.texImage3D(n.TEXTURE_2D_ARRAY,ft,Ht,Dt.width,Dt.height,at.depth,0,ae,Zt,Dt.data)}else{xe&&Ne&&e.texStorage2D(n.TEXTURE_2D,ie,Ht,jt[0].width,jt[0].height);for(let ft=0,U=jt.length;ft<U;ft++)Dt=jt[ft],_.format!==jn?ae!==null?xe?e.compressedTexSubImage2D(n.TEXTURE_2D,ft,0,0,Dt.width,Dt.height,ae,Dt.data):e.compressedTexImage2D(n.TEXTURE_2D,ft,Ht,Dt.width,Dt.height,0,Dt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):xe?e.texSubImage2D(n.TEXTURE_2D,ft,0,0,Dt.width,Dt.height,ae,Zt,Dt.data):e.texImage2D(n.TEXTURE_2D,ft,Ht,Dt.width,Dt.height,0,ae,Zt,Dt.data)}else if(_.isDataArrayTexture)xe?(Ne&&e.texStorage3D(n.TEXTURE_2D_ARRAY,ie,Ht,at.width,at.height,at.depth),e.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,at.width,at.height,at.depth,ae,Zt,at.data)):e.texImage3D(n.TEXTURE_2D_ARRAY,0,Ht,at.width,at.height,at.depth,0,ae,Zt,at.data);else if(_.isData3DTexture)xe?(Ne&&e.texStorage3D(n.TEXTURE_3D,ie,Ht,at.width,at.height,at.depth),e.texSubImage3D(n.TEXTURE_3D,0,0,0,0,at.width,at.height,at.depth,ae,Zt,at.data)):e.texImage3D(n.TEXTURE_3D,0,Ht,at.width,at.height,at.depth,0,ae,Zt,at.data);else if(_.isFramebufferTexture){if(Ne)if(xe)e.texStorage2D(n.TEXTURE_2D,ie,Ht,at.width,at.height);else{let ft=at.width,U=at.height;for(let Mt=0;Mt<ie;Mt++)e.texImage2D(n.TEXTURE_2D,Mt,Ht,ft,U,0,ae,Zt,null),ft>>=1,U>>=1}}else if(jt.length>0&&de){xe&&Ne&&e.texStorage2D(n.TEXTURE_2D,ie,Ht,jt[0].width,jt[0].height);for(let ft=0,U=jt.length;ft<U;ft++)Dt=jt[ft],xe?e.texSubImage2D(n.TEXTURE_2D,ft,0,0,ae,Zt,Dt):e.texImage2D(n.TEXTURE_2D,ft,Ht,ae,Zt,Dt);_.generateMipmaps=!1}else xe?(Ne&&e.texStorage2D(n.TEXTURE_2D,ie,Ht,at.width,at.height),e.texSubImage2D(n.TEXTURE_2D,0,0,0,ae,Zt,at)):e.texImage2D(n.TEXTURE_2D,0,Ht,ae,Zt,at);S(_,de)&&y(k),bt.__version=Z.version,_.onUpdate&&_.onUpdate(_)}v.__version=_.version}function Lt(v,_,D){if(_.image.length!==6)return;let k=et(v,_),W=_.source;e.bindTexture(n.TEXTURE_CUBE_MAP,v.__webglTexture,n.TEXTURE0+D);let Z=i.get(W);if(W.version!==Z.__version||k===!0){e.activeTexture(n.TEXTURE0+D);let bt=_e.getPrimaries(_e.workingColorSpace),lt=_.colorSpace===zn?null:_e.getPrimaries(_.colorSpace),wt=_.colorSpace===zn||bt===lt?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,wt);let zt=_.isCompressedTexture||_.image[0].isCompressedTexture,qt=_.image[0]&&_.image[0].isDataTexture,at=[];for(let ft=0;ft<6;ft++)!zt&&!qt?at[ft]=x(_.image[ft],!1,!0,s.maxCubemapSize):at[ft]=qt?_.image[ft].image:_.image[ft],at[ft]=yt(_,at[ft]);let de=at[0],ae=g(de)||o,Zt=r.convert(_.format,_.colorSpace),Ht=r.convert(_.type),Dt=b(_.internalFormat,Zt,Ht,_.colorSpace),jt=o&&_.isVideoTexture!==!0,xe=Z.__version===void 0||k===!0,Ne=C(_,de,ae);$(n.TEXTURE_CUBE_MAP,_,ae);let ie;if(zt){jt&&xe&&e.texStorage2D(n.TEXTURE_CUBE_MAP,Ne,Dt,de.width,de.height);for(let ft=0;ft<6;ft++){ie=at[ft].mipmaps;for(let U=0;U<ie.length;U++){let Mt=ie[U];_.format!==jn?Zt!==null?jt?e.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,U,0,0,Mt.width,Mt.height,Zt,Mt.data):e.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,U,Dt,Mt.width,Mt.height,0,Mt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):jt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,U,0,0,Mt.width,Mt.height,Zt,Ht,Mt.data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,U,Dt,Mt.width,Mt.height,0,Zt,Ht,Mt.data)}}}else{ie=_.mipmaps,jt&&xe&&(ie.length>0&&Ne++,e.texStorage2D(n.TEXTURE_CUBE_MAP,Ne,Dt,at[0].width,at[0].height));for(let ft=0;ft<6;ft++)if(qt){jt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,0,0,at[ft].width,at[ft].height,Zt,Ht,at[ft].data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,Dt,at[ft].width,at[ft].height,0,Zt,Ht,at[ft].data);for(let U=0;U<ie.length;U++){let Et=ie[U].image[ft].image;jt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,U+1,0,0,Et.width,Et.height,Zt,Ht,Et.data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,U+1,Dt,Et.width,Et.height,0,Zt,Ht,Et.data)}}else{jt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,0,0,Zt,Ht,at[ft]):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,Dt,Zt,Ht,at[ft]);for(let U=0;U<ie.length;U++){let Mt=ie[U];jt?e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,U+1,0,0,Zt,Ht,Mt.image[ft]):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ft,U+1,Dt,Zt,Ht,Mt.image[ft])}}}S(_,ae)&&y(n.TEXTURE_CUBE_MAP),Z.__version=W.version,_.onUpdate&&_.onUpdate(_)}v.__version=_.version}function St(v,_,D,k,W,Z){let bt=r.convert(D.format,D.colorSpace),lt=r.convert(D.type),wt=b(D.internalFormat,bt,lt,D.colorSpace);if(!i.get(_).__hasExternalTextures){let qt=Math.max(1,_.width>>Z),at=Math.max(1,_.height>>Z);W===n.TEXTURE_3D||W===n.TEXTURE_2D_ARRAY?e.texImage3D(W,Z,wt,qt,at,_.depth,0,bt,lt,null):e.texImage2D(W,Z,wt,qt,at,0,bt,lt,null)}e.bindFramebuffer(n.FRAMEBUFFER,v),q(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,k,W,i.get(D).__webglTexture,0,tt(_)):(W===n.TEXTURE_2D||W>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&W<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,k,W,i.get(D).__webglTexture,Z),e.bindFramebuffer(n.FRAMEBUFFER,null)}function Bt(v,_,D){if(n.bindRenderbuffer(n.RENDERBUFFER,v),_.depthBuffer&&!_.stencilBuffer){let k=o===!0?n.DEPTH_COMPONENT24:n.DEPTH_COMPONENT16;if(D||q(_)){let W=_.depthTexture;W&&W.isDepthTexture&&(W.type===Gi?k=n.DEPTH_COMPONENT32F:W.type===ki&&(k=n.DEPTH_COMPONENT24));let Z=tt(_);q(_)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Z,k,_.width,_.height):n.renderbufferStorageMultisample(n.RENDERBUFFER,Z,k,_.width,_.height)}else n.renderbufferStorage(n.RENDERBUFFER,k,_.width,_.height);n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.RENDERBUFFER,v)}else if(_.depthBuffer&&_.stencilBuffer){let k=tt(_);D&&q(_)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,k,n.DEPTH24_STENCIL8,_.width,_.height):q(_)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,k,n.DEPTH24_STENCIL8,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,n.DEPTH_STENCIL,_.width,_.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.RENDERBUFFER,v)}else{let k=_.isWebGLMultipleRenderTargets===!0?_.texture:[_.texture];for(let W=0;W<k.length;W++){let Z=k[W],bt=r.convert(Z.format,Z.colorSpace),lt=r.convert(Z.type),wt=b(Z.internalFormat,bt,lt,Z.colorSpace),zt=tt(_);D&&q(_)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,zt,wt,_.width,_.height):q(_)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,zt,wt,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,wt,_.width,_.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function nt(v,_){if(_&&_.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(n.FRAMEBUFFER,v),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!i.get(_.depthTexture).__webglTexture||_.depthTexture.image.width!==_.width||_.depthTexture.image.height!==_.height)&&(_.depthTexture.image.width=_.width,_.depthTexture.image.height=_.height,_.depthTexture.needsUpdate=!0),z(_.depthTexture,0);let k=i.get(_.depthTexture).__webglTexture,W=tt(_);if(_.depthTexture.format===ps)q(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,k,0,W):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,k,0);else if(_.depthTexture.format===lr)q(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,k,0,W):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,k,0);else throw new Error("Unknown depthTexture format")}function ct(v){let _=i.get(v),D=v.isWebGLCubeRenderTarget===!0;if(v.depthTexture&&!_.__autoAllocateDepthBuffer){if(D)throw new Error("target.depthTexture not supported in Cube render targets");nt(_.__webglFramebuffer,v)}else if(D){_.__webglDepthbuffer=[];for(let k=0;k<6;k++)e.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer[k]),_.__webglDepthbuffer[k]=n.createRenderbuffer(),Bt(_.__webglDepthbuffer[k],v,!1)}else e.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer=n.createRenderbuffer(),Bt(_.__webglDepthbuffer,v,!1);e.bindFramebuffer(n.FRAMEBUFFER,null)}function gt(v,_,D){let k=i.get(v);_!==void 0&&St(k.__webglFramebuffer,v,v.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),D!==void 0&&ct(v)}function R(v){let _=v.texture,D=i.get(v),k=i.get(_);v.addEventListener("dispose",F),v.isWebGLMultipleRenderTargets!==!0&&(k.__webglTexture===void 0&&(k.__webglTexture=n.createTexture()),k.__version=_.version,a.memory.textures++);let W=v.isWebGLCubeRenderTarget===!0,Z=v.isWebGLMultipleRenderTargets===!0,bt=g(v)||o;if(W){D.__webglFramebuffer=[];for(let lt=0;lt<6;lt++)if(o&&_.mipmaps&&_.mipmaps.length>0){D.__webglFramebuffer[lt]=[];for(let wt=0;wt<_.mipmaps.length;wt++)D.__webglFramebuffer[lt][wt]=n.createFramebuffer()}else D.__webglFramebuffer[lt]=n.createFramebuffer()}else{if(o&&_.mipmaps&&_.mipmaps.length>0){D.__webglFramebuffer=[];for(let lt=0;lt<_.mipmaps.length;lt++)D.__webglFramebuffer[lt]=n.createFramebuffer()}else D.__webglFramebuffer=n.createFramebuffer();if(Z)if(s.drawBuffers){let lt=v.texture;for(let wt=0,zt=lt.length;wt<zt;wt++){let qt=i.get(lt[wt]);qt.__webglTexture===void 0&&(qt.__webglTexture=n.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&v.samples>0&&q(v)===!1){let lt=Z?_:[_];D.__webglMultisampledFramebuffer=n.createFramebuffer(),D.__webglColorRenderbuffer=[],e.bindFramebuffer(n.FRAMEBUFFER,D.__webglMultisampledFramebuffer);for(let wt=0;wt<lt.length;wt++){let zt=lt[wt];D.__webglColorRenderbuffer[wt]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,D.__webglColorRenderbuffer[wt]);let qt=r.convert(zt.format,zt.colorSpace),at=r.convert(zt.type),de=b(zt.internalFormat,qt,at,zt.colorSpace,v.isXRRenderTarget===!0),ae=tt(v);n.renderbufferStorageMultisample(n.RENDERBUFFER,ae,de,v.width,v.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+wt,n.RENDERBUFFER,D.__webglColorRenderbuffer[wt])}n.bindRenderbuffer(n.RENDERBUFFER,null),v.depthBuffer&&(D.__webglDepthRenderbuffer=n.createRenderbuffer(),Bt(D.__webglDepthRenderbuffer,v,!0)),e.bindFramebuffer(n.FRAMEBUFFER,null)}}if(W){e.bindTexture(n.TEXTURE_CUBE_MAP,k.__webglTexture),$(n.TEXTURE_CUBE_MAP,_,bt);for(let lt=0;lt<6;lt++)if(o&&_.mipmaps&&_.mipmaps.length>0)for(let wt=0;wt<_.mipmaps.length;wt++)St(D.__webglFramebuffer[lt][wt],v,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+lt,wt);else St(D.__webglFramebuffer[lt],v,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+lt,0);S(_,bt)&&y(n.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(Z){let lt=v.texture;for(let wt=0,zt=lt.length;wt<zt;wt++){let qt=lt[wt],at=i.get(qt);e.bindTexture(n.TEXTURE_2D,at.__webglTexture),$(n.TEXTURE_2D,qt,bt),St(D.__webglFramebuffer,v,qt,n.COLOR_ATTACHMENT0+wt,n.TEXTURE_2D,0),S(qt,bt)&&y(n.TEXTURE_2D)}e.unbindTexture()}else{let lt=n.TEXTURE_2D;if((v.isWebGL3DRenderTarget||v.isWebGLArrayRenderTarget)&&(o?lt=v.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(lt,k.__webglTexture),$(lt,_,bt),o&&_.mipmaps&&_.mipmaps.length>0)for(let wt=0;wt<_.mipmaps.length;wt++)St(D.__webglFramebuffer[wt],v,_,n.COLOR_ATTACHMENT0,lt,wt);else St(D.__webglFramebuffer,v,_,n.COLOR_ATTACHMENT0,lt,0);S(_,bt)&&y(lt),e.unbindTexture()}v.depthBuffer&&ct(v)}function rt(v){let _=g(v)||o,D=v.isWebGLMultipleRenderTargets===!0?v.texture:[v.texture];for(let k=0,W=D.length;k<W;k++){let Z=D[k];if(S(Z,_)){let bt=v.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:n.TEXTURE_2D,lt=i.get(Z).__webglTexture;e.bindTexture(bt,lt),y(bt),e.unbindTexture()}}}function Y(v){if(o&&v.samples>0&&q(v)===!1){let _=v.isWebGLMultipleRenderTargets?v.texture:[v.texture],D=v.width,k=v.height,W=n.COLOR_BUFFER_BIT,Z=[],bt=v.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,lt=i.get(v),wt=v.isWebGLMultipleRenderTargets===!0;if(wt)for(let zt=0;zt<_.length;zt++)e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+zt,n.RENDERBUFFER,null),e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+zt,n.TEXTURE_2D,null,0);e.bindFramebuffer(n.READ_FRAMEBUFFER,lt.__webglMultisampledFramebuffer),e.bindFramebuffer(n.DRAW_FRAMEBUFFER,lt.__webglFramebuffer);for(let zt=0;zt<_.length;zt++){Z.push(n.COLOR_ATTACHMENT0+zt),v.depthBuffer&&Z.push(bt);let qt=lt.__ignoreDepthValues!==void 0?lt.__ignoreDepthValues:!1;if(qt===!1&&(v.depthBuffer&&(W|=n.DEPTH_BUFFER_BIT),v.stencilBuffer&&(W|=n.STENCIL_BUFFER_BIT)),wt&&n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,lt.__webglColorRenderbuffer[zt]),qt===!0&&(n.invalidateFramebuffer(n.READ_FRAMEBUFFER,[bt]),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[bt])),wt){let at=i.get(_[zt]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,at,0)}n.blitFramebuffer(0,0,D,k,0,0,D,k,W,n.NEAREST),l&&n.invalidateFramebuffer(n.READ_FRAMEBUFFER,Z)}if(e.bindFramebuffer(n.READ_FRAMEBUFFER,null),e.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),wt)for(let zt=0;zt<_.length;zt++){e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+zt,n.RENDERBUFFER,lt.__webglColorRenderbuffer[zt]);let qt=i.get(_[zt]).__webglTexture;e.bindFramebuffer(n.FRAMEBUFFER,lt.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+zt,n.TEXTURE_2D,qt,0)}e.bindFramebuffer(n.DRAW_FRAMEBUFFER,lt.__webglMultisampledFramebuffer)}}function tt(v){return Math.min(s.maxSamples,v.samples)}function q(v){let _=i.get(v);return o&&v.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function Ct(v){let _=a.render.frame;h.get(v)!==_&&(h.set(v,_),v.update())}function yt(v,_){let D=v.colorSpace,k=v.format,W=v.type;return v.isCompressedTexture===!0||v.isVideoTexture===!0||v.format===gl||D!==bi&&D!==zn&&(_e.getTransfer(D)===Ce?o===!1?t.has("EXT_sRGB")===!0&&k===jn?(v.format=gl,v.minFilter=Fn,v.generateMipmaps=!1):_=Mo.sRGBToLinear(_):(k!==jn||W!==Yi)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",D)),_}this.allocateTextureUnit=P,this.resetTextureUnits=J,this.setTexture2D=z,this.setTexture2DArray=Q,this.setTexture3D=j,this.setTextureCube=K,this.rebindTextures=gt,this.setupRenderTarget=R,this.updateRenderTargetMipmap=rt,this.updateMultisampleRenderTarget=Y,this.setupDepthRenderbuffer=ct,this.setupFrameBufferTexture=St,this.useMultisampledRTT=q}function E_(n,t,e){let i=e.isWebGL2;function s(r,a=zn){let o,c=_e.getTransfer(a);if(r===Yi)return n.UNSIGNED_BYTE;if(r===Zf)return n.UNSIGNED_SHORT_4_4_4_4;if(r===Jf)return n.UNSIGNED_SHORT_5_5_5_1;if(r===n0)return n.BYTE;if(r===i0)return n.SHORT;if(r===sh)return n.UNSIGNED_SHORT;if(r===qf)return n.INT;if(r===ki)return n.UNSIGNED_INT;if(r===Gi)return n.FLOAT;if(r===ta)return i?n.HALF_FLOAT:(o=t.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(r===s0)return n.ALPHA;if(r===jn)return n.RGBA;if(r===r0)return n.LUMINANCE;if(r===a0)return n.LUMINANCE_ALPHA;if(r===ps)return n.DEPTH_COMPONENT;if(r===lr)return n.DEPTH_STENCIL;if(r===gl)return o=t.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(r===o0)return n.RED;if(r===Kf)return n.RED_INTEGER;if(r===c0)return n.RG;if(r===jf)return n.RG_INTEGER;if(r===Qf)return n.RGBA_INTEGER;if(r===Lc||r===Ic||r===Dc||r===Uc)if(c===Ce)if(o=t.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(r===Lc)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===Ic)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===Dc)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===Uc)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=t.get("WEBGL_compressed_texture_s3tc"),o!==null){if(r===Lc)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===Ic)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===Dc)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===Uc)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===xu||r===yu||r===_u||r===vu)if(o=t.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(r===xu)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===yu)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===_u)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===vu)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===td)return o=t.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===Mu||r===Eu)if(o=t.get("WEBGL_compressed_texture_etc"),o!==null){if(r===Mu)return c===Ce?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(r===Eu)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===Su||r===bu||r===Tu||r===wu||r===Au||r===Ru||r===Cu||r===Pu||r===Lu||r===Iu||r===Du||r===Uu||r===Nu||r===Ou)if(o=t.get("WEBGL_compressed_texture_astc"),o!==null){if(r===Su)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===bu)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Tu)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===wu)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Au)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===Ru)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===Cu)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Pu)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===Lu)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Iu)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===Du)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Uu)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Nu)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===Ou)return c===Ce?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===Nc||r===Fu||r===zu)if(o=t.get("EXT_texture_compression_bptc"),o!==null){if(r===Nc)return c===Ce?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===Fu)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===zu)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===l0||r===Bu||r===Hu||r===ku)if(o=t.get("EXT_texture_compression_rgtc"),o!==null){if(r===Nc)return o.COMPRESSED_RED_RGTC1_EXT;if(r===Bu)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===Hu)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===ku)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===ds?i?n.UNSIGNED_INT_24_8:(o=t.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):n[r]!==void 0?n[r]:null}return{convert:s}}var Pl=class extends _n{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},vt=class extends qe{constructor(){super(),this.isGroup=!0,this.type="Group"}},S_={type:"move"},qr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new vt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new vt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new L,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new L),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new vt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new L,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new L),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let i of t.hand.values())this._getHandJoint(e,i)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,i){let s=null,r=null,a=null,o=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){a=!0;for(let x of t.hand.values()){let g=e.getJointPose(x,i),m=this._getHandJoint(l,x);g!==null&&(m.matrix.fromArray(g.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,m.jointRadius=g.radius),m.visible=g!==null}let h=l.joints["index-finger-tip"],u=l.joints["thumb-tip"],f=h.position.distanceTo(u.position),d=.02,p=.005;l.inputState.pinching&&f>d+p?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&f<=d-p&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,i),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));o!==null&&(s=e.getPose(t.targetRaySpace,i),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(S_)))}return o!==null&&(o.visible=s!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let i=new vt;i.matrixAutoUpdate=!1,i.visible=!1,t.joints[e.jointName]=i,t.add(i)}return t.joints[e.jointName]}},Ll=class extends Zi{constructor(t,e){super();let i=this,s=null,r=1,a=null,o="local-floor",c=1,l=null,h=null,u=null,f=null,d=null,p=null,x=e.getContextAttributes(),g=null,m=null,S=[],y=[],b=new ht,C=null,A=new _n;A.layers.enable(1),A.viewport=new Ge;let w=new _n;w.layers.enable(2),w.viewport=new Ge;let F=[A,w],E=new Pl;E.layers.enable(1),E.layers.enable(2);let M=null,I=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function($){let et=S[$];return et===void 0&&(et=new qr,S[$]=et),et.getTargetRaySpace()},this.getControllerGrip=function($){let et=S[$];return et===void 0&&(et=new qr,S[$]=et),et.getGripSpace()},this.getHand=function($){let et=S[$];return et===void 0&&(et=new qr,S[$]=et),et.getHandSpace()};function N($){let et=y.indexOf($.inputSource);if(et===-1)return;let ut=S[et];ut!==void 0&&(ut.update($.inputSource,$.frame,l||a),ut.dispatchEvent({type:$.type,data:$.inputSource}))}function J(){s.removeEventListener("select",N),s.removeEventListener("selectstart",N),s.removeEventListener("selectend",N),s.removeEventListener("squeeze",N),s.removeEventListener("squeezestart",N),s.removeEventListener("squeezeend",N),s.removeEventListener("end",J),s.removeEventListener("inputsourceschange",P);for(let $=0;$<S.length;$++){let et=y[$];et!==null&&(y[$]=null,S[$].disconnect(et))}M=null,I=null,t.setRenderTarget(g),d=null,f=null,u=null,s=null,m=null,xt.stop(),i.isPresenting=!1,t.setPixelRatio(C),t.setSize(b.width,b.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function($){r=$,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function($){o=$,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function($){l=$},this.getBaseLayer=function(){return f!==null?f:d},this.getBinding=function(){return u},this.getFrame=function(){return p},this.getSession=function(){return s},this.setSession=async function($){if(s=$,s!==null){if(g=t.getRenderTarget(),s.addEventListener("select",N),s.addEventListener("selectstart",N),s.addEventListener("selectend",N),s.addEventListener("squeeze",N),s.addEventListener("squeezestart",N),s.addEventListener("squeezeend",N),s.addEventListener("end",J),s.addEventListener("inputsourceschange",P),x.xrCompatible!==!0&&await e.makeXRCompatible(),C=t.getPixelRatio(),t.getSize(b),s.renderState.layers===void 0||t.capabilities.isWebGL2===!1){let et={antialias:s.renderState.layers===void 0?x.antialias:!0,alpha:!0,depth:x.depth,stencil:x.stencil,framebufferScaleFactor:r};d=new XRWebGLLayer(s,e,et),s.updateRenderState({baseLayer:d}),t.setPixelRatio(1),t.setSize(d.framebufferWidth,d.framebufferHeight,!1),m=new Ti(d.framebufferWidth,d.framebufferHeight,{format:jn,type:Yi,colorSpace:t.outputColorSpace,stencilBuffer:x.stencil})}else{let et=null,ut=null,Lt=null;x.depth&&(Lt=x.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,et=x.stencil?lr:ps,ut=x.stencil?ds:ki);let St={colorFormat:e.RGBA8,depthFormat:Lt,scaleFactor:r};u=new XRWebGLBinding(s,e),f=u.createProjectionLayer(St),s.updateRenderState({layers:[f]}),t.setPixelRatio(1),t.setSize(f.textureWidth,f.textureHeight,!1),m=new Ti(f.textureWidth,f.textureHeight,{format:jn,type:Yi,depthTexture:new Lo(f.textureWidth,f.textureHeight,ut,void 0,void 0,void 0,void 0,void 0,void 0,et),stencilBuffer:x.stencil,colorSpace:t.outputColorSpace,samples:x.antialias?4:0});let Bt=t.properties.get(m);Bt.__ignoreDepthValues=f.ignoreDepthValues}m.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await s.requestReferenceSpace(o),xt.setContext(s),xt.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode};function P($){for(let et=0;et<$.removed.length;et++){let ut=$.removed[et],Lt=y.indexOf(ut);Lt>=0&&(y[Lt]=null,S[Lt].disconnect(ut))}for(let et=0;et<$.added.length;et++){let ut=$.added[et],Lt=y.indexOf(ut);if(Lt===-1){for(let Bt=0;Bt<S.length;Bt++)if(Bt>=y.length){y.push(ut),Lt=Bt;break}else if(y[Bt]===null){y[Bt]=ut,Lt=Bt;break}if(Lt===-1)break}let St=S[Lt];St&&St.connect(ut)}}let O=new L,z=new L;function Q($,et,ut){O.setFromMatrixPosition(et.matrixWorld),z.setFromMatrixPosition(ut.matrixWorld);let Lt=O.distanceTo(z),St=et.projectionMatrix.elements,Bt=ut.projectionMatrix.elements,nt=St[14]/(St[10]-1),ct=St[14]/(St[10]+1),gt=(St[9]+1)/St[5],R=(St[9]-1)/St[5],rt=(St[8]-1)/St[0],Y=(Bt[8]+1)/Bt[0],tt=nt*rt,q=nt*Y,Ct=Lt/(-rt+Y),yt=Ct*-rt;et.matrixWorld.decompose($.position,$.quaternion,$.scale),$.translateX(yt),$.translateZ(Ct),$.matrixWorld.compose($.position,$.quaternion,$.scale),$.matrixWorldInverse.copy($.matrixWorld).invert();let v=nt+Ct,_=ct+Ct,D=tt-yt,k=q+(Lt-yt),W=gt*ct/_*v,Z=R*ct/_*v;$.projectionMatrix.makePerspective(D,k,W,Z,v,_),$.projectionMatrixInverse.copy($.projectionMatrix).invert()}function j($,et){et===null?$.matrixWorld.copy($.matrix):$.matrixWorld.multiplyMatrices(et.matrixWorld,$.matrix),$.matrixWorldInverse.copy($.matrixWorld).invert()}this.updateCamera=function($){if(s===null)return;E.near=w.near=A.near=$.near,E.far=w.far=A.far=$.far,(M!==E.near||I!==E.far)&&(s.updateRenderState({depthNear:E.near,depthFar:E.far}),M=E.near,I=E.far);let et=$.parent,ut=E.cameras;j(E,et);for(let Lt=0;Lt<ut.length;Lt++)j(ut[Lt],et);ut.length===2?Q(E,A,w):E.projectionMatrix.copy(A.projectionMatrix),K($,E,et)};function K($,et,ut){ut===null?$.matrix.copy(et.matrixWorld):($.matrix.copy(ut.matrixWorld),$.matrix.invert(),$.matrix.multiply(et.matrixWorld)),$.matrix.decompose($.position,$.quaternion,$.scale),$.updateMatrixWorld(!0),$.projectionMatrix.copy(et.projectionMatrix),$.projectionMatrixInverse.copy(et.projectionMatrixInverse),$.isPerspectiveCamera&&($.fov=ea*2*Math.atan(1/$.projectionMatrix.elements[5]),$.zoom=1)}this.getCamera=function(){return E},this.getFoveation=function(){if(!(f===null&&d===null))return c},this.setFoveation=function($){c=$,f!==null&&(f.fixedFoveation=$),d!==null&&d.fixedFoveation!==void 0&&(d.fixedFoveation=$)};let st=null;function it($,et){if(h=et.getViewerPose(l||a),p=et,h!==null){let ut=h.views;d!==null&&(t.setRenderTargetFramebuffer(m,d.framebuffer),t.setRenderTarget(m));let Lt=!1;ut.length!==E.cameras.length&&(E.cameras.length=0,Lt=!0);for(let St=0;St<ut.length;St++){let Bt=ut[St],nt=null;if(d!==null)nt=d.getViewport(Bt);else{let gt=u.getViewSubImage(f,Bt);nt=gt.viewport,St===0&&(t.setRenderTargetTextures(m,gt.colorTexture,f.ignoreDepthValues?void 0:gt.depthStencilTexture),t.setRenderTarget(m))}let ct=F[St];ct===void 0&&(ct=new _n,ct.layers.enable(St),ct.viewport=new Ge,F[St]=ct),ct.matrix.fromArray(Bt.transform.matrix),ct.matrix.decompose(ct.position,ct.quaternion,ct.scale),ct.projectionMatrix.fromArray(Bt.projectionMatrix),ct.projectionMatrixInverse.copy(ct.projectionMatrix).invert(),ct.viewport.set(nt.x,nt.y,nt.width,nt.height),St===0&&(E.matrix.copy(ct.matrix),E.matrix.decompose(E.position,E.quaternion,E.scale)),Lt===!0&&E.cameras.push(ct)}}for(let ut=0;ut<S.length;ut++){let Lt=y[ut],St=S[ut];Lt!==null&&St!==void 0&&St.update(Lt,et,l||a)}st&&st($,et),et.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:et}),p=null}let xt=new ld;xt.setAnimationLoop(it),this.setAnimationLoop=function($){st=$},this.dispose=function(){}}};function b_(n,t){function e(g,m){g.matrixAutoUpdate===!0&&g.updateMatrix(),m.value.copy(g.matrix)}function i(g,m){m.color.getRGB(g.fogColor.value,cd(n)),m.isFog?(g.fogNear.value=m.near,g.fogFar.value=m.far):m.isFogExp2&&(g.fogDensity.value=m.density)}function s(g,m,S,y,b){m.isMeshBasicMaterial||m.isMeshLambertMaterial?r(g,m):m.isMeshToonMaterial?(r(g,m),u(g,m)):m.isMeshPhongMaterial?(r(g,m),h(g,m)):m.isMeshStandardMaterial?(r(g,m),f(g,m),m.isMeshPhysicalMaterial&&d(g,m,b)):m.isMeshMatcapMaterial?(r(g,m),p(g,m)):m.isMeshDepthMaterial?r(g,m):m.isMeshDistanceMaterial?(r(g,m),x(g,m)):m.isMeshNormalMaterial?r(g,m):m.isLineBasicMaterial?(a(g,m),m.isLineDashedMaterial&&o(g,m)):m.isPointsMaterial?c(g,m,S,y):m.isSpriteMaterial?l(g,m):m.isShadowMaterial?(g.color.value.copy(m.color),g.opacity.value=m.opacity):m.isShaderMaterial&&(m.uniformsNeedUpdate=!1)}function r(g,m){g.opacity.value=m.opacity,m.color&&g.diffuse.value.copy(m.color),m.emissive&&g.emissive.value.copy(m.emissive).multiplyScalar(m.emissiveIntensity),m.map&&(g.map.value=m.map,e(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.bumpMap&&(g.bumpMap.value=m.bumpMap,e(m.bumpMap,g.bumpMapTransform),g.bumpScale.value=m.bumpScale,m.side===fn&&(g.bumpScale.value*=-1)),m.normalMap&&(g.normalMap.value=m.normalMap,e(m.normalMap,g.normalMapTransform),g.normalScale.value.copy(m.normalScale),m.side===fn&&g.normalScale.value.negate()),m.displacementMap&&(g.displacementMap.value=m.displacementMap,e(m.displacementMap,g.displacementMapTransform),g.displacementScale.value=m.displacementScale,g.displacementBias.value=m.displacementBias),m.emissiveMap&&(g.emissiveMap.value=m.emissiveMap,e(m.emissiveMap,g.emissiveMapTransform)),m.specularMap&&(g.specularMap.value=m.specularMap,e(m.specularMap,g.specularMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest);let S=t.get(m).envMap;if(S&&(g.envMap.value=S,g.flipEnvMap.value=S.isCubeTexture&&S.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=m.reflectivity,g.ior.value=m.ior,g.refractionRatio.value=m.refractionRatio),m.lightMap){g.lightMap.value=m.lightMap;let y=n._useLegacyLights===!0?Math.PI:1;g.lightMapIntensity.value=m.lightMapIntensity*y,e(m.lightMap,g.lightMapTransform)}m.aoMap&&(g.aoMap.value=m.aoMap,g.aoMapIntensity.value=m.aoMapIntensity,e(m.aoMap,g.aoMapTransform))}function a(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,m.map&&(g.map.value=m.map,e(m.map,g.mapTransform))}function o(g,m){g.dashSize.value=m.dashSize,g.totalSize.value=m.dashSize+m.gapSize,g.scale.value=m.scale}function c(g,m,S,y){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.size.value=m.size*S,g.scale.value=y*.5,m.map&&(g.map.value=m.map,e(m.map,g.uvTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function l(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.rotation.value=m.rotation,m.map&&(g.map.value=m.map,e(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,e(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function h(g,m){g.specular.value.copy(m.specular),g.shininess.value=Math.max(m.shininess,1e-4)}function u(g,m){m.gradientMap&&(g.gradientMap.value=m.gradientMap)}function f(g,m){g.metalness.value=m.metalness,m.metalnessMap&&(g.metalnessMap.value=m.metalnessMap,e(m.metalnessMap,g.metalnessMapTransform)),g.roughness.value=m.roughness,m.roughnessMap&&(g.roughnessMap.value=m.roughnessMap,e(m.roughnessMap,g.roughnessMapTransform)),t.get(m).envMap&&(g.envMapIntensity.value=m.envMapIntensity)}function d(g,m,S){g.ior.value=m.ior,m.sheen>0&&(g.sheenColor.value.copy(m.sheenColor).multiplyScalar(m.sheen),g.sheenRoughness.value=m.sheenRoughness,m.sheenColorMap&&(g.sheenColorMap.value=m.sheenColorMap,e(m.sheenColorMap,g.sheenColorMapTransform)),m.sheenRoughnessMap&&(g.sheenRoughnessMap.value=m.sheenRoughnessMap,e(m.sheenRoughnessMap,g.sheenRoughnessMapTransform))),m.clearcoat>0&&(g.clearcoat.value=m.clearcoat,g.clearcoatRoughness.value=m.clearcoatRoughness,m.clearcoatMap&&(g.clearcoatMap.value=m.clearcoatMap,e(m.clearcoatMap,g.clearcoatMapTransform)),m.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=m.clearcoatRoughnessMap,e(m.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),m.clearcoatNormalMap&&(g.clearcoatNormalMap.value=m.clearcoatNormalMap,e(m.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(m.clearcoatNormalScale),m.side===fn&&g.clearcoatNormalScale.value.negate())),m.iridescence>0&&(g.iridescence.value=m.iridescence,g.iridescenceIOR.value=m.iridescenceIOR,g.iridescenceThicknessMinimum.value=m.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=m.iridescenceThicknessRange[1],m.iridescenceMap&&(g.iridescenceMap.value=m.iridescenceMap,e(m.iridescenceMap,g.iridescenceMapTransform)),m.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=m.iridescenceThicknessMap,e(m.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),m.transmission>0&&(g.transmission.value=m.transmission,g.transmissionSamplerMap.value=S.texture,g.transmissionSamplerSize.value.set(S.width,S.height),m.transmissionMap&&(g.transmissionMap.value=m.transmissionMap,e(m.transmissionMap,g.transmissionMapTransform)),g.thickness.value=m.thickness,m.thicknessMap&&(g.thicknessMap.value=m.thicknessMap,e(m.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=m.attenuationDistance,g.attenuationColor.value.copy(m.attenuationColor)),m.anisotropy>0&&(g.anisotropyVector.value.set(m.anisotropy*Math.cos(m.anisotropyRotation),m.anisotropy*Math.sin(m.anisotropyRotation)),m.anisotropyMap&&(g.anisotropyMap.value=m.anisotropyMap,e(m.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=m.specularIntensity,g.specularColor.value.copy(m.specularColor),m.specularColorMap&&(g.specularColorMap.value=m.specularColorMap,e(m.specularColorMap,g.specularColorMapTransform)),m.specularIntensityMap&&(g.specularIntensityMap.value=m.specularIntensityMap,e(m.specularIntensityMap,g.specularIntensityMapTransform))}function p(g,m){m.matcap&&(g.matcap.value=m.matcap)}function x(g,m){let S=t.get(m).light;g.referencePosition.value.setFromMatrixPosition(S.matrixWorld),g.nearDistance.value=S.shadow.camera.near,g.farDistance.value=S.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:s}}function T_(n,t,e,i){let s={},r={},a=[],o=e.isWebGL2?n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS):0;function c(S,y){let b=y.program;i.uniformBlockBinding(S,b)}function l(S,y){let b=s[S.id];b===void 0&&(p(S),b=h(S),s[S.id]=b,S.addEventListener("dispose",g));let C=y.program;i.updateUBOMapping(S,C);let A=t.render.frame;r[S.id]!==A&&(f(S),r[S.id]=A)}function h(S){let y=u();S.__bindingPointIndex=y;let b=n.createBuffer(),C=S.__size,A=S.usage;return n.bindBuffer(n.UNIFORM_BUFFER,b),n.bufferData(n.UNIFORM_BUFFER,C,A),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,y,b),b}function u(){for(let S=0;S<o;S++)if(a.indexOf(S)===-1)return a.push(S),S;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function f(S){let y=s[S.id],b=S.uniforms,C=S.__cache;n.bindBuffer(n.UNIFORM_BUFFER,y);for(let A=0,w=b.length;A<w;A++){let F=Array.isArray(b[A])?b[A]:[b[A]];for(let E=0,M=F.length;E<M;E++){let I=F[E];if(d(I,A,E,C)===!0){let N=I.__offset,J=Array.isArray(I.value)?I.value:[I.value],P=0;for(let O=0;O<J.length;O++){let z=J[O],Q=x(z);typeof z=="number"||typeof z=="boolean"?(I.__data[0]=z,n.bufferSubData(n.UNIFORM_BUFFER,N+P,I.__data)):z.isMatrix3?(I.__data[0]=z.elements[0],I.__data[1]=z.elements[1],I.__data[2]=z.elements[2],I.__data[3]=0,I.__data[4]=z.elements[3],I.__data[5]=z.elements[4],I.__data[6]=z.elements[5],I.__data[7]=0,I.__data[8]=z.elements[6],I.__data[9]=z.elements[7],I.__data[10]=z.elements[8],I.__data[11]=0):(z.toArray(I.__data,P),P+=Q.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,N,I.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function d(S,y,b,C){let A=S.value,w=y+"_"+b;if(C[w]===void 0)return typeof A=="number"||typeof A=="boolean"?C[w]=A:C[w]=A.clone(),!0;{let F=C[w];if(typeof A=="number"||typeof A=="boolean"){if(F!==A)return C[w]=A,!0}else if(F.equals(A)===!1)return F.copy(A),!0}return!1}function p(S){let y=S.uniforms,b=0,C=16;for(let w=0,F=y.length;w<F;w++){let E=Array.isArray(y[w])?y[w]:[y[w]];for(let M=0,I=E.length;M<I;M++){let N=E[M],J=Array.isArray(N.value)?N.value:[N.value];for(let P=0,O=J.length;P<O;P++){let z=J[P],Q=x(z),j=b%C;j!==0&&C-j<Q.boundary&&(b+=C-j),N.__data=new Float32Array(Q.storage/Float32Array.BYTES_PER_ELEMENT),N.__offset=b,b+=Q.storage}}}let A=b%C;return A>0&&(b+=C-A),S.__size=b,S.__cache={},this}function x(S){let y={boundary:0,storage:0};return typeof S=="number"||typeof S=="boolean"?(y.boundary=4,y.storage=4):S.isVector2?(y.boundary=8,y.storage=8):S.isVector3||S.isColor?(y.boundary=16,y.storage=12):S.isVector4?(y.boundary=16,y.storage=16):S.isMatrix3?(y.boundary=48,y.storage=48):S.isMatrix4?(y.boundary=64,y.storage=64):S.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",S),y}function g(S){let y=S.target;y.removeEventListener("dispose",g);let b=a.indexOf(y.__bindingPointIndex);a.splice(b,1),n.deleteBuffer(s[y.id]),delete s[y.id],delete r[y.id]}function m(){for(let S in s)n.deleteBuffer(s[S]);a=[],s={},r={}}return{bind:c,update:l,dispose:m}}var ia=class{constructor(t={}){let{canvas:e=U0(),context:i=null,depth:s=!0,stencil:r=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1}=t;this.isWebGLRenderer=!0;let f;i!==null?f=i.getContextAttributes().alpha:f=a;let d=new Uint32Array(4),p=new Int32Array(4),x=null,g=null,m=[],S=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Ee,this._useLegacyLights=!1,this.toneMapping=Xi,this.toneMappingExposure=1;let y=this,b=!1,C=0,A=0,w=null,F=-1,E=null,M=new Ge,I=new Ge,N=null,J=new Ft(0),P=0,O=e.width,z=e.height,Q=1,j=null,K=null,st=new Ge(0,0,O,z),it=new Ge(0,0,O,z),xt=!1,$=new na,et=!1,ut=!1,Lt=null,St=new Ae,Bt=new ht,nt=new L,ct={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function gt(){return w===null?Q:1}let R=i;function rt(T,B){for(let V=0;V<T.length;V++){let X=T[V],G=e.getContext(X,B);if(G!==null)return G}return null}try{let T={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${eh}`),e.addEventListener("webglcontextlost",ft,!1),e.addEventListener("webglcontextrestored",U,!1),e.addEventListener("webglcontextcreationerror",Mt,!1),R===null){let B=["webgl2","webgl","experimental-webgl"];if(y.isWebGL1Renderer===!0&&B.shift(),R=rt(B,T),R===null)throw rt(B)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&R instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),R.getShaderPrecisionFormat===void 0&&(R.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(T){throw console.error("THREE.WebGLRenderer: "+T.message),T}let Y,tt,q,Ct,yt,v,_,D,k,W,Z,bt,lt,wt,zt,qt,at,de,ae,Zt,Ht,Dt,jt,xe;function Ne(){Y=new Wx(R),tt=new zx(R,Y,t),Y.init(tt),Dt=new E_(R,Y,tt),q=new v_(R,Y,tt),Ct=new $x(R),yt=new c_,v=new M_(R,Y,q,yt,tt,Dt,Ct),_=new Hx(y),D=new Vx(y),k=new em(R,tt),jt=new Ox(R,Y,k,tt),W=new Xx(R,k,Ct,jt),Z=new Kx(R,W,k,Ct),ae=new Jx(R,tt,v),qt=new Bx(yt),bt=new o_(y,_,D,Y,tt,jt,qt),lt=new b_(y,yt),wt=new h_,zt=new g_(Y,tt),de=new Nx(y,_,D,q,Z,f,c),at=new __(y,Z,tt),xe=new T_(R,Ct,tt,q),Zt=new Fx(R,Y,Ct,tt),Ht=new Yx(R,Y,Ct,tt),Ct.programs=bt.programs,y.capabilities=tt,y.extensions=Y,y.properties=yt,y.renderLists=wt,y.shadowMap=at,y.state=q,y.info=Ct}Ne();let ie=new Ll(y,R);this.xr=ie,this.getContext=function(){return R},this.getContextAttributes=function(){return R.getContextAttributes()},this.forceContextLoss=function(){let T=Y.get("WEBGL_lose_context");T&&T.loseContext()},this.forceContextRestore=function(){let T=Y.get("WEBGL_lose_context");T&&T.restoreContext()},this.getPixelRatio=function(){return Q},this.setPixelRatio=function(T){T!==void 0&&(Q=T,this.setSize(O,z,!1))},this.getSize=function(T){return T.set(O,z)},this.setSize=function(T,B,V=!0){if(ie.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}O=T,z=B,e.width=Math.floor(T*Q),e.height=Math.floor(B*Q),V===!0&&(e.style.width=T+"px",e.style.height=B+"px"),this.setViewport(0,0,T,B)},this.getDrawingBufferSize=function(T){return T.set(O*Q,z*Q).floor()},this.setDrawingBufferSize=function(T,B,V){O=T,z=B,Q=V,e.width=Math.floor(T*V),e.height=Math.floor(B*V),this.setViewport(0,0,T,B)},this.getCurrentViewport=function(T){return T.copy(M)},this.getViewport=function(T){return T.copy(st)},this.setViewport=function(T,B,V,X){T.isVector4?st.set(T.x,T.y,T.z,T.w):st.set(T,B,V,X),q.viewport(M.copy(st).multiplyScalar(Q).floor())},this.getScissor=function(T){return T.copy(it)},this.setScissor=function(T,B,V,X){T.isVector4?it.set(T.x,T.y,T.z,T.w):it.set(T,B,V,X),q.scissor(I.copy(it).multiplyScalar(Q).floor())},this.getScissorTest=function(){return xt},this.setScissorTest=function(T){q.setScissorTest(xt=T)},this.setOpaqueSort=function(T){j=T},this.setTransparentSort=function(T){K=T},this.getClearColor=function(T){return T.copy(de.getClearColor())},this.setClearColor=function(){de.setClearColor.apply(de,arguments)},this.getClearAlpha=function(){return de.getClearAlpha()},this.setClearAlpha=function(){de.setClearAlpha.apply(de,arguments)},this.clear=function(T=!0,B=!0,V=!0){let X=0;if(T){let G=!1;if(w!==null){let Rt=w.texture.format;G=Rt===Qf||Rt===jf||Rt===Kf}if(G){let Rt=w.texture.type,Ot=Rt===Yi||Rt===ki||Rt===sh||Rt===ds||Rt===Zf||Rt===Jf,Wt=de.getClearColor(),$t=de.getClearAlpha(),ee=Wt.r,Jt=Wt.g,Kt=Wt.b;Ot?(d[0]=ee,d[1]=Jt,d[2]=Kt,d[3]=$t,R.clearBufferuiv(R.COLOR,0,d)):(p[0]=ee,p[1]=Jt,p[2]=Kt,p[3]=$t,R.clearBufferiv(R.COLOR,0,p))}else X|=R.COLOR_BUFFER_BIT}B&&(X|=R.DEPTH_BUFFER_BIT),V&&(X|=R.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),R.clear(X)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",ft,!1),e.removeEventListener("webglcontextrestored",U,!1),e.removeEventListener("webglcontextcreationerror",Mt,!1),wt.dispose(),zt.dispose(),yt.dispose(),_.dispose(),D.dispose(),Z.dispose(),jt.dispose(),xe.dispose(),bt.dispose(),ie.dispose(),ie.removeEventListener("sessionstart",mn),ie.removeEventListener("sessionend",we),Lt&&(Lt.dispose(),Lt=null),gn.stop()};function ft(T){T.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),b=!0}function U(){console.log("THREE.WebGLRenderer: Context Restored."),b=!1;let T=Ct.autoReset,B=at.enabled,V=at.autoUpdate,X=at.needsUpdate,G=at.type;Ne(),Ct.autoReset=T,at.enabled=B,at.autoUpdate=V,at.needsUpdate=X,at.type=G}function Mt(T){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",T.statusMessage)}function Et(T){let B=T.target;B.removeEventListener("dispose",Et),Xt(B)}function Xt(T){Gt(T),yt.remove(T)}function Gt(T){let B=yt.get(T).programs;B!==void 0&&(B.forEach(function(V){bt.releaseProgram(V)}),T.isShaderMaterial&&bt.releaseShaderCache(T))}this.renderBufferDirect=function(T,B,V,X,G,Rt){B===null&&(B=ct);let Ot=G.isMesh&&G.matrixWorld.determinant()<0,Wt=_p(T,B,V,X,G);q.setMaterial(X,Ot);let $t=V.index,ee=1;if(X.wireframe===!0){if($t=W.getWireframeAttribute(V),$t===void 0)return;ee=2}let Jt=V.drawRange,Kt=V.attributes.position,ke=Jt.start*ee,wn=(Jt.start+Jt.count)*ee;Rt!==null&&(ke=Math.max(ke,Rt.start*ee),wn=Math.min(wn,(Rt.start+Rt.count)*ee)),$t!==null?(ke=Math.max(ke,0),wn=Math.min(wn,$t.count)):Kt!=null&&(ke=Math.max(ke,0),wn=Math.min(wn,Kt.count));let tn=wn-ke;if(tn<0||tn===1/0)return;jt.setup(G,X,Wt,V,$t);let mi,De=Zt;if($t!==null&&(mi=k.get($t),De=Ht,De.setIndex(mi)),G.isMesh)X.wireframe===!0?(q.setLineWidth(X.wireframeLinewidth*gt()),De.setMode(R.LINES)):De.setMode(R.TRIANGLES);else if(G.isLine){let se=X.linewidth;se===void 0&&(se=1),q.setLineWidth(se*gt()),G.isLineSegments?De.setMode(R.LINES):G.isLineLoop?De.setMode(R.LINE_LOOP):De.setMode(R.LINE_STRIP)}else G.isPoints?De.setMode(R.POINTS):G.isSprite&&De.setMode(R.TRIANGLES);if(G.isBatchedMesh)De.renderMultiDraw(G._multiDrawStarts,G._multiDrawCounts,G._multiDrawCount);else if(G.isInstancedMesh)De.renderInstances(ke,tn,G.count);else if(V.isInstancedBufferGeometry){let se=V._maxInstanceCount!==void 0?V._maxInstanceCount:1/0,wc=Math.min(V.instanceCount,se);De.renderInstances(ke,tn,wc)}else De.render(ke,tn)};function be(T,B,V){T.transparent===!0&&T.side===Fe&&T.forceSinglePass===!1?(T.side=fn,T.needsUpdate=!0,Ia(T,B,V),T.side=$i,T.needsUpdate=!0,Ia(T,B,V),T.side=Fe):Ia(T,B,V)}this.compile=function(T,B,V=null){V===null&&(V=T),g=zt.get(V),g.init(),S.push(g),V.traverseVisible(function(G){G.isLight&&G.layers.test(B.layers)&&(g.pushLight(G),G.castShadow&&g.pushShadow(G))}),T!==V&&T.traverseVisible(function(G){G.isLight&&G.layers.test(B.layers)&&(g.pushLight(G),G.castShadow&&g.pushShadow(G))}),g.setupLights(y._useLegacyLights);let X=new Set;return T.traverse(function(G){let Rt=G.material;if(Rt)if(Array.isArray(Rt))for(let Ot=0;Ot<Rt.length;Ot++){let Wt=Rt[Ot];be(Wt,V,G),X.add(Wt)}else be(Rt,V,G),X.add(Rt)}),S.pop(),g=null,X},this.compileAsync=function(T,B,V=null){let X=this.compile(T,B,V);return new Promise(G=>{function Rt(){if(X.forEach(function(Ot){yt.get(Ot).currentProgram.isReady()&&X.delete(Ot)}),X.size===0){G(T);return}setTimeout(Rt,10)}Y.get("KHR_parallel_shader_compile")!==null?Rt():setTimeout(Rt,10)})};let Te=null;function Qe(T){Te&&Te(T)}function mn(){gn.stop()}function we(){gn.start()}let gn=new ld;gn.setAnimationLoop(Qe),typeof self<"u"&&gn.setContext(self),this.setAnimationLoop=function(T){Te=T,ie.setAnimationLoop(T),T===null?gn.stop():gn.start()},ie.addEventListener("sessionstart",mn),ie.addEventListener("sessionend",we),this.render=function(T,B){if(B!==void 0&&B.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(b===!0)return;T.matrixWorldAutoUpdate===!0&&T.updateMatrixWorld(),B.parent===null&&B.matrixWorldAutoUpdate===!0&&B.updateMatrixWorld(),ie.enabled===!0&&ie.isPresenting===!0&&(ie.cameraAutoUpdate===!0&&ie.updateCamera(B),B=ie.getCamera()),T.isScene===!0&&T.onBeforeRender(y,T,B,w),g=zt.get(T,S.length),g.init(),S.push(g),St.multiplyMatrices(B.projectionMatrix,B.matrixWorldInverse),$.setFromProjectionMatrix(St),ut=this.localClippingEnabled,et=qt.init(this.clippingPlanes,ut),x=wt.get(T,m.length),x.init(),m.push(x),ri(T,B,0,y.sortObjects),x.finish(),y.sortObjects===!0&&x.sort(j,K),this.info.render.frame++,et===!0&&qt.beginShadows();let V=g.state.shadowsArray;if(at.render(V,T,B),et===!0&&qt.endShadows(),this.info.autoReset===!0&&this.info.reset(),de.render(x,T),g.setupLights(y._useLegacyLights),B.isArrayCamera){let X=B.cameras;for(let G=0,Rt=X.length;G<Rt;G++){let Ot=X[G];ru(x,T,Ot,Ot.viewport)}}else ru(x,T,B);w!==null&&(v.updateMultisampleRenderTarget(w),v.updateRenderTargetMipmap(w)),T.isScene===!0&&T.onAfterRender(y,T,B),jt.resetDefaultState(),F=-1,E=null,S.pop(),S.length>0?g=S[S.length-1]:g=null,m.pop(),m.length>0?x=m[m.length-1]:x=null};function ri(T,B,V,X){if(T.visible===!1)return;if(T.layers.test(B.layers)){if(T.isGroup)V=T.renderOrder;else if(T.isLOD)T.autoUpdate===!0&&T.update(B);else if(T.isLight)g.pushLight(T),T.castShadow&&g.pushShadow(T);else if(T.isSprite){if(!T.frustumCulled||$.intersectsSprite(T)){X&&nt.setFromMatrixPosition(T.matrixWorld).applyMatrix4(St);let Ot=Z.update(T),Wt=T.material;Wt.visible&&x.push(T,Ot,Wt,V,nt.z,null)}}else if((T.isMesh||T.isLine||T.isPoints)&&(!T.frustumCulled||$.intersectsObject(T))){let Ot=Z.update(T),Wt=T.material;if(X&&(T.boundingSphere!==void 0?(T.boundingSphere===null&&T.computeBoundingSphere(),nt.copy(T.boundingSphere.center)):(Ot.boundingSphere===null&&Ot.computeBoundingSphere(),nt.copy(Ot.boundingSphere.center)),nt.applyMatrix4(T.matrixWorld).applyMatrix4(St)),Array.isArray(Wt)){let $t=Ot.groups;for(let ee=0,Jt=$t.length;ee<Jt;ee++){let Kt=$t[ee],ke=Wt[Kt.materialIndex];ke&&ke.visible&&x.push(T,Ot,ke,V,nt.z,Kt)}}else Wt.visible&&x.push(T,Ot,Wt,V,nt.z,null)}}let Rt=T.children;for(let Ot=0,Wt=Rt.length;Ot<Wt;Ot++)ri(Rt[Ot],B,V,X)}function ru(T,B,V,X){let G=T.opaque,Rt=T.transmissive,Ot=T.transparent;g.setupLightsView(V),et===!0&&qt.setGlobalState(y.clippingPlanes,V),Rt.length>0&&yp(G,Rt,B,V),X&&q.viewport(M.copy(X)),G.length>0&&La(G,B,V),Rt.length>0&&La(Rt,B,V),Ot.length>0&&La(Ot,B,V),q.buffers.depth.setTest(!0),q.buffers.depth.setMask(!0),q.buffers.color.setMask(!0),q.setPolygonOffset(!1)}function yp(T,B,V,X){if((V.isScene===!0?V.overrideMaterial:null)!==null)return;let Rt=tt.isWebGL2;Lt===null&&(Lt=new Ti(1,1,{generateMipmaps:!0,type:Y.has("EXT_color_buffer_half_float")?ta:Yi,minFilter:Qr,samples:Rt?4:0})),y.getDrawingBufferSize(Bt),Rt?Lt.setSize(Bt.x,Bt.y):Lt.setSize(_o(Bt.x),_o(Bt.y));let Ot=y.getRenderTarget();y.setRenderTarget(Lt),y.getClearColor(J),P=y.getClearAlpha(),P<1&&y.setClearColor(16777215,.5),y.clear();let Wt=y.toneMapping;y.toneMapping=Xi,La(T,V,X),v.updateMultisampleRenderTarget(Lt),v.updateRenderTargetMipmap(Lt);let $t=!1;for(let ee=0,Jt=B.length;ee<Jt;ee++){let Kt=B[ee],ke=Kt.object,wn=Kt.geometry,tn=Kt.material,mi=Kt.group;if(tn.side===Fe&&ke.layers.test(X.layers)){let De=tn.side;tn.side=fn,tn.needsUpdate=!0,au(ke,V,X,wn,tn,mi),tn.side=De,tn.needsUpdate=!0,$t=!0}}$t===!0&&(v.updateMultisampleRenderTarget(Lt),v.updateRenderTargetMipmap(Lt)),y.setRenderTarget(Ot),y.setClearColor(J,P),y.toneMapping=Wt}function La(T,B,V){let X=B.isScene===!0?B.overrideMaterial:null;for(let G=0,Rt=T.length;G<Rt;G++){let Ot=T[G],Wt=Ot.object,$t=Ot.geometry,ee=X===null?Ot.material:X,Jt=Ot.group;Wt.layers.test(V.layers)&&au(Wt,B,V,$t,ee,Jt)}}function au(T,B,V,X,G,Rt){T.onBeforeRender(y,B,V,X,G,Rt),T.modelViewMatrix.multiplyMatrices(V.matrixWorldInverse,T.matrixWorld),T.normalMatrix.getNormalMatrix(T.modelViewMatrix),G.onBeforeRender(y,B,V,X,T,Rt),G.transparent===!0&&G.side===Fe&&G.forceSinglePass===!1?(G.side=fn,G.needsUpdate=!0,y.renderBufferDirect(V,B,X,G,T,Rt),G.side=$i,G.needsUpdate=!0,y.renderBufferDirect(V,B,X,G,T,Rt),G.side=Fe):y.renderBufferDirect(V,B,X,G,T,Rt),T.onAfterRender(y,B,V,X,G,Rt)}function Ia(T,B,V){B.isScene!==!0&&(B=ct);let X=yt.get(T),G=g.state.lights,Rt=g.state.shadowsArray,Ot=G.state.version,Wt=bt.getParameters(T,G.state,Rt,B,V),$t=bt.getProgramCacheKey(Wt),ee=X.programs;X.environment=T.isMeshStandardMaterial?B.environment:null,X.fog=B.fog,X.envMap=(T.isMeshStandardMaterial?D:_).get(T.envMap||X.environment),ee===void 0&&(T.addEventListener("dispose",Et),ee=new Map,X.programs=ee);let Jt=ee.get($t);if(Jt!==void 0){if(X.currentProgram===Jt&&X.lightsStateVersion===Ot)return cu(T,Wt),Jt}else Wt.uniforms=bt.getUniforms(T),T.onBuild(V,Wt,y),T.onBeforeCompile(Wt,y),Jt=bt.acquireProgram(Wt,$t),ee.set($t,Jt),X.uniforms=Wt.uniforms;let Kt=X.uniforms;return(!T.isShaderMaterial&&!T.isRawShaderMaterial||T.clipping===!0)&&(Kt.clippingPlanes=qt.uniform),cu(T,Wt),X.needsLights=Mp(T),X.lightsStateVersion=Ot,X.needsLights&&(Kt.ambientLightColor.value=G.state.ambient,Kt.lightProbe.value=G.state.probe,Kt.directionalLights.value=G.state.directional,Kt.directionalLightShadows.value=G.state.directionalShadow,Kt.spotLights.value=G.state.spot,Kt.spotLightShadows.value=G.state.spotShadow,Kt.rectAreaLights.value=G.state.rectArea,Kt.ltc_1.value=G.state.rectAreaLTC1,Kt.ltc_2.value=G.state.rectAreaLTC2,Kt.pointLights.value=G.state.point,Kt.pointLightShadows.value=G.state.pointShadow,Kt.hemisphereLights.value=G.state.hemi,Kt.directionalShadowMap.value=G.state.directionalShadowMap,Kt.directionalShadowMatrix.value=G.state.directionalShadowMatrix,Kt.spotShadowMap.value=G.state.spotShadowMap,Kt.spotLightMatrix.value=G.state.spotLightMatrix,Kt.spotLightMap.value=G.state.spotLightMap,Kt.pointShadowMap.value=G.state.pointShadowMap,Kt.pointShadowMatrix.value=G.state.pointShadowMatrix),X.currentProgram=Jt,X.uniformsList=null,Jt}function ou(T){if(T.uniformsList===null){let B=T.currentProgram.getUniforms();T.uniformsList=ar.seqWithValue(B.seq,T.uniforms)}return T.uniformsList}function cu(T,B){let V=yt.get(T);V.outputColorSpace=B.outputColorSpace,V.batching=B.batching,V.instancing=B.instancing,V.instancingColor=B.instancingColor,V.skinning=B.skinning,V.morphTargets=B.morphTargets,V.morphNormals=B.morphNormals,V.morphColors=B.morphColors,V.morphTargetsCount=B.morphTargetsCount,V.numClippingPlanes=B.numClippingPlanes,V.numIntersection=B.numClipIntersection,V.vertexAlphas=B.vertexAlphas,V.vertexTangents=B.vertexTangents,V.toneMapping=B.toneMapping}function _p(T,B,V,X,G){B.isScene!==!0&&(B=ct),v.resetTextureUnits();let Rt=B.fog,Ot=X.isMeshStandardMaterial?B.environment:null,Wt=w===null?y.outputColorSpace:w.isXRRenderTarget===!0?w.texture.colorSpace:bi,$t=(X.isMeshStandardMaterial?D:_).get(X.envMap||Ot),ee=X.vertexColors===!0&&!!V.attributes.color&&V.attributes.color.itemSize===4,Jt=!!V.attributes.tangent&&(!!X.normalMap||X.anisotropy>0),Kt=!!V.morphAttributes.position,ke=!!V.morphAttributes.normal,wn=!!V.morphAttributes.color,tn=Xi;X.toneMapped&&(w===null||w.isXRRenderTarget===!0)&&(tn=y.toneMapping);let mi=V.morphAttributes.position||V.morphAttributes.normal||V.morphAttributes.color,De=mi!==void 0?mi.length:0,se=yt.get(X),wc=g.state.lights;if(et===!0&&(ut===!0||T!==E)){let Nn=T===E&&X.id===F;qt.setState(X,T,Nn)}let Oe=!1;X.version===se.__version?(se.needsLights&&se.lightsStateVersion!==wc.state.version||se.outputColorSpace!==Wt||G.isBatchedMesh&&se.batching===!1||!G.isBatchedMesh&&se.batching===!0||G.isInstancedMesh&&se.instancing===!1||!G.isInstancedMesh&&se.instancing===!0||G.isSkinnedMesh&&se.skinning===!1||!G.isSkinnedMesh&&se.skinning===!0||G.isInstancedMesh&&se.instancingColor===!0&&G.instanceColor===null||G.isInstancedMesh&&se.instancingColor===!1&&G.instanceColor!==null||se.envMap!==$t||X.fog===!0&&se.fog!==Rt||se.numClippingPlanes!==void 0&&(se.numClippingPlanes!==qt.numPlanes||se.numIntersection!==qt.numIntersection)||se.vertexAlphas!==ee||se.vertexTangents!==Jt||se.morphTargets!==Kt||se.morphNormals!==ke||se.morphColors!==wn||se.toneMapping!==tn||tt.isWebGL2===!0&&se.morphTargetsCount!==De)&&(Oe=!0):(Oe=!0,se.__version=X.version);let is=se.currentProgram;Oe===!0&&(is=Ia(X,B,G));let lu=!1,Nr=!1,Ac=!1,ln=is.getUniforms(),ss=se.uniforms;if(q.useProgram(is.program)&&(lu=!0,Nr=!0,Ac=!0),X.id!==F&&(F=X.id,Nr=!0),lu||E!==T){ln.setValue(R,"projectionMatrix",T.projectionMatrix),ln.setValue(R,"viewMatrix",T.matrixWorldInverse);let Nn=ln.map.cameraPosition;Nn!==void 0&&Nn.setValue(R,nt.setFromMatrixPosition(T.matrixWorld)),tt.logarithmicDepthBuffer&&ln.setValue(R,"logDepthBufFC",2/(Math.log(T.far+1)/Math.LN2)),(X.isMeshPhongMaterial||X.isMeshToonMaterial||X.isMeshLambertMaterial||X.isMeshBasicMaterial||X.isMeshStandardMaterial||X.isShaderMaterial)&&ln.setValue(R,"isOrthographic",T.isOrthographicCamera===!0),E!==T&&(E=T,Nr=!0,Ac=!0)}if(G.isSkinnedMesh){ln.setOptional(R,G,"bindMatrix"),ln.setOptional(R,G,"bindMatrixInverse");let Nn=G.skeleton;Nn&&(tt.floatVertexTextures?(Nn.boneTexture===null&&Nn.computeBoneTexture(),ln.setValue(R,"boneTexture",Nn.boneTexture,v)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}G.isBatchedMesh&&(ln.setOptional(R,G,"batchingTexture"),ln.setValue(R,"batchingTexture",G._matricesTexture,v));let Rc=V.morphAttributes;if((Rc.position!==void 0||Rc.normal!==void 0||Rc.color!==void 0&&tt.isWebGL2===!0)&&ae.update(G,V,is),(Nr||se.receiveShadow!==G.receiveShadow)&&(se.receiveShadow=G.receiveShadow,ln.setValue(R,"receiveShadow",G.receiveShadow)),X.isMeshGouraudMaterial&&X.envMap!==null&&(ss.envMap.value=$t,ss.flipEnvMap.value=$t.isCubeTexture&&$t.isRenderTargetTexture===!1?-1:1),Nr&&(ln.setValue(R,"toneMappingExposure",y.toneMappingExposure),se.needsLights&&vp(ss,Ac),Rt&&X.fog===!0&&lt.refreshFogUniforms(ss,Rt),lt.refreshMaterialUniforms(ss,X,Q,z,Lt),ar.upload(R,ou(se),ss,v)),X.isShaderMaterial&&X.uniformsNeedUpdate===!0&&(ar.upload(R,ou(se),ss,v),X.uniformsNeedUpdate=!1),X.isSpriteMaterial&&ln.setValue(R,"center",G.center),ln.setValue(R,"modelViewMatrix",G.modelViewMatrix),ln.setValue(R,"normalMatrix",G.normalMatrix),ln.setValue(R,"modelMatrix",G.matrixWorld),X.isShaderMaterial||X.isRawShaderMaterial){let Nn=X.uniformsGroups;for(let Cc=0,Ep=Nn.length;Cc<Ep;Cc++)if(tt.isWebGL2){let hu=Nn[Cc];xe.update(hu,is),xe.bind(hu,is)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return is}function vp(T,B){T.ambientLightColor.needsUpdate=B,T.lightProbe.needsUpdate=B,T.directionalLights.needsUpdate=B,T.directionalLightShadows.needsUpdate=B,T.pointLights.needsUpdate=B,T.pointLightShadows.needsUpdate=B,T.spotLights.needsUpdate=B,T.spotLightShadows.needsUpdate=B,T.rectAreaLights.needsUpdate=B,T.hemisphereLights.needsUpdate=B}function Mp(T){return T.isMeshLambertMaterial||T.isMeshToonMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isShadowMaterial||T.isShaderMaterial&&T.lights===!0}this.getActiveCubeFace=function(){return C},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return w},this.setRenderTargetTextures=function(T,B,V){yt.get(T.texture).__webglTexture=B,yt.get(T.depthTexture).__webglTexture=V;let X=yt.get(T);X.__hasExternalTextures=!0,X.__hasExternalTextures&&(X.__autoAllocateDepthBuffer=V===void 0,X.__autoAllocateDepthBuffer||Y.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),X.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(T,B){let V=yt.get(T);V.__webglFramebuffer=B,V.__useDefaultFramebuffer=B===void 0},this.setRenderTarget=function(T,B=0,V=0){w=T,C=B,A=V;let X=!0,G=null,Rt=!1,Ot=!1;if(T){let $t=yt.get(T);$t.__useDefaultFramebuffer!==void 0?(q.bindFramebuffer(R.FRAMEBUFFER,null),X=!1):$t.__webglFramebuffer===void 0?v.setupRenderTarget(T):$t.__hasExternalTextures&&v.rebindTextures(T,yt.get(T.texture).__webglTexture,yt.get(T.depthTexture).__webglTexture);let ee=T.texture;(ee.isData3DTexture||ee.isDataArrayTexture||ee.isCompressedArrayTexture)&&(Ot=!0);let Jt=yt.get(T).__webglFramebuffer;T.isWebGLCubeRenderTarget?(Array.isArray(Jt[B])?G=Jt[B][V]:G=Jt[B],Rt=!0):tt.isWebGL2&&T.samples>0&&v.useMultisampledRTT(T)===!1?G=yt.get(T).__webglMultisampledFramebuffer:Array.isArray(Jt)?G=Jt[V]:G=Jt,M.copy(T.viewport),I.copy(T.scissor),N=T.scissorTest}else M.copy(st).multiplyScalar(Q).floor(),I.copy(it).multiplyScalar(Q).floor(),N=xt;if(q.bindFramebuffer(R.FRAMEBUFFER,G)&&tt.drawBuffers&&X&&q.drawBuffers(T,G),q.viewport(M),q.scissor(I),q.setScissorTest(N),Rt){let $t=yt.get(T.texture);R.framebufferTexture2D(R.FRAMEBUFFER,R.COLOR_ATTACHMENT0,R.TEXTURE_CUBE_MAP_POSITIVE_X+B,$t.__webglTexture,V)}else if(Ot){let $t=yt.get(T.texture),ee=B||0;R.framebufferTextureLayer(R.FRAMEBUFFER,R.COLOR_ATTACHMENT0,$t.__webglTexture,V||0,ee)}F=-1},this.readRenderTargetPixels=function(T,B,V,X,G,Rt,Ot){if(!(T&&T.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Wt=yt.get(T).__webglFramebuffer;if(T.isWebGLCubeRenderTarget&&Ot!==void 0&&(Wt=Wt[Ot]),Wt){q.bindFramebuffer(R.FRAMEBUFFER,Wt);try{let $t=T.texture,ee=$t.format,Jt=$t.type;if(ee!==jn&&Dt.convert(ee)!==R.getParameter(R.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let Kt=Jt===ta&&(Y.has("EXT_color_buffer_half_float")||tt.isWebGL2&&Y.has("EXT_color_buffer_float"));if(Jt!==Yi&&Dt.convert(Jt)!==R.getParameter(R.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Jt===Gi&&(tt.isWebGL2||Y.has("OES_texture_float")||Y.has("WEBGL_color_buffer_float")))&&!Kt){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}B>=0&&B<=T.width-X&&V>=0&&V<=T.height-G&&R.readPixels(B,V,X,G,Dt.convert(ee),Dt.convert(Jt),Rt)}finally{let $t=w!==null?yt.get(w).__webglFramebuffer:null;q.bindFramebuffer(R.FRAMEBUFFER,$t)}}},this.copyFramebufferToTexture=function(T,B,V=0){let X=Math.pow(2,-V),G=Math.floor(B.image.width*X),Rt=Math.floor(B.image.height*X);v.setTexture2D(B,0),R.copyTexSubImage2D(R.TEXTURE_2D,V,0,0,T.x,T.y,G,Rt),q.unbindTexture()},this.copyTextureToTexture=function(T,B,V,X=0){let G=B.image.width,Rt=B.image.height,Ot=Dt.convert(V.format),Wt=Dt.convert(V.type);v.setTexture2D(V,0),R.pixelStorei(R.UNPACK_FLIP_Y_WEBGL,V.flipY),R.pixelStorei(R.UNPACK_PREMULTIPLY_ALPHA_WEBGL,V.premultiplyAlpha),R.pixelStorei(R.UNPACK_ALIGNMENT,V.unpackAlignment),B.isDataTexture?R.texSubImage2D(R.TEXTURE_2D,X,T.x,T.y,G,Rt,Ot,Wt,B.image.data):B.isCompressedTexture?R.compressedTexSubImage2D(R.TEXTURE_2D,X,T.x,T.y,B.mipmaps[0].width,B.mipmaps[0].height,Ot,B.mipmaps[0].data):R.texSubImage2D(R.TEXTURE_2D,X,T.x,T.y,Ot,Wt,B.image),X===0&&V.generateMipmaps&&R.generateMipmap(R.TEXTURE_2D),q.unbindTexture()},this.copyTextureToTexture3D=function(T,B,V,X,G=0){if(y.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let Rt=T.max.x-T.min.x+1,Ot=T.max.y-T.min.y+1,Wt=T.max.z-T.min.z+1,$t=Dt.convert(X.format),ee=Dt.convert(X.type),Jt;if(X.isData3DTexture)v.setTexture3D(X,0),Jt=R.TEXTURE_3D;else if(X.isDataArrayTexture||X.isCompressedArrayTexture)v.setTexture2DArray(X,0),Jt=R.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}R.pixelStorei(R.UNPACK_FLIP_Y_WEBGL,X.flipY),R.pixelStorei(R.UNPACK_PREMULTIPLY_ALPHA_WEBGL,X.premultiplyAlpha),R.pixelStorei(R.UNPACK_ALIGNMENT,X.unpackAlignment);let Kt=R.getParameter(R.UNPACK_ROW_LENGTH),ke=R.getParameter(R.UNPACK_IMAGE_HEIGHT),wn=R.getParameter(R.UNPACK_SKIP_PIXELS),tn=R.getParameter(R.UNPACK_SKIP_ROWS),mi=R.getParameter(R.UNPACK_SKIP_IMAGES),De=V.isCompressedTexture?V.mipmaps[G]:V.image;R.pixelStorei(R.UNPACK_ROW_LENGTH,De.width),R.pixelStorei(R.UNPACK_IMAGE_HEIGHT,De.height),R.pixelStorei(R.UNPACK_SKIP_PIXELS,T.min.x),R.pixelStorei(R.UNPACK_SKIP_ROWS,T.min.y),R.pixelStorei(R.UNPACK_SKIP_IMAGES,T.min.z),V.isDataTexture||V.isData3DTexture?R.texSubImage3D(Jt,G,B.x,B.y,B.z,Rt,Ot,Wt,$t,ee,De.data):V.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),R.compressedTexSubImage3D(Jt,G,B.x,B.y,B.z,Rt,Ot,Wt,$t,De.data)):R.texSubImage3D(Jt,G,B.x,B.y,B.z,Rt,Ot,Wt,$t,ee,De),R.pixelStorei(R.UNPACK_ROW_LENGTH,Kt),R.pixelStorei(R.UNPACK_IMAGE_HEIGHT,ke),R.pixelStorei(R.UNPACK_SKIP_PIXELS,wn),R.pixelStorei(R.UNPACK_SKIP_ROWS,tn),R.pixelStorei(R.UNPACK_SKIP_IMAGES,mi),G===0&&X.generateMipmaps&&R.generateMipmap(Jt),q.unbindTexture()},this.initTexture=function(T){T.isCubeTexture?v.setTextureCube(T,0):T.isData3DTexture?v.setTexture3D(T,0):T.isDataArrayTexture||T.isCompressedArrayTexture?v.setTexture2DArray(T,0):v.setTexture2D(T,0),q.unbindTexture()},this.resetState=function(){C=0,A=0,w=null,q.reset(),jt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Si}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=t===rh?"display-p3":"srgb",e.unpackColorSpace=_e.workingColorSpace===$o?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===Ee?ms:ed}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===ms?Ee:bi}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}},Il=class extends ia{};Il.prototype.isWebGL1Renderer=!0;var Io=class n{constructor(t,e=1,i=1e3){this.isFog=!0,this.name="",this.color=new Ft(t),this.near=e,this.far=i}clone(){return new n(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},sa=class extends qe{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}},Dl=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=ml,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=ci()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,i){t*=this.stride,i*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[i+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ci()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(e,this.stride);return i.setUsage(this.usage),i}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ci()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},xn=new L,Do=class n{constructor(t,e,i,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=i,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,i=this.data.count;e<i;e++)xn.fromBufferAttribute(this,e),xn.applyMatrix4(t),this.setXYZ(e,xn.x,xn.y,xn.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)xn.fromBufferAttribute(this,e),xn.applyNormalMatrix(t),this.setXYZ(e,xn.x,xn.y,xn.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)xn.fromBufferAttribute(this,e),xn.transformDirection(t),this.setXYZ(e,xn.x,xn.y,xn.z);return this}setX(t,e){return this.normalized&&(e=ye(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=ye(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=ye(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=ye(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=oi(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=oi(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=oi(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=oi(e,this.array)),e}setXY(t,e,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=ye(e,this.array),i=ye(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this}setXYZ(t,e,i,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=ye(e,this.array),i=ye(i,this.array),s=ye(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this}setXYZW(t,e,i,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=ye(e,this.array),i=ye(i,this.array),s=ye(s,this.array),r=ye(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let i=0;i<this.count;i++){let s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new fe(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new n(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let i=0;i<this.count;i++){let s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},Ki=class extends wi{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Ft(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Ks,Hr=new L,js=new L,Qs=new L,tr=new ht,kr=new ht,md=new Ae,eo=new L,Gr=new L,no=new L,If=new ht,rl=new ht,Df=new ht,gs=class extends qe{constructor(t=new Ki){if(super(),this.isSprite=!0,this.type="Sprite",Ks===void 0){Ks=new Pe;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new Dl(e,5);Ks.setIndex([0,1,2,0,2,3]),Ks.setAttribute("position",new Do(i,3,0,!1)),Ks.setAttribute("uv",new Do(i,2,3,!1))}this.geometry=Ks,this.material=t,this.center=new ht(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),js.setFromMatrixScale(this.matrixWorld),md.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),Qs.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&js.multiplyScalar(-Qs.z);let i=this.material.rotation,s,r;i!==0&&(r=Math.cos(i),s=Math.sin(i));let a=this.center;io(eo.set(-.5,-.5,0),Qs,a,js,s,r),io(Gr.set(.5,-.5,0),Qs,a,js,s,r),io(no.set(.5,.5,0),Qs,a,js,s,r),If.set(0,0),rl.set(1,0),Df.set(1,1);let o=t.ray.intersectTriangle(eo,Gr,no,!1,Hr);if(o===null&&(io(Gr.set(-.5,.5,0),Qs,a,js,s,r),rl.set(0,1),o=t.ray.intersectTriangle(eo,no,Gr,!1,Hr),o===null))return;let c=t.ray.origin.distanceTo(Hr);c<t.near||c>t.far||e.push({distance:c,point:Hr.clone(),uv:fs.getInterpolation(Hr,eo,Gr,no,If,rl,Df,new ht),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function io(n,t,e,i,s,r){tr.subVectors(n,e).addScalar(.5).multiply(i),s!==void 0?(kr.x=r*tr.x-s*tr.y,kr.y=s*tr.x+r*tr.y):kr.copy(tr),n.copy(t),n.x+=kr.x,n.y+=kr.y,n.applyMatrix4(md)}var Uo=class extends fe{constructor(t,e,i,s=1){super(t,e,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},er=new Ae,Uf=new Ae,so=[],Nf=new Hn,w_=new Ae,Vr=new Tt,Wr=new Ji,No=class extends Tt{constructor(t,e,i){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Uo(new Float32Array(i*16),16),this.instanceColor=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<i;s++)this.setMatrixAt(s,w_)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new Hn),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,er),Nf.copy(t.boundingBox).applyMatrix4(er),this.boundingBox.union(Nf)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Ji),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,er),Wr.copy(t.boundingSphere).applyMatrix4(er),this.boundingSphere.union(Wr)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}raycast(t,e){let i=this.matrixWorld,s=this.count;if(Vr.geometry=this.geometry,Vr.material=this.material,Vr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Wr.copy(this.boundingSphere),Wr.applyMatrix4(i),t.ray.intersectsSphere(Wr)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,er),Uf.multiplyMatrices(i,er),Vr.matrixWorld=Uf,Vr.raycast(t,so);for(let a=0,o=so.length;a<o;a++){let c=so[a];c.instanceId=r,c.object=this,e.push(c)}so.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new Uo(new Float32Array(this.instanceMatrix.count*3),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var ra=class extends wi{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Ft(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Of=new Ae,Ul=new bo,ro=new Ji,ao=new L,aa=class extends qe{constructor(t=new Pe,e=new ra){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){let i=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),ro.copy(i.boundingSphere),ro.applyMatrix4(s),ro.radius+=r,t.ray.intersectsSphere(ro)===!1)return;Of.copy(s).invert(),Ul.copy(t.ray).applyMatrix4(Of);let o=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=i.index,u=i.attributes.position;if(l!==null){let f=Math.max(0,a.start),d=Math.min(l.count,a.start+a.count);for(let p=f,x=d;p<x;p++){let g=l.getX(p);ao.fromBufferAttribute(u,g),Ff(ao,g,c,s,t,e,this)}}else{let f=Math.max(0,a.start),d=Math.min(u.count,a.start+a.count);for(let p=f,x=d;p<x;p++)ao.fromBufferAttribute(u,p),Ff(ao,p,c,s,t,e,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){let s=e[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){let o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}};function Ff(n,t,e,i,s,r,a){let o=Ul.distanceSqToPoint(n);if(o<e){let c=new L;Ul.closestPointToPoint(n,c),c.applyMatrix4(i);let l=s.ray.origin.distanceTo(c);if(l<s.near||l>s.far)return;r.push({distance:l,distanceToRay:Math.sqrt(o),point:c,index:t,face:null,object:a})}}var Qn=class extends Bn{constructor(t,e,i,s,r,a,o,c,l){super(t,e,i,s,r,a,o,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}},Gn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){let i=this.getUtoTmapping(t);return this.getPoint(i,e)}getPoints(t=5){let e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return e}getSpacedPoints(t=5){let e=[];for(let i=0;i<=t;i++)e.push(this.getPointAt(i/t));return e}getLength(){let t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let e=[],i,s=this.getPoint(0),r=0;e.push(0);for(let a=1;a<=t;a++)i=this.getPoint(a/t),r+=i.distanceTo(s),e.push(r),s=i;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){let i=this.getLengths(),s=0,r=i.length,a;e?a=e:a=t*i[r-1];let o=0,c=r-1,l;for(;o<=c;)if(s=Math.floor(o+(c-o)/2),l=i[s]-a,l<0)o=s+1;else if(l>0)c=s-1;else{c=s;break}if(s=c,i[s]===a)return s/(r-1);let h=i[s],f=i[s+1]-h,d=(a-h)/f;return(s+d)/(r-1)}getTangent(t,e){let s=t-1e-4,r=t+1e-4;s<0&&(s=0),r>1&&(r=1);let a=this.getPoint(s),o=this.getPoint(r),c=e||(a.isVector2?new ht:new L);return c.copy(o).sub(a).normalize(),c}getTangentAt(t,e){let i=this.getUtoTmapping(t);return this.getTangent(i,e)}computeFrenetFrames(t,e){let i=new L,s=[],r=[],a=[],o=new L,c=new Ae;for(let d=0;d<=t;d++){let p=d/t;s[d]=this.getTangentAt(p,new L)}r[0]=new L,a[0]=new L;let l=Number.MAX_VALUE,h=Math.abs(s[0].x),u=Math.abs(s[0].y),f=Math.abs(s[0].z);h<=l&&(l=h,i.set(1,0,0)),u<=l&&(l=u,i.set(0,1,0)),f<=l&&i.set(0,0,1),o.crossVectors(s[0],i).normalize(),r[0].crossVectors(s[0],o),a[0].crossVectors(s[0],r[0]);for(let d=1;d<=t;d++){if(r[d]=r[d-1].clone(),a[d]=a[d-1].clone(),o.crossVectors(s[d-1],s[d]),o.length()>Number.EPSILON){o.normalize();let p=Math.acos(an(s[d-1].dot(s[d]),-1,1));r[d].applyMatrix4(c.makeRotationAxis(o,p))}a[d].crossVectors(s[d],r[d])}if(e===!0){let d=Math.acos(an(r[0].dot(r[t]),-1,1));d/=t,s[0].dot(o.crossVectors(r[0],r[t]))>0&&(d=-d);for(let p=1;p<=t;p++)r[p].applyMatrix4(c.makeRotationAxis(s[p],d*p)),a[p].crossVectors(s[p],r[p])}return{tangents:s,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){let t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}},oa=class extends Gn{constructor(t=0,e=0,i=1,s=1,r=0,a=Math.PI*2,o=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=i,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=c}getPoint(t,e){let i=e||new ht,s=Math.PI*2,r=this.aEndAngle-this.aStartAngle,a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(a?r=0:r=s),this.aClockwise===!0&&!a&&(r===s?r=-s:r=r-s);let o=this.aStartAngle+t*r,c=this.aX+this.xRadius*Math.cos(o),l=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),f=c-this.aX,d=l-this.aY;c=f*h-d*u+this.aX,l=f*u+d*h+this.aY}return i.set(c,l)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){let t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}},Nl=class extends oa{constructor(t,e,i,s,r,a){super(t,e,i,i,s,r,a),this.isArcCurve=!0,this.type="ArcCurve"}};function ch(){let n=0,t=0,e=0,i=0;function s(r,a,o,c){n=r,t=o,e=-3*r+3*a-2*o-c,i=2*r-2*a+o+c}return{initCatmullRom:function(r,a,o,c,l){s(a,o,l*(o-r),l*(c-a))},initNonuniformCatmullRom:function(r,a,o,c,l,h,u){let f=(a-r)/l-(o-r)/(l+h)+(o-a)/h,d=(o-a)/h-(c-a)/(h+u)+(c-o)/u;f*=h,d*=h,s(a,o,f,d)},calc:function(r){let a=r*r,o=a*r;return n+t*r+e*a+i*o}}}var oo=new L,al=new ch,ol=new ch,cl=new ch,ca=class extends Gn{constructor(t=[],e=!1,i="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=i,this.tension=s}getPoint(t,e=new L){let i=e,s=this.points,r=s.length,a=(r-(this.closed?0:1))*t,o=Math.floor(a),c=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/r)+1)*r:c===0&&o===r-1&&(o=r-2,c=1);let l,h;this.closed||o>0?l=s[(o-1)%r]:(oo.subVectors(s[0],s[1]).add(s[0]),l=oo);let u=s[o%r],f=s[(o+1)%r];if(this.closed||o+2<r?h=s[(o+2)%r]:(oo.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=oo),this.curveType==="centripetal"||this.curveType==="chordal"){let d=this.curveType==="chordal"?.5:.25,p=Math.pow(l.distanceToSquared(u),d),x=Math.pow(u.distanceToSquared(f),d),g=Math.pow(f.distanceToSquared(h),d);x<1e-4&&(x=1),p<1e-4&&(p=x),g<1e-4&&(g=x),al.initNonuniformCatmullRom(l.x,u.x,f.x,h.x,p,x,g),ol.initNonuniformCatmullRom(l.y,u.y,f.y,h.y,p,x,g),cl.initNonuniformCatmullRom(l.z,u.z,f.z,h.z,p,x,g)}else this.curveType==="catmullrom"&&(al.initCatmullRom(l.x,u.x,f.x,h.x,this.tension),ol.initCatmullRom(l.y,u.y,f.y,h.y,this.tension),cl.initCatmullRom(l.z,u.z,f.z,h.z,this.tension));return i.set(al.calc(c),ol.calc(c),cl.calc(c)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(s.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){let s=this.points[e];t.points.push(s.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(new L().fromArray(s))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}};function zf(n,t,e,i,s){let r=(i-t)*.5,a=(s-e)*.5,o=n*n,c=n*o;return(2*e-2*i+r+a)*c+(-3*e+3*i-2*r-a)*o+r*n+e}function A_(n,t){let e=1-n;return e*e*t}function R_(n,t){return 2*(1-n)*n*t}function C_(n,t){return n*n*t}function Zr(n,t,e,i){return A_(n,t)+R_(n,e)+C_(n,i)}function P_(n,t){let e=1-n;return e*e*e*t}function L_(n,t){let e=1-n;return 3*e*e*n*t}function I_(n,t){return 3*(1-n)*n*n*t}function D_(n,t){return n*n*n*t}function Jr(n,t,e,i,s){return P_(n,t)+L_(n,e)+I_(n,i)+D_(n,s)}var Oo=class extends Gn{constructor(t=new ht,e=new ht,i=new ht,s=new ht){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=i,this.v3=s}getPoint(t,e=new ht){let i=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(Jr(t,s.x,r.x,a.x,o.x),Jr(t,s.y,r.y,a.y,o.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},Ol=class extends Gn{constructor(t=new L,e=new L,i=new L,s=new L){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=i,this.v3=s}getPoint(t,e=new L){let i=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(Jr(t,s.x,r.x,a.x,o.x),Jr(t,s.y,r.y,a.y,o.y),Jr(t,s.z,r.z,a.z,o.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},Fo=class extends Gn{constructor(t=new ht,e=new ht){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new ht){let i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new ht){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Fl=class extends Gn{constructor(t=new L,e=new L){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new L){let i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new L){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},zo=class extends Gn{constructor(t=new ht,e=new ht,i=new ht){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new ht){let i=e,s=this.v0,r=this.v1,a=this.v2;return i.set(Zr(t,s.x,r.x,a.x),Zr(t,s.y,r.y,a.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},zl=class extends Gn{constructor(t=new L,e=new L,i=new L){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new L){let i=e,s=this.v0,r=this.v1,a=this.v2;return i.set(Zr(t,s.x,r.x,a.x),Zr(t,s.y,r.y,a.y),Zr(t,s.z,r.z,a.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Bo=class extends Gn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new ht){let i=e,s=this.points,r=(s.length-1)*t,a=Math.floor(r),o=r-a,c=s[a===0?a:a-1],l=s[a],h=s[a>s.length-2?s.length-1:a+1],u=s[a>s.length-3?s.length-1:a+2];return i.set(zf(o,c.x,l.x,h.x,u.x),zf(o,c.y,l.y,h.y,u.y)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){let s=this.points[e];t.points.push(s.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(new ht().fromArray(s))}return this}},Bl=Object.freeze({__proto__:null,ArcCurve:Nl,CatmullRomCurve3:ca,CubicBezierCurve:Oo,CubicBezierCurve3:Ol,EllipseCurve:oa,LineCurve:Fo,LineCurve3:Fl,QuadraticBezierCurve:zo,QuadraticBezierCurve3:zl,SplineCurve:Bo}),Hl=class extends Gn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){let i=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Bl[i](e,t))}return this}getPoint(t,e){let i=t*this.getLength(),s=this.getCurveLengths(),r=0;for(;r<s.length;){if(s[r]>=i){let a=s[r]-i,o=this.curves[r],c=o.getLength(),l=c===0?0:1-a/c;return o.getPointAt(l,e)}r++}return null}getLength(){let t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let t=[],e=0;for(let i=0,s=this.curves.length;i<s;i++)e+=this.curves[i].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){let e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){let e=[],i;for(let s=0,r=this.curves;s<r.length;s++){let a=r[s],o=a.isEllipseCurve?t*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?t*a.points.length:t,c=a.getPoints(o);for(let l=0;l<c.length;l++){let h=c[l];i&&i.equals(h)||(e.push(h),i=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){let s=t.curves[e];this.curves.push(s.clone())}return this.autoClose=t.autoClose,this}toJSON(){let t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,i=this.curves.length;e<i;e++){let s=this.curves[e];t.curves.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){let s=t.curves[e];this.curves.push(new Bl[s.type]().fromJSON(s))}return this}},Ho=class extends Hl{constructor(t){super(),this.type="Path",this.currentPoint=new ht,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,i=t.length;e<i;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){let i=new Fo(this.currentPoint.clone(),new ht(t,e));return this.curves.push(i),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,i,s){let r=new zo(this.currentPoint.clone(),new ht(t,e),new ht(i,s));return this.curves.push(r),this.currentPoint.set(i,s),this}bezierCurveTo(t,e,i,s,r,a){let o=new Oo(this.currentPoint.clone(),new ht(t,e),new ht(i,s),new ht(r,a));return this.curves.push(o),this.currentPoint.set(r,a),this}splineThru(t){let e=[this.currentPoint.clone()].concat(t),i=new Bo(e);return this.curves.push(i),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,i,s,r,a){let o=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(t+o,e+c,i,s,r,a),this}absarc(t,e,i,s,r,a){return this.absellipse(t,e,i,i,s,r,a),this}ellipse(t,e,i,s,r,a,o,c){let l=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+l,e+h,i,s,r,a,o,c),this}absellipse(t,e,i,s,r,a,o,c){let l=new oa(t,e,i,s,r,a,o,c);if(this.curves.length>0){let u=l.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(l);let h=l.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){let t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}};var xs=class n extends Pe{constructor(t=1,e=32,i=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:i,thetaLength:s},e=Math.max(3,e);let r=[],a=[],o=[],c=[],l=new L,h=new ht;a.push(0,0,0),o.push(0,0,1),c.push(.5,.5);for(let u=0,f=3;u<=e;u++,f+=3){let d=i+u/e*s;l.x=t*Math.cos(d),l.y=t*Math.sin(d),a.push(l.x,l.y,l.z),o.push(0,0,1),h.x=(a[f]/t+1)/2,h.y=(a[f+1]/t+1)/2,c.push(h.x,h.y)}for(let u=1;u<=e;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new he(a,3)),this.setAttribute("normal",new he(o,3)),this.setAttribute("uv",new he(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.segments,t.thetaStart,t.thetaLength)}},Vt=class n extends Pe{constructor(t=1,e=1,i=1,s=32,r=1,a=!1,o=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:i,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:c};let l=this;s=Math.floor(s),r=Math.floor(r);let h=[],u=[],f=[],d=[],p=0,x=[],g=i/2,m=0;S(),a===!1&&(t>0&&y(!0),e>0&&y(!1)),this.setIndex(h),this.setAttribute("position",new he(u,3)),this.setAttribute("normal",new he(f,3)),this.setAttribute("uv",new he(d,2));function S(){let b=new L,C=new L,A=0,w=(e-t)/i;for(let F=0;F<=r;F++){let E=[],M=F/r,I=M*(e-t)+t;for(let N=0;N<=s;N++){let J=N/s,P=J*c+o,O=Math.sin(P),z=Math.cos(P);C.x=I*O,C.y=-M*i+g,C.z=I*z,u.push(C.x,C.y,C.z),b.set(O,w,z).normalize(),f.push(b.x,b.y,b.z),d.push(J,1-M),E.push(p++)}x.push(E)}for(let F=0;F<s;F++)for(let E=0;E<r;E++){let M=x[E][F],I=x[E+1][F],N=x[E+1][F+1],J=x[E][F+1];h.push(M,I,J),h.push(I,N,J),A+=6}l.addGroup(m,A,0),m+=A}function y(b){let C=p,A=new ht,w=new L,F=0,E=b===!0?t:e,M=b===!0?1:-1;for(let N=1;N<=s;N++)u.push(0,g*M,0),f.push(0,M,0),d.push(.5,.5),p++;let I=p;for(let N=0;N<=s;N++){let P=N/s*c+o,O=Math.cos(P),z=Math.sin(P);w.x=E*z,w.y=g*M,w.z=E*O,u.push(w.x,w.y,w.z),f.push(0,M,0),A.x=O*.5+.5,A.y=z*.5*M+.5,d.push(A.x,A.y),p++}for(let N=0;N<s;N++){let J=C+N,P=I+N;b===!0?h.push(P,P+1,J):h.push(P+1,P,J),F+=3}l.addGroup(m,F,b===!0?1:2),m+=F}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Ke=class n extends Vt{constructor(t=1,e=1,i=32,s=1,r=!1,a=0,o=Math.PI*2){super(0,t,e,i,s,r,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:i,heightSegments:s,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(t){return new n(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},ko=class n extends Pe{constructor(t=[],e=[],i=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:i,detail:s};let r=[],a=[];o(s),l(i),h(),this.setAttribute("position",new he(r,3)),this.setAttribute("normal",new he(r.slice(),3)),this.setAttribute("uv",new he(a,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(S){let y=new L,b=new L,C=new L;for(let A=0;A<e.length;A+=3)d(e[A+0],y),d(e[A+1],b),d(e[A+2],C),c(y,b,C,S)}function c(S,y,b,C){let A=C+1,w=[];for(let F=0;F<=A;F++){w[F]=[];let E=S.clone().lerp(b,F/A),M=y.clone().lerp(b,F/A),I=A-F;for(let N=0;N<=I;N++)N===0&&F===A?w[F][N]=E:w[F][N]=E.clone().lerp(M,N/I)}for(let F=0;F<A;F++)for(let E=0;E<2*(A-F)-1;E++){let M=Math.floor(E/2);E%2===0?(f(w[F][M+1]),f(w[F+1][M]),f(w[F][M])):(f(w[F][M+1]),f(w[F+1][M+1]),f(w[F+1][M]))}}function l(S){let y=new L;for(let b=0;b<r.length;b+=3)y.x=r[b+0],y.y=r[b+1],y.z=r[b+2],y.normalize().multiplyScalar(S),r[b+0]=y.x,r[b+1]=y.y,r[b+2]=y.z}function h(){let S=new L;for(let y=0;y<r.length;y+=3){S.x=r[y+0],S.y=r[y+1],S.z=r[y+2];let b=g(S)/2/Math.PI+.5,C=m(S)/Math.PI+.5;a.push(b,1-C)}p(),u()}function u(){for(let S=0;S<a.length;S+=6){let y=a[S+0],b=a[S+2],C=a[S+4],A=Math.max(y,b,C),w=Math.min(y,b,C);A>.9&&w<.1&&(y<.2&&(a[S+0]+=1),b<.2&&(a[S+2]+=1),C<.2&&(a[S+4]+=1))}}function f(S){r.push(S.x,S.y,S.z)}function d(S,y){let b=S*3;y.x=t[b+0],y.y=t[b+1],y.z=t[b+2]}function p(){let S=new L,y=new L,b=new L,C=new L,A=new ht,w=new ht,F=new ht;for(let E=0,M=0;E<r.length;E+=9,M+=6){S.set(r[E+0],r[E+1],r[E+2]),y.set(r[E+3],r[E+4],r[E+5]),b.set(r[E+6],r[E+7],r[E+8]),A.set(a[M+0],a[M+1]),w.set(a[M+2],a[M+3]),F.set(a[M+4],a[M+5]),C.copy(S).add(y).add(b).divideScalar(3);let I=g(C);x(A,M+0,S,I),x(w,M+2,y,I),x(F,M+4,b,I)}}function x(S,y,b,C){C<0&&S.x===1&&(a[y]=S.x-1),b.x===0&&b.z===0&&(a[y]=C/2/Math.PI+.5)}function g(S){return Math.atan2(S.z,-S.x)}function m(S){return Math.atan2(-S.y,Math.sqrt(S.x*S.x+S.z*S.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.vertices,t.indices,t.radius,t.details)}};var ji=class extends Ho{constructor(t){super(t),this.uuid=ci(),this.type="Shape",this.holes=[]}getPointsHoles(t){let e=[];for(let i=0,s=this.holes.length;i<s;i++)e[i]=this.holes[i].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){let s=t.holes[e];this.holes.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,i=this.holes.length;e<i;e++){let s=this.holes[e];t.holes.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){let s=t.holes[e];this.holes.push(new Ho().fromJSON(s))}return this}},U_={triangulate:function(n,t,e=2){let i=t&&t.length,s=i?t[0]*e:n.length,r=gd(n,0,s,e,!0),a=[];if(!r||r.next===r.prev)return a;let o,c,l,h,u,f,d;if(i&&(r=B_(n,t,r,e)),n.length>80*e){o=l=n[0],c=h=n[1];for(let p=e;p<s;p+=e)u=n[p],f=n[p+1],u<o&&(o=u),f<c&&(c=f),u>l&&(l=u),f>h&&(h=f);d=Math.max(l-o,h-c),d=d!==0?32767/d:0}return la(r,a,e,o,c,d,0),a}};function gd(n,t,e,i,s){let r,a;if(s===J_(n,t,e,i)>0)for(r=t;r<e;r+=i)a=Bf(r,n[r],n[r+1],a);else for(r=e-i;r>=t;r-=i)a=Bf(r,n[r],n[r+1],a);return a&&Zo(a,a.next)&&(ua(a),a=a.next),a}function ys(n,t){if(!n)return n;t||(t=n);let e=n,i;do if(i=!1,!e.steiner&&(Zo(e,e.next)||Ue(e.prev,e,e.next)===0)){if(ua(e),e=t=e.prev,e===e.next)break;i=!0}else e=e.next;while(i||e!==t);return t}function la(n,t,e,i,s,r,a){if(!n)return;!a&&r&&W_(n,i,s,r);let o=n,c,l;for(;n.prev!==n.next;){if(c=n.prev,l=n.next,r?O_(n,i,s,r):N_(n)){t.push(c.i/e|0),t.push(n.i/e|0),t.push(l.i/e|0),ua(n),n=l.next,o=l.next;continue}if(n=l,n===o){a?a===1?(n=F_(ys(n),t,e),la(n,t,e,i,s,r,2)):a===2&&z_(n,t,e,i,s,r):la(ys(n),t,e,i,s,r,1);break}}}function N_(n){let t=n.prev,e=n,i=n.next;if(Ue(t,e,i)>=0)return!1;let s=t.x,r=e.x,a=i.x,o=t.y,c=e.y,l=i.y,h=s<r?s<a?s:a:r<a?r:a,u=o<c?o<l?o:l:c<l?c:l,f=s>r?s>a?s:a:r>a?r:a,d=o>c?o>l?o:l:c>l?c:l,p=i.next;for(;p!==t;){if(p.x>=h&&p.x<=f&&p.y>=u&&p.y<=d&&sr(s,o,r,c,a,l,p.x,p.y)&&Ue(p.prev,p,p.next)>=0)return!1;p=p.next}return!0}function O_(n,t,e,i){let s=n.prev,r=n,a=n.next;if(Ue(s,r,a)>=0)return!1;let o=s.x,c=r.x,l=a.x,h=s.y,u=r.y,f=a.y,d=o<c?o<l?o:l:c<l?c:l,p=h<u?h<f?h:f:u<f?u:f,x=o>c?o>l?o:l:c>l?c:l,g=h>u?h>f?h:f:u>f?u:f,m=kl(d,p,t,e,i),S=kl(x,g,t,e,i),y=n.prevZ,b=n.nextZ;for(;y&&y.z>=m&&b&&b.z<=S;){if(y.x>=d&&y.x<=x&&y.y>=p&&y.y<=g&&y!==s&&y!==a&&sr(o,h,c,u,l,f,y.x,y.y)&&Ue(y.prev,y,y.next)>=0||(y=y.prevZ,b.x>=d&&b.x<=x&&b.y>=p&&b.y<=g&&b!==s&&b!==a&&sr(o,h,c,u,l,f,b.x,b.y)&&Ue(b.prev,b,b.next)>=0))return!1;b=b.nextZ}for(;y&&y.z>=m;){if(y.x>=d&&y.x<=x&&y.y>=p&&y.y<=g&&y!==s&&y!==a&&sr(o,h,c,u,l,f,y.x,y.y)&&Ue(y.prev,y,y.next)>=0)return!1;y=y.prevZ}for(;b&&b.z<=S;){if(b.x>=d&&b.x<=x&&b.y>=p&&b.y<=g&&b!==s&&b!==a&&sr(o,h,c,u,l,f,b.x,b.y)&&Ue(b.prev,b,b.next)>=0)return!1;b=b.nextZ}return!0}function F_(n,t,e){let i=n;do{let s=i.prev,r=i.next.next;!Zo(s,r)&&xd(s,i,i.next,r)&&ha(s,r)&&ha(r,s)&&(t.push(s.i/e|0),t.push(i.i/e|0),t.push(r.i/e|0),ua(i),ua(i.next),i=n=r),i=i.next}while(i!==n);return ys(i)}function z_(n,t,e,i,s,r){let a=n;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&$_(a,o)){let c=yd(a,o);a=ys(a,a.next),c=ys(c,c.next),la(a,t,e,i,s,r,0),la(c,t,e,i,s,r,0);return}o=o.next}a=a.next}while(a!==n)}function B_(n,t,e,i){let s=[],r,a,o,c,l;for(r=0,a=t.length;r<a;r++)o=t[r]*i,c=r<a-1?t[r+1]*i:n.length,l=gd(n,o,c,i,!1),l===l.next&&(l.steiner=!0),s.push(Y_(l));for(s.sort(H_),r=0;r<s.length;r++)e=k_(s[r],e);return e}function H_(n,t){return n.x-t.x}function k_(n,t){let e=G_(n,t);if(!e)return t;let i=yd(e,n);return ys(i,i.next),ys(e,e.next)}function G_(n,t){let e=t,i=-1/0,s,r=n.x,a=n.y;do{if(a<=e.y&&a>=e.next.y&&e.next.y!==e.y){let f=e.x+(a-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(f<=r&&f>i&&(i=f,s=e.x<e.next.x?e:e.next,f===r))return s}e=e.next}while(e!==t);if(!s)return null;let o=s,c=s.x,l=s.y,h=1/0,u;e=s;do r>=e.x&&e.x>=c&&r!==e.x&&sr(a<l?r:i,a,c,l,a<l?i:r,a,e.x,e.y)&&(u=Math.abs(a-e.y)/(r-e.x),ha(e,n)&&(u<h||u===h&&(e.x>s.x||e.x===s.x&&V_(s,e)))&&(s=e,h=u)),e=e.next;while(e!==o);return s}function V_(n,t){return Ue(n.prev,n,t.prev)<0&&Ue(t.next,n,n.next)<0}function W_(n,t,e,i){let s=n;do s.z===0&&(s.z=kl(s.x,s.y,t,e,i)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==n);s.prevZ.nextZ=null,s.prevZ=null,X_(s)}function X_(n){let t,e,i,s,r,a,o,c,l=1;do{for(e=n,n=null,r=null,a=0;e;){for(a++,i=e,o=0,t=0;t<l&&(o++,i=i.nextZ,!!i);t++);for(c=l;o>0||c>0&&i;)o!==0&&(c===0||!i||e.z<=i.z)?(s=e,e=e.nextZ,o--):(s=i,i=i.nextZ,c--),r?r.nextZ=s:n=s,s.prevZ=r,r=s;e=i}r.nextZ=null,l*=2}while(a>1);return n}function kl(n,t,e,i,s){return n=(n-e)*s|0,t=(t-i)*s|0,n=(n|n<<8)&16711935,n=(n|n<<4)&252645135,n=(n|n<<2)&858993459,n=(n|n<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,n|t<<1}function Y_(n){let t=n,e=n;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==n);return e}function sr(n,t,e,i,s,r,a,o){return(s-a)*(t-o)>=(n-a)*(r-o)&&(n-a)*(i-o)>=(e-a)*(t-o)&&(e-a)*(r-o)>=(s-a)*(i-o)}function $_(n,t){return n.next.i!==t.i&&n.prev.i!==t.i&&!q_(n,t)&&(ha(n,t)&&ha(t,n)&&Z_(n,t)&&(Ue(n.prev,n,t.prev)||Ue(n,t.prev,t))||Zo(n,t)&&Ue(n.prev,n,n.next)>0&&Ue(t.prev,t,t.next)>0)}function Ue(n,t,e){return(t.y-n.y)*(e.x-t.x)-(t.x-n.x)*(e.y-t.y)}function Zo(n,t){return n.x===t.x&&n.y===t.y}function xd(n,t,e,i){let s=lo(Ue(n,t,e)),r=lo(Ue(n,t,i)),a=lo(Ue(e,i,n)),o=lo(Ue(e,i,t));return!!(s!==r&&a!==o||s===0&&co(n,e,t)||r===0&&co(n,i,t)||a===0&&co(e,n,i)||o===0&&co(e,t,i))}function co(n,t,e){return t.x<=Math.max(n.x,e.x)&&t.x>=Math.min(n.x,e.x)&&t.y<=Math.max(n.y,e.y)&&t.y>=Math.min(n.y,e.y)}function lo(n){return n>0?1:n<0?-1:0}function q_(n,t){let e=n;do{if(e.i!==n.i&&e.next.i!==n.i&&e.i!==t.i&&e.next.i!==t.i&&xd(e,e.next,n,t))return!0;e=e.next}while(e!==n);return!1}function ha(n,t){return Ue(n.prev,n,n.next)<0?Ue(n,t,n.next)>=0&&Ue(n,n.prev,t)>=0:Ue(n,t,n.prev)<0||Ue(n,n.next,t)<0}function Z_(n,t){let e=n,i=!1,s=(n.x+t.x)/2,r=(n.y+t.y)/2;do e.y>r!=e.next.y>r&&e.next.y!==e.y&&s<(e.next.x-e.x)*(r-e.y)/(e.next.y-e.y)+e.x&&(i=!i),e=e.next;while(e!==n);return i}function yd(n,t){let e=new Gl(n.i,n.x,n.y),i=new Gl(t.i,t.x,t.y),s=n.next,r=t.prev;return n.next=t,t.prev=n,e.next=s,s.prev=e,i.next=e,e.prev=i,r.next=i,i.prev=r,i}function Bf(n,t,e,i){let s=new Gl(n,t,e);return i?(s.next=i.next,s.prev=i,i.next.prev=s,i.next=s):(s.prev=s,s.next=s),s}function ua(n){n.next.prev=n.prev,n.prev.next=n.next,n.prevZ&&(n.prevZ.nextZ=n.nextZ),n.nextZ&&(n.nextZ.prevZ=n.prevZ)}function Gl(n,t,e){this.i=n,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function J_(n,t,e,i){let s=0;for(let r=t,a=e-i;r<e;r+=i)s+=(n[a]-n[r])*(n[r+1]+n[a+1]),a=r;return s}var Kr=class n{static area(t){let e=t.length,i=0;for(let s=e-1,r=0;r<e;s=r++)i+=t[s].x*t[r].y-t[r].x*t[s].y;return i*.5}static isClockWise(t){return n.area(t)<0}static triangulateShape(t,e){let i=[],s=[],r=[];Hf(t),kf(i,t);let a=t.length;e.forEach(Hf);for(let c=0;c<e.length;c++)s.push(a),a+=e[c].length,kf(i,e[c]);let o=U_.triangulate(i,s);for(let c=0;c<o.length;c+=3)r.push(o.slice(c,c+3));return r}};function Hf(n){let t=n.length;t>2&&n[t-1].equals(n[0])&&n.pop()}function kf(n,t){for(let e=0;e<t.length;e++)n.push(t[e].x),n.push(t[e].y)}var _s=class n extends Pe{constructor(t=new ji([new ht(.5,.5),new ht(-.5,.5),new ht(-.5,-.5),new ht(.5,-.5)]),e={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];let i=this,s=[],r=[];for(let o=0,c=t.length;o<c;o++){let l=t[o];a(l)}this.setAttribute("position",new he(s,3)),this.setAttribute("uv",new he(r,2)),this.computeVertexNormals();function a(o){let c=[],l=e.curveSegments!==void 0?e.curveSegments:12,h=e.steps!==void 0?e.steps:1,u=e.depth!==void 0?e.depth:1,f=e.bevelEnabled!==void 0?e.bevelEnabled:!0,d=e.bevelThickness!==void 0?e.bevelThickness:.2,p=e.bevelSize!==void 0?e.bevelSize:d-.1,x=e.bevelOffset!==void 0?e.bevelOffset:0,g=e.bevelSegments!==void 0?e.bevelSegments:3,m=e.extrudePath,S=e.UVGenerator!==void 0?e.UVGenerator:K_,y,b=!1,C,A,w,F;m&&(y=m.getSpacedPoints(h),b=!0,f=!1,C=m.computeFrenetFrames(h,!1),A=new L,w=new L,F=new L),f||(g=0,d=0,p=0,x=0);let E=o.extractPoints(l),M=E.shape,I=E.holes;if(!Kr.isClockWise(M)){M=M.reverse();for(let R=0,rt=I.length;R<rt;R++){let Y=I[R];Kr.isClockWise(Y)&&(I[R]=Y.reverse())}}let J=Kr.triangulateShape(M,I),P=M;for(let R=0,rt=I.length;R<rt;R++){let Y=I[R];M=M.concat(Y)}function O(R,rt,Y){return rt||console.error("THREE.ExtrudeGeometry: vec does not exist"),R.clone().addScaledVector(rt,Y)}let z=M.length,Q=J.length;function j(R,rt,Y){let tt,q,Ct,yt=R.x-rt.x,v=R.y-rt.y,_=Y.x-R.x,D=Y.y-R.y,k=yt*yt+v*v,W=yt*D-v*_;if(Math.abs(W)>Number.EPSILON){let Z=Math.sqrt(k),bt=Math.sqrt(_*_+D*D),lt=rt.x-v/Z,wt=rt.y+yt/Z,zt=Y.x-D/bt,qt=Y.y+_/bt,at=((zt-lt)*D-(qt-wt)*_)/(yt*D-v*_);tt=lt+yt*at-R.x,q=wt+v*at-R.y;let de=tt*tt+q*q;if(de<=2)return new ht(tt,q);Ct=Math.sqrt(de/2)}else{let Z=!1;yt>Number.EPSILON?_>Number.EPSILON&&(Z=!0):yt<-Number.EPSILON?_<-Number.EPSILON&&(Z=!0):Math.sign(v)===Math.sign(D)&&(Z=!0),Z?(tt=-v,q=yt,Ct=Math.sqrt(k)):(tt=yt,q=v,Ct=Math.sqrt(k/2))}return new ht(tt/Ct,q/Ct)}let K=[];for(let R=0,rt=P.length,Y=rt-1,tt=R+1;R<rt;R++,Y++,tt++)Y===rt&&(Y=0),tt===rt&&(tt=0),K[R]=j(P[R],P[Y],P[tt]);let st=[],it,xt=K.concat();for(let R=0,rt=I.length;R<rt;R++){let Y=I[R];it=[];for(let tt=0,q=Y.length,Ct=q-1,yt=tt+1;tt<q;tt++,Ct++,yt++)Ct===q&&(Ct=0),yt===q&&(yt=0),it[tt]=j(Y[tt],Y[Ct],Y[yt]);st.push(it),xt=xt.concat(it)}for(let R=0;R<g;R++){let rt=R/g,Y=d*Math.cos(rt*Math.PI/2),tt=p*Math.sin(rt*Math.PI/2)+x;for(let q=0,Ct=P.length;q<Ct;q++){let yt=O(P[q],K[q],tt);St(yt.x,yt.y,-Y)}for(let q=0,Ct=I.length;q<Ct;q++){let yt=I[q];it=st[q];for(let v=0,_=yt.length;v<_;v++){let D=O(yt[v],it[v],tt);St(D.x,D.y,-Y)}}}let $=p+x;for(let R=0;R<z;R++){let rt=f?O(M[R],xt[R],$):M[R];b?(w.copy(C.normals[0]).multiplyScalar(rt.x),A.copy(C.binormals[0]).multiplyScalar(rt.y),F.copy(y[0]).add(w).add(A),St(F.x,F.y,F.z)):St(rt.x,rt.y,0)}for(let R=1;R<=h;R++)for(let rt=0;rt<z;rt++){let Y=f?O(M[rt],xt[rt],$):M[rt];b?(w.copy(C.normals[R]).multiplyScalar(Y.x),A.copy(C.binormals[R]).multiplyScalar(Y.y),F.copy(y[R]).add(w).add(A),St(F.x,F.y,F.z)):St(Y.x,Y.y,u/h*R)}for(let R=g-1;R>=0;R--){let rt=R/g,Y=d*Math.cos(rt*Math.PI/2),tt=p*Math.sin(rt*Math.PI/2)+x;for(let q=0,Ct=P.length;q<Ct;q++){let yt=O(P[q],K[q],tt);St(yt.x,yt.y,u+Y)}for(let q=0,Ct=I.length;q<Ct;q++){let yt=I[q];it=st[q];for(let v=0,_=yt.length;v<_;v++){let D=O(yt[v],it[v],tt);b?St(D.x,D.y+y[h-1].y,y[h-1].x+Y):St(D.x,D.y,u+Y)}}}et(),ut();function et(){let R=s.length/3;if(f){let rt=0,Y=z*rt;for(let tt=0;tt<Q;tt++){let q=J[tt];Bt(q[2]+Y,q[1]+Y,q[0]+Y)}rt=h+g*2,Y=z*rt;for(let tt=0;tt<Q;tt++){let q=J[tt];Bt(q[0]+Y,q[1]+Y,q[2]+Y)}}else{for(let rt=0;rt<Q;rt++){let Y=J[rt];Bt(Y[2],Y[1],Y[0])}for(let rt=0;rt<Q;rt++){let Y=J[rt];Bt(Y[0]+z*h,Y[1]+z*h,Y[2]+z*h)}}i.addGroup(R,s.length/3-R,0)}function ut(){let R=s.length/3,rt=0;Lt(P,rt),rt+=P.length;for(let Y=0,tt=I.length;Y<tt;Y++){let q=I[Y];Lt(q,rt),rt+=q.length}i.addGroup(R,s.length/3-R,1)}function Lt(R,rt){let Y=R.length;for(;--Y>=0;){let tt=Y,q=Y-1;q<0&&(q=R.length-1);for(let Ct=0,yt=h+g*2;Ct<yt;Ct++){let v=z*Ct,_=z*(Ct+1),D=rt+tt+v,k=rt+q+v,W=rt+q+_,Z=rt+tt+_;nt(D,k,W,Z)}}}function St(R,rt,Y){c.push(R),c.push(rt),c.push(Y)}function Bt(R,rt,Y){ct(R),ct(rt),ct(Y);let tt=s.length/3,q=S.generateTopUV(i,s,tt-3,tt-2,tt-1);gt(q[0]),gt(q[1]),gt(q[2])}function nt(R,rt,Y,tt){ct(R),ct(rt),ct(tt),ct(rt),ct(Y),ct(tt);let q=s.length/3,Ct=S.generateSideWallUV(i,s,q-6,q-3,q-2,q-1);gt(Ct[0]),gt(Ct[1]),gt(Ct[3]),gt(Ct[1]),gt(Ct[2]),gt(Ct[3])}function ct(R){s.push(c[R*3+0]),s.push(c[R*3+1]),s.push(c[R*3+2])}function gt(R){r.push(R.x),r.push(R.y)}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes,i=this.parameters.options;return j_(e,i,t)}static fromJSON(t,e){let i=[];for(let r=0,a=t.shapes.length;r<a;r++){let o=e[t.shapes[r]];i.push(o)}let s=t.options.extrudePath;return s!==void 0&&(t.options.extrudePath=new Bl[s.type]().fromJSON(s)),new n(i,t.options)}},K_={generateTopUV:function(n,t,e,i,s){let r=t[e*3],a=t[e*3+1],o=t[i*3],c=t[i*3+1],l=t[s*3],h=t[s*3+1];return[new ht(r,a),new ht(o,c),new ht(l,h)]},generateSideWallUV:function(n,t,e,i,s,r){let a=t[e*3],o=t[e*3+1],c=t[e*3+2],l=t[i*3],h=t[i*3+1],u=t[i*3+2],f=t[s*3],d=t[s*3+1],p=t[s*3+2],x=t[r*3],g=t[r*3+1],m=t[r*3+2];return Math.abs(o-h)<Math.abs(a-l)?[new ht(a,1-c),new ht(l,1-u),new ht(f,1-p),new ht(x,1-m)]:[new ht(o,1-c),new ht(h,1-u),new ht(d,1-p),new ht(g,1-m)]}};function j_(n,t,e){if(e.shapes=[],Array.isArray(n))for(let i=0,s=n.length;i<s;i++){let r=n[i];e.shapes.push(r.uuid)}else e.shapes.push(n.uuid);return e.options=Object.assign({},t),t.extrudePath!==void 0&&(e.options.extrudePath=t.extrudePath.toJSON()),e}var dr=class n extends ko{constructor(t=1,e=0){let i=(1+Math.sqrt(5))/2,s=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new n(t.radius,t.detail)}},pr=class n extends ko{constructor(t=1,e=0){let i=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(i,s,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new n(t.radius,t.detail)}},fa=class n extends Pe{constructor(t=.5,e=1,i=32,s=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:i,phiSegments:s,thetaStart:r,thetaLength:a},i=Math.max(3,i),s=Math.max(1,s);let o=[],c=[],l=[],h=[],u=t,f=(e-t)/s,d=new L,p=new ht;for(let x=0;x<=s;x++){for(let g=0;g<=i;g++){let m=r+g/i*a;d.x=u*Math.cos(m),d.y=u*Math.sin(m),c.push(d.x,d.y,d.z),l.push(0,0,1),p.x=(d.x/e+1)/2,p.y=(d.y/e+1)/2,h.push(p.x,p.y)}u+=f}for(let x=0;x<s;x++){let g=x*(i+1);for(let m=0;m<i;m++){let S=m+g,y=S,b=S+i+1,C=S+i+2,A=S+1;o.push(y,b,A),o.push(b,C,A)}}this.setIndex(o),this.setAttribute("position",new he(c,3)),this.setAttribute("normal",new he(l,3)),this.setAttribute("uv",new he(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}};var ue=class n extends Pe{constructor(t=1,e=32,i=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:i,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),i=Math.max(2,Math.floor(i));let c=Math.min(a+o,Math.PI),l=0,h=[],u=new L,f=new L,d=[],p=[],x=[],g=[];for(let m=0;m<=i;m++){let S=[],y=m/i,b=0;m===0&&a===0?b=.5/e:m===i&&c===Math.PI&&(b=-.5/e);for(let C=0;C<=e;C++){let A=C/e;u.x=-t*Math.cos(s+A*r)*Math.sin(a+y*o),u.y=t*Math.cos(a+y*o),u.z=t*Math.sin(s+A*r)*Math.sin(a+y*o),p.push(u.x,u.y,u.z),f.copy(u).normalize(),x.push(f.x,f.y,f.z),g.push(A+b,1-y),S.push(l++)}h.push(S)}for(let m=0;m<i;m++)for(let S=0;S<e;S++){let y=h[m][S+1],b=h[m][S],C=h[m+1][S],A=h[m+1][S+1];(m!==0||a>0)&&d.push(y,b,A),(m!==i-1||c<Math.PI)&&d.push(b,C,A)}this.setIndex(d),this.setAttribute("position",new he(p,3)),this.setAttribute("normal",new he(x,3)),this.setAttribute("uv",new he(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var mr=class n extends Pe{constructor(t=1,e=.4,i=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:i,tubularSegments:s,arc:r},i=Math.floor(i),s=Math.floor(s);let a=[],o=[],c=[],l=[],h=new L,u=new L,f=new L;for(let d=0;d<=i;d++)for(let p=0;p<=s;p++){let x=p/s*r,g=d/i*Math.PI*2;u.x=(t+e*Math.cos(g))*Math.cos(x),u.y=(t+e*Math.cos(g))*Math.sin(x),u.z=e*Math.sin(g),o.push(u.x,u.y,u.z),h.x=t*Math.cos(x),h.y=t*Math.sin(x),f.subVectors(u,h).normalize(),c.push(f.x,f.y,f.z),l.push(p/s),l.push(d/i)}for(let d=1;d<=i;d++)for(let p=1;p<=s;p++){let x=(s+1)*d+p-1,g=(s+1)*(d-1)+p-1,m=(s+1)*(d-1)+p,S=(s+1)*d+p;a.push(x,g,S),a.push(g,m,S)}this.setIndex(a),this.setAttribute("position",new he(o,3)),this.setAttribute("normal",new he(c,3)),this.setAttribute("uv",new he(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}};var te=class extends wi{constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new Ft(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ft(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=nd,this.normalScale=new ht(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}};function ho(n,t,e){return!n||!e&&n.constructor===t?n:typeof t.BYTES_PER_ELEMENT=="number"?new t(n):Array.prototype.slice.call(n)}function Q_(n){return ArrayBuffer.isView(n)&&!(n instanceof DataView)}var gr=class{constructor(t,e,i,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(i),this.sampleValues=e,this.valueSize=i,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,i=this._cachedIndex,s=e[i],r=e[i-1];n:{t:{let a;e:{i:if(!(t<s)){for(let o=i+2;;){if(s===void 0){if(t<r)break i;return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)}if(i===o)break;if(r=s,s=e[++i],t<s)break t}a=e.length;break e}if(!(t>=r)){let o=e[1];t<o&&(i=2,r=o);for(let c=i-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===c)break;if(s=r,r=e[--i-1],t>=r)break t}a=i,i=0;break e}break n}for(;i<a;){let o=i+a>>>1;t<e[o]?a=o:i=o+1}if(s=e[i],r=e[i-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)}this._cachedIndex=i,this.intervalChanged_(i,r,s)}return this.interpolate_(i,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,i=this.sampleValues,s=this.valueSize,r=t*s;for(let a=0;a!==s;++a)e[a]=i[r+a];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},Vl=class extends gr{constructor(t,e,i,s){super(t,e,i,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Gu,endingEnd:Gu}}intervalChanged_(t,e,i){let s=this.parameterPositions,r=t-2,a=t+1,o=s[r],c=s[a];if(o===void 0)switch(this.getSettings_().endingStart){case Vu:r=t,o=2*e-i;break;case Wu:r=s.length-2,o=e+s[r]-s[r+1];break;default:r=t,o=i}if(c===void 0)switch(this.getSettings_().endingEnd){case Vu:a=t,c=2*i-e;break;case Wu:a=1,c=i+s[1]-s[0];break;default:a=t-1,c=e}let l=(i-e)*.5,h=this.valueSize;this._weightPrev=l/(e-o),this._weightNext=l/(c-i),this._offsetPrev=r*h,this._offsetNext=a*h}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=t*o,l=c-o,h=this._offsetPrev,u=this._offsetNext,f=this._weightPrev,d=this._weightNext,p=(i-e)/(s-e),x=p*p,g=x*p,m=-f*g+2*f*x-f*p,S=(1+f)*g+(-1.5-2*f)*x+(-.5+f)*p+1,y=(-1-d)*g+(1.5+d)*x+.5*p,b=d*g-d*x;for(let C=0;C!==o;++C)r[C]=m*a[h+C]+S*a[l+C]+y*a[c+C]+b*a[u+C];return r}},Wl=class extends gr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=t*o,l=c-o,h=(i-e)/(s-e),u=1-h;for(let f=0;f!==o;++f)r[f]=a[l+f]*u+a[c+f]*h;return r}},Xl=class extends gr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t){return this.copySampleValue_(t-1)}},ti=class{constructor(t,e,i,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=ho(e,this.TimeBufferType),this.values=ho(i,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,i;if(e.toJSON!==this.toJSON)i=e.toJSON(t);else{i={name:t.name,times:ho(t.times,Array),values:ho(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(i.interpolation=s)}return i.type=t.ValueTypeName,i}InterpolantFactoryMethodDiscrete(t){return new Xl(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new Wl(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new Vl(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case fo:e=this.InterpolantFactoryMethodDiscrete;break;case po:e=this.InterpolantFactoryMethodLinear;break;case Oc:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let i="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(i);return console.warn("THREE.KeyframeTrack:",i),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return fo;case this.InterpolantFactoryMethodLinear:return po;case this.InterpolantFactoryMethodSmooth:return Oc}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let i=0,s=e.length;i!==s;++i)e[i]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let i=0,s=e.length;i!==s;++i)e[i]*=t}return this}trim(t,e){let i=this.times,s=i.length,r=0,a=s-1;for(;r!==s&&i[r]<t;)++r;for(;a!==-1&&i[a]>e;)--a;if(++a,r!==0||a!==s){r>=a&&(a=Math.max(a,1),r=a-1);let o=this.getValueSize();this.times=i.slice(r,a),this.values=this.values.slice(r*o,a*o)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let i=this.times,s=this.values,r=i.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let a=null;for(let o=0;o!==r;o++){let c=i[o];if(typeof c=="number"&&isNaN(c)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,c),t=!1;break}if(a!==null&&a>c){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,c,a),t=!1;break}a=c}if(s!==void 0&&Q_(s))for(let o=0,c=s.length;o!==c;++o){let l=s[o];if(isNaN(l)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,l),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),i=this.getValueSize(),s=this.getInterpolation()===Oc,r=t.length-1,a=1;for(let o=1;o<r;++o){let c=!1,l=t[o],h=t[o+1];if(l!==h&&(o!==1||l!==t[0]))if(s)c=!0;else{let u=o*i,f=u-i,d=u+i;for(let p=0;p!==i;++p){let x=e[u+p];if(x!==e[f+p]||x!==e[d+p]){c=!0;break}}}if(c){if(o!==a){t[a]=t[o];let u=o*i,f=a*i;for(let d=0;d!==i;++d)e[f+d]=e[u+d]}++a}}if(r>0){t[a]=t[r];for(let o=r*i,c=a*i,l=0;l!==i;++l)e[c+l]=e[o+l];++a}return a!==t.length?(this.times=t.slice(0,a),this.values=e.slice(0,a*i)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),i=this.constructor,s=new i(this.name,t,e);return s.createInterpolant=this.createInterpolant,s}};ti.prototype.TimeBufferType=Float32Array;ti.prototype.ValueBufferType=Float32Array;ti.prototype.DefaultInterpolation=po;var vs=class extends ti{};vs.prototype.ValueTypeName="bool";vs.prototype.ValueBufferType=Array;vs.prototype.DefaultInterpolation=fo;vs.prototype.InterpolantFactoryMethodLinear=void 0;vs.prototype.InterpolantFactoryMethodSmooth=void 0;var Yl=class extends ti{};Yl.prototype.ValueTypeName="color";var $l=class extends ti{};$l.prototype.ValueTypeName="number";var ql=class extends gr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t,e,i,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=(i-e)/(s-e),l=t*o;for(let h=l+o;l!==h;l+=4)li.slerpFlat(r,0,a,l-o,a,l,c);return r}},da=class extends ti{InterpolantFactoryMethodLinear(t){return new ql(this.times,this.values,this.getValueSize(),t)}};da.prototype.ValueTypeName="quaternion";da.prototype.DefaultInterpolation=po;da.prototype.InterpolantFactoryMethodSmooth=void 0;var Ms=class extends ti{};Ms.prototype.ValueTypeName="string";Ms.prototype.ValueBufferType=Array;Ms.prototype.DefaultInterpolation=fo;Ms.prototype.InterpolantFactoryMethodLinear=void 0;Ms.prototype.InterpolantFactoryMethodSmooth=void 0;var Zl=class extends ti{};Zl.prototype.ValueTypeName="vector";var Jl=class{constructor(t,e,i){let s=this,r=!1,a=0,o=0,c,l=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=i,this.itemStart=function(h){o++,r===!1&&s.onStart!==void 0&&s.onStart(h,a,o),r=!0},this.itemEnd=function(h){a++,s.onProgress!==void 0&&s.onProgress(h,a,o),a===o&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return c?c(h):h},this.setURLModifier=function(h){return c=h,this},this.addHandler=function(h,u){return l.push(h,u),this},this.removeHandler=function(h){let u=l.indexOf(h);return u!==-1&&l.splice(u,2),this},this.getHandler=function(h){for(let u=0,f=l.length;u<f;u+=2){let d=l[u],p=l[u+1];if(d.global&&(d.lastIndex=0),d.test(h))return p}return null}}},tv=new Jl,Kl=class{constructor(t){this.manager=t!==void 0?t:tv,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let i=this;return new Promise(function(s,r){i.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};Kl.DEFAULT_MATERIAL_NAME="__DEFAULT";var Go=class extends qe{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Ft(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}},Vo=class extends Go{constructor(t,e,i){super(t,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(qe.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ft(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},ll=new Ae,Gf=new L,Vf=new L,jl=class{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new ht(512,512),this.map=null,this.mapPass=null,this.matrix=new Ae,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new na,this._frameExtents=new ht(1,1),this._viewportCount=1,this._viewports=[new Ge(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,i=this.matrix;Gf.setFromMatrixPosition(t.matrixWorld),e.position.copy(Gf),Vf.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Vf),e.updateMatrixWorld(),ll.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ll),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(ll)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var Ql=class extends jl{constructor(){super(new Po(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Wo=class extends Go{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(qe.DEFAULT_UP),this.updateMatrix(),this.target=new qe,this.shadow=new Ql}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var Xo=class{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=Wf(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let e=Wf();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}};function Wf(){return(typeof performance>"u"?Date:performance).now()}var lh="\\[\\]\\.:\\/",ev=new RegExp("["+lh+"]","g"),hh="[^"+lh+"]",nv="[^"+lh.replace("\\.","")+"]",iv=/((?:WC+[\/:])*)/.source.replace("WC",hh),sv=/(WCOD+)?/.source.replace("WCOD",nv),rv=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",hh),av=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",hh),ov=new RegExp("^"+iv+sv+rv+av+"$"),cv=["material","materials","bones","map"],th=class{constructor(t,e,i){let s=i||Ie.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let i=this._targetGroup.nCachedObjects_,s=this._bindings[i];s!==void 0&&s.getValue(t,e)}setValue(t,e){let i=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=i.length;s!==r;++s)i[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,i=t.length;e!==i;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,i=t.length;e!==i;++e)t[e].unbind()}},Ie=class n{constructor(t,e,i){this.path=e,this.parsedPath=i||n.parseTrackName(e),this.node=n.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,i){return t&&t.isAnimationObjectGroup?new n.Composite(t,e,i):new n(t,e,i)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(ev,"")}static parseTrackName(t){let e=ov.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let i={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=i.nodeName&&i.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=i.nodeName.substring(s+1);cv.indexOf(r)!==-1&&(i.nodeName=i.nodeName.substring(0,s),i.objectName=r)}if(i.propertyName===null||i.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return i}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let i=t.skeleton.getBoneByName(e);if(i!==void 0)return i}if(t.children){let i=function(r){for(let a=0;a<r.length;a++){let o=r[a];if(o.name===e||o.uuid===e)return o;let c=i(o.children);if(c)return c}return null},s=i(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)t[e++]=i[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,i=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=n.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(i){let l=e.objectIndex;switch(i){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===l){l=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[i]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[i]}if(l!==void 0){if(t[l]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[l]}}let a=t[s];if(a===void 0){let l=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+l+"."+s+" but it wasn't found.",t);return}let o=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}c=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=r}else a.fromArray!==void 0&&a.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(c=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=s;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Ie.Composite=th;Ie.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Ie.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Ie.prototype.GetterByBindingType=[Ie.prototype._getValue_direct,Ie.prototype._getValue_array,Ie.prototype._getValue_arrayElement,Ie.prototype._getValue_toArray];Ie.prototype.SetterByBindingTypeAndVersioning=[[Ie.prototype._setValue_direct,Ie.prototype._setValue_direct_setNeedsUpdate,Ie.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Ie.prototype._setValue_array,Ie.prototype._setValue_array_setNeedsUpdate,Ie.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Ie.prototype._setValue_arrayElement,Ie.prototype._setValue_arrayElement_setNeedsUpdate,Ie.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Ie.prototype._setValue_fromArray,Ie.prototype._setValue_fromArray_setNeedsUpdate,Ie.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var OM=new Float32Array(1);typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:eh}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=eh);var mt=n=>document.getElementById(n),le=(n,t,e)=>Math.max(t,Math.min(e,n)),Ve=(n,t,e)=>n+(t-n)*e,Nt=(n,t,e)=>{let i=le((e-n)/(t-n),0,1);return i*i*(3-2*i)},Ts=(n,t,e)=>Math.exp(-(((n-t)/e)**2)),ph=n=>(n%=Math.PI*2,n>Math.PI&&(n-=Math.PI*2),n<-Math.PI&&(n+=Math.PI*2),n),jo=1,Yt=()=>(jo=jo*16807%2147483647,(jo-1)/2147483646),Ut=(n,t)=>n+Yt()*(t-n);function vr(n,t,e){let i=Math.imul(n|0,374761393)^Math.imul(t|0,668265263)^Math.imul(e|0,1442695041);return i=Math.imul(i^i>>>13,1274126177),i^=i>>>16,(i>>>0)/4294967296}function Ni(n,t,e,i){let s=Math.floor(n),r=Math.floor(t),a=n-s,o=t-r,c=a*a*(3-2*a),l=o*o*(3-2*o),h=x=>e?(x%e+e)%e:x,u=vr(h(s),h(r),i),f=vr(h(s+1),h(r),i),d=vr(h(s),h(r+1),i),p=vr(h(s+1),h(r+1),i);return Ve(Ve(u,f,c),Ve(d,p,c),l)}function Li(n,t,e=4,i=0,s=0){let r=.5,a=1,o=0,c=0;for(let l=0;l<e;l++)o+=r*Ni(n*a,t*a,i?i*a:0,s+l*17),c+=r,r*=.5,a*=2;return o/c}var Ra="ontouchstart"in window||navigator.maxTouchPoints>0;Ra&&document.body.classList.add("touch");var Uh="corridaCaninaTurbo1",H={musicMode:0,vib:!0,voice:!0,mode:0,owned:[],looks:{},stats:{},ach:[],daily:null,trophies:{},coins:400,up:{},best:{},dog:0,track:0,diff:1,laps:3,qual:Ra?1:2,music:!0,cam:0,assist:!0};try{Object.assign(H,JSON.parse(localStorage.getItem(Uh)||"{}"))}catch{}H.music===!1&&H.musicMode===0&&!("musicMode"in JSON.parse((()=>{try{return localStorage.getItem(Uh)||"{}"}catch{return"{}"}})()))&&(H.musicMode=4);function je(){try{localStorage.setItem(Uh,JSON.stringify(H))}catch{}}var $n=new ia({canvas:mt("game"),antialias:!0,powerPreference:"high-performance"});$n.outputColorSpace=Ee;$n.toneMapping=ih;$n.shadowMap.enabled=!0;$n.shadowMap.type=nh;var hv=Math.min(8,$n.capabilities.getMaxAnisotropy()),sn=new sa,me=new _n(66,1,.2,2600),sc=new Vo(16777215,5596740,.4);sn.add(sc);var En=new Wo(16777215,3);En.castShadow=!0;Object.assign(En.shadow.camera,{left:-42,right:42,top:42,bottom:-42,near:1,far:340});En.shadow.bias=-4e-4;En.shadow.normalBias=.05;sn.add(En,En.target);var mh=new L(.4,.6,.3).normalize(),Ss={zen:{value:new Ft},hor:{value:new Ft},gnd:{value:new Ft},sunCol:{value:new Ft},sunDir:{value:new L},haze:{value:.5}},Pd=new kn({uniforms:Ss,side:fn,depthWrite:!1,fog:!1,vertexShader:"varying vec3 vD; void main(){ vD = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }",fragmentShader:`uniform vec3 zen, hor, gnd, sunCol, sunDir; uniform float haze; varying vec3 vD;
    void main(){
      vec3 d = normalize(vD); float h = d.y;
      vec3 c = h > 0.0 ? mix(hor, zen, pow(h, 0.5)) : mix(hor, gnd, pow(min(-h * 3.0, 1.0), 0.7));
      float sd = max(dot(d, normalize(sunDir)), 0.0);
      c += sunCol * (pow(sd, 900.0) * 14.0 + pow(sd, 40.0) * 0.45 * haze + pow(sd, 5.0) * 0.22 * haze * (1.0 - max(h, 0.0)));
      gl_FragColor = vec4(c, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`}),gc=new Tt(new ue(1e3,32,16),Pd);gc.frustumCulled=!1;gc.renderOrder=-10;sn.add(gc);var uv=new fr($n),Sr=null;function fv(){let n=new sa;n.add(new Tt(new ue(50,32,16),Pd)),Sr&&Sr.dispose(),Sr=uv.fromScene(n,.02,.1,200),Ld()}function Ld(){let n=H.qual===0;sn.environment=n?null:Sr&&Sr.texture,sc.intensity=_t.light.hemi+(n?1.1:0)}var Nh=[{n:"BAIXA",pr:.75,sh:0},{n:"M\xC9DIA",pr:1.25,sh:1024},{n:"ALTA",pr:2,sh:2048}];function Id(){let n=Nh[H.qual];$n.setPixelRatio(Math.min(devicePixelRatio,n.pr)),$n.shadowMap.enabled=n.sh>0,En.castShadow=n.sh>0,n.sh&&(En.shadow.mapSize.set(n.sh,n.sh),En.shadow.map&&(En.shadow.map.dispose(),En.shadow.map=null)),Sr&&Ld(),sn.traverse(t=>{t.material&&[].concat(t.material).forEach(e=>e.needsUpdate=!0)}),Dd()}function Dd(){$n.setSize(innerWidth,innerHeight,!1),me.aspect=innerWidth/innerHeight,me.updateProjectionMatrix()}addEventListener("resize",Dd);function Oh(n,t){let e=document.createElement("canvas");e.width=e.height=n;let i=e.getContext("2d"),s=i.createImageData(n,n),r=s.data;for(let a=0;a<n;a++)for(let o=0;o<n;o++){let c=t(o,a),l=(a*n+o)*4;r[l]=c[0],r[l+1]=c[1],r[l+2]=c[2],r[l+3]=c[3]??255}return i.putImageData(s,0,0),e}function rn(n,t=1,e=1,i=!0){let s=new Qn(n);return i&&(s.colorSpace=Ee),s.wrapS=s.wrapT=jr,s.repeat.set(t,e),s.anisotropy=hv,s}function He(n,t,e){let i=document.createElement("canvas");return i.width=n,i.height=t,e(i.getContext("2d"),n,t),i}var Ud=(()=>{let n=He(256,256,(t,e,i)=>{t.fillStyle="#ececec",t.fillRect(0,0,e,i);for(let s=0;s<9e3;s++){let r=Math.random()*e,a=Math.random()*i,o=3+Math.random()*8,c=185+Math.random()*70|0;t.strokeStyle=`rgba(${c},${c},${c},.55)`,t.lineWidth=.7+Math.random()*.8,t.beginPath(),t.moveTo(r,a),t.lineTo(r+(Math.random()-.5)*2,a+o),t.stroke()}});return rn(n,2,2)})(),Ea=new Qn(He(64,64,n=>{let t=n.createRadialGradient(32,32,2,32,32,32);t.addColorStop(0,"rgba(0,0,0,.6)"),t.addColorStop(1,"rgba(0,0,0,0)"),n.fillStyle=t,n.fillRect(0,0,64,64)})),Fh=new Qn(He(64,64,n=>{let t=n.createRadialGradient(32,32,0,32,32,32);t.addColorStop(0,"rgba(255,255,255,1)"),t.addColorStop(.4,"rgba(255,255,255,.6)"),t.addColorStop(1,"rgba(255,255,255,0)"),n.fillStyle=t,n.fillRect(0,0,64,64)})),rc=class{constructor(t,e){this.max=t,this.n=0,this.pos=new Float32Array(t*3),this.col=new Float32Array(t*3),this.size=new Float32Array(t),this.alpha=new Float32Array(t),this.vel=new Float32Array(t*3),this.life=new Float32Array(t),this.ml=new Float32Array(t),this.s0=new Float32Array(t),this.s1=new Float32Array(t),this.a0=new Float32Array(t),this.grav=new Float32Array(t),this.drag=new Float32Array(t);let i=new Pe,s=(r,a)=>{let o=new fe(r,a);return o.setUsage(sd),o};i.setAttribute("position",s(this.pos,3)),i.setAttribute("pcolor",s(this.col,3)),i.setAttribute("psize",s(this.size,1)),i.setAttribute("palpha",s(this.alpha,1)),this.geo=i,this.mat=new kn({uniforms:{uScale:{value:500},map:{value:Fh}},vertexShader:`attribute vec3 pcolor; attribute float psize; attribute float palpha; uniform float uScale; varying vec3 vC; varying float vA;
        void main(){ vC = pcolor; vA = palpha; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_PointSize = psize * uScale / max(0.1, -mv.z); gl_Position = projectionMatrix * mv; }`,fragmentShader:`uniform sampler2D map; varying vec3 vC; varying float vA;
        void main(){ float a = texture2D(map, gl_PointCoord).a * vA; if (a < 0.01) discard; gl_FragColor = vec4(vC, a); }`,transparent:!0,depthWrite:!1,blending:e?qi:Wi}),this.points=new aa(i,this.mat),this.points.frustumCulled=!1,sn.add(this.points)}spawn(t,e,i,s,r,a,o,c,l,h,u=1,f=0,d=1){if(this.n>=this.max)return;let p=this.n++,x=p*3;this.pos[x]=t,this.pos[x+1]=e,this.pos[x+2]=i,this.vel[x]=s,this.vel[x+1]=r,this.vel[x+2]=a,this.col[x]=h[0],this.col[x+1]=h[1],this.col[x+2]=h[2],this.life[p]=this.ml[p]=o,this.s0[p]=c,this.s1[p]=l,this.a0[p]=u,this.grav[p]=f,this.drag[p]=d,this.size[p]=c,this.alpha[p]=0}copy(t,e){for(let i=0;i<3;i++)this.pos[t*3+i]=this.pos[e*3+i],this.vel[t*3+i]=this.vel[e*3+i],this.col[t*3+i]=this.col[e*3+i];this.life[t]=this.life[e],this.ml[t]=this.ml[e],this.s0[t]=this.s0[e],this.s1[t]=this.s1[e],this.a0[t]=this.a0[e],this.grav[t]=this.grav[e],this.drag[t]=this.drag[e],this.size[t]=this.size[e],this.alpha[t]=this.alpha[e]}update(t){for(let e=0;e<this.n;e++){if(this.life[e]-=t,this.life[e]<=0){this.n--,e<this.n&&(this.copy(e,this.n),e--);continue}let i=e*3,s=Math.exp(-this.drag[e]*t);this.vel[i]*=s,this.vel[i+1]=this.vel[i+1]*s-this.grav[e]*t,this.vel[i+2]*=s,this.pos[i]+=this.vel[i]*t,this.pos[i+1]+=this.vel[i+1]*t,this.pos[i+2]+=this.vel[i+2]*t,this.pos[i+1]<.02&&(this.pos[i+1]=.02,this.vel[i+1]*=-.3);let r=1-this.life[e]/this.ml[e];this.size[e]=Ve(this.s0[e],this.s1[e],r),this.alpha[e]=this.a0[e]*Math.min(1,r*10)*(1-r)}this.geo.setDrawRange(0,this.n);for(let e of["position","pcolor","psize","palpha"])this.geo.attributes[e].needsUpdate=!0;this.mat.uniforms.uScale.value=$n.domElement.height/(2*Math.tan(rd.degToRad(me.fov)/2))}clear(){this.n=0}},pi=new rc(1400,!1),Un=new rc(1200,!0);function As(n,t){let e=Math.abs(2*n-1);return Math.pow(Math.max(0,1-Math.pow(e,t)),1/t)}function Pn(n,t,e){let i=new Float32Array((n+1)*t*3),s=new Float32Array((n+1)*t*2),r=[],a=0,o=0;for(let l=0;l<=n;l++){let h=l/n;for(let u=0;u<t;u++){let f=e(h,u/t*Math.PI*2);i[a++]=f[0],i[a++]=f[1],i[a++]=f[2],s[o++]=u/t*2,s[o++]=h*2}}for(let l=0;l<n;l++)for(let h=0;h<t;h++){let u=l*t+h,f=l*t+(h+1)%t,d=u+t,p=f+t;r.push(u,f,d,f,p,d)}let c=new Pe;return c.setAttribute("position",new fe(i,3)),c.setAttribute("uv",new fe(s,2)),c.setIndex(r),c.computeVertexNormals(),c}function ga(n,t,e,i=1){let s=Math.min(t,e)*.8,r=Pn(10,12,(a,o)=>{let c=Ve(t,e,a)*As(a,4);return[Math.cos(o)*c,Math.sin(o)*c*i,-s+a*(n+2*s)]});return r.rotateX(Math.PI/2),r}function Ii(n,t,e,i=14){let s=new ue(1,i,Math.round(i*.75));return s.scale(n,t,e),s}function yr(n,t,e,i=1){let s=As(t,2.4),r=Nt(.3,.85,t),a=Ve(n.rumpW,n.chW,r),o=Ve(n.rumpH,n.chH,r),c=Math.sin(e),l=Math.cos(e),h=c*o*s;return c<0?h*=1-n.waist*Ts(t,.36,.2):h+=n.arch*Ts(t,.38,.22)*s,[l*a*s*i,Ve(n.rumpY,0,r)+h*i,(t-.5)*n.len]}function uh(n,t){let[e,i,s]=n.skull,[r,a,o,c]=n.muzzle,l=e*.5,h=l+r,u=Math.sqrt(Math.max(0,1-(t/e)**2)),f=1;t>l&&(f=Math.pow(Math.max(0,1-Math.pow((t-l)/r,3)),1/3));let d=Nt(-e*.6,l,t);return{w:Math.max(i*u,a*f*d),h:Math.max(s*u,o*f*d),yc:-c*Nt(l-.03,l+.05,t),zStop:l,zEnd:Math.max(h,e)}}var oe=n=>new Ft(n),Vn={shepherd:{base:oe(12615482),dark:oe(2037779),light:oe(14726010)},dalmatian:{base:oe(15855592),dark:oe(1446671)},caramel:{base:oe(12611626),dark:oe(7224597),light:oe(15782042)},grey:{base:oe(8160401),light:oe(15856110)},husky:{base:oe(4673373),dark:oe(2764600),light:oe(15921904)},pug:{base:oe(14003058),dark:oe(2235674),light:oe(15255958)},pinscher:{base:oe(1446158),light:oe(11097887)},pitbull:{base:oe(9987647),light:oe(15986406),dark:oe(7226663)},boar:{base:oe(5061936),dark:oe(2366228),light:oe(8152916),hoof:oe(1446157)},opossum:{base:oe(8552314),light:oe(15526111),dark:oe(2235675),pink:oe(15321026)},gecko:{base:oe(15778634),dark:oe(2760469),light:oe(16116952),band:oe(14272488)},tegu:{base:oe(1250067),light:oe(15526367),belly:oe(14210508)}};function Nd(n,t,e){let i=t.cy,s=t.part==="head"?Nt(t.zStop-.03,t.zStop+.05,t.lz):0;switch(n.coat){case"shepherd":{let r=Vn.shepherd;if(t.part==="ear")return e.copy(r.dark);if(t.part==="head"){let a=Nt(.01,.07,t.ly)*Nt(t.zStop+.02,t.zStop-.05,t.lz);return e.copy(r.base).lerp(r.dark,Math.max(s*.9,a*.65))}if(t.part==="body"){let a=Nt(i,i+.08,t.y)*Nt(n.len/2,n.len/2-.22,t.z);return e.copy(r.base).lerp(r.light,Nt(i-n.chH*.2,i-n.chH*.8,t.y)*.6),e.lerp(r.dark,a)}return t.part==="neck"?e.copy(r.base).lerp(r.dark,Nt(0,.05,t.ly)*.6):t.part==="tail"?e.copy(r.base).lerp(r.dark,.72):e.copy(r.base)}case"dalmatian":{let r=Vn.dalmatian;if(t.part==="ear")return e.copy(r.dark).lerp(r.base,.1);for(let a of t.spots){let o=t.x-a[0],c=t.y-a[1],l=t.z-a[2];if(o*o+c*c+l*l<a[3]*a[3])return e.copy(r.dark)}return e.copy(r.base)}case"caramel":{let r=Vn.caramel;if(t.part==="ear")return e.copy(r.base).lerp(r.dark,.35);if(t.part==="head")return e.copy(r.base).lerp(r.light,Math.max(s*.75,Nt(0,-.035,t.ly)*.7));if(t.part==="body"){let a=Nt(i-n.chH*.1,i-n.chH*.7,t.y),o=Nt(n.len/2-.2,n.len/2-.05,t.z)*Nt(i+n.chH*.2,i-n.chH*.2,t.y);return e.copy(r.base).lerp(r.light,Math.max(a,o)*.85)}return t.part==="neck"?e.copy(r.base).lerp(r.light,Nt(0,-.03,t.ly)*.8):t.part==="paw"||t.part==="leg"&&t.seg>=2?e.copy(r.light):t.part==="tail"?e.copy(r.base).lerp(r.light,t.seg===3?.8:0):e.copy(r.base)}case"grey":{let r=Vn.grey;return t.part==="body"?e.copy(r.base).lerp(r.light,Nt(n.len/2-.22,n.len/2-.08,t.z)*Nt(i+n.chH*.1,i-n.chH*.3,t.y)*.9):t.part==="neck"?e.copy(r.base).lerp(r.light,Nt(0,-.03,t.ly)*.85):t.part==="paw"?e.copy(r.light):t.part==="head"?e.copy(r.base).lerp(r.light,Nt(.012,0,Math.abs(t.lx))*Nt(t.zStop-.05,t.zStop,t.lz)*.7):e.copy(r.base)}case"husky":{let r=Vn.husky;if(t.part==="ear")return e.copy(r.dark);if(t.part==="head"){let a=Nt(-.005,.045,t.ly)*Nt(t.zStop+.01,t.zStop-.03,t.lz),o=Nt(.022,.006,Math.abs(t.lx));return e.copy(r.light).lerp(r.base,a*(1-o*.9))}return t.part==="body"?e.copy(r.light).lerp(r.base,Nt(i-n.chH*.25,i+n.chH*.25,t.y)):t.part==="neck"?e.copy(r.light).lerp(r.base,Nt(-.01,.04,t.ly)):t.part==="tail"?e.copy(r.light).lerp(r.base,Nt(-.015,.02,t.ly)):t.part==="leg"&&t.seg===0&&!t.front?e.copy(r.base).lerp(r.light,.35):e.copy(r.light)}case"pug":{let r=Vn.pug;return t.part==="ear"?e.copy(r.dark):t.part==="head"?e.copy(r.base).lerp(r.dark,Nt(t.zStop-.05,t.zStop+.005,t.lz)*.95):t.part==="body"?e.copy(r.base).lerp(r.light,Nt(i,i-n.chH*.7,t.y)*.4):e.copy(r.base)}case"pinscher":{let r=Vn.pinscher;if(t.part==="ear")return e.copy(r.base);if(t.part==="head"){let a=Math.max(0,1-Math.hypot(Math.abs(t.lx)-.02,t.ly-.028,t.lz-(t.zStop-.01))/.012);return e.copy(r.base).lerp(r.light,Math.max(s*.95,Nt(-.005,-.03,t.ly)*.9,a))}return t.part==="body"?e.copy(r.base).lerp(r.light,Nt(n.len/2-.12,n.len/2-.03,t.z)*Nt(i,i-n.chH*.5,t.y)):t.part==="neck"?e.copy(r.base).lerp(r.light,Nt(0,-.02,t.ly)*.9):t.part==="paw"||t.part==="leg"&&t.seg>=1?e.copy(r.light):e.copy(r.base)}case"boar":{let r=Vn.boar;return t.part==="ear"||t.part==="tail"?e.copy(r.dark):t.part==="paw"?e.copy(r.hoof):t.part==="head"?e.copy(r.base).lerp(r.light,Nt(0,-.04,t.ly)*.5).lerp(r.dark,s*.45):t.part==="body"?e.copy(r.base).lerp(r.dark,Nt(i+n.chH*.2,i+n.chH*.9,t.y)*.8).lerp(r.light,Nt(i-n.chH*.4,i-n.chH,t.y)*.35):t.part==="neck"?e.copy(r.base).lerp(r.dark,Nt(0,.05,t.ly)*.7):t.part==="leg"?e.copy(r.base).lerp(r.dark,t.seg>=1?.7:.2):e.copy(r.base)}case"opossum":{let r=Vn.opossum,a=Ni(t.x*220+t.z*130,t.y*220,0,13);if(t.part==="ear")return e.copy(t.ly>n.earL*.55?r.light:r.dark);if(t.part==="head"){let[o,c,l]=n.skull,h=Nt(.016,.006,Math.abs(t.ly-l*.3))*Nt(c*.25,c*.45,Math.abs(t.lx))*Nt(t.zStop+.03,t.zStop-.01,t.lz),u=Nt(.012,.004,Math.abs(t.lx))*Nt(l*.3,l*.7,t.ly)*Nt(t.zStop,t.zStop-.04,t.lz);return e.copy(r.light).lerp(r.pink,s*Nt(t.zStop+n.muzzle[0]*.6,t.zStop+n.muzzle[0],t.lz)).lerp(r.dark,Math.max(h,u))}return t.part==="body"?e.copy(r.base).lerp(r.light,a>.62?.55:0).lerp(r.light,Nt(i-n.chH*.3,i-n.chH*.8,t.y)*.6):t.part==="neck"?e.copy(r.light).lerp(r.base,Nt(0,.05,t.ly)*.6):t.part==="leg"?e.copy(t.seg>=1?r.dark:r.base):t.part==="paw"?e.copy(r.pink):t.part==="tail"?e.copy(t.seg===0?r.dark:r.pink):e.copy(r.base)}case"gecko":{let r=Vn.gecko;if(t.part==="paw")return e.copy(r.light);for(let a of t.spots){let o=t.x-a[0],c=t.y-a[1],l=t.z-a[2];if(o*o+c*c+l*l<a[3]*a[3])return e.copy(r.dark)}return t.part==="body"&&t.ly<-n.chH*.35?e.copy(r.light):t.part==="tail"?e.copy(r.base).lerp(r.band,Math.sin(t.z*60)>.2?.7:.15).lerp(r.light,Nt(0,-.03,t.ly)*.6):t.part==="head"&&t.ly<-.012?e.copy(r.light):e.copy(r.base)}case"tegu":{let r=Vn.tegu,a=Ni(t.x*260+t.z*150,t.y*260+t.z*90,0,11);if(t.part==="body"||t.part==="tail"){if(t.ly<-n.chH*.45)return e.copy(r.belly).lerp(r.base,Math.sin(t.z*70)>.6?.8:0);let o=Math.sin(t.z*(t.part==="tail"?32:42)+Ni(t.x*30,t.z*30,0,5)*2.5)>.35;return e.copy(o&&a>.35?r.light:r.base)}return t.part==="head"?e.copy(t.ly<-.018?r.belly:a>.72?r.light:r.base):t.part==="leg"||t.part==="paw"?e.copy(a>.6?r.light:r.base):e.copy(r.base)}case"pitbull":{let r=Vn.pitbull;return t.part==="ear"?e.copy(r.dark):t.part==="head"?e.copy(r.base).lerp(r.light,Nt(.012,.004,Math.abs(t.lx))*Nt(t.zStop-.06,t.zStop,t.lz)*.9):t.part==="body"?e.copy(r.base).lerp(r.light,Nt(n.len/2-.2,n.len/2-.06,t.z)*Nt(i+n.chH*.2,i-n.chH*.3,t.y)):t.part==="neck"?e.copy(r.base).lerp(r.light,Nt(0,-.03,t.ly)):t.part==="paw"||t.part==="leg"&&t.seg===2?e.copy(r.light):e.copy(r.base)}}return e.set(16777215)}var Be=[{id:"rex",name:"REX",raca:"PASTOR ALEM\xC3O",coat:"shepherd",color:"#e53935",pitch:.85,eye:3875856,len:.8,chH:.16,chW:.12,rumpH:.13,rumpW:.11,rumpY:0,waist:.3,arch:.01,backY:.6,bone:.028,neck:.2,neckA:.85,skull:[.1,.075,.07],muzzle:[.12,.04,.038,.025],ear:"erect",earW:.05,earL:.12,tail:[.52,.035,-1,.22],spd:4,acc:3,han:3,jmp:3},{id:"pingo",name:"PINGO",raca:"D\xC1LMATA",coat:"dalmatian",color:"#1e63ff",pitch:1,eye:2758411,len:.78,chH:.15,chW:.11,rumpH:.12,rumpW:.1,rumpY:0,waist:.35,arch:0,backY:.62,bone:.026,neck:.2,neckA:.8,skull:[.095,.072,.07],muzzle:[.115,.042,.04,.022],ear:"floppy",earW:.045,earL:.11,tail:[.45,.028,-.35,.06],spd:3,acc:4,han:3,jmp:3},{id:"caramelo",name:"CARAMELO",raca:"VIRA-LATA",coat:"caramel",color:"#16a34a",pitch:1.05,eye:3021324,len:.7,chH:.14,chW:.11,rumpH:.12,rumpW:.1,rumpY:0,waist:.28,arch:0,backY:.52,bone:.026,neck:.18,neckA:.8,skull:[.09,.075,.072],muzzle:[.1,.043,.04,.022],ear:"fold",earW:.045,earL:.09,tail:[.42,.03,.9,.55],spd:3,acc:3,han:4,jmp:3},{id:"flecha",name:"FLECHA",raca:"GALGO",coat:"grey",color:"#f59e0b",pitch:.95,eye:2364682,len:.82,chH:.17,chW:.085,rumpH:.1,rumpW:.08,rumpY:.02,waist:.62,arch:.035,backY:.68,bone:.022,neck:.24,neckA:.75,skull:[.1,.058,.058],muzzle:[.16,.032,.032,.018],ear:"rose",earW:.035,earL:.08,tail:[.62,.022,-1.2,.2],spd:5,acc:2,han:2,jmp:4},{id:"nevasca",name:"NEVASCA",raca:"HUSKY SIBERIANO",coat:"husky",color:"#8b5cf6",pitch:.8,eye:4891647,len:.75,chH:.15,chW:.12,rumpH:.13,rumpW:.11,rumpY:0,waist:.2,arch:0,backY:.58,bone:.028,neck:.18,neckA:.85,skull:[.095,.08,.075],muzzle:[.1,.044,.042,.022],ear:"erect",earW:.045,earL:.09,tail:[.45,.05,.8,.5],spd:4,acc:4,han:3,jmp:2},{id:"bolinha",name:"BOLINHA",raca:"PUG",coat:"pug",color:"#84cc16",pitch:1.35,eye:1707526,eyeR:.028,len:.5,chH:.15,chW:.14,rumpH:.13,rumpW:.12,rumpY:.01,waist:.05,arch:0,backY:.38,bone:.03,neck:.08,neckA:.7,skull:[.1,.105,.095],muzzle:[.03,.06,.045,.03],ear:"floppy",earW:.04,earL:.07,tail:[.2,.035,1.5,1.3],spd:2,acc:5,han:4,jmp:2},{id:"pitiquin",name:"PITIQUIN",raca:"PINSCHER",coat:"pinscher",color:"#06b6d4",pitch:1.7,eye:1182213,eyeR:.017,len:.42,chH:.095,chW:.068,rumpH:.08,rumpW:.062,rumpY:.005,waist:.35,arch:0,backY:.37,bone:.016,neck:.12,neckA:.95,skull:[.058,.045,.044],muzzle:[.06,.021,.021,.012],ear:"erect",earW:.034,earL:.08,tail:[.1,.018,1.2,.1],spd:3,acc:5,han:3,jmp:2},{id:"princesa",name:"PRINCESA",raca:"PITBULL",coat:"pitbull",color:"#ff4fa3",pitch:.9,eye:5911828,nose:7027246,crown:!0,len:.72,chH:.17,chW:.14,rumpH:.13,rumpW:.115,rumpY:0,waist:.25,arch:0,backY:.52,bone:.034,neck:.14,neckA:.75,skull:[.1,.1,.085],muzzle:[.08,.058,.05,.03],ear:"rose",earW:.04,earL:.06,tail:[.4,.035,-.6,.1],spd:4,acc:4,han:2,jmp:3},{id:"linda",name:"LINDA",raca:"JAVALI",coat:"boar",color:"#0f766e",pitch:.8,voice:"grunt",mass:1.8,eye:1707526,eyeR:.014,snoutDisc:!0,tusks:!0,mane:!0,headDown:.3,len:.82,chH:.21,chW:.15,rumpH:.17,rumpW:.135,rumpY:.01,waist:.05,arch:.03,backY:.5,bone:.032,neck:.1,neckA:.3,skull:[.11,.085,.09],muzzle:[.2,.045,.045,.03],ear:"erect",earW:.042,earL:.07,tail:[.2,.012,-1.2,.1],spd:4,acc:4,han:2,jmp:3},{id:"faiton",name:"FAITON",raca:"LOBO NEGRO",kind:"glb",model:"faiton",color:"#dc2626",pitch:.7,mass:1.3,spd:5,acc:3,han:3,jmp:2},{id:"paz",name:"PAZ",raca:"CACHORRO DA PAZ",kind:"glb",model:"paz",fly:!0,color:"#38bdf8",pitch:1.2,mass:.9,spd:3,acc:3,han:4,jmp:2},{id:"voador",name:"PINCHER VOADOR",raca:"PINSCHER AVIADOR",kind:"glb",model:"voador",fly:!0,prop:!0,color:"#f472b6",pitch:1.6,mass:1,spd:4,acc:3,han:3,jmp:1},{id:"pintado",name:"PINTADO",raca:"MABECO",kind:"glb",model:"mabeco",color:"#a16207",pitch:1.1,spd:4,acc:4,han:3,jmp:2},{id:"ruivo",name:"RUIVO",raca:"DINGO",kind:"glb",model:"dingo",color:"#ea580c",pitch:1,spd:4,acc:3,han:3,jmp:3},{id:"ninja",name:"NINJA",raca:"SHIBA INU",kind:"glb",model:"shiba",color:"#334155",pitch:1.3,spd:3,acc:4,han:4,jmp:2},{id:"sombra",name:"SOMBRA",raca:"DOBERMANN",kind:"glb",model:"dobermann",color:"#6d28d9",pitch:.85,mass:1.2,spd:4,acc:4,han:2,jmp:3},{id:"pacoca",name:"PA\xC7OCA",raca:"VIRA-LATA",kind:"glb",model:"vira",color:"#92400e",pitch:1.05,spd:3,acc:3,han:4,jmp:3},{id:"raio",name:"RAIO",raca:"GREYHOUND",kind:"glb",model:"greyhound",color:"#facc15",pitch:.95,spd:5,acc:2,han:2,jmp:4},{id:"duque",name:"DUQUE",raca:"PINSCHER ALEM\xC3O",kind:"glb",model:"duque",color:"#b91c1c",pitch:1.1,spd:4,acc:3,han:3,jmp:3},{id:"frufru",name:"FRUFRU",raca:"POODLE",kind:"glb",model:"poodle",color:"#e879f9",pitch:1.4,spd:3,acc:3,han:4,jmp:3},{id:"major",name:"MAJOR",raca:"PASTOR ALEM\xC3O",kind:"glb",model:"major",color:"#1d4ed8",pitch:.85,mass:1.2,spd:4,acc:3,han:3,jmp:3},{id:"tofu",name:"TOFU",raca:"PUG",kind:"glb",model:"pug2",color:"#65a30d",pitch:1.35,mass:.9,spd:2,acc:5,han:4,jmp:2},{id:"bidu",name:"BIDU",raca:"BOIADEIRO BERN\xCAS",kind:"glb",model:"bernes",color:"#0f766e",pitch:.8,mass:1.5,spd:3,acc:3,han:3,jmp:3},{id:"canela",name:"CANELA",raca:"AKITA",kind:"glb",model:"canela",color:"#c2410c",pitch:.95,spd:3,acc:4,han:3,jmp:3},{id:"biscoito",name:"BISCOITO",raca:"BEAGLE",kind:"glb",model:"beagle",color:"#0891b2",pitch:1.15,spd:3,acc:4,han:4,jmp:2},{id:"emilly",name:"EMILLY",raca:"SARU\xCA",coat:"opossum",noTongue:!0,color:"#be123c",pitch:2.2,voice:"hiss",mass:.8,eye:525830,eyeR:.016,nose:15179946,len:.6,chH:.13,chW:.11,rumpH:.145,rumpW:.125,rumpY:.025,waist:.05,arch:.035,backY:.35,bone:.02,neck:.08,neckA:.35,headDown:.15,skull:[.08,.06,.055],muzzle:[.13,.026,.024,.018],ear:"round",earW:.035,earL:.055,tail:[.6,.026,-.45,.2],spd:3,acc:4,han:4,jmp:2},{id:"taissa",name:"TAISSA",raca:"LAGARTIXA",kind:"lizard",coat:"gecko",color:"#facc15",pitch:1.8,voice:"hiss",mass:.6,scale:1.3,eye:1840914,eyeR:.024,len:.42,chW:.085,chH:.05,backY:.09,headL:[.15,.058,.036],bone:.013,legU:.1,gearS:.55,tailL:.42,tailR:.042,spd:2,acc:5,han:5,jmp:1},{id:"tiffany",name:"TIFFANY",raca:"TEI\xDA",kind:"lizard",coat:"tegu",color:"#f97316",pitch:1,voice:"hiss",mass:1.2,forked:!0,eye:657930,eyeR:.011,len:.68,chW:.13,chH:.075,backY:.13,headL:[.2,.068,.048],bone:.02,legU:.13,gearS:.8,tailL:.9,tailR:.068,spd:4,acc:3,han:4,jmp:2}];function zh(n,t){let e=new Qn(He(64,64,i=>{i.fillStyle="#fff",i.beginPath(),i.arc(32,32,29,0,7),i.fill(),i.lineWidth=6,i.strokeStyle=t,i.stroke(),i.fillStyle="#111",i.font="bold 34px Arial",i.textAlign="center",i.textBaseline="middle",i.fillText(String(n),32,34)}));return e.colorSpace=Ee,e}var Od=new te({color:1708560,roughness:.5}),gh=new te({color:1315346,roughness:.35}),Fd=new te({color:14704762,roughness:.4}),ac=new te({color:12897496,roughness:.25,metalness:.6}),zd=new te({color:13703722,roughness:.3,metalness:.6}),Bd=new Cn({color:6737151,transparent:!0,opacity:.85,blending:qi,depthWrite:!1}),xc=new Cn({color:16769357}),Ca=new Qn(He(64,64,n=>{n.fillStyle="#ffcc00",n.beginPath(),n.arc(32,32,28,0,7),n.fill(),n.fillStyle="#111",n.font="bold 44px Arial",n.textAlign="center",n.textBaseline="middle",n.fillText("!",32,35)}));Ca.colorSpace=Ee;var xh=new te({color:3818063,roughness:.4,metalness:.5}),Bh=new te({color:16742938,roughness:.4,metalness:.3,emissive:4200448}),oc=new te({color:14753066,roughness:.3,metalness:.4}),Hd=(()=>{let n=He(128,128,(t,e,i)=>{t.fillStyle="#e8e8e8",t.fillRect(0,0,e,i);for(let s=0;s<16;s++)for(let r=0;r<16;r++){let a=r*8+s%2*4,o=s*8,c=175+Math.random()*60|0;t.fillStyle=`rgb(${c},${c},${c})`,t.beginPath(),t.ellipse(a,o,3.6,3.1,0,0,7),t.fill()}});return rn(n,3,3)})(),yh=new Set([Ea,Ud,Hd,Od,gh,Fd,ac,zd,Bd,xc,Ca,Ea,Fh,xh,Bh,oc]);function Hh(n,t,e,i=1){let s=new vt;s.position.set(0,t,e),s.scale.setScalar(i),n.add(s),t=0,e=0;let r=[];for(let h of[-1,1]){let u=new Tt(new Vt(.026,.026,.16,12),ac);u.rotation.x=Math.PI/2,u.position.set(h*.034,t+.02,e),u.castShadow=!0,s.add(u);let f=new Tt(new ue(.026,10,6,0,Math.PI*2,0,Math.PI/2),zd);f.rotation.x=Math.PI/2,f.position.set(h*.034,t+.02,e+.08),s.add(f);let d=new Tt(new Vt(.012,.018,.03,8),ac);d.rotation.x=Math.PI/2,d.position.set(h*.034,t+.02,e-.095),s.add(d);let p=new Tt(new Ke(.02,.2,8),Bd);p.rotation.x=-Math.PI/2,p.position.set(h*.034,t+.02,e-.21),p.visible=!1,s.add(p),r.push(p)}let a=new vt;a.position.set(0,t+.058,e+.015),s.add(a);let o=new Tt(new pe(.075,.012,.09),xh);o.position.y=-.012,a.add(o);let c=[];[[-.02,.012],[.02,.012],[0,.044]].forEach(([h,u])=>{let f=new Tt(new Vt(.018,.018,.15,12,1,!0),xh);f.material.side=Fe,f.rotation.x=Math.PI/2,f.position.set(h,u,0),f.castShadow=!0,a.add(f);let d=new Tt(new Vt(.0195,.0195,.014,12),Bh);d.rotation.x=Math.PI/2,d.position.set(h,u,.06),a.add(d);let p=new Tt(new Ke(.014,.034,10),oc);p.rotation.x=Math.PI/2,p.position.set(h,u,.082),a.add(p),c.push(p)});let l=new qe;return l.position.set(0,.03,.12),a.add(l),{flames:r,launcher:{g:a,noses:c,muzzle:l}}}var Qo=2.3;function dv(n,t,e){let i=new vt,s=new vt,r=new vt;i.add(s),s.add(r);let a=new te({vertexColors:!0,map:Ud,roughness:.88}),o=[],c=(v,_,D,k={},W=a)=>{let Z=new Tt(v,W);return Z.userData={part:D,...k},Z.castShadow=!0,_.add(Z),W===a&&o.push(Z),Z},l=n.backY-n.chH*.9,h=c(Pn(28,22,(v,_)=>yr(n,v,_)),r,"body");h.position.y=l;let[u,f,d]=n.skull,[p,x,g,m]=n.muzzle,S=new vt;S.position.set(0,l+n.chH*.3,n.len/2-.07),S.rotation.x=-n.neckA,r.add(S),c(Pn(10,16,(v,_)=>{let D=As(.5+v*.5,3)*.3+.7*(v<.9?1:As(.5+(v-.9)*5,2)),k=Ve(n.chW*.72,f*.8,v)*D,W=Ve(n.chH*.62,d*.85,v)*D;return[Math.cos(_)*k,Math.sin(_)*W,-.04+v*(n.neck+.06)]}),S,"neck");let y=new vt;y.position.set(0,0,n.neck),y.rotation.x=n.neckA-.12+(n.headDown||0),S.add(y);let b=new vt;b.position.set(0,d*.2,u*.55),y.add(b);let C=uh(n,0);c(Pn(34,22,(v,_)=>{let D=-u+v*(C.zEnd+u),k=uh(n,D),W=Math.sin(_);return[Math.cos(_)*k.w,k.yc+W*k.h*(W<0?.88:1),D]}),b,"head");let A=n.eye===4891647?new te({color:4891647,roughness:.05,emissive:664640}):new te({color:n.eye,roughness:.06}),w=n.eyeR||f*.24,F=[0,0,0];{let v=C.zStop-u*.08,_=uh(n,v),D=.42;for(let k of[-1,1]){let W=new Tt(new ue(w,12,9),A);W.position.set(k*Math.cos(D)*_.w*.9,_.yc+Math.sin(D)*_.h*.9,v+w*.3),b.add(W),k>0&&(F=[W.position.x,W.position.y,W.position.z]);let Z=new Tt(new ue(w*1.12,12,6,0,Math.PI*2,0,Math.PI*.42),Od);Z.position.copy(W.position),Z.rotation.x=-.2,b.add(Z)}}let E=Math.max(C.zStop+p-x*.25,u*.97),M=new Tt(Ii(x*.62,x*.42,x*.4),n.nose?new te({color:n.nose,roughness:.35}):gh);if(M.position.set(0,-m+g*.52,E),b.add(M),n.snoutDisc){M.visible=!1;let v=new te({color:12157816,roughness:.55}),_=new Tt(new Vt(x*.95,x*1,.02,22),v);_.rotation.x=Math.PI/2,_.position.set(0,-m*.9,C.zStop+p-.004),b.add(_);for(let D of[-1,1]){let k=new Tt(new ue(x*.2,8,6),gh);k.scale.z=.4,k.position.set(D*x*.35,-m*.9,C.zStop+p+.007),b.add(k)}}if(n.tusks){let v=new te({color:15985366,roughness:.35});for(let _ of[-1,1]){let D=new Tt(new Ke(.009,.06,8),v);D.position.set(_*x*.95,-m-g*.35,C.zStop+p*.62),D.rotation.set(-.5,0,-_*.55),D.castShadow=!0,b.add(D)}}if(n.crown){let v=new te({color:16762173,roughness:.3,metalness:.6,emissive:3810304});var I=new vt;I.position.set(0,d*.95,-u*.1),I.rotation.x=-.15,b.add(I),I.add(new Tt(new Vt(.032,.036,.018,16,1,!0),v));for(let _=0;_<5;_++){let D=_/5*Math.PI*2,k=new Tt(new Ke(.009,.026,6),v);k.position.set(Math.cos(D)*.032,.02,Math.sin(D)*.032),I.add(k);let W=new Tt(new ue(.005,8,6),new te({color:16723338,roughness:.1,emissive:5570594}));W.position.set(Math.cos(D)*.035,.002,Math.sin(D)*.035),I.add(W)}I.traverse(_=>{_.isMesh&&(_.castShadow=!0)})}let N=new vt;N.position.set(0,-m-g*.75,C.zStop+p*.35),b.add(N);let J=new Tt(Ii(x*.55,.008,.06),Fd);J.position.set(0,-.02,.02),J.rotation.x=.9,N.add(J);let P=[];for(let v of[-1,1]){let _=new vt;if(_.position.set(v*f*.55,d*.7,-u*.28),b.add(_),n.ear==="round"){let D=Pn(8,12,(k,W)=>{let Z=n.earW*Math.pow(Math.sin(Math.PI*(.06+.94*k)),.55);return[Math.cos(W)*Z,Math.sin(W)*.01,k*n.earL]});D.rotateX(-Math.PI/2),c(D,_,"ear"),_.rotation.set(-.15,0,-v*.45)}else if(n.ear==="erect"||n.ear==="fold"){let D=Pn(8,12,(k,W)=>{let Z=n.earW*Math.pow(1-k,.85)*(k<.12?.75+2*k:1);return[Math.cos(W)*Z,Math.sin(W)*(.018*(1-k*.6)),k*n.earL]});D.rotateX(-Math.PI/2),c(D,_,"ear"),_.rotation.set(n.ear==="fold"?.55:-.12,0,-v*.28)}else{let D=Pn(8,12,(k,W)=>{let Z=n.earW*Math.pow(Math.sin(Math.PI*(.12+.88*k)),.7);return[Math.cos(W)*Z,Math.sin(W)*.013,k*n.earL]});D.rotateX(Math.PI/2),c(D,_,"ear"),_.rotation.set(n.ear==="rose"?1.3:.05,0,v*.35)}P.push({piv:_,type:n.ear,rx:_.rotation.x,rz:_.rotation.z,sx:v})}let O=[],z=n.bone;for(let v of[{f:1,sx:-1,off:0},{f:1,sx:1,off:.55},{f:0,sx:-1,off:Math.PI+.2},{f:0,sx:1,off:Math.PI+.75}]){let _=new vt;v.f?_.position.set(v.sx*n.chW*.6,l-n.chH*.2,n.len/2-.11):_.position.set(v.sx*n.rumpW*.62,l+n.rumpY,-n.len/2+.13),r.add(_);let D=_.position.y,k=D*(v.f?.44:.42),W=D*.44,Z=D*(v.f?.15:.28);c(ga(k,v.f?z*2:z*2.6,v.f?z*1.25:z*1.35,v.f?1.15:1.35),_,"leg",{front:v.f,seg:0});let bt=new vt;bt.position.y=-k,_.add(bt),c(ga(W,z*1.1,z*.78,1.1),bt,"leg",{front:v.f,seg:1});let lt=new vt;lt.position.y=-W,bt.add(lt),c(ga(Z,z*.82,z*.72,1.1),lt,"leg",{front:v.f,seg:2});let wt=c(Ii(z*1.15,z*.72,z*1.55),lt,"paw",{front:v.f});wt.position.set(0,-Z-z*.35,z*.7);let zt=v.f?.45:-.55,qt=v.f?-.45:1.15,at=v.f?-.22:-.6;_.rotation.x=zt,bt.rotation.x=qt,lt.rotation.x=at,O.push({hip:_,knee:bt,ank:lt,paw:wt,front:v.f,off:v.off,rh:zt,rk:qt,ra:at})}let[Q,j,K,st]=n.tail,it=new vt;it.position.set(0,l+n.rumpY+n.rumpH*.55,-n.len/2+.04),r.add(it);let xt=[],$=it;for(let v=0;v<4;v++){let _=j*(1-v/4*.55),D=j*(1-(v+1)/4*.55),k=Q/4,W=Pn(6,10,(bt,lt)=>{let wt=Ve(_,D,bt)*As(bt,3);return[Math.cos(lt)*wt,Math.sin(lt)*wt,-_*.6+bt*(k+_*1.2)]});W.rotateY(Math.PI);let Z=new vt;Z.position.z=v?-k:0,$.add(Z),c(W,Z,"tail",{seg:v}),Z.rotation.x=v?st:K,xt.push(Z),$=Z}let et=new te({color:e,roughness:.45,metalness:.15,side:Fe}),ut=new Tt(Pn(8,22,(v,_)=>yr(n,Ve(.47,.72,v),_,1.07)),et);ut.position.y=l,ut.castShadow=!0,r.add(ut);let Lt=new te({map:zh(t,e),transparent:!0,roughness:.5});for(let v of[-1,1]){let _=yr(n,.6,v>0?0:Math.PI,1.08),D=new Tt(new on(.12,.12),Lt);D.position.set(_[0]+v*.004,l+_[1],_[2]),D.rotation.y=v*Math.PI/2,r.add(D)}let St=l+yr(n,.52,Math.PI/2,1.07)[1],Bt=yr(n,.5,0)[2],{flames:nt,launcher:ct}=Hh(r,St,Bt);if(n.mane){let v=new te({color:1971986,roughness:.95});for(let _=0;_<16;_++){let D=Ve(.28,.98,_/15),k=yr(n,D,Math.PI/2);if(Math.abs(k[2]-Bt)<.1)continue;let W=new Tt(new Ke(.014,.06+.02*Math.sin(_),5),v);W.position.set(0,l+k[1]+.012,k[2]),W.rotation.x=-.5,W.castShadow=!0,r.add(W)}}let gt=new vt;gt.position.set(0,d*2.2,0),b.add(gt);for(let v=0;v<4;v++){let _=new Tt(new pr(.025),xc);_.position.set(Math.cos(v*1.57)*.09,0,Math.sin(v*1.57)*.09),gt.add(_)}gt.visible=!1;let R=new gs(new Ki({map:Ca,depthTest:!1}));R.scale.set(.13,.13,1),R.position.set(0,d*2.8,0),R.visible=!1,b.add(R),s.updateMatrixWorld(!0);let rt=new Hn;for(let v of O)rt.setFromObject(v.paw),v.hip.position.y-=rt.min.y;s.updateMatrixWorld(!0);let Y=[];if(n.coat==="dalmatian")for(let v=0;v<300;v++)Y.push([Ut(-.2,.2),Ut(.02,.8),Ut(-.6,.75),Ut(.012,.03)]);let tt=new L,q=new Ft;for(let v of o){let _=v.geometry.attributes.position,D=new Float32Array(_.count*3);for(let k=0;k<_.count;k++){tt.fromBufferAttribute(_,k);let W=tt.x,Z=tt.y,bt=tt.z;tt.applyMatrix4(v.matrixWorld),Nd(n,{part:v.userData.part,front:v.userData.front,seg:v.userData.seg,zStop:C.zStop,lx:W,ly:Z,lz:bt,x:tt.x,y:tt.y,z:tt.z,cy:l,spots:Y},q);let lt=(.9+.2*Ni(tt.x*45+tt.z*17,tt.y*45,0,3))*(v.userData.part==="body"?1-.1*Nt(l,l+n.chH,tt.y):1);D[k*3]=q.r*lt,D[k*3+1]=q.g*lt,D[k*3+2]=q.b*lt}v.geometry.setAttribute("color",new fe(D,3))}s.scale.setScalar(Qo);let Ct=new Tt(new on(1,1),new Cn({map:Ea,transparent:!0,depthWrite:!1}));Ct.rotation.x=-Math.PI/2,Ct.position.y=.04,Ct.scale.set(n.chW*5*Qo,n.len*1.5*Qo,1),i.add(Ct);let yt={hat:[0,d*.9,-u*.12],s:f,eye:F,er:w,cape:[0,l+n.chH*.98,n.len/2-.15],capeW:n.chW,capeL:n.len};return{root:i,model:s,body:r,torso:h,neckPiv:S,headPiv:y,head:b,legs:O,tails:xt,ears:P,tongue:N,flames:nt,stars:gt,excl:R,blob:Ct,b:n,launcher:ct,anim:Rv,vestMat:et,hi:yt,crown:typeof I<"u"?I:null}}var Rs={hat:{n:"CHAP\xC9US",items:[["none","NENHUM",0],["bone","BON\xC9",150],["festa","CHAP\xC9U DE FESTA",200],["cartola","CARTOLA",300],["cowboy","CHAP\xC9U DE CAUB\xD3I",350],["capacete","CAPACETE DE CORRIDA",450],["coroa","COROA DE REI",800]]},glasses:{n:"\xD3CULOS",items:[["none","NENHUM",0],["escuro","\xD3CULOS ESCUROS",150],["nerd","\xD3CULOS DE NERD",200],["aviador","AVIADOR",250],["coracao","CORA\xC7\xC3O",300]]},cape:{n:"CAPAS",items:[["none","NENHUMA",0],["vermelha","CAPA VERMELHA",300],["azul","CAPA AZUL",300],["roxa","CAPA ROXA",350],["dourada","CAPA DOURADA",600]]},vest:{n:"COLETES",items:[["padrao","COR ORIGINAL",0],["preto","PRETO",100],["branco","BRANCO",100],["vermelho","VERMELHO",100],["azul","AZUL",100],["verde","VERDE",100],["roxo","ROXO",100],["rosa","ROSA",100],["dourado","DOURADO",300]]},trail:{n:"RASTROS",items:[["none","NENHUM",0],["bolhas","BOLHAS",350],["coracoes","CORA\xC7\xD5ES",450],["estrelas","ESTRELAS",500],["fogo","FOGO",550],["arcoiris","ARCO-\xCDRIS",700]]}},kd={preto:1842207,branco:15921906,vermelho:14163754,azul:2056191,verde:1483594,roxo:8141549,rosa:16732067,dourado:16762173},Gd={vermelha:"#d81f2a",azul:"#1f5fff",roxa:"#7c3aed",dourada:"#ffc53d"},pv={bolhas:"#9fdcff",coracoes:"#ff5f9e",estrelas:"#ffe14d",fogo:"#ff7a1a",arcoiris:"linear-gradient(90deg,#f33,#fc3,#3c6,#39f,#c3f)"},mv={bone:"#d81f2a",festa:"#ff4fa3",cartola:"#1a1a1a",cowboy:"#8a5a2b",capacete:"#f4f4f4",coroa:"#ffc53d"},gv={escuro:"#111",nerd:"#333",aviador:"#c9a24a",coracao:"#ff5f9e"},xv={hat:"none",glasses:"none",cape:"none",vest:"padrao",trail:"none"},yv=(n,t)=>Rs[n].items.find(e=>e[0]===t)[2]===0||H.owned.includes(n+":"+t);function yc(n){return Object.assign({},xv,H.looks[n.id]||{})}function Vd(){let n=(t,e)=>Math.random()<e?Rs[t].items[1+(Math.random()*(Rs[t].items.length-1)|0)][0]:Rs[t].items[0][0];return{hat:n("hat",.35),glasses:n("glasses",.25),cape:n("cape",.12),vest:"padrao",trail:n("trail",.15)}}function cn(n,t=.5,e=0,i={}){return new te({color:n,roughness:t,metalness:e,...i})}function _v(n,t){let e=new vt,i=(s,r,a=0,o=0,c=0)=>{let l=new Tt(s,r);return l.position.set(a,o,c),l.castShadow=!0,e.add(l),l};if(n==="bone")i(new ue(t*.95,18,10,0,Math.PI*2,0,Math.PI/2),cn(14163754,.6)).scale.y=.75,i(new pe(t*1.3,t*.06,t*.9),cn(16053492,.6),0,t*.03,t*1.05),i(new ue(t*.12,8,6),cn(16053492),0,t*.72,0);else if(n==="festa"){let s=new Qn(He(64,64,r=>{for(let a=0;a<8;a++)r.fillStyle=a%2?"#ffe14d":"#ff4fa3",r.fillRect(0,a*8,64,8)}));s.colorSpace=Ee,i(new Ke(t*.6,t*1.9,20),cn(16777215,.6,0,{map:s}),0,t*.9,0),i(new ue(t*.2,10,8),cn(3526911,.9),0,t*1.9,0)}else if(n==="cartola"){let s=cn(1381653,.45);i(new Vt(t*1.25,t*1.25,t*.08,24),s,0,t*.02,0),i(new Vt(t*.72,t*.76,t*1.4,24),s,0,t*.72,0),i(new Vt(t*.78,t*.78,t*.26,24),cn(14163754,.5),0,t*.22,0)}else if(n==="cowboy"){let s=cn(9067051,.8);i(new Vt(t*1.7,t*1.7,t*.07,28),s).scale.z=.85,i(new Vt(t*.72,t*.85,t*.95,20),s,0,t*.48,0),i(new Vt(t*.87,t*.87,t*.2,20),cn(2824718,.6),0,t*.14,0)}else if(n==="capacete")i(new ue(t*1.25,22,12,0,Math.PI*2,0,Math.PI*.55),cn(16053492,.15,.2),0,-t*.25,0),i(new ue(t*1.27,22,12,-.3,.6,0,Math.PI*.55),cn(14163754,.2),0,-t*.25,0),i(new pe(t*1.2,t*.35,t*.1),cn(1120810,.05,.3),0,t*.25,t*1.05);else if(n==="coroa"){let s=cn(16762173,.3,.6,{emissive:3810304});i(new Vt(t*.82,t*.88,t*.42,24,1,!0),s,0,t*.2,0).material.side=Fe;for(let r=0;r<7;r++){let a=r/7*Math.PI*2;i(new Ke(t*.16,t*.42,6),s,Math.cos(a)*t*.82,t*.6,Math.sin(a)*t*.82),i(new ue(t*.1,8,6),cn(r%2?2976767:14753096,.1),Math.cos(a)*t*.86,t*.22,Math.sin(a)*t*.86)}}return e.rotation.x=-.15,e}function vv(n,t){let e=new vt,[i,s,r]=t.eye,a=t.er*1.7,o=r+t.er*.95,c=cn({escuro:1118481,nerd:1710618,aviador:13214282,coracao:16736158}[n],.3,n==="aviador"?.7:.1),l=cn({escuro:328965,nerd:13625599,aviador:3877400,coracao:16752324}[n],.05,.2,{transparent:!0,opacity:n==="nerd"?.35:.85});for(let h of[-1,1])if(n==="coracao"){let u=new ji,f=a*1.1;u.moveTo(0,-f),u.bezierCurveTo(f*1.2,-f*.2,f*.9,f*1,0,f*.45),u.bezierCurveTo(-f*.9,f*1,-f*1.2,-f*.2,0,-f);let d=new Tt(new _s(u,{depth:a*.15,bevelEnabled:!1}),l);d.position.set(h*i,s,o),e.add(d)}else{let u=new Tt(new Vt(a,a,a*.12,20),l);u.rotation.x=Math.PI/2,u.position.set(h*i,s,o),e.add(u),n==="aviador"&&u.scale.set(1,1,1.2);let f=new Tt(new mr(a,a*(n==="nerd"?.22:.13),8,24),c);f.position.set(h*i,s,o),e.add(f)}if(i>a){let h=new Tt(new pe(i*2-a*1.6,a*.18,a*.18),c);h.position.set(0,s+a*.25,o),e.add(h)}return e}function Mv(n,t,e){let i=Gd[n],s=new Qn(He(64,96,c=>{let l=c.createLinearGradient(0,0,0,96);l.addColorStop(0,i),l.addColorStop(1,n==="dourada"?"#b8860b":"#00000088"),c.fillStyle=i,c.fillRect(0,0,64,96),c.fillStyle=l,c.fillRect(0,0,64,96),c.fillStyle="rgba(255,255,255,.85)",c.beginPath(),c.ellipse(32,54,8,7,0,0,7),c.fill();for(let[h,u]of[[-9,-8],[-3,-12],[3,-12],[9,-8]])c.beginPath(),c.ellipse(32+h,54+u,3,3.6,0,0,7),c.fill()}));s.colorSpace=Ee;let r=new on(t*2.3,e*.55,1,6);r.translate(0,-e*.275,0);let a=r.attributes.position;for(let c=0;c<a.count;c++){let l=a.getY(c);a.setX(c,a.getX(c)*(1+-l/e*.6))}let o=new Tt(r,cn(16777215,.6,n==="dourada"?.4:0,{map:s,side:Fe}));return o.castShadow=!0,o}function _c(n,t){n.lookG&&n.lookG.forEach(i=>{i.parent&&i.parent.remove(i),Ar(i)}),n.lookG=[],n.cape=null,n.look=t,n.crown&&(n.crown.visible=t.hat==="none"),n.vestMat.color.set(t.vest==="padrao"?n.b.color:kd[t.vest]),n.vestMat.metalness=t.vest==="dourado"?.7:.15;let e=n.hi;if(t.hat!=="none"){let i=_v(t.hat,e.s);i.position.set(...e.hat),n.head.add(i),n.lookG.push(i)}if(t.glasses!=="none"&&!e.noGlasses){let i=vv(t.glasses,e);n.head.add(i),n.lookG.push(i)}if(t.cape!=="none"){let i=new vt;i.position.set(...e.cape),i.add(Mv(t.cape,e.capeW,e.capeL)),i.rotation.x=1.3,n.body.add(i),n.lookG.push(i),n.cape=i}}var Jo=new Ft;function Ev(n,t){let e=n.look&&n.look.trail,i=Math.hypot(n.vx,n.vz);if(!e||e==="none"||i<6||Math.random()>t*30)return;let s=n.x-Math.sin(n.h)*1.4+(Math.random()-.5)*.8,r=n.z-Math.cos(n.h)*1.4+(Math.random()-.5)*.8,a=.5+n.y+Math.random()*.6;e==="bolhas"?pi.spawn(s,a,r,Math.random()-.5,1.5,Math.random()-.5,1.4,.35,.6,[.65,.88,1],.55,-1.5,1):e==="coracoes"?Un.spawn(s,a,r,0,1.2,0,.9,.45,.25,[1,.3,.6],.9,-.5,1):e==="estrelas"?Un.spawn(s,a,r,(Math.random()-.5)*2,1,(Math.random()-.5)*2,.7,.3,.05,[1,.92,.4],1,0,1):e==="fogo"?Un.spawn(s,.35+n.y,r,0,2.5,0,.45,.6,.15,Math.random()<.5?[1,.45,.1]:[1,.8,.2],1,-2,1):e==="arcoiris"&&(Jo.setHSL((In*.6+Math.random()*.1)%1,.9,.6),Un.spawn(s,a,r,0,.3,0,.8,.5,.35,[Jo.r,Jo.g,Jo.b],.9,0,1))}function Wd(n,t,e){return n.kind==="glb"&&kh[n.model]?bv(n,t,e):n.kind==="lizard"?wv(n,t,e):dv(n,t,e)}var kh={};(function(){let t=window.CAES;if(t)try{let e=atob(t.data),i=new Uint8Array(e.length);for(let a=0;a<e.length;a++)i[a]=e.charCodeAt(a);let s=i.buffer,r=new Ft;for(let a of t.meta){let o=new Int16Array(s,a.p,a.v*3),c=new Uint8Array(s,a.c,a.v*3),l=a.big?new Uint32Array(s,a.x,a.i):new Uint16Array(s,a.x,a.i),h=new Float32Array(a.v*3),u=new Float32Array(a.v*3),f=new Float32Array(a.v*3);for(let N=0;N<a.v;N++){for(let J=0;J<3;J++)h[N*3+J]=a.min[J]+(o[N*3+J]+32767)/65534*a.size[J];r.setRGB(c[N*3]/255,c[N*3+1]/255,c[N*3+2]/255,Ee),u[N*3]=r.r,u[N*3+1]=r.g,u[N*3+2]=r.b,f[N*3]=c[N*3],f[N*3+1]=c[N*3+1],f[N*3+2]=c[N*3+2]}let[d,p,x]=a.size,g=a.min[2]+x/2,m=p,S=0,y=0,b=-1e9,C=1e9;for(let N=0;N<a.v;N++){let J=h[N*3+2];J>b&&(b=J),J<C&&(C=J)}for(let N=0;N<a.v;N++){let J=h[N*3],P=h[N*3+1],O=h[N*3+2];Math.abs(O-g)<x*.12&&P>S&&(S=P),Math.abs(O-g)<x*.05&&Math.abs(J)<d*.3&&P<m&&P>p*.12&&(m=P),O>b-x*.22&&P>y&&(y=P)}let A=m+p*.04,w=new Float32Array(a.v),F=new Float32Array(a.v),E=[0,0,0,0],M=[0,0,0,0];for(let N=0;N<a.v;N++){let J=h[N*3],P=h[N*3+1],O=h[N*3+2],z=(O>g?0:2)+(J>0?1:0);w[N]=z,F[N]=P<A?Nt(A,A*.78,P):0,P<A&&P>A*.75&&(E[z]+=O,M[z]++)}for(let N=0;N<4;N++)E[N]=M[N]?E[N]/M[N]:g+(N<2?x*.3:-x*.3);let I=new Pe;I.setAttribute("position",new fe(h,3)),I.setAttribute("color",new fe(u,3)),I.setAttribute("legG",new fe(w,1)),I.setAttribute("legW",new fe(F,1)),I.setIndex(new fe(a.big?new Uint32Array(l):new Uint16Array(l),1)),I.computeVertexNormals(),I.computeBoundingSphere(),I.userData.keep=!0,kh[a.n]={geo:I,W:d,H:p,L:x,zc:g,zmin:C,zmax:b,belly:m,back:S,headTop:y,legTop:A,pivots:E,raw8:f,idx:l}}}catch(e){console.warn("modelos .glb n\xE3o carregados",e)}})();function Sv(){let n={uAng:{value:new Ge},uPiv:{value:new Ge},uTop:{value:0}},t=new te({vertexColors:!0,flatShading:!0,roughness:.82});return t.onBeforeCompile=e=>{Object.assign(e.uniforms,n),e.vertexShader=`attribute float legG; attribute float legW; uniform vec4 uAng; uniform vec4 uPiv; uniform float uTop;
`+e.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
        if (legW > 0.0) {
          float a = (legG < 0.5 ? uAng.x : legG < 1.5 ? uAng.y : legG < 2.5 ? uAng.z : uAng.w) * legW;
          float pz = legG < 0.5 ? uPiv.x : legG < 1.5 ? uPiv.y : legG < 2.5 ? uPiv.z : uPiv.w;
          float dy = transformed.y - uTop, dz = transformed.z - pz, c = cos(a), s = sin(a);
          transformed.y = uTop + dy * c - dz * s; transformed.z = pz + dy * s + dz * c;
        }`)},t.userData.u=n,t}function bv(n,t,e){let i=kh[n.model],s=new vt,r=new vt,a=new vt;s.add(r),r.add(a);let o=Sv();o.userData.u.uTop.value=i.legTop,o.userData.u.uPiv.value.set(...i.pivots);let c=null;if(n.prop){let w=i.geo.attributes.position,F=i.idx,E=[],M=[],I=new L,N=0,J=P=>{let O=i.raw8[P*3],z=i.raw8[P*3+1],Q=i.raw8[P*3+2];return w.getZ(P)>i.zmax-i.L*.22&&Math.abs(O-z)<18&&Math.abs(z-Q)<18&&O>110};for(let P=0;P<F.length;P+=3){let O=F[P],z=F[P+1],Q=F[P+2];if(J(O)&&J(z)&&J(Q)){M.push(O,z,Q);for(let j of[O,z,Q])I.x+=w.getX(j),I.y+=w.getY(j),I.z+=w.getZ(j),N++}else E.push(O,z,Q)}if(M.length){I.divideScalar(N);let P=i.geo.clone();P.setIndex(E),P.userData.keep=!1;let O=i.geo.clone();O.setIndex(M),O.translate(-I.x,-I.y,-I.z),O.userData.keep=!1;let z=new Tt(P,o);z.castShadow=!0,a.add(z),c=new vt,c.position.copy(I),a.add(c);let Q=new Tt(O,o);c.add(Q)}}if(!c){let w=new Tt(i.geo,o);w.castShadow=!0,a.add(w)}let l=new vt;l.position.set(0,i.headTop-i.H*.08,i.zmax-i.L*.1),a.add(l);let h=i.L/1.9,u=(n.fly,i.back),f=n.fly?i.zc-i.L*.22:i.zc-i.L*.05,d=new te({color:e,roughness:.45,metalness:.15}),p=n.fly?i.H*.62:i.belly+(i.back-i.belly)*.92,x=new Tt(new ue(1,20,8,0,Math.PI*2,0,Math.PI/2),d);x.scale.set(i.W*(n.fly?.3:.55),.06*h,i.L*.16),x.position.set(0,p,f),x.castShadow=!0,a.add(x);let g=new te({map:zh(t,e),transparent:!0,roughness:.5,side:Fe});for(let w of[-1,1]){let F=new Tt(new on(.2*h,.2*h),g);F.position.set(w*(i.W*(n.fly?.3:.55)+.01),p-.02,f),F.rotation.y=w*Math.PI/2,a.add(F)}let{flames:m,launcher:S}=Hh(a,p+.02,f,2.3*h*.9),y=new vt;y.position.set(0,.35*h,0),l.add(y);for(let w=0;w<4;w++){let F=new Tt(new pr(.06),xc);F.position.set(Math.cos(w*1.57)*.22,0,Math.sin(w*1.57)*.22),y.add(F)}y.visible=!1;let b=new gs(new Ki({map:Ca,depthTest:!1}));b.scale.set(.3,.3,1),b.position.set(0,.55*h,0),b.visible=!1,l.add(b);let C=new Tt(new on(1,1),new Cn({map:Ea,transparent:!0,depthWrite:!1}));C.rotation.x=-Math.PI/2,C.position.y=.04,C.scale.set(i.W*2.2,i.L*1.3,1),s.add(C);let A={hat:[0,.1*h,-.02],s:.17*h,eye:[.08,0,.1],er:.03,cape:[0,i.back-.02,i.zc+i.L*.25],capeW:i.W*.4,capeL:i.L*.85,noGlasses:!0};return{root:s,model:r,body:a,torso:a,neckPiv:l,headPiv:l,head:l,legs:[],tails:[],ears:[],tongue:new vt,flames:m,stars:y,excl:b,blob:C,b:n,launcher:S,anim:Tv,vestMat:d,hi:A,crown:null,mat:o,prop:c,G:i}}function Tv(n,t,e){let i=n.b,s=n.mat.userData.u.uAng.value,r=le(t.v/12,0,1),a=t.y>.05;if(i.fly)s.set(0,0,0,0),n.body.position.y=.55+Math.sin(e*2.2)*.12,n.body.rotation.x=-r*.08+Math.sin(e*1.7)*.03,n.prop&&(n.prop.rotation.z+=.4+r*.9);else{let o=t.phase,c=.62*r;a?s.set(-.75,-.75,.8,.8):s.set(Math.sin(o)*c,Math.sin(o+.55)*c,Math.sin(o+Math.PI+.2)*c,Math.sin(o+Math.PI+.75)*c),n.body.position.y=a?0:Math.abs(Math.cos(o))*.06*r+(t.idle?Math.sin(e*3.5)*.008:0),n.body.rotation.x=a?le(-t.vy*.03,-.3,.3):Math.sin(o*2)*.035*r,n.body.rotation.y=t.idle?Math.sin(e*.7)*.08:0}n.model.rotation.z=le(-t.yawRate*(i.fly?.3:.16),-.4,.4)+(t.stun>0?Math.sin(e*18)*.15:0),Xd(n,t,e)}function wv(n,t,e){let i=new vt,s=new vt,r=new vt;i.add(s),s.add(r);let a=new te({vertexColors:!0,map:Hd,roughness:n.coat==="tegu"?.42:.6}),o=[],c=(nt,ct,gt,R={},rt=a)=>{let Y=new Tt(nt,rt);return Y.userData={part:gt,...R},Y.castShadow=!0,ct.add(Y),rt===a&&o.push(Y),Y},l=n.len,h=n.chW,u=n.chH,f=n.backY,d=c(Pn(26,20,(nt,ct)=>{let gt=As(nt,2.2),R=Math.sin(ct);return[Math.cos(ct)*h*gt*(1-.15*Ts(nt,.1,.15)),R*u*gt*(R<0?.8:1),(nt-.5)*l]}),r,"body");d.position.y=f;let[p,x,g]=n.headL,m=new vt;m.position.set(0,f+u*.15,l/2-.03),r.add(m);let S=m;c(Pn(8,16,(nt,ct)=>{let gt=Ve(h*.8,x*.95,nt),R=Ve(u*.8,g*.95,nt);return[Math.cos(ct)*gt,Math.sin(ct)*R,-.05+nt*.09]}),m,"neck");let y=new vt;y.position.set(0,0,.04+p*.3),m.add(y),c(Pn(24,18,(nt,ct)=>{let gt=-p*.3+nt*p*1.3,R=Math.pow(Math.max(0,1-Math.pow(Math.abs(2*nt-1),3)),1/3),rt=x*(1-.45*nt*nt)*R,Y=g*(1-.3*nt)*R,tt=Math.sin(ct);return[Math.cos(ct)*rt,-g*.15*nt+tt*Y*(tt<0?.75:1),gt]}),y,"head");let b=new te({color:n.eye,roughness:.05});for(let nt of[-1,1]){let ct=new Tt(new ue(n.eyeR,14,10),b);ct.position.set(nt*x*.8,g*.42,p*.12),y.add(ct);let gt=new Tt(new ue(n.eyeR*1.15,12,6,0,Math.PI*2,0,Math.PI*.35),a);gt.position.copy(ct.position),gt.rotation.z=-nt*.5,gt.userData={part:"head"},y.add(gt),o.push(gt)}let C=new vt;C.position.set(0,-g*.35,p*.95),y.add(C);let A=new te({color:n.forked?7172019:14711434,roughness:.4}),w=new Tt(new Vt(.004,.005,.07,6),A);if(w.rotation.x=Math.PI/2,w.position.z=.035,C.add(w),n.forked)for(let nt of[-1,1]){let ct=new Tt(new Vt(.0025,.0035,.03,5),A);ct.rotation.set(Math.PI/2,0,nt*.4),ct.position.set(nt*.006,0,.08),C.add(ct)}C.visible=!1;let F=[],E=n.bone,M=Math.PI/2-.18;for(let nt of[{f:1,sx:-1,off:0},{f:1,sx:1,off:Math.PI},{f:0,sx:-1,off:Math.PI},{f:0,sx:1,off:0}]){let ct=new vt;ct.position.set(nt.sx*h*.78,f-u*.2,(nt.f?1:-1)*l*.3),r.add(ct);let gt=new vt;gt.rotation.z=nt.sx*M,ct.add(gt);let R=n.legU;c(ga(R,E*1.7,E*1.15,1.1),gt,"leg",{front:nt.f,seg:0});let rt=new vt;rt.position.y=-R,rt.rotation.z=nt.sx*(.12-M),gt.add(rt);let Y=Math.max(.025,f-u*.2-R*Math.sin(Math.PI/2-M)-E*.5);c(ga(Y,E*1.15,E*.85),rt,"leg",{front:nt.f,seg:1});let tt=new vt;tt.position.y=-Y,tt.rotation.z=-nt.sx*.12,rt.add(tt);let q=c(Ii(E*1.3,E*.5,E*1.2),tt,"paw",{front:nt.f});for(let Ct=0;Ct<5;Ct++){let yt=(Ct-2)*.42+(nt.f?.15:-.1)*-nt.sx,v=c(Ii(E*.32,E*.28,E*1.15),tt,"paw",{front:nt.f});v.position.set(Math.sin(yt)*E*1.5,0,Math.cos(yt)*E*1.5),v.rotation.y=yt,n.coat==="gecko"&&c(new ue(E*.42,8,6),tt,"paw",{front:nt.f}).position.set(Math.sin(yt)*E*2.5,0,Math.cos(yt)*E*2.5)}F.push({yaw:ct,out:gt,knee:rt,paw:q,front:nt.f,sx:nt.sx,off:nt.off,rest:gt.rotation.z})}let I=[],N=7,J=n.tailL/N,P=new vt;P.position.set(0,f,-l/2+.03),r.add(P);for(let nt=0;nt<N;nt++){let ct=n.tailR*(1-nt/N*.88),gt=n.tailR*(1-(nt+1)/N*.88),R=Pn(6,12,(Y,tt)=>{let q=Ve(ct,gt,Y)*As(Y,3);return[Math.cos(tt)*q*1.1,Math.sin(tt)*q*.85,-ct*.6+Y*(J+ct*1.2)]});R.rotateY(Math.PI);let rt=new vt;rt.position.z=nt?-J:0,P.add(rt),c(R,rt,"tail",{seg:nt}),rt.rotation.x=nt?.05:-.28,I.push(rt),P=rt}let O=new te({color:e,roughness:.45,metalness:.15}),z=new Tt(new ue(1,22,10,0,Math.PI*2,0,Math.PI/2),O);z.scale.set(h*1.05,u*.45,l*.26),z.position.set(0,f+u*.7,0),z.castShadow=!0,r.add(z);let Q=new te({map:zh(t,e),transparent:!0,roughness:.5,side:Fe});for(let nt of[-1,1]){let ct=new Tt(new on(.075,.075),Q);ct.position.set(nt*(h*.98+.004),f+u*.2,0),ct.rotation.y=nt*Math.PI/2,r.add(ct)}let{flames:j,launcher:K}=Hh(r,f+u+.005,-.01,n.gearS||1),st=new vt;st.position.set(0,g*3,0),y.add(st);for(let nt=0;nt<4;nt++){let ct=new Tt(new pr(.02),xc);ct.position.set(Math.cos(nt*1.57)*.07,0,Math.sin(nt*1.57)*.07),st.add(ct)}st.visible=!1;let it=new gs(new Ki({map:Ca,depthTest:!1}));it.scale.set(.11,.11,1),it.position.set(0,g*4.2,0),it.visible=!1,y.add(it),s.updateMatrixWorld(!0);let xt=new Hn;for(let nt of F)xt.setFromObject(nt.paw),nt.yaw.position.y-=xt.min.y;s.updateMatrixWorld(!0);let $=[];if(n.coat==="gecko")for(let nt=0;nt<420;nt++)$.push([Ut(-.12,.12),Ut(.02,.2),Ut(-.7,.45),Ut(.006,.013)]);let et=new L,ut=new Ft;for(let nt of o){let ct=nt.geometry.attributes.position,gt=new Float32Array(ct.count*3);for(let R=0;R<ct.count;R++){et.fromBufferAttribute(ct,R);let rt=et.x,Y=et.y,tt=et.z;et.applyMatrix4(nt.matrixWorld),Nd(n,{part:nt.userData.part,front:nt.userData.front,seg:nt.userData.seg,zStop:0,lx:rt,ly:Y,lz:tt,x:et.x,y:et.y,z:et.z,cy:f,spots:$},ut);let q=.92+.16*Ni(et.x*60+et.z*23,et.y*60,0,3);gt[R*3]=ut.r*q,gt[R*3+1]=ut.g*q,gt[R*3+2]=ut.b*q}nt.geometry.setAttribute("color",new fe(gt,3))}let Lt=Qo*(n.scale||1);s.scale.setScalar(Lt);let St=new Tt(new on(1,1),new Cn({map:Ea,transparent:!0,depthWrite:!1}));St.rotation.x=-Math.PI/2,St.position.y=.04,St.scale.set(h*6*Lt,(l+n.tailL*.6)*1.3*Lt,1),i.add(St);let Bt={hat:[0,g*.92,p*.02],s:x*.85,eye:[x*.8,g*.42,p*.12],er:n.eyeR,cape:[0,f+u*.95,l*.28],capeW:h,capeL:l};return{root:i,model:s,body:r,torso:d,neckPiv:m,headPiv:S,head:y,legs:F,tails:I,ears:[],tongue:C,flames:j,stars:st,excl:it,blob:St,b:n,launcher:K,anim:Av,vestMat:O,hi:Bt,crown:null}}function Xd(n,t,e){for(let i of n.flames)i.visible=t.nitro,t.nitro&&i.scale.set(1,.7+Math.random()*.6,1);n.stars.visible=t.stun>0,t.stun>0&&(n.stars.rotation.y=e*7),n.excl.visible=t.spook>0,n.blob.material.opacity=1/(1+t.y*.6),n.cape&&(n.cape.rotation.x=1.3+le(t.v/14,0,1)*.35+Math.sin(e*13)*.06*le(t.v/14,0,1))}function Av(n,t,e){let i=le(t.v/10,0,1),s=t.y>.05,r=t.phase*1.25;for(let c of n.legs){if(s){c.yaw.rotation.y=(c.front?.7:-.7)*-c.sx,c.out.rotation.z=c.rest+c.sx*.35;continue}let l=r+c.off;c.yaw.rotation.y=-c.sx*Math.sin(l)*.65*i,c.out.rotation.z=c.rest+c.sx*Math.max(0,Math.cos(l))*.35*i}let a=i>.05?i:.25;n.body.rotation.y=Math.sin(r)*.13*i,n.body.position.y=t.idle?Math.max(0,Math.sin(e*2.6))*.018:i*.015,n.neckPiv.rotation.y=-Math.sin(r)*.18*i+(t.idle?Math.sin(e*.8)*.35:le(-t.yawRate*.2,-.4,.4)),n.neckPiv.rotation.x=s?-.2:t.idle?-Math.max(0,Math.sin(e*2.6))*.12:0,n.tails.forEach((c,l)=>{c.rotation.y=Math.sin((i>.05?r:e*1.4)-l*.8)*(.2+.05*l)*a,l===0&&(c.rotation.x=s?.1:-.28)});let o=n.b.forked?Math.sin(e*2.3+n.b.len*10)>.9:Math.sin(e*1.3)>.97;n.tongue.visible=o,o&&(n.tongue.scale.z=.6+Math.abs(Math.sin(e*30))*.6),n.model.rotation.z=le(-t.yawRate*.1,-.2,.2)+(t.stun>0?Math.sin(e*18)*.15:0),Xd(n,t,e)}function Rv(n,t,e){let i=n.b,s=le(t.v/12,0,1),r=t.y>.05;for(let o of n.legs){let c=t.phase+o.off,l=Math.sin(c),h=Math.max(0,-Math.cos(c)),u=o.rh,f=o.rk,d=o.ra;r?o.front?(u=-.8,f=.1,d=-.1):(u=.9,f=.2,d=-.3):s>.01&&(o.front?(u+=l*.8*s,f+=(h*1.2-.1)*s,d+=h*.9*s):(u+=l*.75*s,f+=h*.7*s,d-=h*.8*s)),o.hip.rotation.x=u,o.knee.rotation.x=f,o.ank.rotation.x=d}n.body.position.y=s*.035*Math.cos(t.phase)*(r?0:1),n.body.rotation.x=s*.06*Math.sin(t.phase+.8)+(r?le(-t.vy*.03,-.35,.35):0),n.model.rotation.z=le(-t.yawRate*.16,-.32,.32)+(t.stun>0?Math.sin(e*18)*.15:0),n.neckPiv.rotation.x=-i.neckA+.28*s+Math.sin(t.phase)*.07*s,n.headPiv.rotation.x=i.neckA-.12+(i.headDown||0)-.22*s,n.head.rotation.y=le(-t.yawRate*.22,-.45,.45)+(t.idle?Math.sin(e*.7)*.35:0);for(let o of n.ears)o.type==="erect"||o.type==="fold"||o.type==="round"?o.piv.rotation.x=o.rx-.5*s+(t.idle?Math.max(0,Math.sin(e*3+o.sx))*.1:0):o.piv.rotation.x=o.rx+.9*s+Math.sin(t.phase*2)*.18*s;let a=1-s*.75;n.tails.forEach((o,c)=>{o.rotation.y=Math.sin(e*11-c*.6)*(c?.2:.45)*a,c===0&&(o.rotation.x=Ve(i.tail[2],-.2,s*.6)+Math.sin(t.phase)*.1*s)}),n.tongue.visible=!i.noTongue&&(t.v>6||t.idle),n.tongue.rotation.x=Math.sin(t.phase*2)*.25*s+(t.idle?Math.sin(e*9)*.1:0),n.torso.scale.y=1+Math.sin(e*(t.v>1?9:3.5))*.012;for(let o of n.flames)o.visible=t.nitro,t.nitro&&o.scale.set(1,.7+Math.random()*.6,1);n.stars.visible=t.stun>0,t.stun>0&&(n.stars.rotation.y=e*7),n.excl.visible=t.spook>0,n.blob.material.opacity=1/(1+t.y*.6),n.cape&&(n.cape.rotation.x=1.3+le(t.v/14,0,1)*.35+Math.sin(e*13)*.06*le(t.v/14,0,1))}var Us=[{id:"parque",name:"PARQUE CENTRAL",W:18,grip:1,hills:55,surface:"dirt",ground:[92,138,58],trees:"broad",puddle:"mud",ctrl:[[0,-130],[90,-140],[165,-105],[185,-30],[140,25],[150,100],[95,160],[0,150],[-55,105],[-120,140],[-180,85],[-170,0],[-115,-60],[-80,-120]],sky:{zen:2976720,hor:12376047,gnd:7043676,sun:16773336,dir:[.45,.62,.3],haze:.5},fog:[12376047,180,900],light:{sun:3.2,col:16773854,hemi:.35},rail:16053492,curb:["#d62828","#ffffff"],stand:[10133931,3039156],mtn:[5334079,7168597]},{id:"praia",name:"PRAIA DO LATIDO",W:18,grip:.9,hills:14,surface:"sand",ground:[226,204,158],trees:"palm",puddle:"water",sea:-128,ctrl:[[-200,-40],[-120,-90],[0,-100],[120,-95],[200,-60],[230,10],[190,70],[110,80],[60,40],[0,50],[-50,110],[-130,120],[-210,60]],sky:{zen:2964358,hor:16753768,gnd:9071192,sun:16756848,dir:[.2,.09,-.97],haze:1.3},fog:[15770748,160,850],light:{sun:2.8,col:16758405,hemi:.3},rail:9132587,curb:["#1e88e5","#ffffff"],stand:[12028762,1019816],mtn:[8022610,6253386]},{id:"neve",name:"PICO NEVADO",W:18,grip:.78,hills:80,surface:"snow",ground:[236,241,248],trees:"pine",puddle:"ice",snow:!0,ctrl:[[0,-150],[100,-160],[170,-110],[150,-40],[200,20],[180,110],[100,150],[40,100],[-20,140],[-110,150],[-170,90],[-130,30],[-190,-40],[-120,-120]],sky:{zen:6260408,hor:14542834,gnd:13621474,sun:16774890,dir:[-.4,.42,.5],haze:.8},fog:[14542834,110,620],light:{sun:2.4,col:15922943,hemi:.5},rail:13840175,curb:["#d32f2f","#ffffff"],stand:[9268835,12000284],mtn:[5923954,7173508]}],_t=Us[0],It=18,ve=1,Ye=1400,$e=[],ni=[],Ls=[],ws=[];function Cv(n){let t=new ca(n.ctrl.map(e=>new L(e[0],0,e[1])),!0,"centripetal");ve=t.getLength(),$e.length=ni.length=Ls.length=ws.length=0;for(let e=0;e<Ye;e++){let i=e/Ye,s=t.getPointAt(i),r=t.getTangentAt(i);r.y=0,r.normalize(),$e.push(s),ni.push(r),Ls.push(new L(-r.z,0,r.x)),e%6===0&&ws.push(s)}}var vc=n=>(n%ve+ve)%ve,dn=n=>(n=vc(n),n>ve/2?n-ve:n),_d=new L,Ko=new L,vd=new L;function Ir(n){let t=vc(n)/ve*Ye,e=Math.floor(t)%Ye,i=(e+1)%Ye,s=t-Math.floor(t);return _d.copy($e[e]).lerp($e[i],s),Ko.copy(ni[e]).lerp(ni[i],s).normalize(),vd.set(-Ko.z,0,Ko.x),{p:_d,t:Ko,r:vd}}function ze(n,t,e=0){let i=Ir(n);return new L(i.p.x+i.r.x*t,e,i.p.z+i.r.z*t)}function ii(n){let t=Ir(n);return Math.atan2(t.t.x,t.t.z)}function Gh(n,t){let e=!1;for(let i=0,s=ws.length-1;i<ws.length;s=i++){let r=ws[i],a=ws[s];r.z>t!=a.z>t&&n<(a.x-r.x)*(t-r.z)/(a.z-r.z)+r.x&&(e=!e)}return e}function Mc(n,t){let e=1/0;for(let i of ws){let s=i.x-n,r=i.z-t,a=s*s+r*r;a<e&&(e=a)}return Math.sqrt(e)}function Mn(n,t){let e=Mc(n,t);if(_t.sea!==void 0&&t<_t.sea)return Math.max(-7,-(_t.sea-t)*.09)*Nt(It/2+6,It/2+22,e);let i=Nt(It/2+16,It/2+110,e)*Nt(70,150,Math.hypot(n-$e[0].x,t-$e[0].z));return i<=0||Gh(n,t)?0:i*Math.max(0,Li(n*.004+31,t*.004+17,4)-.3)*_t.hills}var Le=null,Vh=[],Wh=[],xa=null,cc=null,Xh=[],Di=null,br=null,Qi=[],_h=[],lc=[],hc=[],Tr=[],Sa=[],wr=[],vh=null,ya=null,pt=(n,t=.85,e=0,i={})=>new te({color:n,roughness:t,metalness:e,...i});function At(n,t,e=!0,i=!0,s=Le){let r=new Tt(n,t);return r.castShadow=e,r.receiveShadow=i,s.add(r),r}function Sn(n,t,e,i=!0){let s=new No(n,t,e);return s.castShadow=i,s.receiveShadow=!0,s.frustumCulled=!1,Le.add(s),s}var Md=new Ae,Ed=new li,Pv=new hr,ne=new L,Lv=new L;function bn(n,t,e,i,s,r,a,o,c,l,h){Ed.setFromEuler(Pv.set(r,a,o)),Md.compose(ne.set(e,i,s),Ed,Lv.set(c,l??c,h??c)),n.setMatrixAt(t,Md)}function Ar(n){n.traverse(t=>{t.geometry&&!t.geometry.userData.keep&&t.geometry.dispose(),t.material&&[].concat(t.material).forEach(e=>{if(!yh.has(e)){for(let i of["map","bumpMap","normalMap","emissiveMap"])e[i]&&!yh.has(e[i])&&e[i].dispose();e.dispose()}})})}function pa(n,t,e,i,s,r=!0){let a=[],o=[],c=[];for(let h=0;h<=Ye;h++){let u=h%Ye,f=$e[u],d=Ls[u];a.push(f.x+d.x*n,e,f.z+d.z*n,f.x+d.x*t,e,f.z+d.z*t);let p=h/Ye*ve/i;if(o.push(0,p,1,p),h<Ye){let x=h*2;c.push(x,x+1,x+2,x+1,x+3,x+2)}}let l=new Pe;return l.setAttribute("position",new he(a,3)),l.setAttribute("uv",new he(o,2)),l.setIndex(c),l.computeVertexNormals(),At(l,s,!1,r)}function Sd(n,t,e,i){let s=[],r=[];for(let c=0;c<=Ye;c+=2){let l=c%Ye,h=$e[l],u=Ls[l];s.push(h.x+u.x*n,t,h.z+u.z*n,h.x+u.x*n,e,h.z+u.z*n)}let a=s.length/6;for(let c=0;c<a-1;c++){let l=c*2;r.push(l,l+2,l+1,l+1,l+2,l+3)}let o=new Pe;o.setAttribute("position",new he(s,3)),o.setIndex(r),o.computeVertexNormals(),At(o,i,!0,!0)}function Iv(n){let e=Us.indexOf(_t)*13,i=Oh(256,(r,a)=>{let o=Li(r/32,a/32,5,8,e),c=Li(r/8,a/8,3,32,e+5),l=vr(r,a,e+9),h=1-.07*Ts(r/256,.33,.07)-.07*Ts(r/256,.67,.07);if(n==="dirt"){let d=132+o*70+c*18,p=90+o*50+c*14,x=56+o*32+c*8;return l>.985?(d+=40,p+=36,x+=30):l<.012&&(d-=40,p-=34,x-=24),[d*h,p*h,x*h]}if(n==="sand"){let d=Math.sin(a*.45+o*9)*7;return[(178+o*30+d)*h,(146+o*26+d)*h,(102+o*20+d*.6)*h]}let u=l>.992?20:0,f=1-.1*Ts(r/256,.25,.05)-.1*Ts(r/256,.75,.05);return[(158+o*34+u)*h*f,(172+o*26+u)*h*f,(196+o*16+u)*h*f]}),s=i.getContext("2d");for(let r=0;r<70;r++){let a=30+Yt()*196,o=Yt()*256,c=Yt()*.4-.2;s.save(),s.translate(a,o),s.rotate(c),s.fillStyle=n==="snow"?"rgba(120,140,170,.22)":"rgba(40,24,10,.22)",s.beginPath(),s.ellipse(0,4,4,3.5,0,0,7),s.fill();for(let[l,h]of[[-4,-2],[-1.4,-4.5],[1.4,-4.5],[4,-2]])s.beginPath(),s.ellipse(l,h,1.5,1.8,0,0,7),s.fill();s.restore()}return i}function Dv(){let[n,t,e]=_t.ground,i=Us.indexOf(_t)*7+3,s=Oh(256,(r,a)=>{let o=Li(r/16,a/16,4,16,i),c=vr(r,a,i),l=.78+o*.4+(c-.5)*(_t.ground[0]<150?.22:.08);return[n*l,t*l,e*l]});if(_t.trees==="broad"){let r=s.getContext("2d");for(let a=0;a<2600;a++){let o=Yt()*256,c=Yt()*256,l=110+Yt()*90|0;r.strokeStyle=`rgba(${l*.55|0},${l},${l*.35|0},.5)`,r.lineWidth=1,r.beginPath(),r.moveTo(o,c),r.lineTo(o+Yt()*2-1,c-2-Yt()*3),r.stroke()}}return s}function Yh(n){Le&&(sn.remove(Le),Ar(Le)),pi.clear(),Un.clear(),_t=Us[n],It=_t.W,jo=1e3+n*77,Cv(_t),Le=new vt,sn.add(Le),wr=[],Vh=[],Wh=[],Xh=[];let t=_t.sky;Ss.zen.value.setHex(t.zen),Ss.hor.value.setHex(t.hor),Ss.gnd.value.setHex(t.gnd),Ss.sunCol.value.setHex(t.sun),mh.set(...t.dir).normalize(),Ss.sunDir.value.copy(mh),Ss.haze.value=t.haze,sn.fog=new Io(_t.fog[0],_t.fog[1],_t.fog[2]),En.color.setHex(_t.light.col),En.intensity=_t.light.sun,sc.color.setHex(t.hor),sc.groundColor.setHex(t.gnd),fv(),Uv(),Nv(),Ov(),Fv(),zv(),Hv(),kv(),Vv(),Wv(),Xv(),Yv(),Zv(),Jv(),Qv(),fM(),tM(),Di&&(sn.remove(Di),Di.geometry.dispose(),Di=null),_t.snow&&$v()}function Uv(){let t=H.qual===0?100:150,e=new on(1700,1700,t,t);e.rotateX(-Math.PI/2);let i=e.attributes.position,s=e.attributes.uv,r=new Float32Array(i.count*3);for(let c=0;c<i.count;c++){let l=i.getX(c),h=i.getZ(c),u=Mn(l,h);i.setY(c,u),s.setXY(c,l/9,h/9);let f=.82+.36*Li(l*.012,h*.012,3,0,5),d=f,p=f,x=f;if(_t.id==="parque"){let g=Nt(.55,.75,Li(l*.006+5,h*.006,3));d+=g*.25,x-=g*.1}if(_t.id==="praia"&&u<-.3&&(d*=.8,p*=.78,x*=.72),_t.id==="neve"&&u>20){let g=Nt(.62,.72,Li(l*.03,h*.03,2));d-=g*.45,p-=g*.42,x-=g*.38}r[c*3]=d,r[c*3+1]=p,r[c*3+2]=x}e.setAttribute("color",new fe(r,3)),e.computeVertexNormals();let a=rn(Dv());At(e,new te({map:a,vertexColors:!0,roughness:_t.id==="neve"?.7:1}),!1,!0);let o=At(new on(9e3,9e3),new te({color:new Ft(`rgb(${_t.ground.join(",")})`).multiplyScalar(.8),roughness:1}),!1,!1);if(o.rotation.x=-Math.PI/2,o.position.y=_t.sea!==void 0?-8:-.4,br=null,_t.sea!==void 0){let c=Oh(128,(h,u)=>{let f=(x,g)=>Li(x/16,g/16,3,8,77),d=f(h+1,u)-f(h-1,u),p=f(h,u+1)-f(h,u-1);return[128-d*400,128-p*400,255]});br=rn(c,40,40,!1);let l=At(new on(4e3,4e3),new te({color:1007490,roughness:.12,metalness:.1,normalMap:br,normalScale:new ht(.6,.6)}),!1,!1);l.rotation.x=-Math.PI/2,l.position.set(0,-1.1,-1400)}}function Nv(){let n=Iv(_t.surface),t=rn(n),e=_t.surface==="snow"?.55:.95;pa(-It/2,It/2,.03,It,new te({map:t,bumpMap:rn(n,1,1,!1),bumpScale:1.2,roughness:e}));let i=rn(He(4,8,a=>{a.fillStyle=_t.curb[0],a.fillRect(0,0,4,4),a.fillStyle=_t.curb[1],a.fillRect(0,4,4,4)}));i.magFilter=nn;let s=new te({map:i,roughness:.6});pa(-It/2-1.3,-It/2,.05,6,s),pa(It/2,It/2+1.3,.05,6,s);let r=new te({map:t,roughness:1,color:13619151});pa(-It/2-2.6,-It/2-1.3,.035,It,r),pa(It/2+1.3,It/2+2.6,.035,It,r)}function Ov(){let n=_t.id==="praia",t=pt(_t.rail,n?.9:.35,n?0:.3,{side:Fe});for(let r of[-1,1])Sd(r*(It/2+2.6),.95,1.12,t),Sd(r*(It/2+2.6),.45,.58,t);let e=Math.floor(ve/4)*2,i=Sn(new Vt(.08,.1,1.25,5),pt(n?7029795:14606046,.5,n?0:.6),e),s=0;for(let r=0;r<ve-2&&s<e-1;r+=4)for(let a of[-1,1]){let o=ze(r,a*(It/2+2.6));bn(i,s++,o.x,.62,o.z,0,0,0,1)}i.count=s}function Fv(){let n=rn(He(16,4,o=>{for(let c=0;c<16;c++)for(let l=0;l<4;l++)o.fillStyle=(c+l)%2?"#111":"#f4f4f4",o.fillRect(c,l,1,1)}));n.magFilter=nn;let t=new Tt(new on(It,2.4),pt(16777215,.6,0,{map:n}));t.rotation.x=-Math.PI/2,t.receiveShadow=!0;let e=new vt;e.add(t),e.position.copy(ze(0,0,.06)),e.rotation.y=ii(0),Le.add(e);let i=new vt,s=pt(2830134,.35,.8);for(let o of[-1,1])At(new pe(.9,11,.9),s,!0,!0,i).position.set(o*(It/2+3.2),5.5,0),At(new pe(1.8,.6,1.8),pt(5593958,.6,.4),!0,!0,i).position.set(o*(It/2+3.2),.3,0);let r=rn(He(512,64,(o,c,l)=>{let h=o.createLinearGradient(0,0,0,l);h.addColorStop(0,"#1a1f2b"),h.addColorStop(1,"#0c0f16"),o.fillStyle=h,o.fillRect(0,0,c,l),o.fillStyle="#ff7a1a",o.fillRect(0,0,c,4),o.fillRect(0,l-4,c,4),o.font="italic 900 38px Arial",o.textAlign="center",o.textBaseline="middle",o.fillStyle="#fff",o.fillText(`LARGADA \xB7 ${_t.name}`,c/2,l/2+2)})),a=pt(16777215,.4,0,{map:r,emissive:16777215,emissiveMap:r,emissiveIntensity:.35});At(new pe(It+7.3,2.2,.6),[s,s,s,s,a,a],!0,!0,i).position.set(0,10,0);for(let o=0;o<3;o++){let c=new te({color:2230280,emissive:0,roughness:.3});At(new ue(.42,16,12),c,!1,!1,i).position.set((o-1)*1.2,8.2,-.3),At(new pe(1.05,1.05,.5),s,!1,!1,i).position.set((o-1)*1.2,8.2,.05),Vh.push(c)}i.position.copy(ze(0,0)),i.rotation.y=ii(0),Le.add(i)}function Mh(n,t){Vh.forEach((e,i)=>{let s=t||i<n,r=s?t?1113952:16719904:2230280;e.color.setHex(r),e.emissive.setHex(s?r:0),e.emissiveIntensity=s?2.2:0})}function $h(){return Gh($e[0].x+Ls[0].x*30,$e[0].z+Ls[0].z*30)?-1:1}function zv(){let n=$h(),t=new pe(1,1,1),e={concrete:[],seat:[],roof:[],pillar:[]},i=[],s=(l,h,u,f,d,p,x,g)=>{let m=ze(h,u,f);l.push([m.x,m.y,m.z,g,d,p,x])};for(let l=-52;l<=52;l+=4){let h=ii(l);for(let u=0;u<7;u++){let f=n*(It/2+7+u*1.6);s(e.concrete,l,f,.4*(u+1),1.7,.8*(u+1),4.02,h),s(e.seat,l,f+n*.3,.8*(u+1)+.12,.5,.25,3.9,h);for(let d of[-1.3,0,1.3]){if(Yt()<.15)continue;let p=Ir(l+d);i.push({x:p.p.x+p.r.x*(f+n*.2),z:p.p.z+p.r.z*(f+n*.2),y:.8*(u+1)+.2,ph:Yt()*6,yaw:h})}}s(e.roof,l,n*(It/2+13),11.5,14,.3,4.05,h),s(e.concrete,l,n*(It/2+19),5.75,.4,11.5,4.05,h),l%16===0&&s(e.pillar,l,n*(It/2+7.2),5.75,.4,11.5,.4,h)}let r={concrete:pt(_t.stand[0],.9),seat:pt(_t.stand[1],.5),roof:pt(15263976,.4,.5),pillar:pt(3817287,.4,.7)};for(let l in e){let h=Sn(t,r[l],e[l].length);e[l].forEach((u,f)=>bn(h,f,u[0],u[1],u[2],0,u[3],0,u[4],u[5],u[6]))}let a=[15022389,2001125,16635957,4431943,16777215,16740419,9315498,44225,2171169],o=[15843965,14724201,9262372,13010498,16767916,7029286];xa=Sn(new Vt(.26,.32,.95,6),pt(16777215,.8),i.length,!1),cc=Sn(new ue(.21,7,5),pt(16777215,.7),i.length,!1);let c=new Ft;i.forEach((l,h)=>{xa.setColorAt(h,c.setHex(a[Yt()*a.length|0])),cc.setColorAt(h,c.setHex(o[Yt()*o.length|0])),Wh.push(l)}),wr.push([$e[0].x,$e[0].z,80])}var ba=.3;function Bv(n){xa&&(Wh.forEach((t,e)=>{let i=Math.max(0,Math.sin(n*8+t.ph))*.4*ba;bn(xa,e,t.x,t.y+.47+i,t.z,0,t.yaw,0,1),bn(cc,e,t.x,t.y+1.15+i,t.z,0,0,0,1)}),xa.instanceMatrix.needsUpdate=cc.instanceMatrix.needsUpdate=!0)}function Hv(){let n=$h();[["RA\xC7\xC3O CROCK","energia para campe\xF5es","#ffcc00","#c62828"],["OSSO DE OURO","o petisco oficial","#101a3a","#ffc53d"],["PET SHOP 2000","tudo para seu c\xE3o","#00a6c8","#ffffff"],["LATIDO FM","97.5 \xB7 a r\xE1dio do auau","#e91e63","#ffffff"],["TURBO DOG","nitro para patas","#111111","#76ff03"],["COLEIRA MAX","aperta sem machucar","#ff8f00","#1a1a1a"],["VET 24H","plant\xE3o veterin\xE1rio","#ffffff","#1565c0"],["PETISCO BOM","sabor bacon","#2e7d32","#ffffff"]].forEach((e,i)=>{let s=ve*(.1+i*.105),r=rn(He(256,128,(p,x,g)=>{p.fillStyle=e[2],p.fillRect(0,0,x,g);let m=p.createLinearGradient(0,0,0,g);m.addColorStop(0,"rgba(255,255,255,.18)"),m.addColorStop(1,"rgba(0,0,0,.18)"),p.fillStyle=m,p.fillRect(0,0,x,g),p.fillStyle=e[3],p.fillRect(0,g-10,x,10),p.font="italic 900 38px Arial",p.textAlign="center",p.fillText(e[0],x/2,62),p.font="600 18px Arial",p.fillText(e[1].toUpperCase(),x/2,94)})),a=new vt,o=pt(2764341,.5,.6);At(new pe(12,6,.35),[o,o,o,o,pt(16777215,.5,0,{map:r}),o],!0,!0,a).position.y=6.5;for(let p of[-4,4])At(new pe(.35,4,.35),o,!0,!0,a).position.set(p,2,0);let c=Ir(s),l=n*(It/2+10),h=c.p.x+c.r.x*l,u=c.p.z+c.r.z*l,f=c.r.x,d=c.r.z;a.position.set(h,Mn(h,u),u),a.rotation.y=Math.atan2(-n*f,-n*d),Le.add(a)})}function Yd(n){let t=[];for(let i=-260;i<=260;i+=12)for(let s=-260;s<=260;s+=12){if(!Gh(i,s))continue;let r=Mc(i,s);r>It/2+22&&t.push([i,s,r])}t.sort((i,s)=>s[2]-i[2]);let e=[];for(let i of t)if(e.every(s=>Math.hypot(s[0]-i[0],s[1]-i[1])>55)&&e.push(i),e.length>=n)break;return e}function kv(){let n=Yd(4),t=(e,i,s)=>{if(!n[i])return;let[r,a]=n[i];e.position.set(r,0,a),e.rotation.y=Yt()*6,Le.add(e),wr.push([r,a,s])};if(_t.id==="parque"){{let e=new vt,i=pt(13209170,.8),s=pt(10558749,.6);At(new pe(14,10,14),i,!0,!0,e).position.y=5;let r=new ji;r.moveTo(-8.5,0),r.lineTo(0,6.5),r.lineTo(8.5,0),r.lineTo(-8.5,0),At(new _s(r,{depth:16,bevelEnabled:!1}),s,!0,!0,e).position.set(0,10,-8);let a=At(new Vt(3,3,.4,20,1,!1,0,Math.PI),pt(1708042,1),!1,!0,e);a.rotation.set(Math.PI/2,Math.PI/2,0),a.position.set(0,4,7.05),At(new pe(6,4,.4),pt(1708042,1),!1,!0,e).position.set(0,2,7.05),At(new Vt(2.2,1.6,1.2,20),pt(13840175,.35,.3),!0,!0,e).position.set(6,.6,12),t(e,0,22)}{let e=new vt,i=pt(14163750,.35,.4),s=pt(15909166,.3,.8);At(new Vt(3.6,4,1.2,24),i,!0,!0,e).position.y=.6,At(new Vt(2.6,2.8,9,24),i,!0,!0,e).position.y=5.5,At(new ue(2.7,24,12,0,Math.PI*2,0,Math.PI/2),i,!0,!0,e).position.y=10,At(new Vt(.7,.9,1.4,12),s,!0,!0,e).position.y=13;for(let r of[-1,1]){let a=At(new Vt(1,1,2,14),s,!0,!0,e);a.rotation.z=Math.PI/2,a.position.set(r*3.2,7,0)}t(e,1,12)}{let e=new vt,i=At(new xs(26,40),pt(12167034,1),!1,!0,e);i.rotation.x=-Math.PI/2,i.position.y=.04;let s=At(new xs(23,40),pt(2781071,.08,.1),!1,!0,e);s.rotation.x=-Math.PI/2,s.position.y=.08,t(e,2,30)}{let e=new vt,i=pt(15985362,.45),s=At(new Vt(1.4,1.4,12,20),i,!0,!0,e);s.rotation.z=Math.PI/2,s.position.y=2.4;for(let r of[-6,6])for(let a of[-1.4,1.4])At(new ue(2.2,20,14),i,!0,!0,e).position.set(r,2.4,a);t(e,3,12)}}else if(_t.id==="praia"){{let e=new vt,i=rn(He(8,64,s=>{for(let r=0;r<8;r++)s.fillStyle=r%2?"#f4f4f4":"#d32f2f",s.fillRect(0,r*8,8,8)}));At(new Vt(3,4.2,26,24),pt(16777215,.5,0,{map:i}),!0,!0,e).position.y=13,At(new Vt(3.6,3.6,.6,24),pt(2236962,.5,.6),!0,!0,e).position.y=26.3,At(new Vt(2.4,2.4,3,16),pt(16774064,.1,0,{emissive:16769674,emissiveIntensity:1.5}),!1,!1,e).position.y=28,At(new Ke(3,3,16),pt(12000284,.5,.3),!0,!0,e).position.y=31,t(e,0,14)}{let e=new vt,i=pt(14268286,1);At(new pe(14,5,14),i,!0,!0,e).position.y=2.5;for(let[s,r]of[[-7,-7],[7,-7],[-7,7],[7,7]])At(new Vt(2.2,2.6,9,12),i,!0,!0,e).position.set(s,4.5,r),At(new Ke(2.6,3.5,12),i,!0,!0,e).position.set(s,10.7,r);At(new Vt(3,3.4,11,14),i,!0,!0,e).position.set(0,5.5,0),t(e,1,16)}{let e=new vt,i=[15022389,2001125,16635957,4431943,16740419];for(let s=0;s<7;s++){let r=Ut(-14,14),a=Ut(-14,14);At(new Vt(.12,.12,5,8),pt(15658734,.4,.5),!0,!0,e).position.set(r,2.5,a),At(new Ke(3.2,1.4,12,1,!0),pt(i[s%5],.6,0,{side:Fe}),!0,!0,e).position.set(r,5.2,a);let o=At(new pe(1.6,.05,3),pt(i[(s+2)%5],.9),!1,!0,e);o.position.set(r+2,.05,a),o.rotation.y=Yt()}t(e,2,20)}}else{{let e=new vt,i=pt(7162413,.9),s=pt(16054527,.6);At(new pe(14,8,11),i,!0,!0,e).position.y=4;let r=new ji;r.moveTo(-8.5,0),r.lineTo(0,6),r.lineTo(8.5,0),r.lineTo(-8.5,0),At(new _s(r,{depth:13,bevelEnabled:!1}),s,!0,!0,e).position.set(0,8,-6.5),At(new pe(1.6,6,1.6),pt(7829367,.9),!0,!0,e).position.set(4,12,0);let a=pt(16765562,.3,0,{emissive:16756800,emissiveIntensity:1.2});for(let o of[-4,4])At(new pe(2,2,.2),a,!1,!1,e).position.set(o,4.5,5.55);t(e,0,16)}{let e=new vt,i=pt(16251647,.6);for(let s=0;s<3;s++){let r=(s-1)*7,a=1+s*.15;At(new ue(2*a,20,14),i,!0,!0,e).position.set(r,1.8*a,0),At(new ue(1.4*a,20,14),i,!0,!0,e).position.set(r,4.4*a,0),At(new ue(.95*a,20,14),i,!0,!0,e).position.set(r,6.4*a,0);let o=At(new Ke(.18*a,1*a,10),pt(16742938,.6),!0,!0,e);o.rotation.x=Math.PI/2,o.position.set(r,6.4*a,1.3*a),At(new Vt(.7*a,.7*a,1.2*a,16),pt(1710618,.5),!0,!0,e).position.set(r,7.6*a,0)}t(e,1,14)}{let e=new vt,i=At(new xs(24,40),pt(12575999,.05,.1),!1,!0,e);i.rotation.x=-Math.PI/2,i.position.y=.06,t(e,2,28)}}}var si=null,$d=new te({vertexColors:!0,flatShading:!0,roughness:.88});yh.add($d);function Gv(){let n=window.MODELOS;if(n)try{let t=atob(n.data),e=new Uint8Array(t.length);for(let r=0;r<t.length;r++)e[r]=t.charCodeAt(r);let i=e.buffer,s=new Ft;si={};for(let r of n.meta){let a=new Int16Array(i,r.p,r.v*3),o=new Uint8Array(i,r.c,r.v*3),c=r.big?new Uint32Array(i,r.x,r.i):new Uint16Array(i,r.x,r.i),l=new Float32Array(r.v*3),h=new Float32Array(r.v*3);for(let f=0;f<r.v;f++){for(let d=0;d<3;d++)l[f*3+d]=r.min[d]+(a[f*3+d]+32767)/65534*r.size[d];s.setRGB(o[f*3]/255,o[f*3+1]/255,o[f*3+2]/255,Ee),h[f*3]=s.r,h[f*3+1]=s.g,h[f*3+2]=s.b}let u=new Pe;u.setAttribute("position",new fe(l,3)),u.setAttribute("color",new fe(h,3)),u.setIndex(new fe(r.big?new Uint32Array(c):new Uint16Array(c),1)),u.computeVertexNormals(),u.computeBoundingSphere(),u.userData.keep=!0,si[r.n]={geo:u,size:r.size}}}catch(t){console.warn("modelos n\xE3o carregados",t),si=null}}var hi=(n,t)=>si?Object.keys(si).filter(e=>e.startsWith(n)&&(!t||t(e))):[],Xn=n=>n[Yt()*n.length|0];function Mr(n,t=!0){let e={};for(let i of n)(e[i[0]]=e[i[0]]||[]).push(i);for(let i in e){let s=si[i];if(!s)continue;let r=e[i],a=Sn(s.geo,$d,r.length,t);r.forEach((o,c)=>bn(a,c,o[1],o[2],o[3],0,o[4],0,o[5])),a.instanceMatrix.needsUpdate=!0}}var ei=2.1;function Vv(){if(!si)return;let n=[],t=$h(),e=(o,c,l,h=ei,u=0)=>{let f=ze(o,c);n.push([l,f.x,Mn(f.x,f.z),f.z,ii(o)+u,h])},i=(o,c,l,h)=>{for(let[u,f,d,p,x]of l){let g=o+f,m=c+d;n.push([u,g,Mn(g,m),m,p,(x||1)*ei])}wr.push([o,c,h])},s={parque:"parque:lamp_1",praia:"parque:lamp_2",neve:"parque:lamp_4"}[_t.id],r=1;for(let o=40;o<ve-30;o+=62)Math.abs(dn(o))<60||(e(o,r*(It/2+4.2),s,ei,r>0?Math.PI/2:-Math.PI/2),r=-r);for(let o=0;o<14;o++){let c=Yt()*ve;if(Math.abs(dn(c))<70)continue;let l=Yt()<.5?-1:1;o%3===0?e(c,l*(It/2+4.6),Xn(["vila:signpost_01","vila:signpost_02","vila:signpost_03"]),ei*1.3,Yt()*.6-.3):e(c,l*(It/2+6.5),_t.id==="neve"?"vila:bench":"parque:bench",ei,_t.id==="neve"?Math.PI/2:0)}let a=Yd(5);if(_t.id==="parque"){for(let c of[.13,.52,.83])for(let l of[-1,1])e(ve*c+Ut(-6,6),l*(It/2+4.8),Xn(["vila:haystack_01","vila:haystack_02","vila:haystack_03"]),ei*1.6,Yt()*6);let o=a[4]||a[3];o&&i(o[0],o[1],[["vila:well",0,0,.4],["vila:canopy",7,-4,1.2,1.3],["vila:trough",-5,4,.3],["vila:bucket",1.6,2.2,0],["vila:basin",-2.5,-2.5,0],["vila:haystack_01",-8,-3,0,1.5],["vila:haystack_02",-9.5,-.5,1,1.5],["vila:haystack_03",-7,1.5,2,1.5],["vila:firewood",6,4,.5],["vila:clothesline",3,8,.2],["vila:washboard",4.5,7,.3],["vila:barrel",8.5,1.5,0],["vila:barrel_broken",9.5,3.5,1],["vila:box",7.5,5,.4],["vila:stump",-4,-7,0],["vila:axe",-4,-7,.3],["vila:signpost_01",0,-9,0,1.3],["vila:pot_01",2.2,-1.8,0],["vila:pot_03",-1.5,2.6,0],["parque:fense_1",12,0,0],["parque:fense_1",12,7.2,0],["parque:fense_1",12,-7.2,0],["parque:fense_2",-12,0,0],["parque:fense_2",-12,6.4,0],["parque:fense_2",-12,-6.4,0]],20)}else if(_t.id==="praia"){let o=a[3]||a[2];o&&i(o[0],o[1],[["vila:chest",0,0,.6,1.4],["vila:barrel",2.5,1,0],["vila:barrel",3.4,-.6,1],["vila:barrel_broken",-2.5,2,.5],["vila:box",-2,-2,.3],["vila:box",-2.8,-1.2,1],["parque:bag_1",1.5,-2.6,0],["parque:bag_2",3,-2.5,1],["vila:canopy",-6,4,.5,1.4],["vila:pot_02",1,2.5,0],["vila:signpost_02",0,5.5,0,1.4],["vila:bench",6,3,1.2]],14);for(let c=0;c<26;c++){let l=Ut(-320,320),h=_t.sea-Ut(2,22);n.push([Xn(hi("pedra:stone_big")),l,Mn(l,h)-.5,h,Yt()*6,ei*Ut(.5,1.1)])}}else{let o=a[3]||a[2];o&&i(o[0],o[1],[["vila:firewood",0,0,0,1.4],["vila:firewood",1.8,.4,.3,1.4],["vila:stump",-2.5,1.5,0,1.3],["vila:axe",-2.5,1.5,.8,1.3],["vila:stump",-1,3.5,1],["vila:barrel",3.5,-2,0],["vila:box",4.5,-.5,.5],["vila:well",-6,-3,.8],["vila:signpost_03",0,-5,0,1.4],["vila:bucket",-4.5,-1,0],["vila:shovel",5.5,2,.3],["vila:rake",6,2.6,.5]],14);for(let c=0;c<12;c++){let l=c/12*Math.PI*2+Ut(-.2,.2),h=Ut(330,460),u=Math.cos(l)*h,f=Math.sin(l)*h;Mc(u,f)<90||n.push([Xn(hi("montanha:hill_winter")),u,Mn(u,f)-1,f,Yt()*6,Ut(3.5,5.5)])}}Mr(n)}function Wv(){let n=H.qual===0,t=(o,c,l)=>{let h=[],u=0;for(;h.length<o&&u++<o*25;){let f=Ut(-l,l),d=Ut(-l,l),p=Mc(f,d);p<c||wr.some(x=>Math.hypot(f-x[0],d-x[1])<x[2])||_t.sea!==void 0&&d<_t.sea+4||h.push([f,d,p])}return h},e=n?130:H.qual===1?220:320,i=new Ft;if(si&&_t.trees!=="palm"){let o=_t.trees==="broad"?hi("arvore:"):hi("pinheiro:",l=>!/_0(09|10|11|19)$/.test(l)),c=t(_t.trees==="broad"?e:e*1.2|0,It/2+9,520);if(Mr(c.map(([l,h])=>[Xn(o),l,Mn(l,h)-.2,h,Yt()*6.28,ei*Ut(.85,1.35)])),_t.trees==="pine"){let l=hi("pinheiro:",h=>/_0(09|10|11|19)$/.test(h));Mr(t(n?20:45,It/2+5,300).map(([h,u])=>[Xn(l),h,Mn(h,u),u,Yt()*6.28,ei*Ut(.9,1.4)]))}}else if(_t.trees==="broad"){let o=t(e,It/2+9,520),c=Sn(new Vt(.3,.5,1,7).translate(0,.5,0),pt(5913894,.95),o.length),l=new dr(1,1);{let u=l.attributes.position;for(let f=0;f<u.count;f++){ne.fromBufferAttribute(u,f);let d=.82+.3*Ni(ne.x*2.3+5,ne.y*2.3+ne.z*1.7,0,9);u.setXYZ(f,ne.x*d,ne.y*d,ne.z*d)}l.computeVertexNormals()}let h=Sn(l,pt(16777215,.9),o.length*3);o.forEach(([u,f],d)=>{let p=Ut(.8,1.4),x=Mn(u,f),g=5*p;bn(c,d,u,x,f,0,0,0,p,g,p);for(let m=0;m<3;m++){let S=2.6*p*Ut(.8,1.1);bn(h,d*3+m,u+Ut(-1.2,1.2)*p,x+g+S*.5+m*1.1*p,f+Ut(-1.2,1.2)*p,Yt()*3,Yt()*3,0,S,S*Ut(.8,1),S),h.setColorAt(d*3+m,i.setHSL(Ut(.22,.32),Ut(.45,.65),Ut(.18,.3)))}})}else if(_t.trees==="pine"){let o=t(e*1.2|0,It/2+9,520),c=Sn(new Vt(.25,.4,1,6).translate(0,.5,0),pt(4862498,.95),o.length),l=new Ke(1,1,10,3).translate(0,.5,0);{let u=l.attributes.position,f=new Float32Array(u.count*3);for(let d=0;d<u.count;d++){let p=u.getY(d)>.45;f[d*3]=p?1:.3,f[d*3+1]=p?1:.42,f[d*3+2]=p?1.05:.3}l.setAttribute("color",new fe(f,3))}let h=Sn(l,pt(16777215,.85,0,{vertexColors:!0}),o.length*3);o.forEach(([u,f],d)=>{let p=Ut(.8,1.6),x=Mn(u,f);bn(c,d,u,x,f,0,0,0,p,3*p,p);for(let g=0;g<3;g++){let m=(3.4-g*.9)*p;bn(h,d*3+g,u,x+(2.2+g*2.6)*p,f,0,Yt()*3,0,m,4.2*p,m),h.setColorAt(d*3+g,i.setHSL(.36,.25,Ut(.62,.8)))}})}else{let o=t(e*.7|0,It/2+8,480),c=Sn(new Vt(.28,.34,1.6,8).translate(0,.8,0),pt(9071176,.9),o.length*7),l=new on(1,1,1,8);{let f=l.attributes.position;for(let d=0;d<f.count;d++){let p=f.getX(d),x=f.getY(d)+.5;f.setXYZ(d,p*(1-x*.8)*1.2,-x*x*1.6,x*4.8)}l.computeVertexNormals()}let h=Sn(l,pt(4164142,.8,0,{side:Fe}),o.length*8),u=Sn(new ue(.28,8,6),pt(5913114,.7),o.length*3);o.forEach(([f,d],p)=>{let x=Ut(.05,.22),g=Yt()*6.28,m=f,S=Mn(f,d),y=d;for(let b=0;b<7;b++){let C=x*(b+1)*.35;bn(c,p*7+b,m,S,y,Math.cos(g)*C,0,-Math.sin(g)*C,1-b*.05),m+=Math.sin(g)*Math.sin(C)*1.5,y+=Math.cos(g)*Math.sin(C)*1.5,S+=Math.cos(C)*1.5*(1-b*.05)}for(let b=0;b<8;b++)bn(h,p*8+b,m,S,y,0,b/8*6.28+Yt()*.3,0,1.2,1,1.2),h.setColorAt(p*8+b,i.setHSL(Ut(.24,.3),.55,Ut(.25,.35)));for(let b=0;b<3;b++)bn(u,p*3+b,m+Math.cos(b*2)*.4,S-.3,y+Math.sin(b*2)*.4,0,0,0,1)})}if(si){let o=hi("pedra:stone_mid"),c=hi("pedra:stone_lit"),l=hi("pedra:stone_big");Mr(t(n?40:90,It/2+6,420).map(([u,f,d],p)=>{let x=p%9===0&&d>It/2+30?Xn(l):p%2?Xn(o):Xn(c);return[x,u,Mn(u,f)-.1,f,Yt()*6.28,ei*(x.includes("lit")?Ut(1.5,3):x.includes("big")?Ut(.5,.8):Ut(.8,1.5))]}));let h=[];for(let u=0;u<(n?40:90);u++){let f=Yt()*ve,d=Yt()<.5?-1:1,p=ze(f,d*(It/2+3+Yt()*6));h.push([Xn(c),p.x,Mn(p.x,p.z),p.z,Yt()*6.28,ei*Ut(1,1.8)])}Mr(h,!1)}let s=si?[]:t(n?40:90,It/2+6,420),r=new dr(1,1);{let o=r.attributes.position;for(let c=0;c<o.count;c++){ne.fromBufferAttribute(o,c);let l=.7+.5*Ni(ne.x*2+3,ne.y*2+ne.z*2,0,4);o.setXYZ(c,ne.x*l,ne.y*l*.7,ne.z*l)}r.computeVertexNormals()}let a=Sn(r,pt(_t.id==="neve"?8160660:9274745,.95,0,{flatShading:!0}),s.length);if(s.forEach(([o,c],l)=>{let h=Ut(.6,2.4);bn(a,l,o,Mn(o,c)+h*.2,c,Yt(),Yt()*6,0,h,h,h)}),_t.id!=="neve"){let o=n?700:_t.id==="praia"?900:H.qual===1?1800:3200,c=new Pe,l=[];for(let f=0;f<5;f++){let d=f/5*Math.PI,p=Math.cos(d)*.12,x=Math.sin(d)*.12,g=Ut(-.25,.25);l.push(-p,0,-x,p,0,x,g*1.4,.7+Yt()*.4,g)}c.setAttribute("position",new he(l,3)),c.computeVertexNormals();let h=Sn(c,pt(16777215,.9,0,{side:Fe}),o,!1),u=0;for(let f=0;f<o*3&&u<o;f++){let d=Yt()*ve,p=Yt()<.5?-1:1,x=p*(It/2+3+Yt()*Yt()*40),g=ze(d,x);wr.some(m=>Math.hypot(g.x-m[0],g.z-m[1])<m[2])||_t.sea!==void 0&&g.z<_t.sea||(bn(h,u,g.x,Mn(g.x,g.z),g.z,0,Yt()*6,0,Ut(.7,1.6)),h.setColorAt(u++,_t.id==="praia"?i.setHSL(.2,.35,Ut(.35,.5)):i.setHSL(Ut(.2,.3),Ut(.4,.6),Ut(.2,.34))))}h.count=u}}function Xv(){if(si&&_t.id==="neve"){let n=hi("montanha:mountain_winter"),t=hi("montanha:plateau_winter"),e=[];for(let i=0;i<22;i++){let s=i/22*Math.PI*2+Ut(-.08,.08),r=Ut(520,640),a=Math.cos(s)*r,o=Math.sin(s)*r;e.push([i%4===3?Xn(t):Xn(n),a,-6,o,Math.atan2(-a,-o)+Ut(-.4,.4),Ut(6,8.5)])}Mr(e,!1);return}for(let n=0;n<26;n++){let t=n/26*Math.PI*2+Ut(-.1,.1),e=Ut(700,880),i=Math.cos(t)*e,s=Math.sin(t)*e;if(_t.sea!==void 0&&s<-250)continue;let r=Ut(110,260)*(_t.id==="neve"?1.35:1),a=Ut(140,240),o=new Ke(a,r,18,6,!0),c=o.attributes.position,l=new Float32Array(c.count*3),h=new Ft(_t.mtn[n%2]),u=new Ft(15922682),f=new Ft;for(let d=0;d<c.count;d++){ne.fromBufferAttribute(c,d);let p=(ne.y+r/2)/r,x=Li(ne.x*.02+n*7,ne.z*.02+ne.y*.02,4),g=1+(x-.5)*.5*(1-p*.5);c.setXYZ(d,ne.x*g,ne.y+(x-.5)*r*.12,ne.z*g),f.copy(h).lerp(u,Nt(.62-x*.2,.75-x*.2,p)*(_t.id==="praia"?0:1)),l[d*3]=f.r,l[d*3+1]=f.g,l[d*3+2]=f.b}o.setAttribute("color",new fe(l,3)),o.computeVertexNormals(),At(o,pt(16777215,.95,0,{vertexColors:!0,flatShading:!0}),!1,!1).position.set(i,r/2-4,s)}}function Yv(){let n=new Qn(He(256,128,e=>{for(let i=0;i<26;i++){let s=40+Yt()*176,r=50+Yt()*40,a=18+Yt()*30,o=e.createRadialGradient(s,r,0,s,r,a);o.addColorStop(0,"rgba(255,255,255,.9)"),o.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=o,e.fillRect(0,0,256,128)}}));n.colorSpace=Ee;let t=_t.id==="praia"?16763040:16777215;for(let e=0;e<18;e++){let i=new gs(new Ki({map:n,color:t,fog:!1,depthWrite:!1,transparent:!0,opacity:Ut(.6,.95)})),s=Yt()*6.28,r=Ut(450,900);i.position.set(Math.cos(s)*r,Ut(160,300),Math.sin(s)*r),i.scale.set(Ut(220,380),Ut(90,140),1),Le.add(i),Xh.push(i)}}function $v(){let n=H.qual===0?700:1600,t=new Float32Array(n*3);for(let i=0;i<n;i++)t[i*3]=Ut(-60,60),t[i*3+1]=Ut(0,40),t[i*3+2]=Ut(-60,60);let e=new Pe;e.setAttribute("position",new fe(t,3)),Di=new aa(e,new ra({size:.22,map:Fh,transparent:!0,depthWrite:!1,color:16777215})),Di.frustumCulled=!1,sn.add(Di)}function qv(n){let t=new vt,e=new Tt(new Vt(.14,.14,.9,12),n);e.rotation.z=Math.PI/2,t.add(e);for(let i of[-.45,.45])for(let s of[-.13,.13]){let r=new Tt(new ue(.2,12,10),n);r.position.set(i,s,0),t.add(r)}return t.traverse(i=>{i.isMesh&&(i.castShadow=!0)}),t}function Zv(){Qi=[],_h=[],lc=[],hc=[],Tr=[],Sa=[];let n=[["pad",.06,-3],["hurdle",.13],["coins",.19,-4],["puddle",.26,4],["nitro",.32],["ramp",.4],["coins",.46,3],["hurdle",.52],["puddle",.59,-3.5],["pad",.65,3],["nitro",.71],["coins",.77,0],["hurdle",.83],["puddle",.89,2.5],["nitro",.95],["ammo",.23],["ammo",.62],["ammo",.925]];ya=rn(He(64,64,h=>{h.fillStyle="#062a3a",h.fillRect(0,0,64,64),h.strokeStyle="#35d0ff",h.lineWidth=9;for(let u of[10,42])h.beginPath(),h.moveTo(8,u+18),h.lineTo(32,u),h.lineTo(56,u+18),h.stroke()}),1,2);let t=rn(He(64,4,h=>{for(let u=0;u<8;u++)h.fillStyle=u%2?"#ffffff":"#e53935",h.fillRect(u*8,0,8,4)}),3,1),e={mud:pt(3876372,.15,0),water:pt(3833768,.05,.1,{transparent:!0,opacity:.85}),ice:pt(13496063,.03,.2)}[_t.puddle],i=pt(2060287,.25,.7),s=pt(3526911,.2,0,{emissive:3526911,emissiveIntensity:1.2}),r=new Cn({color:3526911,transparent:!0,opacity:.45,blending:qi,depthWrite:!1,side:Fe}),a=pt(16762173,.28,.55,{emissive:4861952});Ta=[];let o=rn(He(64,64,h=>{h.fillStyle="#3f4a2c",h.fillRect(0,0,64,64),h.strokeStyle="#2a3120",h.lineWidth=4,h.strokeRect(2,2,60,60),h.beginPath(),h.moveTo(2,2),h.lineTo(62,62),h.moveTo(62,2),h.lineTo(2,62),h.stroke(),h.fillStyle="#ffcc00",h.fillRect(16,26,32,12),h.fillStyle="#111",h.font="bold 10px Arial",h.textAlign="center",h.fillText("M\xCDSSIL",32,35)})),c=pt(16777215,.7,.1,{map:o}),l=pt(16777215,.3,0,{map:ya,emissive:16777215,emissiveMap:ya,emissiveIntensity:1.4});for(let[h,u,f=0]of n){let d=ve*u;if(h==="hurdle"){let p=new vt,x=new vt;At(new pe(It+1,.2,.2),pt(16777215,.4,0,{map:t}),!0,!0,x),x.position.y=.95,p.add(x);for(let g of[-1,1])At(new pe(.22,1.4,.22),pt(15790320,.4,.3),!0,!0,p).position.set(g*(It/2+.6),.7,0),At(new pe(.3,.12,1.4),pt(3355443,.5,.5),!0,!0,p).position.set(g*(It/2+.6),.06,0);p.position.copy(ze(d,0)),p.rotation.y=ii(d),Le.add(p),Qi.push({s:d,bar:x,fall:0})}else if(h==="ramp"){let p=new ji;p.moveTo(-3,0),p.lineTo(3,0),p.lineTo(3,1.1),p.lineTo(-3,0);let x=new _s(p,{depth:It,bevelEnabled:!1});x.translate(0,0,-It/2),x.rotateY(-Math.PI/2);let g=rn(He(64,64,S=>{S.fillStyle="#ffb300",S.fillRect(0,0,64,64),S.fillStyle="#1a1a1a";for(let y=-64;y<128;y+=22)S.beginPath(),S.moveTo(y,0),S.lineTo(y+11,0),S.lineTo(y+75,64),S.lineTo(y+64,64),S.fill()}),.25,.25),m=At(x,pt(16777215,.6,.2,{map:g}));m.position.copy(ze(d,0,.02)),m.rotation.y=ii(d),_h.push({s:d+3})}else if(h==="pad"){let p=At(new on(4.2,7),l,!1,!0);p.rotation.x=-Math.PI/2;let x=new vt;x.add(p),x.position.copy(ze(d,f,.07)),x.rotation.y=ii(d),Le.add(x),lc.push({s:d,d:f})}else if(h==="puddle"){let x=At(new xs(3.3,32),e,!1,!0);x.rotation.x=-Math.PI/2;let g=new vt;g.add(x),g.scale.set(.8,1,1.4),g.position.copy(ze(d,f,.06)),g.rotation.y=ii(d),Le.add(g),hc.push({s:d,d:f,r:3.3,type:_t.puddle})}else if(h==="nitro")for(let p of[-5,0,5]){let x=new vt;At(new Vt(.42,.42,1.2,20),i,!0,!0,x),At(new Vt(.44,.44,.3,20),s,!1,!1,x),At(new Vt(.15,.2,.25,12),ac,!1,!1,x).position.y=.72;let g=At(new fa(.8,1.1,32),r,!1,!1,x);g.rotation.x=-Math.PI/2,g.position.y=-1.15,x.position.copy(ze(d,p,1.3)),Le.add(x),Tr.push({s:d,d:p,g:x,cd:0})}else if(h==="ammo")for(let p of[-5,0,5]){let x=new vt;At(new pe(1.1,.8,1.1),c,!0,!0,x);let g=ep();g.visible=!0,g.scale.setScalar(.55),g.position.y=.7,g.rotation.x=-Math.PI/2,x.add(g);let m=At(new fa(.9,1.2,32),new Cn({color:16734778,transparent:!0,opacity:.45,blending:qi,depthWrite:!1,side:Fe}),!1,!1,x);m.rotation.x=-Math.PI/2,m.position.y=-1,x.position.copy(ze(d,p,1.1)),Le.add(x),Ta.push({s:d,d:p,g:x,cd:0})}else if(h==="coins")for(let p=0;p<6;p++){let x=qv(a);x.scale.setScalar(1.1);let g=d+p*4;x.position.copy(ze(g,f,1.1)),Le.add(x),Sa.push({s:g,d:f,g:x,taken:!1})}}}var Rr=[];function Jv(){Rr=[],[[.36,1,0],[.555,-1,3.2]].forEach(([n,t,e])=>{let i=ve*n,s=new vt,r=new vt,a=new vt;s.position.copy(ze(i,0)),s.rotation.y=ii(i),s.add(r),r.add(a),Le.add(s);let o=1.3,c="";if(_t.id==="parque"){o=1.2,c="ATROPELADO PELO FENO!";let f=rn(He(64,64,p=>{p.fillStyle="#d9b44a",p.fillRect(0,0,64,64);for(let x=0;x<220;x++){p.strokeStyle=Math.random()<.5?"#b8912f":"#f0d27a",p.beginPath();let g=Math.random()*64,m=Math.random()*64;p.moveTo(g,m),p.lineTo(g+Math.random()*10-5,m+Math.random()*3),p.stroke()}})),d=At(new Vt(o,o,2.2,24),pt(16777215,.95,0,{map:f}),!0,!0,a);d.rotation.x=Math.PI/2;for(let p of[-.5,.5]){let x=At(new mr(o+.01,.05,6,32),pt(8014622,.8),!1,!1,a);x.position.z=p}}else if(_t.id==="praia"){o=1.35,c="BOLADA DE PRAIA!";let f=rn(He(128,64,d=>{["#e53935","#ffffff","#1e88e5","#ffffff","#fdd835","#ffffff"].forEach((x,g)=>{d.fillStyle=x,d.fillRect(g*128/6,0,128/6+1,64)})}));At(new ue(o,28,18),pt(16777215,.35,0,{map:f}),!0,!0,a)}else{o=1.5,c="ATROPELADO PELA BOLA DE NEVE!";let f=new dr(o,3),d=f.attributes.position;for(let p=0;p<d.count;p++){ne.fromBufferAttribute(d,p);let x=.92+.12*Ni(ne.x*2+4,ne.y*2+ne.z*2,0,7);d.setXYZ(p,ne.x*x,ne.y*x,ne.z*x)}f.computeVertexNormals(),At(f,pt(16054527,.6),!0,!0,a)}let l=new vt,h=rn(He(64,64,f=>{f.fillStyle="#ffcc00",f.beginPath(),f.moveTo(32,3),f.lineTo(61,32),f.lineTo(32,61),f.lineTo(3,32),f.fill(),f.fillStyle="#111",f.beginPath(),f.arc(32,36,11,0,7),f.fill(),f.fillRect(12,46,40,4)}));At(new pe(1.6,1.6,.08),[pt(3355443),pt(3355443),pt(3355443),pt(3355443),pt(16777215,.5,0,{map:h}),pt(3355443)],!0,!0,l).position.y=2.6,At(new Vt(.06,.06,2,6),pt(7829367,.5,.6),!0,!0,l).position.y=1;let u=ze(i-25,-(It/2+3.4));l.position.set(u.x,0,u.z),l.rotation.y=ii(i)+Math.PI,Le.add(l),Rr.push({s:i,dir:t,off:e,r:o,roller:r,active:!1,d:0,hitMsg:c,period:7.5})})}function qh(n){for(let t of Rr){let e=((n+t.off)%t.period+t.period)%t.period,i=3.6,s=It/2+6,r=Math.min(1,e/i);t.d=t.dir*Ve(-s,s,r),t.active=e<i&&Math.abs(t.d)<It/2+1,t.roller.visible=e<i+.4,t.roller.position.set(-t.d,t.r,0),t.roller.rotation.z=t.d/t.r}}var Kv={parque:{name:"POMBO",plural:"POMBOS",body:9213349,wing:10397622,tip:3817288,head:5205859,beak:3355443,pitch:1},praia:{name:"GAIVOTA",plural:"GAIVOTAS",body:16185074,wing:12173770,tip:1710618,head:16777215,beak:15907118,pitch:1.4},neve:{name:"CORVO",plural:"CORVOS",body:1382172,wing:1842982,tip:789776,head:1382172,beak:2105376,pitch:.7}},Ci=()=>Kv[_t.id],Cs=[],_a=8;function jv(n){let t=new vt,e=a=>pt(a,.6,.05),i=(a,o,c,l,h,u=t)=>{let f=new Tt(a,o);return f.position.set(c,l,h),f.castShadow=!0,u.add(f),f};i(Ii(.2,.19,.38),e(n.body),0,0,0),i(new ue(.14,14,10),e(n.head),0,.14,.33);let s=i(new Ke(.045,.14,8),e(n.beak),0,.12,.5);s.rotation.x=Math.PI/2;for(let a of[-1,1])i(new ue(.03,8,6),pt(657930,.1),a*.09,.18,.42);i(Ii(.14,.025,.24),e(n.tip),0,.02,-.44);let r=[];for(let a of[-1,1]){let o=new vt;o.position.set(a*.14,.08,.04),t.add(o),i(Ii(.42,.02,.2),e(n.wing),a*.4,0,0,o),i(Ii(.18,.018,.12),e(n.tip),a*.78,0,-.05,o),r.push({piv:o,sx:a})}for(let a of[-1,1]){let o=i(new Vt(.012,.012,.16,5),pt(13662784,.6),a*.06,-.2,-.05);o.rotation.x=.8}return t.scale.setScalar(1.7),{g:t,wings:r}}function Qv(){Cs=[],_a=7;for(let n=0;n<4;n++){let t=jv(Ci());t.g.visible=!1,Le.add(t.g),Cs.push({...t,state:"off",pos:new L,vel:new L,t:0,target:null,phase:Math.random()*6})}}function tc(n,t){n.state="flee",n.t=0;let e=n.pos.x-t.x,i=n.pos.z-t.z,s=Math.hypot(e,i)||1;n.vel.set(e/s*22,14,i/s*22),n.target&&(n.target.birdT=0),Pt.squawk(Ci().pitch,ot?le(1-Math.hypot(n.pos.x-ot.x,n.pos.z-ot.z)/60,0,1):1);for(let r=0;r<8;r++)pi.spawn(n.pos.x,n.pos.y,n.pos.z,(Math.random()-.5)*6,Math.random()*3,(Math.random()-.5)*6,1.2,.25,.15,[.95,.95,.95],.9,3,1.5)}var Es=new L;function qd(n,t){if(t&&Yn>5){_a-=n;let e=Cs.filter(i=>i.state==="approach"||i.state==="harass").length;if(_a<=0&&e<1+H.diff){_a=6+Math.random()*5-H.diff;let i=Cs.find(r=>r.state==="off"),s=ge.filter(r=>!r.finished&&r.birdT<=0);if(i&&s.length){let r=s.includes(ot)&&Math.random()<.5?ot:s[Math.random()*s.length|0],a=Ir(r.dist+55+Math.random()*20),o=(Math.random()-.5)*30;i.pos.set(a.p.x+a.r.x*o,16+Math.random()*6,a.p.z+a.r.z*o),i.vel.set(0,0,0),i.state="approach",i.t=0,i.target=r,i.g.visible=!0,r.isPlayer&&Re(`CUIDADO: ${Ci().name}!`,"o")}}}for(let e of Cs){if(e.state==="off")continue;e.t+=n,e.phase+=n*(e.state==="harass"?22:15);let i=e.target;if(e.state==="approach"||e.state==="harass")if(!i||i.finished||!t)tc(e,e.pos);else{i.D.head.getWorldPosition(Es);let r=Math.sin(i.h),a=Math.cos(i.h);if(e.state==="approach"){ne.set(Es.x+r*1.2-e.pos.x,Es.y+.8-e.pos.y,Es.z+a*1.2-e.pos.z);let o=ne.length(),c=Math.hypot(i.vx,i.vz)+16;e.vel.lerp(ne.multiplyScalar(c/Math.max(o,.01)),1-Math.exp(-3*n)),e.pos.addScaledVector(e.vel,n),o<2.4&&(e.state="harass",e.t=0,i.isPlayer?(Re(`${Ci().name} NA CARA! LATE!`,"r"),Pt.squawk(Ci().pitch,1),Dn([20,30,20,30,20])):ui(`${Ci().name} ATACANDO ${i.b.name}!`)),e.t>12&&tc(e,e.pos)}else{let o=e.t*5;ne.set(Es.x+r*1.3+Math.cos(o)*.9,Es.y+.55+Math.sin(e.t*9)*.25,Es.z+a*1.3+Math.sin(o)*.9),e.vel.copy(ne).sub(e.pos).divideScalar(Math.max(n,.001)).clampLength(0,80),e.pos.lerp(ne,1-Math.exp(-10*n)),i.birdT=.25,Math.random()<n*1.5&&Pt.squawk(Ci().pitch,i.isPlayer?.6:.2),e.t>6&&tc(e,e.pos)}}else e.state==="flee"&&(e.vel.y+=n*4,e.pos.addScaledVector(e.vel,n),e.t>4&&(e.state="off",e.g.visible=!1));e.g.position.copy(e.pos),e.vel.lengthSq()>1&&e.g.rotation.set(-le(e.vel.y*.03,-.5,.5),Math.atan2(e.vel.x,e.vel.z),0);let s=Math.sin(e.phase)*(e.state==="flee"?.9:.7);for(let r of e.wings)r.piv.rotation.z=r.sx*s}}function Zd(){for(let n of Cs)n.state="off",n.g.visible=!1,n.target=null;_a=7}function tM(){let n=1/0,t=-1/0,e=1/0,i=-1/0;for(let o of $e)n=Math.min(n,o.x),t=Math.max(t,o.x),e=Math.min(e,o.z),i=Math.max(i,o.z);let s=216/Math.max(t-n,i-e),r=128-(n+t)/2*s,a=128-(e+i)/2*s;vh={f:(o,c)=>[o*s+r,c*s+a],canvas:He(256,256,o=>{o.lineJoin="round",o.beginPath();for(let c=0;c<=Ye;c+=8){let l=$e[c%Ye],h=l.x*s+r,u=l.z*s+a;c?o.lineTo(h,u):o.moveTo(h,u)}o.closePath(),o.lineWidth=16,o.strokeStyle="rgba(0,0,0,.55)",o.stroke(),o.lineWidth=9,o.strokeStyle="rgba(255,255,255,.9)",o.stroke(),o.fillStyle="#ff7a1a",o.fillRect($e[0].x*s+r-6,$e[0].z*s+a-6,12,12)})}}var Jd=[{name:"REDLINE AGOG",src:"musica/redline-agog.mp3"},{name:"APEX PURSUIT",src:"musica/apex-pursuit.mp3"}],Zh=["TODAS","REDLINE AGOG","APEX PURSUIT","8-BIT","DESLIGADA"],Tn=new Audio;Tn.preload="none";Tn.volume=.6;var Eh=Math.random()<.5?0:1,Sh=!1;Tn.addEventListener("ended",()=>{H.musicMode===0&&(Eh=(Eh+1)%Jd.length,Ec(!0))});Tn.addEventListener("error",()=>{Tn.getAttribute("src")&&(Sh=!0,Ec())});function Ec(n){let t=H.musicMode,e=t<=2&&!Sh;if(Pt.ctx&&Pt.setMusic(t===3||t<=2&&Sh),e){let i=Jd[t===0?Eh:t-1];Tn.getAttribute("src")!==i.src&&(Tn.src=i.src,n=!0),Tn.loop=t!==0;let s=Tn.play();s&&s.catch(()=>{}),n&&Pt.ctx&&Re("\u266A "+i.name,"c")}else Tn.pause()}function Kd(){H.musicMode=(H.musicMode+1)%Zh.length,je(),Ec(!0)}var Pt={ctx:null,master:null,music:null,sfx:null,nb:null,loops:{},timer:null,init(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}let n=window.AudioContext||window.webkitAudioContext;if(!n)return;let t=this.ctx=new n;this.master=t.createGain(),this.master.gain.value=.75;let e=t.createDynamicsCompressor();this.master.connect(e).connect(t.destination),this.music=t.createGain(),this.music.gain.value=0;let i=t.createBiquadFilter();i.type="lowpass",i.frequency.value=3200,this.music.connect(i).connect(this.master),this.sfx=t.createGain(),this.sfx.connect(this.master);let s=t.createBuffer(1,t.sampleRate*2,t.sampleRate),r=s.getChannelData(0);for(let a=0;a<r.length;a++)r[a]=Math.random()*2-1;this.nb=s,this.loops.wind=this.loopNoise("highpass",900,.5),this.loops.skid=this.loopNoise("bandpass",2400,2.5),this.loops.nitro=this.loopNoise("lowpass",500,1),this.loops.crowd=this.loopNoise("bandpass",750,.7),this.setLoop("crowd",.035),this.startMusic(),Ec()},loopNoise(n,t,e){let i=this.ctx,s=i.createBufferSource();s.buffer=this.nb,s.loop=!0;let r=i.createBiquadFilter();r.type=n,r.frequency.value=t,r.Q.value=e;let a=i.createGain();return a.gain.value=0,s.connect(r).connect(a).connect(this.sfx),s.start(0,Math.random()),{g:a,f:r}},setLoop(n,t,e){let i=this.loops[n];i&&(i.g.gain.setTargetAtTime(t,this.ctx.currentTime,.06),e&&i.f.frequency.setTargetAtTime(e,this.ctx.currentTime,.1))},tone(n,t,e="square",i=.2,s=0,r=0,a=null){if(!this.ctx)return;let o=this.ctx,c=r||o.currentTime,l=o.createOscillator(),h=o.createGain();l.type=e,l.frequency.setValueAtTime(n,c),s&&l.frequency.exponentialRampToValueAtTime(s,c+t),h.gain.setValueAtTime(i,c),h.gain.exponentialRampToValueAtTime(.001,c+t),l.connect(h).connect(a||this.sfx),l.start(c),l.stop(c+t+.03)},noise(n,t,e,i=0,s=null,r="bandpass"){if(!this.ctx)return;let a=this.ctx,o=i||a.currentTime,c=a.createBufferSource();c.buffer=this.nb;let l=a.createBiquadFilter();l.type=r,l.frequency.value=e,l.Q.value=1.2;let h=a.createGain();h.gain.setValueAtTime(t,o),h.gain.exponentialRampToValueAtTime(.001,o+n),c.connect(l).connect(h).connect(s||this.sfx),c.start(o,Math.random()),c.stop(o+n+.03)},bark(n=1,t=1){if(!this.ctx||t<.02)return;let e=this.ctx.currentTime;for(let i=0;i<2;i++){let s=e+i*.19;this.tone(560*n,.13,"sawtooth",.2*t,230*n,s),this.tone(280*n,.13,"triangle",.18*t,140*n,s),this.noise(.1,.25*t,1300*n,s)}},voice(n,t=1){if(!this.ctx||t<.02)return;let e=this.ctx.currentTime,i=n.pitch||1;if(n.voice==="hiss")for(let s=0;s<2;s++)this.noise(.32,.32*t,3800*i,e+s*.36,null,"highpass"),this.noise(.3,.12*t,1600*i,e+s*.36);else if(n.voice==="grunt")for(let s=0;s<3;s++){let r=e+s*.17;this.tone(190*i,.12,"square",.12*t,110*i,r),this.tone(95*i,.12,"sawtooth",.12*t,70*i,r),this.noise(.1,.2*t,500,r,null,"lowpass")}else this.bark(i,t)},boom(n=1){!this.ctx||n<.02||(this.noise(.8,.6*n,120,0,null,"lowpass"),this.noise(.4,.4*n,900),this.tone(90,.6,"sine",.4*n,30))},launch(n=1){!this.ctx||n<.02||(this.noise(.5,.35*n,1400),this.tone(300,.35,"sawtooth",.08*n,900))},reload(){let n=this.ctx?this.ctx.currentTime:0;this.noise(.05,.3,3e3,n),this.noise(.06,.3,1800,n+.12),this.tone(700,.1,"square",.06,0,n+.12)},lockon(){this.tone(1760,.06,"square",.07)},squawk(n=1,t=1){if(!this.ctx||t<.03)return;let e=this.ctx.currentTime;for(let i=0;i<2;i++)this.tone(1300*n,.09,"sawtooth",.09*t,800*n,e+i*.12),this.noise(.07,.12*t,2500*n,e+i*.12)},beep(n){this.tone(n?1320:660,n?.6:.25,"square",.14)},jump(){this.noise(.18,.14,700),this.tone(220,.16,"sine",.12,420)},land(){this.noise(.12,.25,180,0,null,"lowpass")},paw(n,t){this.noise(.05,.05+n*.05,t==="snow"?1500:t==="sand"?700:260,0,null,"lowpass")},pickup(){let n=this.ctx?this.ctx.currentTime:0;[523,784,1047].forEach((t,e)=>this.tone(t,.16,"triangle",.14,0,n+e*.05)),this.tone(300,.4,"sawtooth",.05,1200)},coin(){let n=this.ctx?this.ctx.currentTime:0;this.tone(1568,.08,"square",.07,0,n),this.tone(2093,.2,"square",.07,0,n+.06)},boost(){this.tone(180,.5,"sawtooth",.12,900),this.noise(.5,.22,1200)},splash(){this.noise(.35,.3,900)},trip(){this.tone(300,.45,"sawtooth",.14,70),this.noise(.25,.3,300)},thud(){this.noise(.14,.35,150,0,null,"lowpass")},lap(){let n=this.ctx?this.ctx.currentTime:0;[880,1175].forEach((t,e)=>this.tone(t,.18,"square",.1,0,n+e*.12))},fanfare(){if(!this.ctx)return;let n=this.ctx.currentTime;[[523,0],[659,.12],[784,.24],[1047,.36],[784,.56],[1047,.68]].forEach(([t,e])=>this.tone(t,.25,"square",.1,0,n+e)),this.cheer()},cheer(){if(!this.ctx)return;let n=this.loops.crowd.g.gain,t=this.ctx.currentTime;n.cancelScheduledValues(t),n.setValueAtTime(.22,t),n.linearRampToValueAtTime(.035,t+4)},setMusic(n){this.music&&this.music.gain.setTargetAtTime(n?.22:0,this.ctx.currentTime,.1)},startMusic(){if(this.timer||!this.ctx)return;let n=a=>440*Math.pow(2,(a-69)/12),t=[[45,[0,3,7]],[41,[0,4,7]],[48,[0,4,7]],[43,[0,4,7]]],e=[76,0,76,79,0,76,74,72,72,0,72,76,0,72,71,69,72,0,72,76,0,79,77,76,74,0,74,79,0,78,79,0],i=60/124/4,s=0,r=this.ctx.currentTime+.1;this.timer=setInterval(()=>{if(!(!this.ctx||this.ctx.state!=="running"))for(;r<this.ctx.currentTime+.15;){let a=(s>>4)%4,o=s%16,[c,l]=t[a],h=this.music;o%2===0&&this.tone(n(c-12+(o%4===2?12:0)),i*1.8,"sawtooth",.22,0,r,h),this.tone(n(c+24+l[o%3]+(o%6>2?12:0)),i*.9,"square",.035,0,r,h);let u=e[(s>>1)%32];s%2===0&&u&&(s>>6)%2&&this.tone(n(u),i*1.8,"triangle",.09,0,r,h),o%4===0&&this.tone(150,.16,"sine",.5,40,r,h),(o===4||o===12)&&this.noise(.14,.3,1800,r,h),o%2===1&&this.noise(.03,.08,8e3,r,h,"highpass"),r+=i,s++}},25)}},ts=[{n:"F\xC1CIL",k:.93,miss:.25,upOff:-1,reward:.8},{n:"NORMAL",k:.98,miss:.12,upOff:0,reward:1},{n:"DIF\xCDCIL",k:1.03,miss:.05,upOff:1,reward:1.3}],eM=[{id:"motor",name:"MOTOR",desc:"Mais velocidade m\xE1xima"},{id:"acel",name:"M\xDASCULOS",desc:"Arranca e acelera mais r\xE1pido"},{id:"grip",name:"GARRAS",desc:"Mais ader\xEAncia nas curvas e no drift"},{id:"nitro",name:"TANQUE DE NITRO",desc:"Nitro dura mais e empurra mais forte"},{id:"pulo",name:"MOLAS",desc:"Pula mais alto e mais longe"}],jd=[150,280,450,700,1e3],nM=2.6,iM=30,sM=1;function Sc(n){return H.up[n.id]||(H.up[n.id]={motor:0,acel:0,grip:0,nitro:0,pulo:0})}function rM(n,t){return{maxV:30+n.spd*1.8+t.motor*1.4,accel:9+n.acc*2.4+t.acel*1.9,grip:5.5+n.han*.8+t.grip*.7,turn:1.5+n.han*.06+t.grip*.05,jumpV:9.6+n.jmp*.75+t.pulo*.5,nitroDrain:30*(1-t.nitro*.09),nitroPow:1.3+t.nitro*.03}}var aM={throttle:0,brake:!1,steer:0,drift:!1,nitro:!1,jump:!1,bark:!1,fire:!1},bh=class{constructor(t,e,i,s){this.b=t,this.num=e,this.isPlayer=i,this.D=Wd(t,e,t.color),sn.add(this.D.root),this.look=i?yc(t):Vd(),_c(this.D,this.look),Object.assign(this,rM(t,s)),this.skill=i?1:ts[H.diff].k*(.98+Math.random()*.04),this.x=0,this.z=0,this.h=0,this.vx=0,this.vz=0,this.y=0,this.vy=0,this.yawRate=0,this.s=0,this.idx=0,this.dist=0,this.d=0,this.speed=0,this.slide=0,this.nitro=30,this.nitroOn=!1,this.drifting=!1,this.driftDir=0,this.driftT=0,this.mini=0,this.pad=0,this.stun=0,this.spook=0,this.barkCD=2,this.slip=0,this.surf=null,this.phase=Math.random()*6,this.lastStep=0,this.finished=!1,this.finishTime=0,this.lastLap=1,this.prevJump=!1,this.prevBark=!1,this.air=!1,this.rampAir=!1,this.ammo=1,this.fireCD=0,this.prevFire=!1,this.missHits=0,this.flip=0,this.lockT=0,this.lane=(Math.random()-.5)*8,this.laneT=1+Math.random()*3,this.aiNitro=!1,this.jumpPlan=new Map,this.minis=0,this.scared=0,this.cleanJumps=0,this.cans=0,this.hits=0,this.birdT=0,this.hitCD=0,this.driftScore=0,this.coins=0,this.lapStart=0,this.bestLap=0,this.pressT=null,this.wrongT=0}get lap(){return le(Math.floor(this.dist/ve)+1,1,H.laps)}place(t,e){this.dist=t,this.s=vc(t),this.idx=Math.round(this.s/ve*Ye)%Ye;let i=ze(t,e);this.x=i.x,this.z=i.z,this.d=e,this.h=ii(t)}dispose(){sn.remove(this.D.root),Ar(this.D.root)}},ge=[],ot=null,Xe=null,pn=null;function oM(n){let t=n.idx,e=1/0;for(let l=-40;l<=40;l++){let h=(n.idx+l+Ye)%Ye,u=n.x-$e[h].x,f=n.z-$e[h].z,d=u*u+f*f;d<e&&(e=d,t=h)}n.idx=t;let i=$e[t],s=ni[t],r=Ls[t],a=n.x-i.x,o=n.z-i.z,c=vc(t*ve/Ye+a*s.x+o*s.z);n.d=a*r.x+o*r.z,n.dist+=dn(c-n.s),n.s=c}function bs(n,t){if(!n.drifting||(n.drifting=!1,t))return;let e=n.driftT>2?2:n.driftT>.9?1:0,i=Math.round(n.driftT*140);n.driftScore+=i,e&&(n.minis++,n.isPlayer&&Dn(e===2?[25,30,25]:25),n.mini=e===2?1.5:.8,n.nitro=Math.min(100,n.nitro+e*8),n.isPlayer&&(Re(e===2?"SUPER MINI-TURBO!":"MINI-TURBO!",e===2?"o":"c"),Pt.boost())),n.isPlayer&&i>60&&Re(`DRIFT +${i}`,"g")}var cM=n=>n.voice==="hiss"?"CHIADO!":n.voice==="grunt"?"RONCO!":"LATIDO!",lM=n=>n.voice==="hiss"?"SSSSSS!":n.voice==="grunt"?"OINC OINC!":"AU AU!";function hM(n){n.barkCD=6;let t=Math.sin(n.h),e=Math.cos(n.h);Pt.voice(n.b,ot?le(1-Math.hypot(n.x-ot.x,n.z-ot.z)/60,0,1):1);let i=0;for(let a of ge){if(a===n||a.stun>0)continue;let o=a.x-n.x,c=a.z-n.z;Math.hypot(o,c)<12&&o*t+c*e>-2&&(a.spook=1.1,i++,a.isPlayer&&Re("ASSUSTADO!","r"))}let s=0;for(let a of Cs)a.state!=="approach"&&a.state!=="harass"||Math.hypot(a.pos.x-n.x,a.pos.z-n.z)<15&&(tc(a,n),s++);s&&(n.scared+=s,n.nitro=Math.min(100,n.nitro+10*s),n.isPlayer&&Re(`ESPANTOU ${s>1?s+" "+Ci().plural:"O "+Ci().name}! +NITRO`,"v"));let r=n.D.head.getWorldPosition(ne);for(let a=0;a<26;a++){let o=a/26*6.28;Un.spawn(r.x,r.y,r.z,Math.cos(o)*14,.5,Math.sin(o)*14,.45,.5,1.4,[1,.85,.4],.8,0,3)}n.isPlayer&&!s&&Re(i?`${cM(n.b)} ${i} ASSUSTADO${i>1?"S":""}`:lM(n.b),"g")}function Th(n,t,e){let i=n.dist,s=n.y>.02;n.stun>0&&(n.stun-=e,t=aM),n.spook>0&&(n.spook-=e,t={...t,nitro:!1,steer:le(t.steer+Math.sin(In*16+n.num)*.7,-1,1)});let r=t.jump&&!n.prevJump;n.prevJump=t.jump;let a=t.bark&&!n.prevBark;n.prevBark=t.bark,n.barkCD-=e,a&&n.barkCD<=0&&hM(n);let o=t.fire&&!n.prevFire;n.prevFire=t.fire,n.fireCD-=e,n.flip=Math.max(0,n.flip-e),o&&dM(n);let c=Math.abs(n.d)>It/2+.4,l=n.grip*_t.grip*(c?.8:1),h=c?.62:1;!s&&n.surf==="mud"?(l*=.5,h*=.62):!s&&n.surf==="water"?(l*=.8,h*=.72):!s&&n.surf==="ice"&&(l*=.22),n.hitCD=Math.max(0,n.hitCD-e),n.birdT>0&&(n.birdT-=e,t={...t,steer:le(t.steer+Math.sin(In*11+n.num*2)*.45,-1,1)}),n.nitroOn=t.nitro&&n.nitro>.5&&n.stun<=0,n.nitroOn&&(n.nitro=Math.max(0,n.nitro-n.nitroDrain*e)),n.mini=Math.max(0,n.mini-e),n.pad=Math.max(0,n.pad-e);let u=1;!n.isPlayer&&ot&&!ot.finished&&(u=1+le((ot.dist-n.dist)/220,-.07,.07));let f=n.maxV*n.skill*u*h*(n.nitroOn?n.nitroPow:1)*(n.mini>0?1.15:1)*(n.pad>0?1.22:1)*(n.slip>.5?1.06:1)*(n.spook>0?.72:1)*(n.birdT>0?.7:1)*(n.finished?.5:1),d=n.vx*Math.sin(n.h)+n.vz*Math.cos(n.h),p=Math.max(.45,le(Math.abs(d)/7,0,1))*(1-.3*le(Math.abs(d)/70,0,1));!n.drifting&&t.drift&&t.steer!==0&&d>16&&!s&&n.stun<=0&&(n.drifting=!0,n.driftDir=Math.sign(t.steer),n.driftT=0),n.drifting&&(!t.drift||d<10)&&bs(n,!1);let x;n.drifting?(n.driftT+=e,x=-n.driftDir*n.turn*p*(.8+.5*t.steer*n.driftDir),n.nitro=Math.min(100,n.nitro+8*e)):x=-t.steer*n.turn*p*(d<-1?-1:1),s&&(x*=.35),n.yawRate=Ve(n.yawRate,x,1-Math.exp(-(n.drifting?6:12)*e)),n.h+=n.yawRate*e;let g=Math.abs(n.d)>It/2+1.6;if(n.isPlayer&&!n.drifting&&!s&&(H.assist&&!t.steer&&d>3||g)){let M=ze(n.dist+8+d*.35,le(n.d,-It/2+2,It/2-2)),I=ph(Math.atan2(M.x-n.x,M.z-n.z)-n.h);n.h+=le(I,-1,1)*(g?3:1.8)*e}let m=Math.sin(n.h),S=Math.cos(n.h),y=-S,b=m;d=n.vx*m+n.vz*S;let C=n.vx*y+n.vz*b;if(s)C*=Math.exp(-.4*e);else if(t.throttle>0&&d<f&&(d+=(n.accel*(n.nitroOn?1.7:1)*t.throttle*(1-.55*le(d/f,0,1))+(n.mini>0?14:0)+(n.pad>.6?30:0))*e),t.throttle||(d-=Math.sign(d)*Math.min(Math.abs(d),7*e)),t.brake&&(d=d>0?Math.max(0,d-38*e):Math.max(-9,d-12*e)),t.drift&&!n.drifting&&d>4&&(d-=10*e),d>f&&(d=Math.max(f,d-(d-f)*2.2*e-2*e)),n.drifting){let M=d*d+C*C;C*=Math.exp(-(2.6+n.grip*.1)*e),d=Math.max(d,Math.sqrt(Math.max(0,M*(1-.12*e)-C*C)))}else C*=Math.exp(-l*e);if(n.vx=m*d+y*C,n.vz=S*d+b*C,n.x+=n.vx*e,n.z+=n.vz*e,n.speed=d,n.slide=C,r&&!s&&n.stun<=0&&(n.vy=n.jumpV,n.isPlayer&&Pt.jump(),n.drifting&&bs(n,!1)),n.vy-=iM*e,n.y+=n.vy*e,n.y<=0){if(s){n.isPlayer&&n.vy<-8&&(Pt.land(),Ri(.12)),n.rampAir&&(n.rampAir=!1,n.nitro=Math.min(100,n.nitro+12),n.isPlayer&&Re("SALTO! +NITRO","c"));for(let M=0;M<10;M++)Qd(n,1.4)}n.y=0,n.vy=0}n.air=n.y>.02;let A=le(Math.abs(d)/12,0,1);n.phase+=e*(A>.02?4+Math.abs(d)*.33:0),oM(n);let w=It/2+2.1;if(Math.abs(n.d)>w){let M=Math.sign(n.d),I=Ir(n.s),N=Math.abs(n.d)-w;n.x-=I.r.x*M*N,n.z-=I.r.z*M*N,n.d=M*w;let J=(n.vx*I.r.x+n.vz*I.r.z)*M;if(J>0){n.vx-=I.r.x*M*J*1.3,n.vz-=I.r.z*M*J*1.3,n.vx*=.95,n.vz*=.95;let P=Math.sin(n.h)*I.t.x+Math.cos(n.h)*I.t.z>=0?1:-1;n.h+=ph(Math.atan2(I.t.x*P,I.t.z*P)-n.h)*.3,n.isPlayer&&J>6&&(Ri(.3),Pt.thud(),Dn(35)),J>8&&bs(n,!0)}}let F=n.s;for(let M of Qi)Math.floor((i-M.s)/ve)<Math.floor((n.dist-M.s)/ve)&&Math.abs(n.d)<It/2+.6&&(n.y<.55&&n.stun<=0&&!n.b.fly?(n.stun=1,n.vx*=.25,n.vz*=.25,n.vy=3,M.fall=1,bs(n,!0),n.nitroOn=!1,n.hits++,n.isPlayer&&(Pt.trip(),Re("TROPE\xC7OU!","r"),Ri(.4),Dn(70))):(n.y>=.55||n.b.fly)&&(n.nitro=Math.min(100,n.nitro+10),n.cleanJumps++,n.isPlayer&&Re("PULO LIMPO! +NITRO","v")));for(let M of _h)Math.floor((i-M.s)/ve)<Math.floor((n.dist-M.s)/ve)&&Math.abs(n.d)<It/2&&n.y<.4&&(n.vy=9+Math.max(0,d)*.13,n.y=1.1,n.rampAir=!0,n.isPlayer&&(Pt.jump(),Ri(.15)));for(let M of lc)n.pad>.5||n.y>.5||Math.abs(dn(F-M.s))<3.5&&Math.abs(n.d-M.d)<2.2&&(n.pad=1.1,n.isPlayer&&(Pt.boost(),Re("TURBO!","c"),Ri(.1)));let E=n.surf;if(n.surf=null,!n.air&&!n.b.fly)for(let M of hc){let I=dn(F-M.s)/1.4,N=(n.d-M.d)/.8;I*I+N*N<M.r*M.r&&(n.surf=M.type)}if(n.isPlayer&&n.surf&&n.surf!==E&&(n.surf==="ice"?Re("GELO!","c"):(Pt.splash(),Re(n.surf==="mud"?"LAMA!":"SPLASH!","r"))),n.surf&&n.surf!=="ice"&&Math.abs(d)>6&&Math.random()<.6){let M=n.surf==="mud"?[.25,.15,.07]:[.75,.88,1];pi.spawn(n.x,.3,n.z,(Math.random()-.5)*6,3+Math.random()*3,(Math.random()-.5)*6,.6,.3,.6,M,.9,14,1)}for(let M of Rr)!M.active||n.hitCD>0||n.stun>0||n.y>M.r*1.25||n.b.fly||Math.abs(dn(F-M.s))<M.r+.7&&Math.abs(n.d-M.d)<M.r+.8&&(n.stun=.9,n.hitCD=2,n.vx*=.3,n.vz*=.3,n.vy=5,n.hits++,bs(n,!0),n.isPlayer?(Pt.thud(),Pt.trip(),Ri(.5),Re(M.hitMsg,"r"),Dn([80,40,80])):ui(`BOLADA EM ${n.b.name}!`));for(let M of Tr){if(M.cd>0||n.y>2.4)continue;let I=dn(F-M.s),N=n.d-M.d;I*I+N*N<3.2&&(M.cd=8,M.g.visible=!1,n.nitro=Math.min(100,n.nitro+35),n.cans++,n.isPlayer&&(Pt.pickup(),Re("NITRO +35","c"),Dn(15)))}for(let M of Ta){if(M.cd>0||n.y>2.4||n.ammo>=3)continue;let I=dn(F-M.s),N=n.d-M.d;I*I+N*N<3.4&&(M.cd=9,M.g.visible=!1,n.ammo++,n.isPlayer&&(Pt.reload(),Re(`M\xCDSSIL +1 (${n.ammo}/3)`,"o"),Dn(15)))}if(n.isPlayer)for(let M of Sa){if(M.taken||n.y>2.6)continue;let I=dn(F-M.s),N=n.d-M.d;I*I+N*N<3.4&&(M.taken=!0,M.g.visible=!1,n.coins++,Pt.coin())}if(!n.finished&&n.dist>=H.laps*ve){n.finished=!0,n.finishTime=Yn;let M=Yn-n.lapStart;(!n.bestLap||M<n.bestLap)&&(n.bestLap=M),bs(n,!1),n.isPlayer&&AM()}else if(!n.finished&&n.lap>n.lastLap){let M=Yn-n.lapStart;(!n.bestLap||M<n.bestLap)&&(n.bestLap=M),n.lapStart=Yn,n.lastLap=n.lap,n.isPlayer&&(Pt.lap(),Kh(n.lap===H.laps?"\xDALTIMA VOLTA":`VOLTA ${n.lap}`,1400,`melhor volta ${Pr(n.bestLap)}`),Is(n.lap===H.laps?"\xDAltima volta!":`Volta ${n.lap}!`,!0))}if(n.isPlayer&&!n.air&&A>.1){let M=Math.floor(n.phase/Math.PI);M!==n.lastStep&&(n.lastStep=M,Pt.paw(A,_t.surface))}}function Qd(n,t=1){let e=_t.surface==="snow"?[.92,.95,1]:_t.surface==="sand"?[.85,.75,.55]:[.55,.4,.27],i=n.x-Math.sin(n.h)*1.2,s=n.z-Math.cos(n.h)*1.2;pi.spawn(i+(Math.random()-.5)*1.2,.2,s+(Math.random()-.5)*1.2,(Math.random()-.5)*3*t-n.vx*.05,(.8+Math.random()*1.5)*t,(Math.random()-.5)*3*t-n.vz*.05,.9+Math.random()*.6,.6*t,2.4*t,e,.45,-.5,1.5)}function uM(n,t){Ev(n,t);let e=Math.hypot(n.vx,n.vz);if(!n.air&&e>8&&Math.random()<t*e*(n.drifting?1.6:.5)*(H.qual===0?.5:1)&&Qd(n,n.drifting?1.3:1),n.drifting&&!n.air){let i=n.driftT>2?2:n.driftT>.9?1:0,s=i===2?[1,.35,.9]:i===1?[.3,.8,1]:[1,.85,.4];for(let r of[-1,1]){let a=n.x-Math.sin(n.h)*1+Math.cos(n.h)*r*.3,o=n.z-Math.cos(n.h)*1-Math.sin(n.h)*r*.3;Un.spawn(a,.15,o,(Math.random()-.5)*5-n.vx*.1,2+Math.random()*3,(Math.random()-.5)*5-n.vz*.1,.35,i?.35:.22,.05,s,1,12,1)}}if(n.nitroOn)for(let i of n.D.flames){let s=i.getWorldPosition(ne);Un.spawn(s.x,s.y,s.z,-Math.sin(n.h)*8+(Math.random()-.5),Math.random()-.5,-Math.cos(n.h)*8+(Math.random()-.5),.25,.45,.1,Math.random()<.5?[1,.5,.15]:[.35,.75,1],1,0,2)}if(n.mini>0||n.pad>0){let i=n.D.body.getWorldPosition(ne);Un.spawn(i.x,i.y+.4,i.z,-n.vx*.3,.5,-n.vz*.3,.3,.8,.2,n.pad>0?[.3,.85,1]:[1,.55,.2],.7,0,1)}}function wh(n,t){let e=n.s;n.laneT-=t,n.laneT<=0&&(n.lane=(Math.random()-.5)*10,n.laneT=2+Math.random()*3);let i=n.lane;if(n.nitro<60)for(let p of Tr){let x=dn(p.s-e);if(p.cd<=0&&x>0&&x<40){i=p.d;break}}for(let p of lc){let x=dn(p.s-e);if(x>0&&x<35){i=p.d;break}}for(let p of hc){let x=dn(p.s-e);x>-3&&x<30&&Math.abs(i-p.d)<p.r+2&&(i=p.d+(i>=p.d?1:-1)*(p.r+2.6))}for(let p of ge){if(p===n)continue;let x=dn(p.dist-n.dist);x>0&&x<6&&Math.abs(p.d-n.d)<2.2&&(i+=n.d>=p.d?2.6:-2.6)}i=le(i,-It/2+1.5,It/2-1.5);let s=7+Math.max(0,n.speed)*.42,r=ze(n.dist+s,i),a=ph(Math.atan2(r.x-n.x,r.z-n.z)-n.h),o=le(-a*2.6,-1,1),l=1-ni[n.idx].dot(ni[(n.idx+40)%Ye])>.2&&n.speed>n.maxV*.9?.4:1,h=!1;for(let p=0;p<Qi.length;p++){let x=dn(Qi[p].s-e),g=p+":"+Math.floor((n.dist-Qi[p].s)/ve);n.jumpPlan.has(g)||n.jumpPlan.set(g,Math.random()<ts[H.diff].miss?-1:.2+Math.random()*.14);let m=n.jumpPlan.get(g);m>0&&x>0&&x<n.speed*m+1&&(h=!0)}let u=ni[n.idx].dot(ni[(n.idx+80)%Ye])>.94;u&&n.nitro>35&&(n.aiNitro=!0),(!u||n.nitro<5)&&(n.aiNitro=!1);for(let p of Rr){if(!p.active)continue;let x=dn(p.s-e);x>0&&x<n.speed*.3+p.r+1&&Math.abs(p.d-n.d)<p.r+2.5&&Math.random()>ts[H.diff].miss*t*30&&(h=!0)}let f=n.birdT>0&&n.barkCD<=0&&Math.random()<t*(.8+H.diff*.8);if(n.barkCD<=0&&Math.random()<t*(.25+H.diff*.2))for(let p of ge){if(p===n)continue;let x=dn(p.dist-n.dist);x>1&&x<9&&Math.abs(p.d-n.d)<4&&(f=!0)}let d=!1;return n.ammo>0&&n.fireCD<=0&&Yn>4&&Math.random()<t*(.5+H.diff*.45)&&ip(n)&&(d=!0),{throttle:l,brake:!1,steer:o,drift:!1,nitro:n.aiNitro,jump:h,bark:f,fire:d}}function tp(n){for(let t=0;t<ge.length;t++)for(let e=t+1;e<ge.length;e++){let i=ge[t],s=ge[e],r=s.x-i.x,a=s.z-i.z,o=r*r+a*a,c=sM*2;if(o<c*c&&Math.abs(i.y-s.y)<1.2){let l=Math.sqrt(o)||.01,h=r/l,u=a/l,f=(c-l)/2,d=(s.b.mass||1)/((i.b.mass||1)+(s.b.mass||1))*2,p=2-d;i.x-=h*f*d,i.z-=u*f*d,s.x+=h*f*p,s.z+=u*f*p;let x=(s.vx-i.vx)*h+(s.vz-i.vz)*u;if(x<0){let g=i.b.mass||1,m=s.b.mass||1,S=-1.3*x/(1/g+1/m);i.vx-=S/g*h,i.vz-=S/g*u,s.vx+=S/m*h,s.vz+=S/m*u,(i.isPlayer||s.isPlayer)&&-x>5&&(Pt.thud(),Ri(.2))}}}for(let t of ge){let e=Math.sin(t.h),i=Math.cos(t.h),s=!1;for(let r of ge){if(r===t||r.speed<15)continue;let a=r.x-t.x,o=r.z-t.z,c=a*e+o*i,l=Math.abs(a*i-o*e);if(c>2.5&&c<14&&l<1.8){s=!0;break}}t.slip=s?t.slip+n:0,t.slip>.5&&(t.nitro=Math.min(100,t.nitro+5*n))}}var Ps=[],Cr=[],Ta=[];function ep(){let n=new vt,t=new Tt(new Vt(.14,.14,.9,14),pt(15658734,.35,.5));t.rotation.x=Math.PI/2,n.add(t);let e=new Tt(new Ke(.14,.34,14),oc);e.rotation.x=Math.PI/2,e.position.z=.62,n.add(e);let i=new Tt(new Vt(.145,.145,.1,14),Bh);i.rotation.x=Math.PI/2,i.position.z=.2,n.add(i);for(let r=0;r<4;r++){let a=new Tt(new pe(.02,.3,.22),oc);a.rotation.z=r*Math.PI/2,a.position.z=-.38,a.translateY(.15),n.add(a)}let s=new Tt(new Ke(.12,.6,10),new Cn({color:16752704,transparent:!0,opacity:.9,blending:qi,depthWrite:!1}));return s.rotation.x=-Math.PI/2,s.position.z=-.75,n.add(s),n.traverse(r=>{r.isMesh&&(r.castShadow=!0)}),n.visible=!1,n}function fM(){Cr=[],Ps=[];for(let n=0;n<10;n++){let t=ep();Le.add(t),Cr.push(t)}}function np(){for(let n of Ps)n.mesh.visible=!1,Cr.push(n.mesh);Ps=[];for(let n of ge)n.lockT=0}function ip(n){let t=Math.sin(n.h),e=Math.cos(n.h),i=null,s=95;for(let r of ge){if(r===n||r.finished)continue;let a=r.x-n.x,o=r.z-n.z,c=Math.hypot(a,o);c<s&&c>2&&(a*t+o*e)/c>.55&&(s=c,i=r)}return i}function dM(n){if(n.ammo<=0||n.fireCD>0||n.stun>0||!Cr.length){n.isPlayer&&n.ammo<=0&&Re("SEM M\xCDSSEIS! PEGUE AS CAIXAS","r");return}n.ammo--,n.fireCD=.7;let t=Cr.pop(),e=n.D.launcher.muzzle.getWorldPosition(new L),i=ip(n),s=Math.sin(n.h),r=Math.cos(n.h),a=Math.max(0,n.speed)+38;t.visible=!0,t.position.copy(e),Ps.push({mesh:t,pos:e,vel:new L(s*a,3,r*a),owner:n,target:i,t:0});let o=ot?le(1-Math.hypot(n.x-ot.x,n.z-ot.z)/70,0,1):1;Pt.launch(o);for(let c=0;c<12;c++)pi.spawn(e.x,e.y,e.z,(Math.random()-.5)*4-s*6,Math.random()*2,(Math.random()-.5)*4-r*6,.8,.5,1.6,[.8,.8,.8],.6,-1,2);n.isPlayer&&Re(i?`M\xCDSSIL NO ${i.b.name}!`:"M\xCDSSIL!","o"),i&&i.isPlayer&&(Re(`${n.b.name} ATIROU EM VOC\xCA!`,"r"),Pt.lockon())}var fh=new L;function sp(n){for(let t=Ps.length-1;t>=0;t--){let e=Ps[t];e.t+=n;let i=e.target&&!e.target.finished?e.target:null,s=Math.max(62,e.vel.length());i?(fh.set(i.x,1.1+i.y,i.z).sub(e.pos).normalize().multiplyScalar(s),e.vel.lerp(fh,1-Math.exp(-(e.t<.25?1:3.4)*n)),i.isPlayer&&(i.lockT=.3)):e.vel.y+=(1.2-e.pos.y)*n*4,e.vel.setLength(Math.min(s+25*n,80)),e.pos.addScaledVector(e.vel,n),e.pos.y<.5&&(e.pos.y=.5,e.vel.y=Math.abs(e.vel.y)*.3),e.mesh.position.copy(e.pos),e.mesh.lookAt(fh.copy(e.pos).add(e.vel)),Un.spawn(e.pos.x,e.pos.y,e.pos.z,-e.vel.x*.05,.3,-e.vel.z*.05,.25,.7,.2,Math.random()<.5?[1,.6,.2]:[1,.9,.5],1,0,2),Math.random()<.7&&pi.spawn(e.pos.x,e.pos.y,e.pos.z,Math.random()-.5,Math.random(),Math.random()-.5,1.2,.5,2.2,[.75,.75,.78],.45,-.6,1.5);let r=null;for(let a of ge)if(!(a===e.owner&&e.t<1.5)&&Math.hypot(a.x-e.pos.x,a.z-e.pos.z)<1.8&&Math.abs(a.y+1-e.pos.y)<1.8){r=a;break}(r||e.t>3.2)&&(pM(e,r),Ps.splice(t,1))}}function pM(n,t){n.mesh.visible=!1,Cr.push(n.mesh);let e=n.pos;for(let s=0;s<40;s++){let r=Math.random()*6.28,a=Math.random()*10;Un.spawn(e.x,e.y,e.z,Math.cos(r)*a,Math.random()*9,Math.sin(r)*a,.5+Math.random()*.4,1.4,.3,Math.random()<.5?[1,.55,.15]:[1,.85,.3],1,6,2.5)}for(let s=0;s<18;s++)pi.spawn(e.x,e.y,e.z,(Math.random()-.5)*7,Math.random()*5,(Math.random()-.5)*7,1.6,1.2,3.6,[.3,.28,.27],.7,-1.5,1.8);let i=ot?Math.hypot(e.x-ot.x,e.z-ot.z):0;Pt.boom(le(1-i/90,0,1)),i<25&&Ri(.6*(1-i/25)),t&&(t.stun=1.4,t.flip=1,t.vx*=.2,t.vz*=.2,t.vy=8,t.nitroOn=!1,t.hits++,bs(t,!0),n.owner!==t&&n.owner.missHits++,t.isPlayer?(Re("ATINGIDO POR UM M\xCDSSIL!","r"),Ri(.8),Dn([100,50,160]),n.owner!==t&&ui(`${n.owner.b.name} ACERTOU VOC\xCA COM UM M\xCDSSIL!`,!0)):!n.owner.isPlayer&&n.owner!==t&&ui(`${n.owner.b.name} ACERTOU ${t.b.name} COM UM M\xCDSSIL!`),n.owner.isPlayer&&t!==n.owner&&(Re(`ACERTOU ${t.b.name}!`,"v"),ui(`VOC\xCA ACERTOU ${t.b.name}!`,!0),n.owner.nitro=Math.min(100,n.owner.nitro+10)))}function va(n){n.D.root.position.set(n.x,0,n.z),n.D.root.rotation.y=n.h,n.D.launcher.noses.forEach((t,e)=>{t.visible=e<n.ammo}),n.D.model.rotation.x=n.flip>0?-(1-n.flip)*Math.PI*2:0,n.D.model.position.y=n.y,n.D.anim(n.D,{v:Math.hypot(n.vx,n.vz),y:n.y,vy:n.vy,phase:n.phase,yawRate:n.yawRate,stun:n.stun,spook:n.spook,nitro:n.nitroOn,idle:!1},In+n.num)}var Jh=["ATR\xC1S","ALTA","CACHORRO"],Ai=new L(0,0,1),dh=new L,Pi=new L,Er=0;function Ri(n){Er=Math.max(Er,n)}function Ah(n,t,e=!1){let i=Math.hypot(n.vx,n.vz),s=Math.sin(n.h),r=Math.cos(n.h);if(i>4&&(s=s*.55+n.vx/i*.45,r=r*.55+n.vz/i*.45),Pi.set(s,0,r).normalize(),Ai.lerp(Pi,e?1:1-Math.exp(-4.5*t)).normalize(),H.cam===2){let o=n.D.head.getWorldPosition(Pi);me.position.set(o.x-Ai.x*.3,o.y+.55,o.z-Ai.z*.3),dh.set(n.x+Ai.x*25,1.2+n.y*.3,n.z+Ai.z*25)}else{let o=(H.cam?11.5:6.6)+i*.025,c=H.cam?6:2.7;Pi.set(n.x-Ai.x*o,c+n.y*.5,n.z-Ai.z*o),me.position.lerp(Pi,e?1:1-Math.exp(-8*t)),dh.set(n.x+Ai.x*5,1.3+n.y*.6,n.z+Ai.z*5)}Er>.001&&(me.position.x+=(Math.random()-.5)*Er,me.position.y+=(Math.random()-.5)*Er,Er*=Math.exp(-7*t)),me.lookAt(dh);let a=64+i*.18+(n.nitroOn?10:0)+(n.pad>0||n.mini>0?5:0);me.fov=Ve(me.fov,a,1-Math.exp(-3*t)),me.updateProjectionMatrix()}var kt="loading",Yn=0,Ma=0,Ui=0,Rh=-1,bd="race",In=0,_r=0,Pr=n=>{let t=Math.floor(n/60),e=Math.floor(n%60),i=Math.floor(n*100%100);return`${t}:${String(e).padStart(2,"0")}.${String(i).padStart(2,"0")}`};function Re(n,t=""){let e=document.createElement("div");e.className="pop "+t,e.textContent=n;let i=mt("pops");for(i.appendChild(e);i.children.length>3;)i.firstChild.remove();setTimeout(()=>e.remove(),1300)}var Td=null;function Kh(n,t=1200,e=""){let i=mt("big");i.innerHTML=n+(e?`<small>${e}</small>`:""),i.classList.remove("pop"),i.offsetWidth,i.classList.add("pop"),clearTimeout(Td),t&&(Td=setTimeout(()=>{i.innerHTML=""},t))}var Ch=["","primeiro","segundo","terceiro","quarto","quinto","sexto"];function mM(n){return n.replace(/(\d)º LUGAR/g,(t,e)=>Ch[+e]+" lugar").replace(/(\d)º/g,(t,e)=>Ch[+e]||e).replace(/[+]\d+/g,"").replace(/[^\p{L}\p{N} ,.!?-]/gu," ").replace(/\s+/g," ").trim().toLowerCase()}var bc={v:null,until:0,pick(){try{let n=speechSynthesis.getVoices();this.v=n.find(t=>/pt[-_]BR/i.test(t.lang))||n.find(t=>/^pt/i.test(t.lang))||null}catch{}},duck(n){Tn.volume=n?.2:kt==="paused"?.25:.6,Pt.music&&Pt.ctx&&Pt.music.gain.setTargetAtTime(n?.07:Zh[H.musicMode]==="8-BIT"?.22:0,Pt.ctx.currentTime,.1)},say(n,t){if(!H.voice)return;let e=mM(n);if(!e)return;let i=performance.now();if(window.AndroidTTS){try{if(!t&&AndroidTTS.busy())return;AndroidTTS.speak(e)}catch{return}this.duck(!0),clearTimeout(this.tm),this.tm=setTimeout(()=>this.duck(!1),500+e.length*70);return}if(!("speechSynthesis"in window))return;if(speechSynthesis.speaking||i<this.until){if(!t)return;speechSynthesis.cancel()}this.v||this.pick();let s=new SpeechSynthesisUtterance(e);s.lang="pt-BR",this.v&&(s.voice=this.v),s.rate=1.12,s.pitch=1.05,s.onstart=()=>this.duck(!0),s.onend=s.onerror=()=>{this.until=0,this.duck(!1)},this.until=i+400+e.length*80;try{speechSynthesis.speak(s)}catch{}},stop(){try{window.AndroidTTS?AndroidTTS.stop():speechSynthesis.cancel()}catch{}this.duck(!1)}};try{speechSynthesis.onvoiceschanged=()=>bc.pick()}catch{}function Is(n,t){bc.say(n,t)}function Dn(n){if(H.vib&&navigator.vibrate)try{navigator.vibrate(n)}catch{}}function Me(n,t){mt(n).hidden=!t}function Dr(){document.querySelectorAll(".cval").forEach(n=>n.textContent=H.coins.toLocaleString("pt-BR"))}function Tc(){Xe&&(sn.remove(Xe.root),Ar(Xe.root));let n=Be[H.dog];Xe=Wd(n,1,n.color),_c(Xe,yc(n)),sn.add(Xe.root);let t=ze(22,0);if(!pn||pn.parent!==Le){pn=new vt,At(new Vt(3.2,3.4,.3,48),pt(2764600,.3,.8),!0,!0,pn).position.y=.15;let e=At(new mr(3.3,.06,8,64),pt(16742938,.3,0,{emissive:16742938,emissiveIntensity:1.5}),!1,!1,pn);e.rotation.x=Math.PI/2,e.position.y=.3,Le.add(pn)}pn.position.copy(t),Xe.root.position.set(t.x,.3,t.z)}function Ur(){let n=Be[H.dog],t=Sc(n);mt("dogName").textContent=n.name,mt("dogBreed").textContent=n.raca;let e=[["VELOCIDADE",n.spd,t.motor],["ACELERA\xC7\xC3O",n.acc,t.acel],["CURVAS",n.han,t.grip],["PULO",n.jmp,t.pulo]];mt("stats").innerHTML=e.map(([i,s,r])=>`<div class="stat"><span>${i}</span><div class="cells">${Array.from({length:10},(a,o)=>`<span class="${o<s?"b":o<s+r?"u":""}"></span>`).join("")}</div></div>`).join(""),mt("trackName").textContent=Us[H.track].name.split(" ")[0],mt("diffName").textContent=ts[H.diff].n,mt("lapsName").textContent=H.laps,mt("modeName").textContent=H.mode?"COPA":"CORRIDA",H.mode&&(mt("trackName").textContent="TODAS"),mt("startBtn").textContent=H.mode?"COME\xC7AR COPA":"CORRER",Dr()}function rp(){let n=Be[H.dog],t=Sc(n);mt("garageDog").textContent=`${n.name} \xB7 ${n.raca}`,mt("upList").innerHTML=eM.map(e=>{let i=t[e.id],s=jd[i],r=i>=5;return`<div class="up panel"><h3>${e.name}</h3><p>${e.desc}</p><div class="pips">${[0,1,2,3,4].map(a=>`<span class="${a<i?"on":""}"></span>`).join("")}</div>
      <button data-up="${e.id}" ${r||H.coins<s?"disabled":""}>${r?"M\xC1XIMO":"MELHORAR<br>"+s}</button></div>`}).join(""),Dr()}mt("upList").addEventListener("click",n=>{let t=n.target.closest("button[data-up]");if(!t||t.disabled)return;let e=Be[H.dog],i=Sc(e),s=t.dataset.up,r=jd[i[s]];H.coins<r||i[s]>=5||(H.coins-=r,i[s]++,i[s]>=5&&(H.stats.maxUp=1),je(),Pa(),Pt.init(),Pt.pickup(),Pt.voice(e,.6),rp())});function di(){Qh(),bc.stop(),mt("pops").style.top="",kt="menu",["hud","results","pause","touch","lights","garage","shop","missions","cupEnd"].forEach(n=>Me(n,!1)),Me("menu",!0),mt("big").innerHTML="",mt("pops").innerHTML="",su(0,0),Pt.ctx&&["wind","skid","nitro"].forEach(n=>Pt.setLoop(n,0)),nu(),Tc(),Ur()}var Ln="hat",ec="daily";function gM(){kt="shop",["menu"].forEach(n=>Me(n,!1)),Me("shop",!0),jh()}function jh(){let n=Be[H.dog],t=yc(n);mt("shopDog").textContent=`${n.name} \xB7 ${n.raca}`,mt("shopTabs").innerHTML=Object.entries(Rs).map(([e,i])=>`<button data-c="${e}" class="${e===Ln?"on":""}">${i.n}</button>`).join(""),mt("shopList").innerHTML=Rs[Ln].items.map(([e,i,s])=>{let r=yv(Ln,e),a=t[Ln]===e,o=Ln==="vest"?e==="padrao"?n.color:"#"+kd[e].toString(16).padStart(6,"0"):Ln==="cape"?Gd[e]||"transparent":Ln==="trail"?pv[e]||"transparent":Ln==="hat"?mv[e]||"transparent":gv[e]||"transparent",c=a?'<button class="eq" disabled>EM USO</button>':r?`<button data-eq="${e}">USAR</button>`:`<button data-buy="${e}" ${H.coins<s?"disabled":""}>COMPRAR ${s}</button>`;return`<div class="item panel"><span class="sw" style="background:${o}"></span><div><h4>${i}</h4><small>${r?a?"equipado no "+n.name:"seu":s+" ossos de ouro"}</small></div>${c}</div>`}).join(""),Dr()}mt("shopTabs").addEventListener("click",n=>{let t=n.target.closest("button[data-c]");t&&(Ln=t.dataset.c,jh())});mt("shopList").addEventListener("click",n=>{let t=n.target.closest("button");if(!t||t.disabled)return;let e=Be[H.dog],i=yc(e);if(t.dataset.buy){let s=Rs[Ln].items.find(r=>r[0]===t.dataset.buy);if(H.coins<s[2])return;H.coins-=s[2],H.owned.push(Ln+":"+s[0]),Wn("bought"),Pt.init(),Pt.pickup(),Dn(30),i[Ln]=s[0]}else t.dataset.eq&&(i[Ln]=t.dataset.eq,Pt.init(),Pt.beep(!1));H.looks[e.id]=i,je(),Xe&&_c(Xe,i),Pa(),jh()});function xM(){kt="missions",Me("menu",!1),Me("missions",!0),up(),ap(),Dr()}function ap(){nu(),document.querySelectorAll("#missTabs button").forEach(s=>s.classList.toggle("on",s.dataset.t===ec));let n=new Date,t=new Date(n);t.setHours(24,0,0,0);let e=Math.floor((t-n)/36e5),i=Math.floor((t-n)/6e4)%60;mt("dailyTag").textContent=ec==="daily"?`NOVAS MISS\xD5ES EM ${e}H ${i}MIN`:`${H.ach.length} DE ${Ih.length} CONQUISTAS`,ec==="daily"?mt("missList").innerHTML=H.daily.ids.map(s=>{let r=fc.find(c=>c.id===s),a=Math.min(hp(r),r.n),o=H.daily.claimed.includes(s);return`<div class="item panel ${o?"done":""}"><span class="sw" style="background:${o?"var(--good)":"transparent"}"></span><div><h4>${r.txt}</h4><div class="bar2"><i style="width:${a/r.n*100}%"></i></div><small>${a}/${r.n}</small></div><span class="rw">${o?"RECEBIDO":"+"+Ph}</span></div>`}).join("")+`<div class="item panel ${H.daily.bonus?"done":""}"><span class="sw" style="background:${H.daily.bonus?"var(--good)":"transparent"}"></span><div><h4>B\xF4nus: complete as 3 miss\xF5es</h4><small>${H.daily.claimed.length}/3</small></div><span class="rw">${H.daily.bonus?"RECEBIDO":"+"+Lh}</span></div>`:mt("missList").innerHTML=Ih.map(s=>{let r=H.ach.includes(s.id),a=Math.min(s.v(),s.g);return`<div class="item panel ${r?"done":""}"><span class="sw" style="background:${r?"var(--gold)":"transparent"}"></span><div><h4>${s.n}</h4><small>${s.d}${r?"":" \xB7 "+a+"/"+s.g}</small>${r?"":`<div class="bar2"><i style="width:${a/s.g*100}%"></i></div>`}</div><span class="rw">${r?"\u2713":"+"+s.r}</span></div>`}).join("")}mt("missTabs").addEventListener("click",n=>{let t=n.target.closest("button[data-t]");t&&(ec=t.dataset.t,ap())});function uc(){kt==="results"&&(Qh(),Tc()),kt="garage",["menu","results"].forEach(n=>Me(n,!1)),Me("garage",!0),rp()}function Qh(){np(),ge.forEach(n=>n.dispose()),ge=[],ot=null,Zd()}function op(n){H.track=n,je(),Me("loading",!0),requestAnimationFrame(()=>requestAnimationFrame(()=>{Yh(H.track),pn=null,Tc(),Ur(),Me("loading",!1)}))}function Ds(){Pt.init(),Qh(),Xe&&(sn.remove(Xe.root),Ar(Xe.root),Xe=null),pn&&(Le.remove(pn),Ar(pn),pn=null),me.clearViewOffset();let n=Sc(Be[H.dog]),t=Object.values(n).reduce((r,a)=>r+a,0)/5,e=ce?[H.dog,...ce.rivals]:[H.dog,...Be.map((r,a)=>a).filter(r=>r!==H.dog).sort(()=>Math.random()-.5).slice(0,5)],i=[5,...[0,1,2,3,4].sort(()=>Math.random()-.5)];e.forEach((r,a)=>{let o=Be[r],c=n;if(a){let d=()=>le(Math.round(t+ts[H.diff].upOff+(Math.random()*2-1)),0,5);c={motor:d(),acel:d(),grip:d(),nitro:d(),pulo:d()}}let l=new bh(o,a+1,a===0,c),h=i[a],u=Math.floor(h/2),f=h%2;l.place(-5-u*6.5-f*2.5,f?3.6:-3.6),ce&&a&&ce.looks[o.id]&&(l.look=ce.looks[o.id],_c(l.D,l.look)),l.lane=l.d,ge.push(l),a||(ot=l)}),Qi.forEach(r=>{r.fall=0,r.bar.rotation.x=0,r.bar.position.y=.95}),Tr.forEach(r=>{r.cd=0,r.g.visible=!0}),Ta.forEach(r=>{r.cd=0,r.g.visible=!0}),Sa.forEach(r=>{r.taken=!1,r.g.visible=!0}),ic=null,ma=5,Dh=!1,pc=0,dc=0,mt("narr").classList.remove("on"),mt("cupTag").textContent=ce?`COPA \xB7 CORRIDA ${ce.idx+1}/${ce.tracks.length}`:"",np(),pi.clear(),Un.clear(),Zd(),_M(),mt("goals").classList.remove("mini"),Yn=0,Ma=4,Rh=4,Ui=0,kt="countdown",ge.forEach(va),me.fov=64,Ah(ot,.016,!0),["menu","results","pause","garage"].forEach(r=>Me(r,!1)),Me("hud",!0),Me("lights",!0),Ra&&Me("touch",!0),mt("lapT").textContent=H.laps,mt("posOf").textContent="DE "+ge.length,mt("lights").querySelectorAll("span").forEach(r=>r.className=""),Mh(0,!1);let s=H.best[_t.id+"_"+H.laps];mt("bestLap").textContent=s?"RECORDE "+Pr(s):"",ba=.6}var yM=[{id:"mini",txt:"Fa\xE7a 3 mini-turbos no drift",n:3,v:n=>n.minis},{id:"scare",txt:"Espante 2 bichos com o latido",n:2,v:n=>n.scared},{id:"jumps",txt:"Pule 3 barreiras sem trope\xE7ar",n:3,v:n=>n.cleanJumps},{id:"coins",txt:"Pegue 10 ossos de ouro",n:10,v:n=>n.coins},{id:"cans",txt:"Pegue 3 latas de nitro",n:3,v:n=>n.cans},{id:"missile",txt:"Acerte 2 m\xEDsseis nos rivais",n:2,v:n=>n.missHits},{id:"clean",txt:"Termine sem trope\xE7ar nem ser atingido",final:!0,ok:(n,t)=>n.finished&&n.hits===0,bad:n=>n.hits>0},{id:"podium",txt:"Termine no p\xF3dio",final:!0,ok:(n,t)=>n.finished&&t<=3}],tu=120,fi=[],nc=0;function _M(){fi=yM.slice().sort(()=>Math.random()-.5).slice(0,3).map(n=>({g:n,done:!1})),nc=5,eu()}function cp(n,t){let e=n.g,i=n.done?"\u2713":"",s="";return e.final?e.bad&&e.bad(ot)&&(i="\u2717"):s=`${Math.min(e.v(ot),e.n)}/${e.n}`,`<div class="${n.done?"ok":i==="\u2717"?"no":""}"><i>${i}</i><span>${e.txt}</span><b>${n.done?"+"+tu:s}</b></div>`}function eu(){let n=fi.map(e=>cp(e)).join(""),t=fi.filter(e=>e.done).length;mt("goals").innerHTML=`<div class="gh">DESAFIOS <b>${t}/${fi.length}</b></div>`+n,mt("pauseGoals").innerHTML=`<div class="gh">DESAFIOS <b>${t}/${fi.length}</b></div>`+n}function lp(n){let t=!1;for(let i of fi)i.done||i.g.final||i.g.v(ot)>=i.g.n&&(i.done=!0,t=!0,Re(`DESAFIO CUMPRIDO! +${tu}`,"g"),Pt.lap(),nc=2.5,Is("Desafio cumprido!"));nc-=n;let e=nc>0;mt("goals").classList.toggle("mini",!e),(t||Math.random()<n*4)&&eu()}function vn(n){return H.stats[n]||0}function Wn(n,t=1){H.stats[n]=(H.stats[n]||0)+t}var fc=[{id:"win",txt:"Ven\xE7a 1 corrida",n:1,stat:"wins"},{id:"podium",txt:"Chegue ao p\xF3dio 2 vezes",n:2,stat:"podiums"},{id:"races",txt:"Complete 3 corridas",n:3,stat:"races"},{id:"minis",txt:"Fa\xE7a 8 mini-turbos",n:8,stat:"minis"},{id:"missiles",txt:"Acerte 4 m\xEDsseis",n:4,stat:"missHits"},{id:"birds",txt:"Espante 4 bichos voadores",n:4,stat:"scared"},{id:"coins",txt:"Pegue 25 ossos de ouro na pista",n:25,stat:"coins"},{id:"jumps",txt:"Pule 8 barreiras sem trope\xE7ar",n:8,stat:"cleanJumps"},{id:"cans",txt:"Pegue 6 latas de nitro",n:6,stat:"cans"}],Ph=250,Lh=300;function vM(){let n=new Date;return`${n.getFullYear()}-${n.getMonth()+1}-${n.getDate()}`}function nu(){let n=vM();if(H.daily&&H.daily.date===n)return;let t=7;for(let r of n)t=t*31+r.charCodeAt(0)>>>0;let e=fc.slice();for(let r=e.length-1;r>0;r--){t=t*1103515245+12345>>>0;let a=t%(r+1);[e[r],e[a]]=[e[a],e[r]]}let i=e.slice(0,3).map(r=>r.id),s={};i.forEach(r=>{let a=fc.find(o=>o.id===r);s[a.stat]=vn(a.stat)}),H.daily={date:n,ids:i,base:s,claimed:[],bonus:!1},je()}function hp(n){return Math.max(0,vn(n.stat)-(H.daily.base[n.stat]||0))}function up(){nu();let n=[];for(let t of H.daily.ids){let e=fc.find(i=>i.id===t);!H.daily.claimed.includes(t)&&hp(e)>=e.n&&(H.daily.claimed.push(t),H.coins+=Ph,n.push([`Miss\xE3o di\xE1ria: ${e.txt}`,Ph]))}return!H.daily.bonus&&H.daily.claimed.length===H.daily.ids.length&&(H.daily.bonus=!0,H.coins+=Lh,n.push(["Todas as miss\xF5es do dia",Lh])),n}var Ih=[{id:"first",n:"Primeira corrida",d:"Complete uma corrida",v:()=>vn("races"),g:1,r:100},{id:"win1",n:"Primeira vit\xF3ria",d:"Ven\xE7a uma corrida",v:()=>vn("wins"),g:1,r:200},{id:"win10",n:"Campe\xE3o de verdade",d:"Ven\xE7a 10 corridas",v:()=>vn("wins"),g:10,r:800},{id:"podium10",n:"Fregu\xEAs do p\xF3dio",d:"Chegue ao p\xF3dio 10 vezes",v:()=>vn("podiums"),g:10,r:400},{id:"minis50",n:"Rei do drift",d:"Fa\xE7a 50 mini-turbos",v:()=>vn("minis"),g:50,r:500},{id:"miss20",n:"Mira de \xE1guia",d:"Acerte 20 m\xEDsseis",v:()=>vn("missHits"),g:20,r:500},{id:"birds30",n:"Espantalho",d:"Espante 30 bichos voadores",v:()=>vn("scared"),g:30,r:500},{id:"coins200",n:"Garimpeiro",d:"Pegue 200 ossos de ouro na pista",v:()=>vn("coins"),g:200,r:500},{id:"jumps50",n:"Saltador",d:"Pule 50 barreiras sem trope\xE7ar",v:()=>vn("cleanJumps"),g:50,r:400},{id:"cup1",n:"Ta\xE7a na estante",d:"Ven\xE7a um campeonato",v:()=>vn("cups"),g:1,r:1e3},{id:"cupHard",n:"Lenda das pistas",d:"Ven\xE7a um campeonato no dif\xEDcil",v:()=>vn("cupsHard"),g:1,r:2e3},{id:"tracks",n:"Turista",d:"Ven\xE7a nas 3 pistas",v:()=>(H.stats.tracksWon||[]).length,g:3,r:600},{id:"zoo",n:"Zool\xF3gico completo",d:"Ven\xE7a com 6 corredores diferentes",v:()=>(H.stats.breedsWon||[]).length,g:6,r:1200},{id:"style",n:"Estiloso",d:"Compre 5 itens na loja",v:()=>vn("bought"),g:5,r:300},{id:"tuned",n:"Tunado",d:"Deixe uma melhoria no n\xEDvel m\xE1ximo",v:()=>vn("maxUp"),g:1,r:300}];function Pa(n){let t=[];for(let e of Ih)H.ach.includes(e.id)||e.v()<e.g||(H.ach.push(e.id),H.coins+=e.r,t.push([`Conquista: ${e.n}`,e.r]),n||Re(`CONQUISTA: ${e.n.toUpperCase()}! +${e.r}`,"g"));return t.length&&je(),t}function MM(n){let t=ot,e=H.stats;Wn("races"),n===1&&Wn("wins"),n<=3&&Wn("podiums"),Wn("minis",t.minis),Wn("missHits",t.missHits),Wn("scared",t.scared),Wn("coins",t.coins),Wn("cleanJumps",t.cleanJumps),Wn("cans",t.cans),n===1&&(e.tracksWon=e.tracksWon||[],e.tracksWon.includes(_t.id)||e.tracksWon.push(_t.id),e.breedsWon=e.breedsWon||[],e.breedsWon.includes(t.b.id)||e.breedsWon.push(t.b.id))}var EM=[10,7,5,3,2,1],SM=[1e3,600,400,0,0,0],ce=null;function bM(){Pt.init();let n=Be.map((t,e)=>e).filter(t=>t!==H.dog).sort(()=>Math.random()-.5).slice(0,5);ce={idx:0,tracks:[0,1,2],rivals:n,pts:{},looks:{}},n.forEach(t=>ce.looks[Be[t].id]=Vd()),fp(0,Ds)}function fp(n,t){Me("loading",!0),requestAnimationFrame(()=>requestAnimationFrame(()=>{H.track=n,je(),Yh(n),pn=null,Me("loading",!1),t()}))}function dp(n){return[Be[H.dog].id,...ce.rivals.map(i=>Be[i].id)].map(i=>({b:Be.find(s=>s.id===i),p:ce.pts[i]||0})).sort((i,s)=>s.p-i.p).map((i,s)=>`<tr class="${i.b.id===Be[H.dog].id?"me":""}"><td class="disp">${s+1}\xBA</td><td><i style="background:${i.b.color}"></i></td><td>${i.b.name}${i.b.id===Be[H.dog].id?" \xB7 VOC\xCA":""}</td><td class="mono">${i.p} pts</td></tr>`).join("")}function TM(n){let t=["#ffc53d","#d7dde6","#cd7f32"][n-1]||"#555b66",e=["#b8860b","#9aa3ae","#8b5a2b"][n-1]||"#333";return`<svg viewBox="0 0 120 140" role="img" aria-label="trof\xE9u"><path fill="${e}" d="M22 20h-14c0 22 10 34 26 36l2-8c-9-2-14-11-14-20zm76 0h14c0 22-10 34-26 36l-2-8c9-2 14-11 14-20z"/>
    <path fill="${t}" d="M24 10h72v26c0 24-16 40-36 42-20-2-36-18-36-42z"/><rect x="52" y="76" width="16" height="22" fill="${e}"/>
    <rect x="34" y="96" width="52" height="12" rx="3" fill="${t}"/><rect x="26" y="108" width="68" height="18" rx="4" fill="${e}"/>
    <text x="60" y="52" text-anchor="middle" font-family="Russo One, Arial Black, sans-serif" font-size="26" fill="${e}">${n<=3?n+"\xBA":""}</text></svg>`}function wM(){let e=[Be[H.dog].id,...ce.rivals.map(a=>Be[a].id)].map(a=>({id:a,p:ce.pts[a]||0})).sort((a,o)=>o.p-a.p).findIndex(a=>a.id===Be[H.dog].id)+1,i=Math.round(SM[e-1]*ts[H.diff].reward);H.coins+=i,e===1&&(Wn("cups"),H.diff===2&&Wn("cupsHard"));let s=H.trophies[H.diff];(!s||e<s)&&(H.trophies[H.diff]=e);let r=Pa(!0);je(),Dr(),mt("cupTitle").textContent=e===1?"CAMPE\xC3O DA COPA!":e<=3?`${e}\xBA LUGAR NA COPA`:`${e}\xBA LUGAR`,mt("trophy").innerHTML=TM(e),mt("cupTable").innerHTML=dp(),mt("cupReward").innerHTML=(i?`PR\xCAMIO DA COPA +${i}`:"SEM PR\xCAMIO DESTA VEZ")+r.map(([a,o])=>`<br>${a.toUpperCase()} +${o}`).join(""),Me("results",!1),Me("cupEnd",!0),e===1&&(Pt.fanfare(),Dn([60,40,60,40,140]))}function pp(){ce=null,Me("cupEnd",!1),di()}function iu(){return ge.slice().sort((n,t)=>n.finished&&t.finished?n.finishTime-t.finishTime:n.finished?-1:t.finished?1:t.dist-n.dist)}function AM(){let n=iu().indexOf(ot)+1;kt="finished",Ui=0,Pt.fanfare(),ba=1.3,Kh(n===1?"VIT\xD3RIA!":"CHEGADA!",3800,`${n}\xBA LUGAR \xB7 ${Pr(ot.finishTime)}`),Is(n===1?`Vit\xF3ria! ${ot.b.name} vence a corrida!`:`${ot.b.name} cruza a linha em ${Ch[n]} lugar!`,!0),setTimeout(()=>ot&&Pt.voice(ot.b),700)}function mp(){kt="results",mt("big").innerHTML="",["hud","touch","lights"].forEach(d=>Me(d,!1)),su(0,0),["wind","skid","nitro"].forEach(d=>Pt.setLoop(d,0));let n=iu(),t=n.indexOf(ot)+1;mt("resTitle").textContent=t===1?"CAMPE\xC3O!":t<=3?"P\xD3DIO!":`${t}\xBA LUGAR`,mt("resTable").innerHTML=n.map((d,p)=>`<tr class="${d===ot?"me":""}"><td class="disp">${p+1}\xBA</td><td><i style="background:${d.b.color}"></i></td><td>${d.b.name}${d===ot?" \xB7 VOC\xCA":""}</td><td class="mono">${d.finished?Pr(d.finishTime):"\u2014"}</td></tr>`).join("");let e={1:.5,3:1,5:1.5,7:2}[H.laps]||1,i=Math.round([500,350,250,180,130,100][t-1]*e*ts[H.diff].reward),s=ot.coins*15,r=Math.round(ot.driftScore/20);for(let d of fi)d.g.final&&!d.done&&(d.done=d.g.ok(ot,t));let a=fi.filter(d=>d.done).length,o=a*tu;eu(),MM(t);let c=[...up(),...Pa(!0)],l=c.reduce((d,p)=>d+p[1],0),h=i+s+r+o+l;H.coins+=h-l,t===1&&Dn([60,40,60,40,120]),ce&&(n.forEach((d,p)=>{ce.pts[d.b.id]=(ce.pts[d.b.id]||0)+EM[p]}),mt("cupMid").innerHTML=`<tr><td colspan="4" class="lbl">COPA \xB7 CORRIDA ${ce.idx+1} DE ${ce.tracks.length}</td></tr>`+dp()),Me("cupPanel",!!ce),mt("resAgain").textContent=ce?ce.idx<ce.tracks.length-1?"PR\xD3XIMA PISTA":"VER TROF\xC9U":"DE NOVO",mt("resMenu").textContent=ce?"SAIR DA COPA":"MENU",Me("resGarage",!ce),mt("rewards").innerHTML=`<div><span>${t}\xBA lugar</span><b>+${i}</b></div><div><span>Ossos de ouro \xD7 ${ot.coins}</span><b>+${s}</b></div><div><span>Drift (${ot.driftScore} pts)</span><b>+${r}</b></div><div><span>Desafios ${a}/${fi.length}</span><b>+${o}</b></div>`+c.map(([d,p])=>`<div><span>${d}</span><b>+${p}</b></div>`).join("")+`<div class="goalsRes">${fi.map(d=>cp(d)).join("")}</div><div class="tot"><span>TOTAL</span><b class="disp">+${h}</b></div>`;let u=_t.id+"_"+H.laps,f=H.best[u];ot.finished&&(!f||ot.finishTime<f)?(H.best[u]=ot.finishTime,mt("recordMsg").textContent="NOVO RECORDE DA PISTA!"):mt("recordMsg").textContent=f?"RECORDE "+Pr(f):"",je(),Dr(),Me("results",!0)}function Lr(n){n&&(kt==="race"||kt==="countdown"||kt==="finished")?(bd=kt,kt="paused",Me("pause",!0),es(),Tn.volume=.25,Pt.ctx&&["wind","skid","nitro"].forEach(t=>Pt.setLoop(t,0))):!n&&kt==="paused"&&(kt=bd,Me("pause",!1),Tn.volume=.6)}function es(){mt("camBtn").textContent="C\xC2MERA: "+Jh[H.cam],mt("assistBtn").textContent="ASSIST\xCANCIA: "+(H.assist?"LIGADA":"DESLIGADA"),mt("qualBtn").textContent="GR\xC1FICOS: "+Nh[H.qual].n,mt("vibBtn").textContent="VIBRA\xC7\xC3O: "+(H.vib?"LIGADA":"DESLIGADA"),mt("voiceBtn").textContent="LOCUTOR: "+(H.voice?"LIGADO":"DESLIGADO"),mt("musicBtn").textContent="M\xDASICA: "+Zh[H.musicMode]}var RM=mt("map").getContext("2d");function CM(){let n=mt("map"),t=Math.min(devicePixelRatio,2),e=Math.round(n.clientWidth*t);n.width!==e&&(n.width=n.height=e);let i=RM;i.setTransform(1,0,0,1,0,0),i.clearRect(0,0,e,e),i.save(),i.scale(e/256,e/256),i.drawImage(vh.canvas,0,0);for(let s of ge.slice().sort(r=>r.isPlayer?1:-1)){let[r,a]=vh.f(s.x,s.z),o=s.isPlayer?9:7;i.beginPath(),i.arc(r,a,o,0,7),i.fillStyle="#000",i.fill(),i.beginPath(),i.arc(r,a,o-2.5,0,7),i.fillStyle=s.isPlayer?"#ffffff":s.b.color,i.fill()}i.restore()}var PM=mt("gauge").getContext("2d");function LM(){let n=mt("gauge"),t=Math.min(devicePixelRatio,2),e=Math.round(n.clientWidth*t);n.width!==e&&(n.width=n.height=e);let i=PM;i.setTransform(1,0,0,1,0,0),i.clearRect(0,0,e,e),i.save(),i.scale(e/220,e/220);let s=110,r=112,a=Math.PI*.75,o=Math.PI*2.25;i.fillStyle="rgba(10,14,24,.62)",i.beginPath(),i.arc(s,r,104,0,7),i.fill(),i.strokeStyle="rgba(255,255,255,.16)",i.lineWidth=1,i.stroke();let c=Math.abs(ot.speed)*nM,l=le(c/180,0,1);for(let u=0;u<=9;u++){let f=a+(o-a)*u/9,d=u%3?88:84;i.strokeStyle=u/9<=l?"#fff":"rgba(255,255,255,.35)",i.lineWidth=u%3?2:3,i.beginPath(),i.moveTo(s+Math.cos(f)*94,r+Math.sin(f)*94),i.lineTo(s+Math.cos(f)*d,r+Math.sin(f)*d),i.stroke()}i.lineCap="round",i.lineWidth=10,i.strokeStyle="rgba(255,255,255,.1)",i.beginPath(),i.arc(s,r,76,a,o),i.stroke();let h=i.createLinearGradient(20,0,200,0);h.addColorStop(0,"#ffffff"),h.addColorStop(.7,"#ffb36b"),h.addColorStop(1,"#ff4d1a"),i.strokeStyle=h,i.beginPath(),i.arc(s,r,76,a,a+(o-a)*Math.max(.001,l)),i.stroke(),i.lineWidth=7,i.strokeStyle="rgba(255,255,255,.1)",i.beginPath(),i.arc(s,r,61,a,o),i.stroke(),i.strokeStyle=ot.nitroOn?"#35d0ff":"#ff7a1a",i.beginPath(),i.arc(s,r,61,a,a+(o-a)*Math.max(.001,ot.nitro/100)),i.stroke(),i.fillStyle="#fff",i.textAlign="center",i.font='46px "Russo One", sans-serif',i.fillText(Math.round(c),s,r+12),i.font="700 14px Rajdhani, sans-serif",i.fillStyle="#9aa7bf",i.fillText("KM/H",s,r+32),i.fillStyle=ot.nitro>99?"#35d0ff":"#ff9a4d",i.fillText(`NITRO ${Math.round(ot.nitro)}%`,s,r+52);for(let u=0;u<3;u++){let f=s-24+u*24,d=r+66;i.fillStyle=u<ot.ammo?"#ff4d5e":"rgba(255,255,255,.15)",i.beginPath(),i.moveTo(f,d-9),i.lineTo(f+5,d-3),i.lineTo(f+5,d+8),i.lineTo(f-5,d+8),i.lineTo(f-5,d-3),i.closePath(),i.fill()}if(ot.drifting){let u=ot.driftT>2?2:ot.driftT>.9?1:0;i.fillStyle=["#ffd97a","#35d0ff","#ff5ae0"][u],i.font='17px "Russo One", sans-serif',i.fillText("DRIFT",s,r-34)}else ot.barkCD<=0&&(i.fillStyle="#ffc53d",i.font="700 13px Rajdhani, sans-serif",i.fillText("LATIDO PRONTO",s,r-34));i.restore()}var wd="",dc=0,pc=0,ic=null,ma=0,Dh=!1;function ui(n,t){if(!ot||pc>0&&!t)return;let e=mt("narr");e.textContent=n,e.classList.add("on"),dc=3,pc=t?1.4:2.8,Is(n,t)}function IM(n,t){if(dc-=t,pc-=t,dc<=0&&mt("narr").classList.remove("on"),kt!=="race"||Yn<3){ic=n[0],ma=n.indexOf(ot);return}let e=n[0],i=n.indexOf(ot);e!==ic&&!e.finished?e.isPlayer?ui("VOC\xCA EST\xC1 NA LIDERAN\xC7A!",!0):ui(`${e.b.name} ASSUMIU A LIDERAN\xC7A!`,!0):i<ma&&n[i+1]?ui(`VOC\xCA ULTRAPASSOU ${n[i+1].b.name}!`):i>ma&&n[i-1]&&!n[i-1].finished&&ui(`${n[i-1].b.name} ULTRAPASSOU VOC\xCA!`),!Dh&&e.finished&&(Dh=!0,e.isPlayer||ui(`${e.b.name} VENCEU A CORRIDA!`,!0)),ic=e,ma=i}function Ad(n){let t=iu(),e=t.indexOf(ot)+1;mt("lap").textContent=ot.lap,mt("time").textContent=Pr(kt==="finished"?ot.finishTime:Yn),mt("pos").innerHTML=e+"<sup>\xBA</sup>";let i=t.map((a,o)=>`<li class="${a.isPlayer?"me":""}"><span class="n">${o+1}</span><i style="background:${a.b.color}"></i>${a.b.name}</li>`).join("");i!==wd&&(mt("board").innerHTML=i,wd=i),IM(t,n),mt("chipSlip").hidden=!(ot.slip>.5);let s=ni[ot.idx].x*Math.sin(ot.h)+ni[ot.idx].z*Math.cos(ot.h)<-.3&&Math.hypot(ot.vx,ot.vz)>3;ot.wrongT=s?ot.wrongT+n:0,mt("chipWrong").hidden=ot.wrongT<1,ot.lockT-=n,mt("chipMissile").hidden=!(ot.lockT>0),ot.lockT>0&&Math.random()<n*6&&Pt.lockon(),mt("tMn").textContent=ot.ammo,CM(),LM();let r=mt("topStack").getBoundingClientRect();mt("pops").style.top=Math.round(r.bottom+6)+"px"}var Rd=mt("fx"),DM=mt("vig");function su(n,t){Rd.style.opacity=n,DM.style.opacity=t,n>0&&(Rd.style.transform=`rotate(${Math.random()*6}deg)`)}var wa={},Aa={left:!1,right:!1,brake:!1,drift:!1,nitro:!1,jump:!1,bark:!1,fire:!1};addEventListener("keydown",n=>{["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space","Enter"].includes(n.code)&&n.preventDefault(),wa[n.code]=!0,!n.repeat&&(Pt.init(),kt==="menu"?((n.code==="ArrowLeft"||n.code==="KeyA")&&mc(-1),(n.code==="ArrowRight"||n.code==="KeyD")&&mc(1),(n.code==="Enter"||n.code==="Space")&&Ds(),n.code==="KeyG"&&uc(),n.code==="KeyT"&&op((H.track+1)%Us.length)):kt==="garage"||kt==="shop"||kt==="missions"?(n.code==="Escape"||n.code==="Enter")&&di():kt==="results"?mt("cupEnd").hidden?((n.code==="Enter"||n.code==="Space")&&gp(),n.code==="Escape"&&(ce=null,di()),n.code==="KeyG"&&!ce&&uc()):["Enter","Space","Escape"].includes(n.code)&&pp():kt==="paused"?((n.code==="Escape"||n.code==="KeyP")&&Lr(!1),n.code==="KeyQ"&&di()):(kt==="race"||kt==="countdown"||kt==="finished")&&(n.code==="Escape"||n.code==="KeyP")&&Lr(!0),n.code==="KeyC"&&(H.cam=(H.cam+1)%Jh.length,je()),n.code==="KeyM"&&(Kd(),kt==="paused"&&es()))});addEventListener("keyup",n=>{wa[n.code]=!1});addEventListener("blur",()=>{for(let n in wa)wa[n]=!1;for(let n in Aa)Aa[n]=!1;Lr(!0)});document.addEventListener("visibilitychange",()=>{document.hidden&&Lr(!0)});function ns(n,t){let e=mt(n),i=r=>{r.preventDefault(),Pt.init(),Aa[t]=!0,e.classList.add("on");try{e.setPointerCapture(r.pointerId)}catch{}},s=r=>{r.preventDefault(),Aa[t]=!1,e.classList.remove("on")};e.addEventListener("pointerdown",i),e.addEventListener("pointerup",s),e.addEventListener("pointercancel",s),e.addEventListener("contextmenu",r=>r.preventDefault())}ns("tL","left");ns("tR","right");ns("tS","brake");ns("tD","drift");ns("tN","nitro");ns("tJ","jump");ns("tB","bark");ns("tM","fire");var Se=(n,t)=>mt(n).addEventListener("click",e=>{e.stopPropagation(),e.currentTarget.blur(),Pt.init(),t()});function mc(n){H.dog=(H.dog+n+Be.length)%Be.length,je(),Tc(),Ur(),Pt.voice(Be[H.dog],.8)}Se("prevDog",()=>mc(-1));Se("nextDog",()=>mc(1));Se("trackBtn",()=>op((H.track+1)%Us.length));Se("diffBtn",()=>{H.diff=(H.diff+1)%ts.length,je(),Ur(),Pt.beep(!1)});Se("lapsBtn",()=>{H.laps=H.laps>=7?1:H.laps+2,je(),Ur(),Pt.beep(!1)});Se("garageBtn",uc);Se("garageBack",di);Se("startBtn",()=>H.mode?bM():Ds());Se("modeBtn",()=>{H.mode=1-H.mode,je(),Ur(),Pt.beep(!1)});Se("shopBtn",gM);Se("shopBack",()=>{Pa(),di()});Se("missBtn",xM);Se("missBack",di);Se("pauseBtn",()=>Lr(!0));Se("resumeBtn",()=>Lr(!1));Se("restartBtn",()=>{Me("pause",!1),Ds()});Se("quitBtn",()=>{ce=null,di()});Se("voiceBtn",()=>{H.voice=!H.voice,je(),es(),H.voice?Is("Locutor ligado!",!0):bc.stop()});Se("vibBtn",()=>{H.vib=!H.vib,je(),es(),Dn(40)});Se("camBtn",()=>{H.cam=(H.cam+1)%Jh.length,je(),es()});Se("assistBtn",()=>{H.assist=!H.assist,je(),es()});Se("qualBtn",()=>{H.qual=(H.qual+1)%Nh.length,je(),Id(),es()});Se("musicBtn",()=>{Kd(),es()});Se("resAgain",gp);function gp(){if(!ce)return Ds();ce.idx<ce.tracks.length-1?(ce.idx++,fp(ce.tracks[ce.idx],Ds)):wM()}Se("resMenu",()=>{ce=null,di()});Se("cupDone",pp);Se("resGarage",uc);function Cd(){let n=wa,t=Aa,e=n.ArrowLeft||n.KeyA||t.left,i=n.ArrowRight||n.KeyD||t.right,s=!!(n.ArrowDown||n.KeyS||t.brake);return{throttle:n.ArrowUp||n.KeyW||Ra&&!s?1:0,brake:s,steer:(i?1:0)-(e?1:0),drift:!!(n.ShiftLeft||n.ShiftRight||t.drift),nitro:!!(n.KeyN||n.ControlLeft||n.ControlRight||t.nitro),jump:!!(n.Space||t.jump),bark:!!(n.KeyB||n.KeyE||t.bark),fire:!!(n.KeyF||n.KeyX||t.fire)}}var UM=new Xo;function xp(){requestAnimationFrame(xp);let n=Math.min(UM.getDelta(),.05);if(In+=n,kt!=="paused"){for(let e of Xh)e.position.x+=n*2,e.position.x>950&&(e.position.x=-950);for(let e of Ta)e.g.rotation.y+=n*1.5,e.g.position.y=1.1+Math.sin(In*3+e.s)*.12,e.cd>0&&(e.cd-=n,e.cd<=0&&(e.g.visible=!0));for(let e of Tr)e.g.rotation.y+=n*2,e.g.position.y=1.3+Math.sin(In*3+e.s)*.15,e.cd>0&&(e.cd-=n,e.cd<=0&&(e.g.visible=!0));for(let e of Sa)e.g.rotation.y+=n*3;for(let e of Qi)if(e.fall>0){e.fall=Math.max(0,e.fall-n*.5);let i=Nt(0,.25,1-e.fall)*(e.fall>.1?1:e.fall*10);e.bar.rotation.x=i*1.4,e.bar.position.y=.95-i*.8}if(ya&&(ya.offset.y-=n*1.5),qh(In),qd(n,kt==="race"),(kt==="race"||kt==="finished"||kt==="results")&&sp(n),br&&(br.offset.x+=n*.01,br.offset.y+=n*.006),Bv(In),ba=Ve(ba,.35,n*.25),pi.update(n),Un.update(n),Di){let e=Di.geometry.attributes.position,i=e.array,s=me.position;for(let r=0;r<i.length;r+=3)i[r+1]-=n*(3+r%7*.3),i[r]+=Math.sin(In+r)*n*.5,i[r+1]<s.y-15&&(i[r+1]+=40),i[r]<s.x-60&&(i[r]+=120),i[r]>s.x+60&&(i[r]-=120),i[r+2]<s.z-60&&(i[r+2]+=120),i[r+2]>s.z+60&&(i[r+2]-=120);e.needsUpdate=!0}}if(kt==="menu"||kt==="garage"||kt==="shop"||kt==="missions"){if(_r+=n*.35,Xe&&pn){pn.rotation.y+=n*.4,Xe.root.rotation.y=pn.rotation.y,Xe.anim(Xe,{v:0,y:0,vy:0,phase:0,yawRate:0,stun:0,spook:0,nitro:!1,idle:!0},In);let e=Xe.root.position,i=innerWidth,s=innerHeight,r=s>i*1.05,a=r?8.2:6.4;me.position.set(e.x+Math.cos(_r*.4)*a,2.4,e.z+Math.sin(_r*.4)*a),me.lookAt(e.x,1.1,e.z),me.fov=50,r?me.setViewOffset(i,s,0,s*.14,i,s):i>820?me.setViewOffset(i,s,Math.min(220,i*.18),0,i,s):me.clearViewOffset(),me.updateProjectionMatrix()}}else if(kt==="countdown"){Ma-=n;let e=Math.ceil(Ma-1);if(!Ra){let i=Cd();i.throttle&&ot.pressT===null&&(ot.pressT=Ma),i.throttle||(ot.pressT=null)}if(e!==Rh){Rh=e;let i=mt("lights").querySelectorAll("span");e>0&&e<=3&&(i[3-e].className="r",Mh(4-e,!1),Pt.beep(!1)),e<=0&&(i.forEach(s=>s.className="g"),Mh(3,!0),Pt.beep(!0),Kh("VAI!",900),kt="race",Is("Valendo!",!0),setTimeout(()=>Me("lights",!1),900),ot.pressT!==null&&(ot.pressT<=.6?(ot.mini=1.2,Re("LARGADA PERFEITA!","v"),Pt.boost(),Dn(40),Is("Largada perfeita!",!0)):ot.pressT>1.4&&(ot.stun=.7,Re("QUEIMOU A LARGADA!","r"))),ge.forEach(s=>{!s.isPlayer&&Math.random()<.35&&(s.mini=.8)}))}ge.forEach(va),Ah(ot,n),Ad(n)}else if(kt==="race"||kt==="finished"){Yn+=n;for(let e of ge)Th(e,e.isPlayer&&!e.finished?Cd():wh(e,n),n);tp(n);for(let e of ge)va(e),uM(e,n);if(kt==="finished"){Ui+=n;let e=ot.D.root.position,i=Ui*.45+ot.h+Math.PI;Pi.set(e.x+Math.sin(i)*8,3.2,e.z+Math.cos(i)*8),me.position.lerp(Pi,1-Math.exp(-3*n)),me.lookAt(e.x,1.3+ot.y,e.z),(Ui>7||Ui>3.5&&ge.every(s=>s.finished))&&mp()}else Ah(ot,n);if(kt!=="results"){Ad(n),lp(n);let e=Math.hypot(ot.vx,ot.vz);su(ot.nitroOn?.55:ot.pad>0||ot.mini>0?.3:le((e-40)/40,0,.18),ot.nitroOn?1:0),Pt.ctx&&(Pt.setLoop("wind",le(e/60,0,1)*.12,700+e*30),Pt.setLoop("skid",ot.drifting&&!ot.air?.16:ot.surf==="ice"&&Math.abs(ot.slide)>3?.08:0),Pt.setLoop("nitro",ot.nitroOn?.3:0))}}else if(kt==="results"){for(let i of ge)Th(i,wh(i,n),n),va(i);let e=ot.D.root.position;_r+=n*.3,Pi.set(e.x+Math.cos(_r)*12,6,e.z+Math.sin(_r)*12),me.position.lerp(Pi,1-Math.exp(-2*n)),me.lookAt(e.x,1,e.z)}gc.position.copy(me.position);let t=ot?ot.D.root.position:Xe?Xe.root.position:$e[0];En.target.position.copy(t),En.position.copy(t).addScaledVector(mh,150),$n.render(sn,me)}Id();Gv();Yh(H.track);di();Me("loading",!1);xp();function NM(n,t){let e=.016666666666666666;for(let i=0;i<n&&(kt==="race"||kt==="finished");i+=e){Yn+=e,In+=e,qh(In),qd(e,kt==="race"),sp(e);for(let s of ge)Th(s,s.isPlayer&&!s.finished?t(ot,Yn):wh(s,e),e);tp(e),kt==="race"&&lp(e),kt==="finished"&&(Ui+=e,(Ui>7||Ui>3.5&&ge.every(s=>s.finished))&&mp())}ge.forEach(va)}window.__game={sim:NM,bgm:Tn,debugBall(){let n=Rr[0];qh(n.period-n.off+1.4-n.period*50);let t=ze(n.s-14,-4,3.5),e=ze(n.s,0,1);me.position.copy(t),me.lookAt(e)},skipCountdown(){Ma=.01},get state(){return kt},get player(){return ot},get runners(){return ge},startRace:Ds,save:H,renderer:$n,scene:sn,camera:me,get L(){return ve}};})();
/*! Bundled license information:

three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2023 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
